param([int]$OwnerPid = 0, [string]$ProjectPath)
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Threading;

public static class ProcodeClientJob {
  [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
  static extern IntPtr CreateFile(string name, uint access, uint share, IntPtr security, uint creation, uint flags, IntPtr template);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool GetFileInformationByHandleEx(IntPtr handle, int infoClass, [Out] byte[] data, uint size);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
  [DllImport("kernel32.dll", SetLastError=true, CharSet=CharSet.Unicode)]
  static extern IntPtr CreateJobObject(IntPtr attributes, string name);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool SetInformationJobObject(IntPtr job, int infoClass, byte[] data, uint size);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool QueryInformationJobObject(IntPtr job, int infoClass, [Out] byte[] data, uint size, IntPtr returned);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern bool TerminateJobObject(IntPtr job, uint exitCode);
  [DllImport("kernel32.dll", SetLastError=true)]
  static extern uint WaitForSingleObject(IntPtr handle, uint timeout);
  [DllImport("kernel32.dll")]
  static extern bool CloseHandle(IntPtr handle);

  public static string DirectoryId(string dir) {
    // FILE_FLAG_BACKUP_SEMANTICS opens a directory. Allow rename/delete while querying.
    IntPtr handle = CreateFile(dir, 0x80, 7, IntPtr.Zero, 3, 0x02000000, IntPtr.Zero);
    if (handle == new IntPtr(-1)) throw new Win32Exception();
    try {
      byte[] data = new byte[24];
      if (!GetFileInformationByHandleEx(handle, 18, data, (uint)data.Length)) throw new Win32Exception();
      string fileId = BitConverter.ToString(data, 8).Replace("-", "");
      if (fileId.Trim('0').Length == 0) throw new InvalidOperationException("File ID is not supported on this volume");
      return BitConverter.ToUInt64(data, 0).ToString("X16") + ":" + fileId;
    } finally { CloseHandle(handle); }
  }

  public static void Watch(int pid) {
    const uint processAccess = 0x00100000 | 0x0100 | 0x0001; // SYNCHRONIZE | SET_QUOTA | TERMINATE
    IntPtr owner = OpenProcess(processAccess, false, pid);
    if (owner == IntPtr.Zero) throw new Win32Exception();
    IntPtr job = IntPtr.Zero;
    try {
      job = CreateJobObject(IntPtr.Zero, null);
      if (job == IntPtr.Zero) throw new Win32Exception();
      // JOBOBJECT_EXTENDED_LIMIT_INFORMATION, LimitFlags at offset 16 on either ABI.
      byte[] limits = new byte[IntPtr.Size == 8 ? 144 : 112];
      BitConverter.GetBytes((uint)0x2000).CopyTo(limits, 16); // KILL_ON_JOB_CLOSE
      if (!SetInformationJobObject(job, 9, limits, (uint)limits.Length)) throw new Win32Exception();
      if (!AssignProcessToJobObject(job, owner)) throw new Win32Exception();
      Console.WriteLine("READY");
      Console.Out.Flush();
      if (WaitForSingleObject(owner, uint.MaxValue) != 0) throw new Win32Exception();
      if (!TerminateJobObject(job, 1)) throw new Win32Exception();
      // Wait for the OS to reap the last member before the supervisor exits.
      byte[] accounting = new byte[48];
      while (true) {
        if (!QueryInformationJobObject(job, 1, accounting, (uint)accounting.Length, IntPtr.Zero)) throw new Win32Exception();
        if (BitConverter.ToUInt32(accounting, 40) == 0) break;
        Thread.Sleep(50);
      }
    } finally {
      if (job != IntPtr.Zero) CloseHandle(job);
      CloseHandle(owner);
    }
  }
}
'@

if ($ProjectPath) {
  [Console]::WriteLine([ProcodeClientJob]::DirectoryId($ProjectPath))
} elseif ($OwnerPid -gt 0) {
  [ProcodeClientJob]::Watch($OwnerPid)
} else {
  throw 'ProjectPath or OwnerPid is required'
}
