/**
 * 澄清选项视觉示意（内联 SVG）的渲染前校验 —— debug 页专用版本。
 *
 * 与 procode-ide 的 `packages/ide-procode/src/components/s-chat/Messages/ask/preview.ts` 同口径：
 * 那份是 IDE 的唯一实现，这份是 debug 页（vanilla、无构建）可加载的等价实现。
 * 改任何一条规则都必须两边一起改；`tests/opencode/ask-preview-parity.test.ts` 用同一张样本表
 * 锁住两边的判定结果，防止一边放宽、一边收紧。
 *
 * 安全说明（同 IDE）：真正兜底的是「按图片渲染」（<img src="data:image/svg+xml,…">），
 * 脚本/事件/外部资源在该上下文里不生效；本模块只是预检，不是完备白名单。
 */
(function (global) {
  var MAX_PREVIEW_CHARS = 4096;
  var SVG_NS = 'http://www.w3.org/2000/svg';
  var XLINK_NS = 'http://www.w3.org/1999/xlink';

  var ALLOWED_TAGS = [
    'svg', 'g', 'defs', 'symbol', 'use', 'rect', 'circle', 'ellipse', 'line', 'polyline',
    'polygon', 'path', 'text', 'tspan', 'title', 'desc', 'lineargradient', 'radialgradient',
    'stop', 'clippath', 'mask',
  ];
  var DRAWABLE_TAGS = ['rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon', 'path', 'text', 'use'];
  var DEFINITION_TAGS = [
    'defs', 'symbol', 'clippath', 'mask', 'lineargradient', 'radialgradient', 'stop', 'title', 'desc',
  ];
  var FORBIDDEN_TEXT = [
    /<\s*script\b/i,
    /<\s*foreignobject\b/i,
    /<\s*style\b/i,
    /<\s*image\b/i,
    /<\s*iframe\b/i,
    /<\s*object\b/i,
    /<\s*embed\b/i,
    /<\s*!entity\b/i,
    /@import/i,
  ];

  function hasExternalUrlRef(text) {
    var re = /\burl\s*\(([^)]*)\)/gi;
    var matched;
    while ((matched = re.exec(text))) {
      if (!/^\s*['"]?\s*#/.test(matched[1] || '')) return true;
    }
    return false;
  }

  function hasNonAnchorHref(text) {
    var re = /\b(?:xlink:)?href\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'>]+))/gi;
    var matched;
    while ((matched = re.exec(text))) {
      var value = matched[2] || matched[3] || matched[4] || '';
      if (value.trim().charAt(0) !== '#') return true;
    }
    return false;
  }

  function ensureNamespaces(svg) {
    var out = svg;
    if (!/\sxmlns\s*=/.test(out)) out = out.replace(/^<svg/i, '<svg xmlns="' + SVG_NS + '"');
    if (/xlink:/.test(out) && !/xmlns:xlink\s*=/.test(out)) {
      out = out.replace(/^<svg/i, '<svg xmlns:xlink="' + XLINK_NS + '"');
    }
    return out;
  }

  function elementName(el) {
    return String(el.localName || el.nodeName || '').toLowerCase();
  }

  function isInsideDefinition(el) {
    var parent = el.parentElement;
    while (parent) {
      if (DEFINITION_TAGS.indexOf(elementName(parent)) >= 0) return true;
      parent = parent.parentElement;
    }
    return false;
  }

  function isStructurallySafe(doc) {
    var all = doc.getElementsByTagName('*');
    for (var i = 0; i < all.length; i += 1) {
      var el = all[i];
      if (ALLOWED_TAGS.indexOf(elementName(el)) < 0) return false;
      var attrs = el.attributes || [];
      for (var j = 0; j < attrs.length; j += 1) {
        var name = String(attrs[j].name || '').toLowerCase();
        var value = attrs[j].value || '';
        if (name.indexOf('on') === 0) return false;
        if ((name === 'href' || name === 'xlink:href') && value.trim().charAt(0) !== '#') return false;
        if (hasExternalUrlRef(value)) return false;
      }
    }
    return true;
  }

  function hasDrawableContent(doc) {
    var all = doc.getElementsByTagName('*');
    for (var i = 0; i < all.length; i += 1) {
      var el = all[i];
      if (DRAWABLE_TAGS.indexOf(elementName(el)) < 0) continue;
      if (!isInsideDefinition(el)) return true;
    }
    return false;
  }

  function parseSvg(svg) {
    if (typeof DOMParser === 'undefined') return null;
    try {
      var doc = new DOMParser().parseFromString(svg, 'image/svg+xml');
      if (doc.getElementsByTagName('parsererror').length > 0) return null;
      return doc;
    } catch (err) {
      return null;
    }
  }

  /** 校验并规范化；不合法返回 null（调用方按「无图、文字照常」处理） */
  function normalizeSvgPreview(raw) {
    if (typeof raw !== 'string') return null;
    var svg = raw.trim();
    if (!svg || svg.length > MAX_PREVIEW_CHARS) return null;
    if (!/^<svg[\s>]/i.test(svg) || !/<\/svg>$/i.test(svg)) return null;
    for (var i = 0; i < FORBIDDEN_TEXT.length; i += 1) {
      if (FORBIDDEN_TEXT[i].test(svg)) return null;
    }
    if (hasNonAnchorHref(svg) || hasExternalUrlRef(svg)) return null;
    var withNs = ensureNamespaces(svg);
    var doc = parseSvg(withNs);
    if (!doc || elementName(doc.documentElement) !== 'svg') return null;
    if (!isStructurallySafe(doc)) return null;
    if (!hasDrawableContent(doc)) return null;
    return withNs;
  }

  function toSvgDataUri(svg) {
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }

  /** 一步到位：非法输入返回空串 */
  function toPreviewSrc(raw) {
    var svg = normalizeSvgPreview(raw);
    return svg ? toSvgDataUri(svg) : '';
  }

  global.AskPreview = {
    MAX_PREVIEW_CHARS: MAX_PREVIEW_CHARS,
    ALLOWED_TAGS: ALLOWED_TAGS,
    DRAWABLE_TAGS: DRAWABLE_TAGS,
    DEFINITION_TAGS: DEFINITION_TAGS,
    normalizeSvgPreview: normalizeSvgPreview,
    toSvgDataUri: toSvgDataUri,
    toPreviewSrc: toPreviewSrc,
  };
})(typeof window !== 'undefined' ? window : globalThis);
