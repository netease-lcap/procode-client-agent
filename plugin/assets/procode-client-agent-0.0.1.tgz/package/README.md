# procode-client-agent 小型安装包

安装：npm i -g /absolute/path/procode-client-agent-0.0.1.tgz
检查命令：procode-client-agent --help
查看构建信息：procode-client-agent --build-info
执行 client 全部阶段：procode-client-agent --workdir /absolute/path/resources
可选：--mode <mode>（默认 client）、--session-id <id>、--requirement <text>。模型及数据服务通过环境变量配置。
同一项目默认复用现有实例。同卷移动项目后自动清理旧实例再启动；使用 --restart 主动重启。跨卷移动可用 --previous-workdir <原项目或原资源目录> 接管已登记的旧实例。只能清理可确认归属的进程。
client 模式默认在工作区 .data/client-task-history 下按需求、工程与原始 description 记录成功的 Agent 任务，再次启动自动跳过。失败、中断及脚本/命令任务不缓存；没有活动需求目录时不启用。使用 --rerun 强制重新执行；需求、提示词或产物已调整但任务名称未变时应使用此选项。同一轮内的验收/修复复跑不会被跳过。
默认启动仅监听 127.0.0.1 的本地交互服务，端口由系统动态分配，只输出当前 session 的页面地址，不自动打开浏览器；多个项目互不占用固定端口。--no-open 保留兼容，--no-ui 仅在终端运行。
显式传入 --open 才会尝试使用系统默认浏览器打开交互页面；--no-open 明确关闭，--no-ui 时不打开。无法启动浏览器不会中断任务，可手动访问输出的地址。
成功、失败或主动停止后会清理本轮 OpenCode 和可确认归属的子进程、关闭交互服务并退出 CLI。回看可使用终端输出的执行日志与结果文件。页面「停止任务」或 Ctrl+C 会取消执行；关闭标签页不会停止。第二次 Ctrl+C 可提前进入清理；不回滚已写入的代码，执行中 SIGINT/SIGTERM 的退出码为 130/143。
交互模式终端仅显示页面地址、日志位置及执行结果提示；执行过程在页面查看，console/stdio 明细保存到 workdir/.data/client-logs/，日志文件仅当前用户可读写。--no-ui 保留终端执行日志。

要求 Node.js >=22.13.0。包内含服务 bundle、合并依赖后的 CLI、页面及 gitignore 基线。
不依赖独立的 @lcap/opencode-runtime 安装；随包携带干净的运行模板，不包含开发源码、类型声明、示例项目、日志或 node_modules。
包内 dist/index.js 在发布暂存阶段压缩并混淆，不分发 source map、类型声明或标识符还原表；开发 dist 不变。混淆提高阅读门槛，不等于不可逆加密；模板和其它运行文件不属于本次混淆范围。
本包只注册 procode-client-agent，内部调用 speckit.executorByPhase('client')，不启动 Spec Server，不注册 procode-agent 或绑定仓库目录的 procode-speckit 调试命令。
安装 zod 时 npm 可能访问 registry；本地 tgz 不代表离线安装包。

执行前检查起点及最多五级父目录；目录自身包含 docs 时，以该目录名覆盖 APP_NAME。否则从直接子目录中选择包含 docs 的唯一应用并覆盖 APP_NAME；多个应用须明确设置 APP_NAME。
procode 自身源码仓库、全局安装目录及其子目录禁止作为应用初始化；父目录选择到这类源码包也会拒绝，避免把开发 docs 误认成应用需求。请用 --workdir 指向独立的实际应用目录。
首次执行将应用整体移动到同级的 {APP_NAME}-resources/{APP_NAME}，外层资源目录作为流水线 workdir；已符合该结构时跳过移动。从资源目录、项目目录或项目子目录再次启动都复用该工作区。已有目标目录不覆盖、不合并；Git worktree 或子模块不自动移动。
匹配成功后将包内 template 内容补缺到 workdir，不覆盖已有文件，_gitignore 映射为工作区 .gitignore；帮助和构建信息查询不初始化。
启动任务前自动检测 OpenCode 1.18.18，版本匹配则跳过；缺失或不匹配时通过 npm 全局安装并验证，同时接入 npm 全局命令目录到当前进程 PATH。安装需要可用的 npm、registry 网络和全局目录写权限，失败则停止，不搬移项目、不执行 AI 任务。--help 和 --build-info 不触发检测或安装。
完整 AI 工作流仍需必要原生工具、模板 .opencode/package.json 声明的依赖和模型/数据服务配置。
本包尚不提供运行环境自动检测安装；不会通过 postinstall 隐式安装系统软件或更改用户环境。
