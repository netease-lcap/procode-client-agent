/* Bundled OpenCode plugin: plugin-opencode-prefill-guard — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-opencode-prefill-guard.ts
function endsWithToolCallAttempt(parts) {
  const text = parts.filter((p) => p.type === "text").map((p) => {
    const t = p.text;
    return typeof t === "string" ? t : "";
  }).join("").trimEnd();
  if (!text) return false;
  const lastOpen = text.lastIndexOf("<invoke");
  if (lastOpen < 0) return false;
  const closeIdx = text.indexOf("</invoke>", lastOpen);
  if (closeIdx < 0) return true;
  const after = text.slice(closeIdx + "</invoke>".length).trim();
  return after.length === 0;
}
async function opencodePrefillGuardPlugin() {
  return {
    "experimental.chat.messages.transform": async (_input, output) => {
      try {
        const out = output;
        const msgs = out.messages;
        if (!msgs?.length) return;
        const last = msgs[msgs.length - 1];
        if (last.info.role !== "assistant") return;
        const hasToolParts = last.parts.some((p) => p.type === "tool");
        if (last.info.finish === "tool-calls" && !hasToolParts) {
          console.warn(
            `[plugin-opencode-prefill-guard] strip terminal assistant id=${last.info.id ?? "unknown"}: finish=tool-calls \u65E0 tool part\uFF08\u5DE5\u5177\u8C03\u7528\u89E3\u6790\u5931\u8D25\uFF09`
          );
          msgs.pop();
          return;
        }
        if (last.info.finish === "stop" && !hasToolParts && endsWithToolCallAttempt(last.parts)) {
          console.warn(
            `[plugin-opencode-prefill-guard] strip terminal assistant id=${last.info.id ?? "unknown"}: finish=stop + \u65E0 tool part + \u5C3E\u90E8 <invoke> \u8C03\u7528\uFF08\u5DE5\u5177\u8C03\u7528\u964D\u7EA7\u4E3A\u6587\u672C\uFF09`
          );
          msgs.pop();
          return;
        }
      } catch {
      }
    }
  };
}
var plugin_opencode_prefill_guard_default = {
  id: "plugin-opencode-prefill-guard",
  server: opencodePrefillGuardPlugin
};
export {
  plugin_opencode_prefill_guard_default as default
};
