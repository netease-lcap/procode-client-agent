/* Bundled OpenCode plugin: plugin-spec-lifecycle-file-guard — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-spec-lifecycle-file-guard.ts
import fs3 from "node:fs";
import os from "node:os";
import path3 from "node:path";

// src/opencode/spec-ctx-file.ts
import fs from "node:fs";
import path from "node:path";
function openCodeSpecCtxPath(workdir, waveSessionId) {
  return path.join(workdir, ".temp", `spec_ctx_${waveSessionId}.json`);
}
function readOpenCodeSpecCtx(workdir, waveSessionId) {
  const fp = openCodeSpecCtxPath(workdir, waveSessionId);
  if (!fs.existsSync(fp)) {
    return null;
  }
  try {
    const raw = JSON.parse(fs.readFileSync(fp, "utf8"));
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
      return null;
    }
    const o = raw;
    const sid = typeof o.waveSessionId === "string" ? o.waveSessionId.trim() : "";
    const specDir = typeof o.specDir === "string" ? o.specDir.trim().replace(/\\/g, "/") : "";
    if (!sid || !specDir) {
      return null;
    }
    return { waveSessionId: sid, specDir };
  } catch {
    return null;
  }
}

// src/utils/spec-lifecycle-file-guard.ts
import fs2 from "node:fs";
import path2 from "node:path";

// src/utils/constants.ts
var SPEC_METADATA_FILE = "metadata.json";

// src/utils/docs-paths.ts
var DOCS_TIMESTAMP_RE = /^\d{4}-\d{2}-\d{2}-\d{2}-\d{2}-\d{2}(-\d{1,3})?$/;
function tryGetAppName() {
  const appName = process.env.APP_NAME?.trim();
  return appName || null;
}
function isDocsTimestampDirName(name) {
  return DOCS_TIMESTAMP_RE.test(name);
}

// src/utils/spec-lifecycle-status.ts
var SPEC_LIFECYCLE_STATUSES = ["ACTIVE", "COMPLETED", "DEPRECATED"];
function parseLifecycleStatus(value) {
  if (typeof value !== "string") {
    return null;
  }
  const normalized = value.trim().toUpperCase();
  return SPEC_LIFECYCLE_STATUSES.includes(normalized) ? normalized : null;
}

// src/utils/spec-lifecycle-file-guard.ts
function toWorkdirRelativePosix(workdir, filePath) {
  const trimmed = filePath.trim();
  if (!trimmed) {
    return null;
  }
  const root = path2.resolve(workdir);
  const abs = path2.isAbsolute(trimmed) ? path2.normalize(trimmed) : path2.resolve(root, trimmed);
  if (abs !== root && !abs.startsWith(root + path2.sep)) {
    return null;
  }
  const rel = path2.relative(root, abs);
  if (!rel || rel.startsWith("..")) {
    return null;
  }
  return rel.split(path2.sep).join("/");
}
function resolveOwningSpecDirRel(relPosix) {
  const parts = relPosix.split("/").filter(Boolean);
  const appName = tryGetAppName();
  if (!appName || parts.length < 3 || parts[0] !== appName || parts[1] !== "docs") {
    return null;
  }
  const folder = parts[2];
  if (!folder || folder === ".meta" || folder.startsWith(".") || !isDocsTimestampDirName(folder)) {
    return null;
  }
  return `${appName}/docs/${folder}`;
}
function normalizeSpecDirRel(specDir) {
  const normalized = specDir.trim().replace(/\\/g, "/").replace(/^\.\//, "").replace(/\/+$/, "");
  if (!normalized) {
    return null;
  }
  const asFileUnderSpec = resolveOwningSpecDirRel(`${normalized}/_`);
  if (asFileUnderSpec) {
    return asFileUnderSpec;
  }
  const parts = normalized.split("/").filter(Boolean);
  const appName = tryGetAppName();
  if (appName && parts.length === 3 && parts[0] === appName && parts[1] === "docs" && isDocsTimestampDirName(parts[2])) {
    return `${appName}/docs/${parts[2]}`;
  }
  return null;
}
function readLifecycleStatusForSpecDir(workdir, specDirRelOrAbs) {
  const abs = path2.isAbsolute(specDirRelOrAbs) ? path2.normalize(specDirRelOrAbs) : path2.resolve(workdir, specDirRelOrAbs);
  const metadataPath = path2.join(abs, SPEC_METADATA_FILE);
  if (!fs2.existsSync(metadataPath)) {
    return null;
  }
  try {
    const metadata = JSON.parse(fs2.readFileSync(metadataPath, "utf-8"));
    return parseLifecycleStatus(metadata.lifecycleStatus);
  } catch {
    return null;
  }
}
function evaluateCrossSpecWriteGuard(input) {
  const rel = toWorkdirRelativePosix(input.workdir, input.filePath);
  if (!rel) {
    return { allow: true };
  }
  const owning = resolveOwningSpecDirRel(rel);
  if (!owning) {
    return { allow: true };
  }
  const current = input.currentSpecDirRel ? normalizeSpecDirRel(input.currentSpecDirRel) : null;
  if (!current) {
    return { allow: true };
  }
  if (owning === current) {
    return { allow: true };
  }
  return { allow: false, reason: `\u7981\u6B62\u5199\u5165\u5176\u5B83 Spec \u76EE\u5F55\uFF1A${rel}` };
}
function evaluateDeprecatedSpecReadGuard(input) {
  const rel = toWorkdirRelativePosix(input.workdir, input.filePath);
  if (!rel) {
    return { allow: true };
  }
  const owning = resolveOwningSpecDirRel(rel);
  if (!owning) {
    return { allow: true };
  }
  const status = readLifecycleStatusForSpecDir(input.workdir, owning);
  if (status === "DEPRECATED") {
    return { allow: false, reason: `\u7981\u6B62\u8BFB\u53D6\u5DF2\u5E9F\u5F03 Spec \u4E0B\u7684\u6587\u4EF6\uFF1A${rel}` };
  }
  return { allow: true };
}
function extractToolFilePath(args) {
  if (!args || typeof args !== "object") {
    return null;
  }
  const a = args;
  const fp = a.filePath ?? a.path ?? a.file_path;
  if (typeof fp === "string" && fp.trim()) {
    return fp.trim();
  }
  return null;
}

// src/opencode/plugin-spec-lifecycle-file-guard.ts
var WRITE_TOOLS = /* @__PURE__ */ new Set(["write", "edit"]);
var READ_TOOLS = /* @__PURE__ */ new Set(["read"]);
function deployManifestWriteTargets(toolId, args) {
  const direct = extractToolFilePath(args);
  const targets = direct ? [direct] : [];
  if (toolId !== "apply_patch" || typeof args?.patchText !== "string") return targets;
  for (const match of args.patchText.matchAll(/^\*\*\* (?:Add File|Update File|Delete File|Move to): (.+)$/gm)) {
    targets.push(match[1].trim());
  }
  return targets;
}
function resolveWaveSessionId(openCodeSessionId) {
  if (openCodeSessionId) {
    const overlayPath = path3.join(os.homedir(), ".wave", "opencode", `shell-env-${openCodeSessionId}.json`);
    try {
      const raw = JSON.parse(fs3.readFileSync(overlayPath, "utf8"));
      const waveSessionId = typeof raw.WAVE_SESSION_ID === "string" ? raw.WAVE_SESSION_ID.trim() : "";
      if (waveSessionId) return waveSessionId;
    } catch {
    }
  }
  return process.env.WAVE_SESSION_ID?.trim() || null;
}
function resolveCurrentSpecDirRel(workdir, openCodeSessionId) {
  const waveSessionId = resolveWaveSessionId(openCodeSessionId);
  if (!waveSessionId) {
    return null;
  }
  const ctx = readOpenCodeSpecCtx(workdir, waveSessionId);
  return ctx?.specDir ?? null;
}
async function specLifecycleFileGuardPlugin() {
  return {
    "tool.execute.before": async (input, output) => {
      const toolId = String(input.tool ?? "").toLowerCase();
      const workdir = process.cwd();
      if (WRITE_TOOLS.has(toolId) || toolId === "apply_patch") {
        for (const target of deployManifestWriteTargets(toolId, output.args)) {
          if (toWorkdirRelativePosix(workdir, target)?.toLowerCase() === ".manifest/deploy.json") {
            throw new Error("\u7981\u6B62\u76F4\u63A5\u4FEE\u6539\u90E8\u7F72\u6E05\u5355\uFF08.manifest/deploy.json\uFF09\uFF1A\u8BF7\u901A\u8FC7 deploy-tool \u90E8\u7F72\u5951\u7EA6\u767B\u8BB0\u6216\u66F4\u65B0\u670D\u52A1\u4E8B\u5B9E\u3002");
          }
        }
      }
      const filePath = extractToolFilePath(output.args);
      if (!filePath) {
        return;
      }
      if (WRITE_TOOLS.has(toolId)) {
        const decision = evaluateCrossSpecWriteGuard({
          workdir,
          filePath,
          currentSpecDirRel: resolveCurrentSpecDirRel(workdir, String(input.sessionID ?? ""))
        });
        if (decision.allow === false) {
          throw new Error(decision.reason);
        }
        return;
      }
      if (READ_TOOLS.has(toolId)) {
        const decision = evaluateDeprecatedSpecReadGuard({ workdir, filePath });
        if (decision.allow === false) {
          throw new Error(decision.reason);
        }
      }
    }
  };
}
var plugin_spec_lifecycle_file_guard_default = {
  id: "plugin-spec-lifecycle-file-guard",
  server: specLifecycleFileGuardPlugin
};
export {
  plugin_spec_lifecycle_file_guard_default as default
};
