/* Bundled OpenCode plugin: plugin-question-schema — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-question-schema.ts
var HICODE_ASK_META_LABEL = "__hicode_ask_meta__";
var ASK_PREVIEW_MAX_CHARS = 4096;
var VISUAL_TONE_QUESTION_HEADER = "\u57FA\u8C03";
var CUSTOM_OPTION_LABEL_PATTERN = /^(?:其他|其它)/;
var QUESTION_INPUT_SCHEMA_HINT = `
Extended fields (must pass through even if the base schema omits them):
- option.isRecommended?: boolean
- option.preview?: string \u2014 two accepted forms. Preferred: a **reference** "ref:<path relative to the working directory>" to a ".svg" file already written on disk under "pieces/question-previews/<service>__<module>/<name>.svg": exactly one sub-directory level, whose name is "<service>__<module>" (the per-task preview directory name the task gives you \u2014 do not write into the "pieces/question-previews/" root and do not add a second level), then one file name segment: letters, digits, ".", "_", "-", extension ".svg". The base is the task working directory from the task input (the workspace root that contains the app folders), so the reference must carry the whole relative path down to that file \u2014 a bare file name is not enough. The host reads that file and validates the resolved content. Size: the host keeps a 16KB (16384 bytes) safety valve on the referenced file (anything bigger is dropped) \u2014 that is a backstop for huge files, **not a size target**: normal samples are far smaller, so never drop content, shrink or rewrite a sample just to fit a number. There is **no character limit** on the resolved SVG content. Legacy **inline SVG** is still accepted: a plain string that starts with "<svg" and ends with "</svg>"; only that inline string is capped at 4096 characters \u2014 the 4096 does not apply to a reference. The element rules below apply to the **resolved SVG content** (the file a reference points to, or the inline string), never to the "ref:" string itself. Supported elements: svg,g,defs,symbol,use,rect,circle,ellipse,line,polyline,polygon,path,text,tspan,title,desc,linearGradient,radialGradient,stop,clipPath,mask. NOT supported: filter/feDropShadow, pattern, marker, textPath (whole sample is dropped). Internal references are allowed (<use href="#id">, fill="url(#id)"); any external href/src/url is rejected, as are <script>, on* handlers, <foreignObject>, <image>, <style>, <a>, animation. A sample with no drawable element (empty svg, defs-only) is dropped. Rendered as an image, so scripts/external resources/clicks never happen.
- **Tone question: every candidate must carry a preview.** The style/tone question is the one whose "header" is exactly "\u57FA\u8C03" (the middle of the three visual-direction questions \u7528\u9014 / \u57FA\u8C03 / \u8FA8\u8BC6\u70B9). Every option of that question must carry preview \u2014 a "ref:..." reference (preferred) or an inline SVG. A call where any candidate (except the custom "\u5176\u4ED6" option) has no preview is **rejected before the user sees it** and must be resent with the missing samples added: never drop the candidate, never move the SVG into description, never fill in a placeholder graphic. Purpose (\u7528\u9014) / \u8FA8\u8BC6\u70B9 / technology-choice questions must NOT carry previews.
- **options[].label must be unique within a question** (after trim; duplicate labels make the answers indistinguishable \u2014 the answer record keys on the label string).
- question.input is exactly one kind. Do not mix fields across kinds. Rich kinds use options: [].
- fileUpload: { kind: "fileUpload", title, submitLabel?, description?, accept?, required?, multiple?, maxCount?, maxSize?, supplementPlaceholder? }
- fileUploadChecklist: { kind: "fileUploadChecklist", items: Array<{ name: string, tag?: string }>, submitLabel?, listTitle?, description?, maxSize? }. items[].name unique, with version and suffix.
- dataSourceSelect: { kind: "dataSourceSelect", databaseName, sources: Array<{ title: string, description?: string }>, submitLabel? }. sources[].title unique in this question.
- form: { kind: "form", formItems: Array<{ key, name, inputType: "text" | "textarea" | "number" | "password" | "select", required, lineRegion: "whole" | "half", value, defaultValue?, placeholder?, regex?, validateMessage?, selectValues?: Array<{ name, value }>, multiple? }>, submitLabel? }. formItems[].key unique. Do not use fields.
- gitRepoSelect: { kind: "gitRepoSelect", submitLabel? }. options: []. IDE scans tenant Git and project then rebinds. Do not pass credential or repo lists.
`;
function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function isUsablePreview(value) {
  return typeof value === "string" && value.trim().length > 0 && value.length <= ASK_PREVIEW_MAX_CHARS;
}
function collectPreviews(options) {
  const previews = /* @__PURE__ */ Object.create(null);
  for (const item of options) {
    const label = typeof item.label === "string" ? item.label.trim() : "";
    if (!label || previews[label]) {
      continue;
    }
    if (isUsablePreview(item.preview)) {
      previews[label] = item.preview;
    }
  }
  return previews;
}
function questionHasPreviews(raw) {
  if (!Array.isArray(raw.options)) {
    return false;
  }
  return raw.options.some((item) => isRecord(item) && isUsablePreview(item.preview));
}
function dedupeOptionsByLabel(raw) {
  if (!Array.isArray(raw.options)) {
    return;
  }
  const seen = /* @__PURE__ */ new Set();
  raw.options = raw.options.filter((item) => {
    if (!isRecord(item) || typeof item.label !== "string") {
      return true;
    }
    const label = item.label.trim();
    if (!label) {
      return true;
    }
    if (seen.has(label)) {
      return false;
    }
    seen.add(label);
    return true;
  });
}
function assertUniqueOptionLabels(args) {
  if (!Array.isArray(args?.questions)) {
    return;
  }
  args.questions.forEach((raw, index) => {
    if (!isRecord(raw)) {
      return;
    }
    const options = Array.isArray(raw.options) ? raw.options : [];
    const seen = /* @__PURE__ */ new Set();
    for (const item of options) {
      if (!isRecord(item) || typeof item.label !== "string") {
        continue;
      }
      const label = item.label.trim();
      if (seen.has(label)) {
        throw new Error(
          `question options[].label must be unique within a question\uFF08\u9009\u9879 label \u649E\u540D\uFF09\uFF1A\u7B2C ${index + 1} \u9898\u91CC label "${label}" \u51FA\u73B0\u4E24\u6B21\u53CA\u4EE5\u4E0A \u2014\u2014 \u7528\u6237\u65E0\u6CD5\u533A\u5206\u8FD9\u4E24\u4E2A\u9009\u9879\uFF0C\u4E14\u7B54\u6848**\u6309 label \u5B57\u7B26\u4E32\u8BB0\u5F55**\uFF08answers=["${label}"]\uFF09\u21D2 \u540C label \u7684\u7B54\u590D\u4E0D\u53EF\u6D88\u6B67\uFF08\u65B9\u6848\u4E5F\u5206\u4E0D\u6E05\u7528\u6237\u5230\u5E95\u9009\u4E86\u54EA\u4E2A\uFF09\u3002\u8BF7\u628A\u91CD\u590D\u7684\u9009\u9879\u6539\u6210**\u4E92\u5F02\u7684 label**\uFF08\u4F8B\u5982\u5404\u81EA\u5E26\u4E0A\u65B9\u6848\u540D / \u7248\u672C\u53F7\uFF09\u540E\u91CD\u53D1\u672C\u9898\uFF1B\u4E0D\u8981\u9760 description \u533A\u5206\uFF08\u8BB0\u5F55\u91CC\u53EA\u7559 label\uFF09\u3002`
        );
      }
      seen.add(label);
    }
  });
}
function assertToneCandidatesHavePreview(args) {
  if (!Array.isArray(args?.questions)) {
    return;
  }
  args.questions.forEach((raw, questionIndex) => {
    if (!isRecord(raw) || typeof raw.header !== "string") {
      return;
    }
    if (raw.header.trim() !== VISUAL_TONE_QUESTION_HEADER) {
      return;
    }
    const options = Array.isArray(raw.options) ? raw.options : [];
    const missing = [];
    let candidates = 0;
    options.forEach((item, optionIndex) => {
      if (!isRecord(item)) {
        return;
      }
      const label = typeof item.label === "string" ? item.label.trim() : "";
      if (CUSTOM_OPTION_LABEL_PATTERN.test(label)) {
        return;
      }
      candidates += 1;
      if (!isUsablePreview(item.preview)) {
        missing.push({ position: optionIndex + 1, label: label || "(\u7A7A label)" });
      }
    });
    if (missing.length === 0) {
      return;
    }
    console.warn(
      `[plugin-question-schema] tone candidate preview missing ${JSON.stringify({
        questionIndex: questionIndex + 1,
        header: raw.header.trim(),
        candidates,
        missing
      })}`
    );
    const detail = missing.map((item) => `\u7B2C ${item.position} \u4E2A\u9009\u9879\u300C${item.label}\u300D`).join("\u3001");
    throw new Error(
      `question options[].preview is required for every tone candidate\uFF08\u57FA\u8C03\u9898\u6BCF\u4E2A\u5019\u9009\u90FD\u5FC5\u987B\u914D\u4E00\u5F20\u89C6\u89C9\u5C0F\u6837\uFF09\uFF1A\u7B2C ${questionIndex + 1} \u9898\uFF08header\u300C${VISUAL_TONE_QUESTION_HEADER}\u300D\uFF09\u5171 ${candidates} \u4E2A\u5019\u9009\uFF0C\u5176\u4E2D ${missing.length} \u4E2A\u6CA1\u6709 preview \u2014\u2014 ${detail}\u3002\u7528\u6237\u5C31\u662F\u9760\u8FD9\u4E9B\u5C0F\u6837\u6BD4\u8F83\u98CE\u683C\u5DEE\u5F02\u7684\uFF0C\u7F3A\u4E00\u5F20\u7B49\u4E8E\u8FD9\u4E2A\u5019\u9009\u6CA1\u6709\u53EF\u6BD4\u7684\u6837\u5B50\u3002\u8865\u6CD5\uFF1A\u2460 \u5148\u7528 write \u5DE5\u5177\u628A\u8BE5\u5019\u9009\u7684\u5C0F\u6837\u5355\u72EC\u5199\u6210 "[\u89C4\u8303\u76EE\u5F55\u5BF9\u5E94\u8DEF\u5F84]/pieces/question-previews/<\u672C\u4EFB\u52A1\u7684\u539F\u578B\u9884\u89C8\u76EE\u5F55\u540D\u79F0>/<\u6587\u4EF6\u540D>.svg"\uFF08\u53EA\u843D\u672C\u4EFB\u52A1\u5B50\u76EE\u5F55\uFF0C\u4E0D\u5199 question-previews \u6839\u5C42\uFF0C\u6587\u4EF6\u540D\u53EA\u7528\u5B57\u6BCD/\u6570\u5B57/./_/-\uFF09\uFF1B\u2461 \u518D\u628A\u8BE5\u9009\u9879\u7684 preview \u5199\u6210\u5F15\u7528 "ref:<\u76F8\u5BF9\u5DE5\u4F5C\u76EE\u5F55\u7684\u8DEF\u5F84>"\uFF08\u6574\u6761\u76F8\u5BF9\u8DEF\u5F84\u90FD\u8981\u5E26\uFF0C\u4E0D\u5F97\u53EA\u5199\u6587\u4EF6\u540D\uFF0C\u4F8B\u5982 "ref:app1xxx/docs/<\u65F6\u95F4\u6233>/pieces/question-previews/<\u76EE\u5F55\u540D>/tone-xxx.svg"\uFF09\uFF1B\u4E5F\u63A5\u53D7\u65E7\u5199\u6CD5\u2014\u2014\u76F4\u63A5\u628A "<svg>\u2026</svg>" \u5168\u6587\u653E\u8FDB preview\uFF08\u22644096 \u5B57\u7B26\uFF09\uFF0C\u4F46\u4F18\u5148\u7528 ref:\u3002\u4E0D\u8981\u9760\u8FD9\u4E9B\u7ED5\uFF1A\u5220\u6389\u8BE5\u5019\u9009\u3001\u628A SVG \u585E\u8FDB description\u3001\u5199\u5360\u4F4D/\u88C5\u9970\u6027\u56FE\u5F62\u51D1\u6570\uFF08\u5408\u89C4\u6027\u4E0D\u5408\u683C\u4F1A\u6574\u5F20\u4E22\u5F03\uFF0C\u7528\u6237\u770B\u5230\u7684\u4ECD\u7136\u662F\u6CA1\u6709\u56FE\uFF09\u3002\u7528\u9014\u9898\u3001\u8FA8\u8BC6\u70B9\u9898\u4E0E\u6280\u672F\u9009\u578B\u9898\u4E0D\u914D\u56FE\uFF0C\u4E0D\u5728\u672C\u95E8\u8303\u56F4\u3002\u8865\u9F50\u540E\u91CD\u53D1\u672C\u9898\u3002`
    );
  });
}
function packQuestionAskExtras(args) {
  if (!Array.isArray(args?.questions)) {
    return;
  }
  for (const raw of args.questions) {
    if (!isRecord(raw)) {
      continue;
    }
    const options = Array.isArray(raw.options) ? raw.options.filter(isRecord) : [];
    if (options.some((item) => item.label === HICODE_ASK_META_LABEL)) {
      continue;
    }
    const recommended = options.filter((item) => item.isRecommended === true).map((item) => String(item.label || "")).filter(Boolean);
    const input = raw.input;
    const previews = collectPreviews(options);
    const hasPreviews = Object.keys(previews).length > 0;
    if (!input && recommended.length === 0 && !hasPreviews) {
      continue;
    }
    raw.options = [
      ...options.map((item) => {
        const rest = { ...item };
        delete rest.isRecommended;
        delete rest.preview;
        return rest;
      }),
      {
        label: HICODE_ASK_META_LABEL,
        description: JSON.stringify({
          input: input ?? null,
          recommended,
          ...hasPreviews ? { previews } : {}
        })
      }
    ];
  }
}
async function questionSchemaPlugin() {
  return {
    "tool.definition": async (input, output) => {
      if (input.toolID !== "question") {
        return;
      }
      if (!output.description.includes("formItems")) {
        output.description = `${output.description.trim()}
${QUESTION_INPUT_SCHEMA_HINT}`;
      }
    },
    "tool.execute.before": async (input, output) => {
      if (input.tool !== "question" || !output?.args) {
        return;
      }
      if (Array.isArray(output.args.questions)) {
        for (const raw of output.args.questions) {
          if (isRecord(raw) && questionHasPreviews(raw)) {
            dedupeOptionsByLabel(raw);
          }
        }
      }
      assertUniqueOptionLabels(output.args);
      assertToneCandidatesHavePreview(output.args);
      packQuestionAskExtras(output.args);
    }
  };
}
var plugin_question_schema_default = {
  id: "plugin-question-schema",
  server: questionSchemaPlugin
};
export {
  plugin_question_schema_default as default
};
