/* Bundled OpenCode plugin: plugin-prototype-detect-scope-guard — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-prototype-detect-scope-guard.ts
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
var WRITE_TOOLS = /* @__PURE__ */ new Set(["write", "edit"]);
function readOverlayValue(openCodeSessionId, key) {
  if (!openCodeSessionId) return null;
  const overlayPath = path.join(os.homedir(), ".wave", "opencode", `shell-env-${openCodeSessionId}.json`);
  try {
    const raw = JSON.parse(fs.readFileSync(overlayPath, "utf8"));
    const value = raw?.[key];
    const trimmed = typeof value === "string" ? value.trim() : "";
    return trimmed || null;
  } catch {
    return null;
  }
}
function extractFilePath(args) {
  if (!args) return null;
  const direct = ["filePath", "file_path", "path", "target", "filename"].map((key) => args[key]).find((value) => typeof value === "string" && value.trim().length > 0);
  return direct ? direct.trim() : null;
}
var isInside = (candidate, root) => {
  const relation = path.relative(root, candidate);
  return relation === "" || !relation.startsWith("..") && !path.isAbsolute(relation);
};
var globToRegExp = (glob) => {
  const escaped = glob.replace(/[.+^${}()|[\]\\]/g, "\\$&").replace(/\*\*/g, "\0").replace(/\*/g, "[^/]*").replace(/\u0000/g, ".*").replace(/\?/g, ".");
  return new RegExp(`^${escaped}$`);
};
var evaluateDetectScopeWrite = (input) => {
  const scope = input.scope;
  if (!scope) return { blocked: false };
  if (scope.expiresAt && Date.parse(scope.expiresAt) <= (input.now ?? Date.now())) return { blocked: false };
  const roots = Array.isArray(scope.allowedRoots) ? scope.allowedRoots.filter((root) => typeof root === "string") : [];
  if (!roots.length) return { blocked: false };
  const absolute = path.resolve(input.cwd, input.filePath);
  const protectedGlobs = Array.isArray(scope.protectedGlobs) ? scope.protectedGlobs.filter((glob) => typeof glob === "string") : [];
  if (protectedGlobs.some((glob) => globToRegExp(glob).test(absolute))) {
    return { blocked: true, reason: `\u547D\u4E2D\u53D7\u4FDD\u62A4\u8DEF\u5F84\uFF08\u53EA\u8BFB\uFF09\uFF1A${input.filePath}\uFF08scope=${scope.detection ?? "?"}\uFF09` };
  }
  if (!roots.some((root) => isInside(absolute, path.resolve(root)))) {
    return {
      blocked: true,
      reason: `\u8D8A\u754C\u5199\u5165\uFF1A${input.filePath} \u4E0D\u5728\u5141\u8BB8\u6839\u5185\uFF08scope=${scope.detection ?? "?"}\uFF0CallowedRoots=${roots.join("\u3001")}\uFF09`
    };
  }
  return { blocked: false };
};
var readScopeFile = (scopePath) => {
  try {
    const payload = JSON.parse(fs.readFileSync(scopePath, "utf8"));
    return payload && typeof payload === "object" ? payload : void 0;
  } catch {
    return void 0;
  }
};
async function prototypeDetectScopeGuardPlugin() {
  return {
    "tool.execute.before": async (input, output) => {
      const toolId = String(input.tool ?? "").toLowerCase();
      if (!WRITE_TOOLS.has(toolId)) return;
      const filePath = extractFilePath(output.args);
      if (!filePath) return;
      const scopePath = readOverlayValue(String(input.sessionID ?? ""), "WAVE_DETECT_SCOPE_FILE");
      if (!scopePath) return;
      const verdict = evaluateDetectScopeWrite({
        scope: readScopeFile(scopePath),
        filePath,
        cwd: process.cwd()
      });
      if (verdict.blocked) throw new Error(verdict.reason ?? "\u68C0\u6D4B\u5199\u9762\u8D8A\u754C");
    }
  };
}
var plugin_prototype_detect_scope_guard_default = {
  id: "plugin-prototype-detect-scope-guard",
  server: prototypeDetectScopeGuardPlugin
};
export {
  plugin_prototype_detect_scope_guard_default as default,
  evaluateDetectScopeWrite
};
