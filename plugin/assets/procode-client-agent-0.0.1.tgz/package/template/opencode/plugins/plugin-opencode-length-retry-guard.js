/* Bundled OpenCode plugin: plugin-opencode-length-retry-guard — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-opencode-length-retry-guard.ts
var RETRY_HINT = "[IMPORTANT] Previous round truncated by token limit with no tool call emitted. Reasoning budget was exhausted before tool call could be emitted. Please retry with shorter reasoning and call write / edit / prepareWrite directly.";
var RETRY_HINT_PREFIX = RETRY_HINT.slice(0, 30);
var MAX_RETRIES = 2;
async function opencodeLengthRetryGuardPlugin() {
  return {
    "experimental.chat.messages.transform": async (_input, output) => {
      try {
        const out = output;
        const msgs = out.messages;
        if (!msgs?.length) return;
        const last = msgs[msgs.length - 1];
        if (last.info.role !== "assistant") return;
        if (last.info.finish !== "length") return;
        const hasToolParts = last.parts.some((p) => p.type === "tool");
        if (hasToolParts) return;
        const retryCount = msgs.filter(
          (m) => Array.isArray(m.parts) && m.parts.some(
            (p) => p.type === "text" && typeof p.text === "string" && p.text.includes(RETRY_HINT_PREFIX)
          )
        ).length;
        if (retryCount >= MAX_RETRIES) return;
        msgs.pop();
        msgs.push({
          info: { role: "user" },
          parts: [{ type: "text", text: RETRY_HINT }]
        });
      } catch {
      }
    }
  };
}
var plugin_opencode_length_retry_guard_default = {
  id: "plugin-opencode-length-retry-guard",
  server: opencodeLengthRetryGuardPlugin
};
export {
  plugin_opencode_length_retry_guard_default as default
};
