/* Bundled OpenCode plugin: plugin-repair-scope-guard — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-repair-scope-guard.ts
import fs from "node:fs";
import path from "node:path";

// src/utils/spec-lifecycle-file-guard.ts
function extractToolFilePath(args) {
  if (!args || typeof args !== "object") {
    return null;
  }
  const a = args;
  const fp = a.filePath ?? a.path ?? a.file_path;
  if (typeof fp === "string" && fp.trim()) {
    return fp.trim();
  }
  return null;
}

// src/opencode/plugin-repair-scope-guard.ts
var WRITE_TOOLS = /* @__PURE__ */ new Set(["write", "edit"]);
var REPAIR_SCOPE_REL = ".temp/repair-scope.json";
var REPAIR_SCOPE_VIOLATION_CODE = "repair-scope-violation";
var isRecord = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value);
var isWithin = (baseAbs, targetAbs) => targetAbs === baseAbs || targetAbs.startsWith(`${baseAbs}${path.sep}`);
var toPosix = (value) => value.split(path.sep).join("/");
var normalizeRepairScopePath = (value) => {
  if (typeof value !== "string") return null;
  let rel = value.trim().replace(/\\/g, "/");
  if (!rel) return null;
  if (rel.startsWith("./")) rel = rel.slice(2);
  if (rel.startsWith("/") || /^[A-Za-z]:/.test(rel) || rel.includes("\0")) return null;
  const segments = [];
  for (const segment of rel.split("/")) {
    if (!segment || segment === ".") continue;
    if (segment === "..") {
      if (segments.length === 0) return null;
      segments.pop();
      continue;
    }
    segments.push(segment);
  }
  return segments.length > 0 ? segments.join("/") : null;
};
var repairScopeGlobToRegExp = (pattern) => {
  const normalized = pattern.trim().replace(/\\/g, "/").replace(/^\.\//, "");
  const escapeRegExp = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const body = normalized.split("**").map((chunk) => chunk.split("*").map(escapeRegExp).join("[^/]+")).join(".*");
  return new RegExp(`^${body}$`);
};
var matchesAnyGlob = (file, globs) => {
  for (const glob of globs) {
    if (!glob.trim()) continue;
    if (repairScopeGlobToRegExp(glob).test(file)) return glob;
  }
  return null;
};
var ownerForFile = (file, ownerOf) => {
  if (!ownerOf) return "";
  const exact = ownerOf[file];
  if (typeof exact === "string" && exact.trim()) return exact.trim();
  for (const [pattern, owner] of Object.entries(ownerOf)) {
    if (typeof owner !== "string" || !owner.trim()) continue;
    if (!pattern.includes("*")) continue;
    if (repairScopeGlobToRegExp(pattern).test(file)) return owner.trim();
  }
  return "";
};
var deny = (code, file, owner, detail, round) => {
  const roundText = typeof round === "number" ? `\u7B2C ${round} \u8F6E` : "\u672C\u8F6E";
  const ownerText = owner ? `\u5E94\u4EA4\u7ED9 owner \`${owner}\` \u5904\u7406\uFF08\u672C\u8F6E\u4FEE\u590D agent \u4E0D\u5F97\u8DE8 owner \u5199\uFF09\u3002` : "\u4F5C\u4E3A\u65B0 issue \u4EA4\u5BF9\u5E94 owner \u5904\u7406\uFF08\u4E0D\u5F97\u81EA\u884C\u8DE8 owner \u5199\uFF09\u3002";
  return {
    allow: false,
    code,
    reason: `[${REPAIR_SCOPE_VIOLATION_CODE}] \u8D8A\u754C\u6587\u4EF6 \`${file}\`\uFF1A${detail}\uFF08${roundText}\u4FEE\u590D\u7684\u5141\u8BB8\u5199\u5165\u9762\uFF09\u3002${ownerText}\u7981\u6B62\u91CD\u8BD5\u540C\u4E00\u8DEF\u5F84\uFF1A\u91CD\u590D\u5199\u5165\u53EA\u4F1A\u518D\u6B21\u88AB\u62E6\u622A\uFF0C\u5E76\u4F1A\u5728\u4E8B\u540E diff \u89C2\u6D4B\u4E2D\u88AB\u8BB0\u4E3A violations\u3001\u51BB\u7ED3\u672C\u8F6E\uFF08\u672C\u8F6E\u7ED3\u8BBA\u4E0D\u4F5C\u6570\uFF0C\u8D8A\u754C\u5185\u5BB9\u4E5F\u4E0D\u4F1A\u81EA\u52A8\u56DE\u6EDA\uFF09\u3002`
  };
};
var evaluateRepairScopeGuard = (input) => {
  const { scope } = input;
  const workRoot = path.resolve(input.workdir);
  const targetAbs = path.resolve(workRoot, input.filePath);
  if (!isWithin(workRoot, targetAbs)) {
    return deny(
      "escape",
      toPosix(path.relative(workRoot, targetAbs) || targetAbs),
      "",
      "\u76EE\u6807\u8DEF\u5F84\u89E3\u6790\u540E\u843D\u5728\u5DE5\u4F5C\u533A\u4E4B\u5916\uFF08\u7EDD\u5BF9\u8DEF\u5F84\u6216 `..` \u9003\u9038\uFF09",
      scope.round
    );
  }
  const plansRootRaw = typeof scope.plansRoot === "string" ? scope.plansRoot.trim() : "";
  const plansRootAbs = plansRootRaw ? path.resolve(workRoot, plansRootRaw) : workRoot;
  if (!isWithin(workRoot, plansRootAbs)) return { allow: true };
  const ownerOf = isRecord(scope.ownerOf) ? scope.ownerOf : void 0;
  if (!isWithin(plansRootAbs, targetAbs)) {
    const relToWork = toPosix(path.relative(workRoot, targetAbs));
    return deny(
      "out-of-scope",
      relToWork,
      ownerForFile(relToWork, ownerOf),
      `\u4E0D\u5728\u672C\u8F6E\u8BBE\u8BA1\u4EA7\u7269\u6839\uFF08plans/\uFF09\u5185\uFF1AplansRoot=${toPosix(path.relative(workRoot, plansRootAbs)) || plansRootAbs}\uFF08\u7EDD\u5BF9\uFF1A${plansRootAbs}\uFF09\uFF0Ctarget=${targetAbs}\u3002\u4FEE\u590D\u8F6E\u6B21\u53EA\u80FD\u6539\u8BBE\u8BA1\u4EA7\u7269\uFF0C\u4E0D\u80FD\u6539\u6E90\u7801/\u914D\u7F6E/specs\uFF1B\u82E5 plansRoot \u4E0D\u7B49\u4E8E <spec\u76EE\u5F55>/plans\uFF0C\u5C5E\u672C\u8F6E scope \u751F\u6210\u7684\u6839\u8DEF\u5F84\u9519\u8BEF\u2014\u2014\u4E0D\u662F\u4F60\u7684\u8DEF\u5F84\u5199\u9519`,
      scope.round
    );
  }
  const rel = toPosix(path.relative(plansRootAbs, targetAbs));
  const normalized = normalizeRepairScopePath(rel);
  if (!normalized) {
    return deny("out-of-scope", rel, ownerForFile(rel, ownerOf), "\u8DEF\u5F84\u65E0\u6CD5\u5F52\u4E00\u4E3A plans/ \u76F8\u5BF9\u8DEF\u5F84", scope.round);
  }
  const protectedHit = matchesAnyGlob(normalized, scope.protectedGlobs ?? []);
  if (protectedHit) {
    return deny(
      "protected",
      normalized,
      ownerForFile(normalized, ownerOf),
      `\u5C5E\u4E8E\u53D7\u4FDD\u62A4\u9762\uFF08\u5339\u914D protectedGlobs \`${protectedHit}\`\uFF09\uFF0C\u4EFB\u4F55 agent \u90FD\u4E0D\u5F97\u5199\u5165`,
      scope.round
    );
  }
  const allowedFiles = (scope.allowedFiles ?? []).map((entry) => normalizeRepairScopePath(entry)).filter((entry) => Boolean(entry));
  const allowedGlobHit = matchesAnyGlob(normalized, scope.allowedGlobs ?? []);
  if (allowedFiles.includes(normalized) || allowedGlobHit) return { allow: true };
  return deny(
    "out-of-scope",
    normalized,
    ownerForFile(normalized, ownerOf),
    "\u4E0D\u5728\u672C\u8F6E\u4FEE\u590D\u6E05\u5355\u7684\u5141\u8BB8\u5199\u5165\u9762\u5185\uFF08allowedFiles / allowedGlobs \u5747\u672A\u8986\u76D6\uFF09",
    scope.round
  );
};
var readRepairScopeDocument = (workdir) => {
  const abs = path.join(workdir, ...REPAIR_SCOPE_REL.split("/"));
  let raw;
  try {
    raw = JSON.parse(fs.readFileSync(abs, "utf-8"));
  } catch {
    return null;
  }
  if (!isRecord(raw)) return null;
  const expiresAt = typeof raw.expiresAt === "string" ? Date.parse(raw.expiresAt) : NaN;
  if (Number.isFinite(expiresAt) && expiresAt <= Date.now()) return null;
  const toStringList = (value) => Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
  return {
    scopeId: typeof raw.scopeId === "string" ? raw.scopeId : void 0,
    round: typeof raw.round === "number" ? raw.round : void 0,
    allowedFiles: toStringList(raw.allowedFiles),
    allowedGlobs: toStringList(raw.allowedGlobs),
    protectedGlobs: toStringList(raw.protectedGlobs),
    ownerOf: isRecord(raw.ownerOf) ? Object.fromEntries(
      Object.entries(raw.ownerOf).filter(
        (entry) => typeof entry[1] === "string"
      )
    ) : void 0,
    plansRoot: typeof raw.plansRoot === "string" ? raw.plansRoot : void 0,
    expiresAt: typeof raw.expiresAt === "string" ? raw.expiresAt : void 0,
    updatedAt: typeof raw.updatedAt === "string" ? raw.updatedAt : void 0
  };
};
async function repairScopeGuardPlugin() {
  return {
    "tool.execute.before": async (input, output) => {
      const toolId = String(input.tool ?? "").toLowerCase();
      if (!WRITE_TOOLS.has(toolId)) return;
      const filePath = extractToolFilePath(output?.args);
      if (!filePath) return;
      const workdir = process.cwd();
      const scope = readRepairScopeDocument(workdir);
      if (!scope) return;
      const decision = evaluateRepairScopeGuard({ workdir, filePath, scope });
      if (decision.allow === false) {
        throw new Error(decision.reason);
      }
    }
  };
}
var plugin_repair_scope_guard_default = {
  id: "plugin-repair-scope-guard",
  server: repairScopeGuardPlugin
};
export {
  REPAIR_SCOPE_REL,
  REPAIR_SCOPE_VIOLATION_CODE,
  plugin_repair_scope_guard_default as default,
  evaluateRepairScopeGuard,
  normalizeRepairScopePath,
  readRepairScopeDocument,
  repairScopeGlobToRegExp
};
