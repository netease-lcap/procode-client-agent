/* Bundled OpenCode plugin: plugin-reliable-bash-output — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-reliable-bash-output.ts
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
var BASH_TOOL_ID = "bash";
var EMPTY_OUTPUT = "(no output)";
var EVIDENCE_DIR_REL = path.join(".log", "opencode");
var MAX_RECOVERY_BYTES = 50 * 1024;
var WRAPPED_EXIT_CODE_ASSIGNMENT = "__wave_bash_exit_code=$?";
var EVIDENCE_BASENAME_PATTERN = /bash-[A-Za-z0-9._-]+\.log/;
var EVIDENCE_TEE_PREFIX = "> >(tee ";
var EVIDENCE_TEE_SUFFIX = ") 2>&1";
var CURRENT_WRAPPER_PREFIX = "set +e\n(\n";
var CURRENT_WRAPPER_SUFFIX = `
${WRAPPED_EXIT_CODE_ASSIGNMENT}
wait
exit "$__wave_bash_exit_code"`;
var CURRENT_WRAPPER_REDIRECT_PREFIX = `
) ${EVIDENCE_TEE_PREFIX}`;
var STALE_EVIDENCE_AGE_MS = 24 * 60 * 60 * 1e3;
var RASH_COMMAND = "procode-rash";
var DEFAULT_RASH_INSTALL_PATH = "/usr/local/bin/procode-rash";
function procodeRashTargetName(platform = process.platform, arch = process.arch) {
  const target = platform === "linux" && arch === "x64" ? "x86_64-unknown-linux-musl" : platform === "linux" && arch === "arm64" ? "aarch64-unknown-linux-musl" : platform === "darwin" && arch === "x64" ? "x86_64-apple-darwin" : platform === "darwin" && arch === "arm64" ? "aarch64-apple-darwin" : null;
  return target ? `procode-rash-${target}` : null;
}
function safeID(value) {
  const normalized = value.trim();
  if (!normalized || normalized.length > 120 || !/^[A-Za-z0-9._-]+$/.test(normalized)) {
    return null;
  }
  return normalized;
}
function shellSingleQuote(value) {
  return `'${value.replace(/'/g, `'"'"'`)}'`;
}
function rashExecutableEnd(command) {
  const match = /^\s*(?:(?:command|exec)\s+)?(?:\/[^\s]+\/)?procode-rash(?=\s|$)/.exec(command);
  return match ? match[0].length : null;
}
function parseShellSingleQuotedArgument(command, start) {
  let cursor = start;
  while (cursor < command.length && /\s/.test(command[cursor])) cursor += 1;
  if (command[cursor] !== "'") return null;
  cursor += 1;
  let value = "";
  while (cursor <= command.length) {
    const close = command.indexOf("'", cursor);
    if (close < 0) return null;
    value += command.slice(cursor, close);
    if (command.slice(close, close + 5) === `'"'"'`) {
      value += "'";
      cursor = close + 5;
      continue;
    }
    return { value, end: close + 1 };
  }
  return null;
}
function parseRashCommand(command) {
  if (typeof command !== "string") return null;
  const executableEnd = rashExecutableEnd(command);
  if (executableEnd === null) return null;
  const commandArgument = parseShellSingleQuotedArgument(command, executableEnd);
  if (!commandArgument) return null;
  const outputLogArgument = parseShellSingleQuotedArgument(command, commandArgument.end);
  if (!outputLogArgument || !/^(?:\d+)?$/.test(command.slice(outputLogArgument.end).trim())) return null;
  return { command: commandArgument.value, outputLog: outputLogArgument.value };
}
function isRashCommand(command) {
  return typeof command === "string" && rashExecutableEnd(command) !== null;
}
function unwrapRashCommandForModel(command) {
  return parseRashCommand(command)?.command ?? null;
}
function findExecutableOnPath(command, pathValue) {
  const commandNames = process.platform === "win32" ? [command, `${command}.cmd`, `${command}.exe`, `${command}.bat`] : [command];
  for (const directory of pathValue.split(path.delimiter)) {
    if (!directory) continue;
    for (const commandName of commandNames) {
      const candidate = path.join(directory, commandName);
      try {
        fs.accessSync(candidate, fs.constants.X_OK);
        return candidate;
      } catch {
      }
    }
  }
  return null;
}
function ensureProcodeRashInstalled(options = {}) {
  const pathValue = options.pathValue ?? process.env.PATH ?? "";
  const installedPath = findExecutableOnPath(RASH_COMMAND, pathValue);
  const targetName = procodeRashTargetName();
  const bundledSource = targetName ? path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", targetName) : null;
  const distSource = targetName && process.env.SBX_DIST_DIR ? path.resolve(process.env.SBX_DIST_DIR, targetName) : null;
  const sourcePaths = options.sourcePaths ?? [bundledSource, distSource].filter((value) => Boolean(value));
  const sourcePath = sourcePaths.find((candidate) => {
    try {
      return fs.statSync(candidate).isFile() && fs.statSync(candidate).size > 0;
    } catch {
      return false;
    }
  });
  if (!sourcePath) {
    if (installedPath) return;
    throw new Error(`\u672A\u627E\u5230 ${RASH_COMMAND} \u5B89\u88C5\u6E90: ${sourcePaths.join(", ")}`);
  }
  const targetPath = options.targetPath ?? installedPath ?? DEFAULT_RASH_INSTALL_PATH;
  if (installedPath && fs.readFileSync(sourcePath).equals(fs.readFileSync(installedPath))) return;
  const temporaryPath = `${targetPath}.${process.pid}.${Date.now()}.tmp`;
  fs.mkdirSync(path.dirname(targetPath), { recursive: true });
  try {
    fs.copyFileSync(sourcePath, temporaryPath);
    fs.chmodSync(temporaryPath, 493);
    fs.renameSync(temporaryPath, targetPath);
    fs.accessSync(targetPath, fs.constants.X_OK);
  } finally {
    try {
      fs.unlinkSync(temporaryPath);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
}
function resolveWorkspaceRoot(input) {
  const value = input?.directory?.trim() || input?.worktree?.trim();
  return value ? path.resolve(value) : process.cwd();
}
function resolveEvidencePath(workspaceRoot, sessionID, callID) {
  const safeSessionID = safeID(sessionID);
  const safeCallID = safeID(callID);
  if (!safeSessionID || !safeCallID) return null;
  return path.join(workspaceRoot, EVIDENCE_DIR_REL, `bash-${safeSessionID}-${safeCallID}.log`);
}
function findWrappedEvidenceBasename(command, evidenceDirectory) {
  if (typeof command !== "string") return null;
  const usesRash = command.includes(RASH_COMMAND) || command.includes("rash.mjs");
  let basename = null;
  for (const match of command.matchAll(new RegExp(EVIDENCE_BASENAME_PATTERN.source, "g"))) {
    const matchIndex = match.index;
    if (matchIndex === void 0) continue;
    const expectedPath = path.join(evidenceDirectory, match[0]);
    if (usesRash && command.includes(expectedPath)) {
      basename = match[0];
      continue;
    }
    const lineStart = command.lastIndexOf("\n", matchIndex) + 1;
    const lineEndCandidate = command.indexOf("\n", matchIndex + match[0].length);
    const lineEnd = lineEndCandidate < 0 ? command.length : lineEndCandidate;
    const line = command.slice(lineStart, lineEnd);
    if (line.includes(expectedPath) && line.startsWith("tee ") && line.endsWith(' < "$__wave_bash_pipe" &') && !line.includes("\r")) {
      basename = match[0];
      continue;
    }
    const prefixIndex = command.lastIndexOf(EVIDENCE_TEE_PREFIX, matchIndex);
    const suffixIndex = command.indexOf(EVIDENCE_TEE_SUFFIX, matchIndex + match[0].length);
    if (prefixIndex < 0 || suffixIndex < 0) continue;
    const wrapperFragment = command.slice(prefixIndex, suffixIndex + EVIDENCE_TEE_SUFFIX.length);
    if (!wrapperFragment.includes(expectedPath) || wrapperFragment.includes("\n") || wrapperFragment.includes("\r")) {
      continue;
    }
    basename = match[0];
  }
  return basename;
}
function parseCompatibleTeeTarget(teeArguments) {
  const match = /^(?:-a\s+)?'([^'\r\n]+)'$/.exec(teeArguments);
  return match?.[1] ?? null;
}
function removeRedundantLegacyEvidenceWrappers(command, evidenceDirectory) {
  let normalized = command;
  const removedEvidenceBasenames = [];
  while (normalized.startsWith(CURRENT_WRAPPER_PREFIX) && normalized.endsWith(CURRENT_WRAPPER_SUFFIX)) {
    const suffixIndex = normalized.length - CURRENT_WRAPPER_SUFFIX.length;
    const redirectIndex = normalized.lastIndexOf(CURRENT_WRAPPER_REDIRECT_PREFIX, suffixIndex);
    if (redirectIndex < CURRENT_WRAPPER_PREFIX.length) break;
    const teeArgumentsStart = redirectIndex + CURRENT_WRAPPER_REDIRECT_PREFIX.length;
    const redirectSuffixIndex = normalized.indexOf(EVIDENCE_TEE_SUFFIX, teeArgumentsStart);
    if (redirectSuffixIndex + EVIDENCE_TEE_SUFFIX.length !== suffixIndex) break;
    const teeArguments = normalized.slice(teeArgumentsStart, redirectSuffixIndex).trim();
    if (!teeArguments || teeArguments.includes("\n") || teeArguments.includes("\r")) break;
    const teeTarget = parseCompatibleTeeTarget(teeArguments);
    if (!teeTarget) break;
    const targetBasename = path.basename(teeTarget);
    const outerEvidenceBasename = path.resolve(path.dirname(teeTarget)) === path.resolve(evidenceDirectory) && EVIDENCE_BASENAME_PATTERN.test(targetBasename) ? targetBasename : null;
    if (!outerEvidenceBasename) break;
    const innerCommand = normalized.slice(CURRENT_WRAPPER_PREFIX.length, redirectIndex);
    removedEvidenceBasenames.push(outerEvidenceBasename);
    normalized = innerCommand;
  }
  return { command: normalized, removedEvidenceBasenames };
}
function buildRashCommand(command, evidencePath, timeout) {
  if (isRashCommand(command) || findWrappedEvidenceBasename(command, path.dirname(evidencePath))) return command;
  const quotedEvidencePath = shellSingleQuote(evidencePath);
  const duration = typeof timeout === "number" && Number.isFinite(timeout) && timeout > 0 ? timeout : 12e4;
  return `${RASH_COMMAND} ${shellSingleQuote(command)} ${quotedEvidencePath} ${Math.max(1, Math.floor(duration - 1500))}`;
}
function resolveEvidencePathFromWrappedCommand(evidenceDirectory, command) {
  const basename = findWrappedEvidenceBasename(command, evidenceDirectory);
  return basename ? path.join(evidenceDirectory, basename) : null;
}
function emptyOutputMetadataSuffix(output) {
  if (typeof output !== "string") return "";
  const normalized = output.trim();
  if (!normalized || normalized === EMPTY_OUTPUT) return "";
  const metadataPrefix = `${EMPTY_OUTPUT}

<shell_metadata>`;
  if (normalized.startsWith(metadataPrefix)) {
    return normalized.slice(EMPTY_OUTPUT.length);
  }
  return null;
}
function readRecoveryOutput(filePath) {
  let stat;
  try {
    stat = fs.statSync(filePath);
  } catch {
    return null;
  }
  if (!stat.isFile() || stat.size === 0) return null;
  if (stat.size > MAX_RECOVERY_BYTES) {
    const fd = fs.openSync(filePath, "r");
    try {
      const buffer = Buffer.allocUnsafe(MAX_RECOVERY_BYTES);
      const bytesRead = fs.readSync(fd, buffer, 0, buffer.length, stat.size - MAX_RECOVERY_BYTES);
      return `...bash recovery truncated...

${buffer.subarray(0, bytesRead).toString("utf8")}`;
    } finally {
      fs.closeSync(fd);
    }
  }
  return fs.readFileSync(filePath, "utf8");
}
function removeEvidenceFile(filePath) {
  try {
    fs.unlinkSync(filePath);
    return true;
  } catch (error) {
    return error.code === "ENOENT";
  }
}
function cleanupStaleEvidenceFiles(evidenceDirectory, now = Date.now()) {
  let entries;
  try {
    entries = fs.readdirSync(evidenceDirectory, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    const isEvidenceLog = entry.name.startsWith("bash-") && (entry.name.endsWith(".log") || entry.name.endsWith(".log.status.json"));
    const isEvidencePipe = entry.name.startsWith("bash-") && /\.log\.pipe\.[0-9]+$/.test(entry.name);
    if (!entry.isFile() && !entry.isFIFO() || !isEvidenceLog && !isEvidencePipe) {
      continue;
    }
    const filePath = path.join(evidenceDirectory, entry.name);
    try {
      const stat = fs.statSync(filePath);
      if (now - stat.mtimeMs >= STALE_EVIDENCE_AGE_MS) {
        removeEvidenceFile(filePath);
      }
    } catch {
    }
  }
}
async function reliableBashOutputPlugin(input) {
  try {
    ensureProcodeRashInstalled();
  } catch {
  }
  const workspaceRoot = resolveWorkspaceRoot(input);
  const evidenceDirectory = path.join(workspaceRoot, EVIDENCE_DIR_REL);
  const activeEvidencePaths = /* @__PURE__ */ new Set();
  const retainedEvidencePaths = /* @__PURE__ */ new Set();
  cleanupStaleEvidenceFiles(evidenceDirectory);
  const cleanupTrackedEvidence = (filePath) => {
    if (retainedEvidencePaths.has(filePath)) return;
    if (removeEvidenceFile(filePath)) {
      removeEvidenceFile(`${filePath}.status.json`);
      activeEvidencePaths.delete(filePath);
    }
  };
  const resolveHookEvidencePath = (hookInput) => resolveEvidencePath(workspaceRoot, String(hookInput.sessionID ?? ""), String(hookInput.callID ?? ""));
  return {
    "tool.execute.before": async (hookInput, hookOutput) => {
      if (String(hookInput.tool ?? "").toLowerCase() !== BASH_TOOL_ID) return;
      if (!findExecutableOnPath(RASH_COMMAND, process.env.PATH ?? "")) return;
      const command = hookOutput.args?.command;
      if (typeof command !== "string" || !command.trim()) return;
      const normalized = removeRedundantLegacyEvidenceWrappers(command, evidenceDirectory);
      for (const basename of normalized.removedEvidenceBasenames) {
        cleanupTrackedEvidence(path.join(evidenceDirectory, basename));
      }
      if (isRashCommand(normalized.command)) {
        hookOutput.args.command = normalized.command;
        return;
      }
      const existingEvidencePath = resolveEvidencePathFromWrappedCommand(evidenceDirectory, normalized.command);
      const evidencePath = existingEvidencePath ?? resolveHookEvidencePath(hookInput);
      if (!evidencePath) return;
      fs.mkdirSync(path.dirname(evidencePath), { recursive: true });
      cleanupTrackedEvidence(evidencePath);
      activeEvidencePaths.add(evidencePath);
      hookOutput.args.command = existingEvidencePath ? normalized.command : buildRashCommand(normalized.command, evidencePath, hookOutput.args?.timeout);
    },
    "experimental.chat.messages.transform": async (_input, output) => {
      for (const message of output.messages ?? []) {
        for (const part of message.parts ?? []) {
          if (part.type !== "tool" || String(part.tool ?? "").toLowerCase() !== BASH_TOOL_ID) continue;
          const toolInput = part.state?.input;
          const originalCommand = unwrapRashCommandForModel(toolInput?.command);
          if (!toolInput || originalCommand === null) continue;
          part.state = { ...part.state, input: { ...toolInput, command: originalCommand } };
        }
      }
    },
    "tool.execute.after": async (hookInput, hookOutput) => {
      if (String(hookInput.tool ?? "").toLowerCase() !== BASH_TOOL_ID) return;
      const evidencePath = resolveEvidencePathFromWrappedCommand(evidenceDirectory, hookInput.args?.command) ?? resolveHookEvidencePath(hookInput);
      if (!evidencePath) return;
      try {
        let status = {};
        try {
          status = JSON.parse(fs.readFileSync(`${evidencePath}.status.json`, "utf8"));
        } catch {
        }
        const terminated = status.timedOut || /shell tool terminated|\[procode-rash\] (?:timeout|interrupted)/.test(hookOutput.output ?? "");
        if (terminated || typeof status.exitCode === "number" && status.exitCode !== 0) {
          retainedEvidencePaths.add(evidencePath);
          const recovered2 = readRecoveryOutput(evidencePath);
          if (recovered2 && !hookOutput.output?.includes(recovered2)) {
            hookOutput.output = `${hookOutput.output ?? ""}
${recovered2}`;
          }
          hookOutput.output = `${hookOutput.output ?? ""}
[procode-rash] exitCode=${status.exitCode ?? "unknown"}; timedOut=${Boolean(status.timedOut || /exceeding timeout/.test(hookOutput.output ?? ""))}; log=${evidencePath}`;
          return;
        }
        const metadataSuffix = emptyOutputMetadataSuffix(hookOutput.output);
        if (metadataSuffix === null) return;
        const recovered = readRecoveryOutput(evidencePath);
        if (recovered) hookOutput.output = `${recovered}${metadataSuffix}`;
      } finally {
        cleanupTrackedEvidence(evidencePath);
      }
    },
    event: async (input2) => {
      if (input2.event?.type !== "message.part.updated") return;
      const part = input2.event.properties?.part;
      if (!part || typeof part !== "object") return;
      const toolPart = part;
      if (String(toolPart.tool ?? "").toLowerCase() !== BASH_TOOL_ID) return;
      const state = toolPart.state;
      if (!state || typeof state !== "object") return;
      const status = String(state.status ?? "");
      if (status !== "completed" && status !== "error") return;
      const stateInput = state.input;
      const evidencePath = resolveEvidencePathFromWrappedCommand(
        evidenceDirectory,
        stateInput && typeof stateInput === "object" ? stateInput.command : void 0
      ) ?? resolveEvidencePath(workspaceRoot, String(toolPart.sessionID ?? ""), String(toolPart.callID ?? ""));
      if (evidencePath) {
        let failed = status === "error";
        try {
          const result = JSON.parse(fs.readFileSync(`${evidencePath}.status.json`, "utf8"));
          failed ||= result.exitCode !== 0 || result.timedOut;
        } catch {
        }
        if (failed) retainedEvidencePaths.add(evidencePath);
        else cleanupTrackedEvidence(evidencePath);
      }
    },
    dispose: async () => {
      for (const filePath of [...activeEvidencePaths]) {
        cleanupTrackedEvidence(filePath);
      }
    }
  };
}
var plugin_reliable_bash_output_default = {
  id: "plugin-reliable-bash-output",
  server: reliableBashOutputPlugin
};
export {
  plugin_reliable_bash_output_default as default,
  ensureProcodeRashInstalled
};
