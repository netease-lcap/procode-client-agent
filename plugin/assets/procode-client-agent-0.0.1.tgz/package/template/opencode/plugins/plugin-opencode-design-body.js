/* Bundled OpenCode plugin: plugin-opencode-design-body — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-opencode-design-body.ts
async function opencodeGatewayHeadersPlugin() {
  return {
    "chat.params": async (input, output) => {
      const providerId = String(input?.provider?.id ?? "");
      const providerName = String(input?.provider?.name ?? "");
      if (process.env.OPENCODE_DISABLED_THINKING === "true" || providerId.includes("design") || providerId.includes("wave-ai-conversation") || providerName.includes("proCode_prototype_visual")) {
        output.options = output.options || {};
        output.options.enable_thinking = false;
        output.options.reasoningEffort = "none";
        output.options.thinking = { "type": "disabled" };
        return;
      }
      const reasoningEffort = process.env.OPENCODE_REASONING_EFFORT;
      if (reasoningEffort) {
        output.options = output.options || {};
        output.options.reasoningEffort = reasoningEffort;
      }
    }
  };
}
var plugin_opencode_design_body_default = {
  id: "plugin-opencode-design-body",
  server: opencodeGatewayHeadersPlugin
};
export {
  plugin_opencode_design_body_default as default
};
