/* Bundled OpenCode plugin: plugin-opencode-repetitive-tool-guard — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-opencode-repetitive-tool-guard.ts
async function opencodeRepetitiveToolGuardPlugin() {
  const REPETITION_THRESHOLD = 3;
  const WARNING_TEXT = "[IMPORTANT] OpenCode blocked a repeated tool-call loop. Do not call the same tool again with identical arguments. Continue the task using the existing result or a different valid action.";
  const emptyToolCallCorrection = (tool) => `[IMPORTANT] The previous ${tool} call was rejected because its argument payload was empty or incomplete. Retry it at most once with a complete JSON object matching the tool schema. If it still cannot be formed, skip this tool and continue the substantive task with another valid action.`;
  return {
    "permission.ask": async (input, output) => {
      if (input.type === "doom_loop") {
        output.status = "deny";
      }
    },
    "experimental.chat.messages.transform": async (_input, output) => {
      try {
        const out = output;
        const msgs = out.messages;
        if (!msgs?.length) return;
        const recentToolCalls = [];
        for (let i = msgs.length - 1; i >= 0 && recentToolCalls.length < REPETITION_THRESHOLD * 2; i--) {
          const m = msgs[i];
          if (m.info.role !== "assistant") continue;
          for (let j = m.parts.length - 1; j >= 0; j--) {
            const p = m.parts[j];
            if (p.type !== "tool") continue;
            const tool = p.tool;
            const input = p.state?.input;
            if (!tool || !input) continue;
            recentToolCalls.push({
              tool,
              argsKey: JSON.stringify(input, Object.keys(input).sort()),
              state: p.state
            });
          }
        }
        const latest = recentToolCalls[0];
        const latestInput = latest?.state?.input;
        const latestIsInterruptedEmptyCall = Boolean(
          latest && latest.state?.status === "error" && latest.state?.metadata?.interrupted === true && latest.state?.raw === "" && latestInput && Object.keys(latestInput).length === 0
        );
        if (latestIsInterruptedEmptyCall) {
          msgs.push({
            info: { role: "user" },
            parts: [{ type: "text", text: emptyToolCallCorrection(latest.tool) }]
          });
          return;
        }
        if (recentToolCalls.length < REPETITION_THRESHOLD) return;
        const last = recentToolCalls.slice(0, REPETITION_THRESHOLD);
        const allSame = last.every(
          (c) => c.tool === last[0].tool && c.argsKey === last[0].argsKey
        );
        if (!allSame) return;
        msgs.push({
          info: { role: "user" },
          parts: [{ type: "text", text: WARNING_TEXT }]
        });
      } catch {
      }
    }
  };
}
var plugin_opencode_repetitive_tool_guard_default = {
  id: "plugin-opencode-repetitive-tool-guard",
  server: opencodeRepetitiveToolGuardPlugin
};
export {
  plugin_opencode_repetitive_tool_guard_default as default
};
