/* Bundled OpenCode plugin: plugin-wave-post-check — do not edit; rebuild: @lcap/procode-agent pnpm build (esbuild node20). */


// src/opencode/plugin-wave-post-check.ts
import { spawn } from "node:child_process";
import { once } from "node:events";
import { existsSync } from "node:fs";
import { mkdir, appendFile } from "node:fs/promises";
import { homedir } from "node:os";
import path from "node:path";
import { text } from "node:stream/consumers";
var LOG_PREFIX = "[plugin-wave-post-check]";
var PLUGIN_LOG_FILE = path.join(homedir(), "logs", "plugin-wave-post-check.log");
var logDirReady = null;
function ensurePluginLogDir() {
  if (!logDirReady) {
    logDirReady = mkdir(path.dirname(PLUGIN_LOG_FILE), { recursive: true }).then(() => void 0);
  }
  return logDirReady;
}
async function writePluginLog(message) {
  const line = `${(/* @__PURE__ */ new Date()).toISOString()} ${message}
`;
  try {
    await ensurePluginLogDir();
    await appendFile(PLUGIN_LOG_FILE, line, "utf8");
  } catch {
  }
}
var POST_CHECK_MATCH_TOOLS = /* @__PURE__ */ new Set(["write", "edit", "apply_patch"]);
var WAVE_POST_CHECK_SCRIPT = path.join(".wave", "scripts", "post-check-file.mjs");
var warnedScriptMissing = false;
var MAX_CAPTURE_CHARS = 32 * 1024 * 1024;
function clipCapture(s) {
  if (s.length <= MAX_CAPTURE_CHARS) return s;
  return `${s.slice(0, MAX_CAPTURE_CHARS)}
\u2026(truncated)`;
}
var MAX_LOG_FILE_OUTPUT_CHARS = 24e3;
function stripAnsi(s) {
  return s.replace(/\x1B\[[\d;]*m/g, "");
}
function clipForPluginLogFile(s) {
  if (s.length <= MAX_LOG_FILE_OUTPUT_CHARS) return s;
  return `${s.slice(0, MAX_LOG_FILE_OUTPUT_CHARS)}
\u2026(plugin log truncated)`;
}
function resolveWorkspaceFilePath(filePath) {
  const cwd = process.cwd();
  if (!filePath) return "";
  return path.isAbsolute(filePath) ? filePath : path.resolve(cwd, filePath);
}
function collectPathsAfterTool(toolId, args, metadata) {
  const out = [];
  const a = args && typeof args === "object" ? args : {};
  if (toolId === "write" || toolId === "edit") {
    const fp = a.filePath;
    if (typeof fp === "string" && fp.trim()) out.push(resolveWorkspaceFilePath(fp.trim()));
    return out;
  }
  if (toolId === "apply_patch") {
    const meta = metadata && typeof metadata === "object" ? metadata : {};
    const files = meta.files;
    if (Array.isArray(files)) {
      for (const entry of files) {
        if (entry && typeof entry === "object" && "filePath" in entry) {
          const fp = entry.filePath;
          if (typeof fp === "string" && fp.trim()) out.push(resolveWorkspaceFilePath(fp.trim()));
        }
      }
    }
  }
  return out;
}
async function runWavePostCheckScript(absFile) {
  const cwd = process.cwd();
  const scriptAbs = path.resolve(cwd, WAVE_POST_CHECK_SCRIPT);
  if (!existsSync(scriptAbs)) {
    if (!warnedScriptMissing) {
      warnedScriptMissing = true;
      await writePluginLog(
        `${LOG_PREFIX} post-check script not found (skip): ${WAVE_POST_CHECK_SCRIPT} cwd=${cwd}`
      );
    }
    return "";
  }
  const payload = JSON.stringify({ tool_input: { file_path: absFile } });
  await writePluginLog(
    `${LOG_PREFIX} post-check cmd: node ${scriptAbs} cwd=${cwd} file=${absFile}`
  );
  const child = spawn("node", [scriptAbs], {
    cwd,
    stdio: ["pipe", "pipe", "pipe"]
  });
  child.stdin.end(payload, "utf8");
  try {
    const [stdoutRaw, stderrRaw, closeEv] = await Promise.all([
      text(child.stdout),
      text(child.stderr),
      once(child, "close")
    ]);
    const exitCode = closeEv[0];
    const signal = closeEv[1];
    const err = clipCapture(String(stderrRaw).trim());
    const out = clipCapture(String(stdoutRaw).trim());
    const combined = [err, out].filter(Boolean).join("\n");
    const forLog = clipForPluginLogFile(stripAnsi(combined));
    await writePluginLog(
      `${LOG_PREFIX} post-check done: exit=${exitCode === null ? "null" : exitCode}${signal ? ` signal=${signal}` : ""} file=${absFile}${forLog ? `
${forLog}` : ""}`
    );
    return combined;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg) {
      await writePluginLog(`${LOG_PREFIX} post-check spawn/read failed for ${absFile}: ${msg}`);
    }
    return msg ? `post-check spawn error: ${msg}` : "";
  }
}
async function wavePostCheckPlugin() {
  return {
    "tool.execute.after": async (input, output) => {
      const toolId = String(input.tool ?? "").toLowerCase();
      if (!POST_CHECK_MATCH_TOOLS.has(toolId)) return;
      const paths = collectPathsAfterTool(toolId, input.args, output.metadata);
      const unique = [...new Set(paths.filter(Boolean))];
      if (!unique.length) return;
      const cwd = process.cwd();
      const rel = unique.map((p) => path.relative(cwd, p) || p);
      await writePluginLog(`${LOG_PREFIX} after ${toolId} file(s): ${rel.join(", ")}`);
      const chunks = (await Promise.all(unique.map((abs) => runWavePostCheckScript(abs)))).filter(
        Boolean
      );
      if (!chunks.length) {
        await writePluginLog(
          `${LOG_PREFIX} no check output (script missing or empty), tool=${toolId}`
        );
        return;
      }
      const block = ["", "--- File Check Result ---", ...chunks].join("\n");
      output.output = `${output.output ?? ""}${block}`;
      await writePluginLog(
        `${LOG_PREFIX} appended file check to tool output, tool=${toolId} files=${unique.length} blockChars=${block.length} (stdout/stderr \u5DF2\u8BB0\u5728\u6BCF\u6B21 post-check done)`
      );
    }
  };
}
var plugin_wave_post_check_default = {
  id: "plugin-wave-post-check",
  server: wavePostCheckPlugin
};
export {
  plugin_wave_post_check_default as default
};
