---
name: upload-design-image
description: |
  从 MasterGo / Figma 等设计工具 MCP 导出图片并上传到 LCAP 文件存储（CDN），获取可在 NASL 代码中直接引用的 URL。
  当 NASL 代码需要引用设计稿中的图片资源（图标、背景、插画等）时使用。
  同样适用于 Prototype HTML：设计稿位图/插画/Logo 须上传 CDN 后引用，禁止本地路径或 base64。
  NASL 项目没有 assets 目录，图片必须托管在外部 CDN 上。
  适用场景：「把设计稿里的图片上传」「导出 MasterGo 图片并获取 URL」「上传设计图标到 CDN」
  「在 NASL 中使用设计稿图片」「上传图片获取链接」「在原型 HTML 中使用设计稿图片」。
  Actions: upload, export, download, save, host, import. Elements: image, icon, illustration, background, logo, picture.
  Sources: MasterGo, Figma, design tool, MCP.
license: Apache-2.0
allowed-tools:
  - Bash              # 执行 node upload-image.mjs 上传脚本、用 curl 下载图片
  - Read              # 读取设计文档、查看已下载的图片文件
  - Write             # 保存下载的图片到本地临时路径
  - MCP               # 调用 MasterGo / Figma MCP 工具导出图片
---

# Upload Design Image

在 NASL 项目中，没有 `assets/` 目录存放图片文件。所有图片资源必须托管在外部 CDN 上，通过 URL 引用。
本 skill 指导你：从设计工具（MasterGo / Figma）导出图片 → 上传到 LCAP 文件存储 → 在 NASL 代码中使用 CDN URL。

## When to use this skill

激活本 skill 当：

- 生成 NASL 代码时需要引用设计稿中的图片（图标、背景图、插画、Logo 等）
- 生成 Prototype HTML 时需要引用设计稿中的图片（位图、插画、Logo 等）
- 用户要求「上传设计稿图片」「把 MasterGo/Figma 里的图片导出并获取 URL」
- 需要将设计工具中的图片资源转为 NASL 可引用的 URL

---

## Workflow

### Step 1: 从设计工具导出图片

#### MasterGo（已配置在 `.mcp.json`）

1. 使用 MasterGo MCP 工具查找目标节点（如 `search_nodes`、`get_file_info` 等）
2. 使用 MCP 的图片导出工具（如 `export_images`）将目标节点导出为图片文件
3. MCP 可能返回：
   - **本地文件路径** → 直接进入 Step 2
   - **图片 URL** → 先下载到本地再进入 Step 2

下载 URL 到本地的命令：
```bash
curl -sL -o /tmp/design-image.png "<image-url>"
```

#### Figma（可选，需用户自行配置 MCP）

如果 `.mcp.json` 中配置了 Figma MCP server，流程与 MasterGo 类似：
1. 使用 Figma MCP 工具获取节点信息
2. 导出目标节点为图片
3. 下载到本地

---

### Step 2: 上传图片到 LCAP CDN

使用本 skill 的上传脚本：

```bash
node skills/upload-design-image/scripts/upload-image.mjs --file <local-path>
```

**必填参数：**

| 参数 | 说明 |
|------|------|
| `--file` | 本地图片文件路径 |

**可选参数：**

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--biz-code` | `spec_driven_extension` | 业务编码 |
| `--file-key` | 自动生成 `spec_driven_extension/<uuid>.<ext>` | 自定义存储路径（不含前导 `/`） |
| `--content-type` | 自动检测 | MIME 类型，如 `image/svg+xml` |

**输出（JSON）：**
```json
{
  "url": "https://cdn.example.com/spec_driven_extension/abc123.png",
  "fileKey": "/spec_driven_extension/abc123.png",
  "domain": "https://cdn.example.com"
}
```

**批量上传示例：**
```bash
# 上传多张图片
for f in /tmp/icon-*.png; do
  node skills/upload-design-image/scripts/upload-image.mjs --file "$f"
done
```

**自定义路径示例（便于后续引用）：**
```bash
node skills/upload-design-image/scripts/upload-image.mjs \
  --file /tmp/logo.png \
  --file-key "spec_driven_extension/my-app/logo.png"
```

---

### Step 3: 在 NASL 代码中使用 CDN URL

上传成功后，将返回的 `url` 值直接填入 NASL 代码中对应的图片属性：

```xml
<!-- 图片组件 -->
<u-image src="https://cdn.example.com/spec_driven_image/abc123.png"></u-image>

<!-- 背景图 -->
<u-div style="background-image: url(https://cdn.example.com/spec_driven_image/abc123.png)"></u-div>
```

### Step 3b: 在 Prototype HTML 中使用 CDN URL

原型页面同样引用上传返回的 `url`，写入 `src` 或 `background-image`；禁止使用本地路径或 base64 data URI。

```html
<img src="https://cdn.example.com/spec_driven_image/abc123.png" alt="..." />
<div style="background-image: url(https://cdn.example.com/spec_driven_image/abc123.png)"></div>
```

---

## Required Environment Variables

上传脚本依赖以下环境变量（由 agent 运行时自动注入，无需手动配置）：

| 变量 | 必填 | 说明 |
|------|------|------|
| `LCAP_OPENAPI_BASE_URL` | ✅ | LCAP 平台根 URL（缺省回退 `NASL_SERVER_BASE_URL`） |
| `LCAP_OPENAPI_AK` | ✅ | OpenAPI AppKey |
| `LCAP_OPENAPI_SK` | ✅ | OpenAPI AppSecret |
| `NASL_STORAGE_ACCOUNT_ID` | ✅ | OpenAPI 用户名（getSignInfo 用） |
| `CW_TENANT` | ✅ | 租户名 |
| `CW_USER_SOURCE` | ❌ | 用户认证源，默认 `Normal`；网易内部 `Netease` |
| `UPLOAD_IMAGE_DEBUG` | ❌ | 设为 `1` 打印调试日志 |

---

## Tips

1. **先确认设计稿节点**：在导出图片前，先用 MCP 工具确认目标节点的 ID 和名称，避免导出错误内容
2. **SVG vs Raster**：SVG 文件上传时建议指定 `--content-type image/svg+xml`，确保浏览器直接渲染
3. **复用 CDN URL**：同一张图片只需上传一次，后续直接复用 URL。上传前可先确认是否已有相同图片的 URL
4. **自定义 fileKey**：为图片指定有语义的 `--file-key`（如 `spec_driven_image/my-app/home-banner.png`），便于识别和管理
5. **图片格式**：建议使用 PNG（透明背景）或 WebP（小体积），避免使用 BMP 等大体积格式
6. **下载再上传**：MCP 导出的图片如果是 URL 形式，需要先 `curl` 下载到本地再上传

---

## Common Patterns

| 场景 | 做法 |
|------|------|
| 设计稿图标 → NASL 页面 | MCP 导出图标 → upload-image.mjs → CDN URL 填入 `src` |
| 设计稿背景图 → NASL 页面 | MCP 导出背景 → upload-image.mjs → CDN URL 填入 `background-image` |
| 设计稿多张图 → NASL 页面 | 批量导出 → 循环 upload-image.mjs → 收集所有 URL |
| 已有图片 URL（非 MCP） | curl 下载 → upload-image.mjs 上传 → 获取新 CDN URL |
| 设计稿图片 → Prototype HTML | MCP 导出 → upload-image.mjs → CDN URL 填入 `src` / `background-image` |
