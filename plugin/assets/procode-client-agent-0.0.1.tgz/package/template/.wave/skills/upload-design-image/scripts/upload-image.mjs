/**
 * upload-image.mjs
 * ─────────────────────────────────────────────────────────────
 * 将本地图片/文件上传到 LCAP 平台文件存储，返回 CDN URL。
 *
 * 用法：
 *   node upload-image.mjs --file <local-path> [--biz-code spec_driven_image] [--file-key <path>] [--content-type <mime>]
 *
 * 输出（stdout，JSON）：
 *   { "url": "https://cdn.xxx.com/path/to/file", "fileKey": "/path/to/file", "domain": "https://cdn.xxx.com" }
 *
 * 环境变量（由 agent 运行时注入，独立调试可用 node --env-file=.env）：
 *   LCAP_OPENAPI_BASE_URL   平台根 URL（缺省回退 NASL_SERVER_BASE_URL）
 *   LCAP_OPENAPI_AK         AppKey
 *   LCAP_OPENAPI_SK         AppSecret
 *   NASL_STORAGE_ACCOUNT_ID getSignInfo 用户名
 *   CW_TENANT               租户名
 *   CW_USER_SOURCE          用户认证源（默认 Normal；网易内部 Netease）
 *   UPLOAD_IMAGE_DEBUG      设为 1/true 打印调试日志
 */
import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { spawnSync } from 'node:child_process';

// ── 常量 ────────────────────────────────────────────────────

const SIGN_INFO_TTL_MS = 60 * 60 * 1000;
const SIGN_INFO_PATH = '/openapi/v3/auth/getSignInfo';
const UPLOAD_PATH = '/openapi/v3/platform/filestorage/upload';
const DEFAULT_TIMEOUT_SEC = 60;
const DEFAULT_BIZ_CODE = 'spec_driven_extension';

// ── CLI 工具 ────────────────────────────────────────────────

function parseArgs() {
  const args = process.argv.slice(2);
  const result = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!a.startsWith('--')) continue;
    const eq = a.indexOf('=');
    if (eq >= 0) {
      result[a.slice(2, eq)] = a.slice(eq + 1);
    } else {
      const key = a.slice(2);
      const next = args[i + 1];
      if (next !== undefined && !next.startsWith('--')) {
        result[key] = next;
        i++;
      } else {
        result[key] = true;
      }
    }
  }
  return result;
}

function requireString(args, key) {
  const v = args[key];
  if (typeof v !== 'string' || !v.trim()) {
    fail(`缺少必填参数: --${key}`);
  }
  return v.trim();
}

function optionalString(args, key) {
  const v = args[key];
  return typeof v === 'string' ? v.trim() : undefined;
}

function output(data) {
  process.stdout.write(JSON.stringify(data, null, 2) + '\n');
}

function info(msg) {
  process.stderr.write(`[info] ${msg}\n`);
}

function fail(msg, code = 1) {
  process.stderr.write(`[error] ${msg}\n`);
  process.exit(code);
}

// ── OpenApiAuthClient（自包含，算法与 register-api 一致） ────

function buildCacheFilePath(ak, baseUrl) {
  const hash = crypto.createHash('md5').update(`${ak}|${baseUrl}`).digest('hex').slice(0, 16);
  return path.join(os.tmpdir(), `.upload-image-signinfo-${hash}.json`);
}

class OpenApiAuthClient {
  constructor(opts) {
    this.ak = opts.ak;
    this.sk = opts.sk;
    this.baseUrl = opts.baseUrl.replace(/\/+$/, '');
    this.tenantName = opts.tenantName;
    this.userName = opts.userName;
    this.source = opts.source ?? 'Normal';
    this.debug = opts.debug ?? false;
    this.timeoutSec = opts.timeout ?? DEFAULT_TIMEOUT_SEC;

    this.signInfo = '';
    this.signInfoCreatedAt = 0;
    this.cacheFile = buildCacheFilePath(this.ak, this.baseUrl);
    this.cacheLoaded = false;
  }

  buildSignature(nonce, timestamp) {
    const plain = `${this.ak}&${nonce}&${timestamp}&${this.sk}`;
    return crypto.createHash('md5').update(plain).digest('hex');
  }

  buildAuthHeaders(nonce, timestamp) {
    const headers = {
      'X-AppKey': this.ak,
      'X-Nonce': nonce,
      'X-Signature': this.buildSignature(nonce, timestamp),
      'X-Timestamp': timestamp.toString(),
    };
    if (this.isSignInfoValid()) {
      headers['X-SignInfo'] = this.signInfo;
    }
    return headers;
  }

  isSignInfoValid() {
    if (this.signInfo && Date.now() - this.signInfoCreatedAt < SIGN_INFO_TTL_MS) {
      return true;
    }
    if (!this.cacheLoaded) {
      this.cacheLoaded = true;
      try {
        const cached = JSON.parse(fs.readFileSync(this.cacheFile, 'utf-8'));
        if (cached?.signInfo && Date.now() - cached.createdAt < SIGN_INFO_TTL_MS) {
          this.signInfo = cached.signInfo;
          this.signInfoCreatedAt = cached.createdAt;
          return true;
        }
      } catch {
        // 文件不存在 / 过期，走重新换发
      }
    }
    return false;
  }

  randomNonce() {
    if (typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    return crypto.randomBytes(16).toString('hex');
  }

  async loadSignInfo() {
    const body = { tenantName: this.tenantName, userName: this.userName, source: this.source };
    const res = await this.request(SIGN_INFO_PATH, 'POST', body);

    if (res?.code !== 200 || typeof res.result !== 'string' || !res.result) {
      throw new Error(
        `getSignInfo 失败 [${res?.code ?? 'no-code'}] ${res?.msg ?? '未知错误'}` +
          `（tenantName=${this.tenantName}, userName=${this.userName}, source=${this.source}）。` +
          `请检查 CW_TENANT / NASL_STORAGE_ACCOUNT_ID / CW_USER_SOURCE 环境变量`,
      );
    }

    this.signInfo = res.result;
    this.signInfoCreatedAt = Date.now();

    try {
      fs.writeFileSync(this.cacheFile, JSON.stringify({ signInfo: this.signInfo, createdAt: this.signInfoCreatedAt }), {
        mode: 0o600,
      });
    } catch {
      // 静默
    }
  }

  async ensureSignInfo() {
    if (this.isSignInfoValid()) return;
    this.signInfo = '';
    await this.loadSignInfo();
  }

  async request(reqPath, method, body, extraHeaders = {}) {
    const nonce = this.randomNonce();
    const timestamp = Math.floor(Date.now() / 1000);
    const headers = { 'Content-Type': 'application/json', ...this.buildAuthHeaders(nonce, timestamp), ...extraHeaders };
    const m = method.toUpperCase();
    const url = this.baseUrl + reqPath;

    if (this.debug) {
      this.logRequest(m, reqPath, headers, body);
    }

    const headerArgs = Object.entries(headers).flatMap(([k, v]) => ['-H', `${k}: ${v}`]);
    const sendBody = m !== 'GET' && m !== 'HEAD' && body !== undefined;
    const bodyStr = sendBody ? JSON.stringify(body ?? null) : undefined;

    const curlArgs = [
      '-s',
      '-w',
      '\n%{http_code}',
      '--max-time',
      String(this.timeoutSec),
      '-X',
      m,
      ...headerArgs,
      ...(sendBody ? ['-d', bodyStr] : []),
      url,
    ];

    const result = spawnSync('curl', curlArgs, { encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });

    if (result.error) {
      if (result.error.code === 'ENOENT') {
        throw new Error('未找到 curl 命令，请确认系统已安装 curl');
      }
      throw new Error(`curl 调用失败: ${result.error.message}`);
    }

    if (result.status !== 0) {
      const hint =
        result.status === 28 ? `（超时 ${this.timeoutSec}s）` : result.status === 6 ? '（DNS 解析失败）' : '';
      throw new Error(`curl 请求失败 (exit=${result.status})${hint}: ${(result.stderr || '').trim()}`);
    }

    const stdout = result.stdout || '';
    const lastNewline = stdout.lastIndexOf('\n');
    const bodyResp = lastNewline >= 0 ? stdout.slice(0, lastNewline) : '';
    const httpStatus = lastNewline >= 0 ? parseInt(stdout.slice(lastNewline + 1), 10) : 0;

    let data;
    try {
      data = bodyResp ? JSON.parse(bodyResp) : {};
    } catch {
      throw new Error(`HTTP ${httpStatus}: 响应非 JSON. body=${bodyResp.slice(0, 200)}`);
    }

    if ((httpStatus < 200 || httpStatus >= 300) && data?.code === undefined) {
      throw new Error(`HTTP ${httpStatus}: ${JSON.stringify(data).slice(0, 200)}`);
    }
    return data;
  }

  logRequest(method, reqPath, headers, body) {
    const sep = '─'.repeat(60);
    process.stderr.write('\n' + sep + '\n');
    process.stderr.write(`[upload-image] ${method} ${this.baseUrl}${reqPath}\n`);
    const safeHeaders = {};
    for (const [k, v] of Object.entries(headers)) {
      if (k === 'X-Signature' || k === 'X-SignInfo') {
        safeHeaders[k] = typeof v === 'string' && v.length > 8 ? `${v.slice(0, 8)}...***` : '***';
      } else {
        safeHeaders[k] = v;
      }
    }
    process.stderr.write(`  Headers: ${JSON.stringify(safeHeaders, null, 2)}\n`);
    if (body !== undefined && body !== null) {
      process.stderr.write(`  Body: ${JSON.stringify(body, null, 2).slice(0, 500)}\n`);
    }
    process.stderr.write(sep + '\n');
  }
}

// ── 文件上传 ────────────────────────────────────────────────

/**
 * 将 fileKey 的每个路径段分别 encodeURIComponent（与 lcap-openapi.ts 行为一致）。
 * 例: "a/b c/d.png" → "a/b%20C/d.png"
 */
function encodeFileKey(fileKey) {
  return fileKey
    .split('/')
    .map((seg) => encodeURIComponent(seg))
    .join('/');
}

/**
 * 上传文件到 LCAP filestorage（multipart/form-data via curl）。
 */
async function uploadFile(client, filePath, bizCode, fileKey, contentType) {
  await client.ensureSignInfo();

  const nonce = client.randomNonce();
  const timestamp = Math.floor(Date.now() / 1000);
  const authHeaders = client.buildAuthHeaders(nonce, timestamp);

  const encodedFileKey = encodeFileKey(fileKey);
  const filename = path.basename(filePath);

  const url = client.baseUrl + UPLOAD_PATH;

  // 构建 curl multipart/form-data 参数
  const curlArgs = [
    '-s',
    '-w',
    '\n%{http_code}',
    '--max-time',
    String(client.timeoutSec),
    '-X',
    'POST',
    // Auth headers
    ...Object.entries(authHeaders).flatMap(([k, v]) => ['-H', `${k}: ${v}`]),
    // Form fields
    '-F',
    `file=@${filePath}`,
    '-F',
    `bizCode=${bizCode}`,
    '-F',
    `fileKey=${encodedFileKey}`,
  ];

  // contentType 可选
  if (contentType) {
    curlArgs.push('-F', `contentType=${contentType}`);
  }

  curlArgs.push(url);

  if (client.debug) {
    info(`Uploading: ${filePath} → ${url}`);
    info(`  bizCode=${bizCode}, fileKey=${encodedFileKey}, contentType=${contentType || '(auto)'}`);
  }

  const result = spawnSync('curl', curlArgs, { encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 });

  if (result.error) {
    if (result.error.code === 'ENOENT') {
      throw new Error('未找到 curl 命令，请确认系统已安装 curl');
    }
    throw new Error(`curl 调用失败: ${result.error.message}`);
  }

  if (result.status !== 0) {
    throw new Error(`curl 上传失败 (exit=${result.status}): ${(result.stderr || '').trim()}`);
  }

  const stdout = result.stdout || '';
  const lastNewline = stdout.lastIndexOf('\n');
  const bodyResp = lastNewline >= 0 ? stdout.slice(0, lastNewline) : '';
  const httpStatus = lastNewline >= 0 ? parseInt(stdout.slice(lastNewline + 1), 10) : 0;

  let data;
  try {
    data = bodyResp ? JSON.parse(bodyResp) : {};
  } catch {
    throw new Error(`上传响应非 JSON (HTTP ${httpStatus}): ${bodyResp.slice(0, 300)}`);
  }

  if (data?.code !== 200) {
    throw new Error(`上传失败 [${data?.code}] ${data?.msg ?? '未知错误'}`);
  }

  const resultData = data.result;
  if (!resultData?.envDomain?.[0]?.domain || !resultData?.fileKey) {
    throw new Error(`上传响应缺少 envDomain/fileKey: ${JSON.stringify(resultData).slice(0, 300)}`);
  }

  const domain = resultData.envDomain[0].domain;
  const returnedFileKey = resultData.fileKey;
  const cdnUrl = `${domain}${returnedFileKey}`;

  return { url: cdnUrl, fileKey: returnedFileKey, domain };
}

// ── 主函数 ──────────────────────────────────────────────────

async function main() {
  const args = parseArgs();
  const filePath = requireString(args, 'file');
  const bizCode = optionalString(args, 'biz-code') || DEFAULT_BIZ_CODE;
  const fileKey = optionalString(args, 'file-key');
  const contentType = optionalString(args, 'content-type');

  // 校验文件存在
  if (!fs.existsSync(filePath)) {
    fail(`文件不存在: ${filePath}`);
  }

  // 读取环境变量
  const baseUrl = process.env.LCAP_OPENAPI_BASE_URL || process.env.NASL_SERVER_BASE_URL;
  const ak = process.env.LCAP_OPENAPI_AK;
  const sk = process.env.LCAP_OPENAPI_SK;
  const userName = process.env.NASL_STORAGE_ACCOUNT_ID;
  const tenantName = process.env.CW_TENANT;
  const source = process.env.CW_USER_SOURCE || 'Normal';
  const debug = process.env.UPLOAD_IMAGE_DEBUG === '1' || process.env.UPLOAD_IMAGE_DEBUG === 'true';

  if (!baseUrl) fail('缺少环境变量 LCAP_OPENAPI_BASE_URL（或 NASL_SERVER_BASE_URL）');
  if (!ak) fail('缺少环境变量 LCAP_OPENAPI_AK');
  if (!sk) fail('缺少环境变量 LCAP_OPENAPI_SK');
  if (!userName) fail('缺少环境变量 NASL_STORAGE_ACCOUNT_ID');
  if (!tenantName) fail('缺少环境变量 CW_TENANT');

  // 生成 fileKey：用户指定 or 自动生成
  const resolvedFileKey = fileKey || `spec_driven_extension/${crypto.randomUUID()}${path.extname(filePath)}`;

  const client = new OpenApiAuthClient({
    ak,
    sk,
    baseUrl,
    tenantName,
    userName,
    source,
    debug,
  });

  const result = await uploadFile(client, filePath, bizCode, resolvedFileKey, contentType);
  output(result);
}

main().catch((err) => {
  const message = err instanceof Error ? err.message : String(err);
  process.stderr.write(`[error] ${message}\n`);
  process.stdout.write(JSON.stringify({ error: message }) + '\n');
  process.exit(1);
});
