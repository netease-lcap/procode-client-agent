#!/usr/bin/env node

/**
 * Generic post-check hook using lint-staged-style config.
 * Config file: post-check-file.json (in the same directory as this script)
 * Uses Node 22+ path.matchesGlob for pattern matching.
 *
 * Matching: every glob key that matches the file runs, in object key order (as in JSON).
 * Commands under one key run in array order; no concurrency.
 *
 * Exit code contract for the caller:
 * - Always exit with code 2, whether success or failure.
 * - Caller 区分成功/失败需要依赖 stderr 文本内容。
 */

import { readFileSync } from "fs";
import path, { dirname, join } from "path";
import { fileURLToPath } from "url";
import { execSync } from "child_process";

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_FILE = join(__dirname, "post-check-file.json");

// Read JSON input from stdin
let jsonInput = "";
for await (const chunk of process.stdin) {
  jsonInput += chunk;
}

const input = JSON.parse(jsonInput || "{}");
const filePath = input?.tool_input?.file_path;

if (!filePath || typeof filePath !== "string") {
  process.exit(0);
}

let config;
try {
  config = JSON.parse(readFileSync(CONFIG_FILE, "utf-8"));
} catch {
  process.exit(0);
}

const projectRoot = process.cwd();
const relativePath = filePath.startsWith(projectRoot + "/")
  ? filePath.slice(projectRoot.length + 1)
  : filePath;

function extractErrorMessage(rawOutput) {
  const match = rawOutput.match(/^Error: ([^\n]+(?:\n(?!    at )[^\n]*)*)/m);
  return match ? match[1].trim() : rawOutput;
}

function runCommand(cmd, file) {
  if (!cmd?.trim()) return;
  try {
    execSync(`${cmd} "${file}"`, {
      encoding: "utf-8",
      stdio: ["pipe", "pipe", "pipe"],
    });
  } catch (err) {
    hasErrors = true;
    const output = err.stderr || err.stdout || err.message || "";
    if (output) {
      errorOutput += "\n================\n" + extractErrorMessage(output);
    }
  }
}

let hasErrors = false;
let errorOutput = "";

const entries = Object.entries(config);

for (const [pattern, commands] of entries) {
  if (!path.matchesGlob(relativePath, pattern)) continue;
  const cmdList = Array.isArray(commands) ? commands : [commands];
  for (const cmd of cmdList) {
    runCommand(cmd, filePath);
  }
}

if (hasErrors && errorOutput) {
  process.stderr.write('自动触发钩子，检查发现错误：');
  process.stderr.write(errorOutput + "\n");
} else if (!hasErrors) {
  process.stderr.write("该文件基础检查无异常，请继续。\n");
}

process.exit(2);
