# playwright-vendor

Official **`playwright-cli`** skill vendored from `@playwright/cli` npm package (`package/skills/playwright-cli/`).

| Field | Value |
|-------|--------|
| Source package | `@playwright/cli@0.1.23` |
| Loaded when | `PLAYWRIGHT_CLI_PREVIEW_ENABLED=1` (staged under `.conversation/wave-addons/playwright-vendor/`) |

## Refresh

```bash
npm pack @playwright/cli@0.1.23
tar -xzf playwright-cli-0.1.23.tgz package/skills/playwright-cli
cp -R package/skills/playwright-cli/* apps/spec-server/template/wave-addons/playwright-vendor/playwright-cli/
```

Update the version pin in this README and in `install-all.sh` when bumping `@playwright/cli`.
