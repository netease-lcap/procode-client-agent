/**
 * Wave Addons plugin for OpenCode.ai
 *
 * Registers wave-addons skills directory so OpenCode discovers
 * asset-recall and other wave-specific skills.
 *
 * AI 网关请求日志：包装各 provider `options.fetch`，记录 request/response headers 与错误摘要；OPENCODE_LOG_RAW_RESPONSE=true 时记录双向诊断。
 * 落盘：`{SBX_LOG_DIR 或 ~/logs}/opencode-request-YYYYMMDD-{N}.log`；单文件超过 10MB 时序号 +1。
 */

import path from 'path';
import fs from 'fs';
import os from 'os';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const LOG_PREFIX = '[wave-addons:ai-fetch]';
const FETCH_LOG_WRAPPED = Symbol('waveAddonsFetchLogWrapped');
let rawResponseSequence = 0;

/** 将完整 SSE 分片汇总为可读正文和工具参数；只展示实际返回，不修复缺失参数。 */
function readableResponseSummary(text) {
  const choices = new Map();
  let unparsed = 0;
  for (const block of text.split(/\r?\n\r?\n/)) {
    const data = block.split(/\r?\n/).filter(line => line.startsWith('data:'))
      .map(line => line.slice(5).replace(/^ /, '')).join('\n');
    if (!data || data.trim() === '[DONE]') continue;
    let event;
    try { event = JSON.parse(data); } catch { unparsed++; continue; }
    for (const choice of event.choices ?? []) {
      const index = choice.index ?? 0;
      if (!choices.has(index)) choices.set(index, { text: '', tools: new Map(), finish: '' });
      const result = choices.get(index);
      const delta = choice.delta ?? choice.message ?? {};
      if (typeof delta.content === 'string') result.text += delta.content;
      if (choice.finish_reason != null) result.finish = choice.finish_reason;
      for (const call of delta.tool_calls ?? []) {
        const key = call.index ?? call.id ?? 0;
        if (!result.tools.has(key)) result.tools.set(key, { id: '', name: '', args: '' });
        const tool = result.tools.get(key);
        if (call.id) tool.id = call.id;
        if (typeof call.function?.name === 'string') tool.name += call.function.name;
        if (typeof call.function?.arguments === 'string') tool.args += call.function.arguments;
      }
    }
  }
  const lines = ['\n\n===== 可读汇总（按实际分片拼接，不补全参数）====='];
  for (const [index, result] of choices) {
    lines.push(`\n候选 ${index}；结束原因：${result.finish || '未返回'}`, '\n回复正文：', result.text || '（无文本正文）');
    for (const [key, tool] of result.tools) {
      let args = tool.args || '（空字符串）';
      try { args = JSON.stringify(JSON.parse(tool.args), null, 2); } catch { /* 保留原始不完整参数 */ }
      lines.push(`\n工具调用 ${key}：${tool.name || '未返回名称'}`, `调用 ID：${tool.id || '未返回'}`, '参数：', args);
    }
  }
  if (!choices.size) lines.push('没有可汇总的 OpenAI 兼容 choices；请查看上方原始响应文本。');
  if (unparsed) lines.push(`未能解析的 SSE 数据段：${unparsed}，请查看上方原文。`);
  return lines.join('\n') + '\n';
}

/** Start before fetch so a failed connection still leaves its request evidence. */
function beginRawExchange(providerId, requestHeaders, requestBody, details = {}, requestSummary) {
  if (process.env.OPENCODE_LOG_RAW_RESPONSE !== 'true') return null;
  let writer, reader, decoder;
  let recording = true, finished = false, responseStarted = false;
  const summaryParts = [];
  let summaryBytes = 0;
  const logId = `${Date.now()}-${process.pid}-${++rawResponseSequence}`;
  const file = path.join(resolveLogDir(), 'opencode-raw-responses', `${logId}.log`);
  const stopRecording = (reason) => {
    if (!recording) return;
    recording = false;
    try { writer?.end(); } catch { /* 日志故障不影响模型响应 */ }
    logAiFetch('raw response recording incomplete:', logId, String(reason));
  };
  const write = (text) => {
    if (!recording) return;
    try {
      if (writer.writableLength > MAX_PENDING_AI_FETCH_LOG_BYTES) {
        stopRecording('log queue exceeded 4MB');
        return;
      }
      writer.write(text);
    } catch (error) { stopRecording(error); }
  };
  const finish = (kind, error) => {
    if (finished) return;
    finished = true;
    const tail = decoder?.decode() ?? '';
    if (tail) { write(tail); if (summaryBytes <= MAX_PENDING_AI_FETCH_LOG_BYTES) summaryParts.push(tail); }
    write(`\n\n===== ${responseStarted ? '响应' : '请求'}终态：${kind} | ${new Date().toISOString()} =====\n${error === undefined ? '' : `原因：${String(error)}\n`}`);
    if (responseStarted) {
      try {
        write(summaryBytes <= MAX_PENDING_AI_FETCH_LOG_BYTES
          ? readableResponseSummary(summaryParts.join(''))
          : '\n响应超过 4MB，未生成汇总；请查看上方原始分片文本。\n');
      } catch { write('\n可读汇总失败，请查看上方原始分片文本。\n'); }
    }
    try { writer?.end(); } catch { /* 日志故障不影响模型响应 */ }
  };
  const safeHeaders = (headers) => Object.fromEntries([...headers].map(([key, value]) =>
    [key, SENSITIVE_HEADER_KEYS.has(key.toLowerCase()) ? '[REDACTED]' : value]));
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    writer = fs.createWriteStream(file, { flags: 'wx', mode: 0o600 });
    writer.on('error', stopRecording);
    const context = { providerId, requestId: diagnosticId(requestHeaders.get('requestid')),
      featurePhaseName: diagnosticId(requestHeaders.get('feature-phase-name')) };
    const summary = requestSummary ?? summarizeReasoningRequest(requestBody, context);
    write(`===== 模型请求与原始响应 =====\n日志编号：${logId}\nRequestId：${context.requestId ?? '未记录'}\n开始时间：${new Date().toISOString()}\nProvider：${providerId}\n模型：${summary.model ?? '未记录'}\n会话：${details.originalSessionId ?? requestHeaders.get('x-session-id') ?? '未记录'}\n请求方法：${details.method ?? '未记录'}\n请求地址：${details.url ?? '未记录'}\n请求头：\n${JSON.stringify(safeHeaders(requestHeaders), null, 2)}\n\n===== 请求参数摘要（reasoning_content 仅记录状态与长度）=====\n${JSON.stringify(summary, null, 2)}\n`);
    logAiFetch('raw response file:', logId, file);
  } catch (error) {
    stopRecording(error);
    return null;
  }
  return {
    fail: (error) => finish('fetch-error', error),
    observe(response) {
      try {
        decoder = new TextDecoder('utf-8', { ignoreBOM: true });
        responseStarted = true;
        write(`\n===== 模型原始响应 =====\nHTTP 状态：${response.status}\n响应头：\n${JSON.stringify(safeHeaders(response.headers), null, 2)}\n\n===== 原始响应分片（UTF-8 文本）=====\n`);
        if (!response.body) { finish('end'); return response; }
        reader = response.body.getReader();
        let index = 0;
        const body = new ReadableStream({
          async pull(controller) {
            try {
              const { done, value } = await reader.read();
              if (done) {
                finish('end'); reader.releaseLock(); controller.close(); return;
              }
              const text = decoder.decode(value, { stream: true });
              summaryBytes += value.byteLength;
              if (summaryBytes <= MAX_PENDING_AI_FETCH_LOG_BYTES) summaryParts.push(text);
              else summaryParts.length = 0;
              write(`\n--- 分片 ${index++} | ${new Date().toISOString()} | ${value.byteLength} 字节 ---\n${text}`);
              controller.enqueue(value);
            } catch (error) {
              finish('error', error);
              try { reader.releaseLock(); } catch { /* noop */ }
              controller.error(error);
            }
          },
          async cancel(reason) {
            finish('cancel', reason);
            try { await reader.cancel(reason); } finally { reader.releaseLock(); }
          },
        }, { highWaterMark: 0 });
        const wrapped = new Response(body, {
          status: response.status, statusText: response.statusText, headers: response.headers,
        });
        for (const key of ['url', 'redirected', 'type']) Object.defineProperty(wrapped, key, { value: response[key] });
        return wrapped;
      } catch (error) {
        stopRecording(error);
        try { reader?.releaseLock(); } catch { /* noop */ }
        return response;
      }
    },
  };
}

/** Direct callers can still record a response; the fetch wrapper supplies its pre-created recorder. */
function recordRawResponse(response, providerId, requestHeaders, requestBody, recorder) {
  const exchange = recorder === undefined ? beginRawExchange(providerId, requestHeaders, requestBody) : recorder;
  return exchange ? exchange.observe(response) : response;
}

const SENSITIVE_HEADER_KEYS = new Set([
  'authorization',
  'x-api-key',
  'api-key',
  'proxy-authorization',
  'cookie',
  'set-cookie',
]);

/** 单文件上限 10MB，超出后写入同日前缀的下一个序号文件 */
const MAX_AI_FETCH_LOG_BYTES = 10 * 1024 * 1024;

/** @type {{ dateKey: string, filePath: string, seq: number } | null} */
let cachedAiFetchLogTarget = null;
let pendingAiFetchLog = '';
let aiFetchLogTimer = null;
let aiFetchLogWriteInFlight = false;

const AI_FETCH_LOG_FLUSH_DELAY_MS = 25;
const AI_FETCH_LOG_IMMEDIATE_FLUSH_BYTES = 64 * 1024;
const MAX_PENDING_AI_FETCH_LOG_BYTES = 4 * 1024 * 1024;
let aiFetchLogOverflowWarned = false;

/** 日志目录：优先 `SBX_LOG_DIR`，否则 `~/logs`（与 spec-server `--log-dir` 默认一致） */
function resolveLogDir() {
  const fromEnv = process.env.SBX_LOG_DIR?.trim();
  if (fromEnv) return path.resolve(fromEnv);
  return path.join(os.homedir(), 'logs');
}

function aiFetchLogDateKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}${m}${day}`;
}

function resolveAiFetchLogFilePath() {
  const dateKey = aiFetchLogDateKey();
  if (cachedAiFetchLogTarget?.dateKey === dateKey) {
    try {
      const stat = fs.statSync(cachedAiFetchLogTarget.filePath);
      if (stat.size < MAX_AI_FETCH_LOG_BYTES) {
        return cachedAiFetchLogTarget.filePath;
      }
    } catch (err) {
      if (!(err && typeof err === 'object' && err.code === 'ENOENT')) {
        /* 无法 stat 时重新解析 */
      }
    }
  }

  const logDir = resolveLogDir();
  try {
    fs.mkdirSync(logDir, { recursive: true });
  } catch {
    /* append 时再失败则静默 */
  }
  const base = path.join(logDir, `opencode-request-${dateKey}`);
  let seq = 1;
  while (true) {
    const filePath = `${base}-${seq}.log`;
    try {
      const stat = fs.statSync(filePath);
      if (stat.size < MAX_AI_FETCH_LOG_BYTES) {
        cachedAiFetchLogTarget = { dateKey, filePath, seq };
        return filePath;
      }
      seq += 1;
    } catch (err) {
      if (err && typeof err === 'object' && err.code === 'ENOENT') {
        cachedAiFetchLogTarget = { dateKey, filePath, seq };
        return filePath;
      }
      throw err;
    }
  }
}

function formatLogArg(arg) {
  if (arg === undefined) return 'undefined';
  if (arg === null) return 'null';
  if (typeof arg === 'object') return JSON.stringify(arg);
  return String(arg);
}

function scheduleAiFetchLogFlush(delayMs = AI_FETCH_LOG_FLUSH_DELAY_MS) {
  if (aiFetchLogTimer || aiFetchLogWriteInFlight) return;
  aiFetchLogTimer = setTimeout(() => {
    aiFetchLogTimer = null;
    flushAiFetchLog();
  }, delayMs);
  aiFetchLogTimer.unref?.();
}

function appendPendingAiFetchLog(content) {
  pendingAiFetchLog += content;
  const size = Buffer.byteLength(pendingAiFetchLog);
  if (size <= MAX_PENDING_AI_FETCH_LOG_BYTES) return;
  // 日志目录持续不可写时必须限制进程内积压；保留最新尾部便于定位当前故障。
  pendingAiFetchLog = Buffer.from(pendingAiFetchLog).subarray(size - MAX_PENDING_AI_FETCH_LOG_BYTES).toString();
  if (!aiFetchLogOverflowWarned) {
    aiFetchLogOverflowWarned = true;
    process.emitWarning('AI fetch log backlog exceeded 4MB; oldest diagnostic logs were dropped', {
      code: 'OPENCODE_AI_FETCH_LOG_OVERFLOW',
    });
  }
}

function flushAiFetchLog() {
  if (aiFetchLogWriteInFlight || !pendingAiFetchLog) return;
  const chunk = pendingAiFetchLog;
  pendingAiFetchLog = '';
  let filePath;
  try {
    filePath = resolveAiFetchLogFilePath();
  } catch {
    const newer = pendingAiFetchLog;
    pendingAiFetchLog = '';
    appendPendingAiFetchLog(chunk + newer);
    if (pendingAiFetchLog) scheduleAiFetchLogFlush();
    return;
  }
  aiFetchLogWriteInFlight = true;
  fs.appendFile(filePath, chunk, 'utf8', (error) => {
    aiFetchLogWriteInFlight = false;
    if (error) {
      const newer = pendingAiFetchLog;
      pendingAiFetchLog = '';
      appendPendingAiFetchLog(chunk + newer);
    }
    if (pendingAiFetchLog) scheduleAiFetchLogFlush(0);
  });
}

/** 批量异步追加，避免高并发模型流被同步磁盘 I/O 阻塞。 */
function logAiFetch(...args) {
  appendPendingAiFetchLog(`${new Date().toISOString()} ${LOG_PREFIX} ${args.map(formatLogArg).join(' ')}\n`);
  scheduleAiFetchLogFlush(
    Buffer.byteLength(pendingAiFetchLog) >= AI_FETCH_LOG_IMMEDIATE_FLUSH_BYTES
      ? 0
      : AI_FETCH_LOG_FLUSH_DELAY_MS,
  );
}

process.once('beforeExit', () => {
  if (!pendingAiFetchLog) return;
  try {
    fs.appendFileSync(resolveAiFetchLogFilePath(), pendingAiFetchLog, 'utf8');
    pendingAiFetchLog = '';
  } catch {
    /* 退出阶段保持原退出码；运行期已通过 warning 报告持续积压。 */
  }
});

function redactHeaderValue(key, value) {
  const k = String(key).toLowerCase();
  if (SENSITIVE_HEADER_KEYS.has(k)) {
    const s = String(value ?? '');
    if (s.length <= 12) return '***';
    return `${s.slice(0, 8)}...***`;
  }
  return value;
}

function headersToObject(headers) {
  if (!headers) return {};
  if (headers instanceof Headers) {
    const out = {};
    headers.forEach((v, k) => {
      out[k] = v;
    });
    return out;
  }
  if (Array.isArray(headers)) {
    const out = {};
    for (const [k, v] of headers) {
      if (k) out[k] = v;
    }
    return out;
  }
  if (typeof headers === 'object') {
    return { ...headers };
  }
  return {};
}

function redactHeaders(headers) {
  const raw = headersToObject(headers);
  const out = {};
  for (const [k, v] of Object.entries(raw)) {
    out[k] = redactHeaderValue(k, v);
  }
  return out;
}

/**
 * 读图结果小图守卫（`tool.execute.after`）：覆盖 PNG 与 JPEG。
 *
 * 现场（2026-10-26）：`read` 把视口外元素 clamp 出来的 1894×2 PNG 作为工具附件放进会话，
 * `wave-prototype` 的整条模型请求被网关 400 拒绝（`[height:2 or width:1894 must be larger than 10]`）。
 * 现场（2026-10-28）：同一约束对 JPEG 同样成立（海上防务装备视觉验收截图为 jpg，网关同样 400）。
 * 这里在**工具结果进入会话之前**把这类退化图从 attachments 摘掉、换成可照做的文字说明：
 * 小图不进上下文/不落历史，模型直接拿到重截指令；合法附件与原 `output` 一律原样保留。
 *
 * provider 身份：`tool.execute.after` 的入参只有 `{tool, sessionID, callID, args}`，没有 provider。
 * 用 `chat.params`（每个模型请求都会触发，且一定早于该请求里发生的工具调用）记 sessionID→provider；
 * 切换模型/provider 后下一条 `chat.params` 就覆盖绑定。**拿不到身份就什么都不做**，
 * 不做无证的全模型拦截。
 */
const IMAGE_GUARD_PROVIDERS = new Set(['wave-prototype']);
const IMAGE_GUARD_DEFAULT_MIN_EDGE = 10;
const IMAGE_GUARD_MARKER = '[wave-guard]';
const PNG_DATA_URL_PATTERN = /^data:image\/png;base64,/i;
const PNG_SIGNATURE = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
const JPEG_DATA_URL_PATTERN = /^data:image\/(?:jpeg|jpg|pjpeg);base64,/i;
const JPEG_SCAN_LIMIT_BYTES = 1024 * 1024;
const JPEG_BLOCK_BYTES = 12 * 1024;
/** 帧头段：SOF0–SOF15 里除 DHT(0xC4)/JPG(0xC8)/DAC(0xCC) 之外的都带像素宽高（含渐进式 SOF2）。 */
const JPEG_SOF_MARKERS = new Set([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf]);
/** 没有长度字段的标记：TEM(0x01)、RST0-7、SOI、EOI。 */
const JPEG_STANDALONE_MARKERS = new Set([0x01, 0xd0, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9]);
const MAX_SESSION_IDENTITY_ENTRIES = 500;

/** sessionID → { providerID, modelID }；按插入序保留最近 500 个会话，避免进程内无界增长。 */
const sessionIdentity = new Map();

function rememberSessionIdentity(sessionID, model, provider) {
  if (!sessionID || typeof sessionID !== 'string') return;
  const providerID = typeof provider?.id === 'string' && provider.id
    ? provider.id
    : String(model?.providerID ?? '');
  if (!providerID) return;
  const modelID = String(model?.id ?? model?.modelID ?? '');
  sessionIdentity.delete(sessionID);
  sessionIdentity.set(sessionID, { providerID, modelID });
  while (sessionIdentity.size > MAX_SESSION_IDENTITY_ENTRIES) {
    const oldest = sessionIdentity.keys().next().value;
    if (oldest === undefined) break;
    sessionIdentity.delete(oldest);
  }
}

/** 阈值只来自已证规则（网关原文 "must be larger than 10"）；`<= minEdge` 判不合格，`0` 关闭守卫。 */
function resolveImageGuardMinEdge() {
  const raw = process.env.OPENCODE_IMAGE_GUARD_MIN_EDGE?.trim();
  if (!raw) return IMAGE_GUARD_DEFAULT_MIN_EDGE;
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0) return IMAGE_GUARD_DEFAULT_MIN_EDGE;
  return Math.floor(parsed);
}

/** 只读 PNG IHDR：核 mime 前缀/签名/首块长度/块类型，任一不符返回 null（放过，不猜）。 */
function readPngPixelSize(url) {
  if (typeof url !== 'string') return null;
  const match = PNG_DATA_URL_PATTERN.exec(url);
  if (!match) return null;
  const base64 = url.slice(match[0].length);
  // 签名 8 + 长度 4 + 类型 4 + 宽高 8 = 24 字节 ⇒ 32 个 base64 字符足够；取 64 保证 4 的整数倍。
  if (base64.length < 32) return null;
  const head = Buffer.from(base64.slice(0, 64), 'base64');
  if (head.length < 24) return null;
  for (let i = 0; i < PNG_SIGNATURE.length; i += 1) {
    if (head[i] !== PNG_SIGNATURE[i]) return null;
  }
  if (head.readUInt32BE(8) !== 13) return null;
  if (head.toString('latin1', 12, 16) !== 'IHDR') return null;
  const width = head.readUInt32BE(16);
  const height = head.readUInt32BE(20);
  if (width <= 0 || height <= 0) return null;
  return { width, height };
}

/**
 * 按需解码 base64 的滑动窗口：只解当前位置那一块，避免把整张图常驻成 Buffer（大图也只读几十字节）。
 * 4 字符解 3 字节，窗口按 3 字节对齐，不会切断编码单元。
 */
function createBase64ByteReader(base64) {
  let start = 0;
  let window = Buffer.alloc(0);
  return (offset, length) => {
    if (offset < 0 || length <= 0) return null;
    if (offset < start || offset + length > start + window.length) {
      start = Math.floor(offset / 3) * 3;
      const charStart = (start / 3) * 4;
      const charCount = Math.ceil((offset - start + length + JPEG_BLOCK_BYTES) / 3) * 4;
      window = Buffer.from(base64.slice(charStart, charStart + charCount), 'base64');
      if (offset - start + length > window.length) return null;
    }
    const from = offset - start;
    return window.subarray(from, from + length);
  };
}

/**
 * 只读 JPEG 帧头（SOF）取像素宽高：按规范逐段扫描标记，命中第一个 SOF 即返回。
 *
 * 为什么是扫描而不是引依赖：该插件由 opencode 以单文件加载（`template/wave-addons/.opencode/plugins/`），
 * 没有 node_modules 保证，所以只按 JPEG 标记段布局读帧头（与 image-size 等成熟实现的 jpeg 分支同一算法），
 * 不做熵解码/DCT，也不扩其它格式。
 *
 * 明确行为：
 * - baseline(SOF0) 与渐进式(SOF2) 等所有 SOFn 走同一条路径，帧头布局一致 ⇒ 都读得到。
 * - Exif 方向**不解析**：守卫唯一判据是最小边，旋转 90° 只交换宽高、最小值不变，判定与提示都不受影响。
 * - 大 Exif/缩略图把帧头推到很后面也能读到（按需逐块解 base64，不依赖固定前缀长度），扫描上限 1MB。
 * - 截断、段长非法、标记不同步、到 SOS 仍无 SOF、data URL mime 与实体字节不符 ⇒ 返回 null（附件原样放过，不猜）。
 */
function readJpegPixelSize(url) {
  if (typeof url !== 'string') return null;
  const match = JPEG_DATA_URL_PATTERN.exec(url);
  if (!match) return null;
  const readBytes = createBase64ByteReader(url.slice(match[0].length));
  const soi = readBytes(0, 2);
  if (!soi || soi[0] !== 0xff || soi[1] !== 0xd8) return null;

  let pos = 2;
  while (pos < JPEG_SCAN_LIMIT_BYTES) {
    const prefix = readBytes(pos, 1);
    if (!prefix || prefix[0] !== 0xff) return null;
    // 规范允许标记前有若干填充 0xFF
    let cursor = pos + 1;
    let marker = null;
    while (cursor < pos + 9) {
      const byte = readBytes(cursor, 1);
      if (!byte) return null;
      if (byte[0] !== 0xff) {
        marker = byte[0];
        break;
      }
      cursor += 1;
    }
    if (marker === null) return null;
    pos = cursor + 1;
    if (JPEG_STANDALONE_MARKERS.has(marker)) continue;
    if (marker === 0xda) return null; // SOS：帧头必须早于它
    const lenBytes = readBytes(pos, 2);
    if (!lenBytes) return null;
    const segmentLength = lenBytes.readUInt16BE(0);
    if (segmentLength < 2) return null;
    if (JPEG_SOF_MARKERS.has(marker)) {
      if (segmentLength < 7) return null;
      const frame = readBytes(pos + 2, 5);
      if (!frame) return null;
      const height = frame.readUInt16BE(1);
      const width = frame.readUInt16BE(3);
      if (width <= 0 || height <= 0) return null;
      return { width, height };
    }
    pos += segmentLength;
  }
  return null;
}

/** 读附件实际像素尺寸：只认 PNG/JPEG，且要求 data URL 声明的 mime 与实体字节一致；其它格式返回 null（放过）。 */
function readAttachmentPixelSize(url) {
  return readPngPixelSize(url) ?? readJpegPixelSize(url);
}

/** 受控反馈：只报实际像素与来源路径（图像头里没有 CSS 尺寸/DSF，不许编），并给可执行的重取步骤。 */
function buildImageGuardText(dropped, sourcePath, minEdge) {
  const lines = [`${IMAGE_GUARD_MARKER} 未送达模型：${sourcePath}`];
  for (const { size } of dropped) {
    lines.push(`图片实际像素 ${size.width}×${size.height}，最小边 ${Math.min(size.width, size.height)}px ≤ ${minEdge}px。`);
  }
  lines.push(
    '原因：该图片不满足模型网关的图片下限（宽高须 > 10），继续发送会让本次请求被 400 拒绝。',
    '原文件保留，可用于人工核对；禁止放大、插值、拼图或裁边伪造可读性。',
    '需要该画面请重新取证：先让元素进入视口（scrollIntoViewIfNeeded），再重测 box 确认可见，再重截；',
    '若元素确实无法呈现（display:none / 0 高 / 折叠面板内 / 已卸载），记录「该区域不可截图」，改走 DOM/样式/运行态证据。',
  );
  return lines.join('\n');
}

/** 结构化留痕：只落 provider / 像素 / 路径，不落图片本体。 */
function logReadImageGuard(client, { providerID, sourcePath, dropped, minEdge }) {
  try {
    const result = client?.app?.log?.({
      body: {
        service: 'wave-addons',
        level: 'warn',
        message: `${IMAGE_GUARD_MARKER} removed degenerate read image`,
        extra: {
          providerID,
          sourcePath,
          pixels: dropped.map(({ size }) => `${size.width}x${size.height}`),
          minEdge,
        },
      },
    });
    if (result && typeof result.catch === 'function') result.catch(() => {});
  } catch {
    /* 日志失败不影响工具结果 */
  }
}

/**
 * 只处理 `read` 的图片附件：命中退化 PNG/JPEG 才改动 output，其余情况一个字都不碰（零语义差分）。
 */
function guardReadResult(toolName, sessionID, args, output, client) {
  if (toolName !== 'read' || !output || typeof output !== 'object') return;
  const identity = sessionID ? sessionIdentity.get(sessionID) : undefined;
  if (!identity || !IMAGE_GUARD_PROVIDERS.has(identity.providerID)) return;
  const attachments = Array.isArray(output.attachments) ? output.attachments : null;
  if (!attachments || attachments.length === 0) return;
  const minEdge = resolveImageGuardMinEdge();
  if (minEdge <= 0) return;

  const kept = [];
  const dropped = [];
  for (const attachment of attachments) {
    const size = readAttachmentPixelSize(attachment?.url);
    if (size && (size.width <= minEdge || size.height <= minEdge)) {
      dropped.push({ size });
      continue;
    }
    kept.push(attachment);
  }
  if (dropped.length === 0) return;

  const sourcePath = (typeof output.title === 'string' && output.title)
    || (typeof args?.filePath === 'string' && args.filePath)
    || '（路径未知）';
  const note = buildImageGuardText(dropped, sourcePath, minEdge);
  const originalOutput = typeof output.output === 'string' ? output.output : '';

  output.attachments = kept;
  // 还有合法附件/其它内容时保留原 output 并追加；全部摘掉才替换成功信息。
  output.output = kept.length > 0 && originalOutput ? `${originalOutput}\n\n${note}` : note;

  logReadImageGuard(client, { providerID: identity.providerID, sourcePath, dropped, minEdge });
}

function resolveRequestUrl(input) {
  if (typeof input === 'string') return input;
  if (input instanceof URL) return input.href;
  if (input && typeof input === 'object' && 'url' in input) return String(input.url);
  return String(input);
}

async function readErrorBodySnippet(response, maxLen = 800) {
  try {
    const text = await response.clone().text();
    if (!text) return '';
    return text.length <= maxLen ? text : `${text.slice(0, maxLen)}…(truncated)`;
  } catch (err) {
    return `(failed to read body: ${err instanceof Error ? err.message : String(err)})`;
  }
}

/** 读取响应体前 maxLen 个字符（用于日志）：clone + 只读首块，避免等整条流读完 */
async function readBodySnippetPrefix(response, maxLen = 200, timeoutMs = 500) {
  try {
    const cloned = response.clone();
    if (!cloned?.body || typeof cloned.body.getReader !== 'function') {
      const text = await cloned.text();
      if (!text) return '';
      return text.length <= maxLen ? text : `${text.slice(0, maxLen)}…(truncated)`;
    }
    const reader = cloned.body.getReader();
    const decoder = new TextDecoder();
    let text = '';
    const deadline = Date.now() + timeoutMs;
    while (text.length < maxLen && Date.now() < deadline) {
      const { done, value } = await reader.read();
      if (done) break;
      text += decoder.decode(value, { stream: true });
    }
    try { await reader.cancel(); } catch { /* noop */ }
    try { reader.releaseLock?.(); } catch { /* noop */ }
    if (!text) return '';
    return text.length <= maxLen ? text : `${text.slice(0, maxLen)}…(truncated)`;
  } catch (err) {
    return `(failed to read body: ${err instanceof Error ? err.message : String(err)})`;
  }
}

const MAX_REASONING_REQUEST_BYTES = 8 * 1024 * 1024;
const MAX_REASONING_EVENT_CHARS = 256 * 1024;
const MAX_REASONING_JSON_CHARS = 1024 * 1024;
const MAX_REASONING_MESSAGES = 256;

function logReasoningSummary(direction, value) {
  try { logAiFetch(`reasoning ${direction}:`, JSON.stringify(value)); } catch { /* Diagnostics must not fail a model call. */ }
}

function reasoningField(object) {
  const present = Object.prototype.hasOwnProperty.call(object, 'reasoning_content');
  const value = object.reasoning_content;
  const type = !present ? 'absent' : value === null ? 'null' : typeof value;
  return {
    present, type,
    ...(type === 'string' ? { length: value.length, bytes: Buffer.byteLength(value) } : {}),
  };
}

function diagnosticId(value) {
  return typeof value === 'string' ? value.slice(0, 256) : null;
}

function summarizeReasoningRequest(body, context) {
  let text;
  let bodyBytes;
  if (typeof body === 'string') {
    bodyBytes = Buffer.byteLength(body);
    if (bodyBytes <= MAX_REASONING_REQUEST_BYTES) text = body;
  } else if (ArrayBuffer.isView(body)) {
    bodyBytes = body.byteLength;
    if (bodyBytes <= MAX_REASONING_REQUEST_BYTES) text = Buffer.from(body.buffer, body.byteOffset, body.byteLength).toString('utf8');
  }
  if (text === undefined) {
    return { ...context, inspection: 'unavailable', bodyBytes,
      reason: bodyBytes > MAX_REASONING_REQUEST_BYTES ? 'body-too-large' : 'unsupported-body' };
  }
  try {
    const source = JSON.parse(text);
    if (!source || typeof source !== 'object' || Array.isArray(source)) throw new Error('not an object');
    const messages = Array.isArray(source.messages) ? source.messages : [];
    const assistants = [];
    let assistantCount = 0;
    for (const [index, message] of messages.entries()) {
      if (message?.role !== 'assistant') continue;
      assistantCount++;
      if (assistants.length >= MAX_REASONING_MESSAGES) continue;
      const tools = Array.isArray(message.tool_calls) ? message.tool_calls : [];
      assistants.push({ index, reasoning_content: reasoningField(message), toolCallCount: tools.length,
        toolCallIds: tools.slice(0, 128).map((t) => diagnosticId(t?.id)), omittedToolCalls: Math.max(0, tools.length - 128) });
    }
    const scalar = (value) => typeof value === 'string' ? value.slice(0, 256)
      : ['boolean', 'number'].includes(typeof value) ? value : undefined;
    return { ...context, inspection: 'complete', bodyBytes,
      model: diagnosticId(source.model), stream: scalar(source.stream),
      thinking: diagnosticId(source.thinking?.type), enable_thinking: scalar(source.enable_thinking),
      reasoning_effort: scalar(source.reasoning_effort), messageCount: messages.length,
      toolCount: Array.isArray(source.tools) ? source.tools.length : 0,
      assistantCount, omittedAssistants: assistantCount - assistants.length, assistantMessages: assistants };
  } catch {
    return { ...context, inspection: 'unavailable', bodyBytes, reason: 'invalid-json' };
  }
}

/** Observe only bytes requested by the consumer; never clone or drain the model stream. */
function observeReasoningResponse(response, context) {
  const contentType = response.headers.get('content-type') ?? '';
  const sse = contentType.includes('text/event-stream');
  const json = /application\/(?:[\w.-]+\+)?json\b/i.test(contentType);
  const details = { ...context, status: response.status,
    gatewayRequestId: diagnosticId(response.headers.get('x-aihub-request-id')),
    responseRequestId: diagnosticId(response.headers.get('requestid')) };
  if ((!sse && !json) || !response.body) {
    logReasoningSummary('response', { ...details, inspection: 'unavailable', reason: 'unsupported-response' });
    return response;
  }
  const choices = new Map();
  const decoder = new TextDecoder();
  let pending = '', data = [], eventChars = 0, droppingEvent = false;
  let uninspected = 0, parsed = 0, sawDone = false, ended = false, model = null, usage;
  let reader;
  function record(payload) {
    parsed++;
    if (payload.model) model = diagnosticId(payload.model);
    if (payload.usage && typeof payload.usage === 'object') {
      usage = Object.fromEntries(['prompt_tokens', 'completion_tokens', 'total_tokens'].filter((key) =>
        typeof payload.usage[key] === 'number').map((key) => [key, payload.usage[key]]));
    }
    if (payload.error) uninspected++;
    for (const item of Array.isArray(payload.choices) ? payload.choices : []) {
      const index = Number.isInteger(item.index) ? item.index : 0;
      if (!choices.has(index)) {
        if (choices.size >= 16) { uninspected++; continue; }
        choices.set(index, { index, reasoning_content: { present: false, type: 'absent', length: 0, bytes: 0 }, tools: new Map(), finishReason: null });
      }
      const choice = choices.get(index);
      const message = item.delta ?? item.message;
      if (message && typeof message === 'object') {
        const field = reasoningField(message);
        if (field.present) {
          const previous = choice.reasoning_content;
          previous.type = !previous.present || previous.type === field.type ? field.type : 'mixed';
          previous.present = true;
          previous.length += field.length ?? 0;
          previous.bytes += field.bytes ?? 0;
        }
        for (const [offset, tool] of (Array.isArray(message.tool_calls) ? message.tool_calls : []).entries()) {
          const toolIndex = Number.isInteger(tool?.index) ? tool.index : offset;
          if (!choice.tools.has(toolIndex) && choice.tools.size >= 128) { uninspected++; continue; }
          const previous = choice.tools.get(toolIndex) ?? '';
          if (typeof tool?.id === 'string' && tool.id !== previous) {
            const id = previous + tool.id;
            if (id.length > 256) uninspected++;
            choice.tools.set(toolIndex, id.slice(0, 256));
          }
        }
      }
      if (item.finish_reason != null) choice.finishReason = diagnosticId(item.finish_reason);
    }
  }
  function parsePayload(text) {
    if (text.trim() === '[DONE]') { sawDone = true; return; }
    try { record(JSON.parse(text)); } catch { uninspected++; }
  }
  function dispatch() {
    if (data.length && !droppingEvent) parsePayload(data.join('\n'));
    data = []; eventChars = 0; droppingEvent = false;
  }
  function line(text) {
    if (!text) { dispatch(); return; }
    if (!text.startsWith('data:')) return;
    const value = text.slice(5).replace(/^ /, '');
    eventChars += value.length;
    if (eventChars > MAX_REASONING_EVENT_CHARS) {
      if (!droppingEvent) uninspected++;
      droppingEvent = true; data = [];
    } else if (!droppingEvent) data.push(value);
  }
  function inspect(text, final = false) {
    if (!sse) {
      if (pending.length + text.length > MAX_REASONING_JSON_CHARS) { droppingEvent = true; pending = ''; }
      else if (!droppingEvent) pending += text;
      if (final) { if (droppingEvent) uninspected++; else parsePayload(pending); }
      return;
    }
    pending += text;
    let offset = 0;
    for (let i = 0; i < pending.length; i++) {
      if (pending[i] !== '\n' && pending[i] !== '\r') continue;
      if (pending[i] === '\r' && i === pending.length - 1 && !final) break;
      line(pending.slice(offset, i));
      if (pending[i] === '\r' && pending[i + 1] === '\n') i++;
      offset = i + 1;
    }
    pending = pending.slice(offset);
    if (pending.length > MAX_REASONING_EVENT_CHARS) {
      if (!droppingEvent) uninspected++;
      droppingEvent = true; data = []; pending = '';
    }
    if (final) { if (pending) line(pending); dispatch(); pending = ''; }
  }
  function finish(endedBy) {
    if (ended) return;
    ended = true;
    logReasoningSummary('response', { ...details, inspection: uninspected || endedBy !== 'eof' ? 'partial' : parsed ? 'complete' : 'unavailable',
      endedBy, sawDone, parsedEvents: parsed, uninspectedEvents: uninspected, model, usage,
      choices: [...choices.values()].map(({ tools, ...choice }) => ({ ...choice, toolCallIds: [...tools.values()] })) });
  }
  try {
    reader = response.body.getReader();
    const stream = new ReadableStream({
      async pull(controller) {
        try {
          const { done, value } = await reader.read();
          try { inspect(decoder.decode(value, { stream: !done }), done); } catch { uninspected++; }
          if (done) { finish('eof'); reader.releaseLock(); controller.close(); }
          else controller.enqueue(value);
        } catch (error) {
          finish('error');
          try { reader.releaseLock(); } catch { /* Already released. */ }
          controller.error(error);
        }
      },
      async cancel(reason) {
        finish('cancelled');
        try { await reader.cancel(reason); } finally { reader.releaseLock(); }
      },
    }, { highWaterMark: 0 });
    const observed = new Response(stream, { status: response.status, statusText: response.statusText, headers: response.headers });
    for (const key of ['url', 'redirected', 'type']) Object.defineProperty(observed, key, { value: response[key] });
    return observed;
  } catch {
    try { reader?.releaseLock(); } catch { /* No active lock. */ }
    logReasoningSummary('response', { ...details, inspection: 'unavailable', reason: 'observer-unavailable' });
    return response;
  }
}

function wrapProviderFetch(fetchFn, providerId) {
  if (typeof fetchFn !== 'function') {
    fetchFn = fetch;
  }
  if (fetchFn[FETCH_LOG_WRAPPED]) {
    return fetchFn;
  }
  const wrapped = async (input, init) => {
    const rawRequestHeaders = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
    // OpenCode 在 chat.headers hook 之后仍会补入默认 Session 头，必须在发送前覆盖/删除。
    // Headers 按大小写不敏感处理，避免 X-Session-Id 与 x-session-id 同时存在。
    const headers = new Headers(init?.headers ?? (input instanceof Request ? input.headers : undefined));
    const appId = process.env.APP_ID?.trim() || process.env.NASL_STORAGE_APP_ID?.trim();
    for (const name of ['x-session-affinity', 'x-session-id']) {
      if (appId) headers.set(name, appId);
      else headers.delete(name);
    }
    init = { ...init, headers };
    const url = resolveRequestUrl(input);
    const method = (init?.method ?? (input instanceof Request ? input.method : 'GET')).toUpperCase();
    const reqHeaders = redactHeaders(init?.headers);
    const captureReasoning = process.env.OPENCODE_LOG_RAW_RESPONSE === 'true';
    const context = { providerId, requestId: diagnosticId(headers.get('requestid')),
      featurePhaseName: diagnosticId(headers.get('feature-phase-name')) };
    let requestSummary;
    if (captureReasoning) {
      try { requestSummary = summarizeReasoningRequest(init.body, context); }
      catch { requestSummary = { ...context, inspection: 'unavailable', reason: 'inspection-failed' }; }
      logReasoningSummary('request', requestSummary);
    }
    const rawExchange = beginRawExchange(providerId, headers, init.body,
      { url, method, originalSessionId: rawRequestHeaders.get('x-session-id') }, requestSummary);

    logAiFetch('====================== AI fetch request start ======================');
    logAiFetch('provider:', providerId);
    logAiFetch('method:', method);
    logAiFetch('url:', url);

    if (process.env.OPENCODE_LOG_BODY) {
      try {
        const source = JSON.parse(init?.body);
        const copied = { ...source };

        delete copied.messages;
        delete copied.tools;

        logAiFetch('request body:', JSON.stringify(copied, null, 2));
      } catch (error) {
        logAiFetch('request body error:', JSON.stringify(error, null, 2));
      }
    }

    logAiFetch('request headers:', JSON.stringify(reqHeaders, null, 2));
    if (init?.signal?.aborted) {
      logAiFetch('request signal: already aborted');
    }

    const started = Date.now();
    try {
      const response = await fetchFn(input, init);
      const elapsedMs = Date.now() - started;
      const resHeaders = redactHeaders(response.headers);

      logAiFetch('====================== AI fetch response headers start ======================');
      logAiFetch('provider:', providerId);
      logAiFetch('status:', response.status, response.statusText || '');
      logAiFetch('elapsedMs:', elapsedMs);
      logAiFetch('response headers:', JSON.stringify(resHeaders, null, 2));

      // 打印响应体前 200 字符（排查网关用 HTTP 200 + 错误体的场景，如「积分不足」/「featurePhaseName 未找到」）。
      // **默认关闭**：clone + 读取会影响流式输出（实测可能卡住），仅排障时用 OPENCODE_LOG_AI_RESPONSE_BODY=true 打开。
      if (process.env.OPENCODE_LOG_AI_RESPONSE_BODY === 'true' && process.env.OPENCODE_LOG_RAW_RESPONSE !== 'true') {
        try {
          const snippet = await readBodySnippetPrefix(response, 200);
          logAiFetch('response body(truncated 200):', snippet || '(empty)');
        } catch (error) {
          logAiFetch('response body read error:', String(error));
        }
      }

      logAiFetch('====================== AI fetch response headers end ======================');

      // response.clone() 会让每个模型流被完整读取两遍。仅在显式诊断时启用，
      // 避免正常高并发任务承担额外的内存、流队列和事件循环开销。
      if (process.env.OPENCODE_MONITOR_RESPONSE_STREAM === 'true' && process.env.OPENCODE_LOG_RAW_RESPONSE !== 'true') void (async () => {
        try {
          const cloned = response.clone();
          const body = cloned?.body;
          if (!body) {
            logAiFetch('====================== AI fetch response stream end (no body) ======================');
            logAiFetch('provider:', providerId, 'streamMs:', Date.now() - started, 'endedAt:', new Date().toISOString());
            return;
          }
          const reader = body.getReader();
          for (;;) {
            const { done } = await reader.read();
            if (done) break;
          }
          const streamMs = Date.now() - started;
          logAiFetch('====================== AI fetch response stream end ======================');
          logAiFetch('provider:', providerId, 'streamMs:', streamMs, 'endedAt:', new Date().toISOString());
          try { reader.releaseLock?.(); } catch { /* noop */ }
        } catch (err) {
          const monitorErr = err instanceof Error ? err.message : String(err);
          logAiFetch('====================== AI fetch response stream monitor failed ======================');
          logAiFetch('provider:', providerId, 'error:', monitorErr);
        }
      })();
      let observedResponse = response;
      if (captureReasoning) {
        try { observedResponse = observeReasoningResponse(response, context); }
        catch { logReasoningSummary('response', { ...context, inspection: 'unavailable', reason: 'observer-failed' }); }
      }
      return recordRawResponse(observedResponse, providerId, headers, init?.body, rawExchange);
    } catch (err) {
      rawExchange?.fail(err);
      if (captureReasoning) logReasoningSummary('response', { ...context, inspection: 'unavailable', endedBy: 'fetch-error' });
      const elapsedMs = Date.now() - started;
      const message = err instanceof Error ? err.message : String(err);
      const cause =
        err instanceof Error && err.cause != null
          ? err.cause instanceof Error
            ? err.cause.message
            : String(err.cause)
          : undefined;
      logAiFetch('====================== AI fetch failed ======================');
      logAiFetch('provider:', providerId);
      logAiFetch('elapsedMs:', elapsedMs);
      logAiFetch('error:', message);
      if (cause) logAiFetch('cause:', cause);
      if (err instanceof Error && err.name) logAiFetch('errorName:', err.name);
      logAiFetch('====================== AI fetch end ======================');
      throw err;
    }
  };

  wrapped[FETCH_LOG_WRAPPED] = true;
  return wrapped;
}

function installProviderFetchLogging(config) {
  const providers = config?.provider;
  if (!providers || typeof providers !== 'object') return;

  for (const [providerId, provider] of Object.entries(providers)) {
    if (!provider || typeof provider !== 'object') continue;
    provider.options = provider.options ?? {};
    const prev = provider.options.fetch;
    provider.options.fetch = wrapProviderFetch(
      typeof prev === 'function' ? prev : fetch,
      providerId,
    );
  }
}

export const WaveAddonsPlugin = async ({ client, directory }) => {
  const skillsDir = path.resolve(__dirname, '../../skills');

  return {
    config: async (config) => {
      config.skills = config.skills || {};
      config.skills.paths = config.skills.paths || [];
      if (!config.skills.paths.includes(skillsDir)) {
        config.skills.paths.push(skillsDir);
      }
      installProviderFetchLogging(config);
    },

    /**
     * 只做 sessionID → provider 的绑定，**不改**模型请求参数（`output` 一个字都不动）。
     * 每个模型请求都会触发，且一定早于该请求里发生的工具调用；切模型后自动覆盖。
     */
    'chat.params': async (input) => {
      rememberSessionIdentity(input?.sessionID, input?.model, input?.provider);
    },

    /** 读图结果进入会话之前：退化 PNG/JPEG 摘掉并换成重截说明；合法附件与原 output 原样保留。 */
    'tool.execute.after': async (input, output) => {
      guardReadResult(input?.tool, input?.sessionID, input?.args, output, client);
    },

    /**
     * OpenCode `bash` 工具在 `process.env` 之上合并此处 `output.env`（见 opencode `tool/bash.ts` shellEnv）。
     * `input.sessionID` 由运行时写入 overlay JSON（`@lcap/opencode-runtime`）。
     */
    'shell.env': async (input, output) => {
      const sessionID = input?.sessionID;
      if (!sessionID || typeof sessionID !== 'string') return;
      const file = path.join(os.homedir(), '.wave', 'opencode', `shell-env-${sessionID}.json`);
      let raw;
      try {
        raw = fs.readFileSync(file, 'utf8');
      } catch {
        return;
      }
      try {
        const data = JSON.parse(raw);
        if (!data || typeof data !== 'object') return;
        for (const [k, v] of Object.entries(data)) {
          if (typeof v === 'string') {
            output.env[k] = v;
          }
        }
      } catch {
        /* 忽略损坏的 JSON */
      }
    },
  };
};
