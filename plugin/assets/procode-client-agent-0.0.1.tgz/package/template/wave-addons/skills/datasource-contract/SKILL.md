---
name: datasource-contract
description: 数据源配置契约操作 skill。覆盖 datasources.json 的查/增/改/删四类操作与「取回环地址写项目配置」的消费路径，按场景编排 datasource-tool.mjs 的子命令链；agent 不得绕过工具直接修改契约文件（.manifest/datasources.json）。触发场景：沙箱工作空间内查看/新增/修改/删除数据源配置，或写项目配置时需要数据源的回环连接地址。
---

# 数据源配置操作手册

> 维护者注：本文为双副本——契约侧源 `config/shared/manifest/datasource/knowledge.md` 与模板侧 skill
> `template/wave-addons/skills/datasource-contract/SKILL.md` 内容逐字一致，修改必须双改（一致性测试钉死）；
> 工具开发细节（参数表 / 退出码全表 / stdout-stderr 契约）见契约侧目录
> `config/shared/manifest/datasource/README.md`，不随沙箱分发。

本文是 AI 对话 agent 在沙箱工作空间内操作数据源配置的**自包含手册**——查 / 增 / 改 / 删四类操作
与消费路径的完整命令链，操作语义不依赖任何外部文档。

- 命令统一形态：`node .specify/scripts/javascript/datasource-tool.mjs <子命令> [参数]`，成败判定以**退出码**为准（一个例外：`register-prepare` 的「平台类型不支持」是 **exit 0** + stdout `UNSUPPORTED_TYPE`——值不是故障，见操作流 1）
- **落点固定 `$HOME/resources/.manifest/datasources.json`**：工具不跟 cwd 走。OpenCode 在 worktree checkout 时 cwd 不是 resources，仍读写沙箱那一份。HOME 未设置则 exit 2，**禁止**回退 cwd
- 数据源条目**不是 agent 手填的连接参数**：连接字段由用户在 IDE 侧选型、平台侧回填（流程见「操作流 1」），
  agent 的职责是**读**、**消费**（取回环地址）与**受控地写**（新增/修正/删除）

## 铁律：禁止绕过工具直改文件

`.manifest/datasources.json` **只经工具子命令读写，禁止直接编辑文件**（含重定向写 / 编辑器改写 /
脚本拼 JSON 落盘）。直改的五重危害：

1. **明文凭据失去权限约束**——条目含 `config.password` 明文，工具落盘为 `0o600` 且原子写；
   手写文件的权限不可控（可能是全局可读）、且非原子（会读到半截文件）
2. **一条坏条目瘫痪全部读路径**——`dataSources` 里一条 `null` / 非对象条目即令 `get` / `validate` /
   `upsert` / `delete` / `resolve` 全部 exit 3（损坏 ≠ 未找到），一处手误整表不可读
3. **判别式联合被旁路**——`validate`（含 `upsert` 的写前自校验）是唯一能拦住「mysql8 条目带
   `schemaName`」这类字段错配的地方；手写条目带着别的数据库类型的字段，消费方会按错误的 URL
   模板拼串，**报错现场在连接时、不在写入时**
4. **回环映射与条目失同步**——消费地址 = 条目 `host:port` join 映射表；手改端点后旧映射成孤儿、
   新端点无映射，`resolve` 直接 exit 4（映射缺失）
5. **权威意图不可重建**——本文件**不是缓存**：没有 `rebuildFrom`、丢了就是数据损失。删文件「重置」
   等于把用户已确认的配置抹掉

> 与中间件配置的区别：中间件**有状态机**（init → ok/failed，`set-status` 置终态）；数据源**没有**
> 状态字段——工具不提供 `set-status`，条目写进去即「可用」（顺序保证见「操作流 1」）。

## 契约结构（最小必要面）

顶层：`{ schemaVersion: 1, dataSources: DataSource[] }`（schemaVersion 恒 1，工具守卫）。

### 条目字段

| 字段 | 说明 |
|---|---|
| `dataSourceName` | 条目唯一名（条目键，全表唯一）。**由 IDE 侧的选型流程产出**，不是自由命名；同名 `upsert` 即**整条目替换**——写前先 `get --name` 查一下，防误覆盖 |
| `databaseType` | `mysql8` \| `oracle` \| `postgresql` \| `sqlserver`——**判别式联合的判别键**，决定 config 允许哪些字段。**表内类型以外的值也合法**（平台可新增类型，如 `mysql`）——见下 |
| `databaseMode` | `Platform_Generation`（平台预置）/ `Manual_Configuration`（手工配置）。**平台侧怎么产生配置**的区别，agent 侧两条路径同构 |
| `config` | 连接参数（下表按类型分家） |

### config 字段矩阵（**判别式联合**）

| `databaseType` | 连接目标字段 | 特有字段 | 公共字段 |
|---|---|---|---|
| `mysql8` | `database` | —— | `host` / `port` / `username` / `password` / `customSetting?` |
| `oracle` | **`connectionTarget`** | `connectedMode`（`sid` \| `serviceName`） | 同上 |
| `postgresql` | `database` | `schemaName` | 同上 |
| `sqlserver` | `database` | `schemaName` | 同上 |
| **表内之外的其它类型**（如 `mysql`） | `database` 或 `connectionTarget`（**二者任一**） | **不判**（无判据） | 同上 |

> ⛔ **上表是「已知形态表」，不是准入白名单**——**类型不在表内 ≠ 非法**。
> `databaseType` 是**平台侧的动态清单**（平台新增类型不经过本契约），表内四值只是**契约已知**的
> 那几种。**把上表当准入门用会拒掉平台的新类型**——工具会 `exit 3` 报错，而 `upsert` 是唯一
> 合法写路径，**被拒即完全无法登记**（历史上平台新增 `mysql`（MySQL 5.7）时正是这个故障）。
>
> **表外类型的校验**：只判「**有连接目标**」——`database` / `connectionTarget` 按其顺序探测，
> **命中任一且非空**即通过；**都没命中 → exit 3**（不是告警）。**不检**「禁多余字段」与特有字段
> （无判据，属已知限制）。
>
> **你的动作**：拿到表外的 `databaseType` 时**照常操作**（`upsert` / `validate`），不要因为
> 「不在四值内」就停下或改写类型——**类型的可用性由平台判定，不由本表判定**。表外类型条目在
> 工具的报错里若出现 `config.database`（探测失败诊断），补一个连接目标字段即可。

**字段级语义（几条不显然的）**：

- `port` 是**字符串**（`"3306"`），填 number 会被 `validate` 拒（exit 3）——端口按文本承载
- `customSetting` 是 JDBC URL 的 **query 片段**且**不带前导 `&`**（`sslmode=require&targetServerType=master`）；
  带 `&` 只出**告警**（不翻退出码），但消费方拼接时会得到 `&&`
- `schemaName` 空串 = 用数据库默认 schema；`password` 空串 = 无密码——**两者都是合法值**
- `host` 只填主机名或 IP：含冒号（`host:port` 或 IPv6 字面量）出**告警**——`resolve` 按
  `${host}:${port}` 拼真实端点，把端口写进 host 会拼出双端口

### JSON 样例

四类型各一条（`ds01` 平台内置 MySQL / `ds02` Oracle / `ds03` PostgreSQL / `ds04` SQL Server）：

```json
{
  "schemaVersion": 1,
  "dataSources": [
    {
      "dataSourceName": "ds01",
      "databaseType": "mysql8",
      "databaseMode": "Platform_Generation",
      "config": {
        "host": "192.168.0.1", "port": "3306", "username": "root", "password": "123456",
        "database": "lcap", "customSetting": "time"
      }
    },
    {
      "dataSourceName": "ds02",
      "databaseType": "oracle",
      "databaseMode": "Manual_Configuration",
      "config": {
        "host": "192.168.0.1", "port": "1521", "username": "root", "password": "123456",
        "connectedMode": "sid", "connectionTarget": "ORCL"
      }
    },
    {
      "dataSourceName": "ds03",
      "databaseType": "postgresql",
      "databaseMode": "Manual_Configuration",
      "config": {
        "host": "192.168.0.1", "port": "5432", "username": "root", "password": "123456",
        "database": "lcap", "schemaName": "",
        "customSetting": "sslmode=require&targetServerType=master"
      }
    },
    {
      "dataSourceName": "ds04",
      "databaseType": "sqlserver",
      "databaseMode": "Manual_Configuration",
      "config": {
        "host": "192.168.0.1", "port": "1433", "username": "root", "password": "123456",
        "database": "lcap", "schemaName": "time"
      }
    }
  ]
}
```

## 退出码速查

| 码 | 含义 | 典型触发 |
|---|---|---|
| `0` | 成功 | ——（`register-prepare` 的**平台类型不支持**也是 `0`：stdout `{"ok":false,"reason":"UNSUPPORTED_TYPE"}`——值不是故障，见操作流 1） |
| `1` | 外部命令调用失败 | `resolve` 的**兄弟工具**（`uds-mapping-tool.mjs`）无法调用 / 超时 / 非 0、4 的退出码；`register-*` 的**平台工具**（`platform-tool.mjs`）无法调用 / 超时 / 非 0、4 的退出码；`register-commit` ⑦ `map-ensure` 失败（**零写入**，见操作流 1） |
| `2` | 参数非法 | 未知子命令 / 未知 flag / 越权 flag（如 `get --entry`）/ flag 缺值 / `--entry` 不是合法 JSON 或不是对象；`register-prepare` 的 `--slots` 非法 JSON 或形态非法（含 `--type` 空串）；`register-commit` 缺参（含 `--type` / `--app` 空串）/ `--answer` 非法 JSON |
| `3` | 校验失败 | JSON 损坏 / `schemaVersion` 不符 / **判别式联合违约**（表内类型）/ **连接目标探测落空**（表外类型）/ 同名字段重复 / `resolve` 拿到形态异常的映射；`register-commit` 的 `--answer` 形态违约（含取消兜底 `{}`）/ 平台工具成功输出的形态违约 / 条目写前自校验 / ⑨ 整文件复验失败 |
| `4` | 未找到 | `get --name` / `delete --name` / `resolve --name` 未命中；`register-commit` ④ **平台未命中** `dataSourceName`（询问答案指向平台不存在的配置——引用不一致，非查询答案，见操作流 1） |
| `5` | 原子写失败 | 磁盘 / 权限问题 |

⛔ **`resolve` 的 exit 4 有两义**，靠 **stderr 首行**区分（读第 4 码时必看首行；`register-commit` ④ 的
exit 4 是第三种——平台未命中，分派见操作流 1）：

| stderr 首行 | 含义 | 下一步 |
|---|---|---|
| `未找到数据源条目：<name>` | 该数据源**不存在** | 走「操作流 1」（register 编排：prepare → 询问 → commit） |
| `映射缺失：<host:port> 在回环映射表（owner：uds-mapping 契约）中无对应条目…` | 数据源**存在**，但回环通道未建 | 先建映射（`map-ensure --real-endpoint <host:port>`）再 `resolve`——**不要**重跑新增流程 |

## 操作流 1：新增数据源（**agent 不手填连接参数**）

连接字段全部由平台回填。类型门、询问载荷拼装、平台取配置、建映射、写条目、复验**全部机器化**在
`register-prepare` / `register-commit` 两个编排子命令里，agent 只做三件事：**跑 prepare → 发一次
询问 → 跑 commit**。ask 是唯一的断开点（发起者是 LLM，子进程没有通往 agent 会话的通道）；平台查询
由子命令内部经 `platform-tool.mjs` 子进程完成，**全链路都在沙箱内**，没有「交回服务层」的中转。
（服务层的 TS 入口 `registerDataSource` 走同一套子命令编排，两个入口同源——本手册只讲 agent 入口。）

```
1. register-prepare --type <t> --slots '<槽位表 json>'
     → ⓪ 问平台该类型是否支持 + 组装询问载荷
     → stdout {"ok":true,"ask":{…}}                     ← 进第 2 步
     → stdout {"ok":false,"reason":"UNSUPPORTED_TYPE"}  ← 平台不支持，到此为止（不询问）
2. 发起 dataSourceSelect 询问（question 工具），input = 第 1 步的 ask 载荷
     → 用户完成选择，拿到答案 JSON 字符串 {"sources":[{title,dataSourceName},…]}
3. register-commit --app <appId> --answer '<答案原文>' --type <t>
     → 子命令内部：④ 逐名查平台配置 → 组装条目 → ⑦ 建映射（先映射后写）→ ⑧ 写条目 → ⑨ 复验
     → stdout {"ok":true,"registered":[<条目名>]}        ← 完成
```

```bash
# 第 1 步：⓪ 类型门 + 询问载荷。
#   --type  = 平台类型标识（如 mysql8，非展示名）
#   --slots = 本问槽位表（任务上下文给出：本问要用户配几个数据源就列几个槽位；
#             title 本问内唯一，答案按它对齐）
node .specify/scripts/javascript/datasource-tool.mjs register-prepare \
  --type mysql8 --slots '[{"title":"数据源 1：CRM 主事务库"},{"title":"数据源 2：报表库"}]'
# → {"ok":true,"ask":{"kind":"dataSourceSelect","databaseName":"mysql8",
#                     "sources":[{"title":"数据源 1：CRM 主事务库"},{"title":"数据源 2：报表库"}]}}

# 第 2 步：发询问（question 工具）——ask 载荷**原样**作 input，options 传 []，文案自拟：
#   {"header":"数据源（mysql8）","question":"请选择要接入的 mysql8 数据源",
#    "options":[],"input":<上面的 ask 载荷>}

# 第 3 步：提交登记。
#   --app    = 当前应用的 appId（agent 上下文持有；数据源按 app 维度隔离）
#   --answer = 第 2 步答案的 JSON 字符串**原文**（不解析、不重组、不去重）
#   --type   = 与第 1 步**同一个值**（条目 databaseType 的唯一来源）
node .specify/scripts/javascript/datasource-tool.mjs register-commit \
  --app app-5 --type mysql8 \
  --answer '{"sources":[{"title":"数据源 1：CRM 主事务库","dataSourceName":"crm-mysql-dev"},{"title":"数据源 2：报表库","dataSourceName":"crm-mysql-dev"}]}'
# → {"ok":true,"registered":["crm-mysql-dev"]}
#   （两槽同选同一个库：按名去重，登记一条即完备——dataSourceName 是条目键，存的是配置而非槽位指派）
```

**三个跨进程交接点（显式约定，缺一环链路即断）**：

| 交接 | 载体 | 约定 |
|---|---|---|
| prepare → 询问 | prepare stdout 的 `ask` | **裸 input 对象**（`{kind, databaseName, sources}`）——原样装进 question 的 `input`，`options` 传 `[]`；不增删改键（下拉候选由 IDE 调 `sqlList?type=` 自己拉，不写进 `sources`） |
| 询问 → commit | question 的返回值 | 答案 map 按**问题文案**取值，取到的 **JSON 字符串原文**逐字交给 `--answer`；按 `title` 对齐、逐槽遍历、同名去重都在 commit 内部，**agent 不解析** |
| prepare ↔ commit | `--type` | 两段必须传**同一个值**——commit 不消费平台响应里的 `databaseType`，`--type` 是条目 `databaseType` 的唯一来源 |

**失败分派（每步的退出码 → agent 的动作）**：

| 步 | 退出码 / 形态 | agent 的动作 |
|---|---|---|
| 1 | `0` + `{"ok":false,"reason":"UNSUPPORTED_TYPE"}` | **值不是故障**：告知用户该类型平台当前不支持，流程到此为止——不发询问、不写条目、不要改用 `upsert` 手拼 |
| 1 | `2`（`--type` / `--slots` 形态非法：槽位空 / `title` 重复 / 非法 JSON） | 自己的调用错误——修参数重跑 |
| 1 | `1`（`platform-tool.mjs` 调用失败：产物缺失 / 超时 / 平台通道故障） | **环境问题**，报告平台——不要误判成「类型不支持」 |
| 1 | `3`（平台成功输出的形态违约） | 基础设施异常，报告——同样不要误判成「类型不支持」 |
| 2 | 答案为空对象 `{}` | 用户取消 / 超时的兜底答案：**终止流程**，不要把 `{}` 提交给 commit（commit 对它 exit 3） |
| 3 | `0` + `{"ok":true,"registered":[…]}` | 完成；`registered` 即落盘的条目名清单（多槽同选已去重） |
| 3 | `2`（缺参 / `--app`、`--type` 空串 / `--answer` 非法 JSON） | 修参数重跑 |
| 3 | `3`（读 stdout `{"ok":false,"errors":[…]}`） | 多为 `--answer` 形态违约（`sources` 空 / 槽位缺 `title` 或 `dataSourceName` / `title` 重复）——按诊断修后重跑；平台响应形态违约、条目写前自校验失败同码，无法自愈时报告 |
| 3 | `4`（平台未命中 `dataSourceName`） | **引用不一致**：询问答案指向平台不存在的配置，需用户 / 平台介入——不要循环重试、不要改用 `upsert` 手拼绕过 |
| 3 | `1`（平台工具 / `map-ensure` 失败） | 此**零写入**（先映射后写：⑦ 失败即中断，条目不留痕；已建的映射是良性孤儿）；确认 `.specify/scripts/javascript/` 下产物就位后整体重跑（commit 幂等，同名 upsert 覆盖） |
| 3 | `5`（落盘失败） | 磁盘 / 权限问题，报告用户；**不要**改用直接写文件绕过 |

**为什么先映射后写**（⑦ 在 ⑧ 前，由子命令内部保证）：文件里的条目**都是可用的**（消费方不必按状态过滤）。若反序（先写条目、建映射失败）→ 留下一条指向不存在通道的条目，消费方必死。顺序反了失败时留的是**孤儿映射**（映射在、条目不在）——那是良性的：没有任何消费方会去找它，下次同端点的 `map-ensure` 会收养它，沙箱重启时 `map-rebuild` 也按引用集清掉它。

**新登记不要回退到手拼链**：`map-ensure` + `upsert` + `validate` 的手工链只用于**修正既有条目**（操作流 3）。新登记若手拼，等于让 agent 自己做答案解析、逐名平台查询、顺序落盘——每一件都是编排子命令已机器化的职责，手拼即重新引入本操作流消除掉的交接断层。

## 操作流 2：查看数据源

```bash
node .specify/scripts/javascript/datasource-tool.mjs get                 # 整表（文件缺失 → 空表，非错误）
node .specify/scripts/javascript/datasource-tool.mjs get --name ds01     # 单条（未命中 exit 4）
```

- `get` 读回的 `config.host` / `config.port` 就是**真实地址**（`192.168.0.1:3306`）——呈现给用户
  核对时**无需任何转换**（`127.0.0.1:<port>` 是沙箱内消费形态，只在「操作流 4」写项目配置时才 join）
- **敏感值打码回显**（`password` / `accessSecret` 类）：只报「已配置/未配置」，不原样贴进对话
- 文件缺失（新工作空间）→ `get` 返回空表 `{"schemaVersion":1,"dataSources":[]}`，**不是错误**；
  文件损坏 → exit 3（**损坏 ≠ 未找到**，此时报告用户/平台，不要自行重建文件）

## 操作流 3：修改与删除

**修改**（适用：既有条目的**字段级修正**——如字段错配，agent 手里已有完整条目语义；用户**重新选型**
不在此列——重走「操作流 1」登记新条目，旧名按需走下方「删除」）：

```bash
node .specify/scripts/javascript/datasource-tool.mjs get --name ds01          # 1. 读回当前条目
# 2. 改目标字段（其余字段原样保留——upsert 是整条目替换，不是字段级合并）
node .specify/scripts/javascript/datasource-tool.mjs upsert --entry '<修正后的整条目 json>'
node .specify/scripts/javascript/datasource-tool.mjs validate                  # 3. 复验
```

- **端点变了要一并重建映射**：`map-ensure --real-endpoint <新 host:port>`（旧端点的映射**不要自己
  删**——它由 `map-rebuild` 按引用集收场）
- **端点没变**则不必重跑 `map-ensure`（重跑幂等无害）
- ⚠️ `upsert` 是**整条目替换**：只把要改的字段带上、丢掉其余字段 = 把条目改残。先 `get`，在完整
  条目上改，再整体写回
- **`upsert` 失败分支**：exit 3 → 读 stdout 的 `{"ok":false,"errors":[{target,message}]}` 按字段修；
  exit 5 → 落盘失败（磁盘/权限），报告用户，**不要**改用直接写文件绕过

**删除**（用户明确要移除；极小概率——配置出错的常规纠正路径是「修改」）：

```bash
node .specify/scripts/javascript/datasource-tool.mjs delete --name ds01
```

- exit 4 = 条目不存在（无需处理）；exit 2 = flag 用法错（`delete` 只收 `--name`）
- **删除即终点**：不调 `set-status`（本契约没有）、**不清理映射**——旧端点的映射条目由 `map-rebuild`
  的引用校验自动清（理由：映射以端点为主体，两个数据源可能共用同一 `host:port`，顺手删会误删
  另一个仍在用的数据源的映射）

## 操作流 4：消费——取回环地址写项目配置

要往项目配置里写数据源连接时，**不要**用 `get` 拿到的真实地址（沙箱内不可达），必须取回环地址：

```bash
node .specify/scripts/javascript/datasource-tool.mjs resolve --name ds01
# → {"host":"192.168.0.1","port":"3306","username":"root","password":"123456",
#    "database":"lcap","databaseType":"mysql8","loopbackHost":"127.0.0.1","loopbackPort":30001}
```

- 写进项目配置的地址 = `127.0.0.1:<loopbackPort>`（`loopbackHost` 恒为 `127.0.0.1`）
- 输出是**摊平**的：条目级 `databaseType` 与 `config` 各字段**同层**（不是 `{config:{…}}`）——
  消费方一次调用即拿到可直接拼 JDBC URL 的全量字段
- **每次写都重新 `resolve`，不缓存**：端口漂移时以新值重写覆盖即自愈
- `resolve` **不判**条目是否可用（本契约无状态字段）——条目存在且有映射即返回；拿不到映射时
  exit 4 且首行写明「映射缺失」（见退出码速查）
- 反查 `127.0.0.1:<port>` 是谁：`get` 全表 → 对每条 `resolve` 比对 `loopbackPort`
- **不要在项目配置里写真实地址**，也不要自己拼 `127.0.0.1:<真实端口>`——回环端口由平台分配，
  与真实端口无关

## 常见错误：字段错配与对应修法

判别式联合的判定由工具负责，agent 需要认得**每条诊断指向的修法**：

| 诊断（`validate` 的 `errors[].target` / `message`） | 原因 | 修法 |
|---|---|---|
| `config.schemaName`「**禁多余字段**」 | `mysql8` / `oracle` 条目带了 `schemaName`（属 postgresql / sqlserver） | 删掉该字段；若本意是 PG/SQL Server，则改正 `databaseType` |
| `config.database` + `config.connectionTarget` 同时报错 | 把 Oracle 的连接目标填进了 `database` | Oracle 的连接目标字段是 **`connectionTarget`**，`database` 是**多余字段** |
| `config.connectedMode`「必须为 sid / serviceName 之一」 | 值域错（如 `driverType: "sid"` 之类旧字段名） | 改 `connectedMode` 的值；`driverType` 已废弃，其值改由 `connectedMode` + `connectionTarget` 承载 |
| `config.port`「必须为**字符串**」 | 端口填成了 number（`3306`） | 改成 `"3306"` |
| `config.port`「必须为 1–65535 的十进制整数文本」 | 端口越界 / 非数字 / 带小数点 | 改成合法端口文本（`"1"`–`"65535"`） |
| `config.database`「…不在契约已知形态…内，无法判定其 config 键集；但**连接目标字段必填**（探测键集：`database` / `connectionTarget`…当前均未命中）」（表外类型专用诊断） | `databaseType` 不在四值内（平台新增类型），且 config 里 `database` 与 `connectionTarget` **都没有**（或为空串） | 补一个连接目标字段（表外类型只认这两个键，`schemaName` 不算）——**不要**因此改写 `databaseType` |
| `dataSources[i].dataSourceName`「重复」 | 两条同名 | 二选一合并（同名即整条目替换，保留最后写入的那条） |
| `dataSources[i]`「条目含未知字段」 | 条目级多了字段（如把 `connectedMode` 放在条目外层） | 连接属性一律放 `config` 内 |
| 告警（不翻退出码）：`config.customSetting` / `config.host` | 前导 `&` / host 含冒号 | 剥掉 `&`；端口移到 `port` 字段 |

## 快速参考：子命令一览

| 子命令 | 用途 |
|---|---|
| `validate [--entry <json>] [--require-filled]` | 校验整文件 / 单条目（纯校验不落盘）；`--require-filled` 追加「必填值非空」（不含 `password` / `schemaName`） |
| `upsert --entry <json>` | 按 `dataSourceName` 插入 / 整条目替换（写前自校验） |
| `get [--name <n>]` | 读整表 / 单条目 |
| `delete --name <n>` | 删条目（不清理映射） |
| `resolve --name <n>` | 取条目 + 回环地址（消费 join，**唯一**get 回环地址的入口） |
| `register-prepare --type <t> --slots <slots json>` | **新增编排·前置段**（操作流 1 步骤 1）：⓪ 平台类型门（不支持 = exit 0 + `UNSUPPORTED_TYPE`，不消耗用户交互）+ 组装 `dataSourceSelect` 的 ask 载荷（裸 input，agent 拿去发 question） |
| `register-commit --app <a> (--name <n> \| --answer <answer json>) --type <t>` | **新增编排·提交段**（操作流 1 步骤 3）：解析答案（`--answer` 按 title 对齐逐槽遍历，**同名去重**——多槽可选同一配置；`--name` 显式优先）→ 平台取配置 → 建映射 → 写条目 → 复验 |
