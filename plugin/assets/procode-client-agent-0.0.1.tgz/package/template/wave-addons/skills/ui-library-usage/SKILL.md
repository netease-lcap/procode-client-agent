---
name: ui-library-usage
description: 使用或修改第三方组件库/UI 库及其配套运行时库时的取证顺序 skill。适用于 element-plus、Ant Design（antd / ant-design-vue）、Arco Design、Naive UI、Vant、MUI 等任意组件库，以及 dayjs / moment / date-fns / lodash 一类配套运行时库。触发场景：调用或调整组件属性/事件/插槽、配置 locale 或主题变量、新增或修改依赖声明、库升级后行为变化，以及「这个组件怎么配」「为什么中文/星期没生效」这类问题。核心规则：先查知识库规范，无命中再查官方文档，最后才读 node_modules；禁止一上来就用 Bash `grep` / `rg` 对 node_modules 盲搜。
---

# 第三方组件库用法取证顺序

本 skill **与具体库无关**。下文出现的库名一律只是举例；换 tech stack（Vue/React、EP/antd/arco）后规则不变，变的是每级要查的文档与包名。

## 何时触发

**凡是要改动「组件/库的用法」时先加载本 skill**——包括但不限于：

- 新增或调整组件：属性、事件、插槽、受控值绑定（`v-model` / `value`+`onChange`）、`type` / `format` / `value-format` 等配置项；
- 国际化（locale）与主题：组件库自身文案语言、日期/数字库的 locale、主题色与样式变量覆盖（CSS 变量 / design token / ConfigProvider 主题对象）；
- 新增、升级或移除依赖声明（`package.json`），以及「这个包是不是幽灵依赖」类判断；
- 库升级或换库后行为与预期不符、中文不生效、日期/数字格式不对等**静默失效**现象；
- 从套用某一组件库的写法**迁移到另一个组件库**（如 EP → antd）——两家的默认值、属性名、必填项往往不同，**不能照搬**。

**不适用**：通用编程语言语法与标准库；纯业务代码定位（用代码图谱 / Grep 工具）；与组件无关的工具函数用法。

> 本 skill 只规定**取证顺序与降级路径**；检索本身的调用协议（参数、返回结构、引用标注）见 `knowledge-search` skill，不要在这里重复推演。

## 取证顺序（固定三级，逐级降级）

| 级别 | 手段 | 定位 |
|------|------|------|
| **1** | `QueryKnowledge(action='search')` 查团队/项目知识库 | **必做且最先做**。团队规范、选型约定、已沉淀的踩坑结论都在这里 |
| **2** | 该库的官方文档确认 API 细节与默认值 | 知识库未覆盖时，第二顺位。**认准本仓库实际在用的那个库**——同族库（antd vs ant-design-vue、EP vs EP-Next）文档相近但不等价 |
| **3** | 读 `node_modules` | **最后手段**，仅在下述两种情况才走 |

**升级到第 3 级只有两个正当理由**，其它一律回到第 1/2 级：

1. **文档不足或相互矛盾**，必须验证**实际行为**；
2. 需要确认**安装事实**：版本号、是否存在多副本、依赖是直接依赖还是传递依赖、两个库是否共用同一份底层依赖（如都依赖同一个日期库）。

> ⚠️ **顺序颠倒是最常见的失效模式**。先对 `node_modules` 跑 Bash `grep` / `rg`、后补查规范，即使最后结论正确，也大概率
> 已经浪费了一半动作，而且**结论可能反了**——见下文典型失效模式。
>
> ⚠️ 「**与既有代码保持一致**」**不等于**「**符合团队规范**」：既有代码本身未必合规，文档才是判定基准。
> 拿既有代码当依据去反推规范，是把基准搞错了。

## 第 3 级（node_modules）的成本约束

`node_modules` 是**目录量级最大**的地方（实测某前端工程：顶层 **186** 个包，`-maxdepth 2` 已达 **441** 个目录）。
一旦进入这一级，遵守：

- **禁止**无 `maxdepth` 的**全树 `find`**——代价不可接受；
- **禁止**用 Bash `grep -r` / `rg` 扫描**整个包目录**——先想清楚要找的模块名；文件名不确定时先用 Glob 定位，再取**精确路径**：
  `<pkg>/package.json`、`<pkg>/es/<已知模块>/<file>.mjs`、`<pkg>/locale/<lang>.js`；
  （各库目录布局不同：EP 在 `es/`，部分库在 `dist/`、`lib/`、`components/`——路径不确定时先用窄范围枚举定位）
- **运行期事实优先用 `node -e` 一次性实测**（locale 是否生效、格式实际输出什么），
  其**证据强度高于源码阅读、成本更低**——能实测就不要读源码；
- 路径不确定时，先用**窄范围**枚举定位（如 `find node_modules -maxdepth 3 -path "*/<pkg>/package.json"`），
  再按精确路径读取。

## 停手条件

**同一目的的检索，连续 2 次不产出新线索 → 立即停手改道。**

改道的两个正解：

- 直接跑 `node -e` 实测（往往一步就能定论，且比继续盲搜便宜）；
- 按官方文档的章节结构去定位（如国际化 / 主题 / 迁移指南章节），而不是在构建产物目录下盲搜关键词。

不要用第 3 次、第 4 次换个关键词继续试——连续落空说明**方向错了**，不是**词选错了**。

## 典型失效模式：两层 locale（几乎每个组件库都有）

组件库通常有**两层互相独立**的语言设置，二者**不会互相代劳**：

1. **组件库自身文案**（按钮、分页、日期面板里的「确定/取消/一月」）——靠组件库的 locale 机制，如
   `ElConfigProvider`、antd 的 `ConfigProvider locale={zhCN}`、MUI 的 `ThemeProvider` + `zhCN` 语言包；
2. **底层日期/数字库的 locale**（星期名、月份名、数字分隔符）——靠那个库自己的全局设置，如
   `dayjs.locale()`、`moment.locale()`、`date-fns` 的 `locale` 参数。

**只设了第 1 层、没设第 2 层是典型静默失效**：界面文案中文了，但星期仍是 `Sunday`——**不报错、不崩，只是不对**。

已核实的实例（本项目当前栈）：

- **element-plus + dayjs**：EP 的 `ConfigProvider` **不会**代为设置 dayjs 全局 locale——
  它只做自身文案的 `t()` 翻译（`use-locale` 仅 `buildLocaleContext(locale)` + `translate()`），与 dayjs 全局 locale 无任何耦合。
  故 `main.ts` 里必须**额外显式** `dayjs.locale('zh-cn')`：实测只写 `import 'dayjs/locale/zh-cn'` 输出 `2026-09-20 Sunday`，
  加上 `dayjs.locale('zh-cn')` 才是 `2026-09-20 星期日`。
  **知识库 `element-plus.md` 的 Date and Time Localization 示例只写了 `import`，照抄会静默不达标。**

> **切忌把上面这个结论当成「所有库都这样」**。换栈后（antd、arco、MUI…）两层各自叫什么、是否真的互不代劳、
> 默认值是什么，**必须按三级顺序重新取证**——尤其第 2 级要看**该库自己的**国际化章节。
> 本实例的价值在于揭示**这一类失效的形状**，不在于提供可跨库照搬的结论。

## 本项目当前栈已沉淀结论（element-plus + dayjs）

> 仅在当前栈成立。换库/换版本后作废，需重新取证。

- 组件库中文星期/locale：需在 `main.ts` **显式** `dayjs.locale('zh-cn')`；
  知识库现有示例只写 `import 'dayjs/locale/zh-cn'`，**不足以**让 `dddd` 输出中文。
- 依赖声明：`dayjs` 已作为**直接依赖**显式声明（`^1.11.20`，与 EP 传递依赖一致），
  后续可直接 `import`，**无需再判定幽灵依赖**。
- `el-datetime-picker` **不存在**：datetime 必须用 `<el-date-picker type="datetime">` 实现。
- `type="datetime"` 的 `format` 默认即 `'YYYY-MM-DD HH:mm:ss'`，而 `el-date-picker` 的 `format`
  默认为 `'YYYY-MM-DD'`——需追加星期时必须**显式覆盖** `format`。

## 检索到结论后

在回答里标注知识来源（`（来源：<knowledgeIdentifier>）`），并调用 `ReportKnowledgeUsage` 上报——
用法见 `knowledge-search` skill 的「证据使用与回答规范」。

若结论是**知识库未覆盖**且确有沉淀价值（团队级踩坑、非本项目特有），提示用户可到知识管理页沉淀；
用户无意愿则不追问。
