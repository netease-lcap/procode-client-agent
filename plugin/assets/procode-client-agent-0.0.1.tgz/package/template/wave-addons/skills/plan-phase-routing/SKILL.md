---
name: plan-phase-routing
description: Plan 阶段（对话计划回合）诉求分流 skill。处理用户确认/修订当前计划，或识别换题后的小改动与中等规模需求。小改动 requirement-only handoff 到 build；中等规模留在 Plan 继续规划。触发场景：确认计划、改计划、Plan 中途换题、局部修 bug、新模块规划。
---

# plan-phase-routing

对话 **Plan 阶段**（`activePhase=plan`）中，用户每条**实质诉求**（非寒暄/只读咨询）时，**先加载本 skill** 再行动。**禁止关键词匹配**。

同一任务内加载一次即可。

## 自由阶段的原型只读约束

当 `specPhase=freePhase` 时，原型工程只读，可读取参考。不得规划修改、删除或重新构建原型，也不得用 Bash/脚本或后续任务绕过；切换 Plan、确认计划均不会解锁原型。明确要求改原型时说明阶段限制。

> ⚠️ **组件类改动另有一层取证顺序**：只要规划/改动涉及**第三方组件库/UI 库及其配套运行时库**
> （element-plus、antd、arco、vant、dayjs、lodash…**任意一家**）的**用法**——组件属性/事件/插槽/
> 样式变量、locale 与主题、依赖声明、换库迁移——
> 取证顺序固定为「**知识库规范 → 官方文档 → node_modules**」：先 `QueryKnowledge(action='search')`
> 查团队规范与已沉淀结论；未覆盖再查官方文档；**只有**「文档不足/矛盾需验证实际行为」或
> 「确认版本、副本、依赖声明等安装事实」才读 `node_modules`，且禁止用 Bash `grep -r` / `rg` 整包递归扫描、
> 禁止无 `maxdepth` 的全树 `find`。细则见 `ui-library-usage` skill（知识能力开启时才物化；
> 未看到该 skill 时按本段执行）。

## 与当前计划的关系（优先判断）

| 用户意图（语义） | 动作 |
|-----------------|------|
| **计划首次就绪 / 修订后待确认** | 落盘后**优先**调用 `question`（见下方形态）→ **禁止** `phase_handoff`；禁止只发「请审阅确认」就结束 |
| **确认当前计划**（question 选「确认，按此计划执行」或自然语言确认） | 更新 plan 中 `## 用户确认` → `status: confirmed`（可附 confirmedAt）→ `phase_handoff(targetPhase=build, summary)` → **立即停止** |
| **修订当前计划**（question 选「需要修改计划」或自然语言修订） | 编辑 implementation-plan，保持 `status: pending` → 再次用 `question` 确认 → **禁止** `phase_handoff` |
| **换题 / 新诉求** | 见下方两档分流 |

### 计划确认 question 形态

一次只问这一题，不要把计划全文贴进 question：

- header：`计划确认`
- question：`当前实施计划已就绪，是否按此执行？`
- options：`确认，按此计划执行`（可 `isRecommended`）、`需要修改计划`

自然语言确认仍有效，但计划就绪后应**尽量**先走 `question`。

## 换题两档定义

| 档位 | 含义 | Plan 阶段动作 |
|------|------|---------------|
| **A 小改动** | 局部调整，**不需** implementation-plan，不改变 PRD 边界 | `phase_handoff(targetPhase=build, summary, requirement=<用户原话或摘要>, interruptedSummary=<可选：当前 pending 计划摘要>)` → **立即停止**；**禁止**读入或附带 plan 文件 |
| **B 中等规模** | 需先规划的新能力，仍在现有 PRD 内 | **留在 Plan**；为新话题写/更新 implementation-plan（`status: pending`）；若切换话题可归档或覆盖旧 pending plan 并在对话中说明 |

### 边界判断

- **A vs B**：是否需 implementation-plan、是否跨多模块/需排期 — 是则 B，否则 A
- 与 `free-phase-routing` 语义一致，但 Plan 阶段 **B 不 handoff**，直接在本阶段规划

## 版本级诉求（暂不可用）

用户表达「重跑 specify / 上传新 PRD / 版本迭代 / 产品方向推翻」等**版本级**意图时：

- **禁止**调用 `begin_version_iteration`
- 先评估是否可在**现有 PRD 框架内**以 **B（中等规模）** 交付 → 是则留在 Plan 规划
- 若确实超出当前 PRD 边界：**说明版本迭代能力暂未开放**，引导描述可落地的中等规模改造

## 决策表

| 用户意图（语义） | 档位 / 类型 | 下一步 |
|-----------------|-------------|--------|
| 计划首次就绪 / 修订后待确认 | 待确认 | 调用 `question`，禁止 handoff |
| OK / 可以执行 / 确认计划 / question 选「确认…」 | 确认 | 改 marker → `phase_handoff(build)` |
| 第 3 节改成… / 计划里加上… / question 选「需要修改计划」 | 修订 | 改 plan，保持 pending，再次 `question` |
| 局部修 bug、改 UI/配置（换题） | A | `phase_handoff(build, requirement=…)` 不带 plan |
| 新模块、多文件联动（换题） | B | 留在 Plan，写/更新 plan |
| 版本级变更、上传新 PRD | 评估 B 或告知暂未开放 | 见上 |
| 寒暄、问技术栈、只读排查 | — | 直接回复 |

## 示例

| 用户说 / 行为 | 类型 |
|--------------|------|
| 计划落盘后调用 question | 待确认 → 禁止 handoff |
| 「可以，按这个计划做」/ 选「确认，按此计划执行」 | 确认 → handoff build |
| 「把验证步骤改成跑 e2e」/ 选「需要修改计划」 | 修订 → pending，再次 question |
| 「顺便把登录按钮改蓝色」（与当前 plan 无关） | A → requirement handoff |
| 「另外做一个导出 Excel，涉及前后端」（换题） | B → 留 Plan |
| 「你好」 | — |

## 计划文档要求

implementation-plan 须含：

```markdown
## 用户确认
- status: pending
```

确认后改为 `status: confirmed`。**仅 confirmed 时**允许无 `requirement` 的 `phase_handoff(build)`；编排会读 plan 并归档到 `.data/freeplan/{sessionId}/archive/`。
