---
name: middleware-contract
description: 中间件配置契约操作 skill。按新增/修改/删除/查询四场景闭环编排 middlewares-tool.mjs 与兄弟工具 uds-mapping-tool.mjs 的命令调用链路，agent 不得绕过工具直接修改契约文件（.manifest/middlewares.json、.manifest/uds-mappings.json）。触发场景：沙箱工作空间内新增/修改/删除/查询中间件配置。
---

# 中间件配置操作手册

> 维护者注：本文为双副本——契约侧源 `config/shared/manifest/middleware/knowledge.md` 与模板侧 skill
> `template/wave-addons/skills/middleware-contract/SKILL.md` 内容逐字一致，修改必须双改（一致性测试钉死）；
> 工具开发细节见契约侧目录 `config/shared/manifest/middleware/README.md`，不随沙箱分发。

本文是 AI 对话 agent 在沙箱工作空间内配置中间件的**自包含操作手册**——新增 / 修改 / 删除 / 查询四个场景的
完整流程与调用链路，操作语义不依赖任何外部文档。两份落盘文件 `.manifest/middlewares.json`（配置意图）与
`.manifest/uds-mappings.json`（端口映射缓存）一律只经工具读写（铁律见下节）。

- 命令统一形态：配置族 `node .specify/scripts/javascript/middlewares-tool.mjs <子命令> [参数]`；
  映射族（建通道 / 读映射 / 重建）走兄弟契约产物 `node .specify/scripts/javascript/uds-mapping-tool.mjs
  <子命令> [参数]`（同目录分发）。成败判定以**退出码**为准
- **落点固定 `$HOME/resources/.manifest/`**：工具不跟 cwd 走。OpenCode 在 worktree checkout 时 cwd
  不是 resources，仍读写沙箱那一份。HOME 未设置则 exit 2，**禁止**回退 cwd
- 配置值不经臆测：条目以 status=init 落盘后，一律经动态表单向用户收集确认（表单形态与取消判定见场景 1）；
  提交失败带 askError 标红重问

## 铁律：禁止绕过工具直改文件

`middlewares.json` 与 `uds-mappings.json` **只经工具子命令读写，禁止直接编辑文件**（含重定向写 /
编辑器改写 / 脚本拼 JSON 落盘）。直改的五重危害：

1. **撕裂写与权限失控**——工具全部写入为原子操作且权限统一收紧（文件含密码等明文
   敏感字段）；手写非原子（会读到半截文件）且权限不可控
2. **坏条目瘫痪全部读路径**——list 里一条 null / 非对象条目即令 get / validate / upsert / delete /
   set-status 全部 exit 3（损坏 ≠ 未找到），一处手误整表不可读
3. **状态机旁路**——upsert 仅收 init、set-status 仅收 ok|failed 等机器守卫全部失效，status 被写成
   非法流转后下游失败分派口径全乱
4. **映射与真实通道失同步**——每条映射记录背后必须有一条 sbx-outbound 真实通道；手改映射 = 记录在
   而通道不在，消费地址必死
5. **漏建通道断消费链**——消费侧按映射的 loopbackPort 拼 `127.0.0.1:<port>` 写项目配置；不经
   `uds-mapping-tool map-ensure` 建通道则 `uds-mapping-tool get` 未命中（exit 4），配置了却连不上

## 契约结构（最小必要面）

顶层：`{ schemaVersion: 1, list: Middleware[] }`（schemaVersion 恒 1，工具守卫）。

### 条目字段

| 字段 | 说明 |
|---|---|
| `name` | 条目唯一名（多实例用 redis-session / redis-01 区分）；list 内唯一，**同名 upsert 即更新**——写前先 `get --name` 查重，防误覆盖 |
| `middleware` | 类型，填**真实类型名**（如 kafka / rabbitmq，任意字符串合法、无白名单）；预置模板仅 redis / s3，其余类型 endpoint 用 `generic` 通用端点族（targets 形态）、properties 自主拼装 |
| `status` | 三态：`init`（待确认）/ `ok`（提交通过）/ `failed`（不可恢复失败）；**agent 拼条目只写 init**，ok / failed 只经 `set-status` 置位 |
| `endpoint` | 固定约束端点，四族按 `kind` 判别（下表） |
| `properties` | 固定约束之外的动态配置项数组（下节） |
| `lastError` | failed 必填非空；`set-status --status ok` 时自动删除 |
| `askError` | `[{target, message}]`——提交失败标红的**持久层唯一载体**（**唯一例外：结构类错误无载体**——upsert 复用同一份结构校验、含结构类错误的条目写不进持久层，此时 askError 不落盘、仅作本轮**内存**重问基准；见「统一失败分派」结构类条款），出现于用户可修失败后待重问的条目；target = 字段路径（如 `endpoint.host` / `endpoint.nodes[0].host` / `properties.password`）；随 upsert 整条目写入，成功提交清空、取消保留 |

### endpoint 四族

| kind | 形态与必填 | 端口缺省 |
|---|---|---|
| `host-port` | `{host, port?, scheme?}`（redis 单机）；host **提交时必填**（init 中间态可留空 = 待填）；scheme 可选承载协议（http / https / es 等任意合法 scheme）——**host 落盘恒裸值，带协议前缀的 host 写入侧自动剥离为 host+scheme**（如 `https://es.example.com` → host=`es.example.com` + scheme=`https`） | redis 6379 |
| `node-list` | `{role: sentinel\|cluster, masterName?, nodes: HostPort[]}`；role + nodes ≥1 为**构造合法性**（无条件判、空数组即拒）；sentinel 的 masterName 与各节点 host **提交时必填**（init 中间态可留空 = 待填）；**节点不使用 scheme**、节点 host 带协议前缀一律拒绝（validate exit 3） | sentinel 26379 / cluster 6379 |
| `url` | `{endPoint, bucketName, pathStyleAccess, mapped?}`（S3）；endPoint + bucketName **提交时必填**（init 中间态可留空 = 待填），pathStyleAccess 恒必填（boolean 类型闸、无待填态）；endPoint 为完整 URL 自带协议头、**无 scheme 字段** | 按 URL scheme（http 80 / https 443） |
| `generic` | `{targets: HostPort[]}`（kafka / rabbitmq 等未预置）；targets 必须为数组且**可为空**（构造合法性——纯 HTTP 中间件：不建通道、消费时原样写）；targets[i].host **提交时必填**（init 中间态可留空 = 待填）；targets[i].scheme 语义同 host-port | 按 middleware 查默认端口表 |

- **「待填」语义（init 中间态）**：端点必填项（host / masterName / nodes[i].host / endPoint / bucketName /
  targets[i].host）在**默认 validate 不判**（与 properties 的 required 同口径），提交前由
  `validate --require-filled` 把关。**待填构造形**：字符串字段用**空串**（`host: ""` / `endPoint: ""` /
  `bucketName: ""` / `masterName: ""`）；node-list 用 `nodes: [{host: ""}]`（**勿用 `nodes: []`**——nodes ≥1 是
  构造合法性门、空数组直接拒，且表单渲染不出节点字段）；`port` 用**省略键**（勿写 `null`——键存在即须 number）。
  构造合法性（kind / role / nodes 非空 / pathStyleAccess 类型 / scheme 格式 / 节点带协议前缀 / 未知类型必须
  显式端口）**不受待填放宽**、默认模式即拒
- `url` 族 `mapped`：`false`（默认）公网直连；`true` = 自建 MinIO 等 ip+port 内网方式、经端口映射——
  agent 按项目证据判定，缺省 false。endPoint 为内网地址（localhost / 127. / 10. / 192.168. / 172.16-31.）
  且 mapped≠true 时 validate 产**告警**（不翻 exit code，防漏判内网 S3）。告警时复核 mapped 判定（向用户确认是否内网自建存储）
- 默认端口表七项：redis 6379 / sentinel 26379 / cluster 6379 / http 80 / https 443 / kafka 9092 /
  rabbitmq 5672；**未知类型必须显式端口**（validate exit 3 兜底）
- scheme 规则：格式 `^[a-z][a-z0-9+.-]*$`（非空；空串走「不落盘」而非格式非法），任意合法 scheme 均收、不列白名单（格式非法
  validate exit 3）；scheme 空串不落盘；host 含 `://` 但格式非法（灰区，如大写 `HTTP://`，仅 host-port/generic；
  node-list 含 `://` 一律拒绝）→ validate 告警、按原样落盘（后续建通道 / 连通校验失败按统一失败分派处置）
- **host 冒号规则**（**结构类**错误，端口请填 port 字段）：host-port / generic 的 host 与 node-list 节点 host 含冒号
  （`host:port` 形态）→ validate exit 3「host 不应包含端口，请把端口填到端口字段」；带协议前缀的 host 剥离后**余项**含冒号
  同样 exit 3（余项即落盘值，放行会留下「写入侧合法、复验侧非法」）；**前述灰区不适用本规则**（含 `://` 但格式非法仍只告警）。
  **已知限制**：IPv6 暂不特判——`::1` / `[::1]` 会被按「含端口」拒绝（见「已知限制」节）

### properties 动态配置项

每项 = 表单 schema + 值。公共字段：`key`（如 username / password / database；**条目内唯一**，答案按
key 回传）/ `name`（显示名）/ `required` / `order`（内部排序字段）/ `lineRegion`（whole | half）/
`value`（null = 未填；迭代回显与存量预填的载体）。两形态：

- `CommonKeyValue`：`inputType ∈ text | textarea | number | password`
- `SelectKeyValue`：`inputType='select'` + `selectValues: [{name, value}]`（不用多选）

次要细则（一句带过）：`updatedAt` 由工具自动盖戳、勿填；`order` 固定区 1..N 归 endpoint 展开项、动态区
在固定区 N 之后续编（generic 条目 N=3×targets 数；targets≥4 且动态区沿用 ≥10 惯例编号时渲染序可能与动态区交错——纯显示序问题，
不影响落盘与校验）；`defaultValue` 仅 value=null 时预填展示（未改按预填值提交）；`regex` /
`validateMessage` / `placeholder` 可选；`error` 仅 ask 线表单视图字段（由 askError 按 target 映射填充，
不落盘、答案不回传）；uds-mappings.json 条目为 `{realEndpoint, loopbackPort, direct?, stale?}`——
direct / stale 为诊断标记，查询场景只用 loopbackPort 与 stale。

### JSON 样例

四族 + 三态 + askError / lastError 形态：

```json
{
  "schemaVersion": 1,
  "list": [
    {
      "name": "redis-cache",
      "middleware": "redis",
      "status": "ok",
      "endpoint": { "kind": "host-port", "host": "redis.example.com", "port": 6379 },
      "properties": [
        { "key": "database", "name": "数据库编号", "required": false, "order": 10, "lineRegion": "half",
          "inputType": "number", "value": 0, "defaultValue": 0 },
        { "key": "password", "name": "密码", "required": false, "order": 11, "lineRegion": "whole",
          "inputType": "password", "value": null, "placeholder": "留空表示无密码" }
      ],
      "updatedAt": "2026-09-08T09:30:00.000Z"
    },
    {
      "name": "redis-session",
      "middleware": "redis",
      "status": "init",
      "endpoint": {
        "kind": "node-list", "role": "sentinel", "masterName": "mymaster",
        "nodes": [
          { "host": "redis-sentinel-1.db.internal", "port": 26379 },
          { "host": "redis-sentinel-2.db.internal", "port": 26379 }
        ]
      },
      "properties": [
        { "key": "password", "name": "密码", "required": false, "order": 10, "lineRegion": "whole",
          "inputType": "password", "value": null, "placeholder": "留空表示无密码" }
      ],
      "updatedAt": "2026-09-08T09:40:00.000Z"
    },
    {
      "name": "s3-storage",
      "middleware": "s3",
      "status": "ok",
      "endpoint": { "kind": "url", "endPoint": "https://oss.example.com", "bucketName": "app-bucket",
                    "pathStyleAccess": true, "mapped": false },
      "properties": [
        { "key": "accessKey", "name": "Access Key", "required": true, "order": 10, "lineRegion": "half",
          "inputType": "text", "value": "AKIAIOSFODNN7EXAMPLE" },
        { "key": "accessSecret", "name": "Secret Key", "required": true, "order": 11, "lineRegion": "half",
          "inputType": "password", "value": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY" }
      ],
      "updatedAt": "2026-09-08T09:50:00.000Z"
    },
    {
      "name": "kafka-broker",
      "middleware": "kafka",
      "status": "failed",
      "endpoint": {
        "kind": "generic",
        "targets": [
          { "host": "kafka-1.internal", "port": 9092, "scheme": "http" },
          { "host": "kafka-2.internal", "port": 9092 }
        ]
      },
      "properties": [
        { "key": "compression", "name": "压缩方式", "required": false, "order": 10, "lineRegion": "whole",
          "inputType": "select", "value": "snappy",
          "selectValues": [ { "name": "无压缩", "value": "none" }, { "name": "snappy", "value": "snappy" } ] },
        { "key": "timeout", "name": "连接超时（毫秒）", "required": false, "order": 11, "lineRegion": "half",
          "inputType": "number", "value": null, "defaultValue": 5000 }
      ],
      "lastError": "sbx-outbound add 失败（exit 9：proxy 内部异常），请携带该错误信息联系平台",
      "askError": [
        { "target": "endpoint.targets[0].host", "message": "kafka-1.internal 不可达，请确认主机名与端口后重试" }
      ],
      "updatedAt": "2026-09-08T10:00:00.000Z"
    }
  ]
}
```

（askError 为上一轮标红重问残留——仅成功提交清空；`error` 视图字段仅表单线、不落盘，故样例 properties 不含；
scheme 可选、缺省即无协议——带协议前缀的 host 写入侧自动剥离为 host+scheme，样例 targets[0] 即剥离后落盘形态。）

## 场景 1：新增中间件

**拼装依据（表驱动）**：

| 类型 | endpoint | 预置 properties 模板 |
|---|---|---|
| Redis 单机 | host-port | password（required=false，留空=无密码） |
| Redis Sentinel | node-list（sentinel） | 同上 |
| Redis Cluster | node-list（cluster） | 同上 |
| S3 | url | accessKey + accessSecret（均 required=true） |
| 其它（kafka / rabbitmq / …） | generic | **无预置**，agent 全自主拼装 |

properties 动态追加两道门槛：① 不填即行为差异的项 → 必追加 required=true；② 可省略项默认不追加，但
**存量项目实际填了该键** → 提取并询问（required=false + value 预填）。

> **消费模式说明**：走平台 workflow（初始化 / 设计轮）时，表单确认与 #4~#7 的闭包后半段
> （validate 填值 / map-ensure 建通道 / set-status）由基座提交循环统一承载，你只做 #1~#2
> （拼条目 + upsert init）；本手册的完整步骤链面向无固定流程条款的自主操作场景。

步骤链（每步：做什么 → 命令形态 → 失败分支）：

| # | 做什么 | 命令形态 | 失败分支 → 下一步 |
|---|---|---|---|
| 1 | 按表驱动拼条目，**status=init**；存量项目已有配置提取预填 value；required 项 value 可为 null、**端点必填项可为空串**（待填语义，默认校验不判——构造形见「endpoint 四族」节） | —（纯拼装） | — |
| 2 | 落盘 | `upsert --entry '<条目 json>'` | exit 3 → 读 stdout `{"ok":false,"errors":[{target,message}]}`，按错误修正重拼回 #1（**拼装错误在此拦回 agent 自己的修复循环**，勿带到用户侧） |
| 3 | 表单确认（形态与取消判定见下） | 向用户发动态表单 | 用户取消 → **不调任何工具**（含 set-status），条目保持 init、askError 保留 |
| 4 | 答案回填重组条目 → 值填答校验 | `validate --entry '<重组条目 json>' --require-filled` | exit 3 → 写 askError 标红重问（统一失败分派）。**值类 vs 结构类**（分界 = upsert 收不收）：**值类**（端点或 properties 的 required 未填 / regex 不符、答案字段级非法）能落 askError 载体；**结构类**（scheme 格式不符 / endPoint 无法 URL 解析 / **host 含端口**或剥离协议前缀后为空 / node-list 节点带协议前缀或显式 scheme 键 / 未知类型端口不可推断）过不了 upsert 的共享结构校验 → **无持久层载体**、只作本轮内存重问基准 |
| 5 | 填值落盘（重组条目不含 askError = 成功提交清空） | `upsert --entry '<重组条目 json>'` | 非预期退出 → failed + 联系平台（统一失败分派） |
| 6 | 建通道 / 连通校验（按族分派见下） | `node .specify/scripts/javascript/uds-mapping-tool.mjs map-ensure --real-endpoint <host:port>`（兄弟契约产物）；url 族 mapped=false 直调 `sbx-outbound check -r <host>:<port>` | 统一失败分派 |
| 7 | 全通过置终态 | `set-status --name <n> --status ok` | 非预期退出 → failed + 联系平台 |

**表单形态（form kind）与答案解析**：

- question 的 `options` 传 `[]`，`input = { kind: 'form', formItems: [...] }`；基础文案
  `请填写中间件 <name> 的配置`，重问轮在文案后拼接「上次提交失败：- <message 列表>」
- endpoint 按族展开为表单项：host / port / scheme、masterName + nodes[i].host/port、endPoint /
  bucketName / pathStyleAccess / mapped、targets[i].host/port/scheme；协议（scheme）为 select 三态
  （无 / http / https、默认无、回显 endpoint.scheme ?? '' / targets[i].scheme ?? ''、与 port 同行
  half/half）——node-list / url 无协议项；布尔字段（pathStyleAccess / mapped）展开为 select 两项
  （是/否，value 为字符串 `'true'` / `'false'`）；properties 原样追加；下发前按 order 升序排列后
  剥离 order
- 展开项 required 按族固定：host / nodes[i].host / endPoint / bucketName / pathStyleAccess = true；
  port 类 = false（defaultValue 预填默认端口，未知类型无预填、须显式填）；masterName role 感知
  （sentinel=true / cluster=false）；mapped / targets 项 = false；scheme 恒非必填（缺省 = 无协议）。
  表单 required = **用户提交时必填**，与端点的「待填语义（init 中间态可留空落盘）」不冲突（表单把关的是提交、
  落盘放宽的是中间态）
- host 类展开项（host-port 的 host / node-list 的 nodes[i].host / generic 的 targets[i].host）带输入提示
  「只填主机名或 IP，端口请填端口字段」；url 族 endPoint 提示给含端口示例（URL 端口属自身语法、与 host 类相反）。
  提示只是引导，不替代校验——连端口填进 host 仍由 validate 按**结构类**拒（见「endpoint 四族」host 冒号规则）
- 答案为两级 JSON：外层 answer-map（key = 当轮 question 全文）→ 内层 `{values: Record<key,
  string|number|null>}`；按 key 匹配回填（endpoint 展开键回填 endpoint 字段、properties 按 key 填
  value），答案不含 schema 字段、未知 key 忽略，schema 一律从落盘条目取
- 协议归一化兜底：host 答案带协议前缀（如 `https://es.example.com`）→ 回填时自动剥离为裸值 host +
  scheme（协议部分覆盖下拉选择值）；scheme 答案空串 = 未选择协议、重组条目不含 scheme 键（改选「无」
  即显式清除原有 scheme）；scheme 键缺席 / null → 保留旧值（与「清除」区分）；node-list 节点带前缀不做归一化、validate exit 3 标红重问
- 取消判定：外层空对象（含超时兜底 `'{}'`）/ 无 values / values 空对象；**密码空串 = 无密码，合法值
  不判取消**
- 布尔回填仅接受 `'true'` / `'false'`；数字仅接受数字（空串 / NaN 非法）——非法值 = 字段级失败，
  保留旧值走标红重问（不置 failed）

**建通道分派（#6 按族）**：

- `host-port`：单端点 `uds-mapping-tool map-ensure` 一次
- `node-list`：逐节点 `uds-mapping-tool map-ensure`
- `generic`：逐 targets 项 `uds-mapping-tool map-ensure`；targets 为空 → 跳过（纯 HTTP 中间件）
- `url`：`mapped=false` → 不建通道，直调 `sbx-outbound check -r <host>:<port>` 连通校验；
  `mapped=true` → 按 URL 的 host:port（显式端口或 scheme 默认）`uds-mapping-tool map-ensure` 一次
- 端口取值：显式端口直用，缺省按默认端口表补齐；**未知类型缺端口无法推断 → 字段级失败**（target
  指向 port 字段，标红重问）；带协议前缀的 host 归一化剥离后以裸值进 `uds-mapping-tool map-ensure`
  （`--real-endpoint` 恒为裸 host:port）

**统一失败分派（场景 1 / 2 提交循环内通用）**：

- **用户可修 → askError 标红重问，无轮次上限（用户取消即界）**。触发：map-ensure / check 的
  sbx-outbound 原始退出码 **1**（目标不可达）；`validate --require-filled` exit 3（required 未填 /
  regex 不符 / scheme 格式不符 / **host 含端口** / node-list 节点带协议前缀或显式 scheme 键，target 指向对应字段）；
  答案字段级非法（布尔 / 数字）；端口缺省不可推断。处置：拼 askError（target 指向失败字段 +
  message）→ `upsert --entry`（**askError 载体 = upsert 整条目替换**）→ 带上一轮 value + 错误信息
  重新发 #3 表单 → 回 #4
- **结构类错误的特例（无持久层载体）**：上条 `validate --require-filled` exit 3 中，**结构类**错误
  （scheme 格式不符 / endPoint 无法 URL 解析 / **host 含端口** / host 剥离协议前缀后为空 / node-list 节点带协议
  前缀或显式 scheme 键 / 未知类型端口不可推断）同时也过不了 upsert 的共享结构校验——**askError 写不进持久层**。此时**跳过落盘**、askError 仅作**本轮内存重问基准**
  （带 `marked` 条目进 #3 → #4），**不置 failed**（误判平台侧失败会让整轮编排崩溃）。**错误信息不丢**——
  重问轮 question 文案照常携带错误列表，用户可见、改完即继续。值类错误仍走上面的完整持久化重问
  （askError 落盘、可跨进程续跑）；**取消语义两条路径一致**（不调任何工具）——结构类路径下条目保持上次落盘态、
  无 askError 残留。**代价**：结构类重问期间进程重启则本轮上下文丢失、从头再来（无持久残留、无损失，严格优于崩溃）
- **非用户可修 → `set-status --name <n> --status failed --last-error '<错误信息>'` + 告知用户联系
  平台，不重问**。触发：sbx-outbound 码 **2 / 3 / 9**（参数非法 / loopback 不可连 / proxy 异常）；
  check 非 0/1；validate / upsert / set-status / map-ensure 异常退出（exit 5 写失败等非预期退出码；exit 2 见下条）；答案结构性损坏
  （两级 parse 失败）
- map-ensure exit 1 的分派依据：stderr **首行纯数字 = sbx-outbound 原始退出码**（1 → 标红重问；
  2/3/9 → failed）；首行非纯数字（spawn 级失败）→ 按未知兜底 = failed + 联系平台
- 任一步骤 exit 2（参数非法：未知 flag / 越权组合 / 缺值 / `--entry` 非 JSON）= 命令行拼装错误，
  修正后重调，不置 failed

## 场景 2：修改中间件

适用：改地址 / 端口 / 密码、补配置项等（条目已存在，任意状态）。

| # | 做什么 | 命令形态 | 失败分支 → 下一步 |
|---|---|---|---|
| 1 | 读回当前条目 | `get --name <n>` | exit 4 不存在 → 走场景 1 新增；exit 3 损坏 → 联系平台 |
| 2 | 改目标字段 + **status 重写为 init**（upsert 只收 init、set-status 不收 init——**回 init 唯一路径 = upsert 重拼**）；建议剥离 lastError / askError 残留（防上一轮错误误导本轮表单） | —（纯拼装） | — |
| 3 | 落盘 | `upsert --entry '<条目 json>'` | exit 3 → 按错误修正重拼 |
| 4 | 新值需用户确认 → 回场景 1 #3 起走表单循环；无需确认 → **仍须跑值填答校验兜底** | `validate --entry '<条目 json>' --require-filled` | 同场景 1 统一失败分派 |
| 5 | 建通道：endpoint 变了 → 对新 realEndpoint 走场景 1 #6 同规则；endpoint 未变 → 可不跑（重跑幂等无害）；**旧地址的映射条目成孤儿不清理**（沙箱重建钩子自动清） | `node .specify/scripts/javascript/uds-mapping-tool.mjs map-ensure --real-endpoint <host:port>` | 同场景 1 统一失败分派 |
| 6 | 置终态 | `set-status --name <n> --status ok` | 非预期退出 → failed + 联系平台 |

## 场景 3：删除中间件

适用：用户明确要移除某中间件配置（极小几率——配置出错的常规纠正路径是场景 2 修改，慎走删除）。

| # | 做什么 | 命令形态 | 失败分支 → 下一步 |
|---|---|---|---|
| 1 | 删条目——**delete 成功即闭环终点** | `delete --name <n>` | exit 4 = 不存在（幂等语义，无需处理）；exit 2 = flag 越权（delete 只收 --name，修正命令行重调） |

不调 set-status（删除即移除，无终态可置）、不清理映射、不调 `uds-mapping-tool map-rebuild`——旧 realEndpoint 的映射
条目由沙箱重建钩子的引用校验自动清，agent 无需代办。

## 场景 4：查询与消费

适用：用户问「配了哪些中间件」「redis 地址是什么」「项目配置里这个 127.0.0.1:40001 是谁」，以及写
项目配置文件时取中间件地址。

| # | 做什么 | 命令形态 | 失败分支 → 下一步 |
|---|---|---|---|
| 1 | 读整表 / 单条目（文件缺失按空表处理：新工作空间 `get` 返回空 list，非错误） | `get` / `get --name <n>` | exit 3 = 文件损坏（**损坏 ≠ 未找到**，联系平台）；exit 4 = 条目不存在 |
| 2 | 按需呈现给用户（建议见下） | — | — |
| 3 | 写项目配置文件时换算消费地址（规则见下） | `node .specify/scripts/javascript/uds-mapping-tool.mjs get --real-endpoint <host:port>` | exit 3 = 映射文件损坏（损坏 ≠ 未找到，联系平台）；exit 4 未命中 → **先走场景 1 #6 建通道（map-ensure）再取** |

- **原始配置即真实地址**：get 读回的 endpoint 字段就是原始真实地址（`redis.example.com:6379` 等），
  呈现与核对**无需任何转换**——`127.0.0.1:<port>` 是沙箱内部消费形态，仅 #3 写项目配置时才需要 join
- **消费 join / 反查仅面向 `status=ok` 条目**：init（待确认 / 待填）与 failed（不可恢复）条目**不参与**——地址
  尚未确认或已判死，写进项目配置必连不上；先按场景 1 把条目推到 ok，再进 join / 反查
- 反查 `127.0.0.1:<port>`（无反向子命令）：`get` 全表 → 按四族算出各条目 realEndpoint（端口缺省按
  默认端口表补齐）→ 逐个 `uds-mapping-tool get` 比对 loopbackPort
- 消费 join 规则（写项目配置文件时）：host-port 单端点 / node-list 逐节点（masterName 原样透传）/
  generic 逐 targets 项 join `127.0.0.1:<loopbackPort>`（targets 为空则原始配置原样写）；url 族
  mapped=false 直接用原始 endPoint（公网直连）、mapped=true 将 URL 的 host:port 替换为
  `127.0.0.1:<loopbackPort>`（scheme / 路径 / query 不变）；**每次写都重新 `uds-mapping-tool get` 不缓存**（端口
  漂移时以新值重写覆盖自愈）
- host-port / generic 的 scheme 字段**不参与地址拼装**——写项目配置需协议头时（如 ES 的 `http://`
  前缀）按条目 scheme 字段取用（缺省即无协议）
- 呈现建议：password / accessSecret 等敏感值打码回显；映射条目带 `stale: true` 时标注「端口可能已
  失效（待下轮重建）」；url 族 mapped=false 注明「公网直连」

## 快速参考：子命令一览

命令名速查（分派细节见各场景步骤链）：

| 子命令 | 用途 |
|---|---|
| `validate [--entry <json>] [--require-filled]` | 校验整文件 / 单条目（纯校验不落盘，含 scheme 格式与 node-list 带前缀拒绝）；`--require-filled` = 提交前值填答校验 |
| `upsert --entry <json>` | 按 name 插入 / 整条目替换（**仅收 status=init**） |
| `delete --name <n>` | 删条目 |
| `set-status --name <n> --status <ok\|failed> [--last-error <e>]` | 终态置位唯一入口（置 failed 必带 `--last-error`） |
| `get [--name <n>]` | 读整表 / 单条目 |

映射族（建通道 / 读映射 / 重建）已移交 `uds-mapping` 契约——命令见
`node .specify/scripts/javascript/uds-mapping-tool.mjs`（`map-ensure` / `get --real-endpoint` /
`map-rebuild`），本表只列 `middlewares-tool.mjs` 的子命令。

## 已知限制

- **IPv6 地址暂不特判**：host 冒号规则按「含冒号 = 含端口」判定，故 `::1` / `[::1]` 等 IPv6 字面量会被
  validate exit 3「host 不应包含端口」拒绝。确有 IPv6 中间件需求时**先告知用户该限制**——host 类字段的任何
  IPv6 写法都过不了校验；换别的族装（如用 url 族 endPoint 塞 IPv6）属**族滥用、语义必错**，禁止。
