/**
 * Validator
 * ─────────────────────────────────────────────────────────────
 * 校验 agent 提取的 ExtractedApiInfo JSON 是否合法，并归一化字段。
 *
 * 设计原则：
 *   - 严格校验：缺失必填字段、未知 type、未知 method 立即报错
 *   - 自动修复：HTTP method 大写、type 首字母规整、domain 自动补 http://
 *   - 不发起任何网络请求（纯本地）
 *
 * 暴露：
 *   - validateApi(raw, idxLabel) → { errors, warnings, normalized }
 */

/** 合法 HTTP 方法 */
const VALID_METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS'];

/**
 * 已知基础类型（大小写不敏感，校验时自动规整为首字母大写形式）。
 * 其他类型一律视为自定义对象类型 → 必须提供 children。
 */
const PRIMITIVE_TYPES = new Set([
  'string', 'integer', 'int', 'long', 'short',
  'boolean', 'bool',
  'float', 'double', 'number', 'decimal',
  'date', 'datetime', 'time', 'timestamp',
  'byte', 'char', 'object',
]);

/** 集合类型识别（List<...> / Array / Set / Collection） */
const COLLECTION_RE = /^(list|array|set|collection)(\s*<\s*(.+?)\s*>)?$/i;

/**
 * 把单个 ExtractedApiInfo 校验并归一化
 * @param {*}       raw       原始 JSON 对象
 * @param {string}  idxLabel  错误信息中用作前缀，如 '0'、'api'
 * @returns {{ errors:string[], warnings:string[], normalized:Object }}
 */
export function validateApi(raw, idxLabel) {
  const errors = [];
  const warnings = [];

  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    errors.push(`[${idxLabel}] 必须是对象，收到 ${typeof raw}`);
    return { errors, warnings, normalized: {} };
  }
  const o = raw;

  // ── 必填字段 ──────────────────────────────────────────────
  const uri = typeof o.uri === 'string' ? o.uri.trim() : '';
  if (!uri) errors.push(`[${idxLabel}] 缺少 uri`);
  else if (!uri.startsWith('/')) {
    warnings.push(`[${idxLabel}] uri 不以 / 开头，已自动补全`);
  }

  // requestMethod：大小写不敏感，统一规整为大写
  const rawMethod = typeof o.requestMethod === 'string' ? o.requestMethod.trim().toUpperCase() : '';
  if (!rawMethod) {
    errors.push(`[${idxLabel}] 缺少 requestMethod`);
  } else if (!VALID_METHODS.includes(rawMethod)) {
    errors.push(`[${idxLabel}] requestMethod 不合法: "${o.requestMethod}"，合法值: ${VALID_METHODS.join(', ')}`);
  }

  // domain：允许为 null（统一在外层从 list 中取一个公共 domain），但若提供必须是合法 URL 形式
  let domain = null;
  if (typeof o.domain === 'string' && o.domain.trim()) {
    domain = normalizeDomain(o.domain.trim(), warnings, idxLabel);
  } else if (o.domain !== null && o.domain !== undefined) {
    errors.push(`[${idxLabel}] domain 必须是字符串或 null`);
  }

  // ── 可选字符串字段 ────────────────────────────────────────
  const apiName = typeof o.apiName === 'string' ? o.apiName.trim() : null;
  const description = typeof o.description === 'string' ? o.description.trim() : null;

  // ── 五组参数 ──────────────────────────────────────────────
  const headerParams  = validateParamArray(o.headerParams,  `${idxLabel}.headerParams`,  errors, warnings);
  const queryParams   = validateParamArray(o.queryParams,   `${idxLabel}.queryParams`,   errors, warnings);
  const pathParams    = validateParamArray(o.pathParams,    `${idxLabel}.pathParams`,    errors, warnings);
  const requestBody   = validateParamArray(o.requestBody,   `${idxLabel}.requestBody`,   errors, warnings);
  const responseBody  = validateParamArray(o.responseBody,  `${idxLabel}.responseBody`,  errors, warnings);

  // 路径参数和 uri 中的 {xxx} 占位符做交叉校验
  if (uri) {
    const placeholders = Array.from(uri.matchAll(/\{([^}]+)\}/g)).map((m) => m[1]);
    for (const ph of placeholders) {
      if (!pathParams.find((p) => p.paramName === ph)) {
        warnings.push(`[${idxLabel}] uri 中包含 {${ph}}，但 pathParams 未声明同名参数`);
      }
    }
    for (const p of pathParams) {
      if (!placeholders.includes(p.paramName)) {
        warnings.push(`[${idxLabel}] pathParams 含 ${p.paramName}，但 uri 中无 {${p.paramName}} 占位符`);
      }
    }
  }

  const normalized = {
    apiName,
    uri: uri ? (uri.startsWith('/') ? uri : `/${uri}`) : null,
    requestMethod: rawMethod || null,
    description,
    domain,
    headerParams,
    queryParams,
    pathParams,
    requestBody,
    responseBody,
  };

  return { errors, warnings, normalized };
}

/** 校验参数数组，返回归一化结果 */
function validateParamArray(raw, pathLabel, errors, warnings) {
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) {
    errors.push(`[${pathLabel}] 必须是数组，收到 ${typeof raw}`);
    return [];
  }
  return raw.map((item, i) => validateParam(item, `${pathLabel}[${i}]`, errors, warnings));
}

/** 校验单个参数（递归处理 children） */
function validateParam(raw, pathLabel, errors, warnings) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    errors.push(`[${pathLabel}] 必须是对象`);
    return { paramName: '', description: null, required: false, type: null };
  }
  const o = raw;

  const paramName = typeof o.paramName === 'string' ? o.paramName.trim() : '';
  if (!paramName) errors.push(`[${pathLabel}] 缺少 paramName`);

  const description = typeof o.description === 'string' ? o.description.trim() : null;
  const required = o.required === true; // 缺失视为 false

  // type：归一化大小写，识别集合 / 对象 / 基础类型
  let type = null;
  if (typeof o.type === 'string' && o.type.trim()) {
    type = normalizeType(o.type.trim());
  } else {
    warnings.push(`[${pathLabel}] 未提供 type，默认为 String`);
    type = 'String';
  }

  // children：递归校验
  let children;
  if (o.children !== undefined && o.children !== null) {
    if (!Array.isArray(o.children)) {
      errors.push(`[${pathLabel}.children] 必须是数组`);
    } else if (o.children.length > 0) {
      children = o.children.map((c, i) =>
        validateParam(c, `${pathLabel}.children[${i}]`, errors, warnings),
      );
    }
  }

  // 复杂类型必须有 children
  if (isComplexType(type) && (!children || children.length === 0)) {
    errors.push(
      `[${pathLabel}] type="${type}" 是对象/对象集合类型，必须提供 children 子字段，` +
      `否则集成中心无法创建 Structure`,
    );
  }

  // defaultValue：仅接受 string|null|undefined
  let defaultValue;
  if (o.defaultValue === undefined) {
    defaultValue = undefined;
  } else if (o.defaultValue === null) {
    defaultValue = null;
  } else if (typeof o.defaultValue === 'string') {
    defaultValue = o.defaultValue;
  } else {
    // 数字、布尔等转字符串
    defaultValue = String(o.defaultValue);
    warnings.push(`[${pathLabel}.defaultValue] 已转为字符串: "${defaultValue}"`);
  }

  return {
    paramName,
    description,
    required,
    type,
    ...(defaultValue !== undefined ? { defaultValue } : {}),
    ...(children ? { children } : {}),
  };
}

/** 类型字符串归一化 */
function normalizeType(t) {
  // 集合类型：List<X> / Array<X> / Set / Collection
  const m = t.match(COLLECTION_RE);
  if (m) {
    const container = capitalize(m[1]); // List / Array / Set / Collection
    const inner = m[3];
    return inner ? `${container}<${normalizeType(inner)}>` : container;
  }

  const lower = t.toLowerCase();
  if (PRIMITIVE_TYPES.has(lower)) {
    return capitalize(lower);
  }

  // 自定义对象类型：保留原文，但首字母大写
  return capitalize(t);
}

function capitalize(s) {
  return s.length ? s[0].toUpperCase() + s.slice(1) : s;
}

/** 是否复杂类型（必须配合 children） */
function isComplexType(type) {
  if (!type) return false;
  // 集合类型且元素是对象时
  const m = type.match(COLLECTION_RE);
  if (m && m[3]) return !PRIMITIVE_TYPES.has(m[3].toLowerCase());
  // 集合类型且未指定元素：当作基础容器处理
  if (m && !m[3]) return false;
  // 普通对象类型
  return !PRIMITIVE_TYPES.has(type.toLowerCase());
}

/** 域名归一化（允许带 / 不带 protocol） */
function normalizeDomain(d, warnings, idxLabel) {
  let s = d.trim().replace(/\/+$/, ''); // 去末尾斜杠
  if (!/^https?:\/\//i.test(s)) {
    warnings.push(`[${idxLabel}] domain 缺少 http(s):// 前缀，已自动补 http://`);
    s = `http://${s}`;
  }
  return s;
}
