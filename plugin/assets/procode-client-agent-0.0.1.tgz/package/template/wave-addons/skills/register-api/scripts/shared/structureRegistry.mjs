/**
 * StructureRegistry
 * ─────────────────────────────────────────────────────────────
 * 跨 API 协调 Structure 命名的"注册中心"。解决两类问题：
 *
 *   1. 同一批 N 个 API 都引用了 "UserInfo"（字段一致）→ 让它们共享同一个 Structure，
 *      不要在 App 里堆出 UserInfo / UserInfo_1 / UserInfo_2 ...
 *   2. 同名但字段不同（API1 的 Result vs API2 的 Result）→ 必须 rename 一个，
 *      否则后端 DB 唯一约束会报冲突。
 *
 * 关键能力：**按 shape 哈希复用**。
 *   shape = (sortedFieldName + typeSig + required) 拼成的稳定字符串。
 *   typeSig 形如 "Integer"、"DeviceVO"、"List<DeviceVO>"，递归处理 generic。
 *   shape 不包含 description（注释，不影响 Structure 身份）。
 *
 * 数据来源：
 *   - backend：list-apps 返回的 app.structures[]，每个含 structureName.structureName + properties[]
 *   - batch：本批次新引用的 Structure（来自 ExtractedParam.children）
 *
 * 输出能力：
 *   - resolve(desiredName, ourChildren) → finalName（决定该用啥名字）
 *   - getSummary() → { reused, renamed, created }（用于 register-apis 输出）
 */

// ── 一组系统级"特殊 reference" 类型 ───────────────────────────
// 后端把 Datetime / Date 等当作 reference 但 properties 为空（系统预置类型）。
// 我们在引用这些时不应当尝试新建 Structure（也不需要传 properties）。
// 收到这些类型时按 "reference 但跳过 dedup" 处理。
const SYSTEM_REFERENCE_TYPES = new Set([
  'datetime', 'date', 'time', 'timestamp',
]);

export class StructureRegistry {
  /**
   * @param {Array<Object>} backendStructures  list-apps 返回的 app.structures[]
   */
  constructor(backendStructures = []) {
    /** Map<name, { shape, source: 'backend'|'batch'|'system', backendId? }> */
    this.byName = new Map();
    /** 命名决策的记录，用于事后输出 summary */
    this.decisions = []; // [{ desiredName, finalName, action: 'reused'|'renamed'|'created'|'system' }]

    // 1) 灌入后端已有 structures
    for (const s of backendStructures) {
      const name = backendStructureName(s);
      if (!name) continue; // 无名记录跳过（容错）
      const shape = shapeFromBackend(s);
      // 同名后端记录如果多于一个（异常情况），保留最先看到的
      if (!this.byName.has(name)) {
        this.byName.set(name, { shape, source: 'backend', backendId: s.id });
      }
    }

    // 2) 预置系统级 reference（即使 backend 没返回也认得，避免误以为是新 reference 去尝试创建）
    for (const sysName of SYSTEM_REFERENCE_TYPES) {
      const cap = capitalize(sysName);
      if (!this.byName.has(cap)) {
        this.byName.set(cap, { shape: `system:${cap}`, source: 'system' });
      }
    }
  }

  /**
   * 决定一个新引用的 Structure 应该用什么名字。
   *
   * @param {string}              desiredName    原始想用的名字（如 "UserInfo"）
   * @param {Array<Object>}       ourChildren    本批次声明的 children（ExtractedParam[]）
   * @returns {{ finalName: string, isExisting: boolean, isSystemRef: boolean }}
   *           - finalName：最终该用的名字（可能 rename 成 UserInfo_1）
   *           - isExisting：true 表示这个 finalName 已经在后端/本批次定义过了，
   *                         构造请求时应当只传 typeName，不要重复传 properties
   *           - isSystemRef：true 表示这是系统类型（Datetime 等），同样不传 properties
   */
  resolve(desiredName, ourChildren) {
    if (!desiredName) {
      throw new Error('StructureRegistry.resolve: desiredName 必填');
    }

    // 系统类型直接复用
    if (SYSTEM_REFERENCE_TYPES.has(desiredName.toLowerCase())) {
      const canonical = capitalize(desiredName.toLowerCase());
      this.decisions.push({ desiredName, finalName: canonical, action: 'system' });
      return { finalName: canonical, isExisting: true, isSystemRef: true };
    }

    const ourShape = shapeFromExtracted(desiredName, ourChildren);
    const existing = this.byName.get(desiredName);
    const childrenEmpty = !ourChildren || ourChildren.length === 0;

    // case A：完全新名字
    if (!existing) {
      // 边界：用户只填了 type 名字（无 children）且 backend 也没这个 Structure
      // → 没法新建（properties 为空后端会报错）。明确抛错让 agent 补全。
      if (childrenEmpty) {
        throw new Error(
          `Structure "${desiredName}" 在 App 已有定义中找不到，且本批次未声明 children；` +
          `请在 ExtractedParam 里补充该类型的字段定义（children），或确认 type 拼写。`,
        );
      }
      this.byName.set(desiredName, { shape: ourShape, source: 'batch' });
      this.decisions.push({ desiredName, finalName: desiredName, action: 'created' });
      return { finalName: desiredName, isExisting: false, isSystemRef: false };
    }

    // 边界：名字已存在但本批次没传 children → 视作"按名引用"，
    // 不做 shape 比较（否则空 shape vs 真实 shape 必然不等会触发 rename）
    if (childrenEmpty) {
      this.decisions.push({ desiredName, finalName: desiredName, action: 'reused' });
      return { finalName: desiredName, isExisting: true, isSystemRef: false };
    }

    // case B：名字已存在且 shape 一致 → 复用
    if (existing.shape === ourShape) {
      this.decisions.push({ desiredName, finalName: desiredName, action: 'reused' });
      return { finalName: desiredName, isExisting: true, isSystemRef: false };
    }

    // case C：同名不同 shape → 找个空位 rename
    const renamed = this.findFreeName(desiredName);
    const renamedShape = shapeFromExtracted(renamed, ourChildren);
    this.byName.set(renamed, { shape: renamedShape, source: 'batch' });
    this.decisions.push({
      desiredName,
      finalName: renamed,
      action: 'renamed',
      reason: '同名 Structure 已存在但字段不同',
    });
    return { finalName: renamed, isExisting: false, isSystemRef: false };
  }

  /** 找一个 name_1 / name_2 / ... 形式的空闲名字 */
  findFreeName(base) {
    let i = 1;
    let candidate = `${base}_${i}`;
    while (this.byName.has(candidate)) {
      i++;
      candidate = `${base}_${i}`;
    }
    return candidate;
  }

  /** 汇总本批次的命名决策，用于脚本最终输出 */
  getSummary() {
    const reused = [];
    const renamed = [];
    const created = [];
    for (const d of this.decisions) {
      if (d.action === 'reused' || d.action === 'system') {
        reused.push(d.finalName);
      } else if (d.action === 'renamed') {
        renamed.push({ from: d.desiredName, to: d.finalName, reason: d.reason });
      } else if (d.action === 'created') {
        created.push(d.finalName);
      }
    }
    return {
      reused: [...new Set(reused)],
      renamed,
      created: [...new Set(created)],
    };
  }
}

// ──────────────────────────────────────────────────────────────
// shape 计算（双向兼容 backend 格式 和 我们的 ExtractedParam 格式）
// ──────────────────────────────────────────────────────────────

/**
 * 取后端 Structure 对象的名字。
 * 兼容两种返回格式：
 *   - 新版 (/openapi/v3/portal/app/detail/{id})：structureName 是字符串
 *   - 旧版：structureName 是 { structureName: string } 嵌套对象
 */
function backendStructureName(s) {
  if (!s) return null;
  const sn = s.structureName;
  if (typeof sn === 'string') return sn;
  return sn?.structureName ?? null;
}

/**
 * 从后端 Structure 对象计算 shape 字符串
 * 兼容两种属性格式：
 *   - 新版：properties[].typeAnnotation（含 typeName / typeKind / typeArguments）
 *   - 旧版：properties[].paramType
 */
function shapeFromBackend(s) {
  const name = backendStructureName(s) ?? '';
  const propSigs = (s?.properties ?? []).map((p) => ({
    paramName: p.paramName,
    typeSig: backendParamTypeToSig(p.typeAnnotation ?? p.paramType),
    required: !!p.required,
  }));
  return canonicalize(name, propSigs);
}

/**
 * 从我们的 ExtractedParam[] 计算 shape 字符串（用于和 backend shape 比较）
 * @param {string}        typeName
 * @param {Array<Object>} children  ExtractedParam[]，每个有 paramName + type(string) + required
 */
function shapeFromExtracted(typeName, children) {
  const propSigs = (children ?? []).map((c) => ({
    paramName: c.paramName,
    typeSig: c.type ?? 'String',
    required: !!c.required,
  }));
  return canonicalize(typeName, propSigs);
}

/** 按 paramName 排序后拼字符串，得到稳定签名 */
function canonicalize(name, propSigs) {
  const sorted = [...propSigs].sort((a, b) => a.paramName.localeCompare(b.paramName));
  const sig = sorted
    .map((p) => `${p.paramName}:${p.typeSig}:${p.required ? 1 : 0}`)
    .join(';');
  return `${name}|${sig}`;
}

/**
 * 把后端 paramType / typeAnnotation 对象转成我们使用的字符串签名
 *   primitive → "Integer"
 *   reference → "DeviceVO"
 *   generic   → "List<DeviceVO>"（递归处理 typeArguments / subParamType）
 *
 * 兼容两种字段命名：
 *   - 新版 typeAnnotation：typeKind + typeArguments
 *   - 旧版 paramType：paramType + subParamType
 */
function backendParamTypeToSig(pt) {
  if (!pt) return 'String';
  const kind = pt.typeKind ?? pt.paramType;
  const args = pt.typeArguments ?? pt.subParamType;
  const typeName = pt.typeName ?? pt.paramTypeName ?? 'String';
  if (kind === 'generic' && Array.isArray(args) && args.length > 0) {
    const inner = args.map(backendParamTypeToSig).join(',');
    return `${typeName}<${inner}>`;
  }
  return typeName;
}

function capitalize(s) {
  if (!s) return s;
  return s[0].toUpperCase() + s.slice(1);
}
