# register-api

> 一个 Agent Skill —— 把 HTTP 接口注册到内部 API 集成中心

## 这是什么

一个 **AI agent 可调用** 的 skill，配合 agent 自己的模型把任意接口文档（自由文本/Markdown/Swagger）自动录入到内部 API 集成中心：

- 接口结构化提取由 **调用方 agent** 完成（本 skill 不内置 LLM）
- 自动新建/复用分组
- 自动创建数据结构（Structure），同名时自动重命名
- 已存在接口可选跳过或更新
- 完全非交互式脚本，便于 agent 通过 `Bash` 工具调用，关键决策点交给 `AskUserQuestion`

## 安装

**零 npm 依赖、无需 `npm install`**。只要满足两个前置条件：

- Node.js 18.17+
- 系统装有 `curl`（macOS / Linux 自带；Windows 10+ 自带；Docker 镜像如缺，apt 一行装）

```bash
cd register-api
cp .env.example .env       # 嵌入到 agent 时无需此步；独立调试时填入集成中心地址、Token、租户信息
```

> 💡 **HTTP 请求底层用 curl 而非 Node 原生 fetch**，目的是开箱即用 `HTTP_PROXY` /
> `HTTPS_PROXY` 环境变量（Node 原生 fetch 不读这俩 env，在 agent 沙箱里会卡死）。
> 详见 `scripts/shared/openApiAuthClient.mjs` 顶部注释。

## 快速使用

完整使用说明见 [SKILL.md](./SKILL.md)。给 agent 用的脚本：

```bash
# 1. 校验你（agent）提取出的接口 JSON
node scripts/validate.mjs --api-file api.json
node scripts/validate.mjs --list-file list.json

# 2. 查分组
node scripts/list-apps.mjs --domain "http://example.com"

# 3. 校验分组名/标识可用
node scripts/check-app.mjs --name "myapp" --code "myappcode"

# 4. 创建分组
node scripts/create-app.mjs --domain "..." --appName "myapp" --appCode "myappcode"

# 5. 注册接口（自动创建 Structure）
node scripts/register-api.mjs --appId 36087 --api-file api.json

# 6. 更新已存在接口
node scripts/update-api.mjs --apiId 1234 --appId 36087 --api-file api.json
```

所有脚本均输出 JSON 到 stdout，错误信息走 stderr，exit code 非零表示失败。

## 作为 Skill 集成到其他工程

把整个 `register-api/` 目录复制到目标工程的 `skills/` 下（或建立 symlink）：

```
your-project/
└── skills/
    └── register-api/    ← 复制本目录
        ├── SKILL.md
        ├── scripts/
        ├── references/
        └── ...
```

兼容 Skill 协议的 AI agent 会自动发现 `SKILL.md` 并按需调用。

## 目录结构

| 路径 | 用途 |
|------|------|
| `SKILL.md` | Skill 入口（YAML frontmatter + AI 指令 + Input Schema） |
| `scripts/*.mjs` | agent 直接调用的入口脚本（全部非交互） |
| `scripts/shared/*.mjs` | 内部共享代码（鉴权客户端、集成中心 client、校验器、CLI 工具） |
| `references/` | 参考文档（agent 按需阅读） |
| `.env.example` | 环境变量模板（独立运行时使用） |

## 必需环境变量

> 与外层 agent 共用，嵌入运行时无需额外注入；独立运行时填到 `.env`。

| 变量 | 说明 |
|------|------|
| `LCAP_OPENAPI_BASE_URL` | LCAP 平台根 URL（缺省时回退 `NASL_SERVER_BASE_URL`） |
| `LCAP_OPENAPI_AK` | OpenAPI v3 AppKey |
| `LCAP_OPENAPI_SK` | OpenAPI v3 AppSecret |
| `NASL_STORAGE_ACCOUNT_ID` | OpenAPI 用户名（getSignInfo 用） |
| `CW_TENANT` | 租户名（路径段、tenantName 头、getSignInfo 入参、App owner 共用） |
| `CW_USER_SOURCE` | 可选，用户认证源，默认 `Normal`；网易内部环境必须为 `Netease` |
| `REGISTER_API_DEBUG` | 可选，`1`/`true` 时打印请求详情到 stderr |

## 文档

- [SKILL.md](./SKILL.md) — agent 完整指令、Input Schema、workflow
- [references/gateway-api-spec.md](./references/gateway-api-spec.md) — 集成中心 API 字段、枚举、易错点
- [references/workflow.md](./references/workflow.md) — 完整业务流程图

## 设计原则

1. **职责单一**：每个 `scripts/*.mjs` 只做一件事，输入/输出都是 JSON
2. **零依赖**：用 spawn('curl') 替代 fetch，免去 npm install 和代理适配的麻烦
3. **无 LLM 依赖**：文本理解交给上层 agent，本 skill 只做"集成中心侧"操作
4. **决策上抛**：缺信息（域名、分组名、命名冲突等）一律由 agent 调用 `AskUserQuestion` 与用户确认
5. **可恢复**：单步失败不影响其他接口，agent 可重试任意失败步骤
