/**
 * GatewayClient
 * ─────────────────────────────────────────────────────────────
 * 封装所有与 API 集成中心的 HTTP 通信，所有请求统一走 LCAP OpenAPI v3 鉴权
 * （MD5 签名 + 1 小时 SignInfo 缓存），由 OpenApiAuthClient 实现。
 *
 * 本类不包含任何业务判断逻辑，只做请求构造、参数转换、响应断言。
 *
 * 环境变量（与外层 agent 共用，无需额外注入）：
 *   LCAP_OPENAPI_BASE_URL     LCAP 平台根 URL（必填，缺省时回退 NASL_SERVER_BASE_URL）
 *   LCAP_OPENAPI_AK           AppKey（必填）
 *   LCAP_OPENAPI_SK           AppSecret（必填）
 *   NASL_STORAGE_ACCOUNT_ID   OpenAPI 用户名（必填，getSignInfo 用）
 *   CW_TENANT                 租户名（必填）
 *   CW_USER_SOURCE            用户认证源（可选，默认 Normal）
 *   REGISTER_API_DEBUG        1/true 时开启请求详情日志
 */
import { OpenApiAuthClient } from './openApiAuthClient.mjs';
import { StructureRegistry } from './structureRegistry.mjs';

export class GatewayClient {
  constructor() {
    const baseURL = (process.env.LCAP_OPENAPI_BASE_URL ?? process.env.NASL_SERVER_BASE_URL ?? '').trim();
    const ak = (process.env.LCAP_OPENAPI_AK ?? '').trim();
    const sk = (process.env.LCAP_OPENAPI_SK ?? '').trim();
    const userName = (process.env.NASL_STORAGE_ACCOUNT_ID ?? '').trim();
    this.tenantName = (process.env.CW_TENANT ?? '').trim();
    const source = (process.env.CW_USER_SOURCE ?? process.env.LCAP_SOURCE ?? '').trim() || undefined;
    const debug =
      process.env.REGISTER_API_DEBUG === '1' ||
      process.env.REGISTER_API_DEBUG === 'true';

    if (!baseURL) throw new Error('缺少环境变量 LCAP_OPENAPI_BASE_URL（或 NASL_SERVER_BASE_URL）');
    if (!ak) throw new Error('缺少环境变量 LCAP_OPENAPI_AK');
    if (!sk) throw new Error('缺少环境变量 LCAP_OPENAPI_SK');
    if (!userName) throw new Error('缺少环境变量 NASL_STORAGE_ACCOUNT_ID');
    if (!this.tenantName) throw new Error('缺少环境变量 CW_TENANT');

    this.auth = new OpenApiAuthClient({
      ak, sk, baseUrl: baseURL,
      tenantName: this.tenantName,
      userName, source, debug,
    });
  }

  // ── 私有：业务请求统一入口 ─────────────────────────────

  async call(path, method, body, extraHeaders, params) {
    await this.auth.ensureSignInfo();
    let res;
    try {
      res = await this.auth.request(
        path, method, body,
        extraHeaders ?? {},
        params ? { params } : {},
      );
    } catch (err) {
      throw new Error(`集成中心请求失败: ${err.message ?? err}`);
    }
    if (res.code !== 200) {
      throw new Error(`集成中心返回错误: [${res.code}] ${res.msg}`);
    }
    return res.result;
  }

  // ── App 分组相关 ─────────────────────────────────────────

  /**
   * 根据域名查询匹配的 App 分组列表（完整对象，含 apis + structures）
   *
   * GET /openapi/v3/api/integration/app/list/by/domain
   * Headers: apiDomain: <域名>
   *
   * 后端按域名直接过滤，租户从 OpenAPI 鉴权上下文取，无需手动传 tenantName。
   * 兼容返回为数组 / { appList } / { list } 等多种结构。
   */
  async getAppListByDomain(domain) {
    const result = await this.call(
      '/openapi/v3/api/integration/app/list/by/domain',
      'GET',
      undefined,
      { apiDomain: domain },
    );
    if (Array.isArray(result)) return result;
    return result?.appList ?? result?.list ?? [];
  }

  /**
   * 按关键字模糊搜索 App（分组名 / 分组标识）。
   *
   * GET /openapi/v3/portal/app/list?TenantId={租户}&Pattern={关键字}&Offset=0&Limit=N
   *
   * 用途：当用户想把接口注册到一个已存在的 App，但该 App 的域名和文档里的域名不同
   *      （或者用户根本不记得 domain）时，用关键字搜索定位 App。
   *
   * @param {string}        pattern    模糊词（匹配 appName / appCode），空字符串表示列全部
   * @param {{
   *   sources?: string[],             过滤 appSource，如 ["external"]
   *   limit?: number,                 默认 50
   *   offset?: number,                默认 0
   * }} [opts]
   * @returns {Promise<{ appCount: number, appList: Array }>}
   */
  async searchAppsByPattern(pattern, opts = {}) {
    const params = {
      TenantId: this.tenantName,
      Offset: opts.offset ?? 0,
      // 后端默认每页 20，太小；这里默认 10000 一次拉完，上层不必处理分页
      Limit: opts.limit ?? 10000,
    };
    if (pattern && pattern.trim()) params.Pattern = pattern.trim();
    if (opts.sources?.length) params.appSources = opts.sources.join(',');

    const result = await this.call(
      '/openapi/v3/portal/app/list',
      'GET',
      undefined,
      undefined,
      params,
    );
    return {
      appCount: result?.appCount ?? 0,
      appList: result?.appList ?? [],
    };
  }

  /**
   * 按 id 直接拿 App 详情（含 apis + structures）。
   *
   * GET /openapi/v3/portal/app/detail/{id}
   *
   * 与 /openapi/v3/portal/app/{id} 入参一致，但返回值额外包含 apis[] + structures[]，
   * 满足 register-apis 内部"按 id 拉完整信息"的需求（不再依赖 domain 反查）。
   */
  async getAppById(appId) {
    return this.call(
      `/openapi/v3/portal/app/detail/${encodeURIComponent(appId)}`,
      'GET',
    );
  }

  async checkAppNameAvailable(appName) {
    return this.call(
      `/openapi/v3/portal/app/appName/${encodeURIComponent(this.tenantName)}/${encodeURIComponent(appName)}`,
      'GET',
    );
  }

  async checkAppCodeAvailable(appCode) {
    return this.call(
      `/openapi/v3/portal/app/appCode/${encodeURIComponent(this.tenantName)}/${encodeURIComponent(appCode)}`,
      'GET',
    );
  }

  async createApp(req) {
    await this.call('/openapi/v3/portal/app', 'POST', req);
  }

  // ── Structure 相关（保留以兼容历史调用，新代码不再需要）────

  /**
   * @deprecated 已被 StructureRegistry 取代。
   * 新代码请用 `getAppListByDomain(domain)` 拿到完整 App 后构造 StructureRegistry。
   * 这里保留是为了不破坏可能的外部调用。
   */
  async getExistingStructureNames(appId) {
    const result = await this.call(
      '/openapi/v3/portal/structure/list',
      'GET',
      undefined, undefined,
      { AppId: appId, Limit: 1000, Offset: 0 },
    );
    const list = result?.list ?? [];
    return new Set(
      list.map((s) => s?.structureName?.structureName).filter(Boolean),
    );
  }

  // ── API 接口相关 ─────────────────────────────────────────

  /**
   * POST /openapi/v3/portal/httpApi/fast
   * 与普通 newHttpApi 的区别：params 中 reference/generic 类型的 typeAnnotation.properties
   * 会被后端自动插入 api_structure 表，无需提前单独创建 Structure。
   */
  async createApiFast(req) {
    return this.call('/openapi/v3/portal/httpApi/fast', 'POST', req);
  }

  /**
   * DELETE /openapi/v3/portal/httpApi/{id}
   *
   * 注意：后端只删 API + call_record，**不删** 关联的 Structure（Structure 是 App 级共享资源）。
   * 鉴权 + 同租户检查在 controller 内完成。
   */
  async deleteApi(apiId) {
    await this.call(
      `/openapi/v3/portal/httpApi/${encodeURIComponent(apiId)}`,
      'DELETE',
    );
  }

  /**
   * PUT /openapi/v3/portal/httpApi
   * @deprecated 旧版 update 端点，遇 reference 类型容易报 500。新流程改用 deleteApi+createApiFast。
   * 保留方法签名以防外部调用，不建议再使用。
   */
  async updateApi(_apiId, req) {
    await this.call('/openapi/v3/portal/httpApi', 'PUT', req);
  }

  // ── 参数构建工具方法（新版基于 StructureRegistry）────────

  /**
   * 把 ExtractedApiInfo 的五类参数转换为 ApiParamDTO 数组。
   *
   * @param {Object}            info       ExtractedApiInfo
   * @param {StructureRegistry} registry   命名注册中心（必填）
   */
  buildParams(info, registry) {
    if (!registry) throw new Error('buildParams: registry 必填');
    const convert = (params, position) =>
      (params ?? []).map((p) => ({
        paramName: p.paramName,
        description: p.description ?? null,
        required: !!p.required,
        defaultValue: p.defaultValue ?? null,
        position,
        typeAnnotation: this.buildTypeAnnotation(p, registry),
      }));

    return [
      ...convert(info.headerParams,  'request_header'),
      ...convert(info.queryParams,   'query_string'),
      ...convert(info.pathParams,    'request_path'),
      ...convert(info.requestBody,   'request_body'),
      ...convert(info.responseBody,  'response_body'),
    ];
  }

  /**
   * 把 ExtractedParam 转成完整的 ParamTypeDTO（含递归 properties）。
   *
   * 关键差异（与旧版）：
   *   - 不再有 existingNames Set，所有命名决策交给 StructureRegistry
   *   - 对 reference 类型：registry 告诉我们 finalName 和"是否已存在"
   *     - 已存在（同名同 shape 或系统类型 Datetime 等）→ 不传 properties，让后端按名引用
   *     - 新增 → 传 properties，让 /fast 端点自动建 Structure
   */
  buildTypeAnnotation(param, registry) {
    const rawType = (param.type ?? 'String').trim();
    const lower = rawType.toLowerCase();

    const primitiveTypes = new Set([
      'string', 'integer', 'int', 'long', 'short',
      'boolean', 'bool',
      'float', 'double', 'number', 'decimal',
      'byte', 'char',
    ]);

    // ── 0. 兜底降级：日期时间 / 不确定类型 → String primitive ─────
    // 理由：
    //   - 不同源给的日期类型五花八门（Date / DateTime / time / timestamp）；
    //     按 reference 接入后端会和已有 DateTime 撞 shape，强引出 _1 _2 链。
    //   - "any" / "unknown" / 空类型本来就没法建 Structure。
    //   一律按 String 兜底，最简单稳定。
    const fallbackToStringTypes = new Set([
      'date', 'datetime', 'time', 'timestamp',
      'any', 'unknown', '',
    ]);
    if (fallbackToStringTypes.has(lower)) {
      return {
        typeName: 'String',
        typeKind: 'primitive',
        typeArguments: [],
        properties: [],
      };
    }

    // 对象类型但**没声明 children** 也无法建 Structure → 同样兜底为 String
    // （只对非 list / 非 primitive 的根类型生效；List<Object> 走自己的路径）
    const looksLikeObjectButEmpty =
      (lower === 'object') && (!param.children || param.children.length === 0);
    if (looksLikeObjectButEmpty) {
      return {
        typeName: 'String',
        typeKind: 'primitive',
        typeArguments: [],
        properties: [],
      };
    }

    // ── 1. 数组/列表：List / Array / List<Xxx> ─────────
    const listMatch =
      rawType.match(/^[Ll]ist<(.+)>$/) ??
      rawType.match(/^[Aa]rray<(.+)>$/);
    if (listMatch || lower === 'list' || lower === 'array') {
      const innerTypeName = listMatch ? listMatch[1].trim() : 'Object';
      const innerLower = innerTypeName.toLowerCase();
      const innerIsPrimitive = primitiveTypes.has(innerLower);

      let innerAnnotation;
      if (innerIsPrimitive) {
        innerAnnotation = {
          typeName: capitalize(innerTypeName),
          typeKind: 'primitive',
          typeArguments: [],
          properties: [],
        };
      } else {
        // List<Object> 或 List<XxxItem>：内层是 reference
        const desiredName = innerLower === 'object'
          ? capitalize(param.paramName) + 'DTO'
          : innerTypeName;
        const { finalName, isExisting, isSystemRef } =
          registry.resolve(desiredName, param.children ?? []);
        innerAnnotation = {
          typeName: finalName,
          typeKind: 'reference',
          typeArguments: [],
          properties: (isExisting || isSystemRef)
            ? []                                                     // 复用：不重复传 properties
            : this.buildProperties(param.children ?? [], registry), // 新建：把 children 展开
        };
      }

      return {
        typeName: 'List',
        typeKind: 'generic',
        typeArguments: [innerAnnotation],
        properties: [],
      };
    }

    // ── 2. 基础类型 ──────────────────────────────────────
    if (primitiveTypes.has(lower)) {
      return {
        typeName: capitalize(rawType),
        typeKind: 'primitive',
        typeArguments: [],
        properties: [],
      };
    }

    // ── 3. 对象类型（Object / 自定义 PascalCase / 系统 Datetime 等）→ reference
    const desiredName = lower === 'object'
      ? capitalize(param.paramName) + 'DTO'
      : rawType;
    const { finalName, isExisting, isSystemRef } =
      registry.resolve(desiredName, param.children ?? []);

    return {
      typeName: finalName,
      typeKind: 'reference',
      typeArguments: [],
      properties: (isExisting || isSystemRef)
        ? []
        : this.buildProperties(param.children ?? [], registry),
    };
  }

  /** 递归把 ExtractedParam[] 转为 ApiStructurePropertyDTO[] */
  buildProperties(children, registry) {
    return (children ?? []).map((child) => ({
      paramName: child.paramName,
      description: child.description ?? null,
      required: !!child.required,
      defaultValue: child.defaultValue ?? null,
      typeAnnotation: this.buildTypeAnnotation(child, registry),
    }));
  }

  /** 首字母大写 */
  // capitalize 提到模块底部去（导出方便测试）

  /**
   * 构建创建/更新接口的请求体（对应 HttpApiInfoDetailDTO）。
   *
   * @param {number}             appId
   * @param {Object}             info            ExtractedApiInfo
   * @param {number|undefined}   existingApiId   有值=更新；undefined=新增
   * @param {StructureRegistry}  registry        StructureRegistry 实例（必填）
   */
  buildCreateOrUpdateRequest(appId, info, existingApiId, registry) {
    if (!registry) throw new Error('buildCreateOrUpdateRequest: registry 必填');
    const apiCode = this.generateApiCode(info.requestMethod ?? 'GET', info.uri ?? '');

    return {
      ...(existingApiId !== undefined ? { id: existingApiId } : {}),
      apiName: info.apiName ?? apiCode,
      apiCode,
      uri: info.uri,
      requestMethod: (info.requestMethod ?? 'GET').toUpperCase(),
      description: info.description ?? '',
      appInfoDTO: {
        id: appId,
        appType: 'http',
      },
      params: this.buildParams(info, registry),
    };
  }

  /** 生成 apiCode：method(小写) + URI 各段首字母大写，去掉 {} */
  generateApiCode(method, uri) {
    const segments = uri
      .split('/')
      .filter(Boolean)
      .map((seg) => {
        const clean = seg.replace(/[{}]/g, '');
        return clean.charAt(0).toUpperCase() + clean.slice(1);
      });
    return method.toLowerCase() + segments.join('');
  }
}

/**
 * 按 URI 在已有接口列表中查找匹配的接口
 * URI 匹配规则：忽略大小写，忽略末尾斜杠；method 大小写不敏感比较
 */
export function findApiByUri(apis, uri, method) {
  const normalize = (u) => (u ?? '').toLowerCase().replace(/\/+$/, '');
  const targetUri = normalize(uri);
  const targetMethod = (method ?? '').toUpperCase();
  return apis?.find((a) =>
    normalize(a.uri) === targetUri &&
    (!targetMethod || (a.requestMethod ?? '').toUpperCase() === targetMethod)
  ) ?? null;
}

function capitalize(s) {
  if (!s) return s;
  return s.charAt(0).toUpperCase() + s.slice(1);
}
