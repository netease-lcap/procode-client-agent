/**
 * register-apis.mjs — 批量注册/更新接口（推荐入口）
 *
 * 与 register-api.mjs 的区别：
 *   - register-api.mjs：单个接口注册（内部仍走批量逻辑，N=1）
 *   - register-apis.mjs：**多个接口一次性处理**，跨接口共享 StructureRegistry，
 *     避免重复定义同名 Structure；自动识别 update vs create
 *
 * Usage:
 *   node scripts/register-apis.mjs --appId 36087 --list-json '[{...},{...}]'
 *   node scripts/register-apis.mjs --appId 36087 --list-file path/to/apis.json
 *
 * 行为：
 *   1. 必须提供 --appId（从 list-apps 或 search-apps 获取）
 *   2. 必须提供 list（数组形式的 ExtractedApiInfo[]）
 *   3. 内部按 appId 直接拉 App 完整信息（含 apis + structures），**不再依赖 domain 反查**
 *   4. 对每个 api：
 *      - 用 (uri + method) 在已有 App.apis 里找
 *      - 命中 → DELETE 旧 + POST /fast 新建（事实上的 update）
 *      - 未命中 → POST /fast 新建
 *   5. Structure 命名跨 api 协调：
 *      - 同名同 shape → 复用（不重传 properties）
 *      - 同名不同 shape → rename 为 _1/_2
 *      - 新名 → 直接用
 *
 * Output (stdout):
 *   {
 *     "appId": 36087,
 *     "appName": "myapp",
 *     "summary": { "total": 4, "created": 2, "updated": 2, "failed": 0 },
 *     "results": [
 *       { "uri": "/api/v1/devices", "method": "GET", "status": "created", "apiId": 305000 },
 *       { "uri": "/api/v1/devices", "method": "POST", "status": "updated",
 *         "apiId": 305001, "previousApiId": 304945 },
 *       ...
 *     ],
 *     "structures": {
 *       "reused":   ["ControlParams", "Datetime"],
 *       "renamed":  [{ "from": "Result", "to": "Result_1", "reason": "..." }],
 *       "created":  ["DeviceVO", "NewStruct"]
 *     },
 *     "warnings": ["..."]
 *   }
 *
 * 失败语义：
 *   - 单个 API 失败不影响其他 API（best-effort）
 *   - 全部失败时进程 exit code 仍为 0，agent 应根据 results[].status 判断
 *   - 仅在前置错误（如缺 appId / list 为空）时 exit 1
 */
import { parseArgs, requireNumber, readJson, output, info, fail, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const appId = requireNumber(args, 'appId');
  const list = readJson(args, 'list');

  if (!Array.isArray(list)) {
    fail('--list-{json|file} 内容必须是 ExtractedApiInfo 数组');
  }
  if (list.length === 0) {
    fail('list 数组为空，没什么可注册的');
  }

  // 校验每个 api 的基本字段，补默认值
  const normalized = list.map((api, i) => {
    if (!api || typeof api !== 'object') {
      fail(`list[${i}] 不是对象`);
    }
    if (!api.uri) fail(`list[${i}] 缺少必填字段 "uri"`);
    if (!api.requestMethod) fail(`list[${i}] 缺少必填字段 "requestMethod"`);
    return {
      apiName: api.apiName ?? null,
      uri: api.uri,
      requestMethod: api.requestMethod,
      description: api.description ?? null,
      // domain 仅作为元数据保留（如果以后想做"App 域名提示"等增强），
      // 不再用于 App 反查（appId 直接定位）
      domain: api.domain ?? null,
      headerParams: api.headerParams ?? [],
      queryParams: api.queryParams ?? [],
      pathParams: api.pathParams ?? [],
      requestBody: api.requestBody ?? [],
      responseBody: api.responseBody ?? [],
    };
  });

  info(`批量处理 ${normalized.length} 个接口，App=${appId}...`);

  // 调用业务逻辑（registerApis 内部按 appId 直接拉 App 详情）
  const skill = new RegisterSkill();
  const result = await skill.registerApis(appId, normalized);

  // 输出统计信息到 stderr，给 agent 一个总览
  info(`完成：created=${result.summary.created}，updated=${result.summary.updated}，failed=${result.summary.failed}`);
  if (result.structures.reused.length > 0) {
    info(`Structure 复用：${result.structures.reused.join(', ')}`);
  }
  if (result.structures.renamed.length > 0) {
    info(`Structure 重命名：${result.structures.renamed.map((r) => `${r.from}→${r.to}`).join(', ')}`);
  }
  if (result.warnings.length > 0) {
    for (const w of result.warnings) info(`⚠ ${w}`);
  }

  output(result);
});
