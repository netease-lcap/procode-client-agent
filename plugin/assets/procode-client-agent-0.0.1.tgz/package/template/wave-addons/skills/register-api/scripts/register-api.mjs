/**
 * register-api.mjs — 在指定分组下新增/更新单个接口（非交互）
 *
 * 注：本脚本是 register-apis.mjs (批量版) 的便捷包装，内部就是 batch=1。
 * **多接口场景请直接用 register-apis.mjs**，能让 Structure 命名跨接口协调。
 *
 * Usage:
 *   node scripts/register-api.mjs --appId 36087 --api-json '{...ExtractedApiInfo...}'
 *   node scripts/register-api.mjs --appId 36087 --api-file path/to/api.json
 *
 * api JSON 字段（ExtractedApiInfo）：
 *   {
 *     "apiName": "...",
 *     "uri": "/api/...",                ← 必填
 *     "requestMethod": "POST",          ← 必填
 *     "domain": "http://...",           ← 推荐填（用于 list-apps 定位 App），register-api 自身不再硬要求
 *     "description": "...",
 *     "headerParams":  [ <Param>, ... ],
 *     "queryParams":   [ <Param>, ... ],
 *     "pathParams":    [ <Param>, ... ],
 *     "requestBody":   [ <Param>, ... ],
 *     "responseBody":  [ <Param>, ... ]
 *   }
 *
 * Output (stdout):
 *   { "apiId": 12345, "uri": "...", "requestMethod": "POST", "status": "created" }
 *
 *   - status="created": URI+Method 在 App 里不存在 → 新建
 *   - status="updated": URI+Method 已存在 → 内部 POST /fast 新建 + DELETE 老的
 *   - status="failed":  脚本仍 exit 0，但 stdout 包含 error 字段
 *
 * 内部行为：
 *   - Structure 命名通过 StructureRegistry 协调：
 *     - 同名同 shape → 复用 App 已有 Structure
 *     - 同名不同 shape → rename 为 _1
 *     - 新名 → 直接用，/fast 自动建
 */
import { parseArgs, requireNumber, readJson, output, info, fail, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const appId = requireNumber(args, 'appId');
  const api = readJson(args, 'api');

  if (!api.uri) fail('api JSON 缺少必填字段 "uri"');
  if (!api.requestMethod) fail('api JSON 缺少必填字段 "requestMethod"');

  const normalized = {
    apiName: api.apiName ?? null,
    uri: api.uri,
    requestMethod: api.requestMethod,
    description: api.description ?? null,
    domain: api.domain ?? null,
    headerParams: api.headerParams ?? [],
    queryParams: api.queryParams ?? [],
    pathParams: api.pathParams ?? [],
    requestBody: api.requestBody ?? [],
    responseBody: api.responseBody ?? [],
  };

  const skill = new RegisterSkill();

  info(`处理接口 [${normalized.requestMethod} ${normalized.uri}] (App ${appId})...`);
  const batchResult = await skill.registerApis(appId, [normalized]);
  const r = batchResult.results[0];

  if (r.status === 'failed') {
    info(`✗ 失败: ${r.error}`);
    output({
      uri: r.uri,
      requestMethod: r.method,
      status: 'failed',
      error: r.error,
    });
    process.exit(1);
  }

  info(`✓ ${r.status === 'updated' ? '更新成功' : '注册成功'}，apiId=${r.apiId}` +
    (r.status === 'updated' ? `（已删除旧 apiId=${r.previousApiId}）` : ''));

  // Warnings（如"旧已删但新没建成功"）也透传到 stderr
  for (const w of batchResult.warnings) info(`⚠ ${w}`);

  output({
    apiId: r.apiId,
    uri: r.uri,
    requestMethod: r.method,
    status: r.status,
    ...(r.previousApiId !== undefined ? { previousApiId: r.previousApiId } : {}),
  });
});
