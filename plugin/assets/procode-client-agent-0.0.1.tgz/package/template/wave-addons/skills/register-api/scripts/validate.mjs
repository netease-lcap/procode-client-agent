/**
 * validate.mjs — 校验 agent 提取的 ExtractedApiInfo JSON 是否合法，并归一化字段
 *
 * 本 skill 不再调用 LLM；agent 在自身模型里完成文本理解后，把结果（一个或多个
 * ExtractedApiInfo）传给本脚本进行 schema 校验和字段归一化，再继续后续的注册流程。
 *
 * Usage:
 *   # 校验单个接口
 *   node scripts/validate.mjs --api-json '{...ExtractedApiInfo...}'
 *   node scripts/validate.mjs --api-file path/to/api.json
 *
 *   # 校验接口数组（批量）
 *   node scripts/validate.mjs --list-json '[{...},{...}]'
 *   node scripts/validate.mjs --list-file path/to/list.json
 *
 * Output (stdout)：
 *   - 成功：{ "ok": true, "domain": "...", "normalized": <Object|Array>, "warnings": [...] }
 *   - 失败：{ "ok": false, "errors": [...], "warnings": [...] }（exit code 1）
 */
import * as fs from 'node:fs';
import { parseArgs, optionalString, output, info, fail, runScript } from './shared/lib.mjs';
import { validateApi } from './shared/validator.mjs';

await runScript(async () => {
  const args = parseArgs();

  // 单个 vs 数组：四种参数任选其一
  const apiJson  = optionalString(args, 'api-json');
  const apiFile  = optionalString(args, 'api-file');
  const listJson = optionalString(args, 'list-json');
  const listFile = optionalString(args, 'list-file');

  let parsed;
  let isArray = false;

  if (apiJson || apiFile) {
    parsed = readJsonInput(apiJson, apiFile, 'api');
  } else if (listJson || listFile) {
    parsed = readJsonInput(listJson, listFile, 'list');
    isArray = true;
  } else {
    fail('必须提供 --api-json/--api-file （单个）或 --list-json/--list-file （数组）');
  }

  if (isArray) {
    if (!Array.isArray(parsed)) {
      fail('--list-json/--list-file 内容必须是数组');
    }
    info(`校验 ${parsed.length} 个接口...`);

    const results = parsed.map((item, i) => validateApi(item, `${i}`));
    const allErrors = results.flatMap((r) => r.errors);
    const allWarnings = results.flatMap((r) => r.warnings);

    if (allErrors.length) {
      output({ ok: false, errors: allErrors, warnings: allWarnings });
      process.exit(1);
    }

    // 计算公共 domain：取第一个非空 domain
    const normalizedList = results.map((r) => r.normalized);
    const commonDomain = normalizedList.find((a) => a.domain)?.domain ?? null;
    const filledList = normalizedList.map((a) => ({ ...a, domain: a.domain ?? commonDomain }));

    output({
      ok: true,
      domain: commonDomain,
      normalized: filledList,
      warnings: allWarnings,
    });
  } else {
    info('校验单个接口...');
    const r = validateApi(parsed, 'api');
    if (r.errors.length) {
      output({ ok: false, errors: r.errors, warnings: r.warnings });
      process.exit(1);
    }
    output({
      ok: true,
      domain: r.normalized.domain,
      normalized: r.normalized,
      warnings: r.warnings,
    });
  }
});

/** 从 --xxx-json / --xxx-file 读取并解析 JSON */
function readJsonInput(jsonStr, filePath, label) {
  let raw;
  if (jsonStr) {
    raw = jsonStr;
  } else if (filePath) {
    if (!fs.existsSync(filePath)) fail(`文件不存在: ${filePath}`);
    raw = fs.readFileSync(filePath, 'utf-8');
  } else {
    fail(`必须提供 --${label}-json 或 --${label}-file`);
  }
  try {
    // 去掉 UTF-8 BOM（U+FEFF）—— Windows 工具默认产生带 BOM 的 UTF-8，JSON.parse 会报错
    return JSON.parse(raw.replace(/^\uFEFF/, ''));
  } catch (e) {
    fail(`解析 --${label}-{json|file} 失败: ${e.message}`);
  }
}
