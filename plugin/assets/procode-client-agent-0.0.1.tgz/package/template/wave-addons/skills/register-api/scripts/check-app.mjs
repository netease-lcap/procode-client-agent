/**
 * check-app.mjs — 校验 appName / appCode 是否可用（不与已有分组冲突）
 *
 * Usage:
 *   node scripts/check-app.mjs --name "myapp"
 *   node scripts/check-app.mjs --code "myappcode"
 *   node scripts/check-app.mjs --name "myapp" --code "myappcode"   ← 同时校验
 *
 * Output (stdout):
 *   { "name": { "value":"myapp",   "available": true } }
 *   { "code": { "value":"myappcode","available": false } }
 *   或两者同时返回
 *
 * 用途：AI 代理在调用 create-app 之前必须确认名称未被占用，否则后端会报重复错。
 */
import { parseArgs, optionalString, output, info, fail, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const name = optionalString(args, 'name');
  const code = optionalString(args, 'code');

  if (!name && !code) {
    fail('必须提供 --name 或 --code 至少一个');
  }

  const skill = new RegisterSkill();
  const result = {};

  if (name) {
    info(`校验 appName: ${name}`);
    result.name = { value: name, available: await skill.checkAppNameAvailable(name) };
  }
  if (code) {
    // appCode 格式校验：只能英文字母/数字
    if (!/^[a-zA-Z0-9]+$/.test(code)) {
      fail(`appCode 只能含英文字母和数字，收到: ${code}`);
    }
    info(`校验 appCode: ${code}`);
    result.code = { value: code, available: await skill.checkAppCodeAvailable(code) };
  }

  output(result);
});
