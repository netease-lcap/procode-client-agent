/**
 * RegisterSkill
 * ─────────────────────────────────────────────────────────────
 * 封装"查询分组 → 对比接口 → 注册/更新"的网关侧业务逻辑。
 *
 * 设计原则：
 *   - 本类只做纯业务计算和 HTTP 调用，不包含任何 I/O 交互
 *   - 文本理解（提取 ExtractedApiInfo）由上层 agent 完成
 *   - **批量是默认形态**：单接口的 register/update 内部都走 registerApis(batch=1)
 *     这样 StructureRegistry 的命名协调逻辑在所有场景下都生效
 *
 * 对外暴露方法：
 *   1. getAppsByDomain(domain)            ── 查 App 列表（完整对象，含 apis + structures）
 *   2. checkAppNameAvailable / checkAppCodeAvailable
 *   3. buildCreateAppRequest / createApp  ── 创建 App
 *   4. registerApis(appId, domain, list)  ── ★ 批量入口，处理 N 个接口
 *   5. registerApi(appId, info)           ── 单接口包装（内部走 batch=1）
 *   6. updateApi(apiId, appId, info)      ── 单接口更新包装（内部 delete + create）
 */
import { GatewayClient, findApiByUri } from './gatewayClient.mjs';
import { StructureRegistry } from './structureRegistry.mjs';

export class RegisterSkill {
  constructor() {
    this.gateway = new GatewayClient();
  }

  // ── Step 2：根据域名查询/创建分组 ───────────────────────

  async getAppsByDomain(domain) {
    return this.gateway.getAppListByDomain(domain);
  }

  /**
   * 按 id 直接拿 App 完整信息（含 apis + structures）。
   * 用于 register-apis 内部 + agent 在用户选择 App 后拉详情。
   */
  async getAppById(appId) {
    return this.gateway.getAppById(appId);
  }

  /**
   * 按关键字模糊搜索 App。当用户想注册到已有 App 但不记得/不知道 domain 时使用。
   */
  async searchAppsByPattern(pattern, opts) {
    return this.gateway.searchAppsByPattern(pattern, opts);
  }

  async checkAppNameAvailable(appName) {
    return this.gateway.checkAppNameAvailable(appName);
  }

  async checkAppCodeAvailable(appCode) {
    return this.gateway.checkAppCodeAvailable(appCode);
  }

  buildCreateAppRequest(domain, appName, appCode) {
    const tenantName = (process.env.CW_TENANT ?? '').trim();
    const resolvedAppName = appName ?? this.domainToAppName(domain);
    const resolvedAppCode = appCode || this.generateAppCode(resolvedAppName);
    return {
      appName: resolvedAppName,
      appCode: resolvedAppCode,
      appType: 'HTTP',
      appSource: 'external',
      description: `由 register-skill 自动创建，域名: ${domain}`,
      owner: tenantName,
      domain: [{ env: 'dev', domain, svcDomain: null, openSsl: null }],
    };
  }

  async createApp(req) {
    return this.gateway.createApp(req);
  }

  // ── Step 3：批量注册/更新接口（核心入口）─────────────────

  /**
   * 批量注册/更新接口。单接口场景内部统一走这条路径（batch=1）。
   *
   * 关键流程：
   *   1. 用 appId 直接拉 App 完整信息（不再依赖 domain 反查）
   *   2. 用 structures 构造 StructureRegistry（含 shape hash）
   *   3. 对每个 API：
   *      a. 用 (uri, method) 在 App.apis 里找 → 命中=update 路径，未命中=新建
   *      b. buildCreateOrUpdateRequest 时通过 registry 协调 Structure 命名：
   *         - 同名同 shape → 复用（不重传 properties）
   *         - 同名不同 shape → rename 为 _1
   *         - 新名 → 直接用
   *      c. 是 update：先 DELETE 旧 apiId（释放 apiCode 唯一约束），再 POST /fast 新建
   *      d. 是 新建：直接 POST /fast
   *      e. 失败的 API 单独标记，不影响其他 API（best-effort）
   *   4. 返回详细结果 + structure 决策摘要 + warnings
   *
   * @param {number}        appId
   * @param {Array<Object>} infoList   ExtractedApiInfo[]
   * @returns {Promise<{ appId, summary, results, structures, warnings }>}
   */
  async registerApis(appId, infoList) {
    if (!appId) throw new Error('registerApis: appId 必填');
    if (!Array.isArray(infoList) || infoList.length === 0) {
      throw new Error('registerApis: infoList 必须是非空数组');
    }

    // 1. 按 id 直接拉 App 完整信息
    let targetApp;
    try {
      targetApp = await this.gateway.getAppById(appId);
    } catch (err) {
      throw new Error(`无法获取 appId=${appId} 的分组信息：${err.message ?? err}`);
    }
    if (!targetApp) {
      throw new Error(`appId=${appId} 不存在或无权访问`);
    }
    const existingStructures = targetApp.structures ?? [];
    const existingApis = targetApp.apis ?? [];

    // 2. 构造 Registry
    const registry = new StructureRegistry(existingStructures);

    // 3. 逐个处理
    const results = [];
    const warnings = [];

    for (const info of infoList) {
      const uri = info.uri;
      const method = (info.requestMethod ?? 'GET').toUpperCase();
      const existing = findApiByUri(existingApis, uri, method);
      const isUpdate = !!existing;
      const previousApiId = existing?.id;

      // 标记当前 api 是否到了"旧已删，新还没建"的脆弱状态
      let oldDeleted = false;

      try {
        // a. 先构造请求体（构造失败属于 input 问题，此时旧的还在，安全）
        //    始终不带 id，因为统一走 POST /fast
        const req = this.gateway.buildCreateOrUpdateRequest(appId, info, undefined, registry);

        // b. 如果是 update（同 uri+method 已存在），**先**删旧的释放 apiCode
        //    顺序解释：apiCode 在 App 内唯一，create-first 会被旧的占着 apiCode 挡掉，
        //    所以必须 delete-first。代价：delete 成功 + create 失败时该接口暂时缺失，
        //    用户重跑一次脚本即可恢复（彼时 list-apps 找不到旧的，走 create 路径）。
        if (isUpdate) {
          await this.gateway.deleteApi(existing.id);
          oldDeleted = true;
        }

        // c. POST /fast 新建（auto-create structures + 唯一 apiCode 检查）
        const newApiId = await this.gateway.createApiFast(req);

        results.push({
          uri,
          method,
          apiName: info.apiName ?? null,
          status: isUpdate ? 'updated' : 'created',
          apiId: newApiId,
          ...(isUpdate ? { previousApiId } : {}),
        });
      } catch (err) {
        const errMsg = err.message ?? String(err);
        const result = {
          uri,
          method,
          apiName: info.apiName ?? null,
          status: 'failed',
          error: errMsg,
        };
        // 关键：区分"create 失败但旧的还在" vs "create 失败且旧的已删"
        if (oldDeleted) {
          result.previousApiId = previousApiId;
          result.oldDeleted = true;
          result.recoveryHint = '旧版本已被删除但新版本未建成，重跑一次本脚本即可恢复（此时会按新建处理）';
          warnings.push(
            `接口 [${method} ${uri}] 数据缺失：旧版本（apiId=${previousApiId}）已删除，` +
            `但新版本创建失败：${errMsg}。重跑一次脚本可恢复。`,
          );
        }
        results.push(result);
      }
    }

    // 4. 汇总
    return {
      appId,
      appName: targetApp.appName,
      summary: {
        total: results.length,
        created: results.filter((r) => r.status === 'created').length,
        updated: results.filter((r) => r.status === 'updated').length,
        failed: results.filter((r) => r.status === 'failed').length,
      },
      results,
      structures: registry.getSummary(),
      warnings,
    };
  }

  /**
   * 单接口注册（向后兼容包装，内部走 registerApis）。
   *
   * @returns {Promise<number>} 新接口 id
   */
  async registerApi(appId, info) {
    const result = await this.registerApis(appId, [info]);
    const r = result.results[0];
    if (r.status === 'failed') throw new Error(r.error);
    return r.apiId;
  }

  /**
   * 单接口更新（向后兼容包装，内部走 registerApis）。
   * 实际行为：DELETE 旧 apiId + POST /fast 新建。
   * apiId 参数仅用作"已存在的提示"，实际查找仍按 (uri, method) 在 App.apis 里匹配。
   *
   * @returns {Promise<void>}
   */
  async updateApi(_apiId, appId, info) {
    const result = await this.registerApis(appId, [info]);
    const r = result.results[0];
    if (r.status === 'failed') throw new Error(r.error);
    // 旧契约：返回 void
  }

  // ── 工具方法 ─────────────────────────────────────────────

  /** 从域名提取可读分组名 */
  domainToAppName(domain) {
    try {
      const url = new URL(domain.startsWith('http') ? domain : `http://${domain}`);
      return url.hostname.split('.')[0];
    } catch {
      return domain.replace(/[^a-zA-Z0-9]/g, '_');
    }
  }

  /** 从 appName 生成 appCode（只保留字母数字、转小写） */
  generateAppCode(appName) {
    return appName.toLowerCase().replace(/[^a-z0-9]/g, '');
  }
}
