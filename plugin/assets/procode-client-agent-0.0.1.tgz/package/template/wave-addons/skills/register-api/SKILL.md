---
name: register-api
description: |
  将 HTTP 接口注册到 API 集成中心（在不同系统中也称：集成中心 / API 网关 / 接口管理平台）。
  当用户提供了一段包含 HTTP 接口信息的文本（含域名、URL、请求/响应参数等），
  需要把这些接口录入到 API 集成中心的分组下时使用。
  支持自动创建新API分组、复用已有API分组、自动创建/复用数据结构、批量注册多个接口、
  URL 冲突检测（已存在的接口可选择更新或跳过）、Structure 重命名去重。
  适用场景：「把这个接口注册到集成中心」「注册到 API 集成中心」「接入第三方 API」
  「把这个接口注册到网关」「接入到内部 API 网关」「把接口录入到 API 分组」
  「register the following APIs to integration center / gateway」等。
license: Apache-2.0
allowed-tools:
  - Bash              # 执行 node scripts/*.mjs 各脚本
  - Read              # 读取用户提供的接口文档（doc.md / openapi.json 等）
  - Write             # 把待注册接口写为临时 JSON 供 register-api/update-api 使用
  - AskUserQuestion   # 关键决策点：补充域名 / 选择分组 / 命名分组与接口 / skip vs update
---

# Register API to Integration Center

## When to use this skill

激活本 skill 当用户：

- 提供了一段第三方 HTTP 接口文档（含域名、路径、参数描述等），要求录入/注册/接入到内部 API 集成中心
- 表达「注册接口」「接入第三方 API」「录入接口文档到API分组」等意图
- 提供 OpenAPI/Swagger/Postman/普通文本格式的接口描述，需要批量入库

---

## 🚫 When NOT to use this skill（明确不在范围内的场景）

本 skill **只负责"录入接口定义"**。下列场景**不要尝试用脚本绕路实现**，**直接告知用户去集成中心后台手动处理**：

| 用户意图 | 处理方式 |
|---|---|
| 🔴 **修改已有 App 的域名** | 让用户去集成中心后台修改。`change-domain` / `update-app-domain` 等都不实现 |
| 🔴 修改已有 App 的名称 / 标识 / 描述等其它 App 级字段 | 同上 |
| 🔴 删除整个 App | 让用户去集成中心后台删除 |
| 🔴 删除单个接口 | 让用户去集成中心后台删除（注：skill 内部为了实现 update 会调用 delete API，但**不**对外暴露"删除"操作） |
| 🔴 查看接口的调用统计 / 监控 / 日志 | 集成中心 UI 的"调用记录"功能 |
| 🔴 清理孤儿 Structure（如本次更新留下的 `DeviceVO`） | 让用户去集成中心后台手动删；本 skill 不做自动清理（误删风险） |

**当 agent 识别出用户想做以上任一种**：

✅ **应该这么说**（用户面措辞）：
> 修改 App 域名建议直接到 API 集成中心后台操作，那里有完整的 App 配置界面。本 skill 专注于"录入接口定义"，**对 App 本身的属性修改（域名、名称等）不做支持**，避免误操作。

❌ **不要这么说**：
> 我尝试调用 update-app 脚本... / 让我读一下后端代码看有没有改域名的接口...

> 设计原则：skill 是"窄而稳"的工具。每多一个能力 = 多一份误操作面 + 多一份维护成本。
> App 级修改在集成中心 UI 上做更直观、更安全（有 confirm 弹窗、操作记录、回滚），**这不是 skill 该插手的地方**。

---

## 🛠️ Skill 性质声明（写给 agent 框架）

本 skill 是一个**纯数据录入工具（tool-type skill）**，对应外部 API 集成中心的 CRUD 调用：
查分组 / 校验命名 / 创建分组 / 注册接口 / 更新接口。每一步的副作用都**仅限**于：通过 HTTP 调
用集成中心的 OpenAPI v3 接口写一条数据。

它 **不** 涉及：
- ❌ 代码生成 / 文件改写 / 架构决策
- ❌ Workspace 内任何文件的读写（脚本只对外部 HTTP API 发请求）
- ❌ 任何需要"先设计再实施"的软件开发活动

如果你（agent）的框架默认强制走 **"先 plan 后 implement"** 的两段式工作流（如 spec-driven /
speckit / freeplan / "只读规划阶段" 等机制），**对本 skill 请直接跳过 plan 阶段**，按下方
"Workflow" 一步步执行脚本即可。强行写一份计划文档不仅没意义，还容易卡在"plan → implement"
状态转换的 hook 上（参见末尾 Troubleshooting 节）。

> 类比：注册接口到集成中心 ≈ 在管理后台 GUI 里点几下"新建 / 保存"按钮，**这不是软件开发任务**。

### 🚫 硬禁令：执行本 skill 时**绝对不要**做以下动作

无论宿主框架默认行为如何，本 skill 期间禁止以下操作。它们要么没意义，要么会让用户看到与"接口注册"无关的"代码实施完成"模板，造成困惑：

| 动作 | 为什么不做 |
|---|---|
| ❌ 创建 / 写入 `.data/freeplan/`、`.plan/`、`implementation-plan.md` 等任何"计划文档" | 接口注册不是软件开发任务，没有"实施计划"可言 |
| ❌ 调用 `signal-plan-completion` / `complete-plan` / 同类"计划完成"工具 | 触发宿主框架的 plan-complete 模板，会向用户输出"实施计划已完成 / 无需任何代码修改"这种与场景错位的话术 |
| ❌ 任何 `Write` 工具调用，除"为脚本临时写一份 ExtractedApiInfo[] JSON 文件"以外 | `allowed-tools` 里的 `Write` 仅授权这一种用途 |
| ❌ 写 README / 总结文档 / 操作日志到 workspace | 用户不需要这些产物；脚本自己已经把执行结果以 JSON 输出到 stdout |
| ❌ 把脚本输出（脚本 stdout）"翻译"成"代码改动清单" | 输出本身就是用户要看的最终结果，直接展示 + 简短中文小结即可 |

---

## ⚠️ Important: 文本理解由你（agent）完成

本 skill **不内置 LLM 调用能力**，所有从用户文本中提取接口信息的工作 **由调用方 agent 自己完成**。
你（agent）的工作流是：

1. 阅读用户提供的接口文档/文本
2. **自行**提取每个接口的结构化信息（schema 见下方）
3. 调用 `scripts/validate.mjs` 做格式校验和归一化
4. 校验通过后，按"workflow"小节的步骤调用其余脚本完成注册

### ⚠️ 关于接收用户输入：**只接受"粘贴文本"或"上传文件"，严禁让用户提供文件路径或 URL**

如果用户最初的请求里没有附带接口文档，你必须用 `AskUserQuestion` 让用户**通过对话界面**提供文档，**不要**给出"提供文件路径"或"提供 URL"之类的选项。

**两种允许的输入方式（用户任选其一即可）**：

| 方式 | 说明 |
|---|---|
| ✅ **粘贴文本** | 用户直接在对话输入框里粘贴接口文档的原文内容 |
| ✅ **上传文件** | 用户通过对话输入框上传文档文件（如 `.md` / `.txt` / `.json` / `.yaml` / `.pdf` / 截图等）。文件内容会被对话框自动转成文本，你能直接阅读 |

**严禁**给用户提供以下任何一种选项（即使它们看上去很合理）：

| 选项 | 禁止理由 |
|---|---|
| ❌ "提供文件路径" / "指定 workspace 内的文件" | agent 运行在远端服务器/沙箱里，用户**根本不知道**这些路径，问也问不出有效答案 |
| ❌ "提供 URL" / "在线接口文档地址" | agent 所在网络环境**未必能访问**用户给的 URL（外网/内网/代理都可能阻挡），即使能访问也容易超时 |

> 关键区分：**"上传文件"是把文件内容直接塞进对话上下文**（agent 立刻能读），和"提供文件路径"完全不是一回事 —— 前者是 OK 的，后者不行。

**支持的文档格式**（粘贴或上传都行）：

- 自由文本（如"接口名称：xxx，URL：/api/...，参数：..."）
- Markdown 表格
- Swagger / OpenAPI JSON / YAML 片段
- Postman 导出文本
- Apifox / YAPI / 公司内部接口平台导出的描述

**推荐询问措辞**（直接给一个开放输入框，不要给单选项强迫用户选方式）：

> 请把要注册的接口文档提供给我，**两种方式任选其一**：
> 1. 在对话框里直接**粘贴**接口文档原文
> 2. 在对话框里**上传**接口文档文件（支持 `.md` / `.txt` / `.json` / `.yaml` / `.pdf` 等）
>
> 支持任意格式（自由文本、Markdown 表格、Swagger/OpenAPI、Postman 导出等）。
> 文档需包含：域名、接口路径、请求方法、请求/响应参数说明。

如果在后续提取过程中发现关键信息缺失（如域名、分组名、分组标识、接口名等），使用 `AskUserQuestion` 工具向用户确认补充，再继续。

### ⚠️ 关于域名选择：**永远只能注册到一个域名（严禁多选）**

当文档里出现**多个候选域名**（典型：生产/测试/预发各一个 URL），必须让用户**单选一个**，**严禁**给出"两个都注册"或类似的多选项。

**为什么不能多注册**：
- 每个域名对应集成中心里**一个独立的 App 分组**
- 同时注册到 2 个域名 = 2 个独立 App = 后续每次改一个接口要在 N 个 App 里同步改
- 用户的真实需求几乎都是"对一个具体环境录入"，多注册是反模式

**严禁出现在 `AskUserQuestion` 里的选项**：
| ❌ 错误选项 | 为什么禁 |
|---|---|
| "两个都注册" / "分别为生产和测试各创建一个API分组" | 制造数据冗余 |
| "先注册生产、再注册测试" | 同上，只是分两步 |
| "全部注册" | 同上 |

**正确做法**：用 `AskUserQuestion` 给出**互斥的单选项**：

> 接口文档里检测到多个候选域名，请选择要注册到哪一个集成中心分组：
> 1. `https://api.example.com/v1`（生产环境）
> 2. `https://test.api.example.com/v1`（测试环境）
> 3. 都不是，我自己填一个

无论用户选 1、2 还是 3，**最终只有一个域名进入后续流程**。如果用户事后真的想在另一个域名也录入一份，那是**第二次独立的 skill 调用**，不在本次任务范围内。

---

## 📋 AskUserQuestion 选项的统一格式

**所有用 `AskUserQuestion` 抛给用户的选项，必须满足以下格式**（保持与宿主 agent 其它 skill 一致的视觉风格）：

| 字段 | 要求 |
|---|---|
| `label`（每项主标题） | **简短一句话**，描述**具体可见的值**或**具体动作**。绝不能是"之前用过的域名 / 生产环境域名"这类**抽象类别**——用户看到的得是真实的 `http://localhost:8080` |
| `description`（每项副标题） | 一句话说明该选项的来源/含义/适用场景，让用户知道**选了会发生什么** |
| 推荐项 | **第一项** label 末尾追加 `(推荐)`，并在 description 里说清楚为什么推荐（"文档里出现的"/"你刚提到的"等具体理由） |
| 兜底项 | **必须**有"其他"作为最后一项，label 写"其他，我自己填一个"，description 写"上面都不合适，下一步会让你直接输入"。**不要**让用户在某个选项里"再叠一个填空框"——每个选项是单选的"已填好"答案 |
| 选项数 | 2~4 项；如候选过多，挑最相关的 3 项 + 一个"其他"，剩余的别堆进来 |

### ✅ 示范：缺 domain 时如何问

❌ 反面例子（在某个 option 里塞了文本框、其它 option 是"之前用过的域名"这种抽象类别）：

> 新分组的域名是什么？
> ① `http://localhost:8080` ── 请提供新分组的域名和名称 [文本框]
> ② `http://127.1.1.1:9090` ── 之前用过的域名
> ③ `https://api.iot-platform.com` ── 生产环境域名
>
> 问题：① 把"选项"和"自由输入"混在一起；② 和 ③ 的 description 是分类标签而非"为什么推荐"的具体理由；少了"其他"兜底项。

✅ 正面例子（每项都是已填好的具体值，第一项带 `(推荐)`，最后一项是"其他"）：

```
title: 新分组的域名是什么？
options:
  - label: "http://localhost:8080 (推荐)"
    description: "你刚才在这次对话里提到的本地测试域名"
  - label: "https://api.iot-platform.com/v1"
    description: "接口文档里出现的生产环境域名"
  - label: "其他，我自己填一个"
    description: "上面都不合适，下一步会让你直接输入"
```

> 同样的格式适用于：选 API 分组、选 appName/appCode、是否覆盖已存在接口、补 path/query 参数等所有让用户做决策的环节。
> 永远不要在某个 option 里嵌"自由文本输入框"——这是宿主 agent 的兜底交互、不是 skill 该用的形式。

### 🧩 高频决策点的模板（直接复用，不要自由发挥）

下面 5 个模板对应本 skill 最常出现的决策点。**LLM 调用 `AskUserQuestion` 时按字段照抄即可**——只替换花括号里的占位值，结构、推荐位、其他项一律保留。

#### T1. 文档里没写 domain，让用户选/填

```
question: 新API分组的域名是什么？
options:
  - label: "{从对话上下文里抓到的最可信的域名} (推荐)"
    description: "{说明为什么推荐：'你刚提到的本地测试域名' / '文档第一段出现的生产域名' 等}"
  - label: "{文档里出现的另一个候选域名}"
    description: "{该域名的来源描述}"
  - label: "其他，我自己填一个"
    description: "上面都不合适，下一步会让你直接输入"
```

#### T2. 文档里出现多个候选 domain，必须单选

```
question: 检测到多个候选域名，请选择要注册到哪一个集成中心分组
options:
  - label: "https://api.example.com/v1 (推荐)"
    description: "生产环境域名（文档主体描述的目标环境）"
  - label: "https://test.api.example.com/v1"
    description: "测试环境域名"
  - label: "其他，我自己填一个"
    description: "上面都不是，下一步会让你直接输入"
```

#### T3. list-apps 找到多个 App，让用户选其中一个

```
question: 同一个域名下有多个 App，要把接口注册到哪一个？
options:
  - label: "{App.appName} (推荐)"
    description: "appCode: {App.appCode}，已有接口 {N} 个，最近修改时间 {modifyTime}"
  - label: "{第二个 App 的 appName}"
    description: "appCode: {App.appCode}，已有接口 {N} 个"
  - label: "其他，让我用关键字重新搜"
    description: "上面都不对，下一步会让你输入关键字模糊搜索"
```

#### T4. domain 找不到 App，三选一

```
question: 这个域名下还没有分组，下一步怎么办？
options:
  - label: "用 {domain} 新建一个分组 (推荐)"
    description: "下一步会让你确认分组名称和标识"
  - label: "把接口注册到一个已有分组（域名不一样也行）"
    description: "下一步会让你提供关键字模糊搜索现有分组"
  - label: "取消注册"
    description: "本次不做任何写入"
```

#### T5. 接口已存在，确认是否覆盖

```
question: 接口 {METHOD} {uri} 在该分组里已存在，怎么处理？
options:
  - label: "更新为新版本 (推荐)"
    description: "用文档里的最新定义覆盖原接口（参数、返回值会被替换）"
  - label: "跳过这一条，保留原样"
    description: "本次不动这个接口，继续处理其它接口"
  - label: "取消整批注册"
    description: "本次什么都不写"
```

> 严格规则：
> - 任何模板里都**不许**出现"在某个 option 里再叠一个文本框"的写法。
> - 任何模板的"其他"都是**单独一项**，不带值；用户选了之后，下一步再用一个**新的** `AskUserQuestion`（或宿主自带的输入对话框）让用户填具体值。**不要用一次提问完成"选 + 填"两个动作**。
> - 选项数 2~4 个，候选太多时优先列最相关的 2~3 个 + "其他"，不要把全部候选堆进去。

---

## Input Schema（你产出的 JSON 必须遵守此结构）

```typescript
/** 单个 API 接口的提取结果 */
interface ExtractedApiInfo {
  apiName:       string | null;       // 接口名称，如"创建用户"
  uri:           string | null;       // 必填，如 "/api/v1/users/{id}"
  requestMethod: string | null;       // 必填，GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS（大小写不敏感，自动大写）
  domain:        string | null;       // 必填，如 "http://example.com"（缺 http:// 会自动补）
  description:   string | null;
  headerParams:  ExtractedParam[];    // 请求头参数
  queryParams:   ExtractedParam[];    // Query string 参数
  pathParams:    ExtractedParam[];    // 路径参数（必须与 uri 中 {xxx} 占位符对应）
  requestBody:   ExtractedParam[];    // 请求体字段
  responseBody:  ExtractedParam[];    // 响应体字段
}

/** 单个参数（可递归嵌套） */
interface ExtractedParam {
  paramName:     string;              // 必填
  description:   string | null;
  required:      boolean;             // 缺失视为 false
  type:          string;              // 见下方"合法 type 值"
  defaultValue?: string | null;
  /** 嵌套子字段：当 type 是对象/对象数组时必填，否则不允许集成中心创建 Structure */
  children?: ExtractedParam[];
}
```

### 合法 type 值

| 类别 | 示例 | 是否需要 children |
|------|------|------------------|
| 基础类型（自动首字母大写） | `String`、`Integer`、`Long`、`Boolean`、`Float`、`Double`、`Number`、`Date`、`DateTime` | ❌ |
| 自定义对象类型 | `UserInfo`、`OrderDetail`、`ExternalSetting` | ✅ 必须 |
| 对象数组 | `List<UserInfo>`、`Array<Order>` | ✅ 必须 |
| 基础类型数组 | `List<String>`、`Array<Integer>` | ❌ |
| 通用集合（不指定元素） | `List`、`Array` | ❌（视为基础容器） |

> **关键约束**：`type` 一旦是自定义对象（如 `UserInfo`）或对象数组（如 `List<UserInfo>`），
> 就 **必须** 在 `children` 提供该对象的字段定义；否则集成中心无法自动创建对应的 Structure，
> validate 脚本会直接报错。

### 完整示例

```json
{
  "apiName": "创建订单",
  "uri": "/api/v1/orders/{userId}",
  "requestMethod": "POST",
  "domain": "http://example.com",
  "description": "为指定用户创建一笔订单",
  "headerParams": [
    { "paramName": "X-Request-Id", "description": "请求追踪 ID", "required": true, "type": "String" }
  ],
  "queryParams": [
    { "paramName": "source", "description": "来源", "required": false, "type": "String" }
  ],
  "pathParams": [
    { "paramName": "userId", "description": "用户 ID", "required": true, "type": "Long" }
  ],
  "requestBody": [
    { "paramName": "items", "required": true, "type": "List<OrderItem>", "children": [
        { "paramName": "skuId", "required": true, "type": "Long" },
        { "paramName": "qty",   "required": true, "type": "Integer" }
    ]},
    { "paramName": "amount", "required": true, "type": "Double" }
  ],
  "responseBody": [
    { "paramName": "orderId",   "required": true, "type": "Long" },
    { "paramName": "status",    "required": true, "type": "String" }
  ]
}
```

---

## Required environment

本 skill 的环境变量 **与外层 agent 共用**，嵌入到 agent 中运行时，agent 已经配置好这些变量，子进程会自动继承，**无需任何额外注入**。

| 变量 | 必填 | 说明 |
|------|------|------|
| `LCAP_OPENAPI_BASE_URL` | ✅ | LCAP 平台根 URL；缺省时回退 `NASL_SERVER_BASE_URL` |
| `LCAP_OPENAPI_AK` | ✅ | OpenAPI v3 AppKey |
| `LCAP_OPENAPI_SK` | ✅ | OpenAPI v3 AppSecret |
| `NASL_STORAGE_ACCOUNT_ID` | ✅ | OpenAPI 用户名（`POST /openapi/v3/auth/getSignInfo` 用） |
| `CW_TENANT` | ✅ | 租户名 —— 同时承担：① `tenantName` 请求头  ② getSignInfo 入参  ③ 部分接口路径段 `{tenantId}`（实际是租户名）  ④ 创建 App 的 `owner` 字段 |
| `REGISTER_API_DEBUG` | ❌ | `1` / `true` 时把 API 集成中心请求详情打到 stderr，便于排错 |

**鉴权机制简述（agent 不需要关心，由 skill 内部处理）**：
所有请求统一走 LCAP OpenAPI v3 签名（`X-AppKey` + `X-Nonce` + `X-Timestamp` + `X-Signature`）+ 1 小时 `X-SignInfo` 缓存（跨进程持久化到 `os.tmpdir()`），由 `scripts/shared/openApiAuthClient.mjs` 实现。

如缺失任一必填变量，脚本会立刻退出并报错；agent 应先用 `AskUserQuestion` 提示用户参考 `.env.example` 配置。

**独立运行（非 agent 嵌入）**：
开发者本地调试时，把上述变量写到 `register-api/.env` 即可，参考 `.env.example`。

---

## Available scripts (非交互式，agent 直接调用)

所有脚本均为：**JSON 输入 → JSON 输出**，stderr 输出错误信息，exit code 非零表示失败。
使用 `node scripts/<name>.mjs <args>` 直接调用（mjs 是 ES Module，Node 18+ 原生支持，零依赖、无需构建）。

### 1. validate — 校验你提取的接口 JSON 是否合法

```bash
# 单个接口
node scripts/validate.mjs --api-json '{...ExtractedApiInfo...}'
node scripts/validate.mjs --api-file path/to/api.json

# 批量数组
node scripts/validate.mjs --list-json '[{...},{...}]'
node scripts/validate.mjs --list-file path/to/list.json
```

成功输出：
```json
{ "ok": true, "domain": "http://example.com",
  "normalized": <ExtractedApiInfo | ExtractedApiInfo[]>,
  "warnings": ["..."] }
```

失败输出（exit code 1）：
```json
{ "ok": false, "errors": ["[0] 缺少 uri", "..."], "warnings": ["..."] }
```

### 2. list-apps — 按域名查询 API 集成中心已有分组

```bash
node scripts/list-apps.mjs --domain "http://example.com"
```

输出：
```json
{
  "matched": 1,
  "apps": [
    { "id": 36087, "appName": "myapp", "apiCount": 5,
      "apis": [{ "id": 1, "uri": "/...", "requestMethod": "GET" }, ...] }
  ]
}
```

### 2'. search-apps — 按关键字模糊搜索已有 App（兜底定位）

当 list-apps 按域名找不到，**而用户表示"我想注册到一个已经存在的分组"**时使用。
后端 SQL LIKE，匹配范围：`appName` / `appCode` / `domain`。
（所以你给一个域名片段如 `"iot-platform.com"` 也能命中。）

```bash
node scripts/search-apps.mjs --pattern "iot"
node scripts/search-apps.mjs --pattern "device" --limit 200
```

> 默认 `--limit 10000`（一次拉完，规避后端 20 条/页的默认分页）。

输出：
```json
{
  "matched": 2, "total": 2, "pattern": "iot",
  "apps": [
    { "id": 36582, "appName": "IoT设备管理-local", "appCode": "iotDeviceManagement",
      "appType": "HTTP", "appSource": "external", "owner": "cstest",
      "domains": ["http://localhost:8080"] },
    { "id": 36542, "appName": "第三方设备管理", "appCode": "thirdPartyDevices",
      "appType": "HTTP", "appSource": "external", "owner": "cstest",
      "domains": ["https://api.iot-platform.com/v1"] }
  ]
}
```

> ⚠️ list 端点不返回 `apis[]` / `structures[]`（始终是空数组）。
> 真正注册接口时（register-apis），脚本内部会用 appId 重新拉完整信息，无需 agent 操心。

> ⚠️ **如果 `matched` 很大（例如 > 30）**：不要把所有 App 一股脑列给用户，
> 改让用户给一个更具体的关键字再搜一次（例如把 `"test"` 改成 `"iot-device"`）。
> 经验值：1000+ 命中通常是 pattern 太短，多半与租户名 / 通用单词撞上了。

### 3. check-app — 校验 appName / appCode 是否可用

```bash
node scripts/check-app.mjs --name "myapp"
node scripts/check-app.mjs --code "myappcode"
```

输出：`{"available": true}`

### 4. create-app — 创建新分组

```bash
node scripts/create-app.mjs --domain "http://example.com" --appName "myapp" --appCode "myappcode"
```

输出：
```json
{ "appId": 36087, "appName": "myapp", "appCode": "myappcode" }
```

### 5. register-apis — 批量注册/更新接口 ⭐ 推荐入口

```bash
node scripts/register-apis.mjs --appId 36087 --list-json '[{...},{...},{...}]'
# 或从文件
node scripts/register-apis.mjs --appId 36087 --list-file path/to/apis.json
```

**何时必须用 register-apis 而不是单接口 register-api**：
- 用户提供的文档**包含多个接口**（哪怕只是 2 个）—— **几乎所有真实场景**
- 多个 API 共享同一个数据结构（如多个接口都用 `UserInfo` / `Result` 等）

为什么：register-apis 跨接口共享 `StructureRegistry`，自动做 Structure 命名协调（同名同 shape 复用、同名不同 shape rename）。如果你拆成多次 register-api 调用，每次都是独立的命名上下文，会产生重复的 Structure 或意外冲突。

输出：
```json
{
  "appId": 36087, "appName": "myapp",
  "summary": { "total": 3, "created": 2, "updated": 1, "failed": 0 },
  "results": [
    { "uri": "/x", "method": "GET",  "status": "created", "apiId": 305000 },
    { "uri": "/y", "method": "POST", "status": "updated", "apiId": 305001,
      "previousApiId": 304950 },
    { "uri": "/z", "method": "PUT",  "status": "failed", "error": "..." }
  ],
  "structures": {
    "reused":  ["UserInfo", "Datetime"],
    "renamed": [{ "from": "Result", "to": "Result_1", "reason": "..." }],
    "created": ["NewStruct"]
  },
  "warnings": []
}
```

> ⚠️ **status="updated" 的语义**：内部实际是 POST /fast 新建 + DELETE 旧 apiId（旧 update 端点对 reference 类型会 500，我们绕开了）。`apiId` 是**新 id**，旧的已删除。

### 6. register-api — 单接口注册（次选）

只有**真的只有 1 个接口**要注册时用。内部走 batch=1，跟 register-apis 同一套逻辑。

```bash
node scripts/register-api.mjs --appId 36087 --api-file path/to/api.json
```

输出：`{"apiId": 1234, "uri": "...", "requestMethod": "POST", "status": "created"}`

### 7. update-api — 单接口更新（次选）

```bash
node scripts/update-api.mjs --apiId 1234 --appId 36087 --api-file path/to/api.json
```

输出：`{"updated": true, "apiId": <新id>, "previousApiId": 1234, ...}`

实际行为是 **delete 旧的 + create 新的**（apiId 会变），对外仍以 "update" 语义呈现。

---

## Workflow (推荐执行顺序)

详细流程见 `references/workflow.md`。简版：

1. **你（agent）从文本中提取** `ExtractedApiInfo` 数组 + 公共 domain
2. **validate** 校验通过后再继续；如失败，根据 errors 修正输出后重试
3. 检查 `domain` 是否为空，若空 → 用 `AskUserQuestion` 询问用户补充
4. **list-apps --domain $domain** → 拿到匹配的分组列表
   - **0 个**：用 `AskUserQuestion` 让用户在以下三选一中**单选**：
     1. **创建新 App**（基于当前 domain）→ 询问 appName / appCode → check-app 校验 → create-app
     2. **使用一个已存在的 App**（domain 不一样也没关系）→ 让用户提供关键字 → 跑 `search-apps --pattern <关键字>` → 把结果列给用户选 → 拿到 appId
     3. **取消注册**
   - **1 个**：直接使用
   - **多个**：列给用户选（`AskUserQuestion`）
5. **一把梭批量注册：** 把所有 `ExtractedApiInfo` 写到一个 list JSON 文件，调用 **`register-apis`** 一次搞定。
   - update vs create 由脚本自动判断（按 uri+method 在 App.apis 里查找）
   - 已存在的接口会被"更新"（实际是 delete + create，对外语义不变）
   - Structure 命名跨接口自动协调，不会产生重复
   - 部分接口失败不影响其他接口，看返回的 `results[]` 标记
   - **不要拆成多次 register-api 调用**，那样会丢失跨接口的 Structure 协调能力

---

## References

- `references/gateway-api-spec.md` — API 集成中心后端接口定义、字段含义、枚举值
- `references/workflow.md` — 完整业务流程图与每步细节

---

## Troubleshooting（卡住时怎么办）

### 1. 卡在"规划阶段"无法进入"实施阶段"

**症状**：agent 写完 `.data/freeplan/<sessionId>/implementation-plan.md`（或类似计划文档）后停下来，说
"准备进入实现阶段执行接口注册操作"但实际**不执行任何脚本**，需要用户手动输入
"Signal plan completion" / "继续" / "开始执行" 之类的指令才往下走。

**根因**：这是上层 agent 框架（如 speckit）的两段式 plan-implement 工作流。它把所有任务
都当成需要"先规划后实施"的软件开发任务，导致**简单的 CRUD 操作也被卡在状态转换处**。

**应对**：
| 角色 | 措施 |
|---|---|
| **agent（你）** | 优先尝试跳过 plan 阶段，直接执行 scripts/*.mjs。参见上方"Skill 性质声明"小节 |
| **用户** | 若已卡在"准备进入实现阶段"提示，回复 `继续` / `Signal plan completion` 通常能解锁 |
| **agent 团队** | 上游 bug：若 agent 自称已自动发出 "Signal plan completion" 却没生效，是框架内部 hook 失败，需要修复 framework，不是本 skill 的问题 |

### 2. 脚本失败但你不知道原因

**症状**：脚本输出 `{"error": "..."}`，但不清楚是 env / 鉴权 / 网络 / 业务码哪一类问题。

**应对**：**直接阅读 stderr 和 stdout 的 `error` 字段**，里面已经包含集成中心真实的 `code`
和 `msg`，不需要重复跑 curl 或手动调试。常见错误对照：

| 错误信息 | 真实原因 | 修复方式 |
|---|---|---|
| `getSignInfo 失败 [500] 用户名 XXX 不存在` | `(CW_TENANT, NASL_STORAGE_ACCOUNT_ID, CW_USER_SOURCE)` 三元组不匹配 | 用 `AskUserQuestion` 提醒用户检查 3 个 env；网易内部环境通常需要 `CW_USER_SOURCE=Netease` |
| `集成中心返回错误: [401101] 操作不允许 租户非法` | 同上（表象错误，根因还是 SignInfo 没拿到） | 同上 |
| `curl 请求失败 (exit=6)` / `DNS 解析失败` | 域名无法解析，通常是内网域名/缺代理 | skill 底层用 curl，会自动读 `HTTP_PROXY` / `HTTPS_PROXY` env；确认这两个环境变量已正确配置 |
| `curl 请求失败 (exit=7)` / `连接被拒绝` | 端口不通或目标服务未启动 | 检查 `LCAP_OPENAPI_BASE_URL` 是否正确、是否需要走代理 |
| `curl 请求失败 (exit=28)` / `超时` | 集成中心接口不可达或响应过慢 | 检查网络；必要时调大 timeout |
| `未找到 curl 命令` | 运行环境缺 curl | macOS/Linux/Win10+ 默认有；Docker 镜像里需要 `apt-get install -y curl` |
| `集成中心返回错误: [400xxx] appCode 不能为空` 等参数问题 | 自身脚本 bug | 把错误贴给开发者，**不要尝试在 agent 侧 hack**（如自己拼 curl 调集成中心）|

**重要原则**：脚本失败时，**不要自己写 curl 命令绕过 skill**。这会让问题永久绕过而无法被
修复。正确的做法：
1. 把脚本的 stderr + stdout 完整保留下来
2. 用 `AskUserQuestion` 告知用户哪一步失败、错误信息是什么
3. 若用户要求继续，**只跳过有问题的接口**，处理剩余的（register-api 是单接口操作，互不影响）

---

## Notes for AI agents

- 🚫 **范围边界**：本 skill 只录入"接口定义"，**App 级修改（域名/名称/标识等）一律不支持，引导用户去集成中心后台处理**（详见上文"When NOT to use this skill"）
- 🗣️ **和用户沟通时必读：底部"用户面措辞守则"**——不要原样复述 "delete+create" / "apiId 会变" / "POST /fast" 等实现细节给用户，他们只需知道是 "更新" 即可
- 🚫 **域名永远单选**：文档里多个候选域名时，让用户在 `AskUserQuestion` 里**单选其一**，**严禁**"两个都注册""分别建两个分组"等多选项（详见上文"关于域名选择"）
- 接口参数中的 `Object` 或自定义类型字段，**必须**在 `children` 提供子字段，否则 validate 报错且 Structure 不会被创建
- `request_header` / `query_string` / `request_path` / `request_body` / `response_body` 是 API 集成中心参数 `position` 字段的合法值（**全小写下划线**），但你不需要在 `ExtractedApiInfo` 里手动写 position —— 通过 headerParams/queryParams/pathParams/requestBody/responseBody 五个分组天然区分
- 创建分组时 `owner` 字段必须等于 `CW_TENANT`，否则后端校验报「租户非法」
- `appCode` 只能含英文字母和数字
- Structure 名称冲突时脚本会自动追加 `_1`、`_2`，无需 agent 处理
- 关键决策点（域名缺失、多 App 选择、命名建议、是否覆盖已存在接口）**统一使用 `AskUserQuestion` 与用户确认**，不要擅自决定
- **接收接口文档时只允许"粘贴文本"或"在对话框上传文件"**，禁止向用户提供"提供文件路径""提供 URL"等选项（详见上文"⚠️ 关于接收用户输入"）

---

## 🗣️ 用户面措辞守则（重要：和用户沟通时必须遵守）

skill 的内部实现细节（如 "delete + create"、"apiId 会变"、"StructureRegistry"、"X-SignInfo"、"shape hash" 等）**是给你 agent 看的，绝对不要原样复述给最终用户**。

用户视角看到的应该是**业务语义**，不是**技术机制**。

### 翻译对照表

| ❌ 错的说法（暴露实现） | ✅ 对的说法（业务语义） |
|---|---|
| "已包含 4 个同名接口，将被标识为更新（旧id删，新id建）" | "已包含 4 个同名接口，将**更新**它们" |
| "POST /fast 新建 + DELETE 旧 apiId" | "更新接口" |
| "新 apiId=305001，旧 apiId=304945 已删除" | "已更新（接口 ID: 305001）" |
| "Structure ControlParams 命中 shape 复用" | "复用了已有的数据结构 ControlParams" |
| "SignInfo 已加载" / "X-Signature 已计算" | （什么都不说，鉴权是底层细节） |
| "走 register-apis.mjs 批量端点" | "正在批量注册接口" |
| "apiId 会变" / "previousApiId" | （不说，对用户来说就是更新） |

### 关于 update 操作的描述

**应该说**：
- "将更新已有的 N 个接口"
- "已成功更新接口 [GET /api/v1/devices]"
- "更新完成"

**不要说**：
- ~~"先删除旧接口再创建新接口"~~
- ~~"旧 ID 304944 已删除，新 ID 305000 已创建"~~
- ~~"将走 delete+create 流程"~~

### 唯一应该向用户暴露"内部异常"的场景：`oldDeleted: true` 且 status="failed"

更新流程实际是 **先删旧 + 再建新**。若删除已成功但新建失败（罕见，但理论可能），输出会包含
`oldDeleted: true` 和 `recoveryHint: "重跑..."`。这种情况**用户必须知道**——他们的集成中心
里这个接口暂时不见了。也要"说人话"：

✅ **应该这么说**：
> 接口 `[GET /api/v1/devices]` 更新失败：旧版本已被自动清理，但新版本没建成功。这个接口现在
> 暂时不在集成中心里。**重跑一次刚才的命令即可恢复**（脚本会按"新建"处理）。

❌ **不要这么说**：
> 旧 apiId=304944 已删除，新 apiId 创建失败（HTTP 500），oldDeleted=true，recoveryHint=...

### 通用原则

1. **以"用户能采取什么行动"为准**决定要不要暴露技术细节
   - 用户需要做什么 → 用业务语义清楚说
   - 用户不需要做什么 → 不说
2. 出错时，把错误**翻译成用户能理解的因果**，而不是直接贴 stack trace 或脚本输出
3. 除非用户主动问"具体怎么实现的"，否则不主动暴露脚本名 / 端点路径 / 字段名

