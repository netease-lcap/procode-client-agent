# Gateway API Spec Reference

本文档面向 AI 代理，详尽描述本 skill 调用的集成中心后端接口、字段含义、枚举值、易错点。
配合 SKILL.md 使用：当 AI 在使用脚本过程中需要构造或修改 JSON 数据时，参考此处。

---

## 1. App 分组相关接口

### 1.1 按域名查分组 — GET /openapi/v3/api/integration/app/list/by/domain

**Headers**：`apiDomain: <域名>`

> 注意：
> - **不需要**手动传 `tenantName` 头，租户身份由 OpenAPI 鉴权上下文（X-AppKey + X-SignInfo）自动解析。
> - 域名字段名是 **`apiDomain`** 而**不是** `domain`（避免与浏览器/Cookie 标准 `domain` 头语义冲突）。

**返回**：`GatewayAppDTO[]`（后端按域名直接过滤后返回，无需客户端再次筛选）

关键字段：
| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | number | App 数据库主键，**后续注册接口必须传此 id** |
| `appName` | string | 分组名 |
| `appUniqueId.appCode` | string | 分组唯一标识 |
| `apis[]` | `GatewayApiDTO[]` | App 下已有接口（用于 URL 冲突检测） |
| `structures[]` | `AppStructure[]` | App 下已有数据结构 |
| `domain[]` | `DomainInfo[]` | 多环境域名 |

### 1.2 校验 appName/appCode — GET /openapi/v3/portal/app/{appName,appCode}/{tenantId}/{value}

**返回**：`{result: true}` = 可用，`{result: false}` = 已被占用

### 1.3 创建分组 — POST /openapi/v3/portal/app

**Body**：`CreateAppRequest`
```json
{
  "appName": "myapp",
  "appCode": "myappcode",         // 必填，只能英文字母+数字
  "appType": "HTTP",              // 固定大写
  "appSource": "external",
  "description": "...",
  "owner": "<CW_TENANT>",         // 必须等于请求头 tenantName，否则报"租户非法"
  "domain": [
    { "env": "dev", "domain": "http://example.com", "svcDomain": null, "openSsl": null }
  ]
}
```

**返回**：不含 id，需二次按域名查询。

---

## 2. API 接口相关

### 2.1 注册接口 — POST /openapi/v3/portal/httpApi/fast ⭐

**重要**：必须使用 `/fast`，普通的 `/httpApi` 不会自动创建 Structure。

**Body**：`HttpApiInfoDetailDTO`
```json
{
  "apiName": "...",
  "apiCode": "postApiV1Users",         // method+URI 各段首字母大写
  "uri": "/api/v1/users",
  "requestMethod": "POST",             // 大写
  "description": "...",
  "appInfoDTO": {
    "id": 36087,                       // App 数据库主键，必填
    "appType": "http"                  // 小写！@JsonSubTypes 识别
  },
  "params": [ <ApiParamDTO>, ... ]
}
```

**关键字段说明**：

#### `<ApiParamDTO>`
```json
{
  "paramName": "userId",
  "description": "用户 ID",
  "required": true,
  "defaultValue": null,
  "position": "request_path",          // 见下方 position 枚举
  "typeAnnotation": <ParamTypeDTO>
}
```

#### `position` 枚举（**全小写下划线**）
对应 `HttpFieldEnums.java`：
- `request_header`
- `query_string`
- `request_path`
- `request_body`
- `response_body`
- `response_header`

⚠️ 大写或驼峰会报 `No enum constant HttpFieldEnums.XXX`。

#### `<ParamTypeDTO>`
```json
{
  "typeName": "String",
  "typeKind": "primitive",             // primitive | reference | generic
  "typeArguments": [],
  "properties": []
}
```

#### `typeKind` 与 Structure 创建规则

| typeKind | 触发后端创建 Structure？ | 说明 |
|----------|--------------------------|------|
| `primitive` | ❌ 否 | String/Integer/Long/Boolean/Float/Double/Number |
| `reference` | ✅ 是 | 自定义对象类型，properties 为字段列表 |
| `generic` | 仅当 `typeArguments[0]` 是 `reference` 时 | List 类型 |

#### Structure 创建示例

**对象类型** `externalSetting: { url, timeout }`：
```json
{
  "paramName": "externalSetting",
  "position": "request_body",
  "typeAnnotation": {
    "typeName": "ExternalSetting",     // PascalCase 名称
    "typeKind": "reference",
    "typeArguments": [],
    "properties": [
      { "paramName": "url",
        "required": true,
        "typeAnnotation": {
          "typeName": "String", "typeKind": "primitive",
          "typeArguments": [], "properties": [] } },
      { "paramName": "timeout",
        "required": false,
        "typeAnnotation": {
          "typeName": "Integer", "typeKind": "primitive",
          "typeArguments": [], "properties": [] } }
    ]
  }
}
```

**数组类型** `headers: [{key, value}, ...]`：
```json
{
  "paramName": "headers",
  "position": "request_body",
  "typeAnnotation": {
    "typeName": "List",
    "typeKind": "generic",
    "typeArguments": [{
      "typeName": "Header",
      "typeKind": "reference",
      "typeArguments": [],
      "properties": [
        { "paramName": "key",   "typeAnnotation": {"typeName":"String","typeKind":"primitive","typeArguments":[],"properties":[]} },
        { "paramName": "value", "typeAnnotation": {"typeName":"String","typeKind":"primitive","typeArguments":[],"properties":[]} }
      ]
    }],
    "properties": []
  }
}
```

### 2.2 更新接口 — PUT /openapi/v3/portal/httpApi

Body 与 register 相同，但需多传 `id`（接口数据库主键）。

### 2.3 查询分组下接口 — GET /openapi/v3/portal/httpApi/list?AppId=...

---

## 3. Structure 相关

### 3.1 查 Structure 列表 — GET /openapi/v3/portal/structure/list?AppId=...&Limit=1000

**返回**：`{list: [{id, structureName, description}, ...], total: N}`

**用途**：在注册接口前查已有 Structure 名称，对将要新建的同名 Structure 自动重命名（`_1`、`_2`...），避免后端唯一性约束冲突。

---

## 4. 常见错误码与原因

| 错误信息                                  | 原因 |
|---------------------------------------|------|
| `No enum constant HttpFieldEnums.XXX` | `position` 字段大小写错误 |
| `租户非法`                                | 创建 App 时 `owner` ≠ `tenantName` |
| `appName 已存在`                         | 未通过 check-app 校验直接创建 |
| `Structure 名称重复`                      | 未查已有 Structure，传了同名 reference |
| `appCode 不能为空`                        | 创建 App 时未传 `appCode` |
| `分组不属于该租户`                            | `appInfoDTO.id` 错误，或租户与 App 不匹配 |

---

## 5. 字段命名对照表

部分字段在前后端命名不同，容易混淆：

| 前端/请求体 | 后端字段 | 说明 |
|------------|----------|------|
| `position` | `httpField` | 参数位置 |
| `typeAnnotation` | `paramType` | 参数类型 |
| `typeKind` | `paramType` (字段名一样但语义不同) | primitive/reference/generic |
| `typeName` | `paramTypeName` | 类型名 |
| `typeArguments` | `subParamType` | 泛型参数 |
| `appInfoDTO.id` | App 数据库主键 | **不是 appCode** |
