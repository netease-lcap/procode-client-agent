/**
 * 脚本通用工具：CLI 参数解析、JSON 输入输出、错误处理
 *
 * 所有非交互式 mjs 脚本（供 AI agent 调用）都通过本模块完成：
 *   1. 解析 CLI 参数（支持 --key value / --key=value / --flag）
 *   2. 输出 JSON 结果到 stdout（一行或格式化），便于 AI 解析
 *   3. 输出错误到 stderr 并以非零 exit code 退出
 *
 * 设计原则：
 *   - stdout 仅输出最终 JSON 结果（避免日志污染）
 *   - 所有日志/进度信息走 stderr
 *   - 不依赖任何 npm 包，纯 Node 内置能力
 *
 * 环境变量加载：本 skill 不再使用 dotenv，env 由 agent 注入。
 *   独立调试时可用 `node --env-file=.env scripts/X.mjs`（Node 20+ 原生支持）
 */
import * as fs from 'node:fs';

// ── 1. CLI 参数解析 ─────────────────────────────────────────

/**
 * 解析 process.argv 形如：
 *   --key value     → { key: 'value' }
 *   --key=value     → { key: 'value' }
 *   --flag          → { flag: true }
 *
 * @returns {Object<string, string|boolean>}
 */
export function parseArgs() {
  const args = process.argv.slice(2);
  const result = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!a.startsWith('--')) continue;
    const eq = a.indexOf('=');
    if (eq >= 0) {
      result[a.slice(2, eq)] = a.slice(eq + 1);
    } else {
      const key = a.slice(2);
      const next = args[i + 1];
      if (next !== undefined && !next.startsWith('--')) {
        result[key] = next;
        i++;
      } else {
        result[key] = true;
      }
    }
  }
  return result;
}

/** 取必填字符串参数；缺失时报错退出 */
export function requireString(args, key) {
  const v = args[key];
  if (typeof v !== 'string' || !v.trim()) {
    fail(`缺少必填参数: --${key}`);
  }
  return v.trim();
}

/** 取可选字符串参数 */
export function optionalString(args, key) {
  const v = args[key];
  return typeof v === 'string' ? v.trim() : undefined;
}

/** 取必填数字参数 */
export function requireNumber(args, key) {
  const s = requireString(args, key);
  const n = Number(s);
  if (!Number.isFinite(n)) fail(`参数 --${key} 必须是数字，收到: ${s}`);
  return n;
}

/**
 * 读取 JSON 数据：优先从 --<key>-json 字符串解析，否则从 --<key>-file 文件读取
 *
 * @example
 *   readJson(args, 'api')  ← 接受 --api-json '{...}' 或 --api-file path
 */
export function readJson(args, key) {
  const jsonStr = optionalString(args, `${key}-json`);
  const filePath = optionalString(args, `${key}-file`);

  let raw;
  if (jsonStr) {
    raw = jsonStr;
  } else if (filePath) {
    if (!fs.existsSync(filePath)) fail(`文件不存在: ${filePath}`);
    raw = fs.readFileSync(filePath, 'utf-8');
  } else {
    fail(`必须提供 --${key}-json 或 --${key}-file 之一`);
  }

  try {
    // 去掉 UTF-8 BOM（U+FEFF）—— Windows 工具（PowerShell/记事本/Excel 等）默认产生带 BOM 的 UTF-8，
    // JSON.parse 会因此报 "Unexpected token '﻿'"
    return JSON.parse(raw.replace(/^\uFEFF/, ''));
  } catch (e) {
    fail(`解析 --${key}-{json|file} 失败: ${e.message}`);
  }
}

// ── 2. 输出 ────────────────────────────────────────────────

/** 输出最终结果到 stdout（格式化 JSON） */
export function output(data) {
  process.stdout.write(JSON.stringify(data, null, 2) + '\n');
}

/** 进度/日志信息到 stderr，不污染 stdout 数据流 */
export function info(msg) {
  process.stderr.write(`[info] ${msg}\n`);
}

/** 错误并退出（非零 code） */
export function fail(msg, code = 1) {
  process.stderr.write(`[error] ${msg}\n`);
  process.exit(code);
}

// ── 3. 顶层执行包装器 ───────────────────────────────────────

/**
 * 包装异步主函数，统一处理：
 *   - 异常捕获 → stderr 错误 + stdout JSON 错误 → 退出 code 1
 */
export async function runScript(main) {
  try {
    await main();
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    process.stderr.write(`[error] ${message}\n`);
    process.stdout.write(JSON.stringify({ error: message }) + '\n');
    process.exit(1);
  }
}
