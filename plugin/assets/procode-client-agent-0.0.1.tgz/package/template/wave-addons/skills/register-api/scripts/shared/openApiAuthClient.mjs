/**
 * OpenApiAuthClient
 * ─────────────────────────────────────────────────────────────
 * LCAP OpenAPI v3 鉴权客户端（mjs 版，零依赖）。
 *
 * 与 hicode-sandbox 的 LcapOpenApiAuthClient 算法一致：
 *   - 静态签名头：X-AppKey / X-Nonce / X-Timestamp / X-Signature
 *     X-Signature = MD5(`${ak}&${nonce}&${timestamp}&${sk}`)
 *   - 会话头：X-SignInfo
 *     通过 POST /openapi/v3/auth/getSignInfo 换发，TTL 1 小时
 *
 * HTTP 实现说明：
 *   底层不用 Node 原生 fetch，而是 spawnSync('curl', ...) 走系统 curl。
 *   理由（和同事在 `.specify/scripts/javascript/shared/service.mjs` 中保持一致）：
 *     1. curl 默认读 HTTP_PROXY / HTTPS_PROXY 环境变量，在 hicode-sandbox
 *        测试环境（容器走 127.0.0.1:7003 代理）开箱即用，**无需 undici 等额外依赖**
 *     2. 行为与 agent 自己用 curl 调试完全一致，不会出现"curl 通了 fetch 不通"的诡异问题
 *     3. 零 npm 依赖，无需 package.json / node_modules，部署即用
 *   代价：spawnSync 阻塞事件循环（短脚本场景可接受），需要系统装 curl（几乎所有系统自带）
 *
 * 增强（针对 agent 嵌入环境）：
 *   1. SignInfo 跨进程持久化（写到 os.tmpdir()），避免每个脚本调用都重新换发
 *   2. getSignInfo 失败立即抛错（含 tenantName/userName/source 上下文），
 *      不再被静默吞掉导致后续报"租户非法"等表象错误
 *
 * 对外方法：
 *   - ensureSignInfo()：业务请求前调用，自动刷新过期 SignInfo
 *   - request()       ：发起带签名的 HTTP 请求
 *   - loadSignInfo()  ：手动强制刷新 SignInfo（极少用到）
 */
import * as crypto from 'node:crypto';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';
import { spawnSync } from 'node:child_process';

/** SignInfo 缓存 TTL（1 小时） */
const SIGN_INFO_TTL_MS = 60 * 60 * 1000;

/** getSignInfo 接口路径（写死，与平台规范一致） */
const SIGN_INFO_PATH = '/openapi/v3/auth/getSignInfo';

/** 默认请求超时（秒，curl --max-time 用） */
const DEFAULT_TIMEOUT_SEC = 60;

/**
 * 为 (ak, baseUrl) 组合生成跨进程的 SignInfo 缓存文件路径。
 * 用 md5 短哈希做后缀，防止多账号互相串用。
 */
function buildCacheFilePath(ak, baseUrl) {
  const hash = crypto
    .createHash('md5')
    .update(`${ak}|${baseUrl}`)
    .digest('hex')
    .slice(0, 16);
  return path.join(os.tmpdir(), `.register-api-signinfo-${hash}.json`);
}

export class OpenApiAuthClient {
  /**
   * @param {Object} opts
   * @param {string} opts.ak        AppKey
   * @param {string} opts.sk        AppSecret
   * @param {string} opts.baseUrl   平台根 URL，不带末尾斜杠
   * @param {string} opts.tenantName
   * @param {string} opts.userName  getSignInfo 入参
   * @param {string} [opts.source]  用户认证源，默认 "Normal"；网易内部环境通常为 "Netease"
   * @param {boolean}[opts.debug]   调试日志，默认 false
   * @param {number} [opts.timeout] 请求超时秒，默认 60
   */
  constructor(opts) {
    this.ak = opts.ak;
    this.sk = opts.sk;
    this.baseUrl = opts.baseUrl.replace(/\/+$/, '');
    this.tenantName = opts.tenantName;
    this.userName = opts.userName;
    this.source = opts.source ?? 'Normal';
    this.debug = opts.debug ?? false;
    this.timeoutSec = opts.timeout ?? DEFAULT_TIMEOUT_SEC;

    this.signInfo = '';
    this.signInfoCreatedAt = 0;

    // 跨进程持久化的缓存文件（与 ak/baseUrl 绑定）
    this.cacheFile = buildCacheFilePath(this.ak, this.baseUrl);
    this.cacheLoaded = false; // 文件只读一次，避免反复 IO
  }

  // ── 签名相关 ─────────────────────────────────────────────

  /** MD5(`${ak}&${nonce}&${timestamp}&${sk}`) */
  buildSignature(nonce, timestamp) {
    const plain = `${this.ak}&${nonce}&${timestamp}&${this.sk}`;
    return crypto.createHash('md5').update(plain).digest('hex');
  }

  /** 4 个静态签名头 + 可选 X-SignInfo */
  buildAuthHeaders(nonce, timestamp) {
    const headers = {
      'X-AppKey': this.ak,
      'X-Nonce': nonce,
      'X-Signature': this.buildSignature(nonce, timestamp),
      'X-Timestamp': timestamp.toString(),
    };
    if (this.isSignInfoValid()) {
      headers['X-SignInfo'] = this.signInfo;
    }
    return headers;
  }

  /**
   * SignInfo 是否仍在 TTL 内。
   *
   * 三段优先级：
   *   1. 内存中已有且未过期 → 直接返回 true
   *   2. 第一次调用 → 尝试从持久化缓存文件加载（避免每个脚本进程都重新换发）
   *   3. 都没有 → 返回 false，调用方应触发 loadSignInfo()
   */
  isSignInfoValid() {
    if (this.signInfo && Date.now() - this.signInfoCreatedAt < SIGN_INFO_TTL_MS) {
      return true;
    }
    // 文件缓存只尝试一次，命中即填充内存
    // 注意：cache 是内部性能优化，不应出现在 debug 日志中（debug 只反映集成中心交互）
    if (!this.cacheLoaded) {
      this.cacheLoaded = true;
      try {
        const cached = JSON.parse(fs.readFileSync(this.cacheFile, 'utf-8'));
        if (cached?.signInfo && Date.now() - cached.createdAt < SIGN_INFO_TTL_MS) {
          this.signInfo = cached.signInfo;
          this.signInfoCreatedAt = cached.createdAt;
          return true;
        }
      } catch {
        // 文件不存在 / 解析失败 / 过期，都走重新换发流程
      }
    }
    return false;
  }

  // ── SignInfo 换发 ────────────────────────────────────────

  /**
   * 强制重新拉取 X-SignInfo
   * 调用本方法时 buildAuthHeaders 不会携带 X-SignInfo（因为还未拿到），
   * 只带 X-AppKey/X-Nonce/X-Timestamp/X-Signature 通过签名校验。
   *
   * 失败时立即抛错（含完整上下文），不再静默吞掉。
   */
  async loadSignInfo() {
    const body = {
      tenantName: this.tenantName,
      userName: this.userName,
      source: this.source,
    };
    const res = await this.request(SIGN_INFO_PATH, 'POST', body);

    // 失败时立即抛错，把后端真实的 code/msg 透出，配合三元组上下文便于排查
    // （以前是 result ?? '' 静默吞掉，导致后续请求带空 SignInfo 出现"租户非法"等表象错误）
    if (res?.code !== 200 || typeof res.result !== 'string' || !res.result) {
      throw new Error(
        `getSignInfo 失败 [${res?.code ?? 'no-code'}] ${res?.msg ?? '未知错误'}` +
        `（tenantName=${this.tenantName}, userName=${this.userName}, source=${this.source}）。` +
        `请检查 CW_TENANT / NASL_STORAGE_ACCOUNT_ID / CW_USER_SOURCE 三个环境变量是否匹配平台上的实际用户`,
      );
    }

    this.signInfo = res.result;
    this.signInfoCreatedAt = Date.now();

    // 持久化到 tmpdir，下次脚本进程启动时可复用，节省一次往返
    // 失败静默：本次进程内仍能正常用，下次脚本调用最多多换发一次
    try {
      fs.writeFileSync(
        this.cacheFile,
        JSON.stringify({
          signInfo: this.signInfo,
          createdAt: this.signInfoCreatedAt,
        }),
        { mode: 0o600 }, // 只有当前用户能读写
      );
    } catch {
      // 静默
    }
  }

  /** SignInfo 缺失或过期 → 自动刷新；其它请求前调用 */
  async ensureSignInfo() {
    if (this.isSignInfoValid()) return;
    this.signInfo = '';
    await this.loadSignInfo();
  }

  // ── 通用请求（基于 curl）────────────────────────────────

  /**
   * 发起一个带签名的 HTTP 请求（底层 spawnSync('curl', ...)）。
   *
   * @param {string} reqPath                           相对路径，如 /openapi/v3/portal/...
   * @param {string} method                            HTTP 方法
   * @param {*}      [body]                            POST/PUT/PATCH 请求体
   * @param {Object<string,string>} [extraHeaders]     业务额外头（如 apiDomain）
   * @param {{ params?: Object<string,*> }} [extraConfig] axios 兼容：params 用于 GET 拼 query
   * @returns {Promise<{ code:number, msg:string, result:any, success?:boolean }>}
   */
  async request(reqPath, method, body, extraHeaders = {}, extraConfig = {}) {
    const nonce = this.randomNonce();
    const timestamp = Math.floor(Date.now() / 1000);
    const headers = {
      'Content-Type': 'application/json',
      ...this.buildAuthHeaders(nonce, timestamp),
      ...extraHeaders,
    };
    const m = method.toUpperCase();

    // 拼 URL（含 query）
    let url = this.baseUrl + reqPath;
    if (extraConfig.params) {
      const qs = new URLSearchParams();
      for (const [k, v] of Object.entries(extraConfig.params)) {
        if (v !== undefined && v !== null) qs.set(k, String(v));
      }
      const s = qs.toString();
      if (s) url += (url.includes('?') ? '&' : '?') + s;
    }

    if (this.debug) {
      this.logRequest(m, reqPath, headers, body, extraConfig.params);
    }

    // ── 调 curl ────────────────────────────────────────
    // -s        静默模式（不输出进度）
    // -w        在 stdout 末尾追加 \n%{http_code}，便于解析 HTTP 状态
    // --max-time 总超时（秒）
    // -X METHOD HTTP 方法
    // -H ...    请求头（每个一个 -H 参数）
    // -d BODY   请求体（仅 POST/PUT/PATCH）
    const headerArgs = Object.entries(headers).flatMap(([k, v]) => ['-H', `${k}: ${v}`]);
    const sendBody = m !== 'GET' && m !== 'HEAD' && body !== undefined;
    const bodyStr = sendBody ? JSON.stringify(body ?? null) : undefined;

    const curlArgs = [
      '-s',
      '-w', '\n%{http_code}',
      '--max-time', String(this.timeoutSec),
      '-X', m,
      ...headerArgs,
      ...(sendBody ? ['-d', bodyStr] : []),
      url,
    ];

    const result = spawnSync('curl', curlArgs, {
      encoding: 'utf8',
      maxBuffer: 10 * 1024 * 1024, // 10MB 响应上限
    });

    // 1) curl 二进制找不到（系统没装）
    if (result.error) {
      if (result.error.code === 'ENOENT') {
        throw new Error(
          '未找到 `curl` 命令。请确认系统已安装 curl（macOS/Linux 通常自带；' +
          'Windows 10+ 自带；Docker 镜像可能需要 apt-get install -y curl）',
        );
      }
      throw new Error(`curl 调用失败: ${result.error.message}`);
    }

    // 2) curl 退出码非零（网络错误 / DNS 失败 / 超时等）
    if (result.status !== 0) {
      // curl exit codes: 6=DNS 失败, 7=连接失败, 28=超时, ...
      const hint =
        result.status === 28 ? `（超时，--max-time=${this.timeoutSec}s）` :
        result.status === 6  ? '（DNS 解析失败）' :
        result.status === 7  ? '（连接被拒绝/无法到达）' : '';
      const stderr = (result.stderr || '').trim();
      throw new Error(`curl 请求失败 (exit=${result.status})${hint}: ${stderr || 'no stderr output'}`);
    }

    // 3) 解析 stdout：最后一行是 HTTP 状态码，其余是响应体
    const stdout = result.stdout || '';
    const lastNewline = stdout.lastIndexOf('\n');
    const bodyResp = lastNewline >= 0 ? stdout.slice(0, lastNewline) : '';
    const httpStatus = lastNewline >= 0 ? parseInt(stdout.slice(lastNewline + 1), 10) : 0;

    let data;
    try {
      data = bodyResp ? JSON.parse(bodyResp) : {};
    } catch {
      throw new Error(
        `HTTP ${httpStatus}: 响应非 JSON. body=${bodyResp.slice(0, 200)}`,
      );
    }

    // 4) HTTP 非 2xx 但响应里有业务码，交给上层 assertSuccess 处理；否则直接抛
    if ((httpStatus < 200 || httpStatus >= 300) && data?.code === undefined) {
      throw new Error(
        `HTTP ${httpStatus}: ${JSON.stringify(data).slice(0, 200)}`,
      );
    }
    return data;
  }

  // ── 内部工具 ─────────────────────────────────────────────

  /** 随机 nonce：优先 randomUUID，回退到 16 字节 hex */
  randomNonce() {
    if (typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    return crypto.randomBytes(16).toString('hex');
  }

  /** 调试日志：打到 stderr，敏感字段脱敏 */
  logRequest(method, reqPath, headers, body, params) {
    const sep = '─'.repeat(60);
    process.stderr.write('\n' + sep + '\n');
    process.stderr.write(`🌐 [Gateway Request] ${method} ${this.baseUrl}${reqPath}\n`);

    // 脱敏：X-Signature / X-SignInfo 只展示前 8 位
    const safeHeaders = {};
    for (const [k, v] of Object.entries(headers)) {
      if (k === 'X-Signature' || k === 'X-SignInfo') {
        safeHeaders[k] =
          typeof v === 'string' && v.length > 8 ? `${v.slice(0, 8)}...***` : '***';
      } else {
        safeHeaders[k] = v;
      }
    }
    process.stderr.write(`  Headers : ${JSON.stringify(safeHeaders, null, 2)}\n`);

    if (params && typeof params === 'object' && Object.keys(params).length > 0) {
      process.stderr.write(`  Params  : ${JSON.stringify(params, null, 2)}\n`);
    }
    if (body !== undefined && body !== null && method !== 'GET' && method !== 'HEAD') {
      process.stderr.write(`  Body    : ${JSON.stringify(body, null, 2)}\n`);
    }
    process.stderr.write(sep + '\n');
  }
}
