# Workflow Reference

完整业务流程图与每步细节。Agent 在不确定下一步时参考此文档。

---

## 完整流程图

```
┌─────────────────────────────────────────────────────────────────┐
│                    用户提供接口文档文本/文件                     │
└────────────────────────┬────────────────────────────────────────┘
                         ↓
        ┌────────────────────────────────────────┐
        │  Step 1: 你（agent）阅读输入，自行提取 │
        │   产出：ExtractedApiInfo[]（参考       │
        │         SKILL.md 的 Input Schema）     │
        └────────────────┬───────────────────────┘
                         ↓
        ┌────────────────────────────────────────┐
        │  Step 2: 调用 validate.mjs 校验/归一化 │
        │   输入：--list-file 或 --api-file      │
        │   输出：{ ok, normalized, domain, ... }│
        └────────────────┬───────────────────────┘
                         ↓
                    校验失败？──── 是 ──→ 修正提取结果，重新校验
                         │
                         ↓ 否
        ┌──────────────────────────────────┐
        │  domain 是否为 null？            │
        └─────┬────────────────────┬───────┘
              ↓ 是                 ↓ 否
        ┌──────────────────┐  ┌──────────────────────────────────┐
        │ AskUserQuestion: │  │  Step 3: 调用 list-apps.mjs       │
        │ "请提供域名"     │→ │   输入：--domain $domain          │
        │ 然后填回         │  │   输出：{ matched, apps[] }       │
        └──────────────────┘  └────────────────┬─────────────────┘
                                              ↓
                ┌──────────────┬──────────────┬────────────────┐
                ↓              ↓              ↓
            matched=0      matched=1      matched>1
                ↓              ↓              ↓
        ┌────────────────┐ ┌──────────────┐ ┌──────────────────┐
        │ AskUserQuestion│ │ 直接使用     │ │ AskUserQuestion: │
        │ 分组名/Code    │ │ targetAppId= │ │ 列表给用户选     │
        │ ↓              │ │ apps[0].id   │ │ ↓                │
        │ check-app      │ └──────┬───────┘ │ targetAppId =    │
        │ ↓              │        │         │ 选中的 app.id    │
        │ create-app     │        │         └────────┬─────────┘
        │ ↓              │        │                  │
        │ targetAppId    │        │                  │
        └─────┬──────────┘        │                  │
              └───────────────────┴──────────────────┘
                              ↓
        ┌──────────────────────────────────────────────────┐
        │  拿到 targetAppId（待会儿喂给 register-apis）    │
        └────────────────────┬─────────────────────────────┘
                             ↓
        ┌──────────────────────────────────────────────────┐
        │  Step 4: 把 normalized 数组整体写到 /tmp/apis.json│
        │          然后 **一次性** 调 register-apis.mjs    │
        │                                                  │
        │  node scripts/register-apis.mjs \                │
        │       --appId $appId --list-file /tmp/apis.json  │
        │                                                  │
        │  脚本内部对每个 api：                            │
        │   - 按 (uri+method) 查 App.apis                  │
        │   - 命中 → 内部 POST/fast + DELETE 旧 = update   │
        │   - 未命中 → POST/fast = create                  │
        │   - Structure 跨 api 自动协调（reuse/rename）    │
        │   - 单个失败不影响其他                           │
        └────────────────────┬─────────────────────────────┘
                             ↓
        ┌──────────────────────────────────────────────────┐
        │  Step 5: 看 results[]，按 status 整理摘要给用户   │
        │   - status: created / updated / failed           │
        │   - structures: { reused, renamed, created }     │
                        │   - warnings: 数据缺失提醒等                     │
        └──────────────────────────────────────────────────┘
```

---

## 每步细节

### Step 1: agent 自行提取 ExtractedApiInfo

阅读用户提供的接口文档（自由文本/Markdown/Swagger/Postman 等），按 `SKILL.md` 中定义的 Input Schema 产出一个 `ExtractedApiInfo` 数组。

**关键提醒**：
- `uri` / `requestMethod` / `domain` 是必填
- 参数中 `type` 是 `Object` / 自定义对象 / `List<UserInfo>` 等复杂类型时，**必须**在 `children` 提供子字段
- 把每个接口的 5 类参数（headerParams / queryParams / pathParams / requestBody / responseBody）正确分组
- 如果文本中信息不足（如缺接口名、缺类型），用 `AskUserQuestion` 询问用户

把数组写到一个临时 JSON 文件，例如 `/tmp/apis.json`。

### Step 2: 校验/归一化

```bash
node scripts/validate.mjs --list-file /tmp/apis.json > /tmp/validated.json
```

成功时输出：
```json
{ "ok": true, "domain": "http://example.com",
  "normalized": [/* ExtractedApiInfo[] */],
  "warnings": ["..."] }
```

失败时（exit code 1）输出 `{ "ok": false, "errors": [...] }`，agent 应：
1. 阅读 errors 数组定位问题
2. 修正提取结果（或用 `AskUserQuestion` 让用户补充）
3. 重新跑 validate

把 `normalized` 字段（已归一化的 `ExtractedApiInfo[]`）写到新文件，例如 `/tmp/apis-normalized.json`，**Step 4 直接用这份**。

### Step 3: 域名定位分组

#### 3a. 域名缺失或多选

如果 `domain` 是 null，或者用户文档里有**多个候选域名**（生产/测试/预发等），必须先用 `AskUserQuestion` 让用户**单选一个**。Skill 不假设默认值。

⚠️ **严禁**给出"两个都注册""分别建两个分组"之类的多选项（详见 SKILL.md "关于域名选择"小节）。每次 skill 调用**只对一个域名负责**，多域名同时录入是反模式（数据冗余、后续维护成本翻倍）。

#### 3b. 查询分组

```bash
node scripts/list-apps.mjs --domain "http://example.com" > apps.json
```

根据 `matched` 字段分支：

**matched = 0：用户三选一**

用 `AskUserQuestion` 让用户**单选**：

1. **创建新 App**（基于当前 domain）
   - 询问 appName / appCode（仅英文字母+数字）
   - check-app 校验是否被占用
   - create-app 新建
   ```bash
   node scripts/check-app.mjs --name "myapp" --code "myappcode"
   node scripts/create-app.mjs --domain "..." --appName "myapp" --appCode "myappcode"
   ```

2. **使用一个已存在的 App**（domain 不一样也没关系）
   - 让用户给关键字
   - `search-apps --pattern <关键字>` 模糊搜索
   - 把结果列给用户选 → 拿到 appId
   ```bash
   node scripts/search-apps.mjs --pattern "iot"
   ```

3. **取消注册**

> 💡 提醒用户：如果选 2，注册到的 App 域名可能和文档不一致 —— **这是正常的**，
> App 的 domain 字段是元数据，接口本身只关心 URI。如果用户想改 App 的域名，
> 应该去集成中心后台手动改（详见 SKILL.md "When NOT to use this skill"）。

**matched = 1：直接使用**

无需询问，直接 `targetAppId = apps[0].id`。

**matched > 1：让用户选**

用 `AskUserQuestion` 列出多个候选分组（含 ID、名称、接口数），让用户选一个。

### Step 4: 批量注册（**一次搞定**）⭐

把 Step 2 归一化后的 `ExtractedApiInfo[]` 完整写到一个 JSON 文件，**一次性**调用 `register-apis.mjs`：

```bash
# 把 normalized 数组写到文件（agent 用 Write 工具）
write_file('/tmp/apis-normalized.json', JSON.stringify(normalized_list))

# 一把梭
node scripts/register-apis.mjs --appId 36087 --list-file /tmp/apis-normalized.json
```

**脚本内部做的事情**（你不需要操心）：
1. 一次性拉 App 完整信息（含已有的 apis + structures）
2. 构造 `StructureRegistry`：把后端 structures 的 (name, shape) 信息装进去
3. 对每个 api：
   - 按 `(uri, method)` 在 `App.apis` 里查找
     - 命中 → POST /fast 新建 + DELETE 旧 apiId（语义上 = update，但 apiId 会变）
     - 未命中 → POST /fast 创建新接口
   - 构造请求时通过 Registry 决定 Structure 用什么名字：
     - 同名同 shape → 复用（不重传 properties，省一份重复 Structure）
     - 同名不同 shape → rename 为 `_1` / `_2`
     - 新名 → 直接用
   - 单接口失败不影响其他接口（best-effort）

**输出结构**：
```json
{
  "appId": 36087, "appName": "myapp",
  "summary": { "total": 4, "created": 2, "updated": 2, "failed": 0 },
  "results": [
    { "uri": "/x", "method": "GET",  "status": "created", "apiId": 305000 },
    { "uri": "/y", "method": "POST", "status": "updated", "apiId": 305001,
      "previousApiId": 304945 },
    ...
  ],
  "structures": {
    "reused":  ["UserInfo", "Datetime"],
    "renamed": [{ "from": "Result", "to": "Result_1", "reason": "..." }],
    "created": ["DeviceVO"]
  },
  "warnings": ["旧 apiId 304947 删除失败：..."]
}
```

#### 单接口场景

如果**真的**只有 1 个接口要注册/更新，可以用 `register-api.mjs` / `update-api.mjs`。
它们内部也走 `register-apis` 的逻辑（batch=1）。

> ❌ **错误的做法**：拆成多次 `register-api` 调用来注册多个接口。
> 这会让每次调用都是独立的 StructureRegistry 上下文，无法跨接口去重，
> 产生 `UserInfo / UserInfo_1 / UserInfo_2` 等堆积。

### Step 5: 整理摘要给用户

读取 `register-apis` 的 stdout JSON，按 `results[]` 整理给用户的可读报告：

```
✅ 新增 2 个：GET /api/v1/users (id=305000), POST /api/v1/orders (id=305002)
🔄 更新 1 个：POST /api/v1/users (id=305001, 旧 id=304945 已删)
❌ 失败 1 个：PUT /api/v1/refund - 错误：...

数据结构（共 5 个被处理）：
  ✓ 复用现有：UserInfo, Datetime
  ✓ 新建：DeviceVO, OrderDetail
  ⚠ 因命名冲突重命名：Result → Result_1

⚠ Warning：旧 apiId 304947 删除失败（手动检查）
```

如果有 `warnings`，**务必告知用户**，他们可能需要去网关 UI 手动清理。

---

## 边界情况处理

### 单个接口失败

`register-apis` 是 best-effort：单个 api 失败会在 `results[]` 里标记为 `status: "failed"`，
其他 api 仍照常处理。**不要因为一个失败就放弃整批**。

agent 应：
- 看清失败的 api 是哪个、错误是什么
- 用 `AskUserQuestion` 让用户决定：跳过 / 让 agent 修正后重试

### Update（实际是 delete+create）的副作用

`status: "updated"` 时，`apiId` 是**新的** id，`previousApiId` 是旧的（已删）。
如果 `oldDeleted: true` 且 `status: "failed"`，说明旧版本已被自动清理但新版本没建成功 →
agent **必须提醒用户**：这个接口暂时不在集成中心里，**重跑脚本即可恢复**（届时会按"新建"处理）。

### Structure 命名

由 `StructureRegistry` 全自动处理，**agent 不需要操心**：
- 同名同字段 → 复用现有 Structure
- 同名不同字段 → 自动 rename 为 `_1` / `_2`
- 系统类型（Datetime / Date 等）→ 当作已存在的 reference，不重建

如果发生 rename，会在 `structures.renamed` 字段里说明。

### 网络/集成中心 5xx 错误

`scripts/shared/openApiAuthClient.mjs` 默认超时 60 秒。失败时单个 api 标 `failed`，
agent 应：
- 把错误信息告知用户，**不要自动循环重试**（可能被风控）
- 用 `AskUserQuestion` 让用户决定是否重试
- 重试时再跑一次 `register-apis`（带相同的 list，已成功的会被识别为"update"路径，幂等的）

---

## 完整调用示例（agent 视角的伪代码）

```text
# 1. 阅读用户输入（粘贴文本或上传文件），自行提取 ExtractedApiInfo[]
extracted = self.extract_apis_from(user_input)
write_file('/tmp/apis.json', json.dumps(extracted))

# 2. 校验
validated = bash('node scripts/validate.mjs --list-file /tmp/apis.json')
if not validated.ok:
    handle_errors_and_retry(validated.errors)
write_file('/tmp/apis-normalized.json', json.dumps(validated.normalized))
domain = validated.domain

# 3. 处理 domain 缺失
if not domain:
    domain = ask_user_question('请提供域名')

# 4. 查分组
apps = bash(f'node scripts/list-apps.mjs --domain "{domain}"')
if apps.matched == 0:
    name = ask_user_question('请输入API分组名')
    code = ask_user_question('请输入 appCode（英文+数字）')
    bash(f'node scripts/check-app.mjs --name "{name}" --code "{code}"')   # 一次校验两个
    app = bash(f'node scripts/create-app.mjs --domain "{domain}" --appName "{name}" --appCode "{code}"')
    app_id = app.appId
elif apps.matched == 1:
    app_id = apps.apps[0].id
else:
    app_id = ask_user_question('请选择目标分组', options=apps.apps).id

# 5. 批量注册 —— ★ 一把梭，不要拆 ★
result = bash(f'node scripts/register-apis.mjs --appId {app_id} --list-file /tmp/apis-normalized.json')

# 6. 整理摘要给用户
report_to_user(result.summary, result.results, result.structures, result.warnings)
```
