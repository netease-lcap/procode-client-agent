/**
 * create-app.mjs — 在集成中心创建新分组
 *
 * Usage:
 *   node scripts/create-app.mjs --domain "http://example.com" --appName "myapp" --appCode "myappcode"
 *
 * Output (stdout):
 *   {
 *     "appId": 36087,
 *     "appName": "myapp",
 *     "appCode": "myappcode",
 *     "domain": "http://example.com"
 *   }
 *
 * 注意：
 *   - 调用前 AI 应已通过 check-app.mjs 确认 appName/appCode 都可用
 *   - 后端 owner 字段会自动取 CW_TENANT 环境变量
 *   - 创建成功后会再次按域名查询拿到 appId（HttpAppController#newHttpApp 不返回 id）
 */
import { parseArgs, requireString, output, info, fail, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const domain = requireString(args, 'domain');
  const appName = requireString(args, 'appName');
  const appCode = requireString(args, 'appCode');

  if (!/^[a-zA-Z0-9]+$/.test(appCode)) {
    fail(`appCode 只能含英文字母和数字，收到: ${appCode}`);
  }

  const skill = new RegisterSkill();

  info(`构建创建请求并校验唯一性...`);
  // 校验 appName 唯一
  const nameOk = await skill.checkAppNameAvailable(appName);
  if (!nameOk) fail(`appName [${appName}] 已被占用`);
  // 校验 appCode 唯一
  const codeOk = await skill.checkAppCodeAvailable(appCode);
  if (!codeOk) fail(`appCode [${appCode}] 已被占用`);

  info(`调用集成中心创建分组 [${appName}]...`);
  const req = skill.buildCreateAppRequest(domain, appName, appCode);
  await skill.createApp(req);

  // 创建后二次查询拿 id
  info(`查询新分组的 ID...`);
  const apps = await skill.getAppsByDomain(domain);
  const found = apps.find((a) => a.appName === appName);
  if (!found) fail(`分组 [${appName}] 创建后查询失败，请手动确认`);

  output({
    appId: found.id,
    appName: found.appName,
    appCode,
    domain,
  });
});
