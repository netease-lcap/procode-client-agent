/**
 * list-apps.mjs — 按域名查询集成中心已注册的分组列表
 *
 * Usage:
 *   node scripts/list-apps.mjs --domain "http://example.com"
 *
 * Output (stdout):
 *   {
 *     "matched": 2,
 *     "apps": [
 *       { "id": 36087, "appName": "...", "appCode": "...",
 *         "apiCount": 5,
 *         "apis": [ { "id":1, "uri":"/...", "requestMethod":"GET", "apiName":"..." }, ... ] }
 *     ]
 *   }
 *
 * 用途：AI 代理在注册接口前，先查域名是否已存在分组，根据 matched 决定下一步：
 *   - matched === 0  → 调用 create-app.mjs 创建新分组
 *   - matched === 1  → 直接使用 apps[0].id
 *   - matched > 1    → 询问用户选择
 */
import { parseArgs, requireString, output, info, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const domain = requireString(args, 'domain');

  info(`查询域名 [${domain}] 匹配的分组...`);
  const skill = new RegisterSkill();
  const apps = await skill.getAppsByDomain(domain);

  info(`匹配到 ${apps.length} 个分组`);

  // 输出精简结构，避免过大 JSON 影响 AI 解析
  output({
    matched: apps.length,
    apps: apps.map((a) => ({
      id: a.id,
      appName: a.appName,
      appCode: a.appUniqueId?.appCode ?? null,
      appType: a.appType,
      appSource: a.appSource,
      owner: a.owner,
      description: a.description,
      apiCount: (a.apis ?? []).length,
      apis: (a.apis ?? []).map((api) => ({
        id: api.id,
        uri: api.uri,
        requestMethod: api.requestMethod,
        apiName: api.apiName,
        apiCode: api.apiCode,
      })),
      structureCount: (a.structures ?? []).length,
    })),
  });
});
