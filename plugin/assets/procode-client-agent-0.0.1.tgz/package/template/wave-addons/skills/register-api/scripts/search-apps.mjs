/**
 * search-apps.mjs — 按关键字模糊搜索 App
 *
 * 用途：当用户想把接口注册到一个**已存在**的 App，但：
 *   - 文档里的 domain 和 App 实际配置的 domain 不一样（list-apps 找不到）
 *   - 或者用户根本不记得 domain，只记得 App 名字 / 标识
 * 的时候，用关键字模糊搜索定位 App。
 *
 * Usage:
 *   node scripts/search-apps.mjs --pattern "iot"
 *   node scripts/search-apps.mjs --pattern "device"
 *   node scripts/search-apps.mjs --pattern ""        # 空字符串=列租户下所有 App（会被 limit 截）
 *   node scripts/search-apps.mjs --pattern "iot" --limit 100
 *
 * 模糊匹配范围：appName + appCode + domain（后端 SQL LIKE 实现）
 *   - 给关键字 `"device"` → 命中名字含 device 的 App
 *   - 给域名片段 `"iot-platform.com"` → 命中 domain 含该片段的 App
 *
 * Output (stdout):
 *   {
 *     "matched": 3,            // 本次返回的 App 数
 *     "total": 3,              // 后端 SQL count(*)，用于判断是否被 limit 截断
 *     "pattern": "iot",
 *     "apps": [
 *       { "id": 36582, "appName": "IoT设备管理-local",
 *         "appCode": "iotDeviceManagement",
 *         "appType": "HTTP", "appSource": "external",
 *         "owner": "cstest",
 *         "description": "...",
 *         "domains": ["http://localhost:8080"]   // 把 domain[].domain 拉平成字符串数组
 *       }
 *     ]
 *   }
 *
 * 注意：search 出来的 App 对象**不**包含完整的 apis[] / structures[]（list 端点固定返回空数组）。
 *       要拿完整信息（注册接口前），必须用 appId 调用 getAppById（register-apis.mjs 内部会自动这么做）。
 */
import { parseArgs, optionalString, output, info, fail, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const pattern = optionalString(args, 'pattern') ?? '';
  const limitStr = optionalString(args, 'limit');
  // 默认 10000 一次拉完，避免分页（后端默认 20，太小）
  const limit = limitStr ? Number(limitStr) : 10000;

  if (!Number.isFinite(limit) || limit <= 0) {
    fail('--limit 必须是正整数');
  }

  info(`搜索 App：pattern="${pattern}"，limit=${limit}...`);
  const skill = new RegisterSkill();
  const { appCount, appList } = await skill.searchAppsByPattern(pattern, { limit });

  info(`匹配到 ${appList.length} 个 App（后端 total=${appCount}）`);

  // 把每个 App 转成精简结构，避免 JSON 太大
  // 字段映射依据：/openapi/v3/portal/app/list 真实 response（顶层 appCode、domain[].domain）
  // 注意：list 端点的 apis[] / structures[] 始终为空数组，要拿这些数据请用 getAppById
  const apps = appList.map((a) => ({
    id: a.id,
    appName: a.appName,
    appCode: a.appCode ?? null,
    appType: a.appType ?? null,
    appSource: a.appSource ?? null,
    owner: a.owner ?? null,
    description: a.description ?? null,
    domains: (a.domain ?? []).map((d) =>
      typeof d === 'string' ? d : (d?.domain ?? null),
    ).filter(Boolean),
  }));

  const result = {
    matched: apps.length,
    total: appCount,
    pattern,
    apps,
  };

  // 提示用户：如果 total > matched，可能被截断
  if (appCount > apps.length) {
    info(`⚠ 后端总匹配数 ${appCount} 多于本次返回 ${apps.length} 条，请用更具体的 pattern 缩窄结果`);
  }
  // 大量命中时给 agent 一个明显信号，让它去问用户更具体的关键字
  if (apps.length > 30) {
    info(`⚠ 命中 ${apps.length} 个 App，请让用户提供更具体的关键字（建议 ≤ 30 条再展示）`);
  }

  output(result);
});
