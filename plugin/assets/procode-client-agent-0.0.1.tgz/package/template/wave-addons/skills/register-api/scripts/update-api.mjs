/**
 * update-api.mjs — 更新已存在的接口
 *
 * 注：本脚本是 register-apis.mjs 的便捷包装。内部实际是 **POST /fast 新建 + DELETE 旧 apiId**
 * （不再走旧的 PUT /openapi/v3/portal/httpApi 端点，因为它处理 reference 类型时容易 500）。
 *
 * 对外契约不变：你提供 apiId + appId + api JSON，脚本帮你"更新"到新内容。
 * agent 视角看到的就是一次 update。
 *
 * Usage:
 *   node scripts/update-api.mjs --apiId 1234 --appId 36087 --api-json '{...}'
 *   node scripts/update-api.mjs --apiId 1234 --appId 36087 --api-file path/to/api.json
 *
 * Output (stdout):
 *   { "updated": true, "apiId": 1235, "previousApiId": 1234, "uri": "...", "requestMethod": "POST" }
 *
 *   - apiId 是新建后的新 id（旧 1234 已被删）
 *   - previousApiId 是传进来的旧 id（仅供参考）
 *   - 若旧 id 删除失败但新建成功，会在 warnings 里说明，updated 仍为 true
 *
 * **多接口场景请用 register-apis.mjs**，能让 Structure 命名跨接口协调。
 */
import { parseArgs, requireNumber, readJson, output, info, fail, runScript } from './shared/lib.mjs';
import { RegisterSkill } from './shared/registerSkill.mjs';

await runScript(async () => {
  const args = parseArgs();
  const apiId = requireNumber(args, 'apiId');
  const appId = requireNumber(args, 'appId');
  const api = readJson(args, 'api');

  if (!api.uri) fail('api JSON 缺少必填字段 "uri"');
  if (!api.requestMethod) fail('api JSON 缺少必填字段 "requestMethod"');

  const normalized = {
    apiName: api.apiName ?? null,
    uri: api.uri,
    requestMethod: api.requestMethod,
    description: api.description ?? null,
    domain: api.domain ?? null,
    headerParams: api.headerParams ?? [],
    queryParams: api.queryParams ?? [],
    pathParams: api.pathParams ?? [],
    requestBody: api.requestBody ?? [],
    responseBody: api.responseBody ?? [],
  };

  const skill = new RegisterSkill();

  info(`更新接口 [${normalized.requestMethod} ${normalized.uri}] (旧 apiId=${apiId}, appId=${appId})...`);
  const batchResult = await skill.registerApis(appId, [normalized]);
  const r = batchResult.results[0];

  if (r.status === 'failed') {
    info(`✗ 失败: ${r.error}`);
    output({
      updated: false,
      uri: r.uri,
      requestMethod: r.method,
      error: r.error,
    });
    process.exit(1);
  }

  // 把传入的 apiId 也带出来供 agent 参考（虽然 r.previousApiId 才是实际删的那个）
  for (const w of batchResult.warnings) info(`⚠ ${w}`);

  if (r.status === 'updated') {
    info(`✓ 更新成功（新 apiId=${r.apiId}, 旧 apiId=${r.previousApiId} 已删除）`);
  } else {
    // 没找到同 uri+method 的旧接口，相当于新建。给个 info 说明，agent 可以决定如何处理
    info(`⚠ App ${appId} 下没找到 [${r.method} ${r.uri}] 这条接口，已按"新建"处理（实际是 created 不是 updated）`);
  }

  output({
    updated: true,
    apiId: r.apiId,
    uri: r.uri,
    requestMethod: r.method,
    requestedApiId: apiId,
    ...(r.previousApiId !== undefined
      ? { previousApiId: r.previousApiId }
      : { note: 'no matching api found by uri+method; created as new' }),
  });
});
