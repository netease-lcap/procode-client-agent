---
name: manage-middleware
description: |
  仅在 **AI 对话阶段** 处理中间件连接配置的读取 / 新增 / 修改（不介入 speckit 宏观自动执行阶段）。
  覆盖的中间件：Redis、消息队列 MQ、对象存储（MinIO / NOS）、数据库（MySQL 等）、Elasticsearch（ES）等。
  当用户在对话中表达以下任一意图时先加载本 skill：
  「接入 / 新增 / 配置 / 修改 / 切换某个中间件连接」「查看 / 读取当前中间件连接信息」
  「把 Redis 改成集群 / 哨兵」「换一个 MySQL 实例」「接入消息队列 MQ」「配置 MinIO / NOS 对象存储」
  「接入 ES / Elasticsearch」；对话中「当前设计方案里要用到某中间件」时也加载本 skill。
  英文触发：「add / configure / update a redis / mysql / mq / minio / nos / elasticsearch connection」等。
  本 skill 是中间件配置的**编排层**：负责意图归一、按类别分派执行、据执行结果驱动后续对话；不生成业务代码；禁止关键词匹配，按语义判断。
  执行分两套契约：**数据库类（仅 MySQL / PostgreSQL / SQL Server / Oracle 四种，MySQL 不限版本）按 `datasource-contract` 流程编排，其余数据库拦截转平台侧；非数据库类型（redis / mq / minio / nos / es 等）按 `middleware-contract` 流程编排**。
  **设计期对话额外围栏**：数据库类仅允许「配置信息查询」与「同一数据库类型的连接信息修改」；严禁新增数据库类型、严禁更换数据库类型。
license: Apache-2.0
allowed-tools:
  - Bash
  - Read
  - Grep
  - AskUserQuestion
---

# manage-middleware（对话内中间件配置 · 编排层）

本 skill 在 **AI 对话阶段** 编排中间件连接配置的读取 / 新增 / 修改 / 删除。它是**外围编排层**：
真正的增删改查由**两套内置执行 skill**完成——**数据库类**由 **`datasource-contract`** 完成（IDE 侧选型、
平台回填配置、建映射、落盘、复验）；**其余类型**由 **`middleware-contract`** 完成（弹窗收集配置、网络打通、
落盘、置终态）。本 skill 负责其之外的一切——意图归一、**按类别分派到对应契约**、读回终态判定成败、
并据结果驱动后续对话流程。

> **调用纪律**：`middleware-contract`（other 类）与 `datasource-contract`（database 类）是本 skill 的
> 内置执行工具，**只能由本 skill 编排调用**。agent 不得在对话中越过本 skill 直接加载它们。

## 硬围栏

中间件连接信息的**增 / 删 / 改 / 查**必须严格走本 skill 编排 + 对应契约（`datasource-contract` / `middleware-contract`）执行的完整闭环。以下行为一律禁止：

1. **禁止自建 / 自起中间件实例**
2. **禁止臆测 / 自填连接值**
3. **应用级降级 ≠ 跳过配置**：运行期降级是业务容错设计，**绝不构成**跳过、简化或绕过本配置流程的理由

## When to use this skill

**前提：仅在 AI 对话阶段生效**（用户与 AI 自由对话的环节；不介入 speckit 宏观自动执行阶段）。在此前提下，用户意图涉及中间件连接配置的**读取 / 新增 / 修改**时加载本 skill。具体覆盖以下两类对话场景：

1. **设计期对话**（源码尚未生成）：workflow 里某个宏观阶段（如需求、技术设计）**走完后进入的对话环节**，用户在方案讨论中**明确要读 / 写某中间件连接配置**，或当前设计方案**明确要用到某中间件**。
2. **自由阶段对话**（源码已生成，进入 freePhase 后）：无论处于自由阶段的 **plan 对话**还是 **build 对话**，只要用户**明确要读 / 写某中间件连接配置**，都加载本 skill。

## 🚫 When NOT to use this skill

- **不在 AI 对话阶段**（speckit 宏观自动执行阶段）→ 本 skill 不介入
- 只是**询问 / 讨论**某中间件的用法、原理、选型（无"配置连接"诉求）→ 正常回答，不加载本 skill
- 要求**编写使用该中间件的业务代码**（连接配置已存在）→ 走正常编码流程，本 skill 不介入

## Workflow(编排六步：A 归一 → B 分类分派 → B2 前置澄清 → C 执行 → D 判成败 → E 分支)

被加载后，按以下顺序执行。契约工具落点固定 **`$HOME/resources/.manifest/`**（不跟 cwd；HOME 缺失 exit 2），worktree checkout 里同样写 resources 那一份。

### Step A · 归一化本次操作

从对话意图解析以下维度：

- `operation ∈ { add, update, delete, query }`（新增 / 修改 / 删除 / 查询，与两套契约的四场景 / 四操作流一一对应）
- `middlewareType`：用户所指中间件真实类型名（如 `mysql` / `redis` / `kafka`）。数据库类在表 1 归一为 `databaseType`（`mysql`→`mysql`、`postgres`→`postgresql`、`sqlserver`/`mssql`→`sqlserver`、`oracle`→`oracle`）。**MySQL 不锁版本**：用户明确版本时用对应平台标识（MySQL 8→`mysql8`、5.7→`mysql`），未明确则用 `mysql`。此值即条目最终 `databaseType`（透传机制见 Step C-2）。
- `phase ∈ { design, free }`：本轮对话所处阶段——`design`=设计期对话（源码尚未生成）；`free`=自由阶段对话（源码已生成，进入 freePhase 后的 plan / build）。用于 Step B 的**设计期数据库围栏（表 2b）**判定。
- `typeChange`（仅 `operation=update` 且 `category=database` 时解析）：本次修改是否**更换 `databaseType`**——如「把这个 MySQL 换成 PostgreSQL」为 `true`；仅改同一数据库类型的连接地址 / 账号 / 密码 / 库名等为 `false`。
- `name`：目标条目唯一名。
  - **新增（`other` 类）**：由本 skill **在此步先行确定**一个 name（多实例用 `redis-session` / `redis-01` 等区分），后续 Step C 必须让 `middleware-contract` **沿用同一 name**，不得另拟。
  - **新增（`database` 类）**：**不在此步预定 name**——`dataSourceName` 由 `datasource-contract` 操作流 1 的 IDE 侧选型流程产出（非自由命名）；本 skill 不预拟、不透传。
  - **修改 / 删除 / 查询单条**：用户所指的既有条目 name（`database` 类即既有 `dataSourceName`）。

### Step B · 分类与分派裁决

在**调用执行契约之前**先按类别定分派目标、并查拦截策略。裁决三态：**ROUTE→middleware-contract**、**ROUTE→datasource-contract**、**BLOCK**。命中 **BLOCK** 即**结束**——不加载任何契约、不进入后续对话流程、不弹窗。

**表 1 · 中间件分类识别（`middlewareType` → `category`，大小写不敏感；按下表自上而下**首次命中**，受支持数据库优先于类数据库兜底）**

| category | 命中规则（清单 / 正则） | 归一化 `databaseType` |
|---|---|---|
| `database`（**受支持 4 种**） | 清单：`mysql` / `postgres`(`postgresql`) / `sqlserver`(`mssql`) / `oracle`；正则 `/(mysql｜postgre｜sql\s*server｜mssql｜oracle)/i` | `mysql`→`mysql`；`postgres`→`postgresql`；`sqlserver`/`mssql`→`sqlserver`；`oracle`→`oracle` |
| `database-unsupported`（**类数据库但契约不支持**） | 上一行未命中、但属数据库类：`mariadb` / `tidb` / `oceanbase`(`ob`) / `dm`(达梦) / `clickhouse` / `mongodb`(`mongo`) / `db2` / `sqlite` 等；正则兜底 `/(maria｜tidb｜oceanbase｜clickhouse｜mongo｜db2｜sqlite｜dm[_-]?db)/i` | —（不进契约） |
| `other` | 以上均不命中（redis / kafka / rabbitmq / mq / s3 / minio / nos / elasticsearch(es) 等） | — |

**表 2 · 分派策略（`category` × `operation` → 裁决）**

| category | operation | 裁决 | 说明 / 固定话术 |
|---|---|---|---|
| `database` | `add` / `update` / `delete` / `query` | **ROUTE→datasource-contract** | 放行走数据源契约（四操作流）；**若 `phase=design` 必须先过表 2b 设计期围栏，通过后才 ROUTE** |
| `database-unsupported` | 任意 | **BLOCK** | 「对话内数据库配置当前仅支持 MySQL / PostgreSQL / SQL Server / Oracle 四种。」 |
| `other` | 任意 | **ROUTE→middleware-contract** | 放行，进入 Step C 走中间件契约（四场景） |

**表 2b · 设计期数据库围栏（仅当 `phase=design` 且 `category=database` 时生效；`phase=free` 自由阶段不受此表约束，直接按表 2 放行）**

设计期严禁改动数据库拓扑：**禁止新增数据库类型、禁止更换数据库类型**；只放行「配置信息查询」与「同一数据库类型的连接信息修改」。

| operation | 条件 | 裁决 | 固定话术                                                                     |
|---|---|---|--------------------------------------------------------------------------|
| `query` | — | **ROUTE→datasource-contract** | 放行，走操作流 2 / 4（读回数据源配置 / 消费地址）                                            |
| `update` | `typeChange=false`（同类型改连接信息） | **ROUTE→datasource-contract** | 放行，走操作流 3（仅改连接地址 / 账号 / 密码 / 库名等，不动 `databaseType`）                      |
| `update` | `typeChange=true`（更换 databaseType） | **BLOCK** | 「当前阶段不支持更换数据库类型（如 MySQL ↔ PostgreSQL），仅可修改同一数据库类型的连接信息。」 |
| `add` | — | **BLOCK** | 「当前阶段不支持新增数据库类型 / 数据源，请沿用当前设计方案中已有的数据源。」                                 |
| `delete` | — | **BLOCK** | 「当前阶段不支持删除数据源。」                                                           |

> **维护提示（改表不改正文）**：新支持某库→从 `database-unsupported` 挪进 `database` 并补归一映射；新增分派→改表 1 命中规则 + 表 2 对应行；收紧/放开某操作→改该行裁决（BLOCK↔ROUTE）；设计期范围→只改表 2b（`phase=free` 恒不受其约束）。`operation` 固定四值，勿加别名。

### Step B2 · 前置澄清（按类型 / 操作驱动，可扩展）

部分中间件**新增**时有"子类型 / 部署模式"分叉，对应 `middleware-contract` 里**不同的表单模版与 endpoint 族**。必须在调用契约**之前**用 `AskUserQuestion` 把分叉澄清定下、记为 `variant`，契约才能走对模版。查下表：命中→先澄清再进 Step C；未命中→直接进 Step C。

**表 3 · 前置澄清策略（`category`(或 `middlewareType`) × `operation` → 澄清维度）**

| 匹配（type/category × operation） | 澄清维度 | `AskUserQuestion` 选项 | 结果 `variant` → 传给 middleware-contract 的语义 |
|---|---|---|---|
| `redis` × `add` | Redis 部署模式 | 单机 / 哨兵(Sentinel) / 集群(Cluster) | `standalone` → endpoint 族 `host-port`；`sentinel` → `node-list`(role=sentinel，需 masterName)；`cluster` → `node-list`(role=cluster) |
| （其余 type × operation） | — | — | 未命中：跳过前置澄清，直接进 Step C |

- **仅 `add` 需澄清**；`database` 类无澄清（`databaseType` 在 Step A 已定，配置靠 IDE 选型产出）。`update` 因契约会先 `get` 读回、模式已知而免澄清——除非用户明确要切换部署模式，此时按 `redis × add` 同规则澄清新模式。
- 澄清只定"**表单模版 / endpoint 族**"分叉；**具体连接字段（host/port/密码等）由 `middleware-contract` 动态表单收集**。`variant` 在 Step C 加载契约时透传。

> **维护提示（只加行不改正文）**：新增前置澄清→表 3 加一行（`type × operation → 维度 + 选项 + variant`）；`variant` 命名须与 `middleware-contract` 场景 1 的 endpoint 族一致；未命中=无需澄清，勿强加。

### Step C · 按分派目标加载对应契约执行

放行后，用 `skill` 工具加载 Step B 裁定的契约，按 `operation` 对应其场景 / 操作流完整执行。

**分派 C-1 · `other` 类 → `middleware-contract`（四场景）**

| operation | middleware-contract 场景 |
|---|---|
| `add` | 场景 1 新增 |
| `update` | 场景 2 修改 |
| `delete` | 场景 3 删除 |
| `query` | 场景 4 查询与消费 |

- 动态表单收集配置、`map-add` 网络打通、`upsert` 落盘、`set-status` 置终态等细节**全部交由 `middleware-contract` 负责**，本 skill 不重复实现。
- **name 透传（新增场景关键）**：加载时明确告知「本次条目 name = `<Step A 的 name>`，场景 1 步骤 1 必须用该 name 拼条目，不得另拟」，确保 Step D 的 `get --name` 能命中。
- **variant 透传（若 Step B2 有澄清结果）**：加载时明确告知「本次 `<middlewareType>` 的部署模式/子类型 = `<variant>`，场景 1 必须按对应 endpoint 族与表单模版拼条目/出表单」，确保走对模版。

**分派 C-2 · `database` 类 → `datasource-contract`（四操作流）**

| operation | datasource-contract 操作流 |
|---|---|
| `add` | 操作流 1 新增数据源（IDE 侧选型 → 平台回填 → 建映射 → 写条目 → 复验） |
| `update` | 操作流 3 修改（`get` 读回 → 改字段整条目 `upsert` → `validate`；端点变则 `map-ensure`） |
| `delete` | 操作流 3 删除（`delete --name`） |
| `query` | 操作流 2 查看 / 操作流 4 消费（`get` 呈现、`resolve` 取回环地址） |

- IDE 侧 `dataSourceSelect` 选型、平台回填连接配置、`map-ensure` 建映射、`upsert` 落盘、`validate` 复验等细节**全部交由 `datasource-contract` 负责**，本 skill 不代填连接参数、不出表单。
- **不透传 name / variant**：数据源 `dataSourceName` 由选型流程产出（新增场景本 skill 不预定）；改 / 删 / 查用既有 `dataSourceName`。
- **数据库类型透传**：加载时告知「本次 `databaseType = <Step A 归一后的 databaseType>`（`mysql` / `postgresql` / `sqlserver` / `oracle` 等，`mysql` 泛指不锁版本）」，作为 `register-prepare` / `register-commit` 的 `--type`——按契约 `--type` 是条目 `databaseType` 的**唯一来源**（`register-commit` 不消费平台响应里的 `databaseType`），平台仅在 `register-prepare` 做类型门（不支持 → `UNSUPPORTED_TYPE` 收尾），**不改写**该值；条目最终 `databaseType` 即此透传值。

### Step D · 读终态判成败（不依赖被调 skill 的自然语言输出）

契约执行完毕后，本 skill **统一用工具读回判定**（成败以退出码为准；`other` 类另看条目 `status`），按分派目标分表：

**判定 D-1 · `other` 类（`middlewares-tool.mjs get --name <name>`，看退出码 + `status`）**

| operation | 成功判定 | 失败判定 | 取消判定 |
|---|---|---|---|
| `add` / `update` | `status = ok` | `status = failed`（读 `lastError` 作失败原因） | `status = init`（未提交）或用户中途取消 |
| `delete` | `get` 返回 exit 4（条目已不存在 = 删成功） | 其余异常退出码 | —（delete 无表单，通常无取消） |
| `query` | `get` / `get --name` exit 0 正常读回 | exit 3 文件损坏（联系平台） | — |

**判定 D-2 · `database` 类（`datasource-tool.mjs`，无状态机，纯看退出码）**

| operation | 成功判定 | 失败判定 | 取消判定 |
|---|---|---|---|
| `add` / `update` | `upsert` exit 0 且复验 `validate` exit 0 | exit 3 校验失败（读 stdout `errors` 作原因）；exit 5 落盘失败（联系平台） | 用户在 IDE 选型 / 改配置环节中途取消（add 未产出 `dataSourceName`；update 未回填新配置）→ 保持原条目不变 |
| `delete` | `delete --name` exit 0 | 其余异常退出码 | exit 4 = 条目不存在（幂等无害，非失败） |
| `query` | `get` / `resolve` exit 0 正常读回 | exit 3 文件 / 映射损坏（联系平台） | — |

> **`resolve` exit 4 两义（消费路径必看 stderr 首行）**：首行「未找到数据源条目」= 条目不存在 → 转 `add`（操作流 1）；首行「映射缺失」= 条目在但通道未建 → 先 `map-ensure --real-endpoint <host:port>` 再 `resolve`，**不要**重跑新增。

### Step E · 结果分支

- **成功**：继续后续 AI 对话流程 ——
  - 源码**已生成**（freePhase / techImplement 等编码期）→ 驱动**改代码**接入 / 使用该中间件 / 数据源。写项目配置取消费地址：`other` 类用 `middlewares-tool.mjs map-get`、`database` 类用 `datasource-tool.mjs resolve`（均写 `127.0.0.1:<loopbackPort>`）。
  - 源码**未生成**（设计期 design / plan）→ 驱动**改设计方案**纳入该中间件 / 数据源。
- **失败**：把 `lastError` / `errors` / 失败原因**回话用户**（不可恢复失败沿用「请携带该错误信息联系平台」口径），不进入后续流程。
- **取消 / 拦截**：按各自话术收尾，不进入后续流程。
