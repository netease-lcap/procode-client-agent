---
name: deploy-contract
description: 当识别或更新项目部署服务、维护业务入口、遇到部署边界歧义、注册命名端口或恢复 Sandbox 预览时使用。
---

# 部署契约操作手册

工作空间根执行`node .specify/scripts/javascript/deploy-tool.mjs`。权威文件`.manifest/deploy.json`，具体参数先读`help manifest`和`help <command>`。

本地无 Sandbox/LCAP 联调在 Workflow/服务启动环境设置 `DEPLOY_EXTERNAL_MODE=local-mock`，生成的 CLI 子进程继承即可；契约按项目工作空间根自动选择跨进程共享的系统临时状态目录。mock 下 `previewStatus=synced` 仅表示模拟目标已保存，不代表真实预览、Ingress 或服务可访问。未显式开启 mock 时仍使用真实外部工具；直接执行外部 `sbx-inbound`/`platform-tool` 不受该开关接管。

## 核心原则

先get并保留完整stdout作为分析基线，逐字复用已有serviceName，只更新证据明确的服务；未扫描到不等于删除。服务按实际进程/交付边界区分，不按页面数量拆。
构建、脚本、产物、端口和入口来自设计与真实工程；可选未知字段省略。只有用户能够回答的业务事实或外部访问意图歧义才提供有证据候选，让契约组装ask；服务拆分/合并、进程数量、serviceName、端口和脚本等技术问题不询问用户，无法推导时返回诊断。字段的正式消费语义以 `README.md` 为准，Agent 不为生码或发布方重新解释字段。
部署分析的输入是预填 Manifest 与需求／技术设计／工程事实；当前 Agent 负责分析，CLI 只执行确定性准备和提交，不自行调用模型。Workflow 的 TypeScript 接入使用 registerDeployServices(manifest, { context, analyze, ask, … })，宿主执行契约提供的只读分析任务；原型等已知流程使用 registerKnownManifest({ manifest, deleteServiceNames? }, options)，Agent 使用 register-known --input '<完整目标JSON>'，均按 serviceName 注册、完整更新或显式删除整个服务，不调用 AI/ask；删除不停止进程或释放 Sandbox 入站映射。TypeScript 只读完整内容使用 index.ts 的 getDeployManifest({ cwd })，Agent 用不带 --service-name 的 deploy-tool get。协议归一化、端口登记、Manifest 保存和预览同步仍由契约统一执行；不自行维护另一套候选规则。
真实模式身份固定从环境读取：`APP_ID → appId`、`PRD_ID → collaborationId`、`CURRENT_BRANCH → branchName`；这些执行上下文不写入 Manifest。Sandbox 入站 path/inboundBasePath 与 Portal 返回的服务 domain 也属于运行/平台结果，不写入 Manifest；`runtime.ports[].connectPort` 首次由登记闭环写入，后续由 `runtime-sync` 或显式 `repair-port` 修复操作更新。
入站登记按每服务唯一 HTTP 端口执行 `sbx-inbound set -p <port> -k <serviceName>`；复用和 runtime-sync 按 key 核对监听端口。gRPC/TCP 可在 Manifest 声明已知监听值，但不申请入站、不回填 connectPort；无 HTTP 端口则跳过，多 HTTP 端口在外部操作前失败。LCAP 按 serviceName 关联一个入站地址，public 页面和 API 进入 Portal Ingress/预览；public 非 HTTP 外部入口、多外部端口仍在副作用前返回能力诊断。已有公开入口被移除时会同步空目标清理 Portal 端信息和 Ingress。

需要读取当前协作可用服务域名时，调用 deploy facade 的 `getDeployServiceDomains()`；真实模式读取 `APP_ID/PRD_ID/CURRENT_BRANCH`，通过 Portal `/internal/v3/cwportal/procode/proapp/preview-domains` 查询，mock 模式返回 fixture 或 `[]`，不调用 Portal。真实平台故障、鉴权失败和响应结构错误必须报错，不能伪装成空结果。结果中一个 `serviceName` 只出现一次；其 PC/H5/API 公开入口在 `endpoints[]`，含 `type/businessType/title/basePath/url`，服务级 `domain` 只含主机名，不猜测端口名。

## service识别与稳定名称

已有服务用目录、启动/构建入口、Dockerfile、职责共同匹配，沿用原名及大小写；真实拆分/合并才调整集合。导入源码时 `serviceName` 与 `sourceDir` 末段严格一致，不因目录名含大写字母、下划线或点号而改写。新生成名称仍优先使用小写字母、数字和连字符；项目内名称忽略大小写不得重复。
`serviceTitle` 由上游技术设计/架构分析确定并随 Manifest 传入；deploy 分析只沿用、校验和透传，不根据 `serviceName` 或 `description` 生成。标题、Path或端口改变不重新命名。多个匹配无法确认时准备候选，不猜边界。
PC/H5共享进程则一个service多个endpoints；独立前端进程各一条service；内部后端无外部入口仍登记命名端口。前端资源由后端同进程提供时入口归该服务，不额外造进程。

## Manifest结构

| 字段                         | 约束与含义                                                           |
| ---------------------------- | -------------------------------------------------------------------- |
| `services`                  | 必填；服务数组可为空                                               |
| `serviceName`                | 必填稳定逻辑主键；英文字母（可大写）、数字及中间的 `_`、`.`、`-`，首尾为字母或数字，最长 63 位；项目内忽略大小写唯一 |
| `serviceTitle`               | 必填非空服务语义标题，由上游技术设计/架构分析提供，不参与服务引用或端口匹配 |
| `serviceType`                | 必填 `frontend`、`backend` 或 `bff`；不从脚本、目录或架构文件推断    |
| `techStack`                  | 可选的服务级技术选型；一旦提供须完整包含 `language/framework/buildTool`，生码前条件字段见 README |
| `businessType`               | 可选 `application` 或 `prototype`；服务业务用途，省略归一化为 `application`，不从入口反推 |
| `description`                | 可选非空服务职责描述，用于上下文理解                                 |
| `apiBasePath`                | 服务 API 前缀；与是否暴露外部入口独立                                |
| `sourceDir`                  | 源码位置，相对项目根；可省略，`.`、`./`均合法                        |
| `build.script`               | 已确认的构建脚本入口                                                 |
| `build.outputs`              | 产物列表；每项`path`必填，可选`static`和`entryFile`                  |
| `imageBuild`                 | 独立镜像入口；业务登记省略时按 `deployName ?? serviceName` 补 Dockerfile 路径；`contextDir` 可省略，默认项目根 |
| `runtime.startScript`        | 实际启动脚本；契约不执行它                                           |
| `runtime.javaOpts`           | JVM 选项数组；仅 backend + Java + Spring Boot 由契约维护本服务 Nacos 参数 |
| `runtime.configFiles`        | `{name,templatePath,path,containerPath}` 数组；同一服务内 `name` 唯一，模板和生成路径相对项目根，容器路径为绝对 POSIX 路径 |
| `runtime.container`          | 可选 `{name,baseDir,port}`；Java WAR 生码前必需，port 须命中本服务命名监听端口 |
| `runtime.ports`              | 命名端口数组；业务登记省略整个数组时默认 `[{name:"http",protocol:"http"}]`，由契约分配并回填 `port/connectPort`；显式数组（含 `[]`）不改写，每服务最多一个 HTTP 端口，非 HTTP 端口不申请入站 |
| `runtime.http.contextPath`    | 应用自身的HTTP上下文路径，例如`/xxl-job-admin`；不等于`apiBasePath`或入口`basePath` |
| `runtime.healthCheck`        | `{script}`；业务登记后必有，省略时补为 `deploy/{serviceName}/scripts/health-check.sh`；不负责启动/构建 |
| `endpoints`                  | 入口数组，每项 `type/title/portName/basePath/exposure` 必填；`businessType` 可省略并按服务类型补齐；`exposure` 为 `public` 或 `internal` |
| `dependencies`               | 可选内部依赖数组；`serviceName/portName/requiredForStartup` 必填，协议从目标端口解析 |

`serviceType` 表达前端、后端或 BFF 的部署职责；服务级 `businessType` 表达原型或普通应用业务用途，一个原型服务可同时提供 PC/H5 页面入口。入口 `type` 为 `pc/h5/api`，入口级 `businessType` 为 `application/prototype`：PC/H5 省略时继承服务级值，显式值优先；API 省略时固定为 `application`，显式 `prototype` 不合法。旧 Manifest 若仅在入口标记 `prototype`，服务级仍归一化为 `application`，不从入口反推。`title` 是入口展示名称，不根据字段缺失推断。`public` 是南北向入口并参与 ingress/预览，`internal` 只供内部访问，不同步 LCAP。Manifest 是完整目标状态：若此前已有 public 入口、本次目标不再包含 public 入口，则同步空目标并清理旧端信息和 Ingress；首次仅登记内部服务时不触发外部同步，但已持久化的显式空 Manifest 在 `runtime-sync` 中会同步空目标用于清理旧端信息。仅为提供 API 的服务填写 `apiBasePath`，纯页面服务不因此补 API 字段；新生成 API 默认 `/api/{serviceName}/`；导入沿用已确认真实路径。它供生码使用，不代表开放入口；所有 `api` endpoint（无论 public 或 internal）都要求填写合法的 `apiBasePath`；`apiBasePath` 是生码使用的内部 API 路由前缀，`endpoint.basePath` 是 Ingress 匹配的对外路径，两者可以不同，内部 API 也可以只声明 `apiBasePath` 而不声明 endpoint。Ingress 保留请求路径，不会把 `/public/x` 自动改写为 `/api/x`；若实际接口是 `/api/x`，应确保公开路径允许该原始路径通过。

登记闭环及技术选型 facts 更新只为 backend + `techStack.language=java` + `techStack.framework=spring-boot` 维护按实际入站 key（普通模式为 `serviceName`，核实预置模式后为数字端口）生成的表达式 `-Dspring.cloud.nacos.discovery.port="$(sbx-inbound get-connect -k <key>)"`；适用服务须恰有一个 HTTP 命名端口。`connectPort` 未分配时也生成，仅 `connectPort` 回填时表达式不变；核实预置模式后按数字 key 更新。该 JVM 键由契约独占，旧数值或旧表达式统一替换，其他选项保留；缺少 `techStack` 时不推断，显式改为其他选型时移除该键。底层 `upsert` 不补做。`dependencies[].portName` 必须命中目标服务的 `runtime.ports[]`，`protocol` 只从目标命名端口读取；仅 `requiredForStartup=true` 的边参与启动依赖环检查。契约只保存和校验依赖意图，不启动进程。
Java `start.sh` 须无参数可启动；生码把受控 Nacos 表达式写入脚本的 `java` 与 `-jar` 之间，让 shell 在启动时查询 `sbx-inbound`，其他选项安全转义。现有 LCAP 仍按字面量传入 `runtime.javaOpts`，`"$@"` 不会二次执行 `$(...)`；脚本如转发参数，不得让重复的字面量 Nacos 参数覆盖动态结果。本次不修改 LCAP。
正式字段名包括 `endpoint.exposure`、`techStack`、`runtime.javaOpts`、`runtime.configFiles` 和 `dependencies`；字段完整规则、形成阶段与消费语义以 README 为准。

技术设计或配置事实生成流程调用 `update-service-facts --service-name <name> --facts <json-object>`；`facts.techStack` 须为完整对象，按服务整体替换；`facts.runtime` 支持 `configFiles:[{name,templatePath,path,containerPath}]` 增改和 `removeConfigFileNames:[name]` 删除，同名按 name 更新完整条目，新名追加，删除只影响明确列出的 name，同一 name 不能同时更新和删除。`templatePath` 和 `path` 必须是项目根相对路径，`containerPath` 必须是绝对 POSIX 路径。未知 service、非法 facts 或受保护字段在原子写入前失败；该命令不接受任意 Manifest patch，也不改写 `serviceType`、`ports`、`connectPort`、`dependencies` 或 `endpoints`；仅提交 `facts.techStack` 时可调整本服务契约生成的 Nacos `javaOpts`，仅更新配置文件不会调整。它不调用 Sandbox/LCAP；服务结构变化走完整登记。

文件路径全部相对项目根，禁止绝对路径和越界；`entryFile`必须位于该`static:true`产物目录内。路径校验不等于文件真实性检查。
`protocol`为`http/grpc/tcp`；同服务端口名唯一，已登记的 `port` 和 `connectPort` 数值分别在工作空间内唯一。同服务HTTP入口Path唯一，不同服务可以使用相同Path。
端口 `name` 必须以小写字母开头，只能使用小写字母、数字和短横线，最长 63 位；`port`/`connectPort` 是 1-65535 的整数，`connectPort` 不能脱离 `port` 单独出现。endpoint 的 `type`、`exposure` 必须使用表中枚举，`title` 非空；dependency 的目标 service 和 port 必须在同一 Manifest 中存在。
`basePath`补前导斜杠、去尾斜杠，根保留`/`，不含查询/Fragment/空白/反斜杠/空路径段/点路径段。
`build`、`runtime`及入口等可选信息按事实填写，省略不是“不需要该能力”。

示例是已登记的多个服务；首次数值可省略。两个前端进程分别承载入口，内部后端包含 HTTP/gRPC，并展示配置文件、应用上下文、内部 API、原型入口与 BFF 依赖：

```json
{
  "services": [
    {
      "serviceName": "teacher-web",
      "serviceTitle": "教师端",
      "serviceType": "frontend",
      "description": "教师 PC/H5 页面服务",
      "sourceDir": "apps/teacher",
      "build": {
        "script": "deploy/teacher-web/scripts/build.sh",
        "outputs": [
          {
            "path": "apps/teacher/dist",
            "static": true,
            "entryFile": "apps/teacher/dist/index.html"
          }
        ]
      },
      "imageBuild": {
        "dockerfile": "deploy/teacher-web/dockerfile/Dockerfile"
      },
      "runtime": {
        "startScript": "deploy/teacher-web/scripts/start.sh",
        "ports": [
          {
            "name": "http",
            "protocol": "http",
            "port": 6123
          }
        ],
        "healthCheck": {
          "script": "deploy/teacher-web/scripts/health-check.sh"
        }
      },
      "endpoints": [
        {
          "type": "pc",
          "title": "教师工作台",
          "portName": "http",
          "basePath": "/pc",
          "exposure": "public"
        },
        {
          "type": "h5",
          "title": "教师移动端",
          "portName": "http",
          "basePath": "/h5",
          "exposure": "public"
        }
      ]
    },
    {
      "serviceName": "student-web",
      "serviceTitle": "学生端",
      "serviceType": "frontend",
      "description": "学生独立前端服务",
      "sourceDir": "apps/student",
      "build": {
        "script": "deploy/student-web/scripts/build.sh",
        "outputs": [
          {
            "path": "apps/student/dist",
            "static": true,
            "entryFile": "apps/student/dist/index.html"
          }
        ]
      },
      "imageBuild": {
        "dockerfile": "deploy/student-web/dockerfile/Dockerfile"
      },
      "runtime": {
        "startScript": "deploy/student-web/scripts/start.sh",
        "ports": [
          {
            "name": "http",
            "protocol": "http",
            "port": 6124
          }
        ]
      },
      "endpoints": [
        {
          "type": "h5",
          "title": "学生移动端",
          "portName": "http",
          "basePath": "/",
          "exposure": "public"
        },
        {
          "type": "pc",
          "businessType": "prototype",
          "title": "学生原型入口",
          "portName": "http",
          "basePath": "/prototype",
          "exposure": "public"
        }
      ]
    },
    {
      "serviceName": "school-api",
      "serviceTitle": "教务服务",
      "serviceType": "backend",
      "description": "教务后端接口与内部 RPC 服务",
      "apiBasePath": "/api/school-api/",
      "sourceDir": "apps/api",
      "build": {
        "script": "deploy/school-api/scripts/build.sh",
        "outputs": [
          {
            "path": "apps/api/target/school-api.jar"
          }
        ]
      },
      "imageBuild": {
        "dockerfile": "deploy/school-api/dockerfile/Dockerfile"
      },
      "runtime": {
        "startScript": "deploy/school-api/scripts/start.sh",
        "configFiles": [
          {
            "name": "application",
            "templatePath": "generated/school-api/application.yml.tpl",
            "path": "generated/school-api/application.yml",
            "containerPath": "/app/config/application.yml"
          },
          {
            "name": "auth",
            "templatePath": "generated/school-api/application-auth.yml.tpl",
            "path": "generated/school-api/application-auth.yml",
            "containerPath": "/app/config/application-auth.yml"
          }
        ],
        "ports": [
          {
            "name": "http",
            "protocol": "http",
            "port": 6125,
            "connectPort": 7125
          },
          {
            "name": "grpc",
            "protocol": "grpc",
            "port": 6126
          }
        ],
        "javaOpts": [
          "-Xmx512m",
          "-Dspring.cloud.nacos.discovery.port=\"$(sbx-inbound get-connect -k school-api)\""
        ],
        "http": {
          "contextPath": "/school-api"
        },
        "healthCheck": {
          "script": "deploy/school-api/scripts/health-check.sh"
        }
      },
      "endpoints": [
        {
          "type": "api",
          "title": "教务内部 API",
          "portName": "http",
          "basePath": "/api/school-api/",
          "exposure": "internal"
        }
      ]
    },
    {
      "serviceName": "school-bff",
      "serviceTitle": "教务接口聚合服务",
      "serviceType": "bff",
      "description": "面向教师端的聚合后端",
      "sourceDir": "apps/bff",
      "runtime": {
        "startScript": "deploy/school-bff/scripts/start.sh",
        "ports": [
          {
            "name": "http",
            "protocol": "http",
            "port": 6127
          }
        ]
      },
      "dependencies": [
        {
          "serviceName": "school-api",
          "portName": "http",
          "requiredForStartup": true
        }
      ]
    }
  ]
}
```

## 部署文件

生成或适配目标：

```text
deploy/<serviceName>/
├── dockerfile/Dockerfile
└── scripts/
    ├── build.sh
    ├── start.sh
    ├── health-check.sh
    └── README.md
```

AI负责依据真实工程生成内容；导入项目的脚本可以委托现有能力，已有效文件先验证再复用。目录是生成约定，Manifest声明实际入口；不生成无意义占位文件。
Dockerfile与`build.sh`独立验收，不强制互调或重复构建；启动脚本前台运行并传递信号/退出码，不隐式构建；健康检查只读、有界，以0/非0表达结果。
执行方按保存端口传入`PORT_`+端口名大写、短横线转下划线，例如`PORT_HTTP`、`PORT_GRPC`、`PORT_HTTP_ADMIN`。应用原配置由启动/容器入口适配，字段不另设环境名。生产沿用监听值；契约不启动应用或发起生产发布。
静态产物是工程事实，`static:true`不代表部署模式；实际域名、CDN前缀、`deployId`及Ingress由平台管理。

## 命令契约

| 命令               | 参数与结果                                                                                                 |
| ------------------ | ---------------------------------------------------------------------------------------------------------- |
| `help`             | `[manifest\|<command>]`，多行可读文本；`--help/-h`为总帮助                                                 |
| `get`              | `[--service-name <name>]`，完整Manifest或一个服务；文件缺失返回 `{"services":[]}`，指定服务不存在退出 4 |
| `validate`         | `[--entry <service-json>] [--require-runtime] [--for-codegen]`；生码前检查完整 Manifest 时使用 `--for-codegen`，不得与 `--entry` 同用 |
| `upsert`           | `--entry <service-json>`，完整条目替换；同名且仍提交的已登记端口保留数值，省略字段/端口可能被移除，拒绝显式漂移 |
| `delete`           | `--service-name <name>`，仅删除描述，不清理外部资源；服务不存在退出 4                                  |
| `register-known`   | `--input <target-json>`，已确认服务完整登记、更新或显式删除，不问询 |
| `check-ports`      | `[--input <完整manifest-json>]`，只读检查 Sandbox 端口与 key，不登记、不预留；建议值在提交时复核 |
| `repair-port`      | `--service-name <name> --port-name <name> --expected-old-port <port> [--target-port <port>]`，显式修复已保存冲突端口，应用配置仍需同步 |
| `register-prepare` | `--input <target-json> --baseline <get-manifest-json>`，只读准备，返回`{target,mode,originals,questions,ask?}` |
| `register-commit`  | `--prepared <prepared-json> [--answer <raw-json>]`，登记/保存/完整预览闭环                                 |
| `runtime-sync`     | 无参数，恢复已保存监听端口，回填`connectPort`并在有效上下文下同步预览                                |
| `update-service-facts` | `--service-name <name> --facts <json-object>`，完整替换 `techStack` 或按 name 更新/删除 `runtime.configFiles`；未知或受保护字段拒绝 |

基础 CRUD 无 Sandbox/LCAP 调用；已知业务变更使用 `register-known`，需要分析的变更使用 prepare/commit，不能只做基础写入却声称预览已同步。已有 Manifest 可用 `createDeployChecker` 做只读契约校验；服务域名消费使用 `getDeployServiceDomains()`，不直接拼 Portal URL。

普通 HTTP 服务的入站通道以 `serviceName` 为 `-k`，普通新端口从 6004 起分配并跳过内置的 6005。仅正式 frontend/6002、backend/6003 或原型 frontend/6005 可使用 `inboundKeyMode:"preset-port"`；历史 Manifest 省略标记时，登记和 `runtime-sync` 也会在核实 `listen=port、key=端口数字、preset=true` 后回填并复用，不执行 `set`。不能只凭端口数字或旧 `connectPort` 推断；其他原型端口、BFF 和不匹配的端口不适用。预置映射缺失或非预置时返回 `RUNTIME_PRESET_UNAVAILABLE`，其他 key 占用时返回 `RUNTIME_KEY_CONFLICT`。已由 `serviceName` 登记在固定端口的服务保留现有通道。预置模式不允许 `repair-port`；普通服务冲突需确认应用配置可同步变更后再显式修复并走登记闭环。

固定 0-1 Workflow 若只有 `appName` 且尚无 Manifest，使用 TypeScript 专用 `ensureDefaultDeployManifest` 生成并登记 frontend、backend、prototype；已有 Manifest 时只恢复和补报当前事实，不再次套模板。该入口不是 Agent 改写任意服务的工具；Agent 的常规增删改仍走 `register-known` 或分析登记。三个可选目录标识 `projectName/deployName/e2eName` 分别描述旧工程、部署脚本和 E2E 目录，均非路径；通用省略脚本路径按 `serviceName` 补齐，固定模板则明确写入 `deployName` 对应路径，源码位置仍取独立 `sourceDir`。不要从 `serviceName` 推导已显式声明的目录，也不要把 backend 的 `apiBasePath` 当作 public 入口。

Help 输出多行文本，其余 stdout 一行 JSON。先看退出码，再保留结构化结果。退出码：0 成功/取消，1 外部/锁失败，2 参数非法，3 校验/答案/前置失败，4 未找到，5 原子写失败。

## 标准操作流

### 已确认事实的登记

1. 执行 `help manifest` 和 `get`，确认现状与稳定服务名。
2. 准备 `{"manifest":{"services":[本轮完整服务]},"deleteServiceNames":[明确删除名]}`；未改服务不列入，同名服务须保留希望继续存在的全部字段与入口。已登记端口数值由契约保留，不为尚未生成的可选脚本捏造内容。
3. 调用 `register-known --input '<目标JSON>'`，不问询；检查结果，再用 get/validate 复核。由控制流程根据返回端口启动和验证服务。

```bash
node .specify/scripts/javascript/deploy-tool.mjs register-known --input '<本轮完整目标JSON>'
node .specify/scripts/javascript/deploy-tool.mjs get
node .specify/scripts/javascript/deploy-tool.mjs validate --require-runtime
```

### 技术设计补齐与生码前检查

原型初登可暂缺 techStack 和 sourceDir；通用 validate 只校验已提供字段，不表示具备生码事实。技术设计确定选型后，按 serviceName 用 update-service-facts 的 facts.techStack 传入完整对象；源码目录等服务结构事实用完整登记更新，不用受控事实入口偷改。

生码前执行 deploy-tool validate --for-codegen；通过后再用 deploy-tool get 读取最新完整 Manifest，按 serviceName 消费 serviceType、sourceDir、techStack、apiBasePath、endpoints、dependencies、build、runtime 和 imageBuild。检查失败时把字段诊断交还技术设计修正，不能猜测默认技术栈。该检查不要求脚本文件存在，也不保证生码器支持所选技术栈；生码完成后再由 createDeployReadinessChecker 检查三个脚本文件。

### 需要分析或确认

先 `get` 并保存完整 stdout，再依据工程和设计事实构造同样的完整目标，调用 `register-prepare --baseline '<分析前get原文>' --input '<目标JSON>'`。保存 prepare 完整输出；有 ask 就原样呈现，得到答案后调用 `register-commit --prepared '<prepare原文>' --answer '<答案原文>'`；无 ask 时省略 answer。prepare 不写文件或申请端口，相关服务变化由 commit 拒绝。

`manifest.services` 中同名服务是完整替换；未列出的已保存服务保持不变。删除整服务放 `deleteServiceNames`，省略同名服务内已有入口表示拟移除该入口。契约自动生成 `service.retention` 或 `entry.retention` 问询；一个多端服务的 PC/H5 可以分别确认，但最终只提交一条服务。新入口公开性确实无法判断时，在入口内提供临时 `exposure`，并将 `{serviceName,type,portName,basePath}` 加入 `unresolvedExposures`，契约生成 `entry.exposure` 问询。Agent 不构造 `upserts/decisions/changes` 或问题选项；结构错误和技术事实缺失不作为问询。serviceName 更名先由上游确认迁移事实，不能静默迁移。

分析型删除整个 `prototype-web` 的输入示例；prepare 会基于旧 Manifest 自动生成 ask：

```json
{"manifest":{"services":[]},"deleteServiceNames":["prototype-web"]}
```

prepare 返回 ask 时，调用宿主现有问询工具展示原 questions/form/select；按 question 键把值为 JSON 字符串的 values 答案原文回传：

```json
{
  "请确认以下项目入口信息": "{\"values\":{\"entry.exposure:portal-web:pc:http:/\":\"public\"}}"
}
```

`fallbackAnswer="{}"`、十分钟超时，取消停止提交并保留原状态；非法答案不能默认同意。确认期间相关服务变化时重新 prepare，不用旧答案覆盖新内容。
### Sandbox恢复

启动 Hook 执行 runtime-sync：按 serviceName 核对并恢复唯一 HTTP 入站端口，将 Sandbox 返回的 connect 端口写入该端口的 `connectPort`，清除非 HTTP 端口的旧运行态映射；适用服务的 Nacos `javaOpts` 保持稳定表达式。有服务的 Manifest 在完整身份下同步 public 入口或空目标清理，已存在的显式空 Manifest 也会同步空目标；无 Manifest 才是空操作。Agent 和普通生码流程不直接调用 runtime-sync。
恢复不首次分配、不改监听值、不问用户、不重新分析、不启动应用；仅在 Sandbox 映射变化时更新 connectPort。应用恢复和实际访问验证由控制流程完成。有 Manifest 时 Hook 失败或超过 150000ms 会阻断 spec-server 启动就绪，但不退出进程，可重试；无 Manifest 时跳过该 Hook。LCAP 等待 `/startup-ready` 成功后才读取 Manifest 和启动服务，不再次执行 runtime-sync；`/health` 仅表示进程存活。facade 单次生成工具调用默认预算为 180000ms，可由 timeoutMs 覆盖。
已知变更走 register-known，分析型变更走 prepare/commit；不能用生命周期恢复代替首次登记。

## 结果与失败恢复

业务提交/恢复结果：

```json
{
  "ok": true,
  "status": "registered",
  "stage": "complete",
  "ports": [
    {
      "serviceName": "teacher-web",
      "portName": "http",
      "port": 6123,
      "inboundPort": 8123,
      "inboundBasePath": "/srt/current/node/8123",
      "action": "created"
    }
  ],
  "previewStatus": "synced",
  "domains": [
    {
      "serviceName": "teacher-web",
      "domain": "teacher.example.com",
      "endpoints": [
        { "type": "pc", "businessType": "application", "title": "教师门户", "basePath": "/", "url": "https://teacher.example.com" }
      ]
    }
  ],
  "uncertain": false,
  "manifestState": "saved",
  "manifest": {
    "services": [
      {
        "serviceName": "teacher-web",
        "serviceTitle": "教师端",
        "serviceType": "frontend",
        "businessType": "application",
        "runtime": {
          "ports": [
            {
              "name": "http",
              "protocol": "http",
              "port": 6123,
              "connectPort": 8123
            }
          ]
        },
        "endpoints": [
          {
            "type": "pc",
            "businessType": "application",
            "title": "教师门户",
            "portName": "http",
            "basePath": "/",
            "exposure": "public"
          }
        ]
      }
    ]
  }
}
```

`manifestState` 为 unchanged/saved/unknown，指本次操作的文件写入状态：saved 返回实际落盘 `manifest`；unknown 不返回候选作为文件事实；恢复发现 Sandbox 映射变化时保存 `connectPort` 并返回更新后的 Manifest，无变化时为 unchanged。

`status`为registered/restored/cancelled/failed，`previewStatus`为synced/not-required/failed/unsupported。失败带`error.code/message`；`stage`标识失败位置，`ports`保留可确认的实际操作，`uncertain:true`表示外部可能已生效，不能认定回滚。取消返回成功的cancelled状态，不代表登记成功。
登记与恢复仅在注册响应和平台回读与 Manifest 完整公开目标一致时返回成功；此时 `domains` 是当前协作全部公开入口的服务级数组；同一服务的多端进入 `endpoints[]`。旧 Portal 成功但未返回快照时同步失败；本地 mock 成功也返回同形态快照；`not-required`、失败或取消时省略 `domains`；Portal 明确接受空目标才返回 `domains: []`。省略不等于空数组，不要自行推导域名。
`port`是应用监听值；`inboundPort`是Sandbox返回的connect端口，写入Manifest时映射为`runtime.ports[].connectPort`；`inboundBasePath`只在结果中，不能写入Manifest。synced只证明平台接受配置，应用可访问由调用方另行验证。

成功登记要求 `status=registered` 且 `manifestState=saved`；目标包含 public 或需要清理已有 Portal 目标时 `previewStatus` 必须为 `synced`，首次登记且仅 internal/no endpoint 的非空服务为 `not-required`。恢复成功为 `status=restored`，有服务的 Manifest 按完整目标同步 public 入口或空目标。

| 结果/错误                        | 处理                                                                                           |
| -------------------------------- | ---------------------------------------------------------------------------------------------- |
| `PREPARED_STALE`                 | 重新get、分析受影响服务并prepare；不复用旧确认结果                                             |
| `PREVIEW_UNSUPPORTED`            | 对齐平台能力，不只发送支持的部分入口                                                           |
| 缺少APP_ID/PRD_ID/CURRENT_BRANCH | 修复执行环境，不从sandboxId/Git猜身份                                                          |
| `RUNTIME_UNASSIGNED`             | 恢复不是首次分配；先按确认事实完成登记                                                         |
| `RUNTIME_SET_UNCERTAIN`          | 停止自动重试；核对Sandbox与返回ports的实际归属，不能换端口绕过                                 |
| `WRITE_FAILED`                   | 保留返回ports，核对落盘状态；先修复磁盘并将确认的已分配值纳入原目标，再prepare；不能直接重申请 |
| `LCAP_API_FAILED`                | Manifest已保存；get后按同目标重新prepare/commit，复用已登记端口并完整同步                      |
| `DEPLOY_LOCK_TIMEOUT`            | 检查工作区根目录 `.deploy.lock` 的归属；存活或无法确认归属的锁不会被抢占                         |

跨系统没有原子回滚。超时/进程中断/部分返回都先核对已发生操作，避免创建新服务名或新端口规避错误。

常见稳定错误码：分析/编排阶段为 `ANALYZER_REQUIRED`、`ANALYSIS_CONTEXT_MISSING`、`ANALYSIS_INPUT_INVALID`、`ANALYSIS_OUTPUT_INVALID`、`DELETE_CONFIRMATION_REQUIRED`、`SERVICE_NAME_CHANGED`、`ASK_REQUIRED`、`ANSWER_INVALID`、`EXECUTION_TIMEOUT`、`TOOL_FAILED`、`TOOL_OUTPUT_INVALID`；提交前置为 `INVALID_ARGUMENT`、`MANIFEST_INVALID`、`BASELINE_INVALID`、`PROTOCOL_REQUIRED`、`PREVIEW_CONTEXT_MISSING`、`PREVIEW_UNSUPPORTED`、`RUNTIME_MAPPING_MISSING`；运行态为 `RUNTIME_LIST_FAILED`、`RUNTIME_EXHAUSTED`、`RUNTIME_SET_UNCERTAIN`、`RUNTIME_UNASSIGNED`；服务域名查询失败为 `SERVICE_DOMAIN_QUERY_FAILED`。调用方保留原始 error.code/message，不将失败降级为空结果或成功。

## 禁止操作

不直接编辑Manifest或自行拼LCAP请求；使用工具保证完整目标与原子写入。
不把端口、标题、Path当新serviceName；不把Sandbox path或执行身份写回描述；Sandbox connect只写入对应端口的`connectPort`运行态字段。
结果uncertain时停止自动重试，先确认外部已发生操作；保存失败后不能盲目再次申请。
不要为了可同步而把API伪装成pc，也不能丢掉不支持的入口只同步半份目标。

## 完成条件

登记：status=registered且manifestState=saved；目标包含 public 或需要清理已有 Portal 目标时 previewStatus=synced，首次登记且仅 internal/no endpoint 的非空服务为 not-required；Manifest复核一致，这不代表应用已运行。
预览：由控制流程按已保存端口启动/恢复后验证全部入口。
取消：宿主收到`{}`即停止提交并保持原状态；facade返回`status=cancelled`。Agent不执行commit时只报告已取消，不声称产生了工具结果。
恢复：原值通道与适用预览同步成功；失败保留具体阶段/实际ports/uncertain，不谎报回滚或就绪。
