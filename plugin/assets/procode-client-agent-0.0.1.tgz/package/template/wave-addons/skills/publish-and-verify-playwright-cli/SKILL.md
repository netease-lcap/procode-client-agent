---
name: publish-and-verify-playwright-cli
description: |
  发布或就绪本地预览 URL 后，用 bash 调用官方 playwright-cli（非 browser MCP）打开页面、snapshot/screenshot，
  再 read 截图与用户参考图或设计意图对照。主会话走 PublishApp 生产预览；worktree 走偏移 PORT 的本机 URL。
  适用：「对照设计验收」「截图看看效果」「发布并验证 UI」「和参考图比一下」。
allowed-tools:
  - Bash
  - Read
---

# Publish and verify (playwright-cli)

对话 UI 验收闭环：**就绪预览 URL → playwright-cli → 截图 → 视觉对照 → 再改码**。不使用 `browser_*` MCP。

## 前置

- 命令面细节可先加载同环境的 **`playwright-cli`** skill（来自 `wave-addons/playwright-vendor/`）。
- 环境已注入 `PLAYWRIGHT_CLI_SESSION` 与 `PUPPETEER_EXECUTABLE_PATH`（系统 Chromium）。
- 每条命令使用同一 session：`-s=$PLAYWRIGHT_CLI_SESSION`（或依赖 env 默认 session 名）。
- **`open` / `goto` 必须带** `--config "$PLAYWRIGHT_CLI_CONFIG"`（shell 已注入，指向 `$SBX_DIST_DIR/playwright-cli.config.json`，`executablePath` 为 `/usr/bin/chromium`）。
- headless / 沙箱：`--config` 内已含 `--no-sandbox` 等 launch args（install-all 生成）。

## 1. 解析预览 URL

### 主会话

1. 需要生产预览时：走项目既有 **PublishApp** 流程，取 `productionURL`（或 skill/文档约定的预览字段）。
2. 仅本地 dev：按 README-dev 与当前 `PORT` 启动前端，基址一般为 `http://127.0.0.1:{PORT}`。

### worktree 会话

1. 使用 shell 环境变量 **`PORT`**、**`BACKEND_PORT`**、**`API_PROXY_TARGET`**（已注入；勿读 `.data/worktrees/.../meta.json`，对话侧不可见）。
2. **就绪**：用 Bash 检查 `$PORT`（前端）与 `$BACKEND_PORT`（若页面依赖 `/api`）是否已有进程监听或 HTTP 可访问；**未启动则先按 worktree 系统提示启动**（`PORT=$PORT` 启前端、`BACKEND_PORT=$BACKEND_PORT` 启后端等），轮询至可访问再预览。不依赖 `buildWarmup` / 安装状态字段。
3. 预览基址：**`http://127.0.0.1:$PORT`**。禁止用主仓默认端口或主会话 Publish URL 代替。
4. worktree 可不强制 PublishApp；merge 后主会话再发布亦可（仅 local URL 预览）。

## 2. 登录

- 主会话：发布凭证 / 项目约定。
- worktree：优先 `PASSWORD.md` 或本地 dev 账密；**禁止臆造**。

## 3. CLI 验证

```bash
playwright-cli -s="$PLAYWRIGHT_CLI_SESSION" open "<预览 URL>" --config "$PLAYWRIGHT_CLI_CONFIG"
playwright-cli -s="$PLAYWRIGHT_CLI_SESSION" snapshot
playwright-cli -s="$PLAYWRIGHT_CLI_SESSION" screenshot
```

截图路径以 CLI 输出为准；用 **Read** 读取 PNG/JPG，与用户消息中的参考图或文字描述列差异。

## 4. 对照与迭代

- 列出布局、颜色、间距、文案等差异后再改码。
- 改码后重复「就绪 → open → screenshot → read」直到可接受或用户确认。

## 5. 收尾

```bash
playwright-cli -s="$PLAYWRIGHT_CLI_SESSION" close
```

失败需保留 browser 重试时可暂不 close，但同一轮任务结束必须 close。禁止 `kill-all` / `close-all`。

## 边界

- 不用 Playwright MCP、不用 `browser_*` 工具。
- 不跑 `playwright install`（浏览器由沙箱镜像提供）。
