# 登录契约 · micro 形态变体篇（按 auth-colocation 四分支：access / identity / per-service / gateway）

本文件是 micro 形态下登录契约的**形态差异单一真理源**。基线篇 `[实现知识库目录对应路径]/base-architecture/auth-login.md` 的
**登录响应信封、两步登录流程、成功码、admin 种子、BCrypt 哈希定值**等通用条款在不与本篇冲突处继续有效并照抄。
**本形态的鉴权收口位置不写死为 BFF**：按台账 `auth-colocation` 分支，见下表；基线篇里「Java 服务侧自建 SecurityConfig/JWT/CSRF/会话 Cookie
一律不适用」的绝对口径**只在 `access` 分支成立**（同名条款以本文件为准）。

路径前缀：`[实现知识库形态目录对应路径]/base-architecture/`（占位符会被框架替换为绝对路径）。

## 第 0 步：分支判定（先读再做）

读 `[大纲目录对应路径]/backend/_meta/clarify-decisions.json` 的 `auth-colocation`（字面值 `access` / `identity` / `per-service` / `gateway`）。
台账无该决策（存量回退）⇒ 按设计产物判定：有 BFF ⇒ `access`；只有内置网关且有统一身份/SSO/身份服务 ⇒ `identity`；否则各服务自验 ⇒ `per-service`；
仍判不出 ⇒ 返回 needsHumanReview 写明缺口，**禁止猜测**。

## 权威结论（每个分支必须写清四件事：登录端点 / 令牌签发方 / 令牌校验落点 / 前端 `/api` 代理目标）

| `auth-colocation` | 登录端点 | 令牌签发 | 令牌校验 | 前端 `/api` 代理目标 | 网关角色 |
|---|---|---|---|---|---|
| `access`（BFF） | BFF | BFF | BFF | BFF | 不适用（或路由到 BFF） |
| `identity`（**内置网关 + 需要登录且无 BFF 的默认 A**） | identity 服务 | identity 服务 | identity 提供的校验契约/密钥；各 Java 服务按该契约校验，**不另立 JWT 实现** | **内置网关**（`application-component` + `role=integration`） | **只路由，不解析 token** |
| `per-service` | identity 服务 | identity 服务 | 各业务服务 | 内置网关 | 只路由 |
| `gateway`（**仅需求显式要求网关承担鉴权/登录**） | gateway 或 identity | gateway | gateway | gateway | 验签 + 注入可信头 |

**默认 A（必守，禁止降级成「可选 / 默认不做」）**：内置网关 + 需要登录 + 无 BFF ⇒ `identity`——
identity 服务统一下发与校验（令牌签发/校验契约归 identity），网关只路由、不解析 token，
前端 `/api` 代理到 gateway，各 Java 服务按 identity 契约校验、不另立 JWT 实现。

### 分支 A · `access`（BFF）

- **① 职责按设计切分：BFF owns 令牌与会话，identity owns 凭证校验与会话登记**（出处：模块 `tech-design.md`
  「会话边界」/「安全机制」/「BFF 调用与身份传播」+ 澄清台账 `jwt-hs256-shared-secret`）：
  - **接入层 BFF（Nest.js，架构发布包 `role=access` 的模块）** owns：
    - 端点 `POST /api/auth/login`、`POST /api/auth/logout`、`GET /api/auth/me`（浏览器登录收口）；
    - JWT **HS256** 签发与校验（Nest `JwtModule` + `JwtService`，或设计钉死的等价机制）；共享密钥由部署配置注入，
      禁写入代码/日志/会话表/镜像；轮换期旧密钥只校验不签发；
    - HttpOnly 会话 Cookie（SameSite=Lax，HTTPS 下追加 Secure；只承载会话/JWT 标识，不放业务数据）；
    - CSRF double-submit、四个可信身份头的注入与伪造头剥离；
    - 登录时转发 `POST /identity/login` 拿身份/角色/权限点/数据范围，签发 JWT 后以 `token_jti` 调身份服务登记会话。
  - **身份服务（Java/Spring Boot）** owns：`POST /identity/login` / `POST /identity/logout`、
    凭证校验（BCrypt）、角色/权限点/数据范围计算、服务端会话登记表读写、多登开关与驱逐逻辑。
    **不签发也不解析 JWT**：不得出现 `JwtUtil`、JWT 解析、JWT 版 `SecurityConfig`、CSRF 装配或会话 Cookie；
    授权只按 BFF 注入的可信头（`X-Role-Ids`/`X-Data-Scope`/`X-Org-Node-Id`）做，不各自再认证。
- **② BFF 侧实现合同（Nest，无 Spring Security 底座）**：
  - 守卫/令牌实现名**钉死**（落点复核按这组名字做机械探针，改名即判红）：
    `JwtModule`、`JwtService`（`@nestjs/jwt`）、`AuthGuard`（鉴权守卫，`auth.guard.ts`）、
    `CsrfGuard`（双提交校验，`csrf.guard.ts`）；
  - CSRF 载体名**钉死**：会话建立时下发非 HttpOnly 的 `XSRF-TOKEN` Cookie，写请求在 **`X-CSRF-Token`** 头回传，
    BFF 比对两者（缺失/不匹配 403）；**不是 Spring 的 `X-XSRF-TOKEN`**；登录端点豁免 CSRF 校验；
  - 身份头：`X-Operator-Id` / `X-Role-Ids` / `X-Data-Scope` / `X-Org-Node-Id`，入口先剥离客户端同名头再按会话真实值重写；
  - BFF 内**禁**任何 Spring 机制（`SecurityConfig`/`JwtAuthenticationFilter`/`CsrfFilter`/`CookieCsrfTokenRepository`/Spring 依赖），
    等价语义用 Nest 守卫 + 统一异常过滤器实现。
- **③ 会话登记表：唯一 DDL 真值 = 正式业务实体（由实体生成链建表）**：会话登记表的**建表真值唯一来自正式业务实体**——
  会话实体随**实体生成链**（实体提取 → `entity-*.md` → 按 entity 真实 DDL 建表）产出，表名/列名/DDL **以该 entity 的真实 DDL 为准**
  （本工程的会话实体如 `sys_session`，`token_jti` 由 BFF 提供）。
  - ⚠️ 基线篇的**「会话登记表是阶段一内置登录 infra、钉死模板 DDL、阶段一现场 `sql-exec` 建、非业务实体、不走实体提取」口径在 micro 形态不适用**——
    本形态**禁**按模板私造会话表、**禁**阶段一自建设计外 DDL；会话表**必须**由实体生成链交付（并行自造路径的产物对种子白名单/
    覆盖判定不可见，j8v3t2 教训在本形态同样成立）。
  - 承载要求不变：含主键、账号标识列、`jti` 列（存 `jti` 或摘要哈希，**禁存明文 token**）、签发时间列、过期时间列、是否活跃列；
    过期惰性失效、登出/驱逐置失效。**列名/表名随该实体 DDL，不套基线模板名**。
- **④ 多登开关取值链保留**：`{appName}.login.allow-multi-session` 配置开关（缺省 `true` = 允许账号多登只登记不驱逐；
  澄清为不允许则 `false` = 单点登录驱逐旧活跃会话）**照旧保留**，取值读澄清台账 `authz` 域的「是否允许账号多登」决策
  （台账无该决策 ⇒ 缺省 `true`）；yml 写真实值、`application.yml.template` 写说明行。**开关与驱逐逻辑住会话登记表的写方
  （identity 登录服务侧），BFF 不重复实现多登策略**。

### 分支 B · `identity`（内置网关 + 需要登录且无 BFF 的默认 A）

- **登录端点**：`POST /api/auth/login`、`POST /api/auth/logout`、`GET /api/auth/me` 由 **identity 服务** owns
  （内部可设计为 `/identity/*`；对外路径仍以 `/api` 开头）。
- **令牌签发方**：identity 服务（可落 `SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter` 或等价 Java 实现——
  **本分支允许 Java 侧 JWT**，不再套用分支 A 的「Java 服务禁 JWT」）。共享密钥由部署配置注入，禁写代码/日志/会话表/镜像；
  轮换期旧密钥只校验不签发。
- **令牌校验落点**：identity owns 校验实现/契约与密钥；**各 Java 服务按 identity 提供的校验模块/公钥/契约校验**，
  不各自另写 JWT 解析、不重造登录端点。若需求要求请求路径上由 identity 唯一校验（introspection），按需求显式分支处理，
  默认不引入额外同步调用。
- **网关角色**：**只路由与转发**（路由/限流/转发），不解析 token；不得在网关另写 JWT 解析。
- **前端 `/api` 代理目标**：**内置网关**（`application-component` + `role=integration`），不是 identity、不是各业务服务。
- **会话登记/多登开关**：住 identity；凭证形态按台账 `auth-mechanism` 分支（Bearer 形态不产会话 Cookie、不产 CSRF）。
- **会话表**：同分支 A ③（正式业务实体通道，禁自造表）。

### 分支 C · `per-service`（各服务自验）

- **登录端点与令牌签发方**：identity 服务统一提供（同分支 B 的 `/api/auth/*` 与签发契约）。
- **令牌校验落点**：各业务服务**各自校验**（按 identity 契约；校验代码允许落本服务，**不另造签发实现**）。
- **网关角色**：只路由，不解析 token。
- **前端 `/api` 代理目标**：内置网关。
- 多登开关/会话登记随设计（若启用会话登记，真值仍归 identity 的会话实体）。

### 分支 D · `gateway`（仅需求显式要求网关承担鉴权/登录）

- **仅当需求显式要求**网关承担鉴权/登录时成立；需求未显式要求 ⇒ **不得**选本分支。
- **登录端点**：gateway 或 identity（按设计）；**令牌签发与校验**：gateway；验签后向下游注入可信身份头
  （入口先剥离客户端同名头，再按真实值重写）。
- **前端 `/api` 代理目标**：gateway。
- **各 Java 服务**：只信任网关注入的可信头，不重造登录/JWT。
- 网关默认只做流量（路由/限流/转发），**不默认拥有登录/鉴权**。

## 配置键落点（按模块，禁"一份 yml"）

- 登录相关配置键（JWT 密钥注入键、Cookie/CSRF 开关、多登开关、数据源等）落在**声明该能力的模块自己的配置文件**：
  - Java 模块（identity / gateway）：该模块自己的 `application.yml`（+ 同名 `.template` 说明文件），键名按该模块技术设计的配置章节；
  - BFF（仅 `access` 分支）：按其 Nest 技术栈的配置文件形态（如 `.env` / 配置模块），**禁**把 `spring.*` 键写进 BFF 配置。
- 份数 = 工程方案 `engineering-plan.json#codeModules` 中实际承载该配置的模块数量，**不预设"一份 yml"**，也不把不同模块的键合并到同一文件。

## 判定信号

- 生成 micro 形态认证相关代码 / 前端登录页 → 本文件适用：先按第 0 步定分支，再照本分支四件事与基线篇通用条款（信封/成功码/种子/阶段归属）。
- 计划在 `access` 分支的 identity（Java）里写 `JwtUtil`/JWT 解析/`SecurityConfig`(JWT)/CSRF/会话 Cookie → 命中反例（这些归 BFF）。
- `access` 分支的 BFF 目录内出现 `SecurityConfig`/`JwtAuthenticationFilter`/`CsrfFilter`/Spring 依赖 → 命中反例（BFF 无 Spring 底座）。
- `access` 分支的 BFF 用 Spring 的 `X-XSRF-TOKEN` 头名 → 命中反例（本形态是 `XSRF-TOKEN` Cookie + `X-CSRF-Token` 头）。
- `identity` 分支：网关内出现 token 解析/JWT 实现 → 命中反例（网关只路由）；各 Java 服务另写一套 JWT 解析 → 命中反例（按 identity 契约校验）。
- `identity` 分支：前端 `/api` 代理到 identity 或各业务服务、或缺少网关节点 → 命中反例（代理目标 = 内置网关）。
- `gateway` 分支：需求未显式要求却由网关承担鉴权/登录 → 命中反例。
- 阶段一按模板 DDL 自建会话表、或自造设计外 `sys_token` 一类表 → 命中反例（会话表真值 = 正式业务实体，走实体生成链建表）。
- 会话表已由 `entity-*.md` 交付、但登录服务侧另建一张"登录自己用"的会话表 → 命中反例（双表并存）。
- 找不到多登开关 / 驱逐逻辑被删 → 命中反例（本形态保留该取值链）。
- `access` 分支：`/api/auth/*` 端点在 identity 侧而不是 BFF 侧 → 命中反例（端点归属见分支 A）。
- `identity`/`per-service` 分支：登录端点/签发不在 identity、或网关解析 token → 命中反例（见分支 B/C）。

## 反例（按分支限定，绝对禁止）

- `access` 分支 ❌ 在 identity（Java）里生成 `JwtUtil`、JWT 签发/解析、JWT 版 `SecurityConfig`、CSRF 过滤器或会话 Cookie——JWT/CSRF/Cookie 全归 BFF。
- `access` 分支 ❌ 在 BFF（Nest.js）内生成 `SecurityConfig`、`JwtAuthenticationFilter` 或任何 Spring 配置类/依赖。
- `access` 分支 ❌ BFF 用 `X-XSRF-TOKEN`/`CookieCsrfTokenRepository` 等 Spring 载体名，或缺 CSRF 双提交、或缺登录端点豁免。
- `identity` 分支 ❌ 网关内写 JWT 解析/token 校验；❌ 各 Java 服务各自另造 JWT 签发或解析实现；❌ 前端 `/api` 代理到 identity/各业务服务。
- `gateway` 分支 ❌ 需求未显式要求网关鉴权却被配置为签发/校验方；❌ 网关不剥离客户端伪造身份头。
- 所有分支 ❌ 阶段一按模板 DDL 现场自建会话登记表、或自造 `sys_token` 等设计外系统表，或绕过实体通道私造表名。
- 所有分支 ❌ 会话表已由实体生成链建好，登录服务侧又另建第二张会话表（双表并存、真值分裂）。
- 所有分支 ❌ 因入口移动而删掉 `{appName}.login.allow-multi-session` 开关或单点登录驱逐逻辑。
- 所有分支 ❌ 会话表存**明文 token**（存 `jti` 或摘要哈希）。
- 所有分支 ❌ 把不同模块的登录配置塞进"一份 yml"，或在 BFF 配置里写 `spring.*` 键。

## 正确写法（按分支）

本形态的落法 = 选定分支的四件事（登录端点 / 签发方 / 校验落点 / 代理目标）+ 通用约束（不重述基线篇的 Java 业务代码正文；
基线篇中与分支冲突的安全条款以本篇为准）。

1. **`access` 分支（BFF）**：`JwtModule` + `JwtService`（HS256）签发/校验 → `AuthGuard` 解析会话 Cookie 并核对会话登记 →
   通过后注入四个可信头（先剥离同名头）→ `CsrfGuard` 双提交校验（`XSRF-TOKEN` Cookie ↔ `X-CSRF-Token` 头，登录端点豁免）→
   转发 `POST /identity/login` 拿身份/角色/权限/数据范围，签发 JWT 并以 `token_jti` 调身份服务登记会话；**BFF 内无任何 Spring 机制**。
2. **`identity` 分支（默认 A）**：identity 服务产 `/api/auth/login|logout|me`、JWT 签发与校验（Java 允许）、校验契约/公钥与密钥、
   会话登记与多登开关；其他 Java 服务按 identity 校验模块/公钥校验（不另立 JWT 实现）；**网关只路由，不解析 token**；
   前端 `/api` 代理到内置网关。
3. **`per-service` 分支**：identity 产登录端点与签发；各业务服务按 identity 契约自校验；网关只路由；前端代理到网关。
4. **`gateway` 分支（仅显式）**：网关产登录端点、JWT 签发/校验与可信头注入；前端代理到网关；各服务只信任可信头。
5. **会话表（所有分支）**：由实体生成链按 `entity-*.md` 真实 DDL 建表（表名/列名/`jti`/过期/活跃列按该实体），阶段一不另建会话表。
   admin 种子等生成期 SQL 仍走 `sql-exec`（基线篇 admin 种子段）；调用须带 `--module-id <该表/DDL 所属模块>`
   （多模块工程必传；归档根规则见基线 `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md`，本篇不重述路径）。
