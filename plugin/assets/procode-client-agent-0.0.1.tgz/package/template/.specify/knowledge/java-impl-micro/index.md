# Java 后端实现常识知识库 · micro 形态变体篇（索引）

本目录 = `[实现知识库形态目录对应路径]`（占位符会被框架替换为绝对路径）。**本目录只承载 micro 形态专属口径**，不是整棵知识树：跨形态的中性篇不在此处，真值仍读**基线目录** `[实现知识库目录对应路径]`。

形态真值 = `plans/tech-stack.json` 的 `backend.form` 键：`micro`（微服务形态）→ 本目录生效；键缺席 / `monolith`（单体形态）→ 形态目录与基线目录同值，读到的就是基线篇。

## 本形态专属篇（与基线篇同名时以本目录为准）

| 篇 | 本形态差异（一句话） |
|---|---|
| `base-architecture/index.md` | micro 形态 base-architecture 的口径差异总览与导航 |
| `base-architecture/datasource-yml.md` | 每持久化模块各一份 `application.yml`（数据源段由 `datasource-binding.json` + 契约条目派生），BFF 无数据源段，取值缺件 fail-loud |
| `base-architecture/auth-login.md` | token 校验前置在 BFF（Nest 侧无 Spring Security 底座）；会话登记表的唯一 DDL 真值 = 正式业务实体 |

## 中性篇（照旧读基线目录 `[实现知识库目录对应路径]`）

- `[实现知识库目录对应路径]/shared/` — 跨阶段共用（`java-spring-bean.md` / `persistence-convention.md` / `test-annotation.md`）
- `[实现知识库目录对应路径]/backend-build/` — 写操作、校验与返回、类型与精度、查询去重
- `[实现知识库目录对应路径]/backend-build-runner/` — 协调者运行时口径（mvnd / surefire / contextLoad）
- `[实现知识库目录对应路径]/inventory-baseline/` — 1-1.1 入口存量扫描规程
- `[实现知识库目录对应路径]/base-architecture/pom-dependencies.md` — 依赖清单（形态无关）
- `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md` — 运行时禁建表 + `sql-exec` 收口（形态无关；多模块工程调用须带 `--module-id <该表/DDL 所属模块>`，归档根规则见该篇）

> ⚠️ **勿按基线导航去读基线同名篇**：基线目录的 `index.md` / `base-architecture/index.md` 里点名的 `base-architecture/datasource-yml.md`、`base-architecture/auth-login.md` 在本形态**由本目录同名篇取代**（形态差异篇），按基线那一行去读会读到**不适用于本形态**的条款（如"阶段一内置会话表、钉死模板 DDL"；旧基线的「派生连接配置缺失用默认值」条款已随产物退役删除）。判据：**读篇前先看本目录有没有同名篇**。

## 读取原则

- 分篇里的【正确写法】必须照抄，【反例】绝对禁止。
- **先查本目录、未命中再走基线目录**：形态专属篇以本目录为准；本目录没有的篇目（含基线 `base-architecture/index.md` 里列的 `pom-dependencies.md` / `runtime-no-ddl.md`）一律读基线目录，禁把本目录当成孤立树、禁因本目录缺篇而跳过必读。
- 不跨界读非本阶段子目录（与基线同纪律）。