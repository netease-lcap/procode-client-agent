# base-architecture 阶段实现约定 · micro 形态变体篇

build/base-architecture 阶段在 micro 形态下遵循本目录约定。**本目录只写形态差异**；同名基线篇 `[实现知识库目录对应路径]/base-architecture/index.md` 里与本篇不冲突的部分继续有效，本篇未覆盖的篇目（`pom-dependencies.md` / `runtime-no-ddl.md` 等）读基线目录。

路径前缀：`[实现知识库形态目录对应路径]/base-architecture/`（占位符会被框架替换为绝对路径）。

## 本形态分篇

### datasource-yml.md —— 数据库连接配置（**micro 形态差异篇**）
- 数据源段是**每持久化模块各一份** `application.yml`（**份数 = 工程方案 `engineering-plan.json` 的 `codeModules` 中持久化模块的实际数量**——逐模块一份、数量由方案决定，不预设固定份数；落各模块真实模块目录），**不是一份**；
- 每份的 `spring.datasource` 取值由 `backend/_meta/datasource-binding.json` 的该模块条目 + 其 `entryRef` 指向的契约条目派生（**禁转录坐标、禁按模块名猜值**）；
- **BFF（Nest.js）无 `spring.datasource` 段**：禁为 BFF 生成 Java 风格数据源段；
- 取值链任何一环缺件（binding 缺席 / 条目缺 `entryRef` / 契约条目解析不到）⇒ **fail-loud 中止**，禁回退默认值；
- **判断**：生成任一模块 `application.yml` 时必读。

### auth-login.md —— 登录契约（**micro 形态差异篇**）
- 鉴权落点按澄清台账 `backend/_meta/clarify-decisions.json` 的 `auth-colocation` **四分支**：`access`（BFF 收口）/ `identity`（**内置网关 + 需要登录且无 BFF 的默认**：identity 服务统一下发与校验，网关只路由）/ `per-service`（各服务自验）/ `gateway`（**仅需求显式要求**网关承担鉴权时）；
- `access` 分支：token 校验前置在 **BFF**（入口先验票），Java 服务侧**只从 BFF 注入的可信头**建立身份上下文，**不解析/不校验 JWT、无 `SecurityConfig`/`JwtUtil`/CSRF**；
- `identity` / `per-service` 分支：**允许 Java 侧 JWT**（签发/校验契约归 identity，各服务按该契约校验，**不各自另写 JWT 解析**）；
- 前端 `/api` 代理目标按承载：内置网关 ⇒ 网关；BFF ⇒ BFF；
- 会话登记表的**唯一 DDL 真值 = 正式业务实体**（由实体生成链建表），阶段一钉死模板 DDL / 自建会话表在本形态**不适用**；
- 多登开关取值链（`{appName}.login.allow-multi-session` + 澄清台账 `authz` 域决策）**照旧保留**；
- **判断**：生成登录服务侧认证代码与前端登录页时必读。

### 内置网关依赖（**micro 形态差异篇**，补充基线 `pom-dependencies.md`）
- 网关模块（`application-component` + `integration`，`application-gateway`）是**独立栈模块**：pom = `spring-boot-starter-parent` + Spring Cloud BOM + `spring-cloud-starter-gateway` + `spring-boot-starter-webflux` + `spring-boot-starter-test`；
- **禁**引入 `spring-boot-starter-web`（Servlet 栈会与 WebFlux 冲突；需求显式要求 Servlet 变体时以 `gateway-runtime.json#/value=webmvc` 为准，由版本对账选择 `gateway-server-webmvc`）；
- 网关仍继承 Spring Boot parent 与 SC BOM（独立栈 ≠ 不消费 parent/BOM）；
- **判断**：生成网关模块 `pom.xml` / 启动类 / 代理路由代码时必读。

## 跨阶段共用（本阶段也读，在基线目录）

- `[实现知识库目录对应路径]/shared/java-spring-bean.md` —— 当 `mapperStyle`=MyBatis 时启动类 `@MapperScan` 必须指定 `annotationClass`（防双 bean）；JPA 栈无 `@MapperScan`、本条不适用
- `[实现知识库目录对应路径]/base-architecture/pom-dependencies.md` —— 依赖清单（含多模块 Maven 工程只增改各子模块 `pom.xml` 的纪律）
- `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md` —— 运行时禁建表 + 建表/改表走 `sql-exec` 收口（多模块工程调用须带 `--module-id <该表/DDL 所属模块>`，归档根规则见该篇）

## 与基线篇的关系（读法）

- **同名篇以本目录为准**（形态差异覆盖基线同名篇的对应条款），基线的方言/风格正文该照抄的照抄；
- 本目录**没有**的篇目 → 读基线目录（不要因为本目录缺篇就跳过必读，也不要照抄基线同名篇里被本篇改写的条款）。