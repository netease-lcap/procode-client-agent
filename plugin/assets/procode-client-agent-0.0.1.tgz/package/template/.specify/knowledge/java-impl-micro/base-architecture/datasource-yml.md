# 数据源 yml 配置 · micro 形态变体篇（每模块一份 application.yml）

本文件是 micro 形态下 `application.yml` 的 `spring.datasource` 配置**单一真理源**，build/base-architecture 生成各模块 yml 与 build/backend 阶段二 yml 校验均引此。方言（url / driver / 参数）分叉照基线篇 `[实现知识库目录对应路径]/base-architecture/datasource-yml.md` 的【权威结论】+【正确写法】/【反例】，**本文件只写形态差异，不重述方言结论**。

## 权威结论（形态差异三条）

- **份数 = 每持久化模块一份**：微服务形态下**每个持久化模块各有自己的 `application.yml`**——**份数 = 工程方案 `engineering-plan.json` 的 `codeModules` 中持久化模块的实际数量**（逐模块一份，数量由方案决定，不预设固定份数），落**该模块真实模块目录**内；**不存在跨模块共用的那一份 yml**，也**不把各模块的数据源塞进同一份 yml 的多 profile / 多数据源段**。非持久化模块不生成数据源段。
- **取值链 = `datasource-binding.json` → `entryRef` → 契约条目**（**禁按模块名猜、禁转录坐标**）：
  1. 读 `[项目设计目录对应路径]/backend/_meta/datasource-binding.json`，取**本模块**（`moduleId` 逐字相等）的条目 `{moduleId, databaseType, dataSourceName, entryRef}`；非持久化模块 = 无条目 ⇒ 该模块无数据源段；
  2. `entryRef` 形如 `datasources.json#<dataSourceName>`，指向 `.manifest/datasources.json` 的契约条目；
  3. 执行 `node .specify/scripts/javascript/datasource-tool.mjs resolve --name <dataSourceName>`（cwd = 工作空间根）拿 host/port（回环坐标）+ database/username/password + `databaseType` 六字段，把**真实值写死**进该模块 yml 的 `url/username/password/driver-class-name`；**禁保留 `${DB_HOST:127.0.0.1}` 等占位符**。
- **粒度双分支、同一条规则（禁写死"同值"）**：绑定的粒度由 `datasource-binding.json` 的**实际取值**决定，两种情况走**完全相同的读取与派生步骤**——① `shared`（共享收敛）分支：各持久化模块条目共指**同一 `entryRef`** ⇒ 各模块 yml 的数据源段**取值自然相同**；② `per-module` 分支：各模块条目各持**不同 `entryRef`** ⇒ 各模块 yml **各自取值**。**判据是读到的 `entryRef` 本身，不是"本形态应该同值/各值"的假设**：禁按粒度分支写死某一个值、禁把一个模块的取值复制给另一模块、禁在 yml 里"顺手统一"。
- **BFF 无数据源段**：BFF（Nest.js 接入层）**不含 `spring.datasource` 段**（也无 `application.yml` 的 Java 形态数据源配置）——禁为 BFF 生成/复制数据源段，禁让 BFF 直连业务库；BFF 的配置形态以其自身栈为准。
- **取值链缺件 ⇒ fail-loud 中止（本形态不设兜底默认值）**：`datasource-binding.json` 缺席 / 本模块条目缺失（而该模块按技术设计应持久化）/ 条目缺 `entryRef` 或 `entryRef` 形态不合法 / 契约条目 `resolve` 解析不到 ⇒ **报红中止并上报 checkerFeedback**，把缺件现象如实写明；**禁止**用 `127.0.0.1` / `3306` / `project_<appName>` / `root` 一类**默认值**把缺件糊过去，**禁止**臆测新方言族。基线篇的「本地派生连接配置缺失 → 用默认值生成并留痕」条款已随该产物退役而删除，**不存在任何可兜底形态**（本形态该链路的真值源是 binding + 契约条目，缺件是必须修的产物缺陷，不是可兜底的常态）。
- **值冲突禁自修**：yml 值与契约条目（真值）冲突时，**只修 yml 侧、上报 checkerFeedback**，禁改 `datasource-binding.json` / 契约条目来对齐 yml（该两个载体 agent 无写权）。
- **禁改范围**：禁止修改 `application.yml` 中数据源以外的配置段。

## 判定信号

- 生成某模块 `application.yml`（base-arch）→ 该模块条目适用；**逐模块判**，不因"别的模块已经生成过"而跳过。
- 本形态出现**唯一一份** `application.yml` 承载全部数据源 / 出现多数据源 profile 段 → 命中反例，按"每模块一份"重做。
- BFF 目录下出现 `spring.datasource` 段 → 命中反例，删除（BFF 无数据源段）。
- yml 的 host/port/database 与 `entryRef` 契约条目 `resolve` 结果不一致 → 命中反例；只修 yml。
- binding 缺席 / 条目缺 `entryRef` / `resolve` 失败却仍产出了 yml → 命中反例（**该情形必须红**，不是"用默认值生成"）。
- 多个模块的条目 `entryRef` **不同**、但各模块 yml 写出了**完全相同**的取值 → 命中反例（把 per-module 当 shared 复制了值）。
- yml 出现 `${DB_HOST}` / `${DB_PORT}` 占位符 → 命中反例，用契约条目真实值替换。
- 阶段二 yml 校验任务 → 真值取 **本模块的契约条目**（六字段，含 `databaseType`），只修 yml 对齐契约，**禁改真值侧**。

## 反例（绝对禁止）

```yaml
# ❌ 全应用只有一份 application.yml、把各模块的数据源塞进多数据源段（micro 形态必须每模块一份，份数按方案持久化模块数）
spring:
  datasource:
    url: jdbc:mysql://${DB_HOST:127.0.0.1}:${DB_PORT:3306}/${DB_NAME:project_app}
    username: ${DB_USER:root}
    password: ${DB_PASS:root}
```

```yaml
# ❌ binding/契约条目缺件时用默认值"生成"（本形态必须 fail-loud 中止）
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/project_app?serverTimezone=Asia/Shanghai
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
```

```yaml
# ❌ BFF（Nest.js 接入层）目录下出现 Java 形态数据源段
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/project_app
    driver-class-name: com.mysql.cj.jdbc.Driver
```

```yaml
# ❌ 各模块 entryRef 不同（per-module 粒度）却按"同值"复制：值未按本模块契约条目派生
#    （命中判据 = 取值与 datasource-tool resolve 的本模块条目结果不一致，而非"看起来整齐"）
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/project_app
    driver-class-name: com.mysql.cj.jdbc.Driver
```

## 正确写法（每模块一份；方言正文照基线篇）

模块 X 的 `application.yml`（`<模块目录>/src/main/resources/application.yml`）——取值来自**模块 X 自己的条目**：

```yaml
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/project_app_org
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
```

模块 Y 的 `application.yml`——取值来自**模块 Y 自己的条目**（与 X 相同或不同，取决于两者 `entryRef` 是否相同；**不假设、不复制，读出来是什么写什么**）：

```yaml
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/project_app_person
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
```

BFF（Nest.js）：**不生成 `spring.datasource` 段**（其上表配置属其它形态，本文件不覆盖）。

> url / driver 的**方言分叉**（MySQL / PG / Oracle 各族前缀、参数、驱动坐标）与"真实值写死、禁占位符"照基线篇 `[实现知识库目录对应路径]/base-architecture/datasource-yml.md`【正确写法】逐条照抄，本文件不重述。