# base-architecture 阶段实现约定（后端基础架构）

build/base-architecture 阶段生成 pom.xml / application.yml / 启动类 / 模块注册底座时遵循本目录约定。

路径前缀：`[实现知识库目录对应路径]/base-architecture/`（占位符会被框架替换为绝对路径）

## 分篇

### pom-dependencies.md —— 后端依赖清单
- 权威依赖清单照骨架 pom 在用栈（ruoyi/MyBatis 栈 illustrative：spring-boot-starter-{web,validation,security,actuator} + mybatis-spring-boot-starter + mysql-connector-j(runtime) + lombok + jjwt + spring-boot-starter-test(test)），换栈照骨架替换、不照抄
- 持久层 starter 照 `skeleton-conventions.json` `mapperStyle` 真值（MyBatis 栈不引 JPA、JPA 栈照引），见 `[实现知识库目录对应路径]/shared/persistence-convention.md`（不重述、不跨栈 mandate 禁 JPA）
- **多模块 Maven 工程**：骨架已有含父 POM 的多模块结构时只增改各子模块 `pom.xml` 依赖（如 `ruoyi-system/pom.xml`、`ruoyi-admin/pom.xml` 各按需加 starter），禁重写父 POM、禁摊平为单模块；单模块骨架才整体生成单 pom
- **判断**：生成/裁定 pom.xml 时必读

### datasource-yml.md —— 数据库连接配置
- application.yml spring.datasource 段：url/username/password/driver-class-name 写真实值（`dataSourceName` 取自 `backend/_meta/datasource-binding.json`，经 `datasource-tool.mjs resolve --name` 读契约条目的 host/port/database/username/password）
- url 格式 jdbc:mysql://（应用自身数据源，项目 MySQL；非方言切换范畴）
- 禁 ${DB_HOST} 占位符
- **判断**：生成 application.yml 时必读

### runtime-no-ddl.md —— 运行时禁建表
- 应用运行时绝不动态建表：禁 ApplicationRunner/启动时 DDL 迁移器（Flyway/Liquibase 运行时迁移）；spring.sql.init.mode=never
- 建表/改表由 agent 在生成期通过 sql-exec CLI（node .specify/scripts/javascript/sql-exec.mjs）经平台 MCP 执行（本地无 MySQL 直连通道），DDL 脚本由 CLI 统一落 sql/*.sql；**调用须带 `--module-id <该表/DDL 所属模块>`**（多模块工程必传；归档根规则见 `runtime-no-ddl.md`，此处不重述路径）
- 禁裸 mysql CLI 手写 SQL 执行
- **判断**：生成启动类 / application.yml / 任何运行期初始化代码时必读

### auth-login.md —— 登录契约与账号密码登录底座实现（阶段一后端 + 阶段二前端 + 阶段四登录业务模块共读）
- Spring Security + JWT（Bearer 传输）+ **服务端会话登记表（有状态，默认）** + BCrypt（PasswordEncoder）通用实现写法：SecurityConfig（Spring 层仍 STATELESS）/ JwtAuthenticationFilter（验签后查会话登记 active）/ JwtUtil（签发写 jti）/ LoginService（签发后按多登策略登记会话）/ 登录 Controller / AuthRepository（登录查询投影）/ SessionRepository（会话登记表读写）正确写法与反例
- **有状态默认**：会话登记表是**阶段一内置登录 infra**（本文钉死模板 DDL、阶段一 `sql-exec` 建，非业务实体、不走段B/C 提取、不生成 CRUD、禁自造 `sys_session`）；多登开关 `{appName}.login.allow-multi-session`（缺省 `true`=允许账号多登只登记不驱逐，`false`=单点登录驱逐旧会话），取值读澄清台账 `authz` 域「是否允许账号多登」决策；技术设计明确纯无状态时才回退无登记纯 JWT
- **包归属**遵循 README §2 MVC 三层 + §9.3 子包规则派生：`LoginController`→`controller`、`LoginService`→无子包、`AuthRepository`→`repository`、`LoginRequest`/`LoginAccount`→`dto`、**`SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter`→全局共享 infra 模块的 `config`**（骨架放 `CorsConfig` 的那个模块、与 `CorsConfig` 同侧，读骨架发现真实包名不硬编码 `common`）
- **登录响应契约（spec 落地）**：统一信封（类名/shape 取 `skeleton-conventions.json` `responseEnvelope` 真值，如 ruoyi 栈 `ApiResponse<T>{code,message,data}`，见 spec §9）、成功码 `200`（spec §9.4）；`POST /api/auth/login` → 信封的成功工厂方法（如 ruoyi `ApiResponse.success({ token })`，**禁裸返 `{token}` 不走信封**，违 spec）；失败走信封失败方法（如 ruoyi `ApiResponse.fail`）配 401。**所有后端 HTTP 端点一律 `/api` 开头**（前端同源 `/api` 代理合同），登录端点缺省 `/api/auth/login`；登录标识列/密码列/端点路径均以技术设计为准
- **`/api/auth/me` 契约（阶段四登录业务模块 owns，阶段一不产）**：`GET /api/auth/me`（需 JWT）→ 信封的成功工厂方法（如 ruoyi `ApiResponse.success({ user: {id,username,realName,role,level,permissions[],regionId,isSuperAdmin} })`，`code=200`），字段取值对齐技术设计（四级层级/区域/超管/角色权限）；组装 account→role→RolePermission→Region，复用阶段三 `<Entity>Repository`。阶段一不产 `/me`（无 RBAC 表）
- **前端两步登录契约（阶段二前端登录页必照抄）**：`POST /api/auth/login` 得 `{token}` 存 store → `GET /api/auth/me`（Bearer）得 `{user}` 存 store；成功判定走 api-client 的 `ApiResponse` 信封 + successCodes（含 200/201），**禁硬判 `res.code==='0'`**（spec 成功码=200，`code=0` 是 LLM 先验臆加违 spec）；禁臆造 inline `{token,user}` 单端点契约
- **阶段归属铁律**：阶段一 owns `POST /api/auth/login`（认证/签 token）+账号表+admin 种子+JWT infra，**不产 `/me`**；阶段四登录业务模块 owns `GET /api/auth/me`（授权上下文），**禁重生 `POST /api/auth/login`**；账号实体 CRUD 归阶段三（`AuthRepository` 与阶段三 `<Entity>Repository` 类名不同、所有权分离、查同表无冲突）
- admin 种子 BCrypt 哈希定值（Admin123456 的 $2a$10$... 哈希，禁止运行时重算）+ 幂等 INSERT DML 模板（表名/列名按所选账号实体 entity-*.md 真实 DDL）
- 不含任何项目实体名/列名；唯一写死常量 = admin/Admin123456 + BCrypt 哈希定值
- **判断**：阶段一登录任务生成 SecurityConfig/JWT/登录代码/AuthRepository/admin 种子 DML 时必读；阶段二前端登录页生成时必读（两步+禁硬判 code=0）；阶段四登录业务模块生成 `/me` 时必读

## 跨阶段共用（本阶段也读，在 shared/）

- `[实现知识库目录对应路径]/shared/java-spring-bean.md` —— 当 `mapperStyle`=MyBatis 时启动类 @MapperScan 必须指定 annotationClass（防双 bean）；JPA 栈无 @MapperScan、本条不适用
