# 登录契约与登录底座实现约定（阶段一后端登录底座 + 阶段二前端登录页 + 阶段四登录业务模块共读）

本文件是**登录响应契约**与**账号+密码登录底座**实现的单一真理源，三处共读：
- build/base-architecture **阶段一**登录任务生成 `SecurityConfig` / `JwtAuthenticationFilter` / `JwtUtil` / 登录 `Controller` / `LoginService` / admin 种子 DML 时引此；
- build/frontend-foundation **阶段二**前端登录页生成时引此（登录两步流程 + 成功判定 + 信封）；
- build/business-modules **阶段四**登录业务模块生成 `GET /api/auth/me`（授权上下文）时引此。

换技术栈则按 `<stack>-impl/base-architecture/` 对应文件。**前后端任何一方生成登录相关代码前必读本文件「权威结论」+「登录响应契约」段并照抄，不重述。**

**信封类名/shape 不在此写死**：本文示例中的 `ApiResponse`/`ErrorCode` 是 ruoyi 栈 illustrative 名。登录响应信封的**类名+FQN 与 shape** 取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` `responseEnvelope` 真实在用值（如 ruoyi 栈为 `ApiResponse<T>{code,message,data}`），失败处理方式以 `failureStyle` 真值为准、错误码类真名见 `errorCode`。换栈照真名替换示例类名；登录响应码值（成功 200/创建 201、失败 401/400）与两步流程、阶段归属是 spec 级契约，通用保留。

**登录响应契约是 spec 的直接落地**（不是本文臆造）：统一信封（类名/shape 取 `skeleton-conventions.json` `responseEnvelope` 真值，如 ruoyi 栈 `ApiResponse<T>{code,message,data}`，见 `README` §9）；成功码 `200`（`README` §9.4 读/更新/删除→200、创建→201）；登录用户上下文（role/level/region/permissions）由 `README` §6.123「数据范围由登录用户上下文(DataScope)注入」要求。本文件只钉死"登录响应 shape + 两步流程 + 阶段归属"，不含任何项目实体名/表名/列名——登录标识列、密码列、登录端点路径、登录类命名、user 画像字段取值均以技术设计为准，本文只给缺省默认。**唯一钉死的常量** = `admin` / `Admin123456` 凭据值 + 下方 admin 种子 BCrypt 哈希定值。

路径前缀：`[实现知识库目录对应路径]/base-architecture/`（占位符会被框架替换为绝对路径）

## 权威结论

- **技术栈**：Spring Security + **HttpOnly Cookie 会话（承载不透明会话标识 = JWT 的 `jti`）+ 服务端会话登记表（有状态，默认）** + `BCryptPasswordEncoder`。Spring session 策略仍 `SessionCreationPolicy.STATELESS`（无 HttpSession，应用层自有 `Set-Cookie` + 会话登记表，非 Spring HttpSession/Cookie），**「有状态」体现在应用层会话登记表**——`LoginService` 签发带 `jti` 的 JWT 即登记一条活跃会话，`JwtAuthenticationFilter` 从 HttpOnly Cookie 取会话标识（`jti`）、验签后再查该 `jti` 在登记表中 active，使会话服务端**可见、可失效、可追踪**（满足后续并发单测断言会话状态 + 账号多登控制 + 登出/账号禁用即时撤销）。技术设计明确要求**纯无状态**（不追踪会话、不需失效/多登控制）时才回退为无登记的纯签名 JWT（此时 Cookie 承载自包含签名凭证、不查登记表）。**不引入 Spring HttpSession**（`SessionCreationPolicy.ALWAYS/IF_REQUIRED` 仍禁）——有状态默认走的是应用层 `Set-Cookie` + 会话登记表，不是 Servlet 会话；浏览器 JS 不可读 HttpOnly 会话凭证，请求由浏览器按 Cookie 规则自动携带。
- **会话登记表（登录承载实体，统一实体通道；建表落地阶段一 owns）**：这是**登录基础设施**（与 `SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter`/admin 种子同类），但承载走**统一实体通道**（plan 2026-09-03/requirement-coverage：决策隐含的表级承载必须有 entity 承接，禁并行自造表路径）——会话实体由 authz 专家给段B **正向建模指引**、**进 `entity-*.md` 提取**（authz 域），表名/列名/DDL **以会话实体 entity 真实 DDL 为准**（缺省命名规约 `<账号表名>_session` / `login_session` 供实体命名参考），**禁自造设计外的 `sys_session` 系统表、禁绕开实体通道按模板私造表名**（实测并行路径产物对种子白名单/覆盖判定不可见，j8v3t2 教训）。由阶段一登录任务用 `node .specify/scripts/javascript/sql-exec.mjs --type ddl` 按 entity 真实 DDL 建表（同账号表建表路径；调用须带 `--module-id <该表/DDL 所属模块>`，多模块工程必传，归档根规则见 `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md`）。**钉死的承载要求**（会话实体 DDL 必须满足，`<...>` 占位随所选账号实体真实列名/表命名规约替换）：会话表含 `id` 主键、`<账号标识列>`（关联登录标识值）、`<jti列>`（存 JWT 的 `jti` 或 token 摘要哈希，**禁存明文 token**）、`<签发时间列>`、`<过期时间列>`、`<是否活跃列>`（`1` 活跃 / `0` 失效），可选 `<设备/ip/ua 列>`。过期会话惰性标失效（查活跃时按过期时间过滤或登记时清理），登出/驱逐把对应行 `<是否活跃列>` 置 `0`。不臆造业务语义列。
- **多登策略（默认允许账号多登 = 只登记不驱逐）**：**默认允许**同一账号多处并发登录——每次登录 APPEND 一条活跃会话、旧会话不失效（多 token 并存）。由澄清台账 `authz` 域的「是否允许账号多登」决策驱动，**缺省默认允许**；若澄清为**不允许** = 单点登录（新登录先把该账号所有旧活跃会话 `<是否活跃列>` 置 `0` 再登记本次）。实现层用配置开关 `{appName}.login.allow-multi-session`（默认 `true`）承载，写入 `application.yml`（真实值）+ `application.yml.template`（说明行）。
- **登录端点契约（认证 = credential → Cookie 会话，阶段一 owns）**：`POST <登录端点路径>` 接收 `{ <登录标识>, <密码> }` → 成功返**统一信封的成功工厂方法**（真名取 `skeleton-conventions.json` `responseEnvelope`，如 ruoyi 栈 `ApiResponse.success(...)`，即 `{ code: 200, message, data: {...} }`，`code=200` 对齐 `README` §9.4 成功码）**且响应正文不含 token、session id 或等价原始凭证**，同时由服务端通过 `Set-Cookie` 写入会话凭证（HttpOnly、`Secure`/`SameSite` 运行时按 `request.isSecure()` 动态推导见下「配置」、正确 Path/明确有效期、承载 JWT 的 `jti`）；失败返信封的失败方法（真名见 `responseEnvelope`/`failureStyle`，如 ruoyi 栈 `ApiResponse.fail(<BIZ_错误码>, <提示>)`）配 HTTP `401`（凭据错误）/`400`（参数缺失）。**禁响应正文含 token/session id 等原始凭证**（违浏览器会话安全规则：HttpOnly Cookie 是唯一凭证载体，前端 JS 不得读取）。**所有后端 HTTP 端点（含登录 Controller）一律以 `/api` 开头**——出处 = 前端同源 `/api` 代理合同（浏览器业务请求统一以 `/api` 开头的同源相对 URL，前端权威开发/预览服务器把 `/api` 代理到后端 `http://127.0.0.1:6003`），后端不带 `/api` 前缀的端点前端无法到达。**登录端点路径以技术设计为准，缺省默认 `/api/auth/login`**。登录标识字段名、密码字段名、请求/响应 DTO 字段名均读技术设计取真实值，不写死。
- **未认证请求状态码契约（401，阶段一 owns）**：Spring Security 在 `SessionCreationPolicy.STATELESS` + 未配 `httpBasic()`/`formLogin()` 时，默认 `AuthenticationEntryPoint` 是 `Http403ForbiddenEntryPoint`，未认证请求返 **403**。但任务/spec 要求未认证请求（含 logout 后重放受保护接口）返 **401**。须在 `SecurityConfig` 显式配 `.exceptionHandling(e -> e.authenticationEntryPoint(...))` 返 401 + 统一信封失败方法（如 ruoyi 栈 `ApiResponse.fail(<BIZ_未认证>)`）。`JwtAuthenticationFilter` 查不到有效会话时不设 `SecurityContext`，`anyRequest().authenticated()` 触发该 entryPoint——**不配则返 403 而非 401**，验收断言"logout 后重放返 401"必失败。
- **登出端点契约（会话失效，阶段一 owns）**：`POST /api/auth/logout`（需已认证 Cookie）→ 调 `SessionRepository` 把当前会话登记行置失效（`<是否活跃列>=0`）+ 返回**同名、同 Path/Domain 作用域的过期 Cookie**（`Max-Age=0`）；随后当前会话查询与受保护接口必须立即返未认证。**登出必须使服务端会话失效，禁止只清前端状态冒充登出**（违浏览器会话安全规则5）。账号禁用、权限撤销、会话过期、密码变更等安全状态变化也必须使现有会话失效或重新校验（`JwtAuthenticationFilter` 查登记表 active 时自然落到 401）。
- **当前用户端点契约（分层 owns：阶段一认证层 + 阶段四 RBAC 扩充）**：`GET /api/auth/me` 的 `@GetMapping` 映射 + 认证层响应对**阶段一** `LoginController` owns（与 login/logout 同 controller）——读 `SecurityContext` 认证主体（JWT subject = 登录标识值）查 account 行，返 `ApiResponse.success({ "user": { <id>, <username> } })`（`code=200`），不查 role/permission/region、不硬编 `isSuperAdmin`。前端阶段二即调此 `/me`，须在阶段一就绪。**RBAC 扩充**对**阶段四** owns：role/permission/region 表由阶段三按 `entity-*.md` DDL 建表后，阶段四提供 `CurrentUserService` + `UserProfile` record，**修改 `LoginController.me()` 方法体**委托 `currentUserService.loadUserProfile(principal)` 补全 `<realName>/<role>/<level>/<permissions[]>/<regionId>/<isSuperAdmin>`（查账号→联角色→联 `RolePermission` 取权限码→联 `Region`）；**禁阶段四新建 `@GetMapping("/me")`/`CurrentUserController`**（与阶段一映射碰撞，`AmbiguousMappingException`）。**user 画像字段取值对齐技术设计**（如 `README` §6 描述的四级管理员层级 province/city/county/school → `level`、行政区域数据范围 → `regionId`、超管 → `isSuperAdmin`、角色权限 → `role`/`permissions[]`，字段名以设计为准）。阶段四扩充触发门 = `stage1-login-base.json` enabled 且 `entity-*.md` 含 RBAC 实体（role/permission/region 之一），不依赖 checklist 文件名为"登录"；无 RBAC 实体的纯登录 spec，阶段一 minimal `/me` 即最终答案。
- **阶段归属铁律**：阶段一 owns `POST /api/auth/login`（认证/建立 HttpOnly Cookie 会话）+ `POST /api/auth/logout`（使服务端会话失效 + 过期 Cookie）+ **`GET /api/auth/me` 的 `@GetMapping` 映射 + 认证层响应（`{id, username}`，读 `SecurityContext` 主体查 account 行，不硬编 RBAC）** + 账号表 DDL + 会话登记表 DDL + admin 种子 + JWT/会话 infra；阶段四 owns **`GET /api/auth/me` 的 RBAC 扩充**（`CurrentUserService` + `UserProfile` record，**改 `LoginController.me()` 方法体**委托 `loadUserProfile` 补 RBAC 字段，禁新建 `@GetMapping("/me")`/`CurrentUserController`）+ **禁重生 `POST /api/auth/login`、`POST /api/auth/logout`**（阶段一已存在，重生致重复 Controller/端点冲突）。`/me` 认证层在前端阶段二之前即就绪，RBAC 扩充在阶段三建 RBAC 表后由阶段四补。认证与授权上下文分属两阶段，对应 `README` §6.120（登录建立会话）与 §6.123（DataScope 用户上下文注入）。
- **前端两步登录契约（阶段二前端登录页必读必照抄）**：① `POST /api/auth/login`（走 `apiClient`，`withCredentials: true`）得 `ApiResponse{code:200}` + 浏览器自动存 HttpOnly 会话 Cookie（前端 JS **不读、不存**会话凭证）；② `GET /api/auth/me`（浏览器按 Cookie 规则自动携带，**不拼 `Authorization`**）得 `ApiResponse{code:200,data:{user}}` → 存 user 到 auth store；**user 必含 `id`/`username`（认证身份，阶段一即提供），RBAC 字段 `role`/`level`/`permissions`/`regionId`/`isSuperAdmin` 可选——阶段四-五权限门控 UI 才用，阶段二-三缺失不 block**；**未拿到 `id`/`username` 视为未完成登录**（非"未拿到全量 RBAC"），前端读 user 须防御性（RBAC 字段有则用、无则不判权限）。③ **成功判定走 `apiClient` 返回的 `ApiResponse` 信封 + successCodes（含 `200`/`201`），禁硬判 `res.code==='0'`**（spec 成功码=200，`README` §9.4；`code===0` 既不符 spec 也非任何既有框架约定，是 LLM 先验臆加，违 spec 必禁）。失败按 `code`+`message` 提示。④ 登录响应**正文不含原始凭证**（HttpOnly Cookie 是唯一凭证载体），user 画像走 `/me` 单独取，**禁前端臆造 inline `{token,user}` 单端点契约**（RBAC user 属阶段四授权上下文，登录认证响应不该带）。⑤ **禁把会话凭证写入 `localStorage`/`sessionStorage`/IndexedDB/普通可读 Cookie/URL/DOM/日志，禁前端从可读存储恢复凭证、禁拼 `Authorization`**——浏览器请求由浏览器按 Cookie 规则自动携带会话。
- **依赖**：见 `[实现知识库目录对应路径]/base-architecture/pom-dependencies.md`（`spring-boot-starter-security` + `jjwt` 已在清单）。JWT 用 `io.jsonwebtoken`（jjwt）。
- **配置**：`application.yml` 加 `{appName}.jwt.secret` / `{appName}.jwt.expire-millis`（或设计指定 key 层级），`secret` 写真实值（JWT 签名密钥，64 字节以上随机串），同步生成 `application.yml.template` 对应说明行（镜像既有 yml 规则，真实值只进 yml、template 写说明）。**有状态默认另加 `{appName}.login.allow-multi-session`**（布尔，缺省 `true`=允许账号多登只登记不驱逐；澄清为不允许则写 `false`=单点登录驱逐旧会话），yml 写真实值、template 写说明行。**会话 Cookie 属性**另加 `{appName}.login.cookie.{httpOnly,path,maxAge}`（`httpOnly=true`、`path=/`、`maxAge` 对齐 `jwt.expire-millis`）；**`secure`/`sameSite` 不作静态配置键**——必须在写 cookie 的请求处理路径运行时按 `request.isSecure()` 动态推导（`boolean secure = request.isSecure(); String sameSite = secure ? "None" : "Lax";`）：`secure` 真→`Secure`+`SameSite=None`（跨源 iframe 预览必需，`Lax` 跨站子请求不发送致 `/me` 401；`None` 必须同 `Secure` 出，否则浏览器全拒），假→`SameSite=Lax`。禁止按后端监听协议/部署形态自判“是否 HTTPS”（后端恒 http 不等于本地同站，恒误判致跨源 iframe `/me` 401）。**前置强制**：`application.yml` 须含 `server.forward-headers-strategy: framework`（应用恒经 https 网关暴露、TLS 在网关终止、须信任 `X-Forwarded-Proto` 才能使 `request.isSecure()` 在网关后为真，否则恒假→恒 `Lax`→回归；不可交 LLM 自加漏配），yml 写真实值、template 写说明行。
- **admin 默认超管账号**：账号值 `admin`、密码明文 `Admin123456`、密码列存 BCrypt 哈希定值（见下「admin 种子 DML」）。**这是用户钉死的固定凭据，不变**。角色 label 信息性记为 `超级管理员`，但阶段一**不 seed 角色行**（role/permission 实体留阶段三建表、阶段四灌库）——admin 的角色归属按技术设计在阶段三 role 表建表后、阶段四落库。
- **登录最小实体集**：由登录任务 LLM 读技术设计判定（验证账号+密码 + 签发 token 直接依赖的实体）；本文不限定实体名/表名。admin 种子 INSERT 的**表名与列名按所选账号实体 `entity-*.md` 的真实 DDL**，本文只给 DML 模板与幂等写法。

## 判定信号

- **登录方案读澄清台账（先于一切登录条款）**：`backend/_meta/clarify-decisions.json` 中 `id === "login-required"` 决策 → `answer` 以「不需要」开头 = 无登录，本文件全部条款不适用（阶段一登录底座跳过）；以「需要」开头 → 再读 `id === "login-scheme"` 决策：`账号密码` → 本文件账密条款（含 admin 种子/Admin123456/admin-account.json）逐字适用；`SSO` → 本文件通用铁律段 + 下「SSO 单点登录变体」段适用、账密专属段（admin 种子/密码列语义）不适用；`邮箱|手机号` → 通用铁律段 + 下「邮箱/手机号验证码登录变体」段适用；台账无 `login-scheme` 但 `login-required` 为需要 → 回退账密条款（缺省账密）。
- 阶段一登录任务生成 SecurityConfig/JWT/登录代码 → 全条适用，生成前必读并照抄【正确写法】、禁【反例】。
- **有状态默认恒适用**：技术设计未明确要求「纯无状态/不追踪会话」→ 按有状态默认，建会话登记表 + `SessionRepository` + `LoginService` 登记 + `JwtAuthenticationFilter` 从 Cookie 取 `jti`、验签后查登记表 active；技术设计明确纯无状态才回退无登记纯签名 JWT（此时不建会话表、Cookie 承载自包含签名凭证、filter 从 Cookie 取凭证只验签不查登记）。
- **多登策略读澄清台账**：`backend/_meta/clarify-decisions.json` 中 `authz` 域「是否允许账号多登」决策 → `login.allow-multi-session` 取该值；台账无该决策 → 缺省 `true`（允许，只登记不驱逐）。
- 登录端点路径在技术设计有明确规定 → 用设计值（须 `/api` 开头）；无 → 缺省 `/api/auth/login`。
- 登录标识列在所选账号实体 `entity-*.md` DDL 有唯一键/账号语义列 → 用该列作登录标识（不写死 `account`/`username`）；密码列用该实体存哈希的列（不写死 `password`/`password_hash`）。
- admin 种子 INSERT 列名与所选账号实体 DDL 一致 → 命中正确；列名臆造（如假设 `password_hash` 但实体列名是 `password`）→ 命中反例。
- **阶段一/阶段三职责切分**：阶段一登录任务**只**生成登录基础设施（`SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter`/`LoginController`/`LoginService`）+ 登录自有的 `AuthRepository`（登录查询投影）+ 账号表 DDL + admin 种子。**禁止**在阶段一生成账号实体的 entity 类 / CRUD Repository（`<Entity>Repository`）/ CRUD Service / DTO / VO / QueryDTO / test——那些归阶段三按 §9 正常生成完整 CRUD。登录查询走**登录自有的 `AuthRepository`**（见下），不重用/不预建阶段三的账号 CRUD Repository，避免跨阶段同名类碰撞或 merge。

## 包归属（遵循 README §2 MVC 三层 + §9.3 子包规则派生，非另造）

登录任务的类按技术设计 README 第 2 章 MVC 三层（`controller / service / dao(repository)`）+ 第 9 章 §9.3 子包规则落包。**全局 Spring 安全 infra 与登录业务逻辑分置**——安全 infra 是整个应用共用的全局 infra（与 `CorsConfig`/`GlobalExceptionHandler` 同性质），不归属某个业务域：

- **全局 Spring 安全 infra 类**（`SecurityConfig` / `JwtUtil` / `JwtAuthenticationFilter`）→ **全局共享 infra 模块的 `config` 子包**：即 base-architecture 骨架已放置 `CorsConfig` / `GlobalExceptionHandler` / `ApiResponse` 的那个模块（读骨架发现其真实包名，**不硬编码 `common`**——不同应用骨架可能命名 `common`/`shared`/`infrastructure`，以骨架实际为准），落其 `config` 子包，与 `CorsConfig` 同侧。这些是全局过滤链/JWT 工具/安全配置，整个应用共用，不塞进业务域包（否则出现"域包一个 config + 全局一个 config"的双 config 目录，且全局 infra 误归域）。
- `LoginController` → `<modulePackage>.controller.LoginController`（§2 controller 层；`<modulePackage>` = 登录所属域的 modulePackage，见 §9.2；阶段一为登录验证提前生成此一个 Controller 是例外，其余 Controller 仍归阶段四业务模块）。
- `LoginService` → `<modulePackage>.LoginService`（§9.3「Service 无子包」）。
- `AuthRepository` → `<modulePackage>.repository.AuthRepository`（§9.3 repository 子包；**类名区别于阶段三的 `<Entity>Repository`**，两者查同一张账号表但所有权分离）。
- `SessionRepository` → `<modulePackage>.repository.SessionRepository`（§9.3 repository 子包；登录自有的会话登记表 `@Mapper`，会话表是**阶段一内置 infra 非业务实体**，无对应 `<Entity>Repository`/CRUD）。
- `LoginRequest`（登录请求 DTO）+ `LoginAccount`（登录投影 record）→ `<modulePackage>.dto`（§9.3 dto 子包）。

`LoginService` 跨包引用全局 `JwtUtil`（infra 工具）属正常，不违反零跨实体铁律（该铁律禁的是 import 其它实体的 Service/Repository，不禁 infra 工具）。

类命名优先跟 README §9；§9 不覆盖时用通用默认（`LoginService`/`LoginController`/`LoginRequest`/`AuthRepository`/`LoginAccount`/`SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter`）。**安全/追踪类自定义 `Filter` / `@Component` 必须显式命名 bean，禁与 Spring Boot 内置 filter bean 同名**（`requestContextFilter`/`characterEncodingFilter`/`hiddenHttpMethodFilter`/`formContentFilter` 一律不可复用，如 `@Component("jwtAuthenticationFilter")`）——同名即 `BeanDefinitionOverrideException`，或内置 bean 被覆盖致 `X-Trace-Id` 不回写、MDC 为空；与 `[实现知识库目录对应路径]/shared/java-spring-bean.md` 规则 4.10 同源，生成时照该文执行。

## 反例（绝对禁止）

- ❌ 写死项目实体名/表名/列名（如硬编码 `internal_user`/`account`/`password_hash`）——本文不含这些，一切取自 `entity-*.md` DDL。
- ❌ 明文存密码列、`NoOpPasswordEncoder`、`noop`/`{noop}` 前缀明文。
- ❌ 运行时 `BCryptPasswordEncoder().encode("Admin123456")` 算哈希——必须用本文钉死的定值，禁止运行时计算。
- ❌ 开 Spring HttpSession（`SessionCreationPolicy.ALWAYS`/`IF_REQUIRED`）实现「有状态」——有状态默认走的是**应用层 `Set-Cookie` + 会话登记表**，Spring 层仍 `STATELESS`（应用层自有 `Set-Cookie` + 会话登记表，非 Spring HttpSession）。
- ❌ 有状态默认下**不建会话登记表** / `LoginService` 签发 token 后**不登记会话** / `JwtAuthenticationFilter` 只验签**不查登记表 active**——三者缺一则退化成不可失效、不可追踪的纯无状态，并发单测与多登控制均落空（仅技术设计明确要求纯无状态时才允许）。
- ❌ 自造 `sys_session`/`sys_token` 等设计外系统表、按本文模板私造表名绕开实体通道建会话表——**会话登记表走统一实体通道**（authz 域实体提取进 `entity-*.md`，表名/列名/DDL 以会话实体 entity 真实 DDL 为准），阶段一只按 entity DDL 建表落地；并行自造路径产物对种子白名单/覆盖判定不可见（j8v3t2 教训）。注意区分：会话实体进实体提取 ≠ 把它当业务实体设计——authz 段B 指引给会话实体的是登录承载语义（jti/过期/活跃列），不臆造业务语义。
- ❌ 会话登记表存**明文 token**——存 JWT 的 `jti` 或 token 摘要哈希即可（够按 token 失效/查活跃）。
- ❌ 逐 Controller `@CrossOrigin` 绕过统一 CORS；关闭 Spring Security 消除错误；**`csrf().disable()` 全局禁 CSRF**（cookie 会话模型下 Cookie 自动携带的写请求必须有 CSRF 防护——double-submit cookie + `X-XSRF-TOKEN` 请求头校验（**CSRF 主防**，header 名须用 Spring `CookieCsrfTokenRepository` 默认 `X-XSRF-TOKEN`，禁写 `X-CSRF-Token`）；**会话/CSRF cookie 的 `SameSite` 运行时按 `request.isSecure()` 动态推导**（同上「配置」段：secure 真→`None;Secure`，假→`Lax`），**不作 CSRF 兜底**（`Lax` 在跨源 iframe 预览不发送、既不防 CSRF 又断登录），CORS 不能替代 CSRF；GET/HEAD 安全方法不得产生业务写入）。**CSRF cookie（`XSRF-TOKEN`）SameSite 动态化**：`CookieCsrfTokenRepository` 的 `sameSite` 是静态字段无法按请求动态、`setSameSite("None")` 静态会在内部 http 同站上下文产 `None` 无 `Secure` 被浏览器全拒；且 Spring Security 6.x `saveToken` 经 `mapToCookie`→`response.addCookie(Cookie)` 写出（**非** `addHeader("Set-Cookie")`），故 servlet 层 response 包装 filter 拦不到——须**包装 `CookieCsrfTokenRepository`**：实现 `CsrfTokenRepository`，`generateToken`/`loadToken` 委托，`saveToken` 中 `request.isSecure()` 时用 `HttpServletResponseWrapper` 包住传给 delegate 的 response、override `addCookie(Cookie)`→`cookie.setAttribute("SameSite","None")` 后 `super.addCookie(cookie)`（Servlet 6.0 `setAttribute`，Tomcat `Rfc6265CookieProcessor` 渲染），非 secure 时透传 delegate 保持默认 `Lax`；`SecurityConfig` 用该包装类 `.csrfTokenRepository(<包装类>.withHttpOnlyFalse())` 替换 `CookieCsrfTokenRepository.withHttpOnlyFalse()`。
- ❌ 纯 API 后端不注册 CSRF token 暴露 filter —— `CookieCsrfTokenRepository` 的 token 是**懒加载**的（只在 `CsrfToken` request attribute 被访问时才生成并写 cookie），纯 API 后端无模板渲染不天然触发 token 生成；`ignoringRequestMatchers` 让 `CsrfFilter` 对被豁免请求（如 login）直接跳过、不设 attribute，被豁免请求的响应不下发 `XSRF-TOKEN` cookie。须在 `CsrfFilter` **之前**注册**守卫式** filter：仅当请求未携带 `XSRF-TOKEN` cookie 时才 `loadDeferredToken().get()` + `saveToken(...)` 物化写 cookie。**严禁每请求无条件 generate/save**——每请求强制轮换与 `CsrfFilter` 内建 rotate 冲突，一次响应同时下发新 token 与删除 cookie，浏览器 token 被清空后受保护写（logout 等）全部 403（2026-09-08 阶段四 e2e 实证）；**也严禁为避冲突把暴露 filter 整个删掉**——删掉则纯 API 后端永远无 token cookie，写请求回到"缺 token 403"。
- ❌ `SecurityConfig` `.csrf()` 链未对 login 端点配 `.ignoringRequestMatchers("<登录端点路径>")` —— login POST 是会话第一个请求，此时无 CSRF token 可校验，`CsrfFilter` 直接拦截返 403；显式 token 暴露 filter（`loadDeferredToken` + `saveToken`）解决的是**后续请求**的 `XSRF-TOKEN` cookie 下发，解决不了 login POST 本身被拦截。login 端点必须在 `ignoringRequestMatchers` 豁免 CSRF（它是认证入口，未建立会话前无法带 token）。
- ❌ `SecurityConfig` 重复定义 `@Bean corsConfigurationSource()` 与骨架 `CorsConfig` 同名 bean —— Spring Boot 默认 `allow-bean-definition-overriding=false`，两个同名 bean 致 `BeanDefinitionOverrideException` 启动失败。骨架已定义 `corsConfigurationSource` bean 时，SecurityConfig 须构造器注入 `CorsConfigurationSource` 复用，禁重复定义 `@Bean`。
- ❌ `SecurityConfig` 未配 `AuthenticationEntryPoint` 致未认证请求返默认 403（任务/spec 要求返 401）——Spring Security `STATELESS` + 无 `httpBasic()`/`formLogin()` 默认走 `Http403ForbiddenEntryPoint`，须显式 `.exceptionHandling(e -> e.authenticationEntryPoint(...))` 返 401 + 统一信封失败方法（如 ruoyi 栈 `ApiResponse.fail(<BIZ_未认证>)`）。
- ❌ 硬编码 JWT token、把 JWT secret 写进 `application.yml.template` 真实值、secret 留占位符。
- ❌ 运行时建表、运行时跑种子初始化器（`ApplicationRunner`/`data.sql`/启动迁移器灌 admin）——建表与种子均由生成期 agent 通过 `sql-exec` CLI 收口（见 `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md`）。
- ❌ 阶段一 seed 角色行（role/permission 表行）——role 表留阶段三建，admin 角色归属阶段四灌。
- ❌ 自造 `sys_user`/`sys_role`/`sys_permission` 等表——登录最小集实体按 `entity-*.md` DDL 建表，不造系统表。
- ❌ 把 MVC 三层类或 infra 类平铺在 `<modulePackage>` 包根（违反 §2 三层组织）——`LoginController` 落 `controller`、`LoginService` 落包根（无子包）、`AuthRepository` 落 `repository`、`LoginRequest`/`LoginAccount` 落 `dto`、`SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter` 落全局 infra 模块的 `config`（与 `CorsConfig` 同侧）。
- ❌ 自造 `<modulePackage>.security`/`auth` 等未在 §9/约定范围内的子包；也禁把全局安全 infra（`SecurityConfig`/`JwtUtil`/`JwtAuthenticationFilter`）塞进业务域包的 `config`——全局 infra 统一落骨架的全局 infra 模块 `config`（与 `CorsConfig` 同侧），避免出现域包 + 全局各一个 `config` 的双目录。
- ❌ 登录端点不带 `/api` 前缀（如 `/auth/login`）——前端同源 `/api` 代理合同要求后端 HTTP 端点一律 `/api` 开头，不带前缀前端无法到达。
- ❌ 阶段一生成账号实体的 CRUD Repository/Service/DTO/VO/QueryDTO/test——账号实体的完整 CRUD 归阶段三按 §9 正常生成，阶段一只生成登录基础设施 + 登录投影 `AuthRepository` + DDL + admin 种子。
- ❌ 登录响应正文含 token、session id 或等价原始凭证（违浏览器会话安全：HttpOnly Cookie 是唯一凭证载体，前端 JS 不可读）——必须 `Set-Cookie` HttpOnly 写会话凭证 + 信封成功方法（如 ruoyi `ApiResponse.success(...)`）无凭证正文（`code=200`）。禁裸返 `{"token":"..."}` 或信封成功方法返 `{"token":...}`。
- ❌ 前端登录页硬判 `res.code==='0'` 判定成功（违 spec §9.4 成功码=200，且 `code=0` 非任何既有框架约定，是 LLM 先验臆加）——成功判定走 `apiClient` 的 `ApiResponse` 信封 + successCodes（含 `200`/`201`）。
- ❌ 前端登录页臆造 inline `{token,user}` 单端点契约（user RBAC 属阶段四 `/auth/me` 授权上下文，登录认证响应正文不含原始凭证、user 画像走 `/me` 单独取）。
- ❌ 阶段一 `/me` 返硬编 RBAC（`isSuperAdmin=true`/`role`/`permissions` 等，违"admin 角色归属阶段四灌库"，阶段一无 RBAC 表）；阶段四新建 `@GetMapping("/me")`/`CurrentUserController`（与阶段一 `LoginController` 的 `/me` 映射碰撞，须**改 `LoginController.me()` 方法体 enrich** 而非重生端点）；阶段四重生 `POST /api/auth/login`（阶段一已 owns，重生致重复 Controller/端点冲突）。阶段一生成 `/me` 认证层（`{id, username}`）是**允许的**。

## 正确写法

### SecurityConfig

> **版本适配（硬条款，非注记）**：本节示例按 Spring Boot 3.x / Java 21 书写。应用 Java 主版本（tech-stack.json `backend.languageVersion`）= `8`（Boot 2.x 线）时：① `jakarta.*` 全部换 `javax.*`（`jakarta.servlet.http.HttpServletRequest` → `javax.servlet.http.HttpServletRequest`，`HttpServletResponse`/`Cookie` 同理）；② `var` 局部变量推断（Java 10+）换显式声明类型；③ `instanceof` 模式匹配（Java 16+）换经典 instanceof + 强转两步；④ lambda 与流式写法两者通用可照抄。读骨架既有 import 或 pom spring-boot 版本判定，禁凭习惯写错命名空间——命名空间错在 Boot 2.x/3.x 下都是编译错。

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;
    private final CorsConfigurationSource corsConfigurationSource;  // 骨架 CorsConfig 已定义此 bean，注入复用，禁重复 @Bean（否则 BeanDefinitionOverrideException）

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter,
                          CorsConfigurationSource corsConfigurationSource) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.corsConfigurationSource = corsConfigurationSource;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // 纯 API 后端 CSRF token 暴露：CookieCsrfTokenRepository 懒加载，无模板渲染不触发 token 生成；
        //   ignoringRequestMatchers 让 CsrfFilter 跳过 login，login 响应不下发 XSRF-TOKEN cookie。
        //   须在 CsrfFilter 之前注册 filter 显式 loadDeferredToken + saveToken 写 cookie，前端才能拿到 token。
        org.springframework.security.web.csrf.CookieCsrfTokenRepository csrfRepository =
            org.springframework.security.web.csrf.CookieCsrfTokenRepository.withHttpOnlyFalse();  // 可读 cookie（前端 JS 读 XSRF-TOKEN 拼 X-XSRF-TOKEN 请求头）；withDefaults() 在 Spring Security 6.4/Boot 3.5.x 不存在
        http
            .csrf(csrf -> csrf
                .csrfTokenRepository(csrfRepository)  // double-submit cookie（可读 CSRF cookie + X-XSRF-TOKEN 请求头同步校验），禁 disable；CORS 不能替代 CSRF
                .csrfTokenRequestHandler(new org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler())  // 从 X-XSRF-TOKEN 请求头读 token 值
                .ignoringRequestMatchers("<登录端点路径，须 /api 开头，缺省 /api/auth/login>"))  // login 是会话第一个请求、无 CSRF token 可校验，不豁免则 CsrfFilter 拦截返 403；显式 token 暴露 filter 解决后续请求 cookie 下发，解决不了 login POST 本身被拦
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))  // Spring 层无 HttpSession；有状态体现在应用层 Set-Cookie + 会话登记表（LoginService 登记 + Filter 查登记），非 Servlet 会话
            .cors(cors -> cors.configurationSource(corsConfigurationSource))  // 统一 CORS，用注入的骨架 CorsConfig bean，禁逐 Controller @CrossOrigin
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("<登录端点路径，须 /api 开头，缺省 /api/auth/login>", "/actuator/**", "/error").permitAll()
                .anyRequest().authenticated())
            // CSRF token 暴露 filter：在 CsrfFilter 之前执行，**守卫式**——仅当请求未携带 XSRF-TOKEN cookie 时
            //   才物化 token 并写 cookie；已有 cookie 严禁再 generate/save。纯 API 后端无模板渲染，不注册此 filter
            //   则 login（被 ignoringRequestMatchers 豁免）和普通 GET 都不下发 XSRF-TOKEN cookie。
            //   ⚠ 每请求无条件 loadDeferredToken().get()+saveToken() = 每请求强制轮换，与 CsrfFilter 内建 rotate
            //   冲突：一次响应同时下发新 token 与删除 cookie（Max-Age=0），浏览器 token 被清空后所有写请求 403
            //   （2026-09-08 阶段四 e2e 实证，findings：/me 401、业务 POST 403）。
            .addFilterBefore((request, response, chain) -> {
                // 经典 instanceof + 强转两步（Java 8 与 21 通用；禁 instanceof 模式匹配——Java 16+ 语法，8 下编译错）
                if (request instanceof jakarta.servlet.http.HttpServletRequest
                        && response instanceof jakarta.servlet.http.HttpServletResponse) {
                    jakarta.servlet.http.HttpServletRequest httpRequest = (jakarta.servlet.http.HttpServletRequest) request;
                    jakarta.servlet.http.HttpServletResponse httpResponse = (jakarta.servlet.http.HttpServletResponse) response;
                    boolean hasTokenCookie = httpRequest.getCookies() != null
                        && java.util.Arrays.stream(httpRequest.getCookies()).anyMatch(c ->
                            "XSRF-TOKEN".equals(c.getName()) && c.getValue() != null && !c.getValue().isEmpty());
                    if (!hasTokenCookie) {
                        // 显式声明类型（禁 var——Java 10+ 语法，8 下编译错）
                        org.springframework.security.web.csrf.CsrfToken csrfToken =
                            csrfRepository.loadDeferredToken(httpRequest, httpResponse).get();  // 懒物化：无 cookie 才生成
                        csrfRepository.saveToken(csrfToken, httpRequest, httpResponse);  // 写 cookie（仅首次/缺 cookie 时走到这里）
                    }
                    // 已带 token cookie 的请求：什么都不做，保持 token 稳定，交还 CsrfFilter 正常校验
                }
                chain.doFilter(request, response);
            }, org.springframework.security.web.csrf.CsrfFilter.class)
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
            // 未认证请求返 401（非默认 403）：STATELESS + 无 httpBasic/formLogin 默认走 Http403ForbiddenEntryPoint，
            //   须显式配 AuthenticationEntryPoint 返 401 + 统一信封失败方法，否则"logout 后重放返 401"验收必失败。
            .exceptionHandling(e -> e.authenticationEntryPoint((request, response, authException) -> {
                response.setStatus(jakarta.servlet.http.HttpServletResponse.SC_UNAUTHORIZED);
                response.setContentType("application/json;charset=UTF-8");
                // 统一信封失败方法，类名/shape 取 skeleton-conventions.json responseEnvelope 真值（如 ruoyi ApiResponse.fail）
                response.getWriter().write(/* ApiResponse.fail(<BIZ_未认证>, "未认证或会话已过期") 信封 JSON */ "");
            }));
        return http.build();
    }
}
```

### JwtUtil

```java
@Component
public class JwtUtil {
    @org.springframework.beans.factory.annotation.Value("${<appName>.jwt.secret}")
    private String secret;
    @org.springframework.beans.factory.annotation.Value("${<appName>.jwt.expire-millis:86400000}")
    private long expireMillis;

    public String generate(String subject) {
        return io.jsonwebtoken.Jwts.builder()
            .setSubject(subject)
            .setId(java.util.UUID.randomUUID().toString())      // jti：会话登记表按此关联，失效精确到单 token（有状态默认）
            .setIssuedAt(new java.util.Date())
            .setExpiration(new java.util.Date(System.currentTimeMillis() + expireMillis))
            .signWith(io.jsonwebtoken.security.Keys.hmacShaKeyFor(secret.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
            .compact();
    }

    public io.jsonwebtoken.Claims parse(String token) {
        return io.jsonwebtoken.Jwts.parserBuilder()
            .setSigningKey(io.jsonwebtoken.security.Keys.hmacShaKeyFor(secret.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
            .build()
            .parseClaimsJws(token)
            .getBody();
    }
}
```

### JwtAuthenticationFilter

```java
@Component("jwtAuthenticationFilter")  // 显式命名 bean，禁与 Spring Boot 内置 filter bean 同名（见 shared/java-spring-bean.md 规则 4.10）
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    private final JwtUtil jwtUtil;
    private final SessionRepository sessionRepository;   // 有状态默认：验签后再查会话登记表 active
    public JwtAuthenticationFilter(JwtUtil jwtUtil, SessionRepository sessionRepository) {
        this.jwtUtil = jwtUtil; this.sessionRepository = sessionRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
            throws ServletException, IOException {
        // 从 HttpOnly Cookie 取会话凭证（承载 JWT），禁只解析 Authorization Bearer。
        // Cookie 名取 application.yml 的 {appName}.login.cookie.name（缺省 <appName>_session），不硬编码。
        jakarta.servlet.http.Cookie[] cookies = req.getCookies();   // Spring Boot 3.x（jakarta）；Boot 2.x 改 javax.servlet.http.Cookie
        String sessionJwt = null;
        if (cookies != null) {
            for (jakarta.servlet.http.Cookie c : cookies) {
                if ("<appName>_session".equals(c.getName())) { sessionJwt = c.getValue(); break; }
            }
        }
        if (sessionJwt != null) {
            try {
                io.jsonwebtoken.Claims claims = jwtUtil.parse(sessionJwt);
                // 有状态校验：jti 必须在会话登记表中 active（登出/驱逐/单点登录会把旧会话置失效 → 此处查不到 → 401）。
                if (sessionRepository.isActive(claims.getId())) {   // claims.getId() = 签发时写入的 jti
                    var auth = new org.springframework.security.authentication.UsernamePasswordAuthenticationToken(
                        claims.getSubject(), null, java.util.Collections.emptyList());
                    SecurityContextHolder.getContext().setAuthentication(auth);
                }
                // 非 active：不设 SecurityContext，后续 anyRequest().authenticated() 返 401
            } catch (Exception ignored) {
                // 无效凭证：不设 SecurityContext，后续 anyRequest().authenticated() 返 401
            }
        }
        chain.doFilter(req, res);
    }
}
```

### LoginService + 登录 Controller

```java
// 登录投影类：只取登录标识列 + 密码列（够 LoginService 校验凭据即可），不映射账号实体全部列。
//   登录标识列名、密码列名取自所选账号实体 entity-*.md DDL（不写死 username/password_hash）。
//   放 <modulePackage>.dto 包。这是登录自有的只读投影，不是账号实体的 entity 类（entity 类归阶段三按 §9 生成）。
//   形态按应用 Java 主版本（tech-stack.json backend.languageVersion）二选一：
//   Java 21 → record（下行第一段）；Java 8 → final class + 显式 getter（下行第二段；record 是 Java 16+ 语法，8 下编译错）。
public record LoginAccount(String <loginIdentifierColumn>, String <passwordColumn>) {}

// —— Java 8 等价写法（languageVersion=8 时用这段，禁 record）——
public final class LoginAccount {
    private final String <loginIdentifierColumn>;
    private final String <passwordColumn>;
    public LoginAccount(String <loginIdentifierColumn>, String <passwordColumn>) {
        this.<loginIdentifierColumn> = <loginIdentifierColumn>;
        this.<passwordColumn> = <passwordColumn>;
    }
    public String <loginIdentifierColumn>() { return <loginIdentifierColumn>; }   // 访问器名派生规则与 record 一致
    public String <passwordColumn>() { return <passwordColumn>; }
}

// AuthRepository：登录自有的 @Mapper，只含登录查询（按登录标识列查账号行，返回 LoginAccount 投影）。
//   放 <modulePackage>.repository 包；类名 AuthRepository 区别于阶段三的 <Entity>Repository（CRUD）。
//   两者查同一张账号表但所有权分离——阶段一 owns 登录查询，阶段三 owns CRUD，无写冲突、无跨阶段 merge。
@Mapper
public interface AuthRepository {
    @org.apache.ibatis.annotations.Select(
        "SELECT <登录标识列> AS <loginIdentifierColumn>, <密码列> AS <passwordColumn> " +
        "FROM <账号表名> WHERE <登录标识列> = #{loginIdentifier} LIMIT 1")
    LoginAccount findByLoginIdentifier(String loginIdentifier);
}

// SessionRepository：登录自有的 @Mapper，会话登记表（内置 infra，非业务实体）的最小读写。
//   放 <modulePackage>.repository 包（与 AuthRepository 同侧，所有权归阶段一登录）。
//   表名/列名按会话登记表模板 DDL 的真实列取（<jti列>/<账号标识列>/<是否活跃列>/<过期时间列>）。
//   有状态默认三件事：登录 APPEND 活跃会话、Filter 查 jti active、单点登录时失效账号旧会话。
@Mapper
public interface SessionRepository {
    // 登记一条活跃会话（登录成功后调用）：jti + 账号标识 + 过期时间，活跃标置 1。
    @org.apache.ibatis.annotations.Insert(
        "INSERT INTO <会话表名> (<jti列>, <账号标识列>, <过期时间列>, <是否活跃列>) " +
        "VALUES (#{jti}, #{loginIdentifier}, #{expireAt}, 1)")
    void register(String jti, String loginIdentifier, java.util.Date expireAt);

    // Filter 校验：该 jti 存在、活跃、未过期。
    @org.apache.ibatis.annotations.Select(
        "SELECT COUNT(1) > 0 FROM <会话表名> " +
        "WHERE <jti列> = #{jti} AND <是否活跃列> = 1 AND <过期时间列> > NOW()")
    boolean isActive(String jti);

    // 单点登录（多登=不允许时）：登录前失效该账号所有旧活跃会话。
    @org.apache.ibatis.annotations.Update(
        "UPDATE <会话表名> SET <是否活跃列> = 0 WHERE <账号标识列> = #{loginIdentifier} AND <是否活跃列> = 1")
    void deactivateAllFor(String loginIdentifier);
}

// LoginService：注入 AuthRepository（登录投影查询）+ SessionRepository（会话登记）+ PasswordEncoder + JwtUtil，
//   BCrypt 比对密码，签发带 jti 的 JWT，并按多登策略登记会话（有状态默认）。
//   放 <modulePackage> 包根（§9.3 Service 无子包）。类命名优先跟 README §9；§9 不覆盖时用通用默认。
//   注意：LoginService 只做登录校验+签发 token+登记会话，不做账号 CRUD（CRUD 归阶段三 <Entity>Service）。
@Service
public class LoginService {
    private final AuthRepository authRepository;
    private final SessionRepository sessionRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    // 多登开关：默认允许（只登记不驱逐）。application.yml 未配则取 true。
    @org.springframework.beans.factory.annotation.Value("${<appName>.login.allow-multi-session:true}")
    private boolean allowMultiSession;

    public LoginService(AuthRepository authRepository, SessionRepository sessionRepository,
                        PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.authRepository = authRepository; this.sessionRepository = sessionRepository;
        this.passwordEncoder = passwordEncoder; this.jwtUtil = jwtUtil;
    }

    public String login(String loginIdentifier, String rawPassword) {
        var account = authRepository.findByLoginIdentifier(loginIdentifier);
        if (account == null || !passwordEncoder.matches(rawPassword, account.<passwordColumnAccessor>())) {
            throw new IllegalArgumentException("凭据错误");
        }
        // 多登=不允许（单点登录）：登记本次前先失效该账号所有旧活跃会话；多登=允许（默认）：不驱逐，直接 APPEND。
        if (!allowMultiSession) {
            sessionRepository.deactivateAllFor(loginIdentifier);
        }
        String token = jwtUtil.generate(loginIdentifier);
        io.jsonwebtoken.Claims claims = jwtUtil.parse(token);            // 取回 jti + 过期时间用于登记
        sessionRepository.register(claims.getId(), loginIdentifier, claims.getExpiration());
        return token;   // 供 Controller 写 HttpOnly Set-Cookie（承载该 JWT），不进响应正文
    }

    // 登出：失效该账号所有活跃会话（满足浏览器会话安全规则5"登出必须使服务端会话失效"，禁只清前端状态）。
    //   Controller 从 SecurityContext 取 principal（=登录标识值）调本方法，并返过期同名同 Path Cookie。
    public void logout(String loginIdentifier) {
        sessionRepository.deactivateAllFor(loginIdentifier);
    }
}

// 登录/登出 Controller：路径取技术设计值（须 /api 开头），缺省 /api/auth/login、/api/auth/logout。
//   放 <modulePackage>.controller 包。阶段一为登录验证提前生成此一个 Controller 是例外，其余 Controller 归阶段四。
//   登录响应走统一信封 ApiResponse（spec §9）：成功 ApiResponse.success(...)（code=200，**正文不含原始凭证**），
//   同时由服务端写 HttpOnly Set-Cookie 承载会话凭证（JWT）；凭据错误 ApiResponse.fail(<BIZ_错误码>) 配 401，参数缺失 400。
//   登出 ApiResponse.success(...)（code=200）+ 返过期同名同 Path Cookie，调 LoginService.logout 使服务端会话失效（禁只清前端状态）。
//   ApiResponse 类型取自骨架全局 infra 模块（与 CorsConfig 同侧那个模块，读骨架发现真实包名不硬编码 common）。
@RestController
@RequestMapping("/api/auth")
public class LoginController {
    private final LoginService loginService;
    public LoginController(LoginService loginService) { this.loginService = loginService; }

    @PostMapping("/login")   // 缺省；设计有明确 /api 路径则改设计值
    public ApiResponse<java.util.Map<String, String>> login(@RequestBody LoginRequest req, HttpServletResponse res, HttpServletRequest servletRequest) {
        if (req == null || req.get<LoginIdentifierField>() == null || req.get<LoginIdentifierField>().isBlank()
                || req.get<PasswordField>() == null || req.get<PasswordField>().isBlank()) {
            return ApiResponse.fail("<BIZ_参数校验失败>", "账号或密码不能为空");   // 配 400（由 GlobalExceptionHandler 或 advice 映射）
        }
        try {
            String jwt = loginService.login(req.get<LoginIdentifierField>().trim(), req.get<PasswordField>());
            setSessionCookie(res, jwt, servletRequest);          // HttpOnly Set-Cookie 承载 JWT，不进响应正文；Secure/SameSite 运行时按 isSecure 推导
            return ApiResponse.success(java.util.Map.of());  // code=200，正文无原始凭证
        } catch (IllegalArgumentException ex) {
            return ApiResponse.fail("<BIZ_凭据错误>", ex.getMessage());  // 配 401
        }
    }

    @PostMapping("/logout")
    public ApiResponse<java.util.Map<String, String>> logout(HttpServletResponse res, HttpServletRequest servletRequest) {
        var principal = SecurityContextHolder.getContext().getAuthentication().getName();  // = 登录标识值（filter 已设）
        loginService.logout(principal);                     // 失效该账号所有活跃会话（服务端会话失效）
        expireSessionCookie(res, servletRequest);            // 返过期同名同 Path Cookie，Secure/SameSite 与下发同源（按 isSecure）
        return ApiResponse.success(java.util.Map.of());      // code=200
    }

    // 写 HttpOnly 会话 Cookie（承载 JWT，属 master 规则1"不透明会话标识或签名凭证"的签名凭证分支）。
    //   Secure/SameSite 运行时按 request.isSecure() 动态推导（非静态 yml 键，见「配置」段）；ResponseCookie.toString() 产出带 SameSite 的合法 Set-Cookie 头。
    private void setSessionCookie(HttpServletResponse res, String jwt, HttpServletRequest req) {
        boolean secure = req.isSecure();                     // 经 https 网关（forward-headers 信任 X-Forwarded-Proto）→ true；内部 http → false
        String sameSite = secure ? "None" : "Lax";           // secure→None（跨源 iframe 第三方发送必需，须同 Secure）；非 secure→Lax（同站）
        org.springframework.http.ResponseCookie c = org.springframework.http.ResponseCookie
            .from("<appName>_session", jwt)
            .httpOnly(true)
            .secure(secure)
            .path(/* yml login.cookie.path，缺省 */ "/")
            .maxAge(java.time.Duration.ofMillis(/* yml jwt.expire-millis */ 86400000L))
            .sameSite(sameSite)
            .build();
        res.addHeader("Set-Cookie", c.toString());
    }

    private void expireSessionCookie(HttpServletResponse res, HttpServletRequest req) {
        boolean secure = req.isSecure();                     // 与下发同作用域过期，须同 Secure/SameSite
        String sameSite = secure ? "None" : "Lax";
        org.springframework.http.ResponseCookie c = org.springframework.http.ResponseCookie
            .from("<appName>_session", "")
            .httpOnly(true).secure(secure).path("/").maxAge(java.time.Duration.ZERO).sameSite(sameSite)   // 与下发同作用域过期，须同 SameSite
            .build();   // 同名同 Path 过期，浏览器立即丢弃
        res.addHeader("Set-Cookie", c.toString());
    }
}
```

> `LoginAccount` 形态按应用 Java 主版本：Java 21 用 record（访问器方法名由列名派生，如 `password_hash` 列→ `passwordHash()` 访问器）；Java 8 用 final class + 显式 getter（命名派生规则相同，`<passwordColumnAccessor>` 即该访问器），取自所选账号实体 DDL 的密码列名。`LoginRequest` 的 getter 同理取设计真实字段名。**不写死** `getUsername`/`getPassword`。`HttpServletResponse` 类型随骨架 Spring Boot 版本（Boot 3.x `jakarta.servlet.http.HttpServletResponse`，Boot 2.x `javax.servlet.http.HttpServletResponse`）——这是硬条款，按 tech-stack.json `backend.languageVersion` / 骨架既有 import 判定，禁凭习惯写错命名空间。

### `/api/auth/me` 端点（分层 owns：阶段一认证层 + 阶段四 RBAC 扩充）

`/me` 的 `@GetMapping("/api/auth/me")` 映射与**认证层响应**对**阶段一 `LoginController`** owns（与 login/logout 同 controller，见下「包归属」阶段一例外），前端阶段二调 `/me` 时即就绪——读 `SecurityContext` 认证主体（JWT subject = 登录标识值）查 account 行，返 `ApiResponse.success({ "user": { <id>, <username> } })`（`code=200`），不查 role/permission/region、不硬编 `isSuperAdmin`。role/permission/region 表由阶段三按 `entity-*.md` DDL 建表后，**阶段四扩充**——提供 `CurrentUserService` + `UserProfile` record，**修改 `LoginController.me()` 方法体**委托 `currentUserService.loadUserProfile(principal)` 补全 `<realName>/<role>/<level>/<permissions[]>/<regionId>/<isSuperAdmin>`。阶段四触发门 = `stage1-login-base.json` enabled 且 `entity-*.md` 含 RBAC 实体（role/permission/region 之一），不依赖 `specs/checklist-登录.md` 派发；无 RBAC 实体的纯登录 spec，阶段一 minimal `/me` 即最终答案。**阶段四禁新建 `@GetMapping("/me")`/`CurrentUserController`**（与阶段一映射碰撞，`AmbiguousMappingException`）；**禁重生 `POST /api/auth/login`、`POST /api/auth/logout`**（阶段一已 owns）。

`/me` 读阶段一 `JwtAuthenticationFilter`（从 HttpOnly Cookie 取凭证、验签、查会话登记表 active）已设的 `SecurityContext` 认证主体（JWT subject = 登录标识值）。阶段一认证层：按主体查 account 行返 `{ <id>, <username> }`。阶段四 RBAC 扩充：`currentUserService.loadUserProfile(principal)` 按主体查账号行 → 联角色 → 联 `RolePermission` 取权限码集合 → 联 `Region` 取区域 → 组装 `UserProfile` record 返 `ApiResponse.success({ "user": profile })`（`code=200`）。user 画像字段（`id`/`username`/`realName`/`role`/`level`/`permissions[]`/`regionId`/`isSuperAdmin`）的**取值与字段名以技术设计为准**（如四级管理员层级 province/city/county/school → `level`、行政区域数据范围 → `regionId`、超管 → `isSuperAdmin`），不写死。

```java
// 当前用户画像类：字段取值对齐技术设计（四级层级/区域/角色权限/超管），不写死列名/枚举值。
//   放登录业务模块的 dto 子包。由阶段四生成（阶段一无 RBAC 表产不出）。
//   形态按应用 Java 主版本：Java 21 → record（下行）；Java 8 → final class + 显式 getter（等价改写，禁 record）。
public record UserProfile(String id, String username, String realName, String role,
                          String level, java.util.List<String> permissions,
                          java.lang.Long regionId, java.lang.Integer isSuperAdmin) {}

// /me 端点：阶段一 LoginController（同 login/logout，阶段一例外 controller）已 owns @GetMapping("/me")。
//   阶段一认证层：me() 读 SecurityContext 主体查 account 行返 {id, username}（前端阶段二即用）。
//   阶段四 RBAC 扩充：提供 CurrentUserService + UserProfile，改 me() 方法体委托 loadUserProfile(principal) 补全 RBAC 字段。
//   禁阶段四新建 @GetMapping("/me")/CurrentUserController（与阶段一映射碰撞，AmbiguousMappingException）。
//   组装用到的账号/角色/权限/区域查询走各自 Repository（阶段三已生成的 <Entity>Repository），不做新跨实体 Service。
// 阶段一 LoginController（与 login/logout 同 controller）：
//   @GetMapping("/me")
//   public ApiResponse<java.util.Map<String, ?>> me() {
//       var principal = SecurityContextHolder.getContext().getAuthentication().getName();   // JWT subject = 登录标识值
//       // 阶段一认证层：查 account 行返 {id, username}（不查 role/permission/region，不硬编 isSuperAdmin）
//       return ApiResponse.success(java.util.Map.of("user", loginService.loadLoginIdentity(principal)));  // {id, username}
//   }
// 阶段四 enrich（改 me() 方法体，不新建 controller/@GetMapping）：
//   public ApiResponse<java.util.Map<String, UserProfile>> me() {
//       var principal = SecurityContextHolder.getContext().getAuthentication().getName();
//       UserProfile profile = currentUserService.loadUserProfile(principal);   // 查账号→联角色→权限→区域
//       return ApiResponse.success(java.util.Map.of("user", profile));          // code=200, data={user}（全量 RBAC）
//   }
```

> `CurrentUserService.loadUserProfile` 按 `principal`（登录标识值）查账号行，再联角色/`RolePermission`/`Region` 组装 `UserProfile`；权限码集合来自 `RolePermission` 表的权限列。组装所需查询复用阶段三已生成的各实体 `<Entity>Repository`，不新建跨实体 Repository。具体列名/表名取自 `entity-*.md` DDL，不写死。

### 前端两步登录（阶段二前端登录页必照抄）

```ts
// 登录页：POST /api/auth/login（withCredentials）得 ApiResponse{code:200} + 浏览器自动存 HttpOnly Cookie；
//   GET /api/auth/me（浏览器自动带 Cookie，不拼 Authorization）得 user → 存 store。
//   user 必含 id/username（认证身份，阶段一即提供）；RBAC 字段 role/level/permissions/regionId/isSuperAdmin 可选
//   （阶段四-五权限门控才用，阶段二-三缺失不 block）。前端读 user 须防御性（RBAC 字段有则用）。
//   成功判定走 apiClient 返回的 ApiResponse 信封 + successCodes（含 200/201），禁硬判 res.code==='0'（spec 成功码=200）。
//   登录响应正文不含原始凭证（HttpOnly Cookie 是唯一载体），user 画像走 /me 单独取，禁臆造 inline {token,user} 单端点契约。
//   禁 localStorage/sessionStorage/IndexedDB 存凭证、禁拼 Authorization——浏览器按 Cookie 规则自动携带会话。
const res = await apiClient.post('/auth/login', { username, password }, { withCredentials: true });
// apiClient 已按 successCodes 判过业务码（含 200/201）；凭证在 HttpOnly Cookie，前端 JS 不可读、不存。
if (res.code !== 200) { setError(res?.message || '登录失败'); return; }   // 走信封 code，不硬判 code==='0'
const me = await apiClient.get<{ user: UserInfo }>('/auth/me', { withCredentials: true });  // 浏览器自动带 Cookie，不拼 Authorization
if (!me.data?.user?.id || !me.data?.user?.username) { setError(me?.message || '获取用户信息失败'); return; }  // 认证身份缺失=未完成登录；RBAC 字段缺失不 block
loginUser(me.data.user);                                                 // 存 user（id/username 必有，RBAC 字段可选），不存凭证
```

### admin 种子 DML（BCrypt 哈希定值 + 幂等）

**钉死的 BCrypt 哈希**（`Admin123456` 的 BCrypt 哈希，10 轮，由 Spring `BCryptPasswordEncoder` 算法生成，可被 `passwordEncoder.matches("Admin123456", hash)` 验证）：

```
$2a$10$Juq3tMIOZ7PEY86TwymQbeDaSSuTXcwyJnXxxNy3DzVMzvmk75zkK
```

阶段一登录任务通过 `sql-exec` CLI 灌 admin 账号行（**只 seed 账号行，够登录即可；不 seed 角色行**）。**INSERT 的表名与列名按所选账号实体 `entity-*.md` 的真实 DDL**——下表是模板，`<...>` 占位由实际 DDL 替换：

```bash
node .specify/scripts/javascript/sql-exec.mjs --type dml --init-data --module-id <账号表所属模块> --sql "$(cat <<'SQL'
INSERT INTO <账号表名> (<登录标识列>, <密码列>, <其它NOT NULL必填列>...)
VALUES ('admin', '$2a$10$Juq3tMIOZ7PEY86TwymQbeDaSSuTXcwyJnXxxNy3DzVMzvmk75zkK', <其它列值>...)
ON DUPLICATE KEY UPDATE <密码列> = '$2a$10$Juq3tMIOZ7PEY86TwymQbeDaSSuTXcwyJnXxxNy3DzVMzvmk75zkK';
SQL
)"
```

- `--init-data` 使 CLI 落盘文件名带 `-init` 后缀（时间戳-表名-init.sql）并水印标 `init-data`，便于回放溯源。
- 归档归属：调用须带 `--module-id <该表/DDL 所属模块>`（多模块工程必传；归档根规则见 `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md`，此处不重述路径）。
- 数据源选择同建表：一律显式传 `--data-source-name <绑定/契约条目名>`（取值见 `backend/_meta/datasource-binding.json`），不回退默认条目。
- `ON DUPLICATE KEY UPDATE` 幂等：重复灌不报错、把密码列重置为定值哈希（哈希值不变，`matches` 仍 true）。
- **禁止运行时算哈希**：必须用上面钉死的定值，不能用 `BCryptPasswordEncoder().encode(...)` 在灌库脚本里现算（每次盐不同导致哈希串漂移，虽不影响 `matches` 但破坏可追溯性）。
- **禁止 seed 角色行**：role/permission 实体不在登录最小集（留阶段三建），admin 的角色归属等阶段三 role 表建好后、阶段四灌库。`admin-account.json`里的 `超级管理员` 是信息性 label，不等于阶段一 DB 角色行。

## SSO 单点登录变体（台账 `login-scheme=SSO` 时适用；账密专属段不适用）

本变体只叠加在「权威结论」通用铁律之上——**HttpOnly Cookie 会话（承载会话标识）+ 服务端会话登记表 + 统一信封 + `/api` 前缀 + 未认证 401 + 登出失效 + CSRF double-submit/login 豁免 + SameSite 运行时动态推导 + `/me` 分层 owns 全部逐字适用**；差异仅在「凭证如何换来」：认证源从本地账号+密码换成外部 IdP。

- **协议与流程按技术设计**：设计指定 CAS / OIDC / SAML / OAuth2 授权码之一；`README` §6.1 未指定时在澄清台账/设计里必须能找到对接描述，找不到 → 按 needsHumanReview 上报，**禁臆造 IdP 端点**。授权回调端点（如 `GET /api/auth/callback/<provider>`）同属阶段一登录任务 owns，`/api` 前缀铁律不变。
- **会话建立（与账密变体的唯一分叉点）**：IdP 回调校验（CAS ticket 校验 / OIDC code 换 token 并验签 id_token / SAML 断言验证）通过后 → **本地账号行映射**（按设计的外部标识列查/建本地账号行，无则按设计的自动注册策略处理）→ 走与账密登录**相同**的会话签发路径：签带 `jti` 的 JWT + 登记会话表 active + `Set-Cookie` HttpOnly + 统一信封成功方法（无凭证正文）+ 重定向到前端入口。会话登记表/多登策略/登出/失效语义与账密变体完全一致。
- **无本地密码列时的账号行种子策略**：设计含本地账号实体但不存密码列（或密码列可空）→ admin 行仍按 `entity-*.md` DDL 灌（外部标识列填设计值、密码列跳过或空），**禁臆造本地密码**；设计连账号实体都没有（纯外部身份）→ 不建账号表、账号映射落在会话/映射 infra 表（登录 infra，非业务实体，同会话登记表口径）。
- **SecurityConfig**：permitAll 名单改为登录入口+回调端点；`JwtAuthenticationFilter` 从 Cookie 建立身份上下文的语义不变（回调成功后签发的仍是本地会话 Cookie，**前端只见过本地会话，不接触 IdP token**）；IdP access/id_token **禁落浏览器可读存储**。
- **admin 凭据与 admin-account.json**：SSO 变体**不适用**——无本地密码凭据可记录，`initializeAdminAccountJson` 按台账 scheme 机械跳过；部署对照验证按「方案非账密」跳过并记录。
- **沙箱验收口径（可执行）**：对接真实外部 IdP 不在沙箱能力内——用**本地测试 IdP**（内存 IdP 或 mock IdP stub，按栈知识文档提供的最小实现）走完整授权码/ticket 流程：未登录访问受保护接口 401 → 引导到 IdP → mock 认证 → 回调建本地会话（断言信封 200 + HttpOnly Cookie + 正文无凭证）→ `/me` 认证层 200 → 登出后会话失效（旧 Cookie 重放 401）→ CSRF 反例被拒。断言口径与账密变体验收一致，仅"凭据提交"一步换成 mock IdP 交互。

## 邮箱/手机号验证码登录变体（台账 `login-scheme=邮箱/手机号验证码` 时适用；账密专属段不适用）

本变体同样只叠加在通用铁律之上——会话建立后（会话登记表/多登/登出/401/CSRF/信封//me）与账密变体完全一致；差异在「第一因子如何送达与校验」。

- **验证码发送抽象接口**：`<modulePackage>` 下定义发送接口（如 `VerificationCodeSender`，落 service 同层，§9.3 无子包）+ 可插拔实现；**沙箱内置 mock 通道兜底**（mock 实现把验证码写入应用日志/内存，供测试断言取回），真实短信/邮件通道由设计指定、依赖注入切换，沙箱不接外部运营商。发送接口与实现落登录 infra 语境（同登录任务 owns），不进业务 `entity-*.md`。
- **验证码校验与限频**：验证码一次性（校验后即失效）、有明确有效期（设计未给则缺省 5 分钟）、**同标识限频**（发送间隔缺省 60s、有效期+频控配置键 `{appName}.login.otp.*`，yml 真实值+template 说明行）；存储用内存/登记表均可（登录 infra，非业务实体），**禁把验证码明文写日志正文以外的持久化业务表**。
- **登录端点**：设计指定端点路径（`/api` 前缀铁律不变；缺省 `POST /api/auth/login` 接收 `{ <登录标识>, <验证码> }`，发送端点缺省 `POST /api/auth/otp/send`）；两步（先发送后提交）或一步（验证码即密码）按设计。校验通过 → 与账密变体**相同**的会话签发路径（JWT jti + 会话登记表 + HttpOnly Cookie + 信封无凭证正文）。
- **账号行**：验证码登录的账号实体若设计无密码列 → 同 SSO 变体口径（密码列跳过/可空，禁臆造本地密码）；admin 行按设计处理。
- **admin 凭据与 admin-account.json**：**不适用**（无固定密码凭据），`initializeAdminAccountJson` 按台账 scheme 机械跳过；部署对照验证按「方案非账密」跳过并记录。
- **沙箱验收口径（可执行）**：走 mock 通道全链——发送验证码（断言限频：60s 内第二次发送被拒）→ 从 mock 通道取码 → 提交登录（断言信封 200 + HttpOnly Cookie + 正文无凭证）→ 错误码/过期码登录被拒（401）→ `/me` 200 → 登出失效重放 401 → CSRF 反例被拒。

## 跨阶段共用（本阶段也读，在 shared/）

- `[实现知识库目录对应路径]/shared/java-spring-bean.md` —— `@Service`/`@Mapper` 注解、`@MapperScan` 指定 annotationClass（防双 bean）、零跨实体铁律等。
- `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md` —— 运行时禁建表/禁启动迁移器灌种子。
- `[实现知识库目录对应路径]/base-architecture/pom-dependencies.md` —— 依赖清单（security + jjwt）。
- `[实现知识库目录对应路径]/base-architecture/datasource-yml.md` —— yml 真实值写法（jwt.secret 同口径写真实值）。
