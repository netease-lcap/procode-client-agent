# 校验与返回风格常识

本篇覆盖字段校验与响应信封返回风格的常见错误。实体只要有校验就必读。

**类名不在此写死**：本文示例中的 `ApiResponse`/`ErrorCode`/`BusinessException` 是 ruoyi 栈 illustrative 名。信封类/错误码类/异常类的**真名+FQN** 与工厂方法签名一律取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `responseEnvelope` / `errorCode` / `failureStyle`（设计阶段读骨架按角色判据发现的真实在用值）；失败处理方式（`return 信封.fail` vs `throw 异常`）以 `failureStyle` 真值为准。换栈照 skeleton-conventions 真名替换示例中的类名，机械规则（判空/查重维度/blank 语义）通用保留。

## 规则 2.1：必填校验必须覆盖 null 和空串

- **何时触发**：NOT NULL 字段的 create/update 校验
- **错误现象**：空串/空白串绕过校验落库，或 test 用 @NullAndEmptySource 断言失败
- **根因**：只判 null 没判空串，或只判空串没判 null
- **正确写法**：
  ```java
  if (name == null || name.isBlank()) {
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "名称不能为空");
  }
  ```
- **反例**：
  ```java
  if (name == null) { ... } // 空串绕过
  if (name.isEmpty()) { ... } // null 时 NPE
  ```
- **test 配合**：反向用例用 @ParameterizedTest + @NullAndEmptySource 覆盖 String 参数。**但 Long/Integer/数值类型参数只能用 @NullSource，不能用 @EmptySource**（@EmptySource 只对 String/Collection 有意义，传给 Long/Integer 会报 ParameterResolutionException: No ArgumentFactory）。String 参数才用 @NullAndEmptySource

## 规则 2.2：唯一校验（查重）维度必须以 DDL UNIQUE 约束为准

- **何时触发**：UNIQUE 字段或联合唯一约束的查重
- **错误现象**：test 期望 (project, name) 联合唯一，但 impl 只查 name 单字段，导致不同 project 下同名被误拒
- **根因**：查重维度与 DDL 的 UNIQUE 约束不符，impl 凭猜测定维度
- **正确写法**：按 DDL 的唯一约束维度查重。若 DDL 是 UNIQUE(project_id, name)，查重就按这两个字段组合查
  ```java
  Entity exist = mapper.selectByProjectIdAndName(dto.getProjectId(), dto.getName());
  if (exist != null) {
      return ApiResponse.fail(ErrorCode.CONFLICT, "名称已存在");
  }
  ```
- **反例**：只查 name 单字段，忽略 project_id 维度
- **注**：去重维度详见 `[实现知识库目录对应路径]/backend-build/java-query-dedup.md` 规则 5.2

## 规则 2.3：范围/枚举校验值必须与 DDL 一致

- **何时触发**：数值范围字段、枚举字段
- **错误现象**：枚举取值与 DDL 的取值范围不符，或范围边界校验错
- **根因**：枚举集合写死时和 DDL 不一致，或范围校验用错边界
- **正确写法**：枚举取值从 entity-*.md 字段表的"取值范围"列识别，逐项核对；范围用 min-1/max+1 测边界
- **反例**：impl 枚举只写了 3 个值，DDL 实际有 5 个，test 传第 4 个值时 impl 拒绝

## 规则 2.4：create 返回创建成功工厂方法(201)，其余返回成功工厂方法(200)

- **何时触发**：所有 CRUD 方法的返回
- **错误现象**：create 返回 200 而非 201，test 断言状态码失败
- **根因**：返回风格不统一
- **正确写法**：create 用信封的创建成功工厂方法（201）；list/getById/update/delete 用信封的成功工厂方法（200）。信封类真名+FQN 与工厂方法名取 `skeleton-conventions.json` `responseEnvelope`（如 ruoyi 栈为 `ApiResponse.created`/`ApiResponse.success`），详见 backend/README.md §9.4
- **反例**：create 用 success（200）

## 规则 2.5：失败处理照 failureStyle 真值，禁与骨架不一致

- **何时触发**：所有校验失败/业务失败的场景
- **错误现象**：test 断言信封.fail 但 impl throw 了异常，断言失败；或 throw 变成 Spring 全局异常处理器的 500
- **根因**：失败处理方式与骨架 `failureStyle` 不一致——骨架 `return 信封.fail(...)` 却 `throw`，throw 的异常不走信封统一响应结构，test 断言 fail 抓不到
- **正确写法**：照 `skeleton-conventions.json` `failureStyle` 真实在用方式——骨架 `return 信封.fail` 则 `return <信封真名>.fail(<错误码真名>.X, msg)`、禁 `throw`；骨架 `throw 异常` 则照 `throw`。信封/错误码真名见 `responseEnvelope`/`errorCode`（ruoyi 栈 failureStyle=`return fail`，示例 `return ApiResponse.fail(ErrorCode.BAD_REQUEST, "名称不能为空")`）
  ```java
  if (name == null || name.isBlank()) {
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "名称不能为空"); // 类名取 skeleton-conventions 真值
  }
  ```
- **反例**（ruoyi 栈 failureStyle=`return fail` 时）：
  ```java
  if (name == null) {
      throw new BusinessException("名称不能为空"); // 与骨架 failureStyle 不一致，test 断言 fail 抓不到
  }
  ```
- **注**：本规则为 Java 实现常识，原设计文档 §9.5 已移入本篇（失败处理不再载于 backend/README.md）

## 规则 2.6：create 与 update partial 的 blank 校验语义不同

- **何时触发**：NOT NULL 字段的校验，且 update 支持 partial update（DTO 字段 null 表示"不改"）
- **错误现象**：create 场景 test 传 null 或空串都期望 400，impl 放行了空串（`expected: <400> but was: <200>`）；或 update partial 场景 test 传 null（表示不改）期望 200，impl 误判为空拒绝返回 400（`expected: <200> but was: <400>`）。两类错误在单测修复阶段反复出现、耗时最长
- **根因**：impl 没区分 create（null+空串都拒）与 update partial（null 合法、只拒空串）的语义差异，对 update 也照 create 的"null 和空串都拒"处理
- **正确写法**：
  - **create**：NOT NULL 字段 null 和空串都拒
    ```java
    if (dto.getName() == null || dto.getName().isBlank()) {
        return ApiResponse.fail(ErrorCode.BAD_REQUEST, "名称不能为空");
    }
    ```
  - **update partial**：null 字段跳过校验（表示不改），只有传了空串才拒
    ```java
    if (dto.getName() != null && dto.getName().isBlank()) {
        return ApiResponse.fail(ErrorCode.BAD_REQUEST, "名称不能为空串");
    }
    // name==null 时不校验，放行（partial update 语义）
    ```
- **test 配合**：create 的反向用例用 @NullAndEmptySource（null+空串都测，String 参数）；update partial 的反向用例用 @EmptySource（只测空串，null 是合法 partial update 不测）
- **反例**：update partial 照 create 写 `if (name == null || name.isBlank())` → partial update 传 null 被误拒
- **注**：全量 update（所有字段都必传，无 partial 语义）不适用本规则，照 create 语义处理
