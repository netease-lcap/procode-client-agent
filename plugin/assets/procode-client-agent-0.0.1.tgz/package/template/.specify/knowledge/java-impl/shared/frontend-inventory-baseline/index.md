# 前端存量事实基线扫描规程（1-1.1 入口阶段 · frontend/_meta/inventory-baseline.json）

本规程供 **plans 入口阶段（inventory-baseline）** 的前端扫描任务使用：1-1.1 增量轮在项目最开头，由一个专职任务读本规程、扫描存量**前端**代码，产出唯一的「前端存量事实基线」`[大纲目录对应路径]/frontend/_meta/inventory-baseline.json`。它是后续阶段的**事实地板**：阶段一 tech-stack 的前端五维（runtime/buildTool/language/framework/componentLibrary）从这里抄写（偏离须留痕）、阶段二前端设计据 entrypoints/structure 写「挂靠策略」、build 前端基础架构任务据 entrypoints 做存量底座「先校验再复用」。

**与其他文档的关系**：本文档决定**每个键/条目怎么取值、怎么判定**；产物的信封形状（必填键、枚举、evidence 锚点、凭据红线、entrypoint 存在性）由零栈知识校验器 `[脚本代码目录对应路径]/javascript/verify-frontend-inventory-baseline.mjs` 机械把关并回灌错误——**本文档不得改动信封约束**，两边不一致时以校验器为真、回来改本文档的示例。

**多栈约定**：本规程是前端多栈通用版（vue/react × vite/webpack × javascript/typescript 等）。前端目录缺失、非 package.json 工程（纯静态 HTML/模板）时**不报错**——按 §7 走 `degraded` 规程，这是已定义态。

---

## §0 任务边界（先读，红线）

- **只写这一个产物文件**（`[大纲目录对应路径]/frontend/_meta/inventory-baseline.json`，目录不存在则创建），**不改任何其他文件**、不写台账、不动 README、不动存量源码。
- **每条断言必须可锚定**：stack 五维、每个 entrypoint、每个结构条目都带 `evidence:[{file, quote}]`；quote 是文件内**逐字连续原文**（见 §5），假锚点会被校验器逐条 grep 拦截。
- **不臆造、不推测**：只写你在清单/配置/源码里真实见到的东西；拿不准的宁可不写，在 summary/notes 说明。
- **凭据不落盘**（校验器红线机械执行）：password/token/secret 等明文值任何形式都不进文件；占位写法（`${ENV}`、`<your-password>`）放行。

---

## §1 第一步-定位前端根

- 存量前端工程根 = `[前端产物目录对应路径]`；若该路径下无 `package.json`，在 `[项目产物目录对应路径]` 下找 `<appName>-frontend` 或 `*-frontend` 目录（取含 `package.json` 的第一个）。
- 两者都找不到，或根下无 `package.json`（纯静态 HTML/单文件页）→ 按 §7 degraded 规程产出，**禁止凭空产基线**。
- `appRoot` 写前端根相对 `[项目产物目录对应路径]` 的目录名（如 `myapp-frontend`）。
- 多个独立前端应用并存时：取与后端 API 消费关系最直接的主应用（入口 HTML + 路由齐全者），在 `notes` 写明其余应用与取舍原因；不强行归并。

## §2 第二步-栈检测（看前端根下有什么清单文件）

- `package.json` 存在 → 进入逐键取值（§3）；
- `package-lock.json` / `yarn.lock` / `pnpm-lock.yaml` → 包管理器 npm/yarn/pnpm，记入 evidence；
- `vite.config.*` / `webpack.config.*` / `vue.config.*` / `next.config.*` / `angular.json` → 构建工具证据；
- `tsconfig.json` / `*.ts` 入口 → language 候选 typescript；仅 `.js`/`.mjs` 入口且 devDeps 无 typescript/vue-tsc/ts-loader → language 候选 javascript。

## §3 stack 节取值规程（键名固定，不得增删键）

`stack` 只允许键：`runtime / buildTool / language / framework / componentLibrary / chainSupported / evidence`。逐键规程：

| 键 | 取值规程 | 锚点来源 |
|---|---|---|
| `runtime` | `{name, version}`。name 固定人类写法 `Node.js`（package.json + 任一 lockfile 存在即成立）；version 从 `.nvmrc`/`engines.node`/CI 配置取，找不到写 `null`。 | package.json engines 行或 .nvmrc |
| `buildTool` | `{name, version}`。name 按 vite/webpack/vue-cli/next/cra 等构建器依赖名小写（`vite`、`webpack`、`@angular/cli`→`angular-cli`）；version 取 devDeps 中该依赖的版本串（去 `^`/`~` 前缀原样保留主版本串如 `5.3.4`）。找不到构建器 → `{name:"none", version:null}`。 | package.json devDependencies 行 / 构建配置文件首部 |
| `language` | 只允许 `"javascript"` 或 `"typescript"`：tsconfig.json 存在，或入口/main 脚本为 `.ts`/`.tsx`，或 devDeps 含 typescript/vue-tsc/ts-loader → `"typescript"`；否则 `"javascript"`。**判定锚点必须真实**，不许凭 README 口径。 | tsconfig.json 首行 / package.json devDeps typescript 行 / 入口文件名 |
| `framework` | `{name, version}`。name 按 dependencies 中框架包小写去 scope：`vue`→`"vue"`、`react`→`"react"`、`next`→`"next"`、`nuxt`→`"nuxt"`；version 取该依赖版本串（去 `^`/`~`）。 | package.json dependencies 行 |
| `componentLibrary` | `{name, version}`。按 dependencies 中 UI 组件库包小写：`element-plus`、`ant-design-vue`→`"ant-design-vue"`、`antd`、`@mui/material`→`"mui"`、`vuetify` 等；version 同上取法。**确无组件库** → `{name:"none", version:null}`。同名职责竞争（两个 UI 库都在 dependencies 且源码真实 import）→ 取源码 import 更多的那个，另一个记入 notes 并在判据（阶段二）弹题。 | package.json dependencies 行 + 源码 import 行 |
| `chainSupported` | `language`/`framework`/`buildTool` 均判定成功且非 `none` → `true`；任一 `none`/失败 → `false`（下游强制人裁决——如实写，不为"能跑"谎报）。 | 由各键派生 |
| `evidence` | ≥1 条，建议 3-5 条：framework/buildTool/language/componentLibrary 各锚一条。 | §2 各判据行 |

**版本串写法**：一律写 package.json 中去掉 `^`/`~` 后的原样串（`3.4.31`、`2.7.5`）；区间/占位（`*`、`workspace:*`）写 `null` 并 notes 说明。

## §4 entrypoints 与 structure 取值规程

### `entrypoints`（数组；build 前端底座「先校验再复用」红线的数据源——此处列出的文件=禁止挪动/删除/改名的存量底座）

每条 `{ "path", "kind", "references", "evidence" }`，`kind` 只允许枚举：`package-manifest | entry-html | entry-script | build-config | router | state | api-client | app-root`。

| kind | 必列性 | path 取值 | references 取值 |
|---|---|---|---|
| `package-manifest` | **必列 ≥1** | `package.json`（相对前端根） | `null` |
| `entry-html` | **必列 ≥1** | 入口 HTML（如 `index.html`） | 该 HTML 引用的 entry script 的 src 属性**逐字值**（如 `/src/main.js`；无模块入口的纯静态页应走 §7 degraded，不落非 degraded 基线） |
| `entry-script` | **必列 ≥1** | entry-html references 指向的源文件相对路径（去开头 `/`，如 `src/main.js`） | `null` |
| `build-config` | 有则列 | `vite.config.js` 等 | `null` |
| `router` / `state` / `api-client` / `app-root` | 有则列（`app-root`=根组件/App 文件） | 对应源文件相对路径 | `null` |

- `entry-script` 必须与某条 `entry-html` 的 `references` 互证（HTML 引什么就列什么，禁止按惯例猜 `src/main.js`）。
- **只列底座文件**（入口/构建/路由/状态/请求/根组件），页面与业务组件进 `structure`，不进 entrypoints。

### `structure`（对象；阶段二前端设计「挂靠策略」的输入）

| 键 | 取值 |
|---|---|
| `pages` | 数组，每条 `{ "path", "name", "status", "evidence" }`：存量页面/视图文件清单（status 固定 `"used"`），name 写路由语义名（从路由配置读，无则文件名）。 |
| `components` | 同上，公共/业务组件清单（可截断至 30 条，notes 说明截断）。 |
| `router` | `{ "mode": "hash|history|none", "paths": [路由记录 path 串…≤30 条], "evidence" }`——从路由配置逐条读，禁止臆造。 |
| `state` | `{ "approach": "pinia|vuex|reactive|redux|none", "evidence" }`。 |
| `api` | `{ "approach": "fetch|axios|其他包名", "baseUrls": [...], "evidence" }`。 |
| `styles` | `{ "approach": "scss|less|css|tailwind|其他", "entry": 全局样式入口相对路径或 null, "evidence" }`。 |
| `notes` | 字符串数组：多应用取舍、截断说明、其他需要下游知道的事实。 |

`structure` 各键判定不出时写 `{ "approach": "none", "evidence": [] }` 或空数组，**禁止省键**。

## §5 evidence 规程（校验器逐条机械验）

- 每条 `{ "file", "quote" }`；`file` 相对**前端根**（如 `src/main.js`），禁止绝对路径、禁止 `..`；
- `quote` 是该文件内**逐字连续原文** ≤200 字符；校验器按空白归一化后逐条 grep，不中即红；
- 禁止为过校验编造/改写 quote——grep 不中只会再红一轮；
- 凭据红线同后端规程：password/token/secret 等明文值不进任何字段（含 quote 原文——含明文密码的行换一行锚）。

## §6 输出 schema（围栏块 = 信封展开，与校验器钉死集一致，不得增删键）

```json
{
  "schemaVersion": 1,
  "generatedBy": "plans/inventory-baseline (LLM, doc-guided)",
  "generatedAt": "<ISO8601>",
  "degraded": false,
  "appRoot": "<appName>-frontend",
  "dependencies": {
    "dependencies": { "vue": "^3.4.31", "element-plus": "^2.7.5" },
    "devDependencies": { "vite": "^5.3.4" }
  },
  "stack": {
    "runtime": { "name": "Node.js", "version": "20", "evidence": [{ "file": "package.json", "quote": "\"engines\": { \"node\": \">=20\"" } }] },
    "buildTool": { "name": "vite", "version": "5.3.4", "evidence": [{ "file": "package.json", "quote": "\"vite\": \"^5.3.4\"" }] },
    "language": "javascript",
    "framework": { "name": "vue", "version": "3.4.31", "evidence": [{ "file": "package.json", "quote": "\"vue\": \"^3.4.31\"" }] },
    "componentLibrary": { "name": "element-plus", "version": "2.7.5", "evidence": [{ "file": "package.json", "quote": "\"element-plus\": \"^2.7.5\"" }] },
    "chainSupported": true,
    "evidence": [{ "file": "vite.config.js", "quote": "import vue from '@vitejs/plugin-vue'" }]
  },
  "entrypoints": [
    { "path": "package.json", "kind": "package-manifest", "references": null, "evidence": [{ "file": "package.json", "quote": "\"name\": \"myapp-frontend\"" }] },
    { "path": "index.html", "kind": "entry-html", "references": "/src/main.js", "evidence": [{ "file": "index.html", "quote": "<script type=\"module\" src=\"/src/main.js\">" }] },
    { "path": "src/main.js", "kind": "entry-script", "references": null, "evidence": [{ "file": "src/main.js", "quote": "createApp(App)" }] }
  ],
  "structure": {
    "pages": [{ "path": "src/views/Login.vue", "name": "登录", "status": "used", "evidence": [{ "file": "src/router.js", "quote": "component: Login" }] }],
    "components": [{ "path": "src/components/ChangePwdDialog.vue", "name": "改密弹窗", "status": "used", "evidence": [{ "file": "src/views/ChangePassword.vue", "quote": "ChangePwdDialog" }] }],
    "router": { "mode": "history", "paths": ["/login", "/main"], "evidence": [{ "file": "src/router.js", "quote": "createWebHistory()" }] },
    "state": { "approach": "reactive", "evidence": [{ "file": "src/store.js", "quote": "reactive(" }] },
    "api": { "approach": "fetch", "baseUrls": ["/api"], "evidence": [{ "file": "src/api.js", "quote": "fetch(" }] },
    "styles": { "approach": "css", "entry": null, "evidence": [] },
    "notes": []
  }
}
```

键约束（校验器钉死）：顶层只允许 `schemaVersion/generatedBy/generatedAt/degraded/appRoot/dependencies/stack/entrypoints/structure`；`stack` 只允许 `runtime/buildTool/language/framework/componentLibrary/chainSupported/evidence`；`language`/`chainSupported` 为枚举；`entrypoints[].kind` 为枚举；evidence 只允许 `{file, quote}`。

**`dependencies` 依赖快照规程**：`{ "dependencies": {...}, "devDependencies": {...} }`，两键至少其一非空——从存量 `package.json` **逐包名逐版本串原样抄写**（键=包名、值=版本区间原文如 `"^3.4.31"`，禁止去 `^`/`~`、禁止改写）。它是 build 前端底座「只增不删」机械判定的快照地板：增量轮 build 结束时，快照中每个包名必须仍在 package.json 中（版本可变），静默删除即红。degraded 时写 `{ "dependencies": {}, "devDependencies": {} }`。

## §7 degraded 规程（前端目录缺失 / 非 package.json 工程 / 规程读不到时）

- `degraded: true`，`appRoot` 写实际探得的目录名或 `null`；`stack` 只填 `language: "none"` 与 `chainSupported: false`（校验器允许 degraded 最小集）；`entrypoints: []`；`structure` 各键写空值形态；`notes` 写明原因（如"前端产物目录下无 package.json，判定为纯静态交付外壳"）。
- degraded 是**已定义态不是错误**：阶段二 tech-stack 前端五维退回 fresh 证据优先级、build 前端底座保真门自动跳过。禁止硬套 §3 键值。

## §8 写盘前自检（全过才准结束）

- [ ] 只写了一个文件：`[大纲目录对应路径]/frontend/_meta/inventory-baseline.json`；
- [ ] 信封与 §6 围栏一致，无增删键；`language` ∈ javascript/typescript/none（degraded）；`entrypoints[].kind` 全在枚举内；
- [ ] `dependencies` 快照与 package.json 逐包名逐版本串一致（原样含 `^`/`~`，未去前缀未改写）；
- [ ] `entrypoints` 含 ≥1 条 package-manifest、≥1 条 entry-html、≥1 条 entry-script，且 entry-script 与 entry-html.references 互证；
- [ ] 每条 evidence 的 file 相对前端根、quote ≤200 字符且能在文件中逐字找到（含缩进/换行以实际文件为准，空白归一化后匹配）；
- [ ] 全文无明文凭据；无绝对路径、无 `..` 路径；
- [ ] `chainSupported` 与各键派生关系一致；degraded 时最小集形态正确。
