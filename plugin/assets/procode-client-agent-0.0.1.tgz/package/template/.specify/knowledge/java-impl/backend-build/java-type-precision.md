# 类型与精度常识

本篇覆盖 BigDecimal、时间、正则的类型精度错误。实体 DDL 有 DECIMAL/NUMERIC/DATETIME/TIMESTAMP 或校验含 regex 才读。

**类名不在此写死**：本文示例中的 `ApiResponse`/`ErrorCode` 是 ruoyi 栈 illustrative 名。信封类/错误码类的**真名+FQN** 取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `responseEnvelope` / `errorCode`，失败处理方式以 `failureStyle` 真值为准。换栈照真名替换示例中的类名；机械规则（BigDecimal compareTo、时间 nano 截断、金额精度范围校验）通用保留。

## 规则 3.1：BigDecimal 用 compareTo 比较，禁止用 equals 或 !=

- **何时触发**：实体有 BigDecimal/金额字段，toVO 或校验里需要比较 BigDecimal
- **错误现象**：BigDecimal 比较 == 或 equals 判错（1.0 和 1.00 判不等），test 断言金额为 0 或相等时失败
- **根因**：BigDecimal 的 equals 比 scale（精度），1.0 和 1.00 scale 不同判不等；!= 比较的是对象引用不是值
- **正确写法**：
  ```java
  // 判断是否为零
  if (amount.compareTo(BigDecimal.ZERO) == 0) { ... }
  // 判断相等
  if (a.compareTo(b) == 0) { ... }
  // 判断大小
  if (amount.compareTo(BigDecimal.ZERO) > 0) { ... }
  ```
- **反例**：
  ```java
  if (amount == BigDecimal.ZERO) { ... }   // 引用比较，永远 false
  if (amount.equals(BigDecimal.ZERO)) { ... } // scale 不同判不等
  if (amount != BigDecimal.ZERO) { ... }    // 引用比较
  ```

## 规则 3.2：LocalDateTime 的 nano 必须截断到秒

- **何时触发**：实体有 LocalDateTime/DATETIME/TIMESTAMP 字段，insert 后回读或在 toVO 里处理时间
- **错误现象**：test 断言时间值失败——Java LocalDateTime 有 nano（纳秒），DB 时间精度通常到秒，insert 后回读的时间 nano=0 但内存对象 nano 非 0，断言不等
- **根因**：Java LocalDateTime 精度到 nano，DB 时间精度到秒（或毫秒），两边精度不一致
- **正确写法**：
  ```java
  // insert 前或 toVO 时截断 nano
  LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS);
  // 或
  entity.setCreateTime(LocalDateTime.now().withNano(0));
  ```
- **反例**：
  ```java
  entity.setCreateTime(LocalDateTime.now()); // 含 nano，回读后 nano=0，断言不等
  ```

## 规则 3.3：正则量词用 + 不用 *，确保非空

- **何时触发**：字段有格式校验用正则 pattern
- **错误现象**：空串绕过正则校验落库，test 传空串时 impl 没拒绝
- **根因**：正则用 *（0 次或多次）允许空串，空串绕过了"必填"校验
- **正确写法**：
  ```java
  // 用 + 确保至少 1 个字符
  if (!code.matches("[a-zA-Z0-9_]+")) {
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "编码格式错误");
  }
  ```
- **反例**：
  ```java
  // 用 * 允许空串，空串绕过校验
  if (!code.matches("[a-zA-Z0-9_]*")) { ... }
  ```

## 规则 3.4：金额字段必须做 DDL 精度范围校验，toVO 的 BigDecimal 比较统一 compareTo

- **何时触发**：实体有 DECIMAL/NUMERIC 金额字段（如 `DECIMAL(15,2)`），且 create/update 接收金额入参
- **错误现象**：test 传极大值（如 `999999999999999.99`，16 位整数）超出 `DECIMAL(15,2)` 范围，impl 未做范围校验直接落库，被 DB 截断或报错；或 toVO 里 `BigDecimal.ZERO != new BigDecimal("0.00")` 断言失败（scale 不同判不等）
- **根因**：impl 没按 DDL 精度做范围校验，超限值漏到 DB 层；或 toVO 用 `==`/`equals` 比较 BigDecimal，scale 不同判错
- **正确写法**：
  ```java
  // 1. 按 DDL DECIMAL(p,s) 算范围上限：值 < 10^(p-s)
  // DECIMAL(15,2) → 整数位 13，上限 9999999999999.99
  BigDecimal MAX = new BigDecimal("9999999999999.99");
  if (amount != null && amount.compareTo(MAX) > 0) {
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "金额超出范围");
  }
  // 2. toVO 比较 BigDecimal 一律 compareTo，禁 == / equals
  if (amount.compareTo(BigDecimal.ZERO) == 0) { ... }
  ```
- **反例**：
  ```java
  // 不校验范围，超限值落库
  entity.setAmount(dto.getAmount());
  // toVO 用 equals，ZERO 和 "0.00" scale 不同判不等
  if (amount.equals(BigDecimal.ZERO)) { ... }
  ```
- **注**：DDL 精度从 entity-*.md 字段表的"类型"列识别（如 `DECIMAL(15,2)` → p=15, s=2）；BigDecimal 比较详见规则 3.1
