# Java 后端实现常识知识库（按阶段细分）

本知识库承载 Java 后端各阶段的实现约定（设计契约仍在 `backend/README.md` §9，不在本目录）。

**路径前缀**：本目录 = `[实现知识库目录对应路径]`（占位符会被框架替换为绝对路径 `<knowledgeDir>/java-impl`）。换技术栈时此目录名变为 `<stack>-impl`，阶段子目录结构各栈一致。

## 按阶段导航（每阶段只读自己子目录的 index）

| 消费阶段 | 子目录 | 该阶段读 |
|---|---|---|
| plans/inventory-baseline（1-1.1 入口存量扫描） | `inventory-baseline/` | `inventory-baseline/index.md`（stack/dataSources/五域信号取值规程 + evidence 锚点规程；信封由 verify 脚本机械守） |
| plans/backend-design（后端技术设计 §1） | `shared/` | `shared/persistence-convention.md` + `shared/test-annotation.md`（§1 下沉后 design 无独有 Java 约定，全引 shared） |
| build/base-architecture（后端基础架构） | `base-architecture/` | `base-architecture/index.md`（pom-dependencies / datasource-yml / runtime-no-ddl）+ `shared/java-spring-bean.md`（@MapperScan/启动类） |
| build/backend 实体生成 + review + 修复 | `backend-build/` | `backend-build/index.md`（crud-write / validation-return / type-precision / query-dedup）+ `shared/java-spring-bean.md`（@Service/@Mapper/零跨实体铁律 4.9）+ `shared/persistence-convention.md` + `shared/test-annotation.md` |
| build/backend 协调者（编译/启动/单测三波） | `backend-build-runner/` | `backend-build-runner/index.md`（build-test-runner：mvnd/surefire/@MapperScan/contextLoad 运行时口径）+ `shared/java-spring-bean.md` |

## shared/（跨阶段共用）

≥2 阶段引用的 Java 约定放 `shared/`，避免重述：
- `shared/java-spring-bean.md` — @MapperScan/启动类（base-arch）+ @Service/@Mapper 生成（backend-build）+ 零跨实体铁律规则 4.9（generate/fix/coordinator 共用）
- `shared/persistence-convention.md` — 持久层风格/分页/实体形态照 skeleton-conventions mapperStyle/pageVo 真值（不 mandate 单一栈；design §1 + base-arch pom 共用，单一真理源）
- `shared/test-annotation.md` — 测试注解组合/数据源/失败断言照 skeleton-conventions testAnnotations/testDataSource/failureStyle 真值（不 mandate 单一组合；design §1 + build generate 共用，单一真理源）

## 阶段独有

- `inventory-baseline/` — 1-1.1 入口存量扫描规程（栈/数据源/五域信号 + 抗漏报 checklist + evidence 锚点规程）
- `base-architecture/` — pom 依赖清单、application.yml 数据源、运行时禁建表 + sql-exec 收口（多模块工程调用须带 `--module-id <该表/DDL 所属模块>`，归档根规则见 `base-architecture/runtime-no-ddl.md`）
- `backend-build/` — 写操作（insert/update/delete）、校验与返回、类型与精度、查询去重与 Stream
- `backend-build-runner/` — 协调者运行时口径（mvnd/surefire/contextLoad）

## 读取原则

- 分篇里的【正确写法】必须照抄，【反例】绝对禁止。
- 跨阶段共用规则读 `shared/`；本阶段独有读自己子目录；不跨界读非本阶段子目录。
