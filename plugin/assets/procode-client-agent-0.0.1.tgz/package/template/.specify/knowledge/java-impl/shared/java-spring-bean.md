# Spring Bean 与测试注解常识

本篇覆盖 Spring 注解与测试注解的常见错误。实体生成必读。

**类名/注解不在此写死**：本文示例中的 `@Mapper`/`@SpringBootTest`/`ApiResponse`/`PageVO`/`ErrorCode` 是 ruoyi 栈 illustrative 名。持久层注解/基类、测试注解组合、测试数据源、信封/分页/错误码类的**真名+FQN** 一律取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `mapperStyle` / `testAnnotations` / `testDataSource` / `responseEnvelope` / `pageVo` / `errorCode`（设计阶段读骨架按角色判据发现的真实在用值），禁臆测、禁造第二套。换栈照真名替换示例中的注解/类名；机械规则（一文件一类、import 自检、泛型不裸、零跨实体）通用保留。

## 规则 4.1：ServiceImpl 必须加 @Service，Repository 注解照 mapperStyle 真值

- **何时触发**：生成 ServiceImpl 类和 Repository 接口时
- **错误现象**：contextLoad 失败，报 No qualifying bean of type 'XxxService'；启动阶段反复修这个
- **根因**：impl 类没加 @Service 注解，Spring 容器没注册这个 bean，@Autowired 注入失败
- **正确写法**：ServiceImpl 加 `@Service`（通用 Spring）；Repository 的注解/基类照 `skeleton-conventions.json` `mapperStyle` 真实在用值（ruoyi 注解 SQL 栈为 `@Mapper`，JPA 栈为 `extends JpaRepository`，XML 栈照骨架）——逐字用其真实注解，不在本文 mandate 单一注解
  ```java
  @Service
  public class XxxServiceImpl implements XxxService { ... }

  @Mapper // 注解取 skeleton-conventions.mapperStyle 真值；JPA/XML 栈照换
  public interface XxxRepository { ... }
  ```
- **反例**：
  ```java
  public class XxxServiceImpl implements XxxService { ... } // 没 @Service → No qualifying bean
  ```

## 规则 4.2：测试注解照 testAnnotations 真值，禁与骨架不一致

- **何时触发**：生成 ServiceTest 类时
- **错误现象**：contextLoad 失败，测试注解组合与骨架不一致不注册所需 bean（如骨架用整体 `@SpringBootTest` 却写切片注解不注册 Service bean / SqlSessionFactory，或 `@DataJpaTest` 因跨域 `@MapperScan` 级联报错）
- **根因**：测试注解组合与骨架 `testAnnotations` 不一致（骨架整体 Spring 栈却用切片注解，或反之）——不在本文 mandate 单一注解组合
- **正确写法**：照 `skeleton-conventions.json` `testAnnotations` 真实在用组合（ruoyi 栈为 `@SpringBootTest`+`@Transactional`）逐字用，禁与骨架不一致
  ```java
  @SpringBootTest // 注解组合取 skeleton-conventions.testAnnotations 真值
  @Transactional
  class XxxServiceTest {
      @Autowired
      private XxxService service;
  }
  ```
- **反例**（当 `testAnnotations`=`@SpringBootTest` 时）：
  ```java
  @DataJpaTest // 与骨架 testAnnotations 不一致，不注册 Service bean
  class XxxServiceTest { ... }
  ```
- **注**：详见 backend/README.md 第 1 章「技术栈」测试约定 + skeleton-conventions.json

## 规则 4.3：测试数据源照 testDataSource 真值，禁与骨架不一致

- **何时触发**：生成 ServiceTest 类时
- **错误现象**：测试数据源与骨架不一致——SQL 方言不符报错；或 `@Sql` 建表与 sql_exec 建的表冲突
- **根因**：测试数据源与骨架 `testDataSource` 不一致（骨架直连真实库却用内存库等）——不在本文 mandate "直连 MySQL 弃 H2"（那是单栈假设）
- **正确写法**：照 `skeleton-conventions.json` `testDataSource` 真实在用数据源（ruoyi 栈为直连 application.yml 的 MySQL），用 `@Transactional` 回滚隔离测试数据，不与骨架数据源不一致
  ```java
  @SpringBootTest
  @Transactional // 回滚隔离，测试数据不落库
  class XxxServiceTest { ... }
  ```
- **反例**（当 `testDataSource`=直连真实库 时）：
  ```java
  @SpringBootTest
  @Sql("schema.sql") // 与骨架数据源不一致，表已由 sql_exec 建好
  class XxxServiceTest { ... }
  ```

## 规则 4.4：一个 .java 文件只声明一个与文件名同名的 public 类

- **何时触发**：生成 DTO/VO/Entity/ServiceImpl 等所有 .java 文件
- **错误现象**：`XxxCreateDTO.java` 文件里声明了 `XxxQueryDTO` 类，多个 DTO 文件内容交叉错乱；javac 报"找不到符号 类 XxxCreateDTO"，**级联整包编译失败**——一个文件类名错配导致 javac 停止处理该包，同包其它类的 getter/setter 引用全部报"找不到符号"，被误判为 Lombok 不生效
- **根因**：生成多个同类文件时内容串了，文件名与声明的 public 类名不匹配
- **正确写法**：`XxxCreateDTO.java` 里只声明 `public class XxxCreateDTO`，文件名与 public 类名严格一致；生成后自检"文件名 == public 类名"
- **反例**：`XxxCreateDTO.java` 里声明 `public class XxxQueryDTO`

## 规则 4.5：Service 接口/Impl 生成后自检 import，禁止裸用类名

- **何时触发**：生成 Service 接口和 ServiceImpl，引用 VO/DTO/Entity/ApiResponse/PageVO 等类时
- **错误现象**：`XxxService.java` 某行用了 `XxxVO` 但没 import，报"找不到符号 类 XxxVO"；该文件编译失败级联到 Impl，Impl 里 `entity.getXxx()` 也报"找不到符号 方法"（被误判为 Lombok 没生成 getter，实为上游编译失败级联）
- **根因**：生成 Service 接口时漏写 import，只写了类名没补 import 语句
- **正确写法**：生成 Service 接口/Impl 后，自检 import 列表——凡类名引用（VO/DTO/Entity/ApiResponse/PageVO/List/Map）必须有对应 import，缺则补
  ```java
  import com.company.project.<domain>.vo.XxxVO;
  import <responseEnvelope.fqn>;  // 信封类 import 路径取 skeleton-conventions responseEnvelope.fqn，不硬编码 common（不同骨架可能放 common/result/shared 等）

  public interface XxxService {
      <EnvelopeCls><XxxVO> getById(Long id); // 用到的类都有 import；<EnvelopeCls> = responseEnvelope 真名（如 ruoyi ApiResponse）
  }
  ```
- **反例**：用了 `XxxVO` 但 import 列表里没有，靠"同包"侥幸——Service 在 service 子包、VO 在 vo 子包，不同包必须显式 import

## 规则 4.6：Test 文件的 import 必须与 Service 接口实际包路径一致

- **何时触发**：生成 Test 文件，import Service 接口时
- **错误现象**：Service 接口在 `com.company.project.<domain>.service` 子包，但 Test 文件用简短类名 `XxxService` 无 import（以为同包），报"找不到符号 类 XxxService"
- **根因**：Service 接口被放在 `service/` 子包（按 §9.2 包结构），Test 文件在实体域包（如 `com.company.project.<domain>`），两者不同包，Test 必须显式 import Service
- **正确写法**：生成 Test 前，先确认 Service 接口的 `package` 声明，Test 的 import 与之一致
  ```java
  // Test 文件在 com.company.project.<domain> 包
  package com.company.project.<domain>;
  import com.company.project.<domain>.service.XxxService; // 显式 import

  class XxxServiceTest {
      @Autowired private XxxService service;
  }
  ```
- **反例**：Test 和 Service 不同包，却裸用 `XxxService` 不 import

## 规则 4.8：当 mapperStyle 为 MyBatis 时，启动类 @MapperScan 必须指定 annotationClass，禁止裸包扫描

- **适用条件**：`skeleton-conventions.json` `mapperStyle` 为注解 SQL / XML（MyBatis 栈）。JPA 栈（`extends JpaRepository`）无 `@MapperScan`，本规则不适用、跳过
- **何时触发**：生成启动类 `ProjectApplication.java`（或等价 Application 类，base-architecture 阶段）
- **错误现象**：contextLoad / 启动失败，报 `NoUniqueBeanDefinitionException`（expected single matching bean but found 2）——某实体的 Service 接口被注册了两个 bean（MyBatis Mapper 代理 + @Service impl）
- **根因**：`@MapperScan` 裸包扫描（`@MapperScan("com.company.project")`）会把根包下**所有接口**（含每个实体的 Service 接口）都注册成 MyBatis Mapper 代理 bean，与 @Service 标注的 impl 撞车。42 个实体 = 42 个 Service 接口被误注册成双 bean
- **正确写法**：只扫标注 @Mapper 的接口
  ```java
  import org.apache.ibatis.annotations.Mapper;
  import org.mybatis.spring.annotation.MapperScan;

  @SpringBootApplication
  @MapperScan(basePackages = "com.company.project", annotationClass = Mapper.class)
  public class ProjectApplication { ... }
  ```
- **反例**：
  ```java
  @MapperScan("com.company.project") // 裸包扫描，Service 接口被误注册成 Mapper → 双 bean
  ```


## 规则 4.7：Service 接口/Impl 方法返回类型必须带泛型参数

- **何时触发**：Service 接口/Impl 方法返回 `ApiResponse` 或 `PageVO` 时
- **错误现象**：Service 接口方法返回裸 `ApiResponse`（无泛型），Test 用 `ApiResponse<XxxVO>` 接收，类型不匹配编译失败；list 方法返回 `ApiResponse` 但 Test 期望 `ApiResponse<PageVO<XxxVO>>`
- **根因**：生成 Service 接口时漏写泛型参数，用了裸类型 `ApiResponse`
- **正确写法**：返回 `<EnvelopeCls><具体VO>`，list 返回 `<EnvelopeCls><<PageVoCls><具体VO>>`（`<EnvelopeCls>`=`responseEnvelope`、`<PageVoCls>`=`pageVo` 真名，如 ruoyi 栈 `ApiResponse`/`PageVO`）
  ```java
  public interface XxxService {
      ApiResponse<XxxVO> create(XxxDTO dto);
      ApiResponse<PageVO<XxxVO>> list(XxxQueryDTO query);
  }
  ```
- **反例**：
  ```java
  ApiResponse create(XxxDTO dto); // 裸类型，Test 端泛型接收编译失败
  ```

## 规则 4.9：零跨实体铁律——跨实体只存外键 ID，不在本实体 Service/Repository 校验目标实体存在性

- **何时触发**：本实体 DDL 有指向**其它领域模块**实体的外键列（如 `fund` 模块实体有 `workshop_id` 列指向 `workshop` 模块实体），生成 Service/Repository 方法时
- **错误现象**：
  - 编译失败：为校验外键目标存在性，在 fund 模块 Service 里 `import com.company.<appName>.workshop.entity.Workshop;` + `@Autowired WorkshopRepository`，触发跨域依赖，build 期多 agent 并发生成时 Workshop/WorkshopRepository 尚未生成或路径漂移，报"找不到符号"
  - 启动失败：跨域 `@MapperScan`/bean 注入拉入其它域 mapper，contextLoad 级联报错（与规则 4.2 同源，但这里是被跨实体校验诱发的）
  - 职责越界：本实体 Service 越权查询目标实体表，破坏领域边界，后续业务模块阶段要补全跨实体逻辑时发现重复校验/冲突
- **根因**：误以为"外键就必须在写入时校验目标存在"。但跨实体（跨领域模块）的存在性校验属**后续业务模块阶段**的职责，base-architecture/实体生成阶段只负责本实体自身的 CRUD，不应跨域 import 或注入
- **正确写法**：
  - 跨实体外键**只存 ID 列**：DDL 声明 `workshop_id BIGINT COMMENT '关联隐患排查工单'`，Entity 有 `private Long workshopId;`，DTO/VO 带该字段，Service/Repository 透传该 ID，**不主动查询目标实体校验其是否存在**
  - 本实体 Service 的 create/update 只校验**本实体领域内**的字段约束（必填/唯一等），跨实体 FK 列只做 null 判空（若必填）+ 类型校验，不做存在性校验
  ```java
  // fund 模块 FundRecordServiceImpl —— 跨实体 workshopId 只透传，不 import Workshop
  //   <EnvelopeCls>/<ErrCodeCls> = skeleton-conventions responseEnvelope/errorCode 真名（如 ruoyi ApiResponse/ErrorCode）
  public <EnvelopeCls><FundRecordVO> create(FundRecordDTO dto) {
      if (dto.getWorkshopId() == null) {
          return ApiResponse.fail(ErrorCode.BAD_REQUEST, "workshopId 不能为空");
      }
      // 不写：workshopRepository.findById(dto.getWorkshopId()) —— 跨实体存在性校验属后续业务模块阶段
      FundRecord entity = new FundRecord();
      entity.setWorkshopId(dto.getWorkshopId()); // 只存外键 ID
      // ...本实体字段赋值、repository.insert(entity)...
  }
  ```
- **反例**：
  ```java
  // 反例：跨域 import + 注入 + 存在性校验
  import com.company.<appName>.workshop.entity.Workshop;              // 跨域 import，build 期 Workshop 未生成即编译失败
  @Autowired private WorkshopRepository workshopRepository;            // 跨域注入，启动期级联
  public ApiResponse<FundRecordVO> create(FundRecordDTO dto) {
      Workshop w = workshopRepository.findById(dto.getWorkshopId());   // 跨实体存在性校验，越权
      if (w == null) return ApiResponse.fail(ErrorCode.NOT_FOUND, "工单不存在");
      // ...
  }
  ```
- **注**：领域**内**的关系（同模块实体间 FK）按 `[实现知识库目录对应路径]/backend-build/java-crud-write.md` 规则 1.x 正常处理；本铁律仅约束**跨领域模块**的实体引用。

## 规则 4.10：自定义 Filter / @Component 必须显式命名 bean，禁与 Spring Boot 内置 bean 同名

- **何时触发**：生成自定义 `Filter`（继承 `OncePerRequestFilter`、实现 `javax.servlet.Filter`/`jakarta.servlet.Filter`，含追踪/MDC/请求上下文透传类）或任何 `@Component` 组件类时
- **错误现象**：
  - 启动失败：`BeanDefinitionOverrideException`（如 `Invalid bean definition ... bean 'requestContextFilter'`）——Spring Boot 2.1+ 默认 `spring.main.allow-bean-definition-overriding=false`，同名 bean 直接启动崩溃；
  - 被覆盖后的静默降级：若把 `spring.main.allow-bean-definition-overriding=true` 当修法，**Spring Boot 内置 bean 会覆盖同名自定义 filter**（内置定义在用户 bean 之后注册）⇒ 自定义 filter 不生效：**响应头缺 `X-Trace-Id` 回写、MDC 为空、traceId 断链**；健康检查只验 body 时仍会「通过」，故障拖到运行期
- **根因**：`@Component` 不显式命名时 bean 名 = 类名首字母小写（`RequestContextFilter` → `requestContextFilter`、`CharacterEncodingFilter` → `characterEncodingFilter`），与 Spring Boot 自动注册的内置 filter bean 同名。Spring Boot 内置的 **`requestContextFilter`、`characterEncodingFilter`、`hiddenHttpMethodFilter`、`formContentFilter`** 四个 bean 名必须避开，禁复用
- **正确写法**：`@Component` 显式给唯一 bean 名，形态 `<域/服务><职责>`，前缀避开上述内置名
  ```java
  @Component("assessmentServiceRequestContextFilter")  // 显式命名，禁留空退化成类名首字母小写
  public class RequestContextFilter extends OncePerRequestFilter { ... }
  ```
  或在 `@Configuration` 中用 `@Bean("assessmentServiceRequestContextFilter")` 显式命名；同名冲突的正确修法是**改名**，不是开 override 开关
- **反例**：
  ```java
  @Component  // bean 名 = requestContextFilter，与 Spring Boot 内置 requestContextFilter 撞名 → BeanDefinitionOverrideException
  public class RequestContextFilter extends OncePerRequestFilter { ... }

  // 反例修法：spring.main.allow-bean-definition-overriding=true 掩盖冲突 → 自定义 filter 被内置 bean 覆盖，X-Trace-Id 不回写
  ```
- **注**：自定义 filter 的**类名**可与 Spring Boot 内置类同名（包不同），但 **bean 名不能同**；四个内置 filter bean 名（`requestContextFilter`/`characterEncodingFilter`/`hiddenHttpMethodFilter`/`formContentFilter`）在自定义命名时一律不可复用。`@Configuration` 里重复定义骨架已有 `@Bean`（如 `corsConfigurationSource`）同理致 `BeanDefinitionOverrideException`，须注入复用而非重复定义（见规则 4.1/4.8 的 bean 唯一性口径）。
