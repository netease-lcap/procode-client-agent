# 运行时禁建表铁律（base-architecture 阶段）

本文件是"应用运行时绝不建表"的单一真理源，build/base-architecture 生成高码应用时引此，build/backend 实体生成建表步骤亦引此对照（生成期建表 vs 运行时禁建表），不重述。

## 权威结论

- **运行时禁建表（铁律）**：生成的高码应用运行时绝不允许动态建表。
- **禁止运行时迁移器**：禁生成任何 `ApplicationRunner` / 启动时执行 DDL 的迁移器（如 `DatabaseMigrator`、Flyway / Liquibase 运行时迁移）。
- **sql.init.mode = never**：`application.yml` 的 `spring.sql.init.mode` 保持 `never`。
- **应用启动只读写已存在的表**：不建表、不改表结构。所有表由 agent 在**生成期**通过 sql-exec CLI 建好。
- **建表收口 sql-exec CLI**：所有建表/改表由 agent 在生成期通过 `node .specify/scripts/javascript/sql-exec.mjs` 经平台 MCP 执行（MySQL 固定 MCP 通道，本地无直连），DDL 脚本由 CLI 统一落 `sql/*.sql` 作记录。**禁止裸 `mysql -h... -uroot ... < file.sql` / `mysql -N -e` 等手写 SQL 并自行执行**——必须走 sql-exec CLI 收口，绕过即视为违规。
- **SQL 归档根按归属模块落盘（plan 2026-10-24 §D6，本节是路径规则的唯一真理源）**：归档根 = `<项目产物根>/<module.pathBase>/sql/<dataSourceName>/<bucket>/`，`pathBase` 取工程方案 `<plans>/backend/_meta/engineering-plan.json` 的 `codeModules[]`（相对**项目产物根**，与部署侧构建单元同一基准）。调用 sql-exec 时带 `--module-id <该表/DDL 所属模块>`（**多模块工程必传**；单模块可省，省略时 CLI 按单模块回落）。三个分支：
  - 单模块服务 ⇒ `micro1023/backend/<service>/sql/<ds>/…`（`pathBase` 指向该服务根）；
  - 多模块服务 ⇒ `micro1023/backend/<service>/<module>/sql/<ds>/…`（module 层级由 `pathBase` 自带，不另造目录规则）；
  - 无工程方案（monolith / 存量产物）⇒ 维持 `<backendDir>/sql/<ds>/…`（旧布局不变）。
  `--module-id` 与 `--data-source-name` **可并存、互不替代**：前者决定归档与服务归属，后者决定数据源。多模块工程缺 `--module-id`（或 module id 未命中工程方案）时 CLI 直接 exit 1、不执行不落盘，**不会**回落到聚合根 `backend/sql`。其他文档只引本节，不另写一份路径规则。
- **种子数据 DML 例外（本铁律只禁运行时 DDL，不禁种子 DML）**：种子数据（默认账号/角色/字典/初始业务态等预置行 INSERT）由生成期 e2e 阶段（build/business-modules、build/deployment）agent 通过 `sql-exec --init-data` 灌库（落 `-init` 后缀文件），**运行时不重复灌、不生成 `ApplicationRunner`/启动迁移器灌种子**——灌种子走生成期 CLI，不走应用运行时链路；建表阶段（build/backend 实体生成）只建表不预置种子，空表交给 e2e 按需现场决策灌库。

## 判定信号

- 生成 `ProjectApplication.java` 或等价启动类 → 全条适用。
- 出现 `ApplicationRunner` / `CommandLineRunner` 执行 DDL → 命中反例，删迁移器。
- `spring.sql.init.mode` 为 `always` / `embedded` → 改 `never`。
- `@PostConstruct` / `init` 方法里 `CREATE TABLE` → 命中反例。
- 实体生成期建表 → 走 sql-exec CLI（生成期允许且要求），与本铁律不冲突（本铁律约束**运行时**）。

## 反例（绝对禁止）

```java
// ❌ 启动时建表迁移器
@Component
public class DatabaseMigrator implements ApplicationRunner {
  @Override
  public void run(ApplicationArguments args) {
    jdbcTemplate.execute("CREATE TABLE IF NOT EXISTS ...");  // 运行时禁建表
  }
}
```

```yaml
# ❌
spring:
  sql:
    init:
      mode: always   # 应为 never
```

## 正确写法

```java
// 启动类只启动 Spring，不建表
@SpringBootApplication
@MapperScan(basePackages = "com.company.project", annotationClass = Mapper.class)
public class ProjectApplication {
  public static void main(String[] args) {
    SpringApplication.run(ProjectApplication.class, args);
  }
}
// 表由生成期 agent 通过 sql-exec CLI 建好，运行时直接读写
```

```yaml
spring:
  sql:
    init:
      mode: never
```
