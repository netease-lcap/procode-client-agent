# 协调者运行时诊断口径（backend-build-runner 阶段）

本文件是 build/backend 三波修复协调者（编译 B0 / 启动 C0 / 单测 B1）的 **Java 运行时诊断口径**单一真理源。协调者 prompt 的**编排流程**（3 阶段模板、subAgent 派发四约束、≤4 并发、一次性全派、fix-history 写入）是栈中立的方法论，留在 prompt 正文不载本文件；本文件只承载 Java 栈特有的诊断命令、emit JSON 字段口径、常见根因信号与标准修法。换技术栈则按 `<stack>-impl/backend-build-runner/` 对应文件。

**类名不在此写死**：本文示例中的 `ApiResponse`/`ErrorCode` 是 ruoyi 栈 illustrative 名，真名+FQN 取 `skeleton-conventions.json` `responseEnvelope`/`errorCode`/`failureStyle`。换栈照真名替换；诊断命令与根因信号（mvnd/surefire/contextLoad）通用保留。

## 三波共用：JDK 与构建器环境前置（先定 JDK，再跑构建）

沙箱预装 8/11/17/21 四套 JDK，**已注入对应环境变量**（与 initialize 阶段 prompt-fragments
同源约定，build 波同样适用）：

| 目标 Java | 用这个 env 变量 |
|---|---|
| 8  | `$JAVA_HOME`     （默认基线，temurin-8）|
| 11 | `$JAVA_11_HOME`  |
| 17 | `$JAVA_17_HOME`  |
| 21 | `$JAVA_21_HOME`  |

跑任何 mvn/mvnd 前：
1. 读 pom 目标版本 NN（`<java.version>NN</java.version>`，未命中读
   `<maven.compiler.release>NN</maven.compiler.release>`）。
2. `export JAVA_HOME=$JAVA_NN_HOME`（Java 21 项目即 `$JAVA_21_HOME`）。
   - **禁止 Java 21 项目直接用 `$JAVA_HOME`**——它指向 JDK8，会让文本块 `"""`
     报 `illegal character: '#'`/`unclosed string literal` 假编译错。这是 JDK 版本问题
     不是源码错误，换对 JDK 即解，**禁改源码绕**。
   - Java 8 项目（`<java.version>1.8</java.version>`，NN 归一为 8，用 `$JAVA_8_HOME`）没有
     文本块/record 等高版本语法问题；版本错配表现为 `invalid target release: 21`（用高版本
     JDK 编 1.8 目标通常反而能编，主要风险是反向——Java 21 项目误用 JDK 8）。
   - 禁写死 `/usr/lib/jvm/temurin-21-jdk-current` 等具体路径——env 变量是沙箱维护的
     映射契约，写死即过拟合，换沙箱/JDK 版本即失效；也不靠 `java -version` 盲试
     （`java -version` 只验当前指向的版本，不能枚举已装 JDK）。

checker（check-backend-test.mjs 的 resolveJavaHome）已按此约定实现：第一步读
`JAVA_NN_HOME`/`JAVANN_HOME` 并 `java -version` 验版本匹配，env 变量命中即用、
零扫描、零写死。本知识段与 checker 同源，agent 手动跑 mvn 时照此 export 即可。

mvnd 崩溃识别（只读 registry 环境）：
- mvnd 输出含 `DaemonException`/`Read-only file system`（`registry.bin`）= mvnd 在本环境
  无法启动 daemon，属环境阻塞非代码 bug。此时换用标准 `mvn`（带上一步 `$JAVA_NN_HOME`）
  重跑，不视为「换 mvn 规避编译错」。
- check-backend-test.mjs 已内置此崩溃自动 fallback；手动诊断命令照此处理。

## 编译波（段 B0）：mvnd test-compile 诊断口径

- **诊断命令**：`mvnd -q test-compile 2>&1`（输出落盘 `${waveName}-diagnosis.log`）；
  若输出含 `DaemonException`/`Read-only file system`（mvnd registry 只读崩），按
  「三波共用：JDK 与构建器环境前置」换 `JAVA_HOME=$JAVA_NN_HOME mvn -B test-compile` 重跑。
- **错误提取**：从日志提取全部 `[ERROR] .../Xxx.java:[line,col] message` 行作为编译错误清单。
- **禁 clean**：mvnd 靠 daemon 增量编译，`clean` 抹掉增量缓存反而更慢。"找不到符号/类重复"是代码错误不是编译器/缓存问题，禁 clean、禁换 mvn（除 mvnd registry 只读崩溃外）、禁调 `-Dmaven.compiler.*` 排查编译环境。mvnd 输出 `DaemonException: .../registry.bin: Read-only file system` 时属环境阻塞，按「三波共用：JDK 与构建器环境前置」换标准 mvn + `$JAVA_NN_HOME` 重跑，不算违反本铁律。
- **Lombok 误判诊断顺序铁律**：遇 `找不到符号 方法 getXxx()/setXxx()/builder()` 且源码有 `@Data`/`@Builder` 注解时，**先排查上游级联编译失败**，禁推理 Lombok/注解处理器/mvnd 缓存。正确顺序：
  1. grep 诊断日志，找该类所属包是否有**其它致命错误**（类名与文件名不匹配、缺 import、包名错）——javac 遇致命错误会停止该包编译，导致同包类的 getter/setter 引用全部报"找不到符号"，这是级联效应不是 Lombok 没生成；
  2. grep 该类被引用处是否有缺 import（如 Service 接口用了 VO 但没 import，该文件编译失败级联到 Impl）；
  3. 只有排除(1)(2)后，才考虑注解处理器问题。
  - **实测**：编译波曾花 30+ 行推理"mvnd 增量缓存/Lombok annotationProcessorPaths 没配/target/classes 空"，最终根因是 ReportOperationLog DTO 类名错配 + SchoolSegmentService 缺 VO import 导致级联失败——Lombok 一直正常工作。
- **诊断命令只跑一次**：落盘后从日志文件读全部错误，禁反复重跑诊断命令 pipe grep（每次重跑都是一次全量编译，极慢）。要看错误细节读已落盘日志 grep。

## 启动波（段 C0）：check-backend-startup.mjs emit JSON 口径

- **诊断命令**：`node ../.specify/scripts/javascript/check-backend-startup.mjs`，脚本启动 Spring 应用 + contextLoad 验证（跑 test-compile + mvnd test 挑 Errors）。脚本不连数据库、方言无关。
- **emit JSON 字段**：
  - `startupErrors`：启动异常行扁平清单，含 `[Bean创建]`/`[MyBatis缺绑定]`/`[CausedBy]`/`[SQL约束]`/`[contextLoad]` 分类前缀；
  - `applicationLog`：Spring 日志路径，可 grep `Caused by|Exception|BindingException|No qualifying bean`；
  - `surefireDir`：surefire-reports 绝对路径；
  - `contextLoadReportFiles`：contextLoad 失败的 .txt 文件名清单，文件名 = 测试类 FQN；
  - `failureDetails`：每个失败方法的截断摘要（方法名 + 根因 + `at com.company...` 业务栈行号，框架栈已砍、同根因已去重），**优先读此字段**。
- **常见根因信号**：
  - `No qualifying bean of type 'XxxService'` = impl 类缺 `@Service`（或 `@Repository`/`@Component`）注解，或未注册为 bean。subAgent 在对应 impl 类上加注解 + 补 import 即可——一个缺注解会级联导致该 Service 的测试类全方法 contextLoad Error，补一个注解即可清零一批 Errors。详见 `[实现知识库目录对应路径]/shared/java-spring-bean.md` 规则 4.1。
  - `BindingException`（MyBatis Mapper 缺 SQL 绑定）= Mapper 接口缺 `@Mapper` 或注解 SQL 未写。详见规则 4.1。
  - `NoUniqueBeanDefinitionException`（expected single matching bean but found 2）= `@MapperScan` 裸包扫描把 Service 接口也注册成 Mapper 代理。详见规则 4.8（`@MapperScan` 必须指定 `annotationClass = Mapper.class`）。
  - contextLoad 级联：切片注解（`@DataJpaTest` 等）或跨域 `@MapperScan` 拉入其它域 mapper 致整类 Error。详见 `[实现知识库目录对应路径]/shared/test-annotation.md`。
  - `NOT NULL 约束` / `SQL约束`：数据源/配置错误或建表缺默认值。
- **诊断命令只跑这一次**：同编译波，落盘后读 JSON，禁反复重跑。

## 单测波（段 B1）：check-backend-test.mjs emit failureDetails 口径

- **诊断命令**：`node ../.specify/scripts/javascript/check-backend-test.mjs`，跑全量单测。
- **emit JSON 字段**：
  - `failureDetails`（**优先读此字段**）：key = 失败 .txt 文件名，value = 截断摘要，每失败方法一块含方法名 + 异常名 + `expected:<X> but was:<Y>` + `at com.company...` 业务栈失败行号，框架栈已砍、同根因已去重（实测 10 个失败文件砍 92% 上下文）；
  - `surefireDir`：surefire-reports 绝对路径，摘要不够时 cat `${surefireDir}/<文件名>` 全量兜底；
  - `reportFiles`：有失败的 .txt 文件名清单，文件名 = 测试类 FQN；
  - `summary`：`totalFailures`/`totalErrors`/`compileErrors`。
- **切片维度**：按 .txt 文件名（=测试类）切片派 subAgent。
- **验收命令 tee 落盘 + 每轮只跑 1 次**：`... 2>&1 | tee ${waveName}-verify-rN.log`（N=轮次序号）。禁裸跑、禁 `2>/dev/null | grep`、禁同轮重跑。想确认结果读 verify.log，不重跑命令。
- **surefire 全绿但 mvn 退出码非 0**（`totalFailures=0 && totalErrors=0` 但 `ok:false`）：不要继续派 subAgent 改 impl——看 failures 里附的 mvn `[ERROR]`/`BUILD FAILURE` 输出判断是否有真实测试问题。若 mvn 输出无测试相关错误（只是 tests 外的构建问题或 surefire 报告落盘不全），则判绿收尾。

### A 类 vs B 类失败分流（B1 核心诊断口径）

- **A 类 = 业务逻辑失败**（断言不对、返回值不对、校验缺失/过严、返回码错）：**改 impl 不改 test**，test 是需求判定基准。返回风格以 README §9.4 为准、失败处理/nullId 以 `[实现知识库目录对应路径]/backend-build/java-validation-return.md`（规则 2.5 失败处理、规则 2.6 create vs update partial）、`java-crud-write.md`（规则 1.3 null id）为准改 impl；字段校验缺失按 entity-*.md DDL 补 impl（返 fail 不 throw、不打 DB）。
- **B 类 = test 数据/结构 bug**（test 本身写错了，不是 impl 的锅）：**允许改 test 修正数据/签名/注解**，不算违反"改 impl 不改 test"铁律。判定信号（命中任一即大概率 B 类）：
  - 失败现象是 `ParameterResolutionException` / `Cannot convert null to primitive` / `NumberFormatException: "null"`；
  - `@CsvSource`/`@ValueSource` 列数与方法参数数对不上、多逗号/少逗号导致参数解析为 null 或错位；
  - test 方法签名用基本类型（int/long）接参数化注入的 null；
  - 或连续 2 轮同一测试方法失败且 `expected/but was` 值不变（impl 已改但断言仍不对，说明根因不在 impl 而在 test 数据/断言设计——如 test 传了越界值、冲突数据、与 DDL 枚举不符的值）。
  - 改 test 前必须读 fix-history：若前轮已从 impl 端绕过此问题且失败（教训栏标了"禁止改法"），本轮直接改 test，不再从 impl 端绕。改 test 只修数据/签名/注解错误，不得改断言期望值（断言是需求基准）。

### 防振荡口径

- **返回风格一次定死**：改返回风格前必须同时读 README §9.4 + test 断言 + impl 现状；test 与 README §9.4 冲突时以 test 为准。
- **同一方法连续 2 轮失败强制切 B 类**：读 fix-history 时，若某测试方法连续 2 轮失败、impl 已改过 2 种以上不同改法仍未修好（典型：去重维度在二元组/三元组间摇摆、Stream 过滤在链式/中间变量/MyBatis dynamic SQL 间摇摆），判定为振荡——根因大概率在 test 数据而非 impl。本轮强制切 B 类：派 subAgent 读 test 源码定位 test 数据/结构问题（冲突数据、越界值、与 DDL 枚举不符的值、`@CsvSource` 列错位），改 test 数据不改 impl。振荡时继续改 impl 只会引入新失败、拉长 B1 时长。
  - 去重维度详见 `[实现知识库目录对应路径]/backend-build/java-query-dedup.md` 规则 5.2（以 DDL UNIQUE 约束为准，不以 test 反推）。

### @NullAndEmptySource + update partial 标准修法（照此改不试错）

- **触发**：失败用例来自 update 方法的 `@NullAndEmptySource` / `@NullSource` 参数化注入（test 名含 `ShouldFail...NullOrEmpty` / `...WhenXxxNullOrEmpty`），且同一测试类还有 `shouldAllowPartialUpdate` / `shouldUpdatePartialFields` 等部分更新成功用例。
- **禁止**把校验改成 `== null || isBlank()`（会拦截所有 partial update 中该字段为 null 的正常用例，引入新失败）。
- **正确修法 = 「全空 DTO 检查」**：在 update 方法入口加一个「整个 DTO 的所有必填字段同时为 null/空」的判断（如 `if (isAllRequiredFieldsBlank(dto)) return ApiResponse.fail(ErrorCode.BAD_REQUEST, "...")`），只拦「全空 DTO」这个明确异常态；单字段 null/空时仍走原有 `!= null && isBlank() → 400` 逻辑（只拦「传了值但为空字符串」，null 跳过 = partial update 语义）。
- 改前必须先读 test 确认：哪些用例期望 400（全空/null/空字符串）、哪些期望 200（partial update 传部分字段），再改 impl 同时满足两类用例。
- 详见 `[实现知识库目录对应路径]/backend-build/java-validation-return.md` 规则 2.6（create vs update partial 的 blank 校验语义不同）。

### contextLoad 残留说明

- B1 进入时 contextLoad Errors 应已被 C0 清零（`@Service` 等已补）。若 cat .txt 见 `Failed to load ApplicationContext` / `No qualifying bean of type`（C0 漏修），说明 C0 未收敛——在返回中标注"疑似 C0 残留 contextLoad 错误"，不强行修（避免 C0/B1 职责混乱）；只修业务断言 Failures。

## 三波共用：FK 错误改 SQL 不改代码

- `SQLIntegrityConstraintViolationException` → 改本实体建表 SQL（`sql/{时间戳}-{表名}.sql`，或重新生成）删 `FOREIGN KEY` 行，列 COMMENT 标注 `FK→target(id)`，用 sql-exec CLI（`node .specify/scripts/javascript/sql-exec.mjs --backend-dir [后端产物目录对应路径] --type ddl --sql "$(cat <<'SQL' ... SQL)"`）重建表；调用须带 `--module-id <该表/DDL 所属模块>`（多模块工程必传；归档根规则与建表约定同见 `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md`）。
