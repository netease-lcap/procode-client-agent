# 写操作常识（insert/update/delete）

本篇覆盖 create/update/delete 方法体的常见写法错误。实体只要有写操作就必读。

**类名不在此写死**：本文示例中的 `ApiResponse`/`ErrorCode` 是 ruoyi 栈 illustrative 名。信封类/错误码类的**真名+FQN** 与工厂方法签名一律取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `responseEnvelope` / `errorCode`（设计阶段读骨架按角色判据发现的真实在用值），失败处理方式以 `failureStyle` 真值为准。换栈照真名替换示例中的类名；机械规则（insert 回读、默认值不覆盖入参、null id 判空、delete 返回 Integer）通用保留。

## 规则 1.1：create 必须回读 DB，禁止用内存 entity 构建 VO

- **何时触发**：实体的 create 方法（凡 insert 后返回 VO 都适用）
- **错误现象**：create 返回的 data 中 id=null、自增字段=null、DB 默认值字段=null，test 断言 assertNotNull(id) 失败
- **根因**：insert 用内存里的 entity 对象直接构建 VO 返回，该对象的 id/默认值是 insert 前的 null，DB 生成的自增 id 和默认值没回填到对象
- **正确写法**：
  ```java
  Entity entity = new Entity();
  // ... set 字段
  mapper.insert(entity);
  Entity saved = mapper.selectById(entity.getId()); // 回读，拿到 DB 生成的 id/默认值
  return ApiResponse.created(toVO(saved));
  ```
- **反例**：
  ```java
  mapper.insert(entity);
  return ApiResponse.created(toVO(entity)); // entity.getId() 还是 null → test 失败
  ```
- **PG 方言条款（databaseType=postgresql，最小深度）**：insert 后回读可用 `INSERT ... RETURNING <列清单>`（含自增 id/DB 默认值列）一次往返拿回 DB 生成值；**禁 MySQL 惯例 `last_insert_id()`/`LAST_INSERT_ID()`**（PG 不存在该函数，运行期报错）。回读另选 `selectById` 仍合法（MyBatis 层方言无关），但 SQL 内禁 MySQL 专属自增回读惯用法。

## 规则 1.2：默认值不覆盖 DTO 入参

- **何时触发**：实体字段有默认值，且 update 支持 partial update（DTO 字段 null 表示"不改"）
- **错误现象**：update 把用户传的值用默认值覆盖了；或 create 时 DTO 明确传了值却被默认值覆盖
- **根因**：set 默认值时没判 DTO 是否传值，无脑覆盖
- **正确写法**：
  ```java
  // 默认值只在 DTO 未传（null）时设，不能覆盖 DTO 明确传入的值
  if (dto.getStatus() == null) {
      entity.setStatus("ACTIVE"); // 默认值
  } else {
      entity.setStatus(dto.getStatus());
  }
  ```
- **反例**：
  ```java
  entity.setStatus("ACTIVE"); // 无脑设默认值，DTO 传的 status 被覆盖
  ```

## 规则 1.3：getById/update/delete 入口判空 id

- **何时触发**：getById/update/delete 方法入口
- **错误现象**：null id 传给 Repository 导致 SQL 异常或意外行为（MyBatis 把 null 传入 SQL）
- **根因**：入口没判空，直接把 null id 丢给 mapper
- **正确写法**：
  ```java
  if (id == null) {
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "id 不能为空");
  }
  ```
- **反例**：
  ```java
  Entity entity = mapper.selectById(id); // id=null 时 MyBatis 行为未定义
  ```
- **注**：本规则为 Java 实现常识，原设计文档 §9.6 已移入本篇（null id 行为不再载于 backend/README.md）

## 规则 1.4：create 返回 created(201)，其余返回 success(200)

- **何时触发**：所有 CRUD 方法的返回
- **错误现象**：create 返回 200 而非 201，或 update 返回 201，test 断言状态码失败
- **根因**：返回风格不统一，create 和其余方法混用
- **正确写法**：create 用信封的创建成功工厂方法（201）；list/getById/update/delete 用信封的成功工厂方法（200）。信封类真名+FQN 与工厂方法名取 `skeleton-conventions.json` `responseEnvelope`（如 ruoyi 栈为 `ApiResponse.created`/`ApiResponse.success`），详见 backend/README.md §9.4
- **反例**：create 用成功方法（200），或 update 用创建方法（201）

## 规则 1.5：Mapper 的 delete/update 返回类型用 Integer 不用 int

- **何时触发**：Repository（Mapper）接口的 delete/update 方法声明返回类型
- **错误现象**：contextLoad 或单测报 `attempted to return null from a method with primitive return type (int)`——MyBatis 在 0 影响行时可能返回 null，int 拆箱失败
- **根因**：MyBatis 的 delete/update 返回受影响行数，当 SQL 返回 null（如某些 dynamic SQL 分支）时，int 基本类型无法接收 null，拆箱 NPE
- **正确写法**：
  ```java
  @Mapper
  public interface XxxRepository {
      Integer deleteById(Long id);   // Integer，允许 null
      Integer updateById(Entity e);  // Integer，允许 null
  }
  ```
- **反例**：
  ```java
  int deleteById(Long id);  // MyBatis 返回 null 时拆箱 NPE
  ```

## 规则 1.6：delete/update 找不到记录返回 404，存在才执行返回 200

- **何时触发**：delete/update 方法的业务逻辑
- **错误现象**：delete 不存在的记录返回 200（成功），test 期望 404；或反过来修过头，把"删除刚创建的记录应 200"也改成 404
- **根因**：delete/update 没先查记录是否存在，无脑执行 SQL 返回 200；或只看受影响行数判断，0 行就返回 404 但没区分"记录不存在"vs"删除成功 0 行"（partial）
- **正确写法**：delete/update 前先 selectById 查记录是否存在，不存在返回 404（NOT_FOUND），存在才执行 SQL 返回 200
  ```java
  Entity exist = mapper.selectById(id);
  if (exist == null) {
      return ApiResponse.fail(ErrorCode.NOT_FOUND, "记录不存在");
  }
  mapper.deleteById(id);
  return ApiResponse.success(null); // 200
  ```
- **反例**：
  ```java
  mapper.deleteById(id); // 不查存在性，记录不存在也返回 200
  return ApiResponse.success(null);
  ```
- **注**：区分两种场景——"删除不存在的记录→404"vs"删除刚创建的记录→200"。test 的 shouldDeleteSuccess（先 create 再 delete）期望 200，shouldDeleteNotFound（直接 delete 不存在的 id）期望 404

## 规则 1.7：update partial 的"全空 DTO 拦截"边界——只拦所有业务字段都 null

- **何时触发**：update 支持 partial update（DTO 字段 null 表示"不改"），且入口有"全空 DTO 拦截"校验
- **错误现象**：update 的"全空 DTO 拦截"把 partial update（只传部分字段，其余 null）也拦了，返回 400 但 test 期望 200（`expected: <200> but was: <400>`）
- **根因**：判全空时用了"DTO 整体 null"或"任一字段 null 就拦"，误伤了合法的 partial update。partial update 的语义是：null 字段表示"不改"，只要有一个业务字段非 null 就是合法请求
- **正确写法**：判全空用"所有可更新字段都 null"——只有所有业务字段都 null 才拦，任一业务字段非 null 就放行
  ```java
  // partial update：所有可更新字段都 null 才拒绝
  if (dto.getName() == null && dto.getStatus() == null && dto.getSortOrder() == null) {
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "至少更新一个字段");
  }
  // 否则放行，null 字段表示不改
  if (dto.getName() != null) { entity.setName(dto.getName()); }
  ```
- **反例**：
  ```java
  if (dto.getName() == null) {  // partial update 只传 status 时 name=null 被误拦
      return ApiResponse.fail(ErrorCode.BAD_REQUEST, "名称不能为空");
  }
  ```
