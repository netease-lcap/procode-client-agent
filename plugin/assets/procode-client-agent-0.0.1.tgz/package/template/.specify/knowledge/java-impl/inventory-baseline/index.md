# 存量事实基线扫描规程（1-1.1 入口阶段 · inventory-baseline.json）

本目录供 **plans 入口阶段（inventory-baseline）** 使用：1-1.1 增量轮在项目最开头，由一个专职任务读本规程、扫描存量后端代码，产出唯一的「存量事实基线」`[大纲目录对应路径]/backend/_meta/inventory-baseline.json`。它是后续阶段的**事实地板**：阶段一 tech-stack 的栈轴从这里抄写（偏离须留痕）、阶段二 5 域专家按本域切片决定「保留/复用/清理」。

**与其他文档的关系**：本文档决定**每个键/条目怎么取值、怎么判定**；产物的信封形状（必填键、枚举、id 规则、evidence 字段结构、凭据红线）由 JSON 契约校验器 `[脚本代码目录对应路径]/javascript/verify-inventory-baseline.mjs` 机械把关并回灌错误——**本文档不得改动信封约束**，两边不一致时以校验器为真、回来改本文档的示例。

**校验边界**：脚本只读取基线 JSON，检查结构、类型、枚举、唯一性、相对路径字符串、证据字段与凭据规则；不发现源码根、不核验文件或服务目录存在性、不比对引用原文，也不判断技术结论。通过仅表示 JSON 合规。

**换栈约定**：本规程是 java-maven 版；未来 python/node 存量 = 各建 `python-impl/inventory-baseline/index.md`，信封与校验器复用。检测到的栈在本知识库**没有对应 `<stack>-impl` 目录时不报错**——按 §7 走 `degraded` 规程，这是已定义态。

---

## §0 任务边界（先读，红线）

- **正确性在产出时成立，不靠事后审核**：基线是下游的事实地板——tech-stack 逐字继承、5 域专家按切片决策、架构按它继承服务身份。错一条会一路放大。因此：
  - **无证据不落笔**：每个值必须来自本轮实际读到的文件；写不出 `{file, quote}` 的断言不写进基线，改写成具名缺口（对象 + 原因 + 责任步骤）或留空（schema 允许时）。禁先写结论再补证据。
  - **证据必须支撑值**：quote 要包含被断言的值本身或其直接判据行（版本号、artifact、driver、类型 token 必须能在 quote 里找到）；"文件里存在一行无关文字"不算证据。
  - **拿不准留缺口，不填默认值**：版本链断、多源冲突、目录归属不明时写 `null` / 缺口 / summary 说明，禁止用"常见版本""模板默认值""我印象中"补位。
  - **不复制、不猜目录**：只从本轮观测代码根读；禁止从 `_archive`/历史 round 复制；空壳/脚手架目录不算服务，也不能作为证据来源。
  - **交付前自检**：逐条把自己的 quote 回到文件里定位一次（记下 `file:line`）；定位不到或与值无关的，删断言或改缺口，再写盘。
- **只写这一个产物文件**（`[大纲目录对应路径]/backend/_meta/inventory-baseline.json`，目录不存在则创建），**不改任何其他文件**、不写台账、不动 README。
- **每条断言必须可锚定**：stack、每个数据源、每个能力条目都带 `evidence:[{file, quote}]`；quote 是文件内**逐字连续原文**（见 §5），引用的真实性与支撑关系由扫描 agent 回读源码自检；校验器不读取源码。
- **不臆造、不推测**：只写你在清单/配置/源码里真实见到的东西；拿不准的宁可不写进 stack，写进对应条目 summary 说明。
- **凭据不落盘**（校验器红线机械执行）：password/token/secret/username 等**明文值**任何形式都不进文件；占位写法（`${DB_PASSWORD}`、`<your-password>`）放行。

---

## §1 stack 节取值规程（键名固定，不得增删键）

`stack` 只允许键：`language / stackId / buildTool / runtime / framework / dataAccess / layout / chainSupported / evidence`。逐键规程：

| 键 | 取值规程（java-maven 版） | 锚点来源 |
|---|---|---|
| `language` | 后端根下存在 `pom.xml` 或 `settings.gradle[.kts]` → `"java"`。 | 清单文件名本身（quote 其首行如 `<project`） |
| `stackId` | 本栈注册值：有 spring-boot 且 ORM 为 mybatis 系 → `"java-spring-mybatis"`；否则取最贴近的已知串（如 `"java-spring-jpa"`）。小写连字符，不发明新结构。 | 支撑判断的那行 pom |
| `buildTool` | 有 `pom.xml` → `"maven"`；有 `settings.gradle[.kts]` → `"gradle"`。两者都在时以实际构建入口（有 `mvnw`/`gradlew` 者优先）为准并在 summary 说明。 | 清单文件 |
| `runtime` | `{name:"jdk", version:"<版本串>"}`。版本优先链（**取第一个命中的，锚定该行**）：① properties 里 `maven.compiler.release` → ② properties 里 `<java.version>` → ③ maven-compiler-plugin 的 `<source>`/`<target>`。version 写原文串（`21`、`17`），找不到写 `null`。 | pom.xml 对应属性行 |
| `framework` | `{name:"spring-boot", version}`。version 优先链：① `<parent>` 为 spring-boot-starter-parent 时取 parent `<version>` → ② dependencyManagement 里 spring-boot-dependencies BOM 的 version → ③ 任一 `spring-boot-starter*` 依赖显式 version。全没有（版本由自定义 parent 管理）→ 查该 parent 的 pom 再取；仍不明 → `null` 并在 stack 的 evidence 加 parent 声明行。 | parent/BOM 行 |
| `dataAccess` | `{name, version}`，name 按 starter artifactId：`mybatis-plus-boot-starter`→`"mybatis-plus"`；`mybatis-spring-boot-starter`→`"mybatis"`；`spring-boot-starter-data-jpa`→`"jpa"`；其他持久层框架取 artifactId 去 starter 后缀小写；**确无数据访问组件** → `name:"none"`。version 有显式取之，否则 `null`。 | starter 的 `<artifactId>` 行 |
| `layout` | `{multiModule, modules, entryModule}`。`modules` = 根 pom `<modules>` 的 `<module>` 逐条列出（数组，保持原名）；`multiModule` = modules 非空；`entryModule` = grep `@SpringBootApplication` 落在哪个模块的 src → 该模块名；单模块或找不到 → `null`。`<modules>` 不存在 → `modules: []`。 | `<module>` 行 / 启动类 import 行 |
| `chainSupported` | **本栈链能力规则**：`language==="java"` 且 §2 所有数据源 `type ⊆ {mysql, mariadb, mysql8, mysql5.7}` → `true`；否则 `false`（false 意味着下游强制人裁决——如实写，不要为了"能跑"谎报）。 | 不需要独立锚点（由 stack/dataSources 派生） |
| `evidence` | ≥1 条，**建议 2-4 条**：runtime/framework/buildTool 各自的判据行各锚一条。 | pom.xml |

**多模块注意**：所有 pom 都要读（根 + 每模块）；`evidence.file` 的锚定根按任务变体取（见 §5）——legacy 1-1.1 相对后端根（如 `app-core/pom.xml`），增量 micro P1 相对项目产物目录（如 `backend/app-core/pom.xml`）。

---

## §2 dataSources 三路枚举（每源一项，键只允许 `id/name/type/primary/evidence`）

**枚举路径**（三条全走一遍，取并集去重）：

1. **dynamic-datasource**：yml 存在 `spring.datasource.dynamic.datasource.<name>:` 块 → 每个 `<name>` 一项。
2. **单数据源**：yml 存在 `spring.datasource.url`（或 `spring.datasource.driver-class-name`）→ 一项，`name` 取 `"master"`。
3. **多 DataSource Bean**：Java 源码 `@Bean` 返回 `DataSource` 的方法名各一项（如 `dataSource()` → `"default"`）。

**各项取值**：
- `id`：恒为 `"ds:" + name`（校验器强制逐字相等）。
- `type`：**版本感知**的 driver / 坐标映射，写**平台字面值**（`mysql` 与 `mysql8` 是不同版本类型，禁互相替换 / 禁并族）：

  | 代码证据 | `type` |
  |---|---|
  | `com.mysql.cj.jdbc.Driver`（Connector/J 8.x 驱动类） | `"mysql8"` |
  | `com.mysql.jdbc.Driver`（Connector/J 5.1.x 驱动类） | `"mysql"` |
  | `com.mysql:mysql-connector-j`（8.x 坐标，无版本也按 8.x） | `"mysql8"` |
  | `mysql:mysql-connector-java` + 版本 `8.*` | `"mysql8"` |
  | `mysql:mysql-connector-java` + 版本 `5.1.*` / 无版本 | `"mysql"` |
  | 仅 `jdbc:mysql://`（无驱动 / 版本判据） | `"mysql"`（族默认，不弹问） |
  | `org.postgresql` / `jdbc:postgresql:` | `"postgresql"` |
  | `oracle.jdbc` / `jdbc:oracle:` | `"oracle"` |
  | `com.microsoft.sqlserver` / `jdbc:sqlserver:` | `"sqlserver"` |
  | `dm.jdbc` / `jdbc:dm:` | `"dameng"` |

  或从 url 前缀 `jdbc:<scheme>:` 取（只知道族时写族默认）。只写基础名，不带连接信息。**不要**因为看到 `mysql-connector-java` 就一律写 `mysql`——版本行命中 `8.*` 时必须写 `mysql8`。
- `primary`：主库/默认库 `true`，其余 `false`（**至多一个 true**；单源恒 true）。
- `evidence`：≥1 条，锚**不含凭据**的行。

**连接值不落盘（校验器红线机械执行）**：条目没有也不该有 url/host/port/username/password 字段。锚点选取指引：

- ✅ `driver-class-name: com.mysql.cj.jdbc.Driver`（首选）
- ✅ `spring.datasource.dynamic.datasource.master:`（键行本身）
- ✅ url 行**截断到查询参数之前**的连续子串，如原行 `url: jdbc:mysql://10.0.0.1:3306/db?user=x&password=y` → quote 用 `url: jdbc:mysql://`（截断子串仍须是逐字原文，由扫描 agent 回读确认）
- ❌ 任何含 `password:`/`username:` 明文的行、含 userinfo（`://user:pass@`）的串
- 放行（但优先选上面 ✅）：环境变量占位 `${DB_PASSWORD}` 形态的值

**profile 文件**：`application.yml` 之外，`application-{dev|test|prod}.yml`、`bootstrap.yml` 也要扫（不同 profile 可能定义不同源；同名 profile 变体去重，summary 注明出现在哪些文件）。

### §2.5 observedIdentity（可选块；增量 micro P1 的存量真实服务身份）

任务提示要求记录存量服务身份时，在顶层写 `observedIdentity: { services: [...] }`；**没有服务清单时整块缺省，不写空数组**。每个服务：

```
{ "serviceName": "ruoyi-system", "serviceType": "backend",
  "sourceDir": "backend/ruoyi-modules/ruoyi-system", "buildUnits": ["ruoyi-modules-system"],
  "port": 6008, "evidence": [{ "file": "backend/ruoyi-modules/ruoyi-system/pom.xml", "quote": "<artifactId>ruoyi-modules-system</artifactId>" }] }
```

- 来源（只读）：`service-manager.config.json`、`<appName>-services.json`、各服务构建清单/启动类；**不得调用会触发登记的 `getServices`**。
- `serviceName` = 真实服务名原样、全局唯一；`serviceType ∈ {backend, frontend}`；`sourceDir` 必须相对锚定根（micro = 项目产物目录）且真实存在；`buildUnits` 是该服务的构建单元名（artifactId/模块目录名）。
- `evidence` 按 §5；**空壳/脚手架目录不登记为服务**（有构建清单但无真实源码/启动类的目录只能作为缺口写明，不进 services）。
- 只有真实存在的服务才登记；需求新增但存量不存在的服务不写进 observedIdentity。

---

## §3 能力域信号集（判定参考，不是穷举上限——穷举责任在 §4 checklist）

每个条目形状固定：`{id, capability, status, evidence, summary}`，`id = "<域名>:<slug>"`，slug 小写字母数字开头、可含 `.-_`（如 `middleware:redis`、`integration:file-upload-oss`）。`status` ∈ `used | configured | declared`（定义见 §4）。

### authz（§6.1 身份与权限）
- pom：`spring-boot-starter-oauth2-*`、`spring-security-oauth2-*`、`jjwt`、`java-jwt`、`sa-token*`、casdoor 等
- yml：`spring.security.oauth2.*`、自定义 `jwt.secret`（值不落盘，锚键行）
- src：`@PreAuthorize`、`hasRole(`/`hasAuthority(`、`SecurityFilterChain` 里的授权规则（`requestMatchers(...).authenticated()`）、Sa-Token 注解

### security（§6.2 安全硬化）
- pom：`spring-boot-starter-security`、`zxcvbn`、kaptcha、加密库（bouncycastle 等）
- yml：cors/csrf 相关开关
- src：`PasswordEncoder` Bean、`CorsConfigurationSource` Bean、`http.csrf()`、登录接口密码校验

### integration（§5.1 外部集成与文件存储）
- pom：`spring-cloud-starter-openfeign`、`xxl-job-core`、`spring-integration-*`、存储 SDK（`aliyun-sdk-oss`、`minio`、`cos_*`）
- yml：`feign.*`、`xxl.job.*`、oss/minio 端点配置（值同上红线）
- src：`@FeignClient`、`@KafkaListener`/`@RabbitListener`/`@RocketMQMessageListener`（**消费侧归 integration**）、`@Scheduled`、XxlJob handler、文件上传下载 service

### middleware（§5.2 中间件选型）
- pom：`spring-boot-starter-data-redis`、`redisson*`、`caffeine`、`spring-boot-starter-amqp`、`spring-kafka`、`rocketmq-client`/`rocketmq-spring-boot-starter`、`spring-boot-starter-websocket`
- yml：`spring.redis.*`、`spring.rabbitmq.*`、`spring.kafka.*`、`rocketmq.*`
- src：`RedisTemplate` 使用、producer 发送调用（**生产侧归 middleware**）、CacheManager Bean

### observability（§7.1 可观测性）
- pom：`spring-boot-starter-actuator`、`micrometer-*`、`apm-toolkit-*`/skywalking、`logstash-logback-encoder`
- yml：`management.endpoints.*`
- src：`logback-spring.xml` 存在、`@EnableAdminServer`、MDC/TraceId filter

### 双投信号归属单表（一个 artifact 只进一个域，防两域各写一条）
| 信号 | 归 | 不归 |
|---|---|---|
| MQ 客户端/producer 发送 | middleware | integration |
| MQ listener 消费、消息处理链 | integration | middleware |
| Redis / 缓存 | middleware | — |
| `@Scheduled` / xxl-job / 定时任务 | integration | middleware |
| actuator / 日志 / 链路追踪 | observability | security |
| JWT / OAuth2 / 权限注解 | authz | security |
| PasswordEncoder / CORS / CSRF / 加密 | security | authz |
| 文件存储 SDK（oss/minio/cos） | integration | middleware |

归属拿不准时：**写进更贴近"对外依赖"语义的那一域**，另一域不重复立条目（summary 可注明关联）。

---

## §4 逐条枚举 checklist（抗漏报主责——照此执行并自查）

> 漏报（该列未列）无机械判据，本 checklist 是全链唯一系统性防线。逐条执行：

- [ ] **找齐全部构建清单**：后端根下 `find . -name pom.xml -not -path '*/target/*'`（或 `build.gradle*`）——每个文件都打开。
- [ ] **逐清单逐条枚举 `<dependencies>`**：**一个 artifactId 一条**，不得合并、不得跳过、不得因"看起来不重要"省略。传递依赖不管（只列 pom 里显式声明的）。
- [ ] **归并豁免须列名**：仅 `scope=test` 依赖、纯日志桥接（`jcl-over-slf4j`/`jul-to-slf4j` 类）可归并成条目，但归并项的 artifactId 必须逐个写进该条 `summary`。
- [ ] **自报数核对**：数清单显式声明依赖总数 X（不含归并豁免），确认基线三节（stack + dataSources + domains 全部条目）对它们的覆盖数 == X。差多少就是漏多少，补齐后才准写盘。
- [ ] **找齐全部配置文件**：`application*.yml`/`application*.properties`/`bootstrap*.yml`（全 profile）——每个中间件配置块各成条目（无代码锚点时 status=configured）。
- [ ] **源码锚点扫描**：对每条 declared/configured 候选，grep `src/main`（排除 `target/`）确认是否有 import/注解/Bean 使用点；有则升级 status 并把源码行加进 evidence。
- [ ] **status 判定**：`used` = src/main 有真实使用锚点（import/注解/Bean/调用）；`configured` = 配置文件有块、代码无锚点；`declared` = 仅构建清单。同一能力多层命中 → 一条，status 取最强，evidence 各层都锚。
- [ ] **粒度**：一条 = 一个可独立决策的"能力"（Redis 缓存、RabbitMQ、JWT 鉴权链、OSS 文件存储……），不是一条 = 一个 jar（同一能力的 starter+client+工具类合一条，evidence 多锚）。

---

## §5 evidence 规程（agent 核实原文，校验器只检查字段）

- 每个 evidence 项 = `{file, quote}` **只有这两个键**。
- `file` 的锚定根按**任务变体**二选一（以本轮任务提示里的 `### 本轮观测代码根` 块为准）：
  - **legacy 1-1.1（只扫后端）**：相对**后端工程根目录**（即 `[后端产物目录对应路径]`），如 `app-core/pom.xml`、`src/main/resources/application.yml`；
  - **增量 micro P1（前后端全量盘点）**：相对**项目产物目录**（即 `[项目产物目录对应路径]`），且**必须以服务目录名开头**，如 `backend/pom.xml`、`backend/ruoyi-modules/ruoyi-system/pom.xml`、`frontend/package.json`。观测代码根之外的目录（尤其 `<appName>-backend` 脚手架）不得作为证据来源。
  - 两种变体都不允许绝对路径、不允许 `..`。
- `quote`：该文件内**逐字连续原文**，≤200 字符，保留原有空白，由扫描 agent 回读确认。可以是一行、一行的一部分、或多行连续片段。
- `quote` **必须支撑该条断言**：被断言的值（版本号、artifactId、driver、类型 token、状态判据）必须能在 quote 中找到；多行 quote 会降低可定位性，优先取**单行判据**。
- 每条断言 ≥1 锚；stack 建议 2-4 锚（版本类判据各一）。
- 找不到合适锚点 = 该断言不该写进基线。删断言，不造锚点。
- 写完每条 quote 后**回读定位一次**（确认 `file:line` 与值对应）；定位不到或与值无关 ⇒ 删断言或改写缺口，禁保留"存在但无关"的锚。

---

## §6 输出 schema（围栏块 = 信封展开，与校验器钉死集一致，不得增删键）

```json
{
  "schemaVersion": 1,
  "generatedBy": "plans/inventory-baseline (LLM, doc-guided)",
  "generatedAt": "<ISO 时间>",
  "degraded": false,
  "stack": {
    "language": "java",
    "stackId": "java-spring-mybatis",
    "buildTool": "maven",
    "runtime": { "name": "jdk", "version": "21" },
    "framework": { "name": "spring-boot", "version": "3.2.5" },
    "dataAccess": { "name": "mybatis-plus", "version": null },
    "layout": { "multiModule": true, "modules": ["app-core", "app-admin"], "entryModule": "app-admin" },
    "chainSupported": true,
    "evidence": [
      { "file": "pom.xml", "quote": "<spring-boot.version>3.2.5</spring-boot.version>" },
      { "file": "pom.xml", "quote": "<maven.compiler.release>21</maven.compiler.release>" }
    ]
  },
  "dataSources": [
    {
      "id": "ds:master",
      "name": "master",
      "type": "mysql8",
      "primary": true,
      "evidence": [
        { "file": "src/main/resources/application.yml", "quote": "driver-class-name: com.mysql.cj.jdbc.Driver" }
      ]
    }
  ],
  "domains": {
    "authz": [],
    "security": [],
    "integration": [],
    "middleware": [
      {
        "id": "middleware:rocketmq",
        "capability": "RocketMQ 消息发送",
        "status": "used",
        "evidence": [
          { "file": "pom.xml", "quote": "<artifactId>rocketmq-client</artifactId>" },
          { "file": "src/main/java/com/example/config/RocketMqConfig.java", "quote": "new DefaultMQProducer(" }
        ],
        "summary": "存量已实装 RocketMQ producer（config/RocketMqConfig.java 建 Bean，业务侧有发送调用）"
      }
    ],
    "observability": []
  }
}
```

（示例中 `domains` 只展开 middleware，**实际写盘必须五域键齐全**，无存量的域给空数组 `[]`。）

---

## §7 degraded 规程（本知识库无该栈文档 / 文档读不到时）

- `degraded: true`；`stack` 只填 `language`（检测到的语言 token）、`stackId`（如 `"python"`，取检测值）、`chainSupported: false`、`evidence`（照常锚定清单文件）；`buildTool/runtime/framework/dataAccess/layout` 可省略。
- `dataSources` 与 `domains` **仍按信封逐条产出**（信封与取证要求不因降级而免——校验器检查 JSON 结构，agent 核实源码证据）：能力条目按通用口径「清单/配置/源码三层」自行归纳，域名归入最接近的五域键之一，summary 说明归属判断。
- 降级不是错误：下游（阶段一/二）见 `degraded:true` + `chainSupported:false` 会走人工裁决边界。如实降级，不要硬套 java 键值。

---

## §8 写盘前自检（全过才准结束）

- [ ] 顶层只有 `schemaVersion(1) / generatedBy / generatedAt / degraded / stack / dataSources / domains` 七键。
- [ ] `degraded:false` 时 stack 九键齐、domains 五域键齐（空域 = `[]`）。
- [ ] 每条 id：域条目 `"<域>:<小写slug>"` 且前缀==所在域、全局唯一；数据源 `id === "ds:" + name`、`primary=true` 至多一条。
- [ ] `status` 全部 ∈ `used|configured|declared`。
- [ ] 每条 evidence：file 按 §5 的变体取锚定根（legacy=后端根相对；micro P1=项目产物目录相对、以服务目录名开头、落在观测代码根内）且真实存在；quote ≤200 字符、在文件内逐字可 grep（空白差异外零改写）。
- [ ] **每条 evidence 的 quote 都能支撑该断言值**（版本/artifact/driver/类型 token 在 quote 内可寻；不只是"文件里存在"）。
- [ ] **每条 quote 已回读定位到 `file:line`**；定位不到或与值无关的已删断言或改为缺口。
- [ ] **没有用常识/模板默认值补位**；没有从 `_archive`/历史 round 复制事实。
- [ ] `observedIdentity` 每个 `sourceDir` 都有构建清单 + 源码/入口支撑；空壳/脚手架已剔除或写成缺口。
- [ ] 全文件搜不到明文 `password:`/`token:`/`secret:` 值与 `://user:pass@` 串（占位除外）。
- [ ] §4 自报数核对已过（清单条数 == 覆盖条数）。
- [ ] 没有改动/新建除该 JSON 以外的任何文件。
