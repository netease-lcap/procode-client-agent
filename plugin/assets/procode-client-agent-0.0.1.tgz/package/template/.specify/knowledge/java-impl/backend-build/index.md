# backend-build 阶段实现常识索引（实体生成 + review + 修复）

本索引列出 build/backend 实体 impl/test 生成与修复时易反复犯的"常识性"错误。这些错误历次生成与修复中反复出现，不读分篇裸生成必然重犯。

**生成前必读本索引**：根据当前实体的操作场景，用 read tool cat 对应分篇。分篇里的【正确写法】必须照抄，【反例】绝对禁止。

分篇路径前缀：`[实现知识库目录对应路径]/backend-build/`（占位符会被框架替换为绝对路径）

## 本阶段独有分篇（按操作场景选读）

### 1. java-crud-write.md —— 写操作（insert/update/delete）
- 适用场景：实体有 create/update/delete 方法（几乎必有）
- 触发关键词：create / insert / 新增 / update / 编辑 / delete / 删除 / 自增ID / 默认值 / null id / partial update / 404 / 返回类型 int
- 覆盖错误：insert 后未回读、默认值覆盖入参、null id 判空、delete 返回类型 int 拆箱 NPE、delete 不存在记录返回码 404/200、partial update 全空 DTO 误拦
- **判断**：实体只要有写操作就必读（命中率 ~100%）

### 2. java-validation-return.md —— 校验与返回风格
- 适用场景：实体有必填/唯一/范围/枚举字段的校验，或返回 ApiResponse
- 触发关键词：必填 / NOT NULL / UNIQUE / 唯一 / 校验 / validate / ApiResponse / created / success / fail / throw / @NullAndEmptySource / @NullSource / @EmptySource / blank / partial update
- 覆盖错误：校验缺失/过严、返回码 201/200 混用、throw vs fail、@NullAndEmptySource 对 Long/Integer 不兼容、create vs update partial 的 blank 校验语义混淆
- **判断**：实体只要有校验就必读（命中率 ~100%）

### 3. java-type-precision.md —— 类型与精度
- 适用场景：实体有 BigDecimal / 金额 / LocalDateTime / 时间 / 正则校验 字段
- 触发关键词：BigDecimal / 金额 / 精度 / DECIMAL / NUMERIC / LocalDateTime / 时间 / nano / 截断 / 正则 / regex / pattern
- 覆盖错误：BigDecimal 用 != 或 equals 比较、时间 nano 未截断、正则 * vs +、金额 DDL 精度范围校验缺失、toVO 的 BigDecimal 比较用 equals
- **判断**：实体 DDL 有 DECIMAL/NUMERIC/DATETIME/TIMESTAMP 或校验含 regex 才读

### 4. java-query-dedup.md —— 查询、去重与 Stream
- 适用场景：实体有 list 查询 / 去重 / Stream 链式操作
- 触发关键词：list / 查询 / 去重 / distinct / Stream / filter / 唯一检查 / 二元组 / 三元组 / Integer 参数
- 覆盖错误：Stream 中间变量失效、去重维度与 DDL UNIQUE 约束不符、list 签名 int vs Integer
- **判断**：实体有 list 查询或唯一性检查（查重）才读

### 5. java-alter-add-column.md —— 存量表加列（ALTER ADD COLUMN 分支）
- 适用场景：entity-*.md 形态为 `ALTER TABLE <存量表> ADD COLUMN`（build ADD COLUMN 分支）
- 触发关键词：ALTER / ADD COLUMN / 存量表加列 / 往已有表加字段 / 框架表加列 / ALTER TABLE ... ADD COLUMN
- 覆盖错误：漏改 resultMap/共享列片段/列表查询/insert/update 任一处、缺 getter/setter、新列索引误进 Java、误生成第二份 entity
- **判断**：entity 形态为 ALTER ADD COLUMN 时必读（ADD INDEX 形态不读、走跳过分支）

## 跨阶段共用分篇（本阶段也必读，在 shared/）

- `[实现知识库目录对应路径]/shared/java-spring-bean.md` —— @Service/@Mapper/@Component 注解（生成几乎必有，命中率 ~100%）+ 零跨实体铁律（规则 4.9）
- `[实现知识库目录对应路径]/shared/persistence-convention.md` —— 持久层风格/分页/实体形态照 skeleton-conventions mapperStyle/pageVo 真值（不 mandate 单一栈；实体 Repository 生成必读）
- `[实现知识库目录对应路径]/shared/test-annotation.md` —— 测试注解约定（注解组合/数据源/失败断言照 skeleton-conventions 真值，不 mandate 单一组合；多模块 `@SpringBootTest` 测试类落 `bootModule.moduleDir` 而非 impl 同模块；单测生成必读）
- 触发关键词：`@SpringBootTest` / `@SpringBootConfiguration` / `Unable to find a @SpringBootConfiguration` / contextLoad 整类 Error / 多模块 → 路由到 `shared/test-annotation.md`「测试类位置（多模块）」段

## 读取顺序建议

1. 先读本实体的 entity-*.md（DDL + 字段表），识别字段类型与约束
2. 对照本索引的"触发关键词"，判断该 cat 哪几个分篇
3. 用 read tool 逐个 cat 对应分篇（路径见上，前缀 `[实现知识库目录对应路径]/backend-build/` 或 `shared/`）
4. 生成 impl/test 时，分篇里的【正确写法】照抄，【反例】绝对禁止
5. 自我审查时，逐篇逐条核对
