# 测试注解约定（跨阶段共用：design §1 + build 实体生成）

本文件是测试注解写法的单一真理源，plans/backend-design §1 与 build/backend 实体单测生成均引此，不重述。

**类名/注解/数据源不在此写死**：测试注解组合、测试数据源、失败断言方式的**真名** 一律取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `testAnnotations` / `testDataSource` / `failureStyle`（设计阶段读骨架按角色判据发现的真实在用值）。本文只承载通用机械规则，具体注解名以 skeleton-conventions 真值为准、禁臆测、禁造第二套。

## 权威结论

- **测试类注解照 `testAnnotations` 真实在用组合**：骨架在用 `@SpringBootTest`+`@Transactional` 则照用、在用 `@DataJpaTest` 则照用、在用纯 `@ExtendWith` 则照用——逐字用其真实注解组合，不在本文 mandate 单一组合。
- **测试数据源照 `testDataSource` 真实在用**：骨架直连真实 DB 则照直连、用 `@Sql` 则照用——**不引 H2/内存库**（pom 不供 `com.h2database:h2` 依赖，见 `[实现知识库目录对应路径]/base-architecture/pom-dependencies.md`「测试依赖」段）；测试在真实 app 数据源跑（`application.yml` 指向的库），测什么跑什么、避免内存库方言假绿。表已由 agent 通过 sql-exec CLI 在生成期建到目标库（见 `[实现知识库目录对应路径]/base-architecture/runtime-no-ddl.md`），测试不负责建表。
- **真实库按测隔离（强制，针对整体 `@SpringBootTest` 直连真实持久库）**：`@Transactional` 只回滚**本测方法内的插入**、**不清已提交的残留/种子行**。故真实库整体 Spring 测试类须二选一：(a) 类级 `@Transactional` + `@BeforeEach`（在事务内）`DELETE`/`TRUNCATE` 被测实体表清空再测——清已提交残留/种子行，对历史污染鲁棒；被测表有入向 FK 时先清依赖表或 `SET FOREIGN_KEY_CHECKS=0` 包裹再复位；(b) 幂等断言——禁 `rows().size()==N` 精确计数，改 `>=N`/按业务键判存在。缺这两者则残留行让 `create` 查重误命中返 409 → `getData()` null → 下游 update/delete/getById 级联 NPE（surefire `Errors`）被 C0 gate 死循环。切片测试（如 `@DataJpaTest`）默认事务回滚，按其自身机制隔离、不强制 `@BeforeEach` 清表。
- **失败断言照 `failureStyle` 真实在用方式**：骨架失败走 `return 信封.fail(...)` 则断言 `assertFalse(r.isSuccess())`、禁断言 throw；骨架失败走 `throw 异常` 则照 `assertThrows(...)`——以 skeleton-conventions `failureStyle` 为准，不预设。信封类真名+FQN 见 `responseEnvelope`。
- **测试类位置（通用 + 多模块）**：测试类 package 放 `<modulePackage>`（与 impl 同包），`@Autowired <Entity>Service service` 注入被测 Service。**多模块 Maven 工程（根 pom packaging=pom 仅聚合、启动类在子模块）**：`@SpringBootTest` 整体注解测试类须落**含 `@SpringBootApplication` 的启动模块**（`skeleton-conventions.json` `bootModule.moduleDir`）的 `src/test/java/<modulePackage>/`，**不跟 impl 同模块**——启动类所在模块外的业务模块向上搜不到 `@SpringBootConfiguration`，会 `Unable to find a @SpringBootConfiguration` 整类 contextLoad Error；package 仍为 `<modulePackage>`（同包、不同模块），禁因跨模块改包名。单模块工程 `bootModule.moduleDir` 为根、test 与 impl 同目录。`@DataJpaTest` 等切片测试无此约束（不找启动类），落 impl 同模块即可。
- **参数化（强制收敛，通用 JUnit 5 机械规则）**：禁为同质输入逐个写 `@Test`，用 `@ParameterizedTest`（`@CsvSource` / `@EnumSource` / `@ValueSource` / `@NullAndEmptySource`）。收敛规则：(1) 枚举字段有效值全覆盖用 `@ParameterizedTest @CsvSource` 或 `@EnumSource`，一个方法覆盖所有枚举值，每个值断言创建成功或返回正确描述；(2) NOT NULL 字段必填校验用 `@ParameterizedTest @NullAndEmptySource`，一个方法同时覆盖 null 和空串两种非法输入；(3) 数值字段范围越界用 `@ParameterizedTest @ValueSource`，一个方法传入 {min-1, max+1} 等越界值；(4) 多字段默认值校验合并为一个 `@ParameterizedTest @CsvSource`，传入「字段名,设置方法,期望默认值」的集合；(5) 多个唯一字段的重复校验合并为一个 `@ParameterizedTest @CsvSource`，传入不同唯一字段的重复值组合；仅业务逻辑复杂、断言差异大的场景保留独立 `@Test`。目标：单实体测试方法数 ≤ 35。
- **测试依赖（通用）**：`spring-boot-starter-test`（test scope，pom 已含）。

## 判定信号

- 生成 `<Entity>ServiceTest.java` → 标准骨架全条适用（命中率 ~100%）。
- 生成代码的测试注解组合与 `skeleton-conventions` `testAnnotations` 不一致 → 命中反例，按真值改。
- `contextLoad` 整类 Error → 检查注解组合是否与骨架一致（如骨架用 `@SpringBootTest` 却写了 `@DataJpaTest` 致跨域级联）。
- `Unable to find a @SpringBootConfiguration` → 多模块下 `@SpringBootTest` 测试类放错模块（落在业务模块而非启动模块 `bootModule.moduleDir`）：把测试类移到启动模块的 `src/test/java/<modulePackage>/`，package 不变。
- `@NullAndEmptySource` 对 `Long`/`Integer` 参数化注入 → 见 `[实现知识库目录对应路径]/backend-build/java-validation-return.md`（create vs update partial 的 blank 校验语义）。

## 反例（绝对禁止）

- 用了与骨架 `testAnnotations` 不一致的注解组合（骨架用整体 `@SpringBootTest` 却写切片注解、或骨架用 `@DataJpaTest` 却写 `@SpringBootTest`）——跨栈固化；
- 断言方式与 `failureStyle` 不一致（骨架 `return fail` 却断言 throw、骨架 `throw` 却断言 fail）；
- 臆测注解名/数据源（不在 skeleton-conventions 真值内）。

## 正确写法（示例：当 `testAnnotations` = `@SpringBootTest`+`@Transactional`、`failureStyle` = `return 信封.fail` 时，如 ruoyi 栈）

```java
// 注解组合取 skeleton-conventions.testAnnotations 真值；以下为整体 Spring 注解风格示例
@SpringBootTest
@Transactional
class UserServiceTest {
  @Autowired UserService service;
  @Test void create_nullName_shouldFail() {
    var dto = buildValidDTO(); dto.setName(null);
    var r = service.create(dto);
    assertFalse(r.isSuccess());           // failureStyle=return fail → 断言 fail；若 failureStyle=throw 则用 assertThrows
  }
  @ParameterizedTest @NullAndEmptySource
  void create_invalidName(String name) { ... }  // 参数化收敛（通用机械规则）
}
```

> 换 JPA 栈（如 ehs）时 `testAnnotations` 可能是 `@DataJpaTest`、`failureStyle` 可能是 `throw`，照 skeleton-conventions 真值写；本文示例仅 illustrative、不跨栈 mandate。
