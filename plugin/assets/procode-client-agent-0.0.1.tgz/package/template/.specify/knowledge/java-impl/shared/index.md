# shared 跨阶段共用 Java 约定

≥2 消费阶段引用的 Java 实现约定放本目录，避免在多处 prompt 重述（单一真理源）。

路径前缀：`[实现知识库目录对应路径]/shared/`（占位符会被框架替换为绝对路径）

## 分篇

### java-spring-bean.md —— Spring Bean 与测试注解
- 跨阶段：base-architecture（@MapperScan/启动类）+ backend-build（@Service/@Mapper/@Component 生成）+ backend-build-runner（@MapperScan/contextLoad 口径）+ 零跨实体铁律规则 4.9
- 触发关键词：@Service / @Mapper / @MapperScan / annotationClass / 启动类 / 双 bean / @Component / @SpringBootTest / contextLoad / No qualifying bean / 切片注解 / import / 找不到符号 / 泛型 / 文件名 / 类名 / ApiResponse / 跨实体 / 外键 / 跨域 / 存在性校验 / 外键 ID
- 覆盖错误：@Service/@Mapper 注解缺失、启动类 @MapperScan 裸包扫描致 Service 接口双 bean、切片注解误用、DTO/VO 文件类名与文件名不一致致级联整包失败、Service 接口缺 VO import、Test import 包路径与 Service 不一致、Service 返回类型缺泛型、跨实体外键存在性校验致跨域 import/注入编译/启动级联失败（零跨实体铁律）
- **判断**：base-arch 生成启动类时必读 @MapperScan 规则；backend-build 实体生成必读（命中率 ~100%）；DDL 有跨领域模块外键列时必读零跨实体铁律（规则 4.9）

### persistence-convention.md —— 持久层约定
- 跨阶段：plans/backend-design §1 + build/base-architecture pom 共用
- 权威结论：持久层风格/分页类/实体形态照 `skeleton-conventions.json` `mapperStyle`/`pageVo` 真实在用值（注解 SQL/JPA/XML 三选一，不 mandate 单一）；依赖边界照骨架在用栈；类名/注解不在此写死，详见该篇
- **判断**：Repository 生成 / pom 依赖裁定时必读

### test-annotation.md —— 测试注解约定
- 跨阶段：plans/backend-design §1 + build/backend 实体生成共用
- 权威结论：测试注解组合/数据源/失败断言照 `skeleton-conventions.json` `testAnnotations`/`testDataSource`/`failureStyle` 真实在用值（不 mandate 单一组合、不预设"直连 MySQL 弃 H2"等单栈假设）；信封类真名见 `responseEnvelope`；参数化收敛用 JUnit5 `@ParameterizedTest`（通用机械规则）；详见该篇
- **判断**：单测生成必读（命中率 ~100%）
