# 持久层约定（跨阶段共用：design §1 + base-arch pom）

本文件是持久层实现的单一真理源，plans/backend-design §1 与 build/base-architecture pom 依赖裁定均引此，不重述。

**类名/注解/风格不在此写死**：持久层风格、分页类的**真名+FQN** 一律取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `mapperStyle` / `pageVo`（设计阶段读骨架按角色判据发现的真实在用值）。本文只承载通用机械规则，具体类名/注解名以 skeleton-conventions 真名为准、禁造第二个、禁臆测。

## 权威结论

- **持久层风格照 `skeleton-conventions.json` `mapperStyle` 真实在用值**（注解 SQL / JPA `extends JpaRepository` / XML 三选一）——逐字用其真实注解/基类，不在本文 mandate 单一风格。骨架用 `@Mapper`+注解 SQL 则照用、用 `JpaRepository` 则照用、用 XML 则照用。
- **分页照 `pageVo` 真实在用类与机制**：分页包装类取 `pageVo` 真名+FQN（可能为 `PageVO`/`TableDataInfo`/`Page<T>` 等），分页机制照骨架在用（`LIMIT offset` / `PageHelper` 等），不预设。
- **实体形态照 `mapperStyle`**：当 `mapperStyle` 为注解 SQL / XML 时，实体为贫血 POJO（无 ORM 注解）；当 `mapperStyle` 为 JPA 时，实体照骨架在用 JPA 注解（`@Entity`/`@Table`/`@Id` 等）。即实体注解风格跟随骨架，不在本文写死。
- **依赖边界照骨架**：pom 依赖以骨架实际在用为准（骨架用 MyBatis 则不引 JPA starter、骨架用 JPA 则引 JPA starter），具体 starter 清单见 `[实现知识库目录对应路径]/base-architecture/pom-dependencies.md`，不在此跨栈 mandate。

## 判定信号

- Repository 生成 → 风格/注解/基类照 `mapperStyle` 真值，分页照 `pageVo` 真值；
- pom 依赖裁定时 → 以骨架在用栈为准（见 pom-dependencies.md）；
- 生成代码的注解/基类与 `skeleton-conventions` `mapperStyle` 不一致 → 命中反例，按 skeleton-conventions 真名改正。

## 反例（绝对禁止）

- 生成代码用了与骨架 `mapperStyle` 不一致的风格（骨架用注解 SQL 却生成 `extends JpaRepository`、或骨架用 JPA 却生成 `@Mapper`）——跨栈固化；
- 臆测类名/注解名（骨架信封/分页/Mapper 基类不叫本文示例名却照抄示例名）——造第二个；
- 造第二个信封/分页类（骨架已有却新建一份）。

## 正确写法（示例：当 `mapperStyle` = 注解 SQL 时，如 ruoyi MyBatis 栈）

```java
// 注解与类名取 skeleton-conventions.mapperStyle 真值；以下为注解 SQL 风格示例
@Mapper
public interface UserMapper {
  @Select("SELECT * FROM user WHERE id = #{id}")
  User selectById(Long id);
}
// 实体：贫血 POJO（注解 SQL/XML 风格下无 ORM 注解；JPA 风格则照骨架加 JPA 注解）
public class User { private Long id; private String name; ... }
```

> 换 JPA 栈（如 ehs）时 `mapperStyle=JpaRepository`，Repository 照 `extends JpaRepository` 写、实体照 JPA 注解写；换 XML 栈时照 XML 写。具体以 skeleton-conventions 真值为准，本文示例仅 illustrative、不跨栈 mandate。
