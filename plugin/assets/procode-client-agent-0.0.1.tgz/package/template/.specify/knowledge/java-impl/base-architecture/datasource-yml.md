# 数据源 yml 配置（base-architecture 阶段 + build yml 校验）

本文件是 `application.yml` 的 `spring.datasource` 配置单一真理源，build/base-architecture 生成 yml 与 build/backend 阶段二 yml 校验均引此，不重述。

**方言真值**：`databaseType` 唯一权威源 = tech-stack.json `database`。连接与回环坐标唯一来源 = 已确认数据源契约条目（经 `datasource-tool.mjs resolve --name <dataSourceName>` 读取；本地派生连接配置产物已退役，不读、不写）。写法按选型分 MySQL/PG 两段 + Oracle 最小段，**禁用默认族写法覆盖异族选型**（postgresql 选型写出 mysql url/driver=命中反例；oracle 选型写出 mysql url/driver 同判反例——字典缺行族无机械门兜底，本文件反例行是唯一防线）。其余非字典方言：无机械判据，按该方言标准写法生成，终局实建+启动仲裁。

## 权威结论

- **真实值写死**：生成 `application.yml` 的 `spring.datasource` 时，**必须**从 `[大纲目录对应路径]/backend/_meta/datasource-binding.json` 取 `dataSourceName`，执行 `node .specify/scripts/javascript/datasource-tool.mjs resolve --name <dataSourceName>` 读取契约条目的 `host/port（回环坐标）/database/username/password`，把真实值写死进 `url/username/password/driver-class-name`。**禁止保留 `${DB_HOST:127.0.0.1}` 等占位符**。
- **url 格式按方言分叉**：
  - MySQL（`databaseType` 为 mysql 形态）：`jdbc:mysql://<host>:<port>/<database>?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true`。
  - PG（`databaseType` 为 postgresql 形态）：`jdbc:postgresql://<host>:<port>/<database>`。**无 serverTimezone/useSSL/allowPublicKeyRetrieval 等 MySQL 专属参数**；schemaName 固定 `public`（建表/探测 SQL 均在 public 下）。
  - Oracle 最小行（`databaseType` 为 oracle 形态）：`jdbc:oracle:thin:@//<host>:<port>/<service_name>`（service 形态）。**无 serverTimezone/useSSL/allowPublicKeyRetrieval 等 MySQL 专属参数**；驱动坐标见 pom-dependencies.md Oracle 行。
- **driver 按方言分叉**：MySQL=`com.mysql.cj.jdbc.Driver`；PG=`org.postgresql.Driver`；Oracle=`oracle.jdbc.OracleDriver`。
- **契约条目缺失 / 不可 resolve** → **fail-loud 中止并上报**：binding 缺席、条目未命中、回环映射缺失均属上游产物缺陷；**禁止**用 `127.0.0.1` / `3306` / `project_<appName>` / `root` 等默认值兜底，也不臆测新族。
- **`--data-source-name` 一律显式传**，值逐字来自 binding envelope / 契约条目 `dataSourceName`；CLI 不再有「省略回退默认条目」形态，臆造 `project_<appName>` 会让 DDL 归档到错误的 `sql/<name>/scheme` 目录。
- **值冲突禁自修**：yml 值与 datasource 契约条目（真值）冲突时，**只修 yml 侧、上报 checkerFeedback，禁止改契约条目或 tech-stack 对齐 yml**（真值侧写入由编排器独占，见 build prompt 禁写条款）。
- **禁改范围**：禁止修改 `application.yml` 中 datasource 以外的配置段。

## 判定信号

- 生成 `application.yml`（base-arch）→ 全条适用。
- yml 出现 `${DB_HOST}` / `${DB_PORT}` 占位符 → 命中反例，用契约条目 resolve 出的真实值替换。
- MySQL 选型 url 缺 `serverTimezone=Asia/Shanghai` → MySQL 8 时区报错，补全参数；**PG 选型 url 带 MySQL 专属参数同判为反例**，删。
- 选型与自报家门不符（postgresql 选型出现 `jdbc:mysql:` / `com.mysql.cj`，反之亦然）→ 命中反例，按方言真值改 yml（yml/pom 方言判定另有 D7 引擎机械比对门兜底）。oracle 选型出现 `jdbc:mysql:` / `com.mysql.cj`（或反之：mysql 选型出现 `jdbc:oracle:` / `oracle.jdbc`）→ **同判反例**——字典缺行族无机械比对门兜底，本文件是唯一防线，按 Oracle 最小段改写。
- 阶段二 yml 校验任务 → 真值取 **datasource 契约条目**（六字段，含 databaseType），只修 yml 对齐契约，**禁改真值侧**；值冲突上报 checkerFeedback，禁自修绕过。

## 反例（绝对禁止）

```yaml
spring:
  datasource:
    url: jdbc:mysql://${DB_HOST:127.0.0.1}:${DB_PORT:3306}/${DB_NAME:project_app}  # ❌ 占位符
    username: ${DB_USER:root}
    password: ${DB_PASS:root}
```

```yaml
# ❌ PG 选型（databaseType=postgresql）却写 MySQL 形态：url 前缀、driver、参数全错
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:5432/project_app?serverTimezone=Asia/Shanghai
    driver-class-name: com.mysql.cj.jdbc.Driver
```

```yaml
# ❌ Oracle 选型（databaseType=oracle）却写 MySQL 形态：url 前缀、driver 全错（0921 事故形态；
#    oracle 无字典行=无机械门兜底，命中本反例即唯一防线，按 Oracle 最小段改写）
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:1521/project_app?serverTimezone=Asia/Shanghai
    driver-class-name: com.mysql.cj.jdbc.Driver
```

## 正确写法

MySQL（`databaseType`=mysql 形态）：

```yaml
spring:
  datasource:
    url: jdbc:mysql://127.0.0.1:3306/project_app?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
```

PG（`databaseType`=postgresql 形态）：

```yaml
spring:
  datasource:
    url: jdbc:postgresql://127.0.0.1:3000/project_app
    username: root
    password: root
    driver-class-name: org.postgresql.Driver
```

Oracle 最小段（`databaseType`=oracle 形态）：

```yaml
spring:
  datasource:
    url: jdbc:oracle:thin:@//127.0.0.1:1521/orcl
    username: root
    password: root
    driver-class-name: oracle.jdbc.OracleDriver
```
