# pom 依赖清单（base-architecture 阶段）

本文件是后端 `pom.xml` 依赖裁定的单一真理源，build/base-architecture 生成 `pom.xml` 时引此，不重述。换技术栈则按 `<stack>-impl/base-architecture/` 对应文件（Python→pyproject.toml 依赖、Node→package.json 依赖）。

**持久层裁决两分支（2026-09-14 基线 plan；裁决序=基线恒赢）**：
- **greenfield**：持久层事实由装配脚本按冻结基线（tech-stack.json `backend.persistence` 原文）+ 统一栈 profile 矩阵派生，已落 `skeleton-conventions.json` `mapperStyle`（`persistenceStarter` 即权威坐标、note 逐字含基线选型原文）——照 `mapperStyle.persistenceStarter` 引用，**禁照抄任何模板/骨架残余、禁把「MyBatis Plus」降级成裸 MyBatis starter**；
- **存量**：持久层以**骨架 `pom.xml` 实际在用**为准（骨架用 MyBatis 则保留 MyBatis starter、不引 JPA；骨架用 JPA 则保留 JPA starter），不跨栈 mandate 唯一栈。

下文 starter 清单与"正确写法"是 **Java 21/Boot 3.x + MyBatis 线 illustrative**，换线/换持久层照矩阵替换，不照抄本文清单。具体持久层栈取 `skeleton-conventions.json` `mapperStyle`。

**多模块 Maven 工程（不重写/摊平骨架模块结构）**：骨架已有含父 POM 的多模块结构时（根 pom `packaging=pom` 仅聚合、各子模块各有子 pom，**按骨架实际模块名**，不预设 `ruoyi-admin`/`ruoyi-system` 等单 app 模块名），base-architecture 只**增改各子模块 `pom.xml` 依赖**使其含权威结论所需 starter（如业务模块子 pom 加 `mybatis-spring-boot-starter`、`bootModule` 指向的启动模块子 pom 加 `spring-boot-starter-test`），**禁重写骨架父 POM、禁摊平为单模块**；本文"正确写法"的单 `<dependencies>` 块是单模块 illustrative，多模块照骨架在用各子模块 pom 增改。单模块骨架才整体生成单 pom。多模块定位读 `skeleton-conventions.json` `bootModule`（moduleDir/fqn）。

## 权威结论

- **核心 starter 清单（compile，Boot 3.x + MyBatis 线 illustrative）**：`spring-boot-starter-web`、`spring-boot-starter-validation`、`spring-boot-starter-security`、`spring-boot-starter-actuator`、持久层 starter（照 `mapperStyle.persistenceStarter`，见下方持久层坐标矩阵）、数据库驱动（runtime scope，**由 base-architecture agent 按下方驱动表生成——装配骨架不预置任何数据库驱动**，D6 0921 拍板，本表即生成侧事实唯一驻地）、`lombok`、`jjwt`。
- **测试依赖（test scope）**：`spring-boot-starter-test`。**不引 H2/内存库依赖**（`com.h2database:h2` 一律禁引）——测试在真实 app 数据源跑（`application.yml` 指向的库），按测隔离见 `[实现知识库目录对应路径]/shared/test-annotation.md`，避免内存库方言假绿。
- **持久层三态坐标（greenfield 照 `mapperStyle.persistenceStarter`；存量照骨架在用，不跨栈 mandate）**：
  - `MyBatis` → `org.mybatis.spring.boot:mybatis-spring-boot-starter`（**不受 Boot BOM 管理，须显式版本**，随线见矩阵）；
  - `MyBatis Plus` → Boot 3.x 线 `com.baomidou:mybatis-plus-spring-boot3-starter` / Boot 2.x 线 `com.baomidou:mybatis-plus-boot-starter`（**两线坐标不同**：Boot 3 线裸写 Boot 2 坐标=构件解析不到/运行期 NoSuchClassError；同样不受 BOM 管理，须显式版本）；
  - `JPA` → `org.springframework.boot:spring-boot-starter-data-jpa`（Boot 自有 starter，parent BOM 管理版本，禁写显式版本号）。
  - 选型与 mapperStyle 风格真值见 `[实现知识库目录对应路径]/shared/persistence-convention.md`（持久层风格照 mapperStyle 真值，实体形态/分页随之）。

### Spring Boot 大版本 × 依赖坐标矩阵（plan 2026-09-08/java8-backend-generation-support；2026-09-14 基线 plan 扩 MyBatis Plus 行）

权威源 = `tech-stack.json` 冻结基线 `frameworkVersion`（矩阵配对见 `config/shared/stack-profile.ts`——全链唯一版本字面驻地：Java 21 线 → Boot 3.5.15、Java 8 线 → Boot 2.7.18；增量读存量 pom）。**坐标随大版本换，禁混用**：

| 依赖 | Boot 3.x（Java 21 线） | Boot 2.x（Java 8 线） |
| --- | --- | --- |
| mybatis 持久层 starter | `mybatis-spring-boot-starter` **3.0.4** | `mybatis-spring-boot-starter` **2.3.2**（3.x 只配 Boot 3，Boot 2 下运行期 `NoSuchClassError`） |
| MyBatis Plus 持久层 starter | `mybatis-plus-spring-boot3-starter` **3.5.5** | `mybatis-plus-boot-starter` **3.5.3**（Boot 3 线专属 spring-boot3 变体，两线禁互写） |
| JPA starter | `spring-boot-starter-data-jpa`（BOM 管理） | 同左 |
| MySQL 驱动 | `com.mysql:mysql-connector-j` **8.0.33** | `mysql:mysql-connector-java` **8.0.33**（`mysql-connector-j` 坐标是 Boot 3 线改名产物，Boot 2 pom 写它=解析不到构件） |
| PG 驱动 | `org.postgresql:postgresql`（两线同坐标，parent BOM 管理，禁写显式版本） | 同左 |
| Oracle 驱动（最小行） | `com.oracle.database.jdbc:ojdbc8`（两线同坐标，parent BOM 管理）；driverClass=`oracle.jdbc.OracleDriver` | 同左 |
| SQLServer 驱动（最小行） | `com.microsoft.sqlserver:mssql-jdbc`（两线同坐标，parent BOM 管理）；driverClass=`com.microsoft.sqlserver.jdbc.SQLServerDriver` | 同左 |
| Servlet/Validation API 包名 | `jakarta.servlet` / `jakarta.validation` | `javax.servlet` / `javax.validation` |
| jjwt（登录底座按需引入：台账 `login-required=需要登录` 时由登录任务加进对应子 pom；parent BOM 不管理，引入须显式版本。**装配出厂不含**——登录可插拔，不预置登录依赖） | **0.11.5** | **0.11.5**（同版兼容两线，禁 0.12.x 混入 SB2 线——API 包名 `jjwt.api` 拆分自 0.12 起） |

Spring Boot 各 starter 与 `spring-boot-starter-test` 版本由 parent BOM 管理，装配 pom 已锁 parent，不需显式版本号；上表坐标/版本差异是唯一需要随线切换的点。

**数据库类型事实口径（0921 rev3）**：`databaseType` 权威源 = tech-stack.json `database`（唯一事实源；本地派生连接配置产物已退役）。驱动坐标按选型从上表取行，**禁默认族兜底**（postgresql 选型写 mysql-connector=命中反例；方言不符另有 D7 机械比对门兜底）。oracle/sqlserver 知识层给足坐标+驱动类（生成侧不缺事实、不预拒）；其执行链（sql-exec 客户端/方言 DDL/设计侧门）暂缺=该层显式红「事实缺口」，不在生成层拦截。

## 判定信号

- 生成/增改 `pom.xml` → 全条适用（持久层照 `mapperStyle.persistenceStarter`；存量 starter 清单照骨架在用栈替换）。
- 基线 `persistence`="MyBatis Plus" 而 pom 出现裸 `mybatis-spring-boot-starter` → **命中反例（jinqucode 0914 实证病）**，按坐标矩阵换 MyBatis Plus 对应线 starter。
- `mapperStyle` 为 MyBatis 系时 pom 出现 `spring-boot-starter-data-jpa` / `hibernate-*` → 命中反例，删该依赖；`mapperStyle` 为 JPA 时则反之（MyBatis 系 starter 为反例）。以 mapperStyle 真值/骨架在用栈为准。
- 缺 `spring-boot-starter-test`（test）→ 单测无法编译，补 test scope 依赖。
- 驱动未标 runtime → 改 runtime scope（连接池运行期才需；JPA 栈照骨架 driver 替换）。
- 驱动坐标与选型不符（postgresql 选型写 mysql-connector，或反之）→ 命中反例，按驱动表选型行换坐标。
- 驱动依赖缺位（装配骨架不预置驱动，D6）→ 按驱动表补对应选型行，禁省略（运行期 `No suitable driver`/连不上库）。
- **Boot 2.x（Java 8 线）pom 出现 `com.mysql:mysql-connector-j` 或 mybatis 系 starter 3.x 版本 → 命中反例**，按版本矩阵换 `mysql:mysql-connector-java` / mybatis starter 2.3.2（反之 Boot 3.x 出现 `mysql-connector-java` 或 `mybatis-plus-boot-starter`（非 spring-boot3 变体）同判）。

## 反例（绝对禁止——以 mapperStyle 真值/骨架在用栈为准，以下为 `mapperStyle`=MyBatis 线示例）

```xml
<!-- ❌ 当 mapperStyle=MyBatis 系时：误引 JPA starter（与持久层栈不一致） -->
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<!-- ❌ 禁引 h2 测试库（测试在真实库跑，不引入 H2 方言假绿） -->
<dependency>
  <groupId>com.h2database</groupId>
  <artifactId>h2</artifactId>
  <scope>test</scope>
</dependency>
<!-- ❌ 基线选型 MyBatis Plus（Boot 3.x 线）时：降级裸 MyBatis starter（jinqucode 0914 实证病） -->
<dependency>
  <groupId>org.mybatis.spring.boot</groupId>
  <artifactId>mybatis-spring-boot-starter</artifactId>
</dependency>
```

> 当 `mapperStyle`=JPA 时，本文"正确写法"的 MyBatis 系 starter 换成 JPA starter、反例反过来（MyBatis 系 starter 为反例），照 mapperStyle 真值/骨架在用栈为准，不跨栈 mandate。

## 正确写法（Boot 3.x / Java 21 线 + MyBatis illustrative；持久层照 mapperStyle.persistenceStarter 替换、换线按上方版本矩阵换坐标与显式版本，其余相同）

```xml
<dependencies>
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
  </dependency>
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
  </dependency>
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
  </dependency>
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
  </dependency>
  <dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>3.0.4</version>
  </dependency>
  <dependency>
    <groupId>com.mysql</groupId>
    <artifactId>mysql-connector-j</artifactId>
    <version>8.0.33</version>
    <scope>runtime</scope>
  </dependency>
  <dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
  </dependency>
  <dependency>
    <groupId>io.jsonwebtoken</groupId>
    <artifactId>jjwt</artifactId>
  </dependency>
  <dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-test</artifactId>
    <scope>test</scope>
  </dependency>
</dependencies>
```
