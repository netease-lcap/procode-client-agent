# 查询、去重与 Stream 常识

本篇覆盖 list 查询、去重、Stream 链式的常见错误。实体有 list 查询或唯一性检查才读。

**类名不在此写死**：本文示例中的 `ApiResponse`/`ErrorCode` 是 ruoyi 栈 illustrative 名。信封类/错误码类的**真名+FQN** 取 `[大纲目录对应路径]/backend/_meta/skeleton-conventions.json` 的 `responseEnvelope` / `errorCode`，失败处理方式以 `failureStyle` 真值为准。换栈照真名替换示例中的类名；机械规则（Stream 一次链成、去重维度照 DDL UNIQUE、Integer 不用 int）通用保留。

## 规则 5.1：Stream 链式调用必须一次链成，禁止中间变量重赋值

- **何时触发**：list 方法里用 Stream filter 过滤查询结果
- **错误现象**：filter 没生效，返回了未过滤的全量结果，test 断言 list 大小失败
- **根因**：filter 结果赋给中间变量再 reassign，链断了；或 filter 的 lambda 条件写错（如 Integer 参数被 MyBatis 短路返回了 null）
- **正确写法**：一次链式完成，不要拆成中间变量
  ```java
  List<VO> result = list.stream()
      .filter(x -> x.getStatus() != null && x.getStatus().equals("ACTIVE"))
      .map(this::toVO)
      .collect(Collectors.toList());
  ```
- **反例**：
  ```java
  Stream<Entity> stream = list.stream();
  stream.filter(x -> x.getStatus().equals("ACTIVE")); // filter 结果丢了，没赋值回 stream
  List<VO> result = stream.map(this::toVO).collect(Collectors.toList()); // 全量返回
  ```

## 规则 5.2：去重维度必须以 DDL UNIQUE 约束为准

- **何时触发**：唯一性检查/查重逻辑，或 list 结果去重
- **错误现象**：test 用三元组（project, name, type）查重，impl 只查二元组（project, name），导致不同 type 的同名被误拒；或在二元组/三元组之间振荡反复改不收敛
- **根因**：去重维度与 DDL 的 UNIQUE 约束不符，impl 凭猜测定维度
- **正确写法**：先读 DDL 确认 UNIQUE 约束的维度组合，impl 按该维度去重
  ```java
  // DDL 是 UNIQUE(project_id, name, type)，按三元组查重
  Entity exist = mapper.selectByProjectIdAndNameAndType(projectId, name, type);
  if (exist != null) {
      return ApiResponse.fail(ErrorCode.CONFLICT, "已存在");
  }
  ```
- **反例**：只按 (project, name) 二元组查重，忽略 type 维度；或按 name 单字段查重
- **注**：若在二元组/三元组间振荡，回到 DDL 确认 UNIQUE 约束维度，不要凭 test 断言反推

## 规则 5.3：list 查询参数用 Integer 不用 int，list 签名按 README §9

- **何时触发**：list 方法的查询参数，尤其可选筛选条件
- **错误现象**：MyBatis 对 int 类型 null 参数短路，查询条件失效；或 list 签名与 README §9 不符
- **根因**：int 是基本类型不能为 null，null 筛选条件传不进来；MyBatis dynamic SQL 对 int 参数处理异常
- **正确写法**：查询参数用 Integer（允许 null=不筛选），list 签名统一为 list(QueryDTO query)
  ```java
  // QueryDTO 里的筛选字段用 Integer
  public class UserQueryDTO {
      private Integer status; // null 表示不筛选
      private Integer page;
      private Integer pageSize;
  }
  public ApiResponse<List<UserVO>> list(UserQueryDTO query) { ... }
  ```
- **反例**：
  ```java
  public ApiResponse<List<UserVO>> list(int status) { ... } // int 不能 null，无法表达"不筛选"
  ```
- **注**：list 签名详见 backend/README.md §9.3，分页参数封装进 QueryDTO 的 page/pageSize
