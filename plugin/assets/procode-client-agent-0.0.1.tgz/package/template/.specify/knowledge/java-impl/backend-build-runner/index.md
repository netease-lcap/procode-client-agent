# backend-build-runner 阶段实现约定（协调者运行时口径）

build/backend 协调者（编译/启动/单测三波修复）运行时口径——mvnd / surefire / @MapperScan / contextLoad 等诊断与验收口径。与 backend-build/ 的生成规则语义区分（生成 vs 运行时）。

路径前缀：`[实现知识库目录对应路径]/backend-build-runner/`（占位符会被框架替换为绝对路径）

## 分篇

### build-test-runner.md —— 协调者 Java 运行时诊断口径
- 仅承载 Java 栈特有的诊断命令、emit JSON 字段口径、常见根因信号与标准修法：编译波（段 B0）mvnd -q test-compile 诊断口径、`[ERROR] .../Xxx.java:[line,col]` 提取、Lombok 误判诊断顺序（先排查上游级联编译失败，禁推理注解处理器/缓存）、禁 clean；启动波（段 C0）check-backend-startup.mjs emit JSON 口径（startupErrors / applicationLog / surefireDir / contextLoadReportFiles / failureDetails）、No qualifying bean = impl 缺 @Service、BindingException、contextLoad 级联；单测波（段 B1）check-backend-test.mjs emit failureDetails 口径、surefire .txt 兜底、A 类（业务逻辑失败改 impl）/ B 类（test 数据 bug 改 test）分流、防振荡（同方法连续 2 轮失败切 B 类）、@NullAndEmptySource + partial update 标准修法、surefire 全绿但 mvn 退出码非 0 判绿口径
- **编排方法论（3 阶段模板/subAgent 派发四约束/≤4 并发/一次性全派/fix-history 写入）是栈中立，留在协调者 prompt 正文不载本文件**
- **判断**：协调者 prompt 生成时必读（Java 诊断口径）；换技术栈则按 `<stack>-impl/backend-build-runner/` 对应文件

## 跨阶段共用（协调者也读，在 shared/）

- `[实现知识库目录对应路径]/shared/java-spring-bean.md` —— 零跨实体铁律规则 4.9（subAgent 修复约束共用）
