# 存量表加列常识（ALTER ADD COLUMN 分支）

本篇覆盖 build entity-gen 读到 `entity-*.md` 形态为 `ALTER TABLE <存量表> ADD COLUMN`（ADD COLUMN 分支）时，就地改已有 entity + mapper 的常见写法错误。entity 形态为 ALTER ADD COLUMN 时必读。

**类名/表名/列名/包路径/方法 id 不在此写死**：本文规则体用 `<存量表>`（取自 `entity-*.md` ALTER DDL 的目标表名）、`<T>`（该表对应实体类名，表名 snake_case→PascalCase；多模块骨架取类名读 `skeleton-conventions.json` `bootModule.moduleDir` 下实际存量类文件名）、`<col>`（ALTER delta 的新列名）、`<T>Result`/`<selectVoId>`/`<selectListId>`/`<insertId>`/`<updateId>`（取自**存量 mapper 已有**的 resultMap id / sql id，读存量 `*Mapper.xml` 实际值，禁臆造）作占位。**包路径读 `skeleton-conventions.json` `bootModule`**（moduleDir/fqn，多模块骨架定位目标子模块；不硬编码 `com.ruoyi.*`/`ruoyi-common`/`ruoyi-system`——那是 ruoyi 单 app 的模块名，换 app 不存在）。Lombok 用否照骨架存量实体类在用风格判（见规则 2）。持久层风格照 `mapperStyle` 真值。下文以 ruoyi 栈 SysUser 加 `crm_ext` 列为 **illustrative 旁注**（`sys_user`→`SysUser`、`SysUserResult`/`selectUserVo`/`insertUser`/`updateUser` 是 ruoyi 存量 mapper 的真实 id），换 app 照真实 DDL/存量 mapper id 替换占位，机械规则通用照抄。

## 规则 0：适用边界——只改已有框架文件，不造新 entity/CRUD，索引走 delta*.sql 序号族

- **何时触发**：build entity-gen 读本实体 `entity-*.md`，顶部 DDL 为 `ALTER TABLE <存量表> ADD COLUMN <列> ...`（ADD COLUMN 分支）
- **正确做法**：本分支**就地外科式改已有的 entity + mapper**，把 ALTER delta 里的新列加进 `<T>.java` + 存量 `*Mapper.xml`（输出 backend 副本，非模板原件）；**不生成**新 entity/Repository/Service/CRUD/test/建表 SQL（这是与 CREATE 分支的本质区别——CREATE 造新文件，ADD COLUMN 改已有文件）；新列的索引/约束**走 `migration/delta*.sql` 序号族**（段 A 前已 `ALTER TABLE ... ADD INDEX/UNIQUE` 改库；单语句门禁配套拆分，每文件恰一条 ALTER），**不进 Java 代码**
- **反例**：为存量表新建第二份 `<T>` entity + 一整套 CRUD（与存量 `<T>` 双份映射同一张表，且等价于 CREATE 分支）；或把新列索引写进 Java 代码（索引是 DB 层，delta*.sql 序号族已建）
- **注**：本分支机制与 CREATE 同——技术栈代码生成由知识文档驱动，本篇即该机制承载处；分支差异在路由（改已有文件 vs 造新文件），不在机制

## 规则 1：按表名定位已有存量文件，禁臆造路径/新建第二份

- **何时触发**：进入 ADD COLUMN 分支，定位要改的 entity + mapper 文件
- **正确写法**：表名 snake_case → 类名 PascalCase（`sys_user`→`SysUser`、`sys_dept`→`SysDept`）；在输出 backend 源树 find 定位（**类名/包路径取自 entity-*.md + skeleton-conventions bootModule，禁臆造**）：
  - entity：`find . -name '<T>.java'`（多模块骨架按 `bootModule.moduleDir` 定位目标子模块；单模块骨架直接在根包下找）
  - mapper：`find . -name '<T>Mapper.xml'`（MyBatis XML 栈；注解 SQL 栈无 xml，改 `@Select`/`@Insert` 注解方法体）
  ```bash
  # 在输出 backend 根目录下；<T> 取自 entity-*.md 真实类名
  find . -name '<T>.java'
  find . -name '<T>Mapper.xml'
  ```
- **反例**：臆造路径 `com.company.app.entity.<T>`（app 侧无此包/类，存量类在骨架实际位置）；或 `new` 一份新 `<T>.java`（双份映射同一张表，contextLoad 类冲突）
- **注**：改的是输出 backend 的**副本**（build 从模板拷出来的那份），不是模板原件

## 规则 2：<T>.java 加字段 + getter/setter 照骨架存量实体风格（Lombok 用否不预设）

- **何时触发**：ALTER delta 含新列（如 `crm_ext VARCHAR(64)`，`<col>` 取自 entity-*.md 真实列名）
- **错误现象**：只加 `private String <colCamel>;` 不加 getter/setter → MyBatis 反射设值/取值失败，查询回显新列=null；或与存量实体风格冲突（存量手写 getter/setter 却对新列用 `@Data`，或存量用 `@Data` 却对新列手写）
- **根因**：存量 `<T>` 的字段写法由骨架决定（ruoyi 栈 SysUser 是手写 getter/setter 的 POJO extends BaseEntity 无 `@Data`；ehs 等栈实体带 `@Data`）。新列须照**同文件既有字段**风格加——存量带 `@Data` 则只加 field（Lombok 生成 accessors）；存量不带 `@Data` 则加 field + 手写 getter + setter。列名 snake_case → 属性 camelCase（`crm_ext`→`crmExt`）
- **正确写法（存量实体无 @Data，手写 getter/setter 时，如 ruoyi SysUser）**：
  ```java
  /** <列注释，取自 entity-*.md 字段表> */
  private String <colCamel>;

  public String get<ColPascal>()
  {
      return <colCamel>;
  }

  public void set<ColPascal>(String <colCamel>)
  {
      this.<colCamel> = <colCamel>;
  }
  ```
- **正确写法（存量实体带 @Data 时）**：只加 field，accessors 由 Lombok 生成：
  ```java
  /** <列注释> */
  private String <colCamel>;
  ```
- **反例**：
  ```java
  @Data // 与存量风格不一致（存量无 @Data 时强加，或存量有 @Data 时重复标注）
  private String <colCamel>; // 存量无 @Data 时漏 getter/setter → MyBatis 反射失败
  ```
- **注**：Lombok 用否照**骨架存量实体类在用风格**判（读 `<T>.java` 既有字段是否带 `@Data`/手写 getter/setter），不预设"框架不用 Lombok"——那是 ruoyi 单栈假设

## 规则 3：resultMap 加列映射（id 取自存量 mapper）

- **何时触发**：新列要在查询结果里回显（凡 select 走该 resultMap 都适用）
- **错误现象**：SQL select 了 `<col>` 但 resultMap 没映射 → `<T>.get<ColPascal>()` 返回 null（property 没被填）
- **根因**：MyBatis 按 resultMap 的 `<result>`/`<id>` 把列填到属性，漏映射的列不进对象
- **正确写法**：在存量 `<resultMap type="<T>" id="<T>Result">`（`<T>Result` 是 ruoyi 栈 SysUser 的 resultMap id；换 app 取存量 mapper 实际 id）内加一行（PK 用 `<id>`，普通列用 `<result>`）：
  ```xml
  <resultMap type="<T>" id="<T>Result">
      <id     property="<pkCamel>"     column="<pkCol>"          />
      ...
      <result property="<someCamel>"   column="<someCol>"         />
      <result property="<colCamel>"    column="<col>"             />
      <association property="..." ... />
  </resultMap>
  ```
- **反例**：只改 select 不改 resultMap → 查询 `<col>` 列查出来了但 `get<ColPascal>()` 还是 null

## 规则 4：共享列清单 sql 片段加新列（id 取自存量 mapper）

- **何时触发**：新列要在详情/登录回显（存量 mapper 有被多个详情型 select `<include>` 的共享列片段；ruoyi 栈为 `<sql id="selectUserVo">`，换 app 取存量实际 id）
- **错误现象**：详情/登录查询回显新列=null——只改了列表 select 没改共享列片段，而详情/登录 `<include>` 的是共享片段
- **根因**：共享列片段是被多个详情型 select `<include>` 的列清单，漏改它 = 所有走它的 select 都不查新列
- **正确写法**：在存量 `<sql id="<selectVoId>">`（`selectUserVo` 为 ruoyi 例）的列清单里加 `<表别名>.<col>`：
  ```xml
  <sql id="<selectVoId>">
      select u.<pkCol>, u.<col2>, ... , u.<someCol>, u.<col>,
      <联表列...> from <存量表> u ...
  </sql>
  ```
- **反例**：只改列表 select，详情/登录回显新列=null

## 规则 5：列表查询列清单加新列（id 取自存量 mapper）

- **何时触发**：新列要在列表查询里回显
- **错误现象**：列表查询不带新列 → 列表页 `get<ColPascal>()` 全 null
- **根因**：列表 select 有自己的列清单（不 `<include>` 共享列片段），漏改它列表就不查新列
- **正确写法**：在存量 `<select id="<selectListId>">`（`selectUserList` 为 ruoyi 例）的列清单里加 `<表别名>.<col>`
- **反例**：只改共享列片段，列表仍不带新列
- **注**：ruoyi 栈另有 `selectAllocatedList`/`selectUnallocatedList`（角色分配用户列表）也各有列清单，新列是否进这两条取决于业务是否需在角色分配页回显——默认不进（这两条只取分配相关列），除非需求明确要

## 规则 6：insert 的列清单 + values 双段都加新列（id 取自存量 mapper）

- **何时触发**：新列要能写入（create/insert 时落库该列）
- **错误现象**：`Column count doesn't match value count` SQL 错，或漏写列导致新列永远 null
- **根因**：存量 `<insert id="<insertId>">`（`insertUser` 为 ruoyi 例）的列段和 values 段都用 `<if test>` 动态拼，漏任一段 = 列/值不匹配；漏整条 = 新列不写入
- **正确写法**：列段与 values 段各加一条 `<if>`（字符串列照既有 `!= null and != ''` 风格，注意末尾逗号）：
  ```xml
  <insert id="<insertId>" parameterType="<T>" useGeneratedKeys="true" keyProperty="<pkCamel>">
    insert into <存量表>(
      ...
      <if test="<someCamel> != null and <someCamel> != ''"><someCol>,</if>
      <if test="<colCamel> != null and <colCamel> != ''"><col>,</if>
      <createTimeCol>
    )values(
      ...
      <if test="<someCamel> != null and <someCamel> != ''">#{<someCamel>},</if>
      <if test="<colCamel> != null and <colCamel> != ''">#{<colCamel>},</if>
      sysdate()
    )
  </insert>
  ```
- **反例**：只加列段 `<if><col>,</if>` 不加 values 段 → 列数 ≠ 值数，SQL 报错；或漏末尾逗号 → 与下一列拼连

## 规则 7：update 的 `<set>` 加 `<if>` 片段，末尾保留逗号（id 取自存量 mapper）

- **何时触发**：新列要能编辑（update 时改该列，partial update）
- **错误现象**：update 不带新列 → 编辑不生效；或漏逗号 → SQL 语法错列名粘连
- **根因**：存量 `<update id="<updateId>">`（`updateUser` 为 ruoyi 例）用 `<set>` 块内多条 `<if test="prop != null">col = #{prop},</if>`（partial update，null 表示不改），漏逗号或无条件 set 都会出错
- **正确写法**：在 `<set>` 内加 `<if>`（照既有风格，注意末尾逗号由 `<set>` 标签自动处理尾部逗号，但每条自身末尾逗号须有）：
  ```xml
  <update id="<updateId>" parameterType="<T>">
    update <存量表>
    <set>
      ...
      <if test="<someCamel> != null"><someCol> = #{<someCamel>},</if>
      <if test="<colCamel> != null"><col> = #{<colCamel>},</if>
      <updateTimeCol> = sysdate()
    </set>
    where <pkCol> = #{<pkCamel>}
  </update>
  ```
- **反例**：`<if test="<colCamel> != null"><col> = #{<colCamel>}</if>`（漏逗号，与下一行粘连带语法错）；或 `<col> = #{<colCamel>}` 无 `<if>`（null 也覆盖，partial update 语义被破坏）

## 规则 8：多新列 = 规则 2-7 逐列机械叠加

- **何时触发**：ALTER delta 含多条 ADD COLUMN
- **正确写法**：每列独立一套（field + getter/setter/`@Data`照存量 + resultMap + 共享列片段 + 列表 select + insert 列/values + update `<if>`），机械叠加，列与列之间无顺序依赖
- **反例**：试图复用一条 `<if>` 写多列（MyBatis 动态 SQL 不支持，必须每列独立 `<if>`）

## 自我审查

产出后逐条核对，缺一处即返工（漏改 = 运行时列错位/SQL 报错/回显 null）：

- [ ] `<T>.java` 加了 field + getter/setter（照存量实体风格：存量无 `@Data` 则手写、存量带 `@Data` 则只加 field），列名→属性名 snake→camel
- [ ] resultMap（id 取自存量 mapper）加了 `<result property column>`
- [ ] 共享列清单 sql 片段（id 取自存量 mapper）列清单加了 `<别名>.<新列>`
- [ ] 列表 select（id 取自存量 mapper）列清单加了 `<别名>.<新列>`
- [ ] insert（id 取自存量 mapper）列段 + values 段都加了 `<if>`（双段齐全、末尾逗号在）
- [ ] update（id 取自存量 mapper）`<set>` 加了 `<if>...= #{...},</if>`（末尾逗号在、null 不覆盖）
- [ ] 未生成新 entity/Repository/Service/CRUD/test/建表 SQL（ADD COLUMN 分支不造新文件）
- [ ] 新列索引/约束走 delta*.sql 序号族，未写进 Java
- [ ] 表名/列名/类名/包路径/sql id 全取自 entity-*.md 真实 DDL + 存量 mapper + skeleton-conventions（bootModule/mapperStyle），未臆造 `com.ruoyi`/`sys_user` 等 ruoyi 单栈 token
