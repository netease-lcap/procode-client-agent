# 架构语义规约（波 1：系统架构图）

本规约是**全项目通用**的架构契约撰写说明，不绑定任何形态、业务域或技术产品。
你（agent）是架构契约（`architecture.model.json` 候选）的**唯一作者**；校验、投影、渲染与落盘
由公共 tool 执行 —— 你**不写图**、**不写派生事实**、**不手改生成物**。

> 契约经由 tool 过 schema 与语义两道校验；**任一红都不产出发布包**。看到反馈就改契约再重跑，
> 不要为了过关反复改同一个字段，也不要绕过 tool 自己造 `architecture.json` / `architecture-overview.md`。

## 〇、先判失败性质：三类红，三种动作

反馈里的红**不是一回事**。先判性质，再选动作 —— 判错性质会把「要问人的事」当成「再改一遍」，
或把「照着决定落实」当成「无解」。

| 性质 | 判据 | 动作 |
|---|---|---|
| **可直接修候选** | 反馈已给出确定依据（点名服务/域重复认领、字段组合非法、证据引用不成立等） | 直接改候选，改完复跑 tool |
| **已确认但未落实** | 已有 `accepted` 决定（澄清答复 / 上游设计），候选尚未体现 | 按决定落实（见 §五 `ownedDomainIds`），复跑 tool |
| **缺业务决定** | 归属 / scope / 职责判断缺少只有用户能给的事实 | **结构化提问**：写成 `openQuestions`（带问题标识与候选），由执行层发起提问；不得用反复改字段或重试替代 |

- **未决 ≠ 可修**：前两类修完复跑即可；第三类必须先拿到用户决定，改字段只会制造「看起来已覆盖」的假绿。
- **未落实 ≠ 无解**：已有决定时这是**可修的落实动作**，不是缺决定 —— 不要重复提问，也不要提前放行。
- **终止只用于真实输入或环境故障**（输入材料缺失/不可读、tool 或环境不可用）。「当前默认业务规则
  满足不了某个域」通常属于「缺业务决定」，不是阶段已无可处理。

输入（background 注入）：需求原文（`specs/pieces`）、`plans/domain.json` 的 `domains[]`、
`tech-stack.json` 的 `form` / `formEvidence` / `cloudStack`。这些是**证据**，不是模型字段 ——
不得把它们原样抄进候选 JSON。

## 一、对象识别：按职责判，不按名称/产品猜

七类 `kind` 与本期的合法 `role`（`LEGAL_ROLES_BY_NODE_KIND`，语义校验逐条判组合合法性）：

| 要找什么 | 判据（它在这个系统里**承担什么职责**） | 落点 |
|---|---|---|
| 参与者 | 发起业务的人 / 角色 / 外部组织（不是软件） | `kind: actor` + `role: client` |
| 应用入口 | 用户直接使用的界面载体 | `kind: frontend` + `role: client` |
| 内置网关（默认接入承载） | 部署在本应用内、承担**入口收口 / 路由 / 限流 / 协议适配**的网关组件 | `kind: application-component` + `role: integration` |
| BFF（点名 BFF 时取代内置网关） | 部署在本应用内、面向前端的聚合 / 会话定制组件（**只聚合调用，不承载域**） | `kind: application-component` + `role: access` |
| 外部网关（点名接入外部网关时） | 外部既有 API 网关实例，本项目不构建 | `kind: external-system` + `role: integration` + `coverage[]` 标记 |
| 业务服务 | 承载一个业务域、可独立说明职责的服务 | `kind: service` + `role: business` |
| 数据资源 | 被读写的数据存储（库 / 缓存 / 对象存储中承载业务数据的那个） | `kind: datastore` + `role: data` |
| 中间件与基础设施 | 消息、注册发现、配置中心、网关设备等运行支撑 | `kind: infrastructure` + `role: access`/`data`/`integration` |
| 外部既有系统 | 不在本系统内、需对接的既有平台 | `kind: external-system` + `role: integration` |

**`kind` 与 `role` 都按职责判**：名字里出现某个产品名（前端框架、网关产品、消息产品）**不构成**
归类依据 —— 同一个产品在不同项目里可以是不同职责。判断依据不足时写进 `openQuestions`，不要猜。
这属于「缺业务决定」（§〇 第三类）：必须走结构化提问，不要靠换字段试错或反复重跑 tool 碰运气。

**`role` 是必填**（schema `required`）。理由不是形式主义：`service` / `application-component` /
`infrastructure` 的合法角色不止一个，role 缺席时投影判不出职责矩阵，这条交互的流量类别只能落
「未判定」⇒ 图上没有线型、图退化。**判不出职责就落 unresolved，不要随便挑一个 role 填满**。

`name` 必填（人类可读的展示名，本期不收外部权威引用 `ref`）；`responsibility` 写这个对象**承担的职责**，
不是写它用了什么技术。

## 二、交互识别：需求里出现的关系都要有落点

四类 `kind`（按**语义分类**，不按实现猜）：

- 请求-响应 ⇒ `sync-request`（**恰 1 个 target**）；
- 事件通知 ⇒ `async-notification`（可有多个 target，每个目标都要能被追溯）；
- 读写数据 ⇒ `data-access`（**必填 `access: read | write | read-write`**；**恰 1 个 target**）；
- **只知有依赖、机制未定** ⇒ `dependency` + 非空 `questionIds`（**不得**把未定的关系写成某种技术调用）。

纪律：

- 逐条读已注入的需求与证据，**每一处范围内的「A 与 B 有关系」都要有结论**：要么建一条交互，
  要么在 `coverage` 里说明为何不建。**对象齐全不代表关系已覆盖**。
- 对承担鉴权、转发、聚合或协议适配的组件，逐项核对**请求来自谁、处理后交给谁、职责由哪些交互承载**。
  **鉴权依赖不能代替业务请求转发**；不能从组件名称、两个节点同时存在、或职责文字猜出连接。
- 一个来源可以有多条交互（同一对节点之间也可以有多条，不要按节点对去重）。
- 反向关系（结果回传、审批回传）是**独立交互**，不是把原边反过来画。
- 没有证据要求的组件或关系**不补画**；不为「凑通路」把所有服务连起来。

## 三、证据与依据：`evidenceRefs` / `basis`

- `evidenceRefs`（**必填、≥1 条**）：`{sourceId, locator:{kind: json-pointer|text|code, value}, note?}`。
  `sourceId` 必须是本轮**注入的**来源标识；`locator` 要可定位（指针 / 文本锚 / 代码位置）。
- `basis` 区分 `requirement | decision | observation | inference`：
  - `requirement`：需求原文直接要求；
  - `decision`：已定决策（澄清答复 / 上游设计）；
  - `observation`：在给定材料里**看到的**（静态依赖只证明代码或配置里的关系，不证明运行中的真实调用）；
  - `inference`：**你的推断 —— 必须同时给非空 `reason`**（schema 的 `if/then` 会判）。
- 「引用可定位」只证明**出处存在**，不证明推断成立。关键不确定点关联到 `openQuestions`，
  不要用语法层面的反复重试替代人工业务决定。未决项必须落成带问题标识的结构化提问（§〇 第三类）：
  用 `inference` 硬填或反复改 `evidenceRefs` 都不算解决。

## 四、`coverage`：逐项交代，不是写一句「已覆盖」

`coverage` 是本次输入与扫描范围的**逐项**交代，粒度细到「一条需求条目 / 一个业务域 / 一个外部平台」
各自一行。写「全部业务领域已覆盖」这种粗条目等于没交代 —— 它没法让人核对少了什么。

- `represented`：**必须**给 `nodeIds` **或** `interactionIds`（≥1）——**节点在场 ≠ 关系在场**。
  关系性需求（「A 调用 B」「下单后通知用户」）必须逐条引用对应的 `interactionIds`；
  只给 `nodeIds`、只靠职责文字、或笼统的「链路已覆盖」**不能**证明关系覆盖。
- `out-of-scope`：写清 `reason`（为什么不画）。
- `unresolved`：**必须**挂 `questionIds`（未决必须落成可回答的 `openQuestion`，否则缺口无人接）。
  出现未决即属「缺业务决定」：走结构化提问（§〇），不得用反复改字段、补 `inference` 或重试 tool 替代。
- **自查方法**：把输入里的条目数与你 coverage 的行数对一下；行数明显少于条目数，说明有东西没交代。

## 五、`ownedDomainIds` 与 `contractRef` 的填报纪律

### `ownedDomainIds`（D11 / D12：域 → 模块映射即实体绑定真值；默认规则 + 已确认认领决定）

- **默认规则只约束「没有有效认领决定的域」**：这类域必须被**恰一个** `role: 'business'` 的节点认领 ——
  0 个（不豁免）与 ≥2 个都是红；一个域只归一个模块，一个模块可以拥有多个域。
- **已确认的认领决定优先于默认规则**：某个域已有有效且仍适用的认领决定时，按决定给出的 `ownerNodeId`
  与 `ownershipScope` 判定 —— **不再**因该节点不是 business 而报红，也**不再**把这个域算成无人认领。
  决定可以落在 `frontend` / `client` 这类非 business 节点上（典型：界面工作台认领一个域）：
  **该节点的 kind / role 是已确认事实，原样保留 —— 不要为了过校验把前端改成 service / business**。
- **两种归属不可混用**：
  - `ownershipScope: view`（视图归属）只进入架构图与域对照表，**不产生**后端模块、实体或数据库绑定；
  - `ownershipScope: module` **必须指向 `role: business` 的后端模块**；view / frontend / 网关 / BFF
    （`access` / `integration`）**不产生**后端模块、实体或数据库绑定，**不得**为它们写 `ownedDomainIds`
    （连「引用域」也不写——没有 common 豁免，非 business 节点声明域一律判红）。
- **决定只在模型落实后生效**：owner 节点必须在自己的 `ownedDomainIds` 里**保留**该域。未落实 ⇒ 报
  「已确认归属未落实」，修法是**在该节点上保留域** —— **不要**改成 service / business、**不要**删除该域、
  **不要**把某个域的决定扩大解释到其它域（例如 BFF 的域不因工作台的决定而放行）。
- **未落实与未决要分开**：已确认归属未落实是**可修的落实动作**——拿到的决定就是修复目标，不重复提问；
  归属/scope 本身缺少业务决定才是**未决**，走结构化提问（§〇）。两者都不许用「删域 / 改 role / 重跑」蒙混。
- **落实后必须复验**：改完候选要复跑同一 tool 与 checker；只报「已修」而不复跑，等于把未落实说成通过。
- 取值必须来自 `plans/domain.json` 的 `domains[]`，**逐字符照抄**（精确匹配：不做 trim、不做大小写
  或前缀归一 —— `Order-Management` 与 `order-management` 是两个域）。
- 你**不写**实体文件、不写绑定投影：实体归属由 tool 按这张表推导（`view` 归属不推导后端实体 / 模块绑定）。
- **粒度两级兜底（硬约束；只约束没有已确认认领决定的域）**：
  **第一优先**——需求原文里**点名**的服务/域必须**逐个**落成独立 `business` 节点（点名几个就落几个节点）；
  **兜底**——需求原文未点名时，`plans/domain.json` 的每个域（**不论 `type`**）至少对应一个**独立**
  `business` 节点；没有现成业务服务承载时，必须新增 `<domainId>-service`
  （`kind: service`, `role: business`）。已确认 `view` 归属的域**不因本条**额外造 `business` 节点
  （决定优先，该域后续按 `view` 口径消费）。
  上一条「一个模块可以拥有多个域」是**技术上允许**、不是**默认做法**：它只在下面这条成立时才可用。
- **反静默合并**：任何「多个域合进一个 `business` 节点」（或把多个点名服务并进一个节点），
  都必须带依据——在 `coverage[]` 里逐条交代「凭什么合」，或落成 `openQuestions[]` 里的待裁决问题
  （附 `reason`）。确认环的三列对照表会把「多域合节点」**逐行高亮**交人裁决：机器不替你判断「合得对不对」，
  但一条没说凭什么合的合并，在人工确认前就是欠交代的。
- **落库承载（硬约束；只约束 `role: business` 且 `ownedDomainIds` 非空的节点）**：
  每个这样的节点必须至少有一条 `kind: "data-access"`、`access` 为 `write` 或 `read-write`、
  `targets` 指向**已有** `kind: "datastore"` 节点的交互。只有 `access: "read"` 的边**不算**承载
  （只读边不证明该域会落库）。补边时**复用模型里已有的 datastore 节点，禁新建 datastore 节点**——
  库粒度判据含「`kind: "datastore"` 节点数 N ≥ 2 ⇒ per-module」，新建会让 `tech-stack.database`、
  `datasource-binding`、`database-design.md` 全部推翻。接入组件（`role: integration` 的网关 /
  `role: access` 的 BFF）不受本条约束。

### `contractRef`（D16：服务间契约的单一权威载体）

- 形态 `{providerModuleId, docPath, anchor}`（三键必填、不得增键）。`docPath` **只有三种合法形态**
  （封闭白名单，**波 1 构建期就判红**），指向提供方契约文档的接口段 / 事件 schema 段：
  business 提供方 ⇒ `backend/modules/<providerModuleId>/tech-design.md`（模块文档由**波 5**产出）；
  **external 提供方 ⇒ `backend/mock/<providerModuleId>.md` 或 `backend/third-party/<providerModuleId>.md`**
  （外部系统契约由**集成专家**产出——**不产外部系统的模块文档**）。
  两处硬约束：`providerModuleId` 必须是模型 `nodes[]` 里真实存在的节点 id 原样（拼错即红），
  且形态与提供方身份相符（business 只许 modules，external-system 只许 mock / third-party）；
  `docPath` **禁带 `plans/` 前缀**（解析基目录本身就是 `plans/`，带前缀会被解析成 `plans/plans/...`）。
- **谁必填**：`sync-request` / `async-notification` **且端点跨模块** ⇒ 必填。
- **谁不得有**：`data-access` / `dependency` 上出现 `contractRef` ⇒ 红（这两类是模块内访问/依赖，
  没有跨模块契约可指）。
- 不另造登记文件：指向的 `docPath` / `anchor` 稍后由模块设计文档补齐；**不要**在这里转录接口正文。

## 六、其余口径

- **未决项在有真实可选方案时要带候选**：`openQuestions[].options` 列 1–6 条互斥、覆盖真实分支的候选，
  写清「选它意味着什么」；**不写**「其他 / 待定 / 稍后决定」这类不是候选的占位。没有可选方案不必给
  `options`（自由输入始终可用）。
- **视图与分组**：只声明必要的视图与有业务依据的分组（`views[].groups`）；**不声明**坐标、颜色、
  subgraph 的渲染 ID 或手工显示边 —— 那些由渲染器生成。视图列出的每条 interaction，其 source 与
  所有 targets 都应在同一视图的 `nodeIds` 里（否则端点会落在视图之外）。
  - **画框只认 `groups`**：`boundaries` 只表达归属与内外部语义，**不会**自动生成分组框；
    要视觉分组，必须在该视图的 `groups[]` 里声明。
  - 字段形态：`{id, name, parentId?, nodeIds[]}`。`nodeIds` 必须是本视图 `nodeIds` 的**子集**；
    嵌套只靠 `parentId`（父组可以没有直属节点，只要后代有成员就会被保留）；同一节点只写一次
    （重复归属时渲染取最内层）。
  - **overview 视图的默认形态（有分层依据时照此分组）**：
    ① 外部系统单独一框（`external-system` 节点）；
    ② 内部平台一个容器组（不挂直属节点），下挂需求/技术栈里声明的分层，典型是
       「接入层（actor + frontend）→ 网关（integration）→ 微服务层（business）→ 集成与数据层（integration + datastore）」；
       需求点名 BFF 时，接入层内为 BFF（access）聚合（BFF 取代内置网关，二者不并存）。
       层名用业务语言，不要拿 `kind` / `role` 字面量当组名。
  - **有业务依据才分组**：不为了凑框把节点塞进不成立的层；无法归类的留在容器直属并在 `coverage[]`
    交代依据。分组只影响展示，不改变交互、流量分类与任何校验结论。
- **`flows`**：多段业务链路按实际语义用 `links` 显式关联并记 `reason`；`flow.links.reason` 的文字
  **不能代替**缺失的 interaction。
- **修复边界**：修复只针对契约本身。**不手工修改**由 tool 生成的 `architecture.json` 与
  `architecture-overview.md`（它们由图与表同源生成，手改必然与契约漂移）。
- **修复后必须复跑原检查**：改完契约要重跑同一 tool / checker，复跑通过才算落实。用户回答了问题
  **不等于**验收通过 —— 回答只是输入，决定仍要在模型里落实并通过复跑。

## 七、派生事实禁入模型（写进去就是红）

以下都**由投影从模型 + 域清单导出**，一律**不进**候选模型（schema 全层 `additionalProperties: false`，
语义层另有键名判据）：

- **流量类别**（南北向 / 东西向 / 外部）：按职责矩阵判、**条件不足不猜**（落 notClassified ⇒ 红）；
  你只需把 `kind` / `role` / `boundaryId` 这些**输入事实**写对，类别由 tool 判，**禁直填**。
- **已解析名称**（`resolved*`）：由名称解析生成。
- **渲染 ID**（`renderId`）、以及任何 `traffic*` / `resolved*` / `renderId` 形态的键。
- **交互索引**、**发布包字段**（`schemaVersion` 之外的 `metadata` / `projection`）。

## 八、明确不写进本规约的内容

- **不写「必须有某组件」**：注册中心 / 配置中心 / 消息队列这类组件由当前需求决定，没有结构性必选；
  **例外 = 微服务接入网关**：micro 架构按产品默认**必备**一个接入承载（默认内置网关；需求点名 BFF 或
  外部网关时按点名的形态），fresh run 缺承载即判红。推荐与取舍走后续澄清波，本轮只如实识别对象与关系。
- 不写具体业务名称或产品名；它们是否出现应由当前需求决定。
- 不写「图可以省略」「用静态图替代」这类降级口径 —— 图由程序从契约生成，是必交付材料。