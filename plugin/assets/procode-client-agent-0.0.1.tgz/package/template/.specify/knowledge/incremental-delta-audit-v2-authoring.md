# 增量 Delta v2 · Audit 产出规范（独立 audit agent）

> **权威源**：仓库 `docs/hicode-spec/incremental-delta-audit-v2-authoring.md`。
> **部署副本**：`template/.specify/knowledge/incremental-delta-audit-v2-authoring.md`（随 `.specify`
> 部署到 workspace，audit agent 实际读取该副本）。修改任一文件后必须同步另一处，否则 agent 读到旧规范。

> 适用：`buildIncrementalDeltaChain` 中的 **audit phase**。
> 权威契约：`shared/database/delta-audit.ts`（P0）+ plan
> `docs/hicode-spec/plan/2026-11-06/incremental-delta-v2-sql-success-mechanical-merge-and-audit.md` §5.5/§8。
> 本文是 audit agent 的写作规范；checker 只校验结构，不替代本文。

## 1. 目的与边界

audit 是**独立旁路**：把「本轮每个对象最终怎么处理」写成可审计条目，供 Gate D 与人工复核。
它不生成 SQL、不改 operations、不补片段、不裁决业务语义。

- **唯一写面**：`backend/migration/delta-audit.json`。
- **只读输入**：manifest（紧凑事实，优先读它）、operations v2、片段 v2、retained-tables、post-delta、inventory。
  **不要读整份 `code-schema.json`**（体积过大）：表名/身份已由 manifest 解析好，基线身份只读 manifest 的 compact 字段。
- 禁止修改：`operations.json`、`migration/_fragments/*.json`、任何 `*.sql`、`code-schema.json`、
  `post-delta.json`、`retained-tables.json`；禁止连库、执行 SQL、扩 kind 词表、改 checker。

## 2. 输入 / 输出路径

| 角色 | 路径（相对 `<spec>/plans/backend/`） |
| --- | --- |
| 输入清单（脚本产物，只搬运事实） | `migration/_meta/delta-audit-input.json` |
| operations v2（唯一 SQL 真源） | `migration/operations.json` |
| 单表片段 v2 | `migration/_fragments/*.json` |
| 基线 schema v2 | `_meta/code-schema.json` |
| retained 登记 | `_meta/retained-tables.json` |
| pre-delta 分类（可缺） | `migration/post-delta.json` |
| codeOnly 决策（可缺） | `_meta/code-table-inventory.json` |
| **audit 产出** | `migration/delta-audit.json` |

manifest 只搬运事实（operations/片段/retained/post-delta/inventory + baseline-only 身份），
**不包含分类判断**。分类由 audit agent 依据 operations/片段事实写出。

## 3. 三类 classification × gapClass（固定映射）

| classification | 含义 | 允许的 gapClass |
| --- | --- | --- |
| `operation` | 有可执行 SQL 的机械 operation（含新表 create 延迟） | **只能 `G0`** |
| `unsupported` | 语义/不可解析变更，落 `operations.unsupported[]` | **`G1`–`G8`** |
| `skip` | 结构上明确无 operation/SQL | **只能 `G9`** |

- `G9` 只允许出现在 `classification:"skip"`；operation/unsupported 写 G9 一律红。
- 不要发明 `classification:"gap"`（v1 概念已删除）。

## 4. changeKind 词表

operation（`SQL_OPERATION_KINDS`，6 种，closed）：

```
add-column | add-index | add-unique | create-table | create-index | add-comment
```

unsupported（`UNSUPPORTED_CHANGE_KINDS`，5 种，closed）：

```
drop-column | modify-column | add-primary-key | unparseable-alter | unparseable
```

`state` 只允许：`pending | accepted-manual | design-applied | withdrawn`。
`unsupported` 的 `changeKind/requested/state/decisionRefs/manualMigration` 必须从
`operations.unsupported[]` **原样搬运**，不重写、不翻译、不省略。

## 5. items[] 必填字段矩阵

### 5.1 普通 operation（有 actionId）

| 字段 | 要求 |
| --- | --- |
| `classification` | `"operation"` |
| `gapClass` | `"G0"` |
| `actionId` | operations 中真实存在的 actionId |
| `sourceId` / `objectId` | 非空，且在 code-schema 中可解析 |
| `table` | 非空；从基线对象或 operations 事实取 |
| `column` | 字符串；表级变更写 `""` |
| `changeKind` | `= operations[].kind`（6 种之一） |
| `reason` | 简述为何是该 operation |
| `evidenceRef` | 可复核依据（片段/设计/基线列），无则省略或空串 |

### 5.2 新表 create（延迟到 post-delta）

| 字段 | 要求 |
| --- | --- |
| `classification` | `"operation"` |
| `gapClass` | `"G0"` |
| `changeKind` | `"create-table"` |
| `deferredTo` | `"post-delta"`（必填） |
| `table` | 非空 |
| `actionId` | 可选（新表可尚未有 operation） |
| `sourceId` / `objectId` | 可空；若写必须为字符串 |
| `column` | 可省略；若写必须是字符串 |

新表 create 不要求 actionId，但必须是 `changeKind:"create-table"` + `deferredTo:"post-delta"`；
反过来，`deferredTo:"post-delta"` 也只能配 `create-table`。

### 5.3 unsupported

| 字段 | 要求 |
| --- | --- |
| `classification` | `"unsupported"` |
| `gapClass` | `G1`–`G8` 之一 |
| `unsupportedKey` | 与 `operations.unsupported[].unsupportedKey` 逐字一致 |
| `sourceId` / `objectId` | 非空且可解析 |
| `table` | 非空 |
| `column` | 字符串；表级变更写 `""` |
| `changeKind` | 5 种 unsupported kind 之一 |
| `requested` | 非空，原样搬运 |
| `state` | 4 态之一，原样搬运 |
| `decisionRefs` | 字符串数组，原样搬运 |
| `manualMigration` | 可选字符串，原样搬运（`state:"accepted-manual"` 的承接条件） |

### 5.4 skip（`gapClass:"G9"`）

公共：`classification:"skip"`、`gapClass:"G9"`、`skipReason`、非空 `table`。

| skipReason | 何时用 | sourceId/objectId |
| --- | --- | --- |
| `retained-unchanged` | 该表按设计/基线保持不动（片段 class=retained，或 retained-tables 登记） | 非空 |
| `baseline-only` | 基线中存在、但本轮设计范围与 retained 都不涉及 | 可空（能写则写） |
| `no-operation-sql-produced` | 设计范围内，但本轮明确没有 operation/SQL（例如仅 unsupported 或空变更） | 非空 |

**skip 不表示语义审核通过**。它只表示「没有可执行产物」。不得用 skip 掩盖：

- 片段/operations/SQL 读不到、不可解析；
- 片段缺 operations 条目、statement kind 非法、unsupported 缺字段、create/alter 无 SQL；
- post-delta 分类与片段/operations 不一致。

以上属于**结构异常**，不产 audit item；在回复中报告 producer（`single-table` / `merge`），
由 checker 判红。

## 6. 最小 JSON 示例（每类一条）

文档头（所有 class 共用）：

```json
{
  "schemaVersion": 2,
  "iterationId": "incremental-20261106-120000",
  "inputRevision": "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
  "baselineRef": {
    "path": "backend/_meta/code-schema.json",
    "schemaVersion": 2,
    "sourceIds": ["main"]
  },
  "dialectBySource": { "main": "mysql" },
  "unsupportedDialects": [],
  "items": []
}
```

普通 operation：

```json
{
  "classification": "operation",
  "gapClass": "G0",
  "actionId": "existing-delta:main:user:add-column:001",
  "sourceId": "main",
  "objectId": "tbl-user",
  "table": "user",
  "column": "nickname",
  "changeKind": "add-column",
  "reason": "设计新增 nickname 列，机械可执行。",
  "evidenceRef": "backend/entity-user.md#L42"
}
```

新表 create（延迟）：

```json
{
  "classification": "operation",
  "gapClass": "G0",
  "changeKind": "create-table",
  "deferredTo": "post-delta",
  "table": "audit_log",
  "sourceId": "main",
  "objectId": "",
  "column": "",
  "reason": "inventory 决策 create，建表由 post-delta 承接。"
}
```

unsupported：

```json
{
  "classification": "unsupported",
  "gapClass": "G5",
  "unsupportedKey": "main:tbl-user:user:legacy_flag:drop-column",
  "sourceId": "main",
  "objectId": "tbl-user",
  "table": "user",
  "column": "legacy_flag",
  "changeKind": "drop-column",
  "requested": "删除遗留标记列 legacy_flag",
  "state": "pending",
  "decisionRefs": [],
  "reason": "删除列不自动生成 SQL，需人工确认。"
}
```

skip：

```json
{
  "classification": "skip",
  "gapClass": "G9",
  "skipReason": "baseline-only",
  "sourceId": "main",
  "objectId": "tbl-order",
  "table": "order",
  "reason": "基线既有表，本轮设计与 retained 均未涉及。"
}
```

## 7. checker 只校验什么

checker（`createDeltaAuditChecker`）只做**结构校验**：

1. `schemaVersion === 2`；`iterationId`/`inputRevision` 与 operations 同值；`baselineRef`
   path/schemaVersion/sourceIds 与 code-schema 一致，且**不带 digest**。
2. 按 classification 的必填字段/类型/枚举。
3. classification → gapClass 固定映射；G9 仅 skip。
4. 覆盖：每个普通 operation、每条 unsupported、retained/baseline-only/无产物表、新表 create。
5. 引用完整性：actionId/unsupportedKey 存在且不重复；身份可解析；`diffKey`（若写）唯一。
6. operation item 的 `operations[].sql.digest` 与 SQL 文件字节一致。
7. 五类结构异常判红并点名 producer，不要求 audit item：
   - 片段 unsupported 在 operations.unsupported[] 中缺失；
   - statement kind 不在 6 种 closed kind 内；
   - unsupported 缺 `changeKind`/`requested`/`state`；
   - create/alter 无 statement/SQL（或 SQL 缺失/为空）；
   - post-delta 分类与片段/operations 不一致。

checker **不校验**：分类语义是否正确、`requested` 是否忠实、SQL 语义、operation vs unsupported
的业务判断、G1–G8 的具体档位选择。这些由人工评审负责。

## 8. 禁止字段

audit 文档与 item **不得出现**：

```
before | after | objectDigest | designDigest | baselineRef.digest | resolvesDiffKeys
```

`diffKey` 只是可选的报告派生字段：若写，必须全局唯一，且不参与 join（join 只认
`actionId` / `unsupportedKey`）。

## 9. 失败恢复入口

- **audit checker 失败（schema / 覆盖 / 引用 / SQL 摘要）**：只修 `delta-audit.json`，重跑 audit
  phase。不要改 operations/片段/SQL 来迁就 audit。
- **结构异常（checker 报 `producer`）**：
  - `producer: "single-table"` → 回对应单表 phase（`DeltaDerivationTablePhase:<slug>`）修片段与 SQL；
  - `producer: "merge"` → 回 `DeltaDerivationMergePhase` 修 operations/post-delta/retained；
    若片段缺 unsupported 条目，先回单表阶段。
- **inputRevision 不一致**：上游输入已重新生成，必须重跑 merge → manifest → audit → Gate D。
- 任何情况下都**禁止**手改 Gate D MJS、改 checker 阈值、或把结构异常写成 skip 放行。
