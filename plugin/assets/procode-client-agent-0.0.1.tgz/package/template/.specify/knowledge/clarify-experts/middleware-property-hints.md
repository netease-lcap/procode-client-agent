# 中间件属性提案约定与字段提示表（propertyProposal 唯一约定源）

> 适用面：middleware 专家①选型阶段，为中间件类型设计 `propertyProposal`（动态表单的字段清单）。
> 按类型归属分三条通道（**禁跨道**）：
> 1. **redis（标准族）禁带**——表单由契约层 `family-templates` 预置，你的 selection 里**禁带** `propertyProposal`；
> 2. **矩阵族（rabbitmq / nacos / gateway / config-center）可携「补充段」**——只登记矩阵基线字段
>    基线项（`rabbitmq` = `username`/`password`/`virtual-host`；`nacos`/`gateway`/`config-center` = `username`/`password`）**未覆盖**的项；键**禁与该族矩阵基线键重键**
>    （重键 = 非法提案，组 checker 会红）；
> 3. **其余类型（kafka / rocketmq / elasticsearch / mongodb / …）走完整提案**（本文件的常规对象）。
> 三条通道共同硬约束：**禁发 form 问询、禁写连接值、禁写条目 JSON**。
> 机器对偶 = `middleware-family-matrix.ts` 的 `validatePropertyProposal`（结构校验门）；
> 校验失败会在组 checker 红停时逐条透出，按提示修正后改 selection 重跑即可。
>
> **`gateway` 族口径（plan 2026-10-30/micro-builtin-gateway-default-carrier §3.5）**：gateway 族只登记
> **外部已存在实例**。内置网关（`application-component + role=integration`）/ BFF（`application-component + role=access`）
> 已由架构承载时，**不写 gateway 条目**（空 `selections` 合法；即使写 `gateway:none` 也不得抑制 D8 `inAppIngress`
> 的 ingress 组件推导）。仅当需求点名接入**外部网关**（架构节点 `external-system + role=integration`）时才登记该族，
> 且 `moduleId` **必填** = 外部网关节点 id（取架构契约摘要的「接入承载」清单，禁自造）。

## 一、propertyProposal 是什么

你在**中间件选型记录**里给出的 `propertyProposal`（`selections[i].propertyProposal` 数组）——你为该中间件类型设计的
**连接配置表单字段清单**（完整提案，或矩阵族的**补充段**，见 §首）。工作流会把它确定性拼装进契约条目
（端点形态与矩阵段由基座拼装，你的 proposal 作属性段）并下发动态表单让用户填写，答案按 `key` 回填。
你只设计字段（schema），**不写连接值、不写条目 JSON、不发 form 问询**
（既有硬约束不变；连接值由用户经表单提供，存量值可放进 `prefill` 同名键）。

## 二、字段形状（每项）

```json
{ "key": "username", "name": "用户名", "required": false, "inputType": "text",
  "order": 10, "lineRegion": "half", "value": null, "placeholder": "可选" }
```

| 字段 | 约束 |
|---|---|
| `key` | 非空、匹配 `^[a-z][a-z0-9-]*$`、数组内唯一、**不得侵占端点展开键**（host / port / scheme / masterName / nodes / endPoint / bucketName / pathStyleAccess / mapped / targets）、**不得与该族矩阵基线键重键**（矩阵族补充段场景：rabbitmq = username/password/virtual-host，nacos/gateway/config-center = username/password；重键 = 非法提案，机器按注册表基线项判） |
| `key` 命名语义 | **key = build 消费时宿主栈配置键的后缀段**（Java 栈示例：`username` → `spring.<前缀>.username`；其它栈取对应配置键形态）。禁括号/点号/下划线 |
| `name` | 非空中文显示名 |
| `inputType` | `text` / `textarea` / `number` / `password` / `select` 五选一（`boolean` 是端点展开专用，属性项不可用） |
| 密码类 | key 含 password / secret / credential（大小写不敏感）→ **必须** `inputType:"password"` |
| `select` | 必须带非空 `selectValues: [{name, value}]`（字符串对） |
| `order` | 正整数，建议 ≥10（动态区，排在端点固定区之后） |
| `lineRegion` | `whole` / `half` |
| `value` | `null`（未填）或 string/number；`number` 项只接受 number/null |
| 数量 | 全部提案项 **≤ 12** |

## 三、部署形态（有无集群形态 + 集群额外字段提示）

**形态判定归 ① 选型 agent**：依据需求输入 + 本表 + 你的类型知识，判断该中间件**有无集群形态**；
有 → 先弹模式选择（单机 / 集群，`multiSelect`=false），并落 `variant`（`standalone` / `cluster`；
redis 另有 `sentinel`）。本表**提示非强制**——未列出的类型按类型知识自行判断，拿不准走 §五 兜底。

| 类型 | 有无集群形态 | 集群额外字段提示 |
|---|---|---|
| nacos | 有（集群部署） | `namespace`（命名空间）、`group`（分组，缺省 `DEFAULT_GROUP`）——**补充段**（`username`/`password` 属矩阵基线，禁重键） |
| gateway | 有（外部网关多实例 / 网关集群） | 按外部网关实现补（如 `namespace`/`group`）；无额外项则补充段留空——**补充段**（内置网关 / BFF 承载时不登记 gateway 条目） |
| config-center | 有（集群部署） | 同 nacos 形态（`namespace` / `group`）——**补充段** |
| rabbitmq | 有（集群 / 镜像队列） | 通常无额外必填（`username`/`password`/`virtual-host` 属矩阵基线，禁重键）——**补充段** |
| kafka | 有（多 broker 即集群） | 多 broker 地址走**端点区节点列表**（见下「端点收集归属」）；通常无额外字段 |
| elasticsearch | 天然集群（多节点） | **无需表单差异**（地址形态不变）；如需显式多节点，同走端点区节点列表 |
| mongodb | 有（副本集 / 分片） | `auth-source`（缺省 `admin`）等按需——**完整提案** |
| redis | 有（集群 / Sentinel） | **标准族**——表单由契约层 `family-templates` 预置，**禁带 proposal**（见 §首） |
| 其它 | 按类型知识判断 | 见 §四 字段提示与 §五 兜底 |

**集群形态的端点收集归属（节点列表不进 proposal）**：

- cluster 形态下**节点列表属端点区**——由 ① 的节点问询收集用户输入，基座拼装
  `endpoint.nodes[i] = { host, port }`，**不进 `propertyProposal`**；
- **proposal 的 key 禁侵占端点展开键**（`host` / `port` / `scheme` / `masterName` / `nodes` /
  `endPoint` / `bucketName` / `pathStyleAccess` / `mapped` / `targets`），**也禁数组下标形态**
  （`nodes[0]` 一类含 `[` / `.`，被 key 正则 `^[a-z][a-z0-9-]*$` 拦下）。

**端口纪律（节点端口以用户提供为准）**：

- **新族不带默认端口**：集群节点端口**以用户提供为准、必须显式提供**；
- 契约层 `resolveDefaultPort` 对 `role=cluster` 的**缺 port 节点会无条件按 6379 补齐**
  （redis 系专属表，与新族类型名无关）⇒ **新族省掉端口的节点会以 6379 落盘，属错误数据**——
  机制不会替你把关，不会报缺项；
- 因此**必须在节点问询里拿到用户显式 `host:port`**；用户未给端口 → 按「未提供」如实记台账
  并按 §五 兜底，**禁自造端口、禁默认靠 6379 兜底**。

## 四、已知类型字段提示表（提示非强制，可按类型知识增删）

| 类型 | 提示字段（key 建议） | 备注 |
|---|---|---|
| rocketmq | `name-server`（NameServer 地址）、`producer-group`、`consumer-group` | host/port 走端点区（prefill.host/port），不进提案 |
| kafka | `bootstrap-servers` 之外通常无额外必填；按需 `sasl-mechanism`、`security-protocol` | 多 broker 走**集群形态** → 端点区节点列表（`nodes[i].host` / `nodes[i].port`，见 §三）；单机形态沿用端点区原口径（地址并入端点项，非节点列表） |
| elasticsearch | `username`、`password` | scheme（http/https）走端点区 scheme 下拉 |
| mongodb | `username`、`password`、`auth-source`（缺省 admin） | host/port 走端点区（副本集 / 分片形态见 §三） |
| nacos | `namespace`、`group`（**补充段**；`username`/`password` 属矩阵基线，禁重键） | 集群形态见 §三 |
| gateway | 按外部网关实现补 `namespace` / `group` 等（无则补充段留空） | 仅外部网关承载时登记（`moduleId` 必填 = 外部节点 id）；内置网关 / BFF 承载不写条目；集群形态见 §三 |
| config-center | `namespace`、`group`（**补充段**） | 集群形态见 §三 |
| rabbitmq | 通常无补充项（`username`/`password`/`virtual-host` 属矩阵基线，禁重键） | 集群 / 镜像队列形态见 §三 |
| 其它 | 按该中间件官方连接参数梳理；拿不准的字段宁缺勿错，校验失败会逐条透出 | |

`required` 判断口径：缺了就**连不上**的字段才 `true`（如 ES 的 username 视部署而定，缺省 false）；
语义可选的一律 `false`，让用户留空跳过。

## 五、无把握时的兜底

注入文件缺失、类型陌生、字段拿不准 → 该类型**不要硬造提案**：selection 里记
`variant:"unsupported"`（如实透出诉求），走人工裁决。硬造非法提案只会红停重跑，不会更快。
