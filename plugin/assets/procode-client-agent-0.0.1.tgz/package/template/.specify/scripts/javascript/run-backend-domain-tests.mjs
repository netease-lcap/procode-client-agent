#!/usr/bin/env node

/**
 * 段 B1｜单域单测批量自检脚本（供每域修复 agent 使用）。
 *
 * 解决的问题：修复 agent 实测用 for 循环逐类跑 `mvn test -Dtest="...$testClass"`，
 * 每次独立 JVM + 一次 Spring 上下文启动（实测单次间隔 30-60s、平均 58.7s；workshop 域约 100 次
 * 去重调用 ≈ 40 分钟空转）。本脚本一次 `mvn test` 跑完本域全部测试类（同一 surefire fork
 * 复用 Spring 上下文），只统计本域 surefire 报告（前缀过滤，忽略其它域陈旧 .txt），输出紧凑 JSON。
 *
 * 用法：
 *   node .specify/scripts/javascript/run-backend-domain-tests.mjs <domain> [--focus=<FQN>#<method>]
 *       domain 与 test-buckets.json 的 domains key 一致（workshop / auth / common/system 等）。
 *       exit 0 = 本域绿（无编译错、无 contextLoad、Failures=Errors=0）。
 *       --focus=<FQN>#<method> 聚焦单方法（仍一次 Spring 启动，只跑一个方法）。
 *   node .specify/scripts/javascript/run-backend-domain-tests.mjs --help
 *
 * 输出 JSON：{ ok, domain, domainPkg, cmd, compileError, contextLoadIssue, totals, classes, noTestsMatched, advice, summary }
 */

import { existsSync, readdirSync, readFileSync } from 'fs';
import { resolve, basename, relative, dirname, sep } from 'path';
import { spawnSync, execSync } from 'child_process';
import { parsePomJavaMajor, parseJavaVersionOutput } from './shared/java-version.mjs';
import {
  findBackendDir,
  findPlanBackendDir,
  resolveDeclaredBackendRoots,
  resolveProjectRoot,
  resolveRootPackage,
  parseDomainModuleMap,
} from './shared/backend-common.mjs';

const cwd = process.cwd();
const args = process.argv.slice(2);

if (args.includes('--help')) {
  console.log(
    [
      'run-backend-domain-tests.mjs — 一次 mvn test 跑完本域全部测试类（复用 Spring 上下文）',
      '',
      '用法：',
      '  node .specify/scripts/javascript/run-backend-domain-tests.mjs <domain> [--focus=<FQN>#<method>]',
      '    domain          与 test-buckets.json 的 domains key 一致（workshop / auth / common/system）。',
      '    --focus=<FQN>#<method>  聚焦单方法（如 com.company.<appName>.workshop.HazardSourceServiceTest#update）。',
      '  node .specify/scripts/javascript/run-backend-domain-tests.mjs --help',
      '',
      '退出码：0=本域绿；1=有编译错 / contextLoad / 测试失败 / 用法错误。',
    ].join('\n')
  );
  process.exit(0);
}

const DEBUG_HINT =
  '只能调 run-backend-domain-tests.mjs（--focus=<FQN>#<method> 调单方法）；裸 mvn test/mvnw test 一律禁止。' +
  '所有测试失败信息已在此 JSON 的 classes[].failures[] 中完整给出（含方法名+错误消息+断言值）；' +
  '禁止再 glob/read/grep surefire XML 或原始 Maven 输出——那些信息不会比本 JSON 更多。';

function emit(ok, payload) {
  console.log(JSON.stringify({ ok, debugHint: DEBUG_HINT, ...payload }, null, 2));
  process.exit(ok ? 0 : 1);
}

/** 读 `--backend-root`（可重复）/ `--active-spec-dir`；未知/缺值忽略。 */
function collectRootArgs(argv) {
  const explicitRoots = [];
  let activeSpecDir;
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === '--backend-root') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) explicitRoots.push(resolve(value));
    } else if (argv[i] === '--active-spec-dir') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) activeSpecDir = resolve(value);
    }
  }
  return { explicitRoots, activeSpecDir };
}

/** 单根直接采用；多根只认声明里本身是其余所有根祖先的聚合根，否则无法唯一确定（null）。 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/** 代码根定位（D5）：声明/显式根优先；findBackendDir 仅兜底并打 warning；歧义不猜。 */
function resolveBackendRoot() {
  const baseRoot = resolveProjectRoot(cwd) ?? cwd;
  const { explicitRoots, activeSpecDir } = collectRootArgs(args);
  // 未显式传 --active-spec-dir 时由最新 plans/backend 反推 active spec 目录，使工程方案声明生效。
  const planBackendDir = findPlanBackendDir(cwd);
  // planBackendDir = <activeSpecDir>/plans/backend ⇒ activeSpecDir 需再上溯一层（plans 的父目录）。
  const specDir = activeSpecDir ?? (planBackendDir ? dirname(dirname(planBackendDir)) : undefined);
  const declared = resolveDeclaredBackendRoots({ activeSpecDir: specDir, rootDir: baseRoot, explicitRoots });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[run-backend-domain-tests] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[run-backend-domain-tests] 代码根存在多个且无声明聚合根，无法唯一确定：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root，或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[run-backend-domain-tests] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(cwd);
  if (legacy) console.warn(`[run-backend-domain-tests] 未找到代码根声明，回落启发式 findBackendDir：${legacy}`);
  return legacy;
}

const focus = args.find((a) => a.startsWith('--focus='))?.slice('--focus='.length);
const domainArg = args.find((a) => !a.startsWith('--'));
if (!domainArg) {
  emit(false, { failures: ['用法：node run-backend-domain-tests.mjs <domain> [--focus=<FQN>#<method>]（--help 查看详情）'] });
}

// ── 自动解析项目所需 JDK 的 JAVA_HOME（与 check-backend-test.mjs 同源） ──────────
// 消除「agent 用 JDK21 修绿 → 本脚本用默认 JDK8 跑 mvn 报文本块 illegal character 假编译错」死锁。

function resolveJavaHome(backendDir) {
  let javaVersion = null;
  const pomPath = resolve(backendDir, 'pom.xml');
  if (existsSync(pomPath)) {
    try {
      const pom = readFileSync(pomPath, 'utf-8');
      // 归一在 shared/java-version.mjs 单点实现（1.8→8；旧 (\d+) 解析不到 "1.8" 致回退系统 JAVA_HOME）。
      javaVersion = parsePomJavaMajor(pom);
    } catch { /* ignore */ }
  }
  if (!javaVersion) return null;
  const envCandidates = [
    process.env[`JAVA_${javaVersion}_HOME`],   // JAVA_21_HOME
    process.env[`JAVA${javaVersion}_HOME`],    // JAVA21_HOME
    process.env.JAVA_HOME,
  ].filter(Boolean);
  for (const home of envCandidates) {
    if (!existsSync(resolve(home, 'bin', 'java'))) continue;
    try {
      const verOut = execSync(`"${resolve(home, 'bin', 'java')}" -version 2>&1`, {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5000,
      });
      if (parseJavaVersionOutput(verOut) === javaVersion) return home;
    } catch { /* 跳过该候选 */ }
  }
  const jvmRoot = '/usr/lib/jvm';
  if (existsSync(jvmRoot)) {
    try {
      const dirs = readdirSync(jvmRoot);
      const found = dirs.find((n) => n.startsWith(`temurin-${javaVersion}`));
      if (found) return resolve(jvmRoot, found);
    } catch { /* ignore */ }
  }
  return null;
}

// 1. 定位后端工程 + 根包（声明根优先，findBackendDir 仅兜底）
const backendDir = resolveBackendRoot();
if (!backendDir) {
  emit(false, { failures: ['未找到后端工程（pom.xml / build.gradle）：cwd=' + cwd] });
}
const javaHome = resolveJavaHome(backendDir);
const root = resolveRootPackage(backendDir, cwd);

// 域 key → 包：优先从 README §9.2 映射表查 modulePackage；
// 映射缺失 → 直接报错退出（不静默兜底拼不存在的包跑 0 tests）。
const domainModuleMap = parseDomainModuleMap(cwd);
if (!domainModuleMap.has(domainArg)) {
  emit(false, { failures: [
    `domain→modulePackage 映射缺失：domain=${domainArg} 未在 README §9.2 表格中找到。` +
    `请检查 README §9.2 是否已生成、domain 标识是否与 domain.json/plans/domain.json 一致。`
  ] });
}
const domainPkg = domainModuleMap.get(domainArg).modulePkg.slice(root.dot.length + 1);
const domainPkgDot = `${root.dot}.${domainPkg}`;
const domainPkgSlash = `${root.slash}/${domainPkg.replace(/\./g, '/')}`;

// 2. 测试选择：文件系统枚举 FQN 逗号合并（确定性，规避 surefire 3.x `*` 不跨包歧义）；
//    focus 优先（单方法），无枚举结果时兜底域通配 `.*`（不跨子包，够用）。
function listTestFqns() {
  const testRoot = resolve(backendDir, 'src', 'test', 'java');
  const dir = resolve(testRoot, domainPkgSlash);
  if (!existsSync(dir)) return [];
  const out = [];
  (function walk(d) {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const p = resolve(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (/.*(Test|Tests|TestCase)\.java$/.test(e.name))
        out.push(relative(testRoot, p).replace(/\.java$/, '').split(/[\\/]/).join('.'));
    }
  })(dir);
  return out.sort();
}
const fqns = listTestFqns();
const sel = focus || (fqns.length ? fqns.join(',') : `${domainPkgDot}.*`);

// 3. 跑一次 mvn test（编译仍全量；-Dtest 只过滤跑哪些测试类；不加 -o 防离线仓未预热）
const isMaven = existsSync(resolve(backendDir, 'pom.xml'));
const cmd = isMaven ? (existsSync(resolve(backendDir, 'mvnw')) ? resolve(backendDir, 'mvnw')
  : (() => { try { execSync('which mvnd', { stdio: 'ignore' }); return 'mvnd'; } catch { return 'mvn'; } })()) : 'gradle';
const runArgs = isMaven ? ['-q', '-B', 'test', `-Dtest=${sel}`] : ['test', '--console=plain', `--tests=${sel}`];
let run = spawnSync(cmd, runArgs, {
  cwd: backendDir,
  encoding: 'utf-8',
  maxBuffer: 64 * 1024 * 1024,
  env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
});

// ── mvnd 崩溃退化到 mvn ──────────────────────────────────────────
// mvnd 因 /root/.m2/mvnd/registry 只读 mount 启动即崩，从未跑测试；崩溃栈不含 COMPILATION ERROR
// 也不含 "No tests to run"，会漏过所有检测 → totals=0 → ok=true 假绿。命中崩溃签名时重跑 mvn。
const _firstOut = `${run.stdout || ''}\n${run.stderr || ''}`;
if (cmd === 'mvnd' && run.status !== 0
    && /Read-only file system|DaemonException/.test(_firstOut)) {
  run = spawnSync('mvn', runArgs, {
    cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024,
    env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
  });
}
if (run.error) {
  emit(false, { failures: [`无法执行测试命令 ${cmd} ${runArgs.join(' ')}：${run.error.message}`] });
}
const combined = `${run.stdout || ''}\n${run.stderr || ''}`;
const compileError = /COMPILATION ERROR/i.test(combined);

// 编译错误结构化 + 兜底片段（防 agent 绕过脚本直调 mvn 看全量输出）
let compileErrors = [];
let compileErrorSnippet = '';
if (compileError) {
  const errRe = /\[ERROR\]\s+([^\s]+\.java):(?:\[(\d+)(?:,(\d+))?\])?\s*(.+)/g;
  let em;
  while ((em = errRe.exec(combined)) !== null) {
    const absFile = em[1];
    const file = existsSync(absFile) ? relative(backendDir, absFile) : absFile;
    compileErrors.push({
      file,
      line: em[2] ? Number(em[2]) : null,
      col: em[3] ? Number(em[3]) : null,
      msg: (em[4] || '').trim().slice(0, 300),
    });
  }
  const startIdx = combined.search(/COMPILATION ERROR/i);
  const endIdx = combined.search(/BUILD FAILURE/i);
  const sliceEnd = endIdx > startIdx ? endIdx : combined.length;
  compileErrorSnippet = startIdx >= 0 ? combined.slice(startIdx, sliceEnd).slice(0, 4000) : combined.slice(0, 4000);
}

// 4. 解析 surefire 报告：只统计本域前缀的类（其它域历史 .txt 视为陈旧忽略）
const classes = [];
if (!compileError) {
  const repDir = resolve(backendDir, 'target', 'surefire-reports');
  const files = existsSync(repDir) ? readdirSync(repDir).filter((n) => n.endsWith('.txt') && !n.startsWith('TEST-')) : [];
  for (const f of files) {
    const fqn = basename(f, '.txt');
    if (!fqn.startsWith(`${domainPkgDot}.`)) continue; // 关键：只统计本域
    const content = readFileSync(resolve(repDir, f), 'utf-8');
    const m = content.match(/Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+)(?:,\s*Skipped:\s*(\d+))?/);
    const failures = Number(m?.[2] || 0);
    const errors = Number(m?.[3] || 0);
    if (failures + errors === 0) continue; // 本域该类绿
    const contextLoad = /Failed to load ApplicationContext/i.test(content);
    const issues = (content.match(/^[^\n]*(?:<<<\s*(?:FAILURE|ERROR)!|\[ERROR\])[^\n]*/gm) || []).slice(0, 20).map((l) => l.trim().slice(0, 300));
    classes.push({ class: fqn, failures, errors, contextLoad, issues });
  }
}

const totals = classes.reduce(
  (t, c) => ({
    tests: t.tests + c.failures + c.errors,
    failures: t.failures + c.failures,
    errors: t.errors + c.errors,
  }),
  { tests: 0, failures: 0, errors: 0 }
);
const contextLoadIssue =
  !compileError &&
  (classes.some((c) => c.contextLoad) || /Failed to load ApplicationContext|BeanCreationException|Error creating bean/i.test(combined));

// 兜底：-Dtest 一个都没匹配上（类被删/改名/域目录为空）→ 提示，勿采信"0 失败=绿"
// 不限 fqns.length > 0：枚举空（domainPkgSlash 目录不存在/无测试类）同样算 0 tests 匹配，
// 之前漏判导致静默返回 ok、agent 误以为本域绿。
const noTestsMatched =
  !compileError && !classes.some((c) => c.failures + c.errors > 0) && run.status !== 0 && /No tests to run|no tests were executed|No tests run/i.test(combined);

const ok = !compileError && !contextLoadIssue && !noTestsMatched && totals.failures === 0 && totals.errors === 0;

emit(ok, {
  domain: domainArg,
  domainPkg: domainPkgDot,
  cmd: `${cmd} ${runArgs.join(' ')}`,
  compileError,
  compileErrors,
  compileErrorSnippet,
  contextLoadIssue,
  noTestsMatched,
  totals,
  classes,
  advice: compileError
    ? '编译错误（mvn test 含全量编译）：根因若不在本域，追加 acceptance-public-fixes.json 后返回'
    : contextLoadIssue
      ? 'Spring 上下文加载失败（多为公共层/依赖缺陷，非本域可修）→ 把 {entity/域, file, missing, suggestion} 追加到 acceptance-public-fixes.json 后返回，勿本域硬修'
      : noTestsMatched
        ? '-Dtest 未匹配到任何本域测试类（类被删/改名？）→ 确认本域测试类是否仍存在，或转交 B1-final'
        : '对仍失败子集再修再验，目标 ≤4 轮；同一失败 3 轮未解决转交 B1-final',
  summary: `${domainArg}: ${totals.tests} tests, ${totals.failures} failures, ${totals.errors} errors` + (contextLoadIssue ? ', contextLoadIssue' : '') + (compileError ? ', compileError' : ''),
});
