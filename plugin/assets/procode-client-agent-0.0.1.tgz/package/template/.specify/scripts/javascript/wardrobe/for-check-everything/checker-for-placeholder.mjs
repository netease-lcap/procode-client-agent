import { readFileSync } from '../../shared/index.mjs';

import { combine } from './tools.mjs';

export const FEATURE = '[FEATURE]';

export const checkerForPlaceholder = {
  callback:
    (rootDir) =>
    (bundle = {}) => {
      const { absoluteFilePath } = bundle;

      // 前导字符类只允许空白/blockquote/列表项，排除 mermaid nodeId[中文] 节点标签误报
      const reg = /\n[\s>\-]*\[[\u4e00-\u9fa5,.:()`，。：（）、\s]{3,}\](?!\()/g;
      const source = readFileSync(absoluteFilePath);
      const matched = source.match(reg) || [];

      const isNecessary = source.includes(FEATURE);

      if (matched.length <= 1 && !isNecessary) {
        return;
      }

      let array = matched.slice();
      const map = (item) => {
        const [got = item] = item.match(/\[.+\]/g) || [];

        return `\`${got}\``;
      };

      isNecessary && array.push(FEATURE);
      array = array.map(map);
      array = Array.from(new Set(array));

      const merged = array.join('、');

      const messages = [
        '### 文件内容存在以下的占位符，请参考流程，严格按照占位符要求生成内容替代占位符',
        '',
        '<!-- 占位符替换示例：`[天气状况]` 替换成 `天气晴朗`，必须严格遵守占位符要求、任务要求生成高质量内容。 -->',
        '<!-- 禁止此类错误操作：只是通过移除占位符的中括号来跳过检查 `[天气状况]` 替换成 `天气状况`，必须严格遵守占位符要求、任务要求生成高质量内容。 -->',
        '',
        `需要替换的占位符：${merged}`,
      ];

      return combine(...messages);
    },
};

export default checkerForPlaceholder;
