import fs from 'fs';
import path from 'path';

import {
  findUnderSpecs,
  filterUnderSpecs,
  readFileSync,
  readJSONSync,
  parseStemFromPath,
  auto,
} from '../shared/index.mjs';

const findTechStack = (item) => item === 'plans/tech-stack.json';
const filterEntities = (item) => item.startsWith('plans/backend/entity-') && item.endsWith('.md');

// ── 技术栈摘要工具 ──
// 只展示真正用到的部分：`none` / 空值 / 非字符串（如 micro 的 { deferred: true }）不参与拼接
const asText = (value) => (typeof value === 'string' ? value.trim() : '');

const isNone = (value) => {
  const text = asText(value).toLowerCase();

  return !text || text === 'none' || text === '不需要持久化';
};

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const messages = [];

  // ── 1. 技术栈 ──
  const techStackBundle = findUnderSpecs(rootDir)(findTechStack);
  const techStack = techStackBundle ? readJSONSync(techStackBundle.absoluteFilePath) : null;

  if (techStack) {
    const { backend, database } = techStack;
    const backendLine = backend
      ? [
          asText(backend.language),
          asText(backend.framework),
          // 不持久化（none / 不需要持久化）时整段不参与
          isNone(backend.persistence) ? '' : asText(backend.persistence),
        ]
          .filter(Boolean)
          .join(' + ')
      : '';
    // 无库形态（type 为 none / 空）⇒ 整行不展示；有库名才追加（库名）
    const dbName = database ? asText(database.database) : '';
    const dbLine =
      database && !isNone(database.type)
        ? `${asText(database.type)}${dbName ? `（${dbName}）` : ''}`
        : '';

    const parts = [backendLine, dbLine].filter(Boolean);
    if (parts.length) {
      messages.push(`### 技术栈\n\n${parts.join('  /  ')}`);
    }
  }

  // ── 2. 实体建模（按领域分组） ──
  const entityBundles = filterUnderSpecs(rootDir)(filterEntities);

  if (entityBundles.length) {
    // 逐文件解析领域归属
    const domainMap = new Map(); // domainNameZh → { id, entities: [{ stem, fileName }] }

    for (const bundle of entityBundles) {
      const content = readFileSync(bundle.absoluteFilePath) || '';
      const stem = parseStemFromPath(bundle.fileName); // e.g. "project" from "entity-project.md"
      const fileName = bundle.fileName;

      // 解析首行 > 业务领域：<domainId>（<domainNameZh>）
      const domainMatch = content.match(/^> 业务领域：(.+?)（(.+?)）/m);
      const domainId = domainMatch ? domainMatch[1] : 'unknown';
      const domainNameZh = domainMatch ? domainMatch[2] : '未分类';

      if (!domainMap.has(domainNameZh)) {
        domainMap.set(domainNameZh, { id: domainId, entities: [] });
      }
      domainMap.get(domainNameZh).entities.push({ stem, fileName });
    }

    messages.push(`### 实体建模\n`);

    for (const [nameZh, { id, entities }] of domainMap) {
      const names = entities.slice(0, 5).map((e) => e.stem).join('、');
      const suffix = entities.length > 5 ? `等` : '';
      messages.push(`- **${nameZh}（${id}）**：${names}${suffix}【${entities.length}】个实体`);
    }
  }

  if (!messages.length) {
    return 'PLANS 总结：未找到技术栈或实体建模产物';
  }

  return messages.join('\n\n');
};

auto(import.meta)(toRaw);
export default toRaw;
