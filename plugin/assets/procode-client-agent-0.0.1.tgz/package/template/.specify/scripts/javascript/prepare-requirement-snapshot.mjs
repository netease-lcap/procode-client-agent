#!/usr/bin/env node

/**
 * 需求快照 CLI（确定性、幂等）。
 *
 * 用法：
 *   node prepare-requirement-snapshot.mjs ensure --stage <outline|backend-design> --scenario <fresh|incremental|free> --spec-dir <abs>
 *
 * 可选（仅 backend-design）：
 *   --roster a,b,c   存量基线计数使用的专家 id
 *   --baseline <abs> 存量基线路径；默认 <specDir>/plans/backend/_meta/inventory-baseline.json
 *
 * stdout 恒为单个 JSON 对象；诊断写 stderr。
 *   成功 exit 0：{ ok:true, action:'created'|'unchanged'|'changed', stage, scenario,
 *                 requirementSnapshot, contextPath, algorithmVersion, inputs:[{id,path,present,sha256}],
 *                 updatedAt, note? }
 *   失败 exit 1：{ ok:false, error:{ code, message, detail? } }
 *
 * 快照只做提示（agent 判断「本轮是否同一轮重试」），不是门：失败只供调用方记录，
 * 不得据此断链。`check` 子命令已随门禁语义一并删除（2026-10-25 plan）。
 *
 * hash / 输入投影 / 复用判定只在 shared/requirement-snapshot.mjs 实现，本文件只做参数
 * 解析与错误到退出码/JSON 的映射，不复制任何算法。
 */

import path from 'path';

import { SNAPSHOT_SCENARIOS, SNAPSHOT_STAGES, SnapshotError, ensureSnapshot } from './shared/requirement-snapshot.mjs';

const USAGE =
  'Usage: node prepare-requirement-snapshot.mjs ensure --stage <outline|backend-design> ' +
  '--scenario <fresh|incremental|free> --spec-dir <absolute path> [--roster a,b,c] [--baseline <absolute path>]';

const COMMANDS = ['ensure'];
const FLAG_VALUES = ['--stage', '--scenario', '--spec-dir', '--roster', '--baseline'];

function badArgs(message, detail) {
  return new SnapshotError('bad-args', message, detail);
}

function parseArgv(argv) {
  const args = argv.slice(2);
  const command = args.shift();
  if (!COMMANDS.includes(command)) {
    throw badArgs(`unknown or missing command "${command ?? ''}"`, { command: command ?? null, usage: USAGE });
  }

  const flags = {};
  while (args.length > 0) {
    const flag = args.shift();
    if (!FLAG_VALUES.includes(flag)) {
      throw badArgs(`unknown argument "${flag}"`, { argument: flag, usage: USAGE });
    }
    const value = args.shift();
    if (value === undefined || value.startsWith('--')) {
      throw badArgs(`missing value for ${flag}`, { argument: flag, usage: USAGE });
    }
    flags[flag] = value;
  }

  const stage = flags['--stage'];
  const scenario = flags['--scenario'];
  const specDir = flags['--spec-dir'];

  if (!stage) throw badArgs('missing required flag --stage', { usage: USAGE });
  if (!SNAPSHOT_STAGES.includes(stage)) throw badArgs(`unknown stage "${stage}"`, { stage, allowed: SNAPSHOT_STAGES });
  if (!scenario) throw badArgs('missing required flag --scenario', { usage: USAGE });
  if (!SNAPSHOT_SCENARIOS.includes(scenario)) throw badArgs(`unknown scenario "${scenario}"`, { scenario, allowed: SNAPSHOT_SCENARIOS });
  if (!specDir) throw badArgs('missing required flag --spec-dir', { usage: USAGE });
  if (!path.isAbsolute(specDir)) throw badArgs(`--spec-dir must be an absolute path: ${specDir}`, { specDir });

  const hasRoster = flags['--roster'] !== undefined;
  const hasBaseline = flags['--baseline'] !== undefined;
  if (stage !== 'backend-design' && (hasRoster || hasBaseline)) {
    throw badArgs('--roster and --baseline are only valid with --stage backend-design', { stage });
  }

  const roster = hasRoster
    ? flags['--roster']
        .split(',')
        .map((id) => id.trim())
        .filter(Boolean)
    : undefined;

  let baselinePath;
  if (hasBaseline) {
    if (!path.isAbsolute(flags['--baseline'])) {
      throw badArgs(`--baseline must be an absolute path: ${flags['--baseline']}`, { baselinePath: flags['--baseline'] });
    }
    baselinePath = flags['--baseline'];
  }

  return { command, stage, scenario, specDir, roster, baselinePath };
}

function emit(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
}

function fail(err) {
  const error =
    err instanceof SnapshotError
      ? { code: err.code, message: err.message, ...(err.detail === undefined ? {} : { detail: err.detail }) }
      : { code: 'write-failed', message: err && err.message ? err.message : String(err) };
  process.stderr.write(`prepare-requirement-snapshot: ${error.code}: ${error.message}\n`);
  emit({ ok: false, error });
  process.exitCode = 1;
}

try {
  const args = parseArgv(process.argv);
  emit(ensureSnapshot(args));
  process.exitCode = 0;
} catch (err) {
  fail(err);
}
