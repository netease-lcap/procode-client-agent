#!/usr/bin/env node

/**
 * 预计算公共类型注册表 — 在阶段一骨架生成后、Wave 1 实体并发生成前运行。
 *
 * 产出 _meta/type-registry.json：{ "ClassName": "com.company.<appName>.pkg.ClassName", ... }
 * 所有 import 语句从此表查找，避免 42 个 agent 各自拼写 import 路径导致编译错误。
 */

import { existsSync, readdirSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { resolve, basename, dirname, sep } from 'path';
import {
  findBackendDir,
  findPlanBackendDir,
  loadSkeletonConventions,
  readMicroEngineeringPlan,
  freshMicroContextOfPlan,
  resolveDeclaredBackendRoots,
  resolveFreshMicroEntityPlacement,
  resolveProjectRoot,
} from './shared/backend-common.mjs';

const cwd = process.cwd();

/** 单根直接采用；多根只认声明里本身是其余所有根祖先的聚合根，否则无法唯一确定（null）。 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/** 代码根定位（D5）：声明根优先；findBackendDir 仅兜底并打 warning；歧义不猜。 */
function resolveBackendRoot(activeSpecDir) {
  const baseRoot = resolveProjectRoot(cwd) ?? cwd;
  const declared = resolveDeclaredBackendRoots({ activeSpecDir, rootDir: baseRoot });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[generate-type-registry] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[generate-type-registry] 代码根存在多个且无声明聚合根，无法唯一确定：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root，或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[generate-type-registry] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(cwd);
  if (legacy) console.warn(`[generate-type-registry] 未找到代码根声明，回落启发式 findBackendDir：${legacy}`);
  return legacy;
}

function findMetaDir(planDir) {
  // _meta 与其他 bucket 文件（compile-buckets.json 等）同目录：plans/backend/_meta/
  return planDir ? resolve(planDir, '_meta') : resolve(cwd, '_meta');
}

const planDir = findPlanBackendDir(cwd);
// micro 工程方案判据（fresh=v1 / incremental=v2）= 工程方案在场且自描述匹配；
// 方案不在场 ⇒ legacy 行为逐字不变。方案 invalid ⇒ fail loud，不回落旧 conventions。
// v2 增量方案没有 executionActions，本脚本只依赖 codeModules[].pathBase/sourceDirs，不读该字段。
const planState = planDir ? readMicroEngineeringPlan(planDir) : { kind: 'legacy', planPath: '' };
if (planState.kind === 'invalid') {
  console.error(`[generate-type-registry] 工程方案不可用：${planState.reason}（${planState.planPath}）`);
  process.exit(1);
}
const microPlan = planState.kind === 'fresh-micro' || planState.kind === 'incremental-micro';
// micro 工程方案（fresh/incremental）的源码根由工程方案 pathBase/sourceDirs 决定（见下方 freshCtx），
// 不需要单后端根；legacy 才用声明代码根的聚合根。
const backendDir = microPlan ? null : resolveBackendRoot(planDir ? dirname(dirname(planDir)) : undefined);
if (!backendDir && !microPlan) {
  console.error('未找到后端工程目录');
  process.exit(1);
}

if (!planDir) {
  console.error('未找到 plans/backend 目录');
  process.exit(1);
}

const metaDir = findMetaDir(planDir);

// 2. 读 domain.json → domain → module 映射
const domainJsonPath = resolve(dirname(planDir), 'domain.json');
const domains = [];
if (existsSync(domainJsonPath)) {
  try {
    const raw = JSON.parse(readFileSync(domainJsonPath, 'utf-8'));
    for (const d of raw.domains || []) {
      domains.push({ id: d.id, nameZh: d.nameZh });
    }
  } catch (e) {
    console.error('domain.json 解析失败:', e.message);
  }
}

// 3. 读 README.md §3 取 domain → 模块目录映射
const readmePath = resolve(planDir, 'README.md');
const readmeContent = existsSync(readmePath) ? readFileSync(readmePath, 'utf-8') : '';

// 从 README 表格提取: | 项目管理 | project_management | core | project | `<backend>/project/` |
const domainModuleMap = new Map();
const tableRe = /\|\s*(.+?)\s*\|\s*(\w+)\s*\|\s*\w+\s*\|\s*(\w+)\s*\|/g;
let m;
while ((m = tableRe.exec(readmeContent)) !== null) {
  const domainId = m[2].trim();
  const moduleDir = m[3].trim();
  if (domainId && moduleDir && !domainModuleMap.has(domainId)) {
    domainModuleMap.set(domainId, moduleDir);
  }
}

// 4. 根包名（契约优先，plan 2026-09-09/root-package-contract-consumers-stack-neutral-roles §3.3）
// micro 工程方案（fresh/incremental）：SOT = 工程方案 codeModules[].packageName 公共前缀；
// 其他场景 = skeleton-conventions.rootPackage。
// 旧实现本地 walk 包树 + 'com.company.app' 兜底占位——包树歧义时静默退化/假包名继续跑，皆废（0909 沙箱事故同根因）。
// 缺契约/方案 invalid = 上游产物缺失（上游故障）→ fail loud（exit 1），不兜底继续。
const conventions = loadSkeletonConventions(planDir);
const rootPackage = conventions?.rootPackage || '';
if (!rootPackage) {
  console.error(microPlan
    ? '[generate-type-registry] micro 工程方案（fresh/incremental）无法确定根包（fail loud，不兜底假包名）'
    : '[generate-type-registry] 无法确定根包：skeleton-conventions.json 缺失或无 rootPackage（fail loud，不兜底假包名）');
  console.error(`  - planDir: ${planDir}`);
  if (microPlan) {
    console.error(`  - 原因：${conventions.rootPackageReason || '工程方案 codeModules[].packageName 公共前缀不可判定'}`);
    console.error('  - 处置：工程方案生产任务补齐 packageName/Java 栈声明；本脚本禁止按目录名或 com.company 猜根包');
  } else {
    console.error('  - 处置：design 阶段须先产出 backend/_meta/skeleton-conventions.json（rootPackage 从骨架包树派生）；属上游产物缺失，非本脚本可修');
  }
  process.exit(1);
}
// 域→公共包映射照契约 commonPackageMapping 角色（换应用/换公共层包名不改代码）；查无 → 通用 root.<moduleDir>
const commonMappingRole = conventions.conventions.commonPackageMapping || null;
const commonPackageMapping =
  commonMappingRole && commonMappingRole.absent !== true && commonMappingRole.mapping && typeof commonMappingRole.mapping === 'object'
    ? commonMappingRole.mapping
    : null;
const freshCtx = microPlan ? freshMicroContextOfPlan(planDir, planState) : null;

const registry = {};

// 5. 扫描现有 Java 文件获取公共类型（阶段一骨架已生成）
function scanJavaFiles(dir, basePkg) {
  if (!existsSync(dir)) return;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    const fullPath = resolve(dir, entry.name);
    if (entry.isDirectory()) {
      scanJavaFiles(fullPath, basePkg ? `${basePkg}.${entry.name}` : entry.name);
    } else if (entry.name.endsWith('.java')) {
      const className = basename(entry.name, '.java');
      const fqn = basePkg ? `${basePkg}.${className}` : className;
      // 只注册顶层 public 类型（class/interface/enum），不注册内部类
      const content = readFileSync(fullPath, 'utf-8');
      if (/public\s+(class|interface|enum|@interface)\s+\w+/.test(content)) {
        registry[className] = fqn;
      }
    }
  }
}
if (microPlan) {
  // 多代码模块/多构建单元：按工程方案 pathBase + sourceDirs 逐模块扫描，不再假设单一
  // `backendDir/src/main/java` 根（工程方案的 pathBase 基准才是代码根）。
  for (const module of freshCtx.modules) {
    if (module.sourceDirs.length === 0) {
      console.error(`[generate-type-registry] 代码模块 ${module.moduleId} 未声明 sourceDirs——工程方案缺口，注册表不猜源码根`);
      process.exit(1);
    }
    for (const dir of module.sourceDirs) {
      scanJavaFiles(resolve(freshCtx.codeRoot, module.pathBase, dir), '');
    }
  }
} else {
  scanJavaFiles(resolve(backendDir, 'src', 'main', 'java'), '');
}

// 6. 从 entity-*.md 推导各层类型
const entityFiles = existsSync(planDir)
  ? readdirSync(planDir).filter((n) => n.startsWith('entity-') && n.endsWith('.md'))
  : [];

const entityNames = [];
for (const ef of entityFiles) {
  const content = readFileSync(resolve(planDir, ef), 'utf-8');
  // 提取业务领域：> 业务领域：<domain>
  const domainMatch = content.match(/^\s*>\s*业务领域[：:]\s*(\w+)/m);
  const domain = domainMatch ? domainMatch[1].trim() : 'common';

  // 提取实体名：## <entity_name>
  const entityMatch = content.match(/^##\s+(\w+)/m);
  if (!entityMatch) continue;
  const entityName = entityMatch[1].trim();

  // 转换为 PascalCase 类名（snake_case → PascalCase）
  const pascalName = entityName
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('');

  // 确定模块目录与基包
  let moduleDir;
  let pkgBase;
  if (microPlan) {
    // micro 工程方案（fresh/incremental）：实体投影绑定优先，service-binding 次之；多模块下**禁 moduleDir 回退 domain**
    // （那会生成 root.<domain> 幻影包）。不可判 = 设计缺口，fail loud，不静默省略实体类型。
    const entityPath = resolve(planDir, ef);
    const placement = resolveFreshMicroEntityPlacement(freshCtx, entityPath);
    if (placement.kind !== 'bound') {
      console.error(`[generate-type-registry] 实体 ${ef} 的模块归属不可判：${placement.reason}`);
      console.error('  - 处置：补齐 entity-module-binding.json 或 service-binding.json 的服务归属；本脚本禁止按 domain/README/旧 modules 兜底');
      process.exit(1);
    }
    const module = placement.module;
    if (!module.modulePackage) {
      console.error(`[generate-type-registry] 实体 ${ef} 归属模块 ${module.moduleId} 未声明 packageName——工程方案缺口，禁按目录名推包名`);
      process.exit(1);
    }
    moduleDir = module.moduleDir;
    const commonPkg = commonPackageMapping ? commonPackageMapping[domain] : null;
    pkgBase = commonPkg ? `${rootPackage}.${commonPkg}` : module.modulePackage;
  } else {
    moduleDir = domainModuleMap.get(domain) || domain;
    // 域→公共包映射照契约 commonPackageMapping（换应用/换公共层包名不改代码）；查无 → 通用 root.<moduleDir>
    const commonPkg = commonPackageMapping ? commonPackageMapping[domain] : null;
    pkgBase = commonPkg ? `${rootPackage}.${commonPkg}` : `${rootPackage}.${moduleDir}`;
  }

  entityNames.push({ entityName, pascalName, domain, pkgBase, moduleDir });

  // 主实体类型
  registry[pascalName] = `${pkgBase}.entity.${pascalName}`;

  // Service 层
  const entityModule = pascalName.toLowerCase().includes(domain.replace(/_/g, '').toLowerCase())
    ? '' // 简洁命名：如 FundInput 直接在 fund 包下
    : '';
  registry[`${pascalName}Service`] = `${pkgBase}.service.${pascalName}Service`;
  registry[`${pascalName}ServiceImpl`] = `${pkgBase}.service.${pascalName}ServiceImpl`;

  // DTO
  registry[`${pascalName}DTO`] = `${pkgBase}.dto.${pascalName}DTO`;
  registry[`${pascalName}QueryDTO`] = `${pkgBase}.dto.${pascalName}QueryDTO`;

  // VO
  registry[`${pascalName}VO`] = `${pkgBase}.vo.${pascalName}VO`;

  // Repository
  registry[`${pascalName}Repository`] = `${pkgBase}.repository.${pascalName}Repository`;

  // Test
  registry[`${pascalName}ServiceTest`] = `${pkgBase}.service.${pascalName}ServiceTest`;

  // 子实体类型（如果 entity-*.md 的 DDL 中有多个子表，这里只做基本推导）
  // 更多子类型在运行时由 agent 按约定推导
}

// 7. 公共类安全网：对 Step 5 scanJavaFiles 可能遗漏的关键公共类做按名递归搜索。
// 不硬编码包路径（不同骨架放 config/、common/、common/result/ 等，硬编码必错）；
// 找不到则跳过——动态 backendPublicFilesList（project.ts resolveBackendRootPackage）会从骨架发现真实路径。
function findClassByName(dir, className, basePkg) {
  if (!existsSync(dir)) return null;
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue;
    const fullPath = resolve(dir, entry.name);
    if (entry.isDirectory()) {
      const found = findClassByName(fullPath, className, basePkg ? `${basePkg}.${entry.name}` : entry.name);
      if (found) return found;
    } else if (entry.name === `${className}.java`) {
      return basePkg ? `${basePkg}.${className}` : className;
    }
  }
  return null;
}
const safetyNetClasses = ['ApiResponse', 'ErrorCode', 'PageVO', 'GlobalExceptionHandler', 'PageResult', 'LoginVO', 'LoginRequestDTO'];
let safetyNetAdded = 0;
// 源码根：micro 工程方案（fresh/incremental）= 工程方案声明的各模块 sourceDirs；legacy = 单一后端根。
const javaSourceDirs = microPlan
  ? freshCtx.modules.flatMap((module) => module.sourceDirs.map((dir) => resolve(freshCtx.codeRoot, module.pathBase, dir)))
  : [resolve(backendDir, 'src', 'main', 'java')];
for (const cn of safetyNetClasses) {
  if (!registry[cn]) {
    let found = null;
    for (const dir of javaSourceDirs) {
      found = findClassByName(dir, cn, '');
      if (found) break;
    }
    if (found) {
      registry[cn] = found;
      safetyNetAdded++;
    }
    // 找不到 → 跳过，不写错路径
  }
}

// 8. 落盘
if (metaDir) {
  mkdirSync(metaDir, { recursive: true });
  const outputPath = resolve(metaDir, 'type-registry.json');
  writeFileSync(outputPath, JSON.stringify(registry, null, 2));
  console.log(`type-registry.json 已生成 (${Object.keys(registry).length} 个类型)`);
  console.log(`  - 来自 Java 扫描: ${Object.keys(registry).length - entityNames.length * 7} 个`);
  console.log(`  - 来自 entity-*.md 推导: ${entityNames.length} 个实体 × 7 层类型`);
  console.log(`输出路径: ${outputPath}`);
} else {
  // 兜底: 输出到 stdout 供 script 调用方捕获
  console.log(JSON.stringify(registry, null, 2));
}
