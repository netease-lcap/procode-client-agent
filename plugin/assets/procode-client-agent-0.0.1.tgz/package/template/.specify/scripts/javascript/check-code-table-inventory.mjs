#!/usr/bin/env node
/**
 * 门 A：代码表清单机械校验 + 确定性预扫（plan 2026-11-04/incremental-code-schema-and-build-codegen §5.1 / §5.2）。
 *
 * 本脚本是 **P4 门 A 的判据单源**，同时承担 Agent A 的确定性预扫（不是第二套 agent 判断）：
 *   prescan   ：从 mapper XML / Java 字符串 / JPA 注解 / sql / migration / delta*.sql / 旧 entity
 *               机械提取「已知表集」与「动态表名位置」，写 `plans/backend/_meta/code-table-scan.json`，
 *               供 Agent A 作为输入证据、门 A 作为漏表校验基准。
 *   catalog   ：只校验 `code-table-inventory.json` 的 schema/catalog（Agent A 任务 checker 用；
 *               此时 db-table-list 还不存在，不能做分类）。
 *   connection：preflight 的坐标解析（唯一 resolver = shared/mysql-client.mjs 的
 *               resolveIncrementalDatasource；本脚本不另写第二套契约读取）。
 *   check     ：门 A 全量校验（候选/证据/动态/漏表/分类/codeOnly 决策/dbOnly 摘要）。
 *
 * 纪律（§5.1 / §5.2.2）：
 *   · 每条表名必须有证据；`agent-asserted` 只能来自代码文本定位（路径 + 行 + 文本可复核）；
 *   · 动态表名必须扫，运行时才确定的标 `dynamic:true`，不静默丢；
 *   · 具体表只走两类：`scope:"bound"`（有已确认绑定连接）与 `scope:"external"`（无绑定连接，
 *     需 `reason` + 真实 SQL/代码证据）；动态模式进 `dynamicPatterns[]`，不再是表；
 *   · `unresolved` 已废弃：顶层出现即红（含迁移指引），不再接受新条目；
 *   · 机械已知表集必须出现在 `tables[]` 或 `dynamicPatterns[]`，否则红（漏表）；
 *   · 首轮主来源为空时不得以空集放行；
 *   · codeOnly 必须由门 A 给 `decision: create|external|ignore` + 理由，checker 只验证据一致性；
 *     只有 `create` 进 delta；`scope:"external"` 强制 external、永不进 delta；dbOnly 不判红，
 *     但必须进入分类供 C 装配为 identity-only。
 *
 * inventory 版本：只接受 `schemaVersion: 2`。v1 旧产物红 `TABLE_INVENTORY_VERSION_LEGACY`，
 * 要求重跑 Agent A；不在 checker 内做不可靠投影（旧 unresolved 无法可靠判断 bound/external）。
 *
 * CLI（成功 stdout 一行 JSON，exit 0；失败 stdout 一行 JSON `{ok:false,failures}`，exit 1）：
 *   node check-code-table-inventory.mjs prescan [--root DIR] [--plans-dir DIR] [--out FILE] [--include-entity]
 *   node check-code-table-inventory.mjs catalog --inventory FILE [--binding FILE] [--root DIR]
 *   node check-code-table-inventory.mjs connection --inventory FILE [--binding FILE] [--root DIR] [--active-spec-dir DIR] [--channel mcp]
 *       （local 通道已退役；显式传 local 返回确定性失败）
 *   node check-code-table-inventory.mjs check --inventory FILE --db-table-list FILE
 *        [--scan FILE] [--root DIR] [--plans-dir DIR] [--binding FILE]
 *   node check-code-table-inventory.mjs --self-test
 *
 * 导出（单测直驱）：
 *   scanMechanicalTables / validateCodeTableInventory / parseInventoryCatalog /
 *   foldIdentifier / createLineIndexCache /
 *   SCAN_SCHEMA_VERSION / INVENTORY_SCHEMA_VERSION
 */

import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  realpathSync,
  renameSync,
  rmSync,
  writeFileSync,
  statSync,
  readdirSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

import { resolveIncrementalDatasource } from './shared/mysql-client.mjs';

export const SCAN_SCHEMA_VERSION = 1;
export const INVENTORY_SCHEMA_VERSION = 2;
export const GATE_VERSION = 1;

const IDENT = '[A-Za-z_][A-Za-z0-9_$]*';
const SQL_TABLE_REF = new RegExp(
  `\\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\\s+((?:${IDENT}\\s*\\.\\s*)?[\`"\\[]?${IDENT}[\`"\\]]?)`,
  'gi',
);
const JPA_TABLE = /@(?:Table|JoinTable|CollectionTable)\s*\(\s*(?:name\s*=\s*)?["']([^"']+)["']/gi;
const JAVA_STRING = /"((?:[^"\\]|\\.)*)"/g;
const DYN_PLACEHOLDER = new RegExp(
  `\\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\\s+((?:${IDENT})?(?:\\$\\{[^}]+\\}(?:${IDENT})?|#\\{[^}]+\\}))`,
  'gi',
);
const DYN_CONCAT = /\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\s*["'`]?\s*\+\s*[A-Za-z_$]/gi;
const DYN_FORMAT = /\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\s+(?:%s|%1\$s)/gi;

const SQL_DENY = new Set([
  'select', 'from', 'where', 'join', 'left', 'right', 'inner', 'outer', 'full', 'cross', 'on', 'using',
  'as', 'set', 'values', 'value', 'table', 'dual', 'null', 'true', 'false', 'and', 'or', 'not', 'exists', 'if',
  'case', 'when', 'then', 'else', 'end', 'union', 'all', 'distinct', 'group', 'order', 'by', 'having',
  'limit', 'offset', 'insert', 'update', 'delete', 'create', 'alter', 'drop', 'truncate', 'into',
  'information_schema', 'pg_catalog', 'performance_schema', 'sys', 'mysql',
  'user_tables', 'all_tables', 'dba_tables', 'user_columns', 'all_columns', 'user_constraints',
  'all_constraints', 'user_indexes', 'all_indexes', 'temp', 'temporary',
]);
const SYSTEM_SCHEMAS = new Set(['information_schema', 'pg_catalog', 'performance_schema', 'sys', 'mysql']);

const CODE_EXTENSIONS = new Set(['.java', '.kt', '.xml', '.sql']);
const EXCLUDED_DIRS = new Set([
  'node_modules', '.git', '.svn', '.hg', '.specify', '.opencode', 'dist', 'build', 'target', 'out',
  'coverage', '.next', '.nuxt', '.turbo', '.cache', 'tmp', '.tmp', 'venv', '.venv', '__pycache__',
  'plans', 'docs',
]);
const MAX_SCAN_FILES = 20000;
const MAX_FILE_BYTES = 4 * 1024 * 1024;

const EVIDENCE_KINDS = new Set([
  'mapper-xml', 'java-string', 'jpa-annotation', 'sql', 'migration', 'delta-sql', 'entity',
]);
const CODE_EVIDENCE_KINDS = new Set(['mapper-xml', 'java-string', 'jpa-annotation', 'sql', 'migration', 'delta-sql']);
const CONFIRMED_KINDS = new Set(['mechanical', 'agent-asserted']);
const DECISIONS = new Set(['create', 'external', 'ignore']);
const SCOPES = new Set(['bound', 'external']);
const PLAIN_IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_$]*$/;
// 动态模式必须带动态标记：`${...}` / `#{...}` / `*` 通配 / `%s` 占位 / 字符串拼接 `+`；
// 预扫自己的内部标记（java-string-concat / format-placeholder）也接受。
const DYNAMIC_PATTERN_MARKER = /\$\{[^}]*\}|#\{[^}]*\}|\*|%[0-9]*\$?s|\+/;
const DYNAMIC_PATTERN_INTERNAL_MARKERS = new Set(['java-string-concat', 'format-placeholder']);
// 动态位置的语句上下文（plan 2026-11-09 §3.1）：只有 DML 上下文允许停在 dynamicPatterns[]；
// DDL 可能建表必须解析为具体表/external；上下文不可判按 unknown 红停（不得 skip）。
const STATEMENT_KINDS = new Set(['dml', 'ddl', 'unknown']);
const DDL_KEYWORDS = new Set(['create', 'alter', 'drop', 'rename', 'truncate']);
const DML_KEYWORDS = new Set(['select', 'insert', 'update', 'delete', 'replace', 'merge', 'with']);
// MyBatis 的 DML 标签；`<sql>` 片段或其它标签无法判定语句类型。
const DML_MAPPER_TAGS = new Set(['select', 'insert', 'update', 'delete']);
const XML_TAG_RE = /<\/?\s*([A-Za-z_][\w.:-]*)\b[^>]*?(\/?)>/g;
// external 的 SQL 证据要能证明「独立库/外部库」：CREATE DATABASE / USE / 连接串库路径 / database|schema 声明。
const EXTERNAL_DB_SCOPE_EVIDENCE =
  /\bCREATE\s+DATABASE\b|\bUSE\s+[`"']?[A-Za-z_][A-Za-z0-9_$]*|jdbc:[a-z0-9]+:\/\/[^/\s]+\/[A-Za-z_][A-Za-z0-9_$]*|\b(?:database|schema)\s*[:=]\s*[`"']?[A-Za-z_]/i;

const isPlainObject = (value) => value != null && typeof value === 'object' && !Array.isArray(value);
const nonEmpty = (value) => typeof value === 'string' && value.trim() !== '';

/** dynamicPatterns[].pattern 必须是动态模式，不能是 `global_table` 这种普通标识符。 */
function isDynamicPattern(pattern) {
  const value = typeof pattern === 'string' ? pattern.trim() : '';
  if (!value) return false;
  if (DYNAMIC_PATTERN_INTERNAL_MARKERS.has(value)) return true;
  return DYNAMIC_PATTERN_MARKER.test(value) && !PLAIN_IDENTIFIER.test(value);
}

const nowIso = () => new Date().toISOString();

function writeJsonAtomic(filePath, value) {
  mkdirSync(dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`, 'utf-8');
  renameSync(tmp, filePath);
}

function readJson(filePath) {
  return JSON.parse(readFileSync(filePath, 'utf-8'));
}

function toPosix(value) {
  return String(value).split(sep).join('/');
}

// ─── 标识符归一 / catalog 形态 ───────────────────────────────────────────────

/** 方言归一：MySQL/PG 未引号标识符按小写折叠；Oracle/达梦按大写折叠；未知方言保持原样。 */
export function foldIdentifier(dialect, name) {
  const raw = String(name ?? '').trim().replace(/^[`"\[]|[`"\]]$/g, '');
  const d = String(dialect ?? '').trim().toLowerCase();
  if (['mysql', 'mariadb', 'postgres', 'postgresql', 'pg'].includes(d)) return raw.toLowerCase();
  if (['oracle', 'dm', 'dameng'].includes(d)) return raw.toUpperCase();
  return raw;
}

export function isMysqlDialect(dialect) {
  return ['mysql', 'mariadb', 'mysql8', 'mysql5.7'].includes(String(dialect ?? '').trim().toLowerCase());
}

/** 读取并校验 inventory 的 schema/catalog 段（不要求 db-table-list）。 */
export function parseInventoryCatalog(inventory) {
  const failures = [];
  if (!isPlainObject(inventory)) {
    return { ok: false, failures: [{ code: 'TABLE_INVENTORY_SCHEMA', path: '$', message: 'inventory 顶层必须是对象' }] };
  }
  if (inventory.schemaVersion === 1) {
    failures.push({
      code: 'TABLE_INVENTORY_VERSION_LEGACY',
      path: '$.schemaVersion',
      message:
        'inventory schemaVersion=1 为旧版（tables[] 无 scope、unresolved[] 已废弃）：门 A 只接受 schemaVersion=2。' +
        '恢复动作：重跑 Agent A（P4-A）产出 v2 —— 具体表进 tables[] 并标 scope:"bound"|"external"，' +
        '动态表名进 dynamicPatterns[]，禁止 unresolved[]。本 checker 不做旧产物自动投影' +
        '（旧 unresolved 无法可靠判断 bound/external）。',
    });
  } else if (inventory.schemaVersion !== INVENTORY_SCHEMA_VERSION) {
    failures.push({
      code: 'TABLE_INVENTORY_SCHEMA',
      path: '$.schemaVersion',
      message: `schemaVersion 必须为 ${INVENTORY_SCHEMA_VERSION}，实际 ${JSON.stringify(inventory.schemaVersion)}`,
    });
  }
  if (!nonEmpty(inventory.generatedBy)) {
    failures.push({ code: 'TABLE_INVENTORY_SCHEMA', path: '$.generatedBy', message: 'generatedBy 必须为非空字符串' });
  }
  const catalog = isPlainObject(inventory.catalog) ? inventory.catalog : null;
  if (!catalog) {
    failures.push({ code: 'TABLE_INVENTORY_CATALOG', path: '$.catalog', message: 'catalog 必须是对象' });
  } else {
    if (!nonEmpty(catalog.dialect)) {
      failures.push({ code: 'TABLE_INVENTORY_CATALOG', path: '$.catalog.dialect', message: 'catalog.dialect 必须为非空字符串' });
    }
    if (!nonEmpty(catalog.listTablesSql)) {
      failures.push({
        code: 'TABLE_INVENTORY_CATALOG',
        path: '$.catalog.listTablesSql',
        message: 'catalog.listTablesSql 必须为非空字符串',
      });
    }
    if (catalog.dataSourceName !== undefined && !nonEmpty(catalog.dataSourceName)) {
      failures.push({
        code: 'TABLE_INVENTORY_CATALOG',
        path: '$.catalog.dataSourceName',
        message: 'catalog.dataSourceName 省略时不写；写了必须为非空字符串',
      });
    }
    if (catalog.countSql !== undefined && !nonEmpty(catalog.countSql)) {
      failures.push({
        code: 'TABLE_INVENTORY_CATALOG',
        path: '$.catalog.countSql',
        message: 'catalog.countSql 省略时不写；写了必须为非空字符串',
      });
    }
    if (catalog.pageSize !== undefined && (!Number.isInteger(catalog.pageSize) || catalog.pageSize <= 0)) {
      failures.push({
        code: 'TABLE_INVENTORY_CATALOG',
        path: '$.catalog.pageSize',
        message: 'catalog.pageSize 必须是正整数',
      });
    }
  }
  if (!Array.isArray(inventory.tables)) {
    failures.push({ code: 'TABLE_INVENTORY_SCHEMA', path: '$.tables', message: 'tables 必须是数组' });
  }
  // v2：unresolved 已废弃（见 check 判据）；dynamicPatterns 可选，写了必须是数组。
  if (inventory.dynamicPatterns !== undefined && !Array.isArray(inventory.dynamicPatterns)) {
    failures.push({
      code: 'TABLE_INVENTORY_SCHEMA',
      path: '$.dynamicPatterns',
      message: 'dynamicPatterns 省略时不写；写了必须是数组',
    });
  }
  if (failures.length > 0) return { ok: false, failures };
  return {
    ok: true,
    failures: [],
    catalog: {
      dialect: catalog.dialect.trim(),
      listTablesSql: catalog.listTablesSql,
      countSql: catalog.countSql !== undefined ? catalog.countSql : undefined,
      pageSize: catalog.pageSize !== undefined ? catalog.pageSize : undefined,
      dataSourceName: catalog.dataSourceName ? catalog.dataSourceName.trim() : undefined,
    },
  };
}

// ─── 文件遍历 / 行号 ─────────────────────────────────────────────────────────

function makeLineIndex(text) {
  const starts = [0];
  for (let i = 0; i < text.length; i += 1) {
    if (text.charCodeAt(i) === 10) starts.push(i + 1);
  }
  return (index) => {
    let lo = 0;
    let hi = starts.length - 1;
    while (lo < hi) {
      const mid = Math.ceil((lo + hi) / 2);
      if (starts[mid] <= index) lo = mid;
      else hi = mid - 1;
    }
    return lo + 1;
  };
}

function walkFiles(rootDir, { extensions, shouldVisit, accept, maxFiles = MAX_SCAN_FILES }) {
  const files = [];
  if (!rootDir || !existsSync(rootDir)) return { files, truncated: false };
  const stack = [resolve(rootDir)];
  while (stack.length > 0) {
    const dir = stack.pop();
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      continue;
    }
    entries.sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      const abs = join(dir, entry.name);
      if (entry.isDirectory()) {
        if (EXCLUDED_DIRS.has(entry.name)) continue;
        if (entry.name.startsWith('.') && entry.name !== '.') continue;
        if (shouldVisit && !shouldVisit(abs)) continue;
        stack.push(abs);
        continue;
      }
      if (!entry.isFile()) continue;
      const lower = entry.name.toLowerCase();
      if (extensions && !extensions.has(lower.slice(lower.lastIndexOf('.')))) continue;
      if (accept && !accept(abs)) continue;
      files.push(abs);
      if (files.length >= maxFiles) return { files, truncated: true };
    }
  }
  return { files, truncated: false };
}

function safeRead(abs) {
  try {
    const stat = statSync(abs);
    if (!stat.isFile() || stat.size > MAX_FILE_BYTES) return null;
    return readFileSync(abs, 'utf-8');
  } catch {
    return null;
  }
}

// ─── 文本抽取 ───────────────────────────────────────────────────────────────

function stripToken(raw) {
  return String(raw ?? '')
    .trim()
    .replace(/^[\`"\[]/, '')
    .replace(/[\`"\]]$/, '')
    .replace(/\s+/g, '');
}

function splitQualified(raw) {
  const token = stripToken(raw);
  const parts = token.split('.').filter(Boolean);
  return { qualified: parts.join('.'), schema: parts.length > 1 ? parts[parts.length - 2] : null, table: parts[parts.length - 1] };
}

function pushEvidence(map, table, evidence) {
  const key = table.toLowerCase();
  if (!map.has(key)) map.set(key, { table, evidence: [] });
  const entry = map.get(key);
  entry.evidence.push(evidence);
}

/** 等长掩码（保留换行与下标 ⇒ 行号不漂）。 */
function maskLengthPreserving(text, regex) {
  return String(text).replace(regex, (match) => match.replace(/[^\n]/g, ' '));
}

/**
 * 只在「当 SQL 扫」的文本上去噪（沙箱实证的假表名来源）：
 *   · `-- …` 行注释 / `/* … *\/` 块注释：注释里的自然语言会喂出 `to` / `the` 之类；
 *   · mapper XML 标签：`<update id="…">` 的 tag 名会被当成 `UPDATE id`（假表名 `id`）；
 *   · `DROP TABLE IF EXISTS` 的 `IF` 由 SQL_DENY 兜底。
 * 等长掩码，`lineOf` 下标仍按原文计算。
 */
function maskNonSqlText(text, fileKind) {
  let masked = maskLengthPreserving(text, /--[^\n]*/g);
  masked = maskLengthPreserving(masked, /\/\*[\s\S]*?\*\//g);
  if (fileKind === 'mapper-xml') masked = maskLengthPreserving(masked, /<[^>]*>/g);
  return masked;
}

function extractRefsFromText(text, fileKind, relPath, lineOf) {
  const tables = new Map();
  const seen = new Set();
  const source = maskNonSqlText(text, fileKind);
  const add = (raw, index) => {
    const { qualified, schema, table } = splitQualified(raw);
    if (!table || !/^[A-Za-z_][A-Za-z0-9_$]*$/.test(table)) return;
    if (/[${}]/.test(table)) return;
    const lower = table.toLowerCase();
    if (SQL_DENY.has(lower)) return;
    if (schema && SYSTEM_SCHEMAS.has(String(schema).toLowerCase())) return;
    const dedupe = `${fileKind}\u0000${relPath}\u0000${lineOf(index)}\u0000${qualified.toLowerCase()}`;
    if (seen.has(dedupe)) return;
    seen.add(dedupe);
    pushEvidence(tables, table, {
      kind: fileKind,
      path: relPath,
      line: lineOf(index),
      ...(qualified.toLowerCase() !== lower ? { qualified } : {}),
    });
  };

  let match;
  // Java/Kotlin 源码字符串单独走 extractJavaSqlStrings（含字面量行号），这里只抽注解，
  // 避免把整个 .java 文本的 SQL 关键字当成 jpa-annotation 证据。
  if (fileKind !== 'jpa-annotation') {
    SQL_TABLE_REF.lastIndex = 0;
    while ((match = SQL_TABLE_REF.exec(source)) !== null) {
      // `FROM t_${suffix}` 这类「静态前缀 + 占位」整体是动态表名，不能把 t_ 当静态表。
      const next = source[match.index + match[0].length] ?? '';
      if (next === '$' || next === '#' || next === '{') continue;
      add(match[1], match.index);
    }
  }

  if (fileKind === 'java-string' || fileKind === 'jpa-annotation') {
    JPA_TABLE.lastIndex = 0;
    while ((match = JPA_TABLE.exec(source)) !== null) {
      const table = stripToken(match[1]);
      if (!/^[A-Za-z_][A-Za-z0-9_$]*$/.test(table) || SQL_DENY.has(table.toLowerCase())) continue;
      const dedupe = `jpa\u0000${relPath}\u0000${lineOf(match.index)}\u0000${table.toLowerCase()}`;
      if (seen.has(dedupe)) continue;
      seen.add(dedupe);
      pushEvidence(tables, table, { kind: 'jpa-annotation', path: relPath, line: lineOf(match.index) });
    }
  }
  return tables;
}

function extractJavaSqlStrings(text) {
  const tables = new Map();
  const dynamic = [];
  const lineOf = makeLineIndex(text);
  JAVA_STRING.lastIndex = 0;
  let match;
  while ((match = JAVA_STRING.exec(text)) !== null) {
    const literal = match[1];
    if (literal.length < 6) continue;
    if (!/\b(?:select|insert|update|delete|merge|from|join|table)\b/i.test(literal)) continue;
    const literalStart = match.index;
    const literalLineOf = (index) => lineOf(literalStart + Math.min(index, literal.length));
    const refs = extractRefsFromText(literal, 'java-string', '', literalLineOf);
    // 路径由调用方补：此处先保留 line，避免在字符串内重复算相对路径。
    for (const entry of refs.values()) {
      for (const evidence of entry.evidence) pushEvidence(tables, entry.table, { ...evidence, path: '' });
    }
    for (const dyn of extractDynamicPatterns(literal, 'java-string')) {
      dynamic.push({ ...dyn, line: literalLineOf(dyn.index), path: '' });
    }
  }
  return { tables, dynamic };
}

/**
 * 语句上下文分类（plan 2026-11-09 §3.1）：
 *   · mapper-xml：命中位于 `<select|insert|update|delete>` 内 → dml；`<sql>` / 其它标签 / 无标签 → unknown；
 *   · jpa-annotation：注解不承载 DDL → dml；
 *   · java-string：命中所在字符串字面量的 SQL 首关键字 → ddl/dml，无字面量或不可判 → unknown；
 *   · sql / migration / delta-sql / entity：命中所在语句（上一个 `;` 起）首关键字 → 同上三态。
 */
function normalizeStatementKind(value) {
  return STATEMENT_KINDS.has(value) ? value : 'unknown';
}

/** 语句首关键字（跳过空白 / `--` 行注释 / 块注释）；取不到返回 ''。 */
function firstSqlKeyword(statement) {
  let text = String(statement ?? '');
  let previous;
  do {
    previous = text;
    text = text.replace(/^\s+/, '');
    text = text.replace(/^--[^\n]*(?:\n|$)/, '');
    text = text.replace(/^\/\*[\s\S]*?\*\//, '');
  } while (text !== previous);
  const match = /^[A-Za-z_]+/.exec(text);
  return match ? match[0].toLowerCase() : '';
}

function kindFromKeyword(keyword) {
  if (DDL_KEYWORDS.has(keyword)) return 'ddl';
  if (DML_KEYWORDS.has(keyword)) return 'dml';
  return 'unknown';
}

/**
 * 栈式匹配命中位置最近的未闭合 XML 标签，返回最近的 DML 祖先标签（select/insert/update/delete）。
 * MyBatis 动态 SQL 常嵌套 `<if>` / `<where>` / `<foreach>`：只要仍处于某个 DML 语句内就是 dml；
 * 顶层 `<sql>` 片段或其它标签（无 DML 祖先）返回 null（= unknown）。
 */
function enclosingMapperTag(text, index) {
  const before = String(text ?? '').slice(0, Math.max(0, index));
  const stack = [];
  XML_TAG_RE.lastIndex = 0;
  let match;
  while ((match = XML_TAG_RE.exec(before)) !== null) {
    const name = match[1].toLowerCase();
    if (match[0].startsWith('</')) {
      const at = stack.lastIndexOf(name);
      if (at >= 0) stack.length = at;
    } else if (match[2] !== '/') {
      stack.push(name);
    }
  }
  for (let i = stack.length - 1; i >= 0; i -= 1) {
    if (DML_MAPPER_TAGS.has(stack[i])) return stack[i];
  }
  return null;
}

/**
 * 命中位置所在 Java/Kotlin 双引号字符串字面量的内容：
 *   · 全文含引号：只返回真正包住 index 的字面量，否则 null（命中在字面量之外 = 不可判）；
 *   · 全文没有引号：调用方传入的已是字面量内容（extractJavaSqlStrings），整段视为字面量。
 */
function javaStringLiteralAt(text, index) {
  const source = String(text ?? '');
  let start = -1;
  let hasQuote = false;
  for (let i = 0; i < source.length; i += 1) {
    const ch = source[i];
    if (start === -1) {
      if (ch === '\\') {
        i += 1;
        continue;
      }
      if (ch === '"') {
        hasQuote = true;
        start = i + 1;
      }
      continue;
    }
    if (ch === '\\') {
      i += 1;
      continue;
    }
    if (ch === '"') {
      if (index >= start && index < i) return source.slice(start, i);
      start = -1;
    }
  }
  if (start !== -1 && index >= start) return source.slice(start);
  if (!hasQuote) return source;
  return null;
}

function classifyDynamicStatement(text, index, kind) {
  const source = String(text ?? '');
  const at = Number.isInteger(index) && index >= 0 ? index : 0;
  if (kind === 'jpa-annotation') return 'dml';
  if (kind === 'mapper-xml') {
    const tag = enclosingMapperTag(source, at);
    return tag && DML_MAPPER_TAGS.has(tag) ? 'dml' : 'unknown';
  }
  if (kind === 'java-string') {
    const literal = javaStringLiteralAt(source, at);
    return literal == null ? 'unknown' : kindFromKeyword(firstSqlKeyword(literal));
  }
  // sql / migration / delta-sql / entity：取命中位置所在语句（上一个 ; 起）的首关键字。
  const start = source.lastIndexOf(';', Math.max(0, at - 1)) + 1;
  const semicolon = source.indexOf(';', at);
  const end = semicolon === -1 ? source.length : semicolon;
  return kindFromKeyword(firstSqlKeyword(source.slice(start, end)));
}

function extractDynamicPatterns(text, kind) {
  const out = [];
  const seen = new Set();
  const push = (pattern, index) => {
    const key = `${pattern}\u0000${index}`;
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ pattern, kind, index, statementKind: classifyDynamicStatement(text, index, kind) });
  };
  let match;
  DYN_PLACEHOLDER.lastIndex = 0;
  while ((match = DYN_PLACEHOLDER.exec(text)) !== null) push(match[1], match.index);
  DYN_CONCAT.lastIndex = 0;
  while ((match = DYN_CONCAT.exec(text)) !== null) push('java-string-concat', match.index);
  DYN_FORMAT.lastIndex = 0;
  while ((match = DYN_FORMAT.exec(text)) !== null) push('format-placeholder', match.index);
  return out;
}

function fileKindForCode(abs, text) {
  const ext = abs.slice(abs.lastIndexOf('.')).toLowerCase();
  if (ext === '.xml') {
    if (/<mapper\b/i.test(text) || /[\\/]mapper[\\/]/i.test(abs)) return 'mapper-xml';
    // 非 mapper 的 XML（pom.xml / spring / logback …）不是 SQL 载体：当成 SQL 扫会把
    // 描述文本里的词喂成假表名（沙箱实证：pom description 的 `tech-stack` → 假表 `tech`）。
    return null;
  }
  if (ext === '.java' || ext === '.kt') return 'java-annotated';
  if (ext === '.sql') return 'sql';
  return null;
}

function plansSqlKind(relFromBackend) {
  const rel = toPosix(relFromBackend);
  if (/(^|\/)delta[^/]*\.sql$/i.test(rel)) return 'delta-sql';
  if (/(^|\/)migration\//i.test(rel)) return 'migration';
  if (/(^|\/)sql\//i.test(rel)) return 'sql';
  if (/\.sql$/i.test(rel)) return 'sql';
  return null;
}

/**
 * 确定性预扫。
 *
 * @param {{rootDir?: string, plansBackendDir?: string, includeEntityEvidence?: boolean, now?: Function}} options
 * @returns {object} code-table-scan 文档
 */
export function scanMechanicalTables(options = {}) {
  const rootDir = resolve(options.rootDir || process.cwd());
  const plansBackendDir = options.plansBackendDir ? resolve(options.plansBackendDir) : null;
  const now = typeof options.now === 'function' ? options.now : nowIso;
  if (!existsSync(rootDir)) throw new Error(`预扫工作区根不存在：${rootDir}`);

  const relOf = (abs) => toPosix(relative(rootDir, abs));
  const tables = new Map();
  const dynamic = [];
  const warnings = [];
  const files = { scanned: 0, skipped: 0, byKind: {} };

  const mergeEvidence = (map) => {
    for (const entry of map.values()) {
      for (const evidence of entry.evidence) {
        pushEvidence(tables, entry.table, evidence);
      }
    }
  };

  // 1) 代码侧：mapper XML / Java(Kotlin) 字符串 / JPA 注解 / SQL 文件
  const codeWalk = walkFiles(rootDir, {
    extensions: CODE_EXTENSIONS,
    shouldVisit: (abs) => abs !== plansBackendDir,
  });
  if (codeWalk.truncated) warnings.push(`代码扫描达到 ${MAX_SCAN_FILES} 文件上限，后续文件未扫描（需收窄工作区或拆轮）`);
  for (const abs of codeWalk.files) {
    const text = safeRead(abs);
    if (text == null) {
      files.skipped += 1;
      continue;
    }
    const kind = fileKindForCode(abs, text);
    if (!kind) {
      files.skipped += 1;
      continue;
    }
    const relPath = relOf(abs);
    const lineOf = makeLineIndex(text);
    if (kind === 'java-annotated') {
      // Java/Kotlin：先抽字符串里的 SQL，再抽注解表名。字符串内行号按字面量起点估算，
      // 门 A 的证据校验允许 ±N 行窗口 + 整文件回退。
      const java = extractJavaSqlStrings(text);
      for (const entry of java.tables.values()) {
        for (const evidence of entry.evidence) pushEvidence(tables, entry.table, { ...evidence, path: relPath });
      }
      for (const dyn of java.dynamic) {
        dynamic.push({
          pattern: dyn.pattern,
          kind: 'java-string',
          path: relPath,
          line: dyn.line ?? lineOf(dyn.index ?? 0),
          statementKind: dyn.statementKind,
        });
      }
      // 字符串拼接 / String.format 的表名在 Java 源码里位于字面量之外（"FROM " + tableName），
      // 单独扫整段源码，否则动态表名会静默漏掉。
      for (const dyn of extractDynamicPatterns(text, 'java-string')) {
        dynamic.push({
          pattern: dyn.pattern,
          kind: 'java-string',
          path: relPath,
          line: lineOf(dyn.index),
          statementKind: dyn.statementKind,
        });
      }
      const refs = extractRefsFromText(text, 'jpa-annotation', relPath, lineOf);
      mergeEvidence(refs);
    } else {
      const refs = extractRefsFromText(text, kind, relPath, lineOf);
      mergeEvidence(refs);
      if (kind === 'mapper-xml') {
        for (const dyn of extractDynamicPatterns(text, 'mapper-xml')) {
          dynamic.push({
            pattern: dyn.pattern,
            kind: 'mapper-xml',
            path: relPath,
            line: lineOf(dyn.index),
            statementKind: dyn.statementKind,
          });
        }
      }
    }
    files.scanned += 1;
    files.byKind[kind] = (files.byKind[kind] || 0) + 1;
  }

  // 2) 存量 SQL：plans/backend/sql/**、migration/**、delta*.sql（以及工作区内 sql/migration 目录）
  const sqlCandidates = [];
  if (plansBackendDir && existsSync(plansBackendDir)) {
    const planWalk = walkFiles(plansBackendDir, {
      extensions: new Set(['.sql']),
      accept: (abs) => plansSqlKind(relative(plansBackendDir, abs)) !== null,
    });
    sqlCandidates.push(...planWalk.files.map((abs) => ({ abs, kind: plansSqlKind(relative(plansBackendDir, abs)) })));
  }
  const workspaceSqlWalk = walkFiles(rootDir, {
    extensions: new Set(['.sql']),
    shouldVisit: (abs) => abs !== plansBackendDir,
    accept: (abs) => /[\\/](?:sql|migration)[\\/]/i.test(abs),
    maxFiles: 2000,
  });
  sqlCandidates.push(...workspaceSqlWalk.files.map((abs) => ({ abs, kind: 'sql' })));
  const seenSql = new Set();
  for (const { abs, kind } of sqlCandidates) {
    if (seenSql.has(abs)) continue;
    seenSql.add(abs);
    const text = safeRead(abs);
    if (text == null) {
      files.skipped += 1;
      continue;
    }
    const relPath = relOf(abs);
    const lineOf = makeLineIndex(text);
    mergeEvidence(extractRefsFromText(text, kind, relPath, lineOf));
    for (const dyn of extractDynamicPatterns(text, kind)) {
      dynamic.push({
        pattern: dyn.pattern,
        kind,
        path: relPath,
        line: lineOf(dyn.index),
        statementKind: dyn.statementKind,
      });
    }
    files.scanned += 1;
    files.byKind[kind] = (files.byKind[kind] || 0) + 1;
  }

  // 3) 可选：上一轮 entity 快照（只从 _meta/prior-round/ 读；P4 早于 P6，**禁止**读本轮
  //    backend/entity-*.md，否则会把 P6 尚未产出的设计当既有事实）。
  if (options.includeEntityEvidence && plansBackendDir && existsSync(plansBackendDir)) {
    const priorDir = join(plansBackendDir, '_meta', 'prior-round');
    for (const name of existsSync(priorDir) ? readdirSync(priorDir).sort() : []) {
      if (!/^entity-.*\.md$/.test(name)) continue;
      const abs = join(priorDir, name);
      const text = safeRead(abs);
      if (text == null) continue;
      const relPath = relOf(abs);
      mergeEvidence(extractRefsFromText(text, 'entity', relPath, makeLineIndex(text)));
      files.scanned += 1;
      files.byKind.entity = (files.byKind.entity || 0) + 1;
    }
  }

  const tableList = [...tables.values()]
    .map((entry) => ({
      table: entry.table,
      evidence: dedupeEvidence(entry.evidence),
    }))
    .sort((a, b) => a.table.localeCompare(b.table));
  const dynamicList = dedupeDynamic(dynamic).sort(
    (a, b) => a.path.localeCompare(b.path) || (a.line ?? 0) - (b.line ?? 0) || a.pattern.localeCompare(b.pattern),
  );

  return {
    schemaVersion: SCAN_SCHEMA_VERSION,
    kind: 'code-table-scan',
    generatedAt: now(),
    generatedBy: 'incremental/code-table-prescan',
    roots: { workspaceRoot: rootDir, plansBackendDir },
    files,
    tables: tableList,
    dynamic: dynamicList,
    warnings,
  };
}

function dedupeEvidence(evidence) {
  const seen = new Set();
  const out = [];
  for (const item of evidence) {
    const key = `${item.kind}\u0000${item.path}\u0000${item.line ?? ''}\u0000${item.qualified ?? ''}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out.sort((a, b) => a.path.localeCompare(b.path) || (a.line ?? 0) - (b.line ?? 0));
}

function dedupeDynamic(entries) {
  const seen = new Set();
  const out = [];
  for (const item of entries) {
    const key = `${item.kind}\u0000${item.path}\u0000${item.line ?? ''}\u0000${item.pattern}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({
      pattern: item.pattern,
      kind: item.kind,
      path: item.path,
      line: item.line,
      statementKind: item.statementKind,
    });
  }
  return out;
}

// ─── 门 A 校验 ───────────────────────────────────────────────────────────────

function failure(code, path, message, extra = {}) {
  return { code, path, message, ...extra };
}

/**
 * 证据定位的唯一口径（§5.2）：
 *   · evidence.line 存在 → 只校验该行（不允许 ±N 窗口或整文件回落，否则行号形同虚设）；
 *   · evidence.line 省略 → 校验整份文件文本。
 * 比较按方言归一（MySQL/PG 小写、Oracle/达梦大写），而不是裸字符串相等。
 *
 * 行号索引缓存（性能修复）：按**绝对路径**缓存每个文件的行起始偏移表。
 *
 * 旧实现 `lineAt(text, line)` 对**每一条证据**都 `text.split(/\r?\n/)` 整份文件：
 * 沙箱实测 482 张表 / 40,502 条证据，其中 38,415 条指向同一个 3.8MB DDL（一次 split 6.79ms），
 * 单轮校验约 261 秒。这里改为「每个文件首次访问时线性扫一遍换行 + 之后按行号二分 + slice」，
 * 同一文件不再重复 split。
 *
 * 语义与 `text.split(/\r?\n/)[line - 1]` 逐字一致：
 *   · `line` 必须是正整数，否则返回 `null`；越界返回 `null`；行号 1-based；
 *   · 兼容 `\r\n` / `\n`（单独 `\r` 不是换行，与 `\r?\n` 同解）。
 *
 * 缓存键必须是绝对路径（调用方从 `resolveEvidencePath` 拿到 `resolved.abs`），不用文件内容做键；
 * 一次校验 run 引用的文件集合有限（<200），用普通 Map 即可，不需要 LRU。缓存随 run 结束释放。
 */
export function createLineIndexCache() {
  const indexes = new Map(); // 绝对路径 -> { text, starts }
  let builds = 0;

  const indexFor = (abs, text) => {
    const cached = indexes.get(abs);
    if (cached) return cached;
    const starts = [0];
    for (let i = 0; i < text.length; i += 1) {
      if (text.charCodeAt(i) === 10) starts.push(i + 1);
    }
    const entry = { text, starts };
    indexes.set(abs, entry);
    builds += 1;
    return entry;
  };

  return {
    /**
     * @param {string} abs 证据文件绝对路径（缓存键）
     * @param {string} text 该文件全文（同一 run 内同一 abs 视为同一文本）
     * @param {number} line 1-based 行号
     */
    lineAt(abs, text, line) {
      if (!Number.isInteger(line) || line <= 0) return null;
      const { text: source, starts } = indexFor(abs, text);
      if (line > starts.length) return null;
      const start = starts[line - 1];
      if (line === starts.length) return source.slice(start);
      // 该行以换行结尾：去掉 `\n`；`\r\n` 再去掉 `\r`（与 split 的分隔语义一致）。
      let end = starts[line] - 1;
      if (end > start && source.charCodeAt(end - 1) === 13) end -= 1;
      return source.slice(start, end);
    },
    /** 与 `text.split(/\r?\n/).length` 同值；复用同一索引，避免越界分支再 split 一次整份文件。 */
    lineCount(abs, text) {
      return indexFor(abs, text).starts.length;
    },
    /** 测试钩子：已缓存的文件数（按绝对路径去重）。 */
    size() {
      return indexes.size;
    },
    /** 测试钩子：索引构建次数；同一文件重复查询应保持不变。 */
    buildCount() {
      return builds;
    },
  };
}

function containsIdentifier(text, table, dialect) {
  const target = foldIdentifier(dialect, table);
  const re = /[`"\[]?([A-Za-z_][A-Za-z0-9_$]*)/g;
  let match;
  while ((match = re.exec(text)) !== null) {
    if (foldIdentifier(dialect, match[1]) === target) return true;
  }
  return false;
}

function resolveEvidencePath(rootDir, rawPath) {
  if (!nonEmpty(rawPath)) return { ok: false, message: 'evidence.path 必须为非空字符串' };
  if (isAbsolute(rawPath)) return { ok: false, message: 'evidence.path 必须是相对工作区根的路径（禁绝对路径）' };
  const abs = resolve(rootDir, rawPath);
  const rel = relative(rootDir, abs);
  if (!rel || rel.startsWith('..') || isAbsolute(rel)) {
    return { ok: false, message: `evidence.path 越界：${rawPath}` };
  }
  if (!existsSync(abs)) return { ok: false, message: `evidence.path 不存在：${rawPath}` };
  return { ok: true, abs };
}

/**
 * db-table-list 归一（多数据源 + 单源兼容）。
 *
 * 新形状：`{ kind, sources:[{ dataSourceName, dialect, database, pages, catalogComplete,
 *   catalogExpected, catalogReturned, count, tableNames, truncated, ... }] }`
 * 兼容形状：顶层直接承载 `tableNames/rowCount/truncated/catalogComplete/...`（单源）。
 *
 * 完整性判据（§D）：多源或显式来源条目必须 `catalogComplete === true`；
 * 字节 `truncated`、COUNT 与分页返回数不符、页数自相矛盾一律红。
 */
function normalizeDbList(dbTableList, catalogDialect) {
  const failures = [];
  if (!isPlainObject(dbTableList)) {
    return { ok: false, failures: [failure('TABLE_INVENTORY_DB_LIST', '$db-table-list', 'db-table-list 顶层必须是对象')], sources: new Map() };
  }
  if (dbTableList.kind !== 'db-table-list') {
    return {
      ok: false,
      failures: [
        failure(
          'TABLE_INVENTORY_DB_LIST',
          '$db-table-list.kind',
          `db-table-list.kind 必须为 "db-table-list"，实际 ${JSON.stringify(dbTableList.kind)}`,
        ),
      ],
      sources: new Map(),
    };
  }

  const hasSources = Array.isArray(dbTableList.sources) && dbTableList.sources.length > 0;
  const rawSources = hasSources
    ? dbTableList.sources.map((entry, index) => ({ entry, path: `$.sources[${index}]` }))
    : [{ entry: dbTableList, path: '$db-table-list', legacy: true }];

  const sources = new Map();
  for (const { entry, path, legacy } of rawSources) {
    if (!isPlainObject(entry)) {
      failures.push(failure('TABLE_INVENTORY_DB_LIST', path, 'db-table-list 来源条目必须是对象'));
      continue;
    }
    let ds = nonEmpty(entry.dataSourceName) ? entry.dataSourceName.trim() : '';
    if (!ds && !legacy) {
      failures.push(
        failure('TABLE_INVENTORY_DATASOURCE', `${path}.dataSourceName`, '多数据源 db-table-list 的每个来源必须带 dataSourceName'),
      );
    }
    // 单源兼容：老产物没有 dataSourceName；用 catalog 声明的数据源补身份。
    if (!ds && legacy && nonEmpty(dbTableList.dataSourceName)) ds = dbTableList.dataSourceName.trim();

    const dialect = nonEmpty(entry.dialect) ? entry.dialect.trim() : catalogDialect;
    if (!legacy) {
      if (entry.catalogComplete !== true) {
        failures.push(
          failure(
            'TABLE_INVENTORY_DB_LIST',
            `${path}.catalogComplete`,
            `数据源 ${ds || '<unknown>'} 目录不完整（catalogComplete=${JSON.stringify(entry.catalogComplete)}）：` +
              '不得把「只取了第一页」当完整目录',
          ),
        );
      }
    } else if (entry.catalogComplete !== undefined && entry.catalogComplete !== true) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DB_LIST',
          `${path}.catalogComplete`,
          `catalogComplete=${JSON.stringify(entry.catalogComplete)}：目录不完整，不得用于分类`,
        ),
      );
    }
    if (entry.truncated === true) {
      failures.push(
        failure('TABLE_INVENTORY_DB_LIST', `${path}.truncated`, `数据源 ${ds || '<unknown>'} 目录被字节截断（truncated=true）`),
      );
    }

    if (!Array.isArray(entry.tableNames)) {
      failures.push(failure('TABLE_INVENTORY_DB_LIST', `${path}.tableNames`, 'db-table-list.tableNames 必须是数组'));
      continue;
    }
    if (entry.rowCount > 0 && !nonEmpty(entry.tableNameColumn)) {
      failures.push(
        failure('TABLE_INVENTORY_DB_LIST', `${path}.tableNameColumn`, 'db-table-list 非空但未能机械确定表名列（tableNameColumn=null）'),
      );
    }
    if (entry.rowCount > 0 && entry.tableNames.length === 0) {
      failures.push(
        failure('TABLE_INVENTORY_DB_LIST', `${path}.tableNames`, 'db-table-list 非空行数但表名集合为空：preflight 结果不可用于分类'),
      );
    }

    // COUNT / 分页对账：catalogExpected/Returned（runner）+ count.expected/returned。
    const expected = Number.isInteger(entry.catalogExpected)
      ? entry.catalogExpected
      : isPlainObject(entry.count) && Number.isInteger(entry.count.expected)
        ? entry.count.expected
        : null;
    const returned = Number.isInteger(entry.catalogReturned)
      ? entry.catalogReturned
      : isPlainObject(entry.count) && Number.isInteger(entry.count.returned)
        ? entry.count.returned
        : null;
    if (expected != null && returned != null && expected !== returned) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DB_LIST',
          `${path}.catalogExpected`,
          `数据源 ${ds || '<unknown>'} 目录 COUNT=${expected} 与返回表数=${returned} 不一致`,
        ),
      );
    }
    if (isPlainObject(entry.count)) {
      if (Number.isInteger(entry.count.expected) && Number.isInteger(entry.count.returned) && entry.count.expected !== entry.count.returned) {
        failures.push(
          failure(
            'TABLE_INVENTORY_DB_LIST',
            `${path}.count`,
            `数据源 ${ds || '<unknown>'} COUNT=${entry.count.expected} 与分页返回 ${entry.count.returned} 行不一致`,
          ),
        );
      }
    }
    if (
      Array.isArray(entry.pages) &&
      Number.isInteger(entry.catalogPageCount) &&
      entry.catalogPageCount !== entry.pages.length
    ) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DB_LIST',
          `${path}.catalogPageCount`,
          `数据源 ${ds || '<unknown>'} 页数自相矛盾：catalogPageCount=${entry.catalogPageCount}，pages=${entry.pages.length}`,
        ),
      );
    }

    const names = [];
    const seen = new Set();
    for (const raw of entry.tableNames) {
      if (!nonEmpty(raw)) continue;
      const name = String(raw).trim();
      const key = foldIdentifier(dialect, name);
      if (seen.has(key)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_DUPLICATE',
            `${path}.tableNames`,
            `同一数据源 ${ds || '<unknown>'} 内表名按方言归一后重复：${name}（key=${key}）`,
          ),
        );
        continue;
      }
      seen.add(key);
      names.push({ raw: name, key });
    }

    const key = ds || '';
    if (sources.has(key)) {
      failures.push(
        failure('TABLE_INVENTORY_DATASOURCE', `${path}.dataSourceName`, `db-table-list 中数据源 ${key || '<unknown>'} 重复`),
      );
      continue;
    }
    sources.set(key, {
      dataSourceName: ds,
      dialect,
      expected,
      returned,
      truncated: entry.truncated === true,
      catalogComplete: entry.catalogComplete === undefined ? null : entry.catalogComplete === true,
      names,
    });
  }

  if (failures.length > 0) return { ok: false, failures, sources };
  return { ok: true, failures: [], sources };
}


/**
 * 门 A 全量校验（纯函数；输入全部显式传入，便于单测）。
 *
 * @param {{
 *   inventory: unknown,
 *   dbTableList: unknown,
 *   scan?: object|null,
 *   rootDir?: string,
 *   bindingNames?: string[]|null,
 *   requireDecisions?: boolean,
 * }} input
 * @returns {{ok:boolean, failures:object[], classification:object, summary:object}}
 */
export function validateCodeTableInventory(input = {}) {
  const failures = [];
  const inventory = input.inventory;
  const dbTableList = input.dbTableList;
  const rootDir = resolve(input.rootDir || process.cwd());
  const requireDecisions = input.requireDecisions !== false;

  const catalogRead = parseInventoryCatalog(inventory);
  const legacyVersion = isPlainObject(inventory) && inventory.schemaVersion === 1;
  if (legacyVersion) {
    // v1 只红 + 迁移指引：不做 bound/external 投影（旧 unresolved 的语义无法可靠还原）。
    return {
      ok: false,
      failures: catalogRead.failures,
      classification: {
        codeTables: [],
        codeOnly: [],
        createTables: [],
        externalTables: [],
        dbOnly: [],
        sources: [],
      },
      summary: {
        candidateCount: 0,
        codeTableCount: 0,
        codeOnlyCount: 0,
        dbOnlyCount: 0,
        unresolvedCount: Array.isArray(inventory.unresolved) ? inventory.unresolved.length : 0,
        mechanicalCount: 0,
        dynamicCount: 0,
        sourceCount: 0,
        legacyVersion: true,
      },
    };
  }
  if (!catalogRead.ok) {
    // catalog/schema 红后仍尽量分类，但缺 dialect 时只能按原样比较。
    failures.push(...catalogRead.failures);
  }
  const catalog = catalogRead.catalog || { dialect: '', listTablesSql: '' };
  const dialect = catalog.dialect;

  const tables = isPlainObject(inventory) && Array.isArray(inventory.tables) ? inventory.tables : [];
  const dynamicPatterns =
    isPlainObject(inventory) && Array.isArray(inventory.dynamicPatterns) ? inventory.dynamicPatterns : [];
  // v2 废弃 unresolved：顶层出现且非空即红（空数组也视为旧习惯，但不阻断——只警告不判据）。
  const rawUnresolved = isPlainObject(inventory) ? inventory.unresolved : undefined;
  const unresolvedCount = Array.isArray(rawUnresolved) ? rawUnresolved.length : rawUnresolved === undefined ? 0 : 1;
  if (rawUnresolved !== undefined && (!Array.isArray(rawUnresolved) || rawUnresolved.length > 0)) {
    failures.push(
      failure(
        'TABLE_INVENTORY_UNRESOLVED_FORBIDDEN',
        '$.unresolved',
        `顶层 unresolved 已废弃，发现 ${unresolvedCount} 条：不得再用 unresolved 兜底。` +
          '迁移：具体表（表名可还原）→ tables[] 并标 scope:"bound"（有已确认绑定连接）或 ' +
          'scope:"external"（无绑定连接，补 reason + SQL/代码证据）；动态表名（无法还原）→ ' +
          'dynamicPatterns[]（pattern/path/line/reason）；身份/归属无法判断 → 红停/blocked，等人工或上游补齐。' +
          '恢复动作：重跑 Agent A 产出 schemaVersion:2。',
      ),
    );
  }

  // §5.2.2：首轮增量的主来源是代码；空候选必须红，DB 目录完整/DB-only 都不能替代代码证据。
  // 合法空结构不在这里：它发生在候选非空、但逐源 codeTable 交集为空时，由 B/C 放行空 plan/evidence。
  const noCandidates = tables.length === 0;
  if (noCandidates) {
    failures.push(
      failure(
        'TABLE_INVENTORY_EMPTY',
        '$.tables',
        'tables 为空：首轮增量必须由 Agent A 提供可复核的代码证据（Java/JPA/字符串定位）；' +
          '目录完整或 DB-only 分类不能替代代码证据，unresolved 也不能替代候选',
      ),
    );
  }

  const bindingNames = Array.isArray(input.bindingNames)
    ? new Set(input.bindingNames.filter(nonEmpty).map((name) => name.trim()))
    : null;
  const bindingList = bindingNames ? [...bindingNames] : [];

  const dbRead = normalizeDbList(dbTableList, dialect);
  if (!dbRead.ok) failures.push(...(dbRead.failures || []));
  const dbSources = dbRead.sources || new Map();
  const dbSourceFor = (ds) => {
    if (dbSources.has(ds)) return dbSources.get(ds);
    // 单源兼容：legacy 顶层没有 dataSourceName 时，目录对任意单一来源生效。
    if (dbSources.size === 1) {
      const only = [...dbSources.values()][0];
      if (!only.dataSourceName) return only;
    }
    return null;
  };
  const missingSourceReported = new Set();
  const resolveEntryDataSource = (entry, at) => {
    const explicit = nonEmpty(entry.dataSourceName) ? entry.dataSourceName.trim() : '';
    if (explicit) {
      if (bindingNames && bindingNames.size > 0 && !bindingNames.has(explicit)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_DATASOURCE',
            `${at}.dataSourceName`,
            `dataSourceName 必须是已确认绑定之一（${bindingList.join(', ')}），实际 ${JSON.stringify(entry.dataSourceName)}`,
          ),
        );
      }
      return explicit;
    }
    if (bindingNames && bindingNames.size > 1) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DATASOURCE',
          `${at}.dataSourceName`,
          `存在多个已确认绑定（${bindingList.join(', ')}），表条目必须显式 dataSourceName（不得猜默认源）`,
        ),
      );
      return '';
    }
    if (bindingNames && bindingNames.size === 1) return bindingList[0];
    if (dbSources.size === 1) {
      const only = [...dbSources.values()][0];
      if (only.dataSourceName) return only.dataSourceName;
    }
    if (dbSources.size > 1) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DATASOURCE',
          `${at}.dataSourceName`,
          'db-table-list 有多个数据源，表条目必须显式 dataSourceName（不得猜默认源）',
        ),
      );
    }
    return '';
  };
  const dbNamesFor = (ds) => {
    const source = dbSourceFor(ds);
    if (!source) {
      if (dbSources.size > 0 && !missingSourceReported.has(ds) && ds) {
        missingSourceReported.add(ds);
        failures.push(
          failure(
            'TABLE_INVENTORY_DB_LIST',
            '$db-table-list',
            `缺少 dataSourceName=${ds} 的目录：多数据源 preflight 必须逐源产出（不得只跑一个源）`,
          ),
        );
      }
      return [];
    }
    return source.names;
  };
  const scan = isPlainObject(input.scan) ? input.scan : null;
  const mechanical = new Map();
  if (scan) {
    if (scan.kind !== 'code-table-scan' || !Array.isArray(scan.tables)) {
      failures.push(failure('TABLE_INVENTORY_SCAN', '$scan', '预扫文件 shape 非法（kind/tables），拒绝静默跳过'));
    } else {
      for (const entry of scan.tables) {
        if (!isPlainObject(entry) || !nonEmpty(entry.table) || !Array.isArray(entry.evidence)) continue;
        mechanical.set(foldIdentifier(dialect, entry.table), entry);
      }
    }
  }
  const dynamicFromScan = scan && Array.isArray(scan.dynamic) ? scan.dynamic.filter(isPlainObject) : [];

  // ── dynamicPatterns[]（v2 独立桶）──────────────────────────────────────────
  // 每条必须带 pattern/path/line/reason；pattern 必须含动态标记；禁止 table 字段
  // （一旦有 table，它就不是"无法还原表名的动态模式"，应进 tables[] 并标 scope）。
  const validDynamicPatterns = [];
  for (const [index, entry] of dynamicPatterns.entries()) {
    const at = `$.dynamicPatterns[${index}]`;
    if (!isPlainObject(entry)) {
      failures.push(failure('TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID', at, 'dynamicPatterns 条目必须是对象'));
      continue;
    }
    let entryValid = true;
    if (Object.prototype.hasOwnProperty.call(entry, 'table')) {
      entryValid = false;
      failures.push(
        failure(
          'TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID',
          `${at}.table`,
          'dynamicPatterns 禁止 table 字段：能给出具体表名就不是动态模式，应进 tables[] 并标 scope:"bound"|"external"',
        ),
      );
    }
    if (!nonEmpty(entry.pattern)) {
      entryValid = false;
      failures.push(failure('TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID', `${at}.pattern`, 'dynamicPatterns.pattern 必须为非空字符串'));
    } else if (!isDynamicPattern(entry.pattern)) {
      entryValid = false;
      failures.push(
        failure(
          'TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID',
          `${at}.pattern`,
          `动态模式 ${JSON.stringify(entry.pattern)} 不含动态标记（\${...} / #{...} / * / %s / 拼接 +）：` +
            '普通标识符是具体表，必须进 tables[] 并标 scope',
        ),
      );
    }
    if (!nonEmpty(entry.path)) {
      entryValid = false;
      failures.push(failure('TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID', `${at}.path`, 'dynamicPatterns.path 必须为非空字符串（真实代码/SQL 位置）'));
    }
    if (!Number.isInteger(entry.line) || entry.line <= 0) {
      entryValid = false;
      failures.push(failure('TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID', `${at}.line`, 'dynamicPatterns.line 必须为正整数'));
    }
    if (!nonEmpty(entry.reason)) {
      entryValid = false;
      failures.push(failure('TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID', `${at}.reason`, 'dynamicPatterns.reason 必须为非空字符串'));
    }
    if (entryValid) validDynamicPatterns.push(entry);
  }

  const candidateKeys = new Set();
  const candidates = [];
  const evidenceMeta = new Map();
  const textCache = new Map();
  const readCached = (abs) => {
    if (!textCache.has(abs)) textCache.set(abs, safeRead(abs));
    return textCache.get(abs);
  };
  // 行索引按本次 run 缓存（键 = 绝对路径）：同一文件的多条证据共用一份偏移表。
  const lineIndex = createLineIndexCache();

  const validEvidenceFor = (entry, index) => {
    const at = `$.tables[${index}]`;
    const list = Array.isArray(entry.evidence) ? entry.evidence : [];
    if (list.length === 0) {
      failures.push(failure('TABLE_INVENTORY_EVIDENCE_MISSING', `${at}.evidence`, '每条表名必须有证据（禁无证据候选）'));
      return [];
    }
    const valid = [];
    for (const [evIndex, evidence] of list.entries()) {
      const eAt = `${at}.evidence[${evIndex}]`;
      if (!isPlainObject(evidence)) {
        failures.push(failure('TABLE_INVENTORY_EVIDENCE_INVALID', eAt, 'evidence 条目必须是对象'));
        continue;
      }
      if (!EVIDENCE_KINDS.has(evidence.kind)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_EVIDENCE_INVALID',
            `${eAt}.kind`,
            `未知证据类型 ${JSON.stringify(evidence.kind)}（允许：${[...EVIDENCE_KINDS].join('/')}）`,
          ),
        );
        continue;
      }
      const resolved = resolveEvidencePath(rootDir, evidence.path);
      if (!resolved.ok) {
        failures.push(failure('TABLE_INVENTORY_EVIDENCE_INVALID', `${eAt}.path`, resolved.message));
        continue;
      }
      if (evidence.line !== undefined && (!Number.isInteger(evidence.line) || evidence.line <= 0)) {
        failures.push(failure('TABLE_INVENTORY_EVIDENCE_INVALID', `${eAt}.line`, 'line 省略时不写；写了必须为正整数'));
        continue;
      }
      const text = readCached(resolved.abs);
      if (text == null) {
        failures.push(failure('TABLE_INVENTORY_EVIDENCE_INVALID', `${eAt}.path`, `证据文件不可读或超过 ${MAX_FILE_BYTES} 字节`));
        continue;
      }
      const evidenceText = evidence.line !== undefined ? lineIndex.lineAt(resolved.abs, text, evidence.line) : text;
      if (evidenceText == null) {
        failures.push(
          failure(
            'TABLE_INVENTORY_EVIDENCE_INVALID',
            `${eAt}.line`,
            `line 超出文件行数：${evidence.line}（${evidence.path} 共 ${lineIndex.lineCount(resolved.abs, text)} 行）`,
          ),
        );
        continue;
      }
      if (containsIdentifier(evidenceText, entry.table, dialect)) {
        valid.push({ ...evidence, text });
        continue;
      }
      failures.push(
        failure(
          'TABLE_INVENTORY_EVIDENCE_UNVERIFIED',
          `${eAt}`,
          `证据${evidence.line !== undefined ? `第 ${evidence.line} 行` : '文件文本'}中找不到表名 "${entry.table}"` +
            `（path=${evidence.path}；按方言 ${dialect || 'unknown'} 归一比较）：不得以编造证据放行`,
        ),
      );
    }
    return valid;
  };

  for (const [index, entry] of tables.entries()) {
    const at = `$.tables[${index}]`;
    if (!isPlainObject(entry)) {
      failures.push(failure('TABLE_INVENTORY_SCHEMA', at, 'table 条目必须是对象'));
      continue;
    }
    const table = nonEmpty(entry.table) ? entry.table.trim() : '';
    if (!table || !/^[A-Za-z_][A-Za-z0-9_$]*$/.test(table)) {
      failures.push(
        failure('TABLE_INVENTORY_IDENTIFIER', `${at}.table`, `表名必须是合法裸标识符（^[A-Za-z_][A-Za-z0-9_$]*$），实际 ${JSON.stringify(entry.table)}`),
      );
      continue;
    }
    const scope = entry.scope;
    const validScope = SCOPES.has(scope);
    if (!validScope) {
      failures.push(
        failure(
          'TABLE_INVENTORY_SCOPE',
          `${at}.scope`,
          `每条 tables[] 必须标 scope:"bound"|"external"，实际 ${JSON.stringify(entry.scope)}；` +
            '具体表+有绑定连接 → bound，具体表+无绑定连接 → external，动态表名进 dynamicPatterns[]',
        ),
      );
    }

    // scope 决定连接信息：external 禁止 dataSourceName；bound 走绑定解析（单体可省略）。
    let ds = '';
    if (scope === 'bound') {
      ds = resolveEntryDataSource(entry, at);
    } else if (scope === 'external') {
      if (entry.dataSourceName !== undefined) {
        failures.push(
          failure(
            'TABLE_INVENTORY_SCOPE_CONFLICT',
            `${at}.dataSourceName`,
            'scope:"external" 表示无绑定连接，禁止 dataSourceName；若该表属于已确认绑定，应改 scope:"bound"',
          ),
        );
      }
      if (!nonEmpty(entry.reason)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_EXTERNAL_EVIDENCE',
            `${at}.reason`,
            'scope:"external" 必须写非空 reason（说明独立库/外部库归属，如 SQL 中的 CREATE DATABASE/USE/独立库路径）',
          ),
        );
      }
      if (entry.confidence !== 'agent-asserted') {
        failures.push(
          failure(
            'TABLE_INVENTORY_EXTERNAL_EVIDENCE',
            `${at}.confidence`,
            `scope:"external" 是 agent 归属判断，confidence 必须为 "agent-asserted"，实际 ${JSON.stringify(entry.confidence)}`,
          ),
        );
      }
      if (entry.decision === 'create') {
        failures.push(
          failure(
            'TABLE_INVENTORY_EXTERNAL_CREATE',
            `${at}.decision`,
            'scope:"external" 的表永不进 delta，不得写 decision:"create"；门 A 强制 decision:"external"',
          ),
        );
      } else if (entry.decision !== undefined && entry.decision !== 'external') {
        failures.push(
          failure(
            'TABLE_INVENTORY_SCOPE_CONFLICT',
            `${at}.decision`,
            `scope:"external" 的 decision 只能是 "external"（可省略由门 A 补写），实际 ${JSON.stringify(entry.decision)}`,
          ),
        );
      }
    }

    const folded = foldIdentifier(dialect, table);
    // 身份 = (dataSourceName, 方言折叠表名)：不同源同名表合法；同一源内重复才红。
    const key = `${ds}\u0000${folded}`;
    if (candidateKeys.has(key)) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DUPLICATE',
          `${at}.table`,
          `同一数据源 ${ds || '<unknown>'} 内按方言归一后重复的表名：${table}（key=${folded}）`,
        ),
      );
    }
    candidateKeys.add(key);

    if (!CONFIRMED_KINDS.has(entry.confidence)) {
      failures.push(
        failure('TABLE_INVENTORY_CONFIDENCE', `${at}.confidence`, `confidence 必须是 mechanical | agent-asserted，实际 ${JSON.stringify(entry.confidence)}`),
      );
    }
    if (entry.dynamic !== undefined && typeof entry.dynamic !== 'boolean') {
      failures.push(failure('TABLE_INVENTORY_SCHEMA', `${at}.dynamic`, 'dynamic 省略时不写；写了必须是布尔值'));
    }

    const validEvidence = validEvidenceFor(entry, index);
    const codeEvidence = validEvidence.filter((evidence) => CODE_EVIDENCE_KINDS.has(evidence.kind));
    // external 需要真实 SQL/代码位置；只有 SQL 证据时还必须能证明独立库/外部库归属
    // （CREATE DATABASE / USE / 连接串库路径），不能只凭表名猜。
    if (scope === 'external') {
      const sqlEvidence = codeEvidence.filter((evidence) => ['sql', 'migration', 'delta-sql'].includes(evidence.kind));
      const nonSqlEvidence = codeEvidence.filter((evidence) => !['sql', 'migration', 'delta-sql'].includes(evidence.kind));
      if (codeEvidence.length === 0) {
        failures.push(
          failure(
            'TABLE_INVENTORY_EXTERNAL_EVIDENCE',
            `${at}.evidence`,
            'scope:"external" 必须有真实 SQL/代码证据（SQL 文件里的 CREATE DATABASE/USE/独立库路径，或绑定之外的代码位置）',
          ),
        );
      } else if (sqlEvidence.length > 0 && nonSqlEvidence.length === 0) {
        const proving = sqlEvidence.some((evidence) => EXTERNAL_DB_SCOPE_EVIDENCE.test(String(evidence.text ?? '')));
        if (!proving) {
          failures.push(
            failure(
              'TABLE_INVENTORY_EXTERNAL_EVIDENCE',
              `${at}.evidence`,
              'scope:"external" 的 SQL 证据未体现独立库/外部库归属：evidence 文件需含 ' +
                'CREATE DATABASE / USE <db> / 连接串库路径 / database|schema 声明，不能按表名猜',
            ),
          );
        }
      }
    }
    const inMechanical = mechanical.has(folded);
    if (entry.confidence === 'mechanical' && !inMechanical) {
      failures.push(
        failure(
          'TABLE_INVENTORY_HALLUCINATION',
          at,
          `confidence=mechanical 但 "${table}" 不在确定性预扫已知表集：不得把 agent 推断冒充机械事实`,
        ),
      );
    }
    if (entry.confidence === 'agent-asserted' && codeEvidence.length === 0) {
      failures.push(
        failure(
          'TABLE_INVENTORY_HALLUCINATION',
          at,
          `confidence=agent-asserted 但 "${table}" 没有可复核的代码文本证据（Java/JPA/字符串/SQL）：无证据 = 红`,
        ),
      );
    }
    if (!inMechanical && codeEvidence.length === 0) {
      failures.push(
        failure(
          'TABLE_INVENTORY_HALLUCINATION',
          at,
          `候选 "${table}" 不在机械已知表集，且没有代码证据（候选必须 ⊆ 机械已知表集 ∪ agent 代码证据）`,
        ),
      );
    }

    // 动态证据位置必须标 dynamic:true（漏标 = 把运行时表名当静态表）。
    // 位置按「同一行」精确匹配：预扫与证据行号来自同一套行索引；放宽窗口会把邻近的静态表
    // （如 mapper 里紧挨着动态语句的 sys_user）误判成动态表。
    const sameLocation = (evidence, dyn) =>
      nonEmpty(dyn.path) &&
      evidence.path === dyn.path &&
      (dyn.line == null || evidence.line == null || Number(evidence.line) === Number(dyn.line));
    // 动态命中按「证据声明的 path/line」判定（不依赖该行文本是否通过证据校验——
    // 证据行不匹配会另行判 EVIDENCE_UNVERIFIED，不能因此吞掉动态漏标）。
    const rawEvidence = Array.isArray(entry.evidence) ? entry.evidence.filter(isPlainObject) : [];
    const dynamicHit = dynamicFromScan.find((dyn) => rawEvidence.some((evidence) => sameLocation(evidence, dyn)));
    if (dynamicHit && entry.dynamic !== true) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DYNAMIC_FLAG',
          `${at}.dynamic`,
          `证据位置 ${dynamicHit.path}${dynamicHit.line ? `:${dynamicHit.line}` : ''} 命中动态表名 ${dynamicHit.pattern}，必须标 dynamic:true`,
        ),
      );
    }

    candidates.push({
      table,
      key,
      folded,
      ds,
      scope: validScope ? scope : null,
      entry,
      // external 不属于任何已确认绑定：永不参与 bound 的 codeOnly / delta 分类。
      inDb: scope === 'bound' && dbNamesFor(ds).some((name) => name.key === folded),
      inMechanical,
      validEvidence,
    });
    evidenceMeta.set(key, { dynamicHit });
  }

  // 漏表：机械已知表集必须出现在 tables[] 或 dynamicPatterns[]（两桶并集，按折叠名判）。
  const candidateFolded = new Set(candidates.map((candidate) => candidate.folded));
  const dynamicPatternFolded = new Set(
    validDynamicPatterns.map((entry) => foldIdentifier(dialect, String(entry.pattern).trim())),
  );
  for (const [key, entry] of mechanical) {
    if (candidateFolded.has(key) || dynamicPatternFolded.has(key)) continue;
    failures.push(
      failure(
        'TABLE_INVENTORY_MECHANICAL_MISSING',
        '$.tables',
        `漏表：机械已知表 "${entry.table}" 未出现在 tables[] 或 dynamicPatterns[]（机械来源：${entry.evidence
          .slice(0, 3)
          .map((evidence) => `${evidence.kind}:${evidence.path}:${evidence.line}`)
          .join(' / ')}）`,
      ),
    );
  }

  // 动态表名不得静默消失：每个动态位置必须被 dynamic:true 候选或 dynamicPatterns[] 承接。
  // statementKind（plan 2026-11-09 §3.1）决定失败码：
  //   dml     → 允许停泊在 dynamicPatterns[]；完全未承接才红 DYNAMIC_MISSING；
  //   ddl     → 必须由 tables[] 的 dynamic:true 承接（DDL 可能建表，不得停泊在动态桶）；
  //   unknown → 同上（无法证明其不建表，不得当 skip 或静默 complete）。
  // 旧 scan（无 statementKind）按 unknown 处理：不可判 = 红，不静默放行。
  const dynLocationMatches = (dyn, evidence) =>
    evidence.path === dyn.path &&
    (dyn.line == null || evidence.line == null || Number(evidence.line) === Number(dyn.line));
  const dynPatternMatches = (entry, dyn) =>
    (nonEmpty(entry.pattern) && entry.pattern === dyn.pattern) ||
    (nonEmpty(entry.path) &&
      entry.path === dyn.path &&
      (dyn.line == null || entry.line == null || Number(entry.line) === Number(dyn.line)));
  const resolvedByDynamicTable = (dyn) =>
    candidates.some(
      (candidate) =>
        candidate.entry.dynamic === true &&
        candidate.validEvidence.some((evidence) => dynLocationMatches(dyn, evidence)),
    );
  for (const dyn of dynamicFromScan) {
    const statementKind = normalizeStatementKind(dyn.statementKind);
    const resolved = candidates.some((candidate) => {
      const hit = evidenceMeta.get(candidate.key)?.dynamicHit;
      return hit === dyn || (
        candidate.entry.dynamic === true &&
        candidate.validEvidence.some((evidence) => dynLocationMatches(dyn, evidence))
      );
    });
    const dynamicPatternHit = validDynamicPatterns.some((entry) => dynPatternMatches(entry, dyn));
    const where = `${dyn.pattern}（${dyn.path}${dyn.line ? `:${dyn.line}` : ''}）`;
    if (statementKind === 'ddl') {
      if (!resolvedByDynamicTable(dyn)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_DYNAMIC_DDL_UNRESOLVED',
            '$.dynamicPatterns',
            `动态表名 ${where} 处于 DDL 上下文（statementKind=ddl），未被 tables[] 的 dynamic:true 承接：` +
              'DDL 可能创建表，不得停泊在 dynamicPatterns[]。恢复动作：解析为具体表写入 tables[]' +
              '（confidence:agent-asserted，evidence 指向真实 DDL 行）并标 dynamic:true；' +
              '若属于独立库/外部库则写 scope:"external" + 非空 reason + 独立库证据（CREATE DATABASE/USE/连接串）。',
          ),
        );
      }
      continue;
    }
    if (statementKind === 'unknown') {
      if (!resolvedByDynamicTable(dyn)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_DYNAMIC_CONTEXT_UNKNOWN',
            '$.dynamicPatterns',
            `动态表名 ${where} 的语句上下文不可判（statementKind=unknown），未被 tables[] 的 dynamic:true 承接：` +
              '无法证明它不会建表，不得当 skip 或静默 complete。恢复动作：补证据把它解析为 tables[] 中的具体表' +
              '（evidence 指向真实语句行），或写 scope:"external" + 独立库证据；' +
              '若扫描未覆盖真实语句，补扫描覆盖后重跑 prescan。',
          ),
        );
      }
      continue;
    }
    // dml：维持现有承接规则（dynamic:true 候选或 dynamicPatterns[] 任一即可）。
    if (!resolved && !dynamicPatternHit) {
      failures.push(
        failure(
          'TABLE_INVENTORY_DYNAMIC_MISSING',
          '$.dynamicPatterns',
          `动态表名 ${where} 未被 dynamic:true 候选或 ` +
            'dynamicPatterns[] 承接：动态表名不得静默丢',
        ),
      );
    }
  }

  // inventory 里的每条动态模式都必须能在 scan.dynamic[] 找到权威上下文（statementKind 单一来源）；
  // 匹配不到 → 按 unknown 处理并红：Agent A 不能靠自述把未知上下文塞进动态桶。
  for (const entry of validDynamicPatterns) {
    if (dynamicFromScan.some((dyn) => dynPatternMatches(entry, dyn))) continue;
    failures.push(
      failure(
        'TABLE_INVENTORY_DYNAMIC_CONTEXT_UNKNOWN',
        '$.dynamicPatterns',
        `动态模式 ${entry.pattern}（${entry.path}${entry.line ? `:${entry.line}` : ''}）无法按 pattern 或 path+line ` +
          '匹配 code-table-scan.json#/dynamic[] 条目，按 statementKind=unknown 处理：无法证明它不会建表。' +
          '恢复动作：补扫描覆盖（重跑 prescan 后重跑 Agent A），或把它解析为 tables[] 中的具体表 + 证据 / scope:"external"。',
      ),
    );
  }

  // 分类：按 (dataSourceName, 表) 维度；顶层保留单源兼容的裸表名汇总。
  // external 单独成桶：永不进 codeOnly/create/delta。
  const boundCandidates = candidates.filter((candidate) => candidate.scope === 'bound');
  const externalCandidates = candidates.filter((candidate) => candidate.scope === 'external');
  const codeCandidates = boundCandidates.filter((candidate) => candidate.inDb);
  const codeOnly = boundCandidates.filter((candidate) => !candidate.inDb);
  const uniqueSorted = (items) => [...new Set(items)].sort();
  const candidatesOfSource = (ds) => {
    // 只把 bound 候选归到数据源；external 无连接信息，不参与逐源分类。
    if (ds) return boundCandidates.filter((candidate) => candidate.ds === ds);
    return boundCandidates;
  };
  const sourceDetails = [];
  const dbOnlyNames = [];
  for (const [ds, source] of [...dbSources.entries()].sort(([a], [b]) => a.localeCompare(b))) {
    const sourceCandidates = candidatesOfSource(source.dataSourceName);
    const sourceCodeTables = uniqueSorted(
      sourceCandidates.filter((candidate) => candidate.inDb).map((candidate) => candidate.table),
    );
    const sourceCodeOnly = sourceCandidates.filter((candidate) => !candidate.inDb);
    const sourceCreateTables = uniqueSorted(
      sourceCodeOnly
        .filter((candidate) => candidate.entry.decision === 'create')
        .map((candidate) => candidate.table),
    );
    const sourceKeys = new Set(sourceCandidates.map((candidate) => candidate.folded));
    // 空候选已经红：不得把整库表当成「成功分类出的 DB-only」。
    const sourceDbOnly = noCandidates
      ? []
      : source.names
          .filter((name) => !sourceKeys.has(name.key))
          .map((name) => name.raw)
          .sort();
    dbOnlyNames.push(...sourceDbOnly);
    sourceDetails.push({
      dataSourceName: source.dataSourceName || ds || null,
      codeTables: sourceCodeTables,
      codeOnly: sourceCodeOnly.map((candidate) => ({
        table: candidate.table,
        decision: DECISIONS.has(candidate.entry.decision) ? candidate.entry.decision : null,
        reason: nonEmpty(candidate.entry.reason) ? candidate.entry.reason : null,
        dataSourceName: nonEmpty(candidate.entry.dataSourceName)
          ? candidate.entry.dataSourceName
          : candidate.ds || null,
      })),
      createTables: sourceCreateTables,
      dbOnly: sourceDbOnly,
    });
  }

  for (const candidate of codeOnly) {
    const at = `$.tables[${tables.indexOf(candidate.entry)}]`;
    if (requireDecisions) {
      if (!DECISIONS.has(candidate.entry.decision)) {
        failures.push(
          failure(
            'TABLE_INVENTORY_CODE_ONLY_DECISION',
            `${at}.decision`,
            `codeOnly 表 "${candidate.table}" 必须给 decision: create | external | ignore + reason（只有 create 进 delta）`,
          ),
        );
      }
      if (!nonEmpty(candidate.entry.reason)) {
        failures.push(
          failure('TABLE_INVENTORY_CODE_ONLY_DECISION', `${at}.reason`, `codeOnly 表 "${candidate.table}" 的 decision 必须附非空 reason`),
        );
      }
    }
  }
  for (const candidate of candidates) {
    if (candidate.inDb && candidate.entry.decision !== undefined) {
      const at = `$.tables[${tables.indexOf(candidate.entry)}]`;
      failures.push(
        failure('TABLE_INVENTORY_DECISION_MISPLACED', `${at}.decision`, `decision 只用于 codeOnly 表；"${candidate.table}" 已存在于 DB，不得写 decision`),
      );
    }
  }

  return {
    ok: failures.length === 0,
    failures,
    classification: {
      codeTables: uniqueSorted(codeCandidates.map((candidate) => candidate.table)),
      codeOnly: codeOnly.map((candidate) => ({
        table: candidate.table,
        decision: DECISIONS.has(candidate.entry.decision) ? candidate.entry.decision : null,
        reason: nonEmpty(candidate.entry.reason) ? candidate.entry.reason : null,
        dataSourceName: nonEmpty(candidate.entry.dataSourceName)
          ? candidate.entry.dataSourceName
          : candidate.ds || null,
      })),
      createTables: uniqueSorted(
        codeOnly
          .filter((candidate) => candidate.entry.decision === 'create')
          .map((candidate) => candidate.table),
      ),
      // scope:"external" 的处置恒为 external（门 A 校验/补写），永不进 delta。
      externalTables: uniqueSorted(externalCandidates.map((candidate) => candidate.table)),
      dbOnly: uniqueSorted(dbOnlyNames),
      sources: sourceDetails,
    },
    summary: {
      candidateCount: candidates.length,
      codeTableCount: codeCandidates.length,
      codeOnlyCount: codeOnly.length,
      externalCount: externalCandidates.length,
      dbOnlyCount: uniqueSorted(dbOnlyNames).length,
      unresolvedCount,
      mechanicalCount: mechanical.size,
      dynamicPatternCount: validDynamicPatterns.length,
      dynamicCount: dynamicFromScan.length,
      sourceCount: sourceDetails.length,
      ...(noCandidates ? { emptyReason: 'TABLE_INVENTORY_EMPTY' } : {}),
    },
  };
}

// ─── self-test ──────────────────────────────────────────────────────────────

/**
 * 自测（`--self-test`）：锁住 v2 关键判据（scope / external / dynamicPatterns / unresolved / 漏表）。
 * 返回失败文案数组；空数组 = 通过。
 */
function selfTest() {
  const failures = [];
  const expectCode = (name, verdict, expected) => {
    const actual = verdict && Array.isArray(verdict.failures) ? verdict.failures.map((entry) => entry.code) : [];
    if (!actual.includes(expected)) failures.push(`${name}: 期望 ${expected}，实际 ${JSON.stringify(actual)}`);
  };
  const root = mkdtempSync(join(tmpdir(), 'code-table-inventory-self-test-'));
  const canonicalSql =
    "SELECT TABLE_NAME AS table_name FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME LIMIT 500 OFFSET 0";
  try {
    const externalSql = 'sql/ry-seata/database.sql';
    mkdirSync(join(root, 'sql', 'ry-seata'), { recursive: true });
    writeFileSync(
      join(root, externalSql),
      '-- Seata transaction store\nCREATE DATABASE `ry-seata`;\nUSE `ry-seata`;\nCREATE TABLE global_table (id bigint);\n',
      'utf-8',
    );
    writeFileSync(join(root, 'app.sql'), 'CREATE TABLE sys_user (id bigint);\n', 'utf-8');
    const evidence = (path, line) => [{ kind: 'sql', path, line }];
    const bound = {
      table: 'sys_user',
      scope: 'bound',
      dataSourceName: 'ds-main',
      confidence: 'mechanical',
      evidence: evidence('app.sql', 1),
    };
    const external = {
      table: 'global_table',
      scope: 'external',
      confidence: 'agent-asserted',
      reason: 'Seata 独立库 ry-seata：SQL 含 CREATE DATABASE/USE，非已确认绑定',
      evidence: evidence(externalSql, 4),
    };
    const dbTableList = {
      kind: 'db-table-list',
      tableNames: ['sys_user'],
      tableNameColumn: 'table_name',
      rowCount: 1,
      truncated: false,
    };
    const scan = {
      kind: 'code-table-scan',
      tables: [
        { table: 'sys_user', evidence: evidence('app.sql', 1) },
        { table: 'global_table', evidence: evidence(externalSql, 4) },
      ],
      dynamic: [],
    };
    const inventoryOf = (overrides = {}) => ({
      schemaVersion: 2,
      generatedBy: 'self-test/code-table-inventory',
      catalog: { dialect: 'mysql', listTablesSql: canonicalSql, dataSourceName: 'ds-main' },
      tables: [bound, external],
      dynamicPatterns: [],
      ...overrides,
    });
    const validate = (overrides = {}, extra = {}) =>
      validateCodeTableInventory({
        inventory: inventoryOf(overrides),
        dbTableList,
        scan,
        rootDir: root,
        bindingNames: ['ds-main'],
        ...extra,
      });
    const without = (entry, key) => {
      const copy = { ...entry };
      delete copy[key];
      return copy;
    };

    // 1) 合法 bound + external → 通过；external 不进 createTables。
    const ok = validate();
    if (!ok.ok) failures.push(`合法 bound+external: 期望通过，实际 ${JSON.stringify(ok.failures.map((f) => f.code))}`);
    if (!ok.classification.externalTables.includes('global_table')) failures.push('合法 external: externalTables 应含 global_table');
    if (ok.classification.createTables.length > 0) failures.push('合法 external: external 不得进 createTables');

    // 2) v1 → 版本守卫（不做自动投影）。
    expectCode('v1 版本守卫', validate({ schemaVersion: 1 }), 'TABLE_INVENTORY_VERSION_LEGACY');
    // 3) unresolved 非空 → 见即红。
    expectCode(
      'unresolved 禁止',
      validate({ unresolved: [{ table: 'global_table', reason: '旧习惯' }] }),
      'TABLE_INVENTORY_UNRESOLVED_FORBIDDEN',
    );
    // 4) 缺 scope。
    expectCode(
      '缺 scope',
      validate({ tables: [{ ...bound, scope: undefined }, external] }),
      'TABLE_INVENTORY_SCOPE',
    );
    // 5) 多绑定下 bound 缺 dataSourceName。
    expectCode(
      'bound 缺 dataSourceName',
      validate({ tables: [without(bound, 'dataSourceName'), external] }, { bindingNames: ['ds1', 'ds2'] }),
      'TABLE_INVENTORY_DATASOURCE',
    );
    // 6) external 带 dataSourceName。
    expectCode(
      'external 带 dataSourceName',
      validate({ tables: [bound, { ...external, dataSourceName: 'ds-main' }] }),
      'TABLE_INVENTORY_SCOPE_CONFLICT',
    );
    // 7) external 缺 reason。
    expectCode(
      'external 缺 reason',
      validate({ tables: [bound, without(external, 'reason')] }),
      'TABLE_INVENTORY_EXTERNAL_EVIDENCE',
    );
    // 8) external + decision:create。
    expectCode(
      'external + create',
      validate({ tables: [bound, { ...external, decision: 'create' }] }),
      'TABLE_INVENTORY_EXTERNAL_CREATE',
    );
    // 9) dynamicPatterns 普通标识符 / 带 table 字段。
    expectCode(
      '动态模式普通标识符',
      validate({ dynamicPatterns: [{ pattern: 'global_table', path: 'app.sql', line: 1, reason: 'x' }] }),
      'TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID',
    );
    expectCode(
      '动态模式带 table 字段',
      validate({ dynamicPatterns: [{ pattern: '${p}_log', table: 'x', path: 'app.sql', line: 1, reason: 'x' }] }),
      'TABLE_INVENTORY_DYNAMIC_PATTERN_INVALID',
    );
    // 10) 动态位置由 dynamicPatterns[] 承接（不再用 unresolved）。
    const dynamicScan = {
      ...scan,
      dynamic: [{ pattern: '${p}_log', kind: 'mapper-xml', path: 'app.sql', line: 1, statementKind: 'dml' }],
    };
    const covered = validate(
      { dynamicPatterns: [{ pattern: '${p}_log', path: 'app.sql', line: 1, reason: '动态表名' }] },
      { scan: dynamicScan },
    );
    if (covered.failures.some((entry) => entry.code === 'TABLE_INVENTORY_DYNAMIC_MISSING')) {
      failures.push('动态覆盖: 合法 dynamicPatterns 不应判 DYNAMIC_MISSING');
    }
    // 11) 机械漏表基准 = tables[] ∪ dynamicPatterns[]。
    expectCode(
      '机械漏表',
      validate({ tables: [bound], dynamicPatterns: [] }),
      'TABLE_INVENTORY_MECHANICAL_MISSING',
    );

    // 12) 扫描器：mapper `<select>` 内的动态名 → dml；`.sql` 的 CREATE TABLE ${t} → ddl；
    //     mapper `<sql>` 片段（无语句上下文）→ unknown。
    const scannerRoot = join(root, 'scanner-fixtures');
    mkdirSync(join(scannerRoot, 'mapper'), { recursive: true });
    mkdirSync(join(scannerRoot, 'sql'), { recursive: true });
    writeFileSync(
      join(scannerRoot, 'mapper', 'LogMapper.xml'),
      '<mapper namespace="x">\n  <select id="q">SELECT * FROM ${p}_log</select>\n</mapper>\n',
      'utf-8',
    );
    writeFileSync(
      join(scannerRoot, 'mapper', 'FragMapper.xml'),
      '<mapper namespace="x">\n  <sql id="cols">FROM ${q}_log</sql>\n</mapper>\n',
      'utf-8',
    );
    writeFileSync(join(scannerRoot, 'sql', 'ddl.sql'), 'CREATE TABLE ${t} (id bigint);\n', 'utf-8');
    const scanner = scanMechanicalTables({ rootDir: scannerRoot });
    const statementKindOf = (pattern) => {
      const hit = scanner.dynamic.find((entry) => entry.pattern === pattern);
      return hit ? hit.statementKind : undefined;
    };
    if (statementKindOf('${p}_log') !== 'dml') {
      failures.push(`扫描器 mapper <select>: 期望 statementKind=dml，实际 ${JSON.stringify(statementKindOf('${p}_log'))}`);
    }
    if (statementKindOf('${t}') !== 'ddl') {
      failures.push(`扫描器 .sql CREATE TABLE: 期望 statementKind=ddl，实际 ${JSON.stringify(statementKindOf('${t}'))}`);
    }
    if (statementKindOf('${q}_log') !== 'unknown') {
      failures.push(`扫描器 <sql> 片段: 期望 statementKind=unknown，实际 ${JSON.stringify(statementKindOf('${q}_log'))}`);
    }

    // 13) 门 A：dml 动态模式放行；ddl → DDL_UNRESOLVED；unknown → CONTEXT_UNKNOWN。
    const dmlGate = validate(
      { dynamicPatterns: [{ pattern: '${p}_log', path: 'app.sql', line: 1, reason: '运行时拼接' }] },
      { scan: { ...scan, dynamic: [{ pattern: '${p}_log', kind: 'mapper-xml', path: 'mapper/LogMapper.xml', line: 1, statementKind: 'dml' }] } },
    );
    for (const code of [
      'TABLE_INVENTORY_DYNAMIC_DDL_UNRESOLVED',
      'TABLE_INVENTORY_DYNAMIC_CONTEXT_UNKNOWN',
      'TABLE_INVENTORY_DYNAMIC_MISSING',
    ]) {
      if (dmlGate.failures.some((entry) => entry.code === code)) {
        failures.push(`门 A dml 放行: 不应出现 ${code}`);
      }
    }
    expectCode(
      '门 A ddl 未解析',
      validate(
        { dynamicPatterns: [{ pattern: '${t}', path: 'app.sql', line: 1, reason: 'DDL 动态表名' }] },
        { scan: { ...scan, dynamic: [{ pattern: '${t}', kind: 'sql', path: 'sql/dynamic.sql', line: 1, statementKind: 'ddl' }] } },
      ),
      'TABLE_INVENTORY_DYNAMIC_DDL_UNRESOLVED',
    );
    expectCode(
      '门 A unknown 上下文',
      validate(
        { dynamicPatterns: [{ pattern: '${q}_log', path: 'app.sql', line: 1, reason: '<sql> 片段' }] },
        { scan: { ...scan, dynamic: [{ pattern: '${q}_log', kind: 'mapper-xml', path: 'mapper/FragMapper.xml', line: 1, statementKind: 'unknown' }] } },
      ),
      'TABLE_INVENTORY_DYNAMIC_CONTEXT_UNKNOWN',
    );
    // 14) inventory 动态模式在 scan 里匹配不到权威上下文 → 按 unknown 红。
    expectCode(
      '门 A 动态模式无扫描来源',
      validate({ dynamicPatterns: [{ pattern: '${orphan}_log', path: 'app.sql', line: 1, reason: '自述' }] }),
      'TABLE_INVENTORY_DYNAMIC_CONTEXT_UNKNOWN',
    );
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
  return failures;
}

// ─── CLI ────────────────────────────────────────────────────────────────────

function parseArgs(argv) {
  const args = { command: null };
  const rest = argv.slice(2);
  args.command = rest.shift() || null;
  for (let i = 0; i < rest.length; i += 1) {
    const arg = rest[i];
    const next = () => rest[++i];
    if (arg === '--root') args.root = next();
    else if (arg === '--plans-dir') args.plansDir = next();
    else if (arg === '--out') args.out = next();
    else if (arg === '--inventory') args.inventory = next();
    else if (arg === '--db-table-list') args.dbTableList = next();
    else if (arg === '--scan') args.scan = next();
    else if (arg === '--binding') args.binding = next();
    else if (arg === '--active-spec-dir') args.activeSpecDir = next();
    else if (arg === '--channel') args.channel = next();
    else if (arg === '--include-entity') args.includeEntity = true;
    else if (arg === '--help' || arg === '-h') args.help = true;
    else throw new Error(`未知参数：${arg}`);
  }
  return args;
}

function usage() {
  return [
    '用法:',
    '  node check-code-table-inventory.mjs prescan [--root DIR] [--plans-dir DIR] [--out FILE] [--include-entity]',
    '  node check-code-table-inventory.mjs catalog --inventory FILE [--binding FILE] [--root DIR]',
    '  node check-code-table-inventory.mjs connection --inventory FILE [--binding FILE] [--root DIR] [--active-spec-dir DIR] [--channel mcp]',
    '  node check-code-table-inventory.mjs connections --inventory FILE [--binding FILE] [--root DIR] [--active-spec-dir DIR] [--channel mcp]',
    '       （local 通道已退役；显式传 local 返回确定性失败）',
    '  node check-code-table-inventory.mjs check --inventory FILE --db-table-list FILE',
    '       [--scan FILE] [--root DIR] [--plans-dir DIR] [--binding FILE]',
    '  node check-code-table-inventory.mjs --self-test',
  ].join('\n');
}

function readBindingEntries(filePath) {
  if (!filePath) return null;
  if (!existsSync(filePath)) throw new Error(`绑定 envelope 不存在：${filePath}`);
  let doc;
  try {
    doc = readJson(filePath);
  } catch (error) {
    throw new Error(`绑定 envelope 不可解析（${(error && error.message) || String(error)}）：${filePath}`);
  }
  if (!isPlainObject(doc) || !Array.isArray(doc.bindings)) {
    throw new Error(`绑定 envelope 形状非法（需 { bindings: [] }）：${filePath}`);
  }
  // 单一解析器：绑定名与库类型都从这里出（`readBindingNames` 只做投影，禁另写解析）。
  return doc.bindings.map((entry, index) => {
    if (!isPlainObject(entry)) {
      throw new Error(`绑定 envelope 形状非法（bindings[${index}] 不是对象）：${filePath}`);
    }
    const dataSourceName = nonEmpty(entry.dataSourceName) ? entry.dataSourceName.trim() : '';
    if (!dataSourceName) {
      throw new Error(`绑定 envelope 形状非法（bindings[${index}] 缺 dataSourceName）：${filePath}`);
    }
    return {
      dataSourceName,
      databaseType: nonEmpty(entry.databaseType) ? entry.databaseType.trim() : '',
    };
  });
}

function readBindingNames(filePath) {
  const entries = readBindingEntries(filePath);
  if (entries === null) return null;
  return entries.map((entry) => entry.dataSourceName).filter(Boolean);
}

/**
 * 方言族内等价判定（判据保持现状，不放宽：`mysql` 与 `mysql8` 仍视为不同值）。
 * `catalog --binding` 与 `connections` 共用，禁在别处另写副本。
 */
function sameFamily(a, b) {
  return (
    a === b ||
    (['postgres', 'postgresql', 'pg'].includes(a) && ['postgres', 'postgresql', 'pg'].includes(b)) ||
    (['oracle', 'ora'].includes(a) && ['oracle', 'ora'].includes(b)) ||
    (['dm', 'dameng'].includes(a) && ['dm', 'dameng'].includes(b))
  );
}

/**
 * `catalog.dialect` 与绑定 `databaseType` 的一致性比对（单一真理源）。
 * 返回 `null` 表示通过；否则返回 `TABLE_INVENTORY_CATALOG_DIALECT`（文案带恢复动作）。
 */
function catalogDialectFailure(catalogDialect, databaseType, dataSourceName) {
  const catalogValue = String(catalogDialect ?? '').trim();
  const bindingValue = String(databaseType ?? '').trim();
  if (!catalogValue || !bindingValue) return null;
  if (sameFamily(catalogValue.toLowerCase(), bindingValue.toLowerCase())) return null;
  const sourceText = nonEmpty(dataSourceName) ? `（数据源 ${String(dataSourceName).trim()}）` : '';
  return failure(
    'TABLE_INVENTORY_CATALOG_DIALECT',
    '$.catalog.dialect',
    `catalog.dialect=${catalogValue} 与已确认绑定${sourceText} databaseType=${bindingValue} 不一致：` +
      '不得按错方言执行 preflight。恢复动作：改 backend/_meta/code-table-inventory.json 的 catalog.dialect 为绑定实际类型后重跑阶段四',
  );
}

/** `catalog --binding`：按 catalog 声明的数据源（或全部绑定）逐条比对，返回首个失败。 */
function catalogDialectFailureForBindings(catalog, entries) {
  if (!Array.isArray(entries) || entries.length === 0) {
    return failure(
      'TABLE_INVENTORY_DATASOURCE',
      '$.catalog.dialect',
      '绑定 envelope 的 bindings 为空：无法校验 catalog.dialect。恢复动作：先补数据源绑定（2d）后重跑阶段四',
    );
  }
  const explicit = nonEmpty(catalog.dataSourceName) ? catalog.dataSourceName.trim() : '';
  const targets = explicit ? entries.filter((entry) => entry.dataSourceName === explicit) : entries;
  if (explicit && targets.length === 0) {
    return failure(
      'TABLE_INVENTORY_DATASOURCE',
      '$.catalog.dataSourceName',
      `catalog.dataSourceName=${explicit} 不在已确认绑定中（${entries
        .map((entry) => entry.dataSourceName)
        .filter(Boolean)
        .join(', ')}）`,
    );
  }
  for (const entry of targets) {
    if (!entry.databaseType) {
      return failure(
        'TABLE_INVENTORY_DATASOURCE',
        '$.catalog.dialect',
        `绑定条目${entry.dataSourceName ? `（${entry.dataSourceName}）` : ''}缺 databaseType：无法校验 catalog.dialect。` +
          '恢复动作：先补齐数据源绑定（2d）后重跑阶段四',
      );
    }
    const mismatch = catalogDialectFailure(catalog.dialect, entry.databaseType, entry.dataSourceName);
    if (mismatch) return mismatch;
  }
  return null;
}

function resolveConnection(
  inventory,
  { bindingPath, rootDir, activeSpecDir, channel, dataSourceName, bindingNames } = {},
) {
  const catalogRead = parseInventoryCatalog(inventory);
  if (!catalogRead.ok) return { ok: false, failures: catalogRead.failures };
  const catalog = catalogRead.catalog;

  let names = Array.isArray(bindingNames) ? bindingNames : readBindingNames(bindingPath);
  if (names === null) {
    const fallback = join(activeSpecDir || rootDir, 'plans', 'backend', '_meta', 'datasource-binding.json');
    if (existsSync(fallback)) names = readBindingNames(fallback);
  }
  names = names || [];
  if (dataSourceName && catalog.dataSourceName && dataSourceName !== catalog.dataSourceName) {
    return {
      ok: false,
      failures: [
        failure(
          'TABLE_INVENTORY_DATASOURCE',
          '$.catalog.dataSourceName',
          `catalog.dataSourceName=${catalog.dataSourceName} 与逐源 preflight 的 dataSourceName=${dataSourceName} 冲突：多源场景 catalog.dataSourceName 必须省略`,
        ),
      ],
    };
  }
  const chosen = dataSourceName || catalog.dataSourceName || (new Set(names).size === 1 ? names[0] : '');
  if (!chosen) {
    return {
      ok: false,
      failures: [
        failure(
          'TABLE_INVENTORY_DATASOURCE',
          '$.catalog.dataSourceName',
          `无法唯一确定 preflight 数据源（绑定：${names.join(', ') || '空'}）：多绑定必须在 catalog.dataSourceName 显式指定`,
        ),
      ],
    };
  }
  if (names.length > 0 && !names.includes(chosen)) {
    return {
      ok: false,
      failures: [failure('TABLE_INVENTORY_DATASOURCE', '$.catalog.dataSourceName', `catalog.dataSourceName=${chosen} 不在已确认绑定中`)],
    };
  }

  // 通道已收敛为 mcp：不再按方言推导 local。显式 local/未知值由共享 resolver 确定性拒绝。
  const resolved = resolveIncrementalDatasource(rootDir, {
    dataSourceName: chosen,
    channel,
  });
  if (!resolved.ok) {
    return { ok: false, failures: [failure('TABLE_INVENTORY_DATASOURCE', '$.catalog', resolved.reason)] };
  }
  const ds = resolved.ds;
  // 方言与契约条目的一致性（unknown 不判，方言集合开放）；比对函数与 catalog --binding 同源。
  const dialectFailure = catalogDialectFailure(catalog.dialect, ds.databaseType, chosen);
  if (dialectFailure) {
    return { ok: false, failures: [dialectFailure] };
  }

  return {
    ok: true,
    failures: [],
    connection: {
      dialect: catalog.dialect,
      listTablesSql: catalog.listTablesSql,
      dataSourceName: chosen,
      channel: 'mcp',
      dbName: ds.db,
      appId: ds.appId,
      databaseType: ds.databaseType,
    },
  };
}

function resolveConnections(inventory, { bindingPath, rootDir, activeSpecDir, channel } = {}) {
  const catalogRead = parseInventoryCatalog(inventory);
  if (!catalogRead.ok) return { ok: false, failures: catalogRead.failures, connections: [] };

  let names = readBindingNames(bindingPath);
  if (names === null) {
    const fallback = join(activeSpecDir || rootDir, 'plans', 'backend', '_meta', 'datasource-binding.json');
    if (existsSync(fallback)) names = readBindingNames(fallback);
  }
  const uniqueNames = [...new Set((names || []).filter(Boolean))];
  const catalogDataSource = catalogRead.catalog.dataSourceName;
  if (catalogDataSource && uniqueNames.length > 0 && !uniqueNames.includes(catalogDataSource)) {
    return {
      ok: false,
      failures: [
        failure(
          'TABLE_INVENTORY_DATASOURCE',
          '$.catalog.dataSourceName',
          `catalog.dataSourceName=${catalogDataSource} 不在已确认绑定中（${uniqueNames.join(', ')}）`,
        ),
      ],
      connections: [],
    };
  }
  // 每个已确认绑定解析一次连接；多绑定时 catalog.dataSourceName 不得用来裁剪，否则会漏源。
  if (catalogDataSource && uniqueNames.length > 1) {
    return {
      ok: false,
      failures: [
        failure(
          'TABLE_INVENTORY_DATASOURCE',
          '$.catalog.dataSourceName',
          `已确认多个绑定（${uniqueNames.join(', ')}）时 catalog.dataSourceName=${catalogDataSource} 必须省略：` +
            '否则 preflight 会漏源',
        ),
      ],
      connections: [],
    };
  }
  const targets = uniqueNames.length > 0 ? uniqueNames : [catalogDataSource || ''];
  const connections = [];
  const failures = [];
  for (const name of targets) {
    const resolved = resolveConnection(inventory, {
      rootDir,
      activeSpecDir,
      channel,
      dataSourceName: name || undefined,
      bindingNames: uniqueNames,
    });
    if (resolved.ok) connections.push(resolved.connection);
    else failures.push(...resolved.failures.map((entry) => ({ ...entry, dataSourceName: name || null })));
  }
  return { ok: failures.length === 0, failures, connections };
}

function runCli(argv = process.argv) {
  const args = parseArgs(argv);
  if (args.help) {
    process.stdout.write(`${usage()}\n`);
    return 0;
  }
  const rootDir = resolve(args.root || process.cwd());

  if (args.command === 'prescan') {
    const scan = scanMechanicalTables({
      rootDir,
      plansBackendDir: args.plansDir ? resolve(args.plansDir) : undefined,
      includeEntityEvidence: args.includeEntity === true,
    });
    if (args.out) writeJsonAtomic(resolve(args.out), scan);
    process.stdout.write(
      `${JSON.stringify({
        ok: true,
        kind: 'code-table-scan',
        outputPath: args.out ? resolve(args.out) : null,
        tables: scan.tables.length,
        dynamic: scan.dynamic.length,
        files: scan.files,
      })}\n`,
    );
    return 0;
  }

  if (args.command === 'catalog') {
    if (!args.inventory) throw new Error('catalog 模式缺 --inventory');
    const parsed = parseInventoryCatalog(readJson(resolve(args.inventory)));
    if (!parsed.ok) {
      process.stdout.write(`${JSON.stringify(parsed)}\n`);
      return 1;
    }
    if (args.binding) {
      const bindingPath = resolve(args.binding);
      let entries;
      try {
        entries = readBindingEntries(bindingPath);
      } catch (error) {
        const message = (error && error.message) || String(error);
        process.stdout.write(
          `${JSON.stringify({
            ok: false,
            failures: [
              failure(
                'TABLE_INVENTORY_DATASOURCE',
                '$binding',
                `${message}（恢复动作：先跑完数据源绑定（2d）后重跑阶段四，禁止跳过一致性校验）`,
              ),
            ],
          })}\n`,
        );
        return 1;
      }
      const dialectFailure = catalogDialectFailureForBindings(parsed.catalog, entries);
      if (dialectFailure) {
        process.stdout.write(`${JSON.stringify({ ok: false, failures: [dialectFailure] })}\n`);
        return 1;
      }
    }
    process.stdout.write(`${JSON.stringify({ ok: true, catalog: parsed.catalog })}\n`);
    return 0;
  }

  if (args.command === 'connections') {
    if (!args.inventory) throw new Error('connections 模式缺 --inventory');
    const resolved = resolveConnections(readJson(resolve(args.inventory)), {
      bindingPath: args.binding ? resolve(args.binding) : null,
      rootDir,
      activeSpecDir: args.activeSpecDir ? resolve(args.activeSpecDir) : null,
      channel: args.channel,
    });
    process.stdout.write(
      `${JSON.stringify(resolved.ok ? { ok: true, connections: resolved.connections } : resolved)}\n`,
    );
    return resolved.ok ? 0 : 1;
  }

  if (args.command === 'connection') {
    if (!args.inventory) throw new Error('connection 模式缺 --inventory');
    const resolved = resolveConnection(readJson(resolve(args.inventory)), {
      bindingPath: args.binding ? resolve(args.binding) : null,
      rootDir,
      activeSpecDir: args.activeSpecDir ? resolve(args.activeSpecDir) : null,
      channel: args.channel,
    });
    process.stdout.write(`${JSON.stringify(resolved.ok ? { ok: true, connection: resolved.connection } : resolved)}\n`);
    return resolved.ok ? 0 : 1;
  }

  if (args.command === 'check') {
    if (!args.inventory) throw new Error('check 模式缺 --inventory');
    if (!args.dbTableList) throw new Error('check 模式缺 --db-table-list');
    const inventory = readJson(resolve(args.inventory));
    const dbTableList = readJson(resolve(args.dbTableList));
    let scan = null;
    if (args.scan) {
      if (!existsSync(resolve(args.scan))) {
        process.stdout.write(
          `${JSON.stringify({
            ok: false,
            failures: [failure('TABLE_INVENTORY_SCAN', '$scan', `预扫文件不存在：${resolve(args.scan)}（拒绝静默跳过）`)],
            classification: null,
            summary: null,
          })}\n`,
        );
        return 1;
      }
      scan = readJson(resolve(args.scan));
    } else {
      scan = scanMechanicalTables({
        rootDir,
        plansBackendDir: args.plansDir ? resolve(args.plansDir) : undefined,
      });
    }
    const bindingNames = args.binding ? readBindingNames(resolve(args.binding)) : null;
    const verdict = validateCodeTableInventory({ inventory, dbTableList, scan, rootDir, bindingNames });
    process.stdout.write(`${JSON.stringify({ ...verdict, version: GATE_VERSION })}\n`);
    return verdict.ok ? 0 : 1;
  }

  throw new Error(`未知子命令 ${JSON.stringify(args.command)}；${usage()}`);
}

// macOS 的 os.tmpdir()（/var/folders）经软链解析后是 /private/var/...：两侧都按 realpath 比较，
// 否则脚本会静默退出（exit 0、无输出）。realpath 失败时兜底为「非主模块」，不改变判据。
const isMain = (() => {
  try {
    if (!process.argv[1]) return false;
    return realpathSync(resolve(process.argv[1])) === realpathSync(fileURLToPath(import.meta.url));
  } catch {
    return false;
  }
})();
if (isMain) {
  if (process.argv[2] === '--self-test') {
    const failures = selfTest();
    if (failures.length > 0) {
      process.stderr.write(`✗ check-code-table-inventory self-test 失败:\n${failures.join('\n')}\n`);
      process.exit(1);
    }
    process.stdout.write('✓ check-code-table-inventory self-test PASS\n');
    process.exit(0);
  }
  try {
    process.exit(runCli());
  } catch (error) {
    process.stdout.write(
      `${JSON.stringify({
        ok: false,
        failures: [failure('TABLE_INVENTORY_SCRIPT_ERROR', '$', (error && error.message) || String(error))],
        classification: null,
        summary: null,
      })}\n`,
    );
    process.exit(1);
  }
}
