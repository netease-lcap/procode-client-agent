/** SQL 文本屏蔽仅用于只读/破坏性操作约束，不用于校验语法或改写执行内容。 */
export function sanitizeSql(sql) {
  let text = '';
  let i = 0;
  let executableComment = false;
  // `#` 只在行首（其前只有空白）才按 MySQL 行注释处理：`SELECT 1 # 2` 在 PG 是
  // 位运算，不能把 `#` 之后当注释吞掉（否则可藏第二条语句）。
  let lineStartOnlyWhitespace = true;
  const n = sql.length;
  const isWhitespace = (value) => value !== undefined && /\s/.test(value);
  while (i < n) {
    const ch = sql[i];
    const next = sql[i + 1];

    // 行注释：`-- `（MySQL 要求其后为空白/控制符）与行首 `# `（MySQL）
    if ((ch === '-' && next === '-' && (i + 2 >= n || isWhitespace(sql[i + 2]))) ||
      (ch === '#' && lineStartOnlyWhitespace)) {
      i += ch === '#' ? 1 : 2;
      while (i < n && sql[i] !== '\n') i += 1;
      text += ' ';
      continue;
    }

    // 块注释：`/* ... */`；`/*! ... */` 是 MySQL 可执行注释，内容会被数据库执行。
    if (ch === '/' && next === '*') {
      if (sql[i + 2] === '!') executableComment = true;
      i += 2;
      while (i < n && !(sql[i] === '*' && sql[i + 1] === '/')) i += 1;
      i = Math.min(n, i + 2);
      text += ' ';
      continue;
    }

    // 屏蔽引用内容用于执行约束；SQL 原文始终由数据库解释。
    const dollar = ch === '$' ? /^(?:\$\$|\$[A-Za-z_][A-Za-z0-9_]*\$)/.exec(sql.slice(i)) : null;
    if (dollar) {
      const end = sql.indexOf(dollar[0], i + dollar[0].length);
      i = end < 0 ? n : end + dollar[0].length;
      text += "''";
      lineStartOnlyWhitespace = false;
      continue;
    }
    if ((ch === 'q' || ch === 'Q') && next === "'" && sql[i + 2]) {
      const opening = sql[i + 2];
      const closing = ({ '[': ']', '{': '}', '(': ')', '<': '>' })[opening] || opening;
      const end = sql.indexOf(closing + "'", i + 3);
      i = end < 0 ? n : end + 2;
      text += "''";
      lineStartOnlyWhitespace = false;
      continue;
    }
    // 字符串 / 引用标识符：屏蔽内容，只保留起止引号。
    if (ch === "'" || ch === '"' || ch === '`') {
      const quote = ch;
      text += quote;
      i += 1;
      while (i < n) {
        // MySQL 反斜杠转义（反引号标识符不适用）。
        if (quote !== '`' && sql[i] === '\\') {
          i += 2;
          continue;
        }
        if (sql[i] === quote) {
          // 双写转义：'' / "" / ``
          if (sql[i + 1] === quote) {
            i += 2;
            continue;
          }
          i += 1;
          break;
        }
        i += 1;
      }
      text += quote;
      lineStartOnlyWhitespace = false;
      continue;
    }

    text += ch;
    i += 1;
    if (ch === '\n') lineStartOnlyWhitespace = true;
    else if (!isWhitespace(ch)) lineStartOnlyWhitespace = false;
  }
  return { text, executableComment };
}
