// db-config.json 只读钩子（plan 2026-09-21/pg-selection-fidelity-full-chain-repair §B2）。
//
// 极薄 denylist：凡经 agent write 工具落到 plans/db-config.json 的写入一律非法。
// 历史背景：该产物已随 plan 2026-11-04/retire-db-config-json-artifact 退役（编排器读写点全部删除），
// 本钩子仅作为**残留文件写保护**保留——防止 agent 把旧轮残留文件当配置真值改写。
// 写后红语义（post-check 在 write 完成后追加红文案，不能阻止写入）：
// 「守住」= agent 见红自纠（恢复原值/回修 yml）+ 阶段二 yml 契约门兜底，两层缺一不可。
// 文本红契约：stderr 红 + 回修指引，非零 exit（post-check-file.mjs 捕获后恒 exit 2）。
//
// 用法（由 .wave/scripts/post-check-file.json 的 `**/plans/db-config.json` pattern 路由）：
//   node .specify/scripts/javascript/hooks/check-db-config-readonly.mjs <file_path>

const filePath = process.argv[2];

if (!filePath) process.exit(0);
const normalized = filePath.replace(/\\/g, '/');
// 防御性自查：本钩子只对 plans/db-config.json 生效（pattern 命中是路由侧责任，此处兜底防误挂）。
if (!/(^|\/)plans\/db-config\.json$/.test(normalized)) process.exit(0);

console.error(
  '禁止写入 plans/db-config.json：该本地派生连接配置产物已退役（plan 2026-11-04），agent 无写入权限，残留文件也不得改写。' +
  '处置：1) 撤销本次写入、恢复文件原值（禁保留任何 agent 侧改写）；' +
  '2) 若本意是修正 application.yml / pom 的数据库配置，直接改 yml/pom 使其与数据源契约条目一致（阶段二 yml 校验真值=契约条目）；' +
  '3) 若认为契约条目本身有误，上报 checkerFeedback 等人工裁决，禁自行改写契约数据文件。',
);
process.exit(1);
