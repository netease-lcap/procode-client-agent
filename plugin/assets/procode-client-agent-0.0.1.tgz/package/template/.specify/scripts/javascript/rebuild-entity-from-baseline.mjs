#!/usr/bin/env node

/**
 * 增量 delta 派生 · **只读结构判据**（U7 退役生成器，plan 2026-11-06/
 * incremental-delta-per-table-agents-and-matrix-repo-defer §2 D4）。
 *
 * 生成路径已退役：delta 由 `backend-design/incremental/delta-derivation-wave.ts` 的按表 agent phase
 * 产出片段 / 单语句 SQL / canonical md，合并与机械补全由 TS 合并层完成。本脚本**不推导、不渲染、
 * 不落盘**，只对已落盘产物执行 D4 结构判据：
 *   1. 每条 SQL 恰一条语句，kind ∈ 6 种 closed kind（ADD COLUMN / ADD INDEX / ADD UNIQUE /
 *      CREATE TABLE / CREATE INDEX / ADD COMMENT）；operations/片段均为 v2；
 *   2. migration 表集合 = _fragments 表集合 = entity-*.md(ALTER) ∪ post-delta 三类；
 *   3. unsupported 表不得出现在 operations，且必须保留完整设计；
 *   4. diffable=false / 空列基线对象必须是 unsupported；
 *   5. post-delta 三分类键为 camelCase 字符串数组；
 *   6. REFERENCES 目标列必须在基线该表真实主键内；
 *   7. baseline.table 必须存在于 code-schema，且一个基线表只能被一个设计表绑定；
 *   8. baseline=null ⇔ class=create；baseline 非空 ⇒ class ∈ alter/retained/unsupported；
 *   9. match=semantic 必须带证据，且基线主键列名必须出现在设计 DDL 中。
 *
 * 用法（只读）：
 *   node rebuild-entity-from-baseline.mjs --code-schema <path> --entity-dir <backend 目录>
 *     [--entity-source <PRE-DELTA 完整设计目录>] --check
 *
 * 任何写模式（缺 `--check`）直接失败：生成器已退役，禁止用脚本生成 delta（agent 改脚本绕红是
 * 本次事故的根因，保留写入口等于保留绕红面）。
 *
 * 仍导出的 `buildPkMap` 只服务 `tests/scripts/*` 的主键映射纯函数用例（U8 迁移测试后即可删除）。
 */

import { existsSync, readdirSync, readFileSync } from 'fs';
import { resolve, dirname, join } from 'path';
import { createHash } from 'crypto';
import { fileURLToPath } from 'url';

import { SOURCE_ID_RE, splitSqlStatements, stableJson } from './extract-code-schema.mjs';
import {
  isSchemaObjectRef,
  isTableRef,
  refKeyOf,
  refEquals,
  formatRef,
  resolvePrimaryKeysV3,
} from './lib/entity-pk-resolver.mjs';
import { parseTableRefsMetadata, extractCreateTableSegments, splitQualifiedTableName } from './shared/cross-domain-decl.mjs';

/** v3 契约版本（本批本地钉死，避免读到共享常量的中间态）。 */
const CODE_SCHEMA_VERSION_V3 = 3;
const FRAGMENT_SCHEMA_VERSION = 3;
const POST_DELTA_SCHEMA_VERSION = 2;
export const OPERATIONS_SCHEMA_VERSION = 3;
const BASELINE_REF_PATH = 'backend/_meta/code-schema.json';
const MIGRATION_REL = 'migration';
const FRAGMENTS_REL = ['migration', '_fragments'];
const POST_DELTA_FILENAME = 'post-delta.json';
const DELTA_CLASSES = ['create', 'alter', 'retained', 'unsupported'];
const DELTA_STATEMENT_KINDS = [
  'add-column',
  'add-index',
  'add-unique',
  'create-table',
  'create-index',
  'add-comment',
];
const ALLOWED_OPERATION_KINDS = [
  'add-column',
  'add-index',
  'add-unique',
  'create-table',
  'create-index',
  'add-comment',
];
const POST_DELTA_KEYS = ['newTableCreate', 'existingDeltaAlter', 'designRetainedUnsupported'];

// ─── 参数解析（只接受只读模式）────────────────────────────────────────────────
function parseArgs(argv) {
  const args = { codeSchema: null, entityDir: null, entitySource: null, check: false };
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (token === '--code-schema') args.codeSchema = argv[++i];
    else if (token === '--entity-dir') args.entityDir = argv[++i];
    else if (token === '--entity-source') args.entitySource = argv[++i];
    else if (token === '--operations') args.operations = argv[++i];
    else if (token === '--check') args.check = true;
    else if (token === '--self-test') args.selfTest = true;
    else if (token === '--module-id' || token === '--iteration-id') {
      // 旧生成参数：吞掉值，避免误当文件路径；写模式仍会被拒绝。
      i++;
    }
  }
  return args;
}

export function loadCodeSchemaV3(p) {
  const raw = JSON.parse(readFileSync(p, 'utf-8'));
  if (!raw || raw.schemaVersion !== CODE_SCHEMA_VERSION_V3 || !Array.isArray(raw.sources)) {
    throw new Error(
      `code-schema 不是 v3（需要 {schemaVersion:3, sources[]}）：${p}。` +
        '恢复入口：用 extract-code-schema.mjs 重采 v3（对象只带 owner/kind/name），' +
        '或在集中迁移边界跑 v2→v3 迁移脚本；禁止手工改版本号冒充 v3。',
    );
  }
  return raw;
}

/** v3 索引：refKey → {ref,sourceId,object}；sourceId+精确名 → entry[]。裸名不做归一。 */
export function buildTableIndex(schema) {
  const byRefKey = new Map();
  const bySourceName = new Map();
  const bySource = new Map();
  for (const source of schema.sources || []) {
    for (const object of source.objects || []) {
      if (!object || typeof object.name !== 'string' || !object.name) continue;
      const ref = {
        sourceId: source.sourceId,
        owner: object.owner === undefined ? null : object.owner,
        kind: object.kind === undefined ? 'table' : object.kind,
        name: object.name,
      };
      if (!isSchemaObjectRef(ref)) continue;
      const entry = { ref, sourceId: source.sourceId, object };
      byRefKey.set(refKeyOf(ref), entry);
      const nameKey = `${source.sourceId}\u0000${object.name}`;
      if (!bySourceName.has(nameKey)) bySourceName.set(nameKey, []);
      bySourceName.get(nameKey).push(entry);
      const listBySource = bySource.get(source.sourceId) || [];
      listBySource.push(entry);
      bySource.set(source.sourceId, listBySource);
    }
  }
  return { byRefKey, bySourceName, bySource };
}

/** source 作用域内按精确名 + 可选 owner 唯一解析；0 → null，>1 → 抛歧义。 */
export function resolveIndexedRef(index, sourceId, owner, name, context) {
  const candidates = (index.bySourceName.get(`${sourceId}\u0000${name}`) || []).filter(
    (entry) => owner == null || entry.ref.owner === owner,
  );
  if (candidates.length === 1) return candidates[0].ref;
  if (candidates.length === 0) return null;
  throw new Error(
    `${context}：${sourceId}/${owner == null ? '<null>' : owner}.${name} 命中 ${candidates.length} 个引用` +
      `（${candidates.map((entry) => formatRef(entry.ref)).join(' / ')}）；` +
      '禁按裸表名合并，请用 tableRef 显式消歧',
  );
}

/**
 * 主键映射（单列、唯一引用命中）。复合主键 / 重复引用不猜。
 * 返回 `Map<refKey, {tableRef, column}>`；仍是纯函数，`tests/scripts/rebuild-entity-operations.test.mjs` 直接引用。
 */
export function buildPkMap(schema, failures = [], referencedRefKeys = new Set()) {
  const referenced = referencedRefKeys instanceof Set ? referencedRefKeys : new Set(referencedRefKeys || []);
  const resolved = resolvePrimaryKeysV3(schema);
  const ambiguityByKey = new Map((resolved.ambiguities || []).map((item) => [item.refKey, item]));
  const pkMap = new Map();
  for (const [key, entry] of resolved.byRef || []) {
    const ambiguity = ambiguityByKey.get(key);
    if (ambiguity) {
      if (referenced.has(key)) {
        failures.push(`引用 ${formatRef(entry.tableRef)} 重复出现：FK 回填目标歧义，需人工确认归属`);
      }
      continue;
    }
    const primaryKey = entry.primaryKey;
    if (!primaryKey) continue;
    if (primaryKey.composite) {
      if (!referenced.has(key)) continue;
      failures.push(
        `引用 ${formatRef(entry.tableRef)} 为复合主键（${primaryKey.columns.map((column) => column.name).join(', ')}）：` +
          'FK 回填只支持单列主键，需人工确认',
      );
      continue;
    }
    if (primaryKey.columns.length !== 1) continue;
    pkMap.set(key, { tableRef: entry.tableRef, column: primaryKey.columns[0].name });
  }
  return pkMap;
}

// ─── 只读判据 ────────────────────────────────────────────────────────────────
const sha256OfBytes = (text) => 'sha256:' + createHash('sha256').update(Buffer.from(String(text), 'utf8')).digest('hex');

/** 去字符串字面量与注释后再做关键字判定，避免注释里的 DROP 误报。 */
function stripSqlLiteralsAndComments(sql) {
  let out = '';
  let quote = null;
  for (let i = 0; i < sql.length; i++) {
    const ch = sql[i];
    if (quote) {
      if (ch === '\\' && quote !== '`') {
        i++;
        continue;
      }
      if (ch === quote) {
        if (sql[i + 1] === quote) {
          i++;
          continue;
        }
        quote = null;
      }
      out += ' ';
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') {
      quote = ch;
      out += ' ';
      continue;
    }
    if (ch === '-' && sql[i + 1] === '-') {
      while (i < sql.length && sql[i] !== '\n') i++;
      out += '\n';
      continue;
    }
    if (ch === '/' && sql[i + 1] === '*') {
      i += 2;
      while (i < sql.length && !(sql[i] === '*' && sql[i + 1] === '/')) i++;
      i++;
      out += ' ';
      continue;
    }
    out += ch;
  }
  return out;
}

const readJson = (p) => {
  try {
    return { ok: true, value: JSON.parse(readFileSync(p, 'utf-8')) };
  } catch (error) {
    return { ok: false, message: error.message };
  }
};

const listEntitySlugs = (dir) => {
  if (!dir || !existsSync(dir)) return [];
  return readdirSync(dir)
    .filter((name) => name.startsWith('entity-') && name.endsWith('.md'))
    .map((name) => name.slice('entity-'.length, -'.md'.length))
    .sort();
};

const readSqlBlock = (file) => {
  try {
    const src = readFileSync(file, 'utf-8');
    const block = src.match(/```sql\s*\n([\s\S]*?)```/i);
    return block ? block[1] : null;
  } catch {
    return null;
  }
};

const sqlPathSafe = (p) =>
  typeof p === 'string' &&
  p.length > 0 &&
  !p.startsWith('/') &&
  !p.split('/').includes('..') &&
  /^[A-Za-z0-9._/-]+$/.test(p);

/** 实体文档头部 source 声明（objectId 已退役，只读出用于判红）。 */
const escapeRegExp = (value) => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function headHints(text) {
  const head = String(text || '').slice(0, 4000);
  const read = (patterns) => {
    for (const pattern of patterns) {
      const m = head.match(pattern);
      if (m) return m[1].trim();
    }
    return undefined;
  };
  return {
    sourceId: read([/(?:^|\n)\s*sourceId\s*[：:]\s*`?([^\s`"']+)/i]),
    objectId: read([/(?:^|\n)\s*objectId\s*[：:]\s*`?([^\s`"']+)/i]),
    dataSourceName: read([
      /(?:^|\n)\s*dataSourceName\s*[：:]\s*`?([^\s`"']+)/i,
      /(?:^|\n)\s*数据源\s*[：:]\s*`?([^\s`"']+)/i,
    ]),
  };
}

/** 文档 source 作用域：sourceId 精确 > 数据源 binding 唯一 > 单 source 兜底。 */
function resolveDocSourceId(hints, codeSchema, violations, file) {
  if (hints.sourceId) {
    if (codeSchema.sources.some((source) => source && source.sourceId === hints.sourceId)) return hints.sourceId;
    violations.push(`${file}：sourceId=${hints.sourceId} 不在 code-schema v3 sources 中`);
    return null;
  }
  if (hints.dataSourceName) {
    const matched = codeSchema.sources.filter(
      (source) => source && source.binding && source.binding.dataSourceName === hints.dataSourceName,
    );
    if (matched.length === 1) return matched[0].sourceId;
    violations.push(`${file}：数据源 ${hints.dataSourceName} 命中 ${matched.length} 份基线，无法唯一作用域`);
    return null;
  }
  return codeSchema.sources.length === 1 ? codeSchema.sources[0].sourceId : null;
}

/** 文档某 DDL 目标 → v3 引用：优先 tableRefs 元数据，否则按 source 作用域精确名唯一解析。 */
function resolveDocTargetRef(target, { bindings, sourceId }, index, violations, file) {
  if (!target || !target.name) return null;
  const byMetadata = bindings.find(
    (binding) => binding.tableRef.name === target.name &&
      (target.owner == null || binding.tableRef.owner === target.owner),
  );
  if (byMetadata) return byMetadata.tableRef;
  if (!sourceId) {
    violations.push(`${file}：表 ${target.name} 无法确定所属 source（多份基线），请写 sourceId/数据源或用 \`## tableRefs\``);
    return null;
  }
  try {
    const ref = resolveIndexedRef(index, sourceId, target.owner, target.name, file);
    if (!ref) violations.push(`${file}：表 ${target.name} 不在 sourceId=${sourceId} 的基线中`);
    return ref;
  } catch (error) {
    violations.push(error.message);
    return null;
  }
}

/**
 * D4 九条结构判据（只读）。返回 `{ ok, violations }`；空 violations 才是绿。
 * 不在本函数内推导 delta；片段 / operations / post-delta / entity md 都是已落盘事实。
 */
export function verifyArtifacts({ codeSchema, entityDir, entitySource = null, operationsPath = null }) {
  const violations = [];
  const requirePostDelta = Boolean(entitySource);
  const designDir = entitySource || entityDir;
  const migrationDir = resolve(entityDir, MIGRATION_REL);
  const opsPath = operationsPath || resolve(migrationDir, 'operations.json');
  const fragmentsDir = resolve(entityDir, ...FRAGMENTS_REL);
  const index = buildTableIndex(codeSchema);
  const pkMap = buildPkMap(codeSchema, violations, new Set());
  const sourceIds = (codeSchema.sources || []).map((source) => source.sourceId).sort();

  // ── fragments（D4-2/3/4/7/8/9）────────────────────────────────────────────
  const fragments = new Map(); // slug → fragment
  const baselineBinding = new Map(); // sourceId\0objectId → slug
  const tableSeen = new Map(); // normalized table → slug
  if (!existsSync(fragmentsDir)) {
    violations.push(`缺片段目录：${fragmentsDir}（未派生或合并前）`);
  } else {
    for (const name of readdirSync(fragmentsDir).filter((n) => n.endsWith('.json')).sort()) {
      const slug = name.slice(0, -'.json'.length);
      const file = resolve(fragmentsDir, name);
      const parsed = readJson(file);
      if (parsed.ok === false) {
        violations.push(`片段 ${name} 不是合法 JSON：${parsed.message}`);
        continue;
      }
      const fragment = parsed.value;
      fragments.set(slug, fragment);
      if (!fragment || typeof fragment !== 'object' || Array.isArray(fragment)) {
        violations.push(`片段 ${name} 顶层必须是对象`);
        continue;
      }
      if (fragment.schemaVersion !== FRAGMENT_SCHEMA_VERSION) {
        violations.push(
          `片段 ${name} schemaVersion 必须为 ${FRAGMENT_SCHEMA_VERSION}（Delta v3；v2 片段必须重跑单表 agent 产出 tableRef）`,
        );
      }
      if (!isTableRef(fragment.tableRef)) {
        violations.push(
          `片段 ${name} 缺合法 tableRef（需 {sourceId,owner,kind:'table',name}；旧 table/sourceId/objectId 不再接受）`,
        );
      }
      if (!DELTA_CLASSES.includes(fragment.class)) {
        violations.push(`片段 ${name} class 非法：${JSON.stringify(fragment.class)}（只接受 ${DELTA_CLASSES.join('/')}）`);
      }
      if (typeof fragment.evidence?.design !== 'string' || !fragment.evidence.design.trim()) {
        violations.push(`片段 ${name} 缺 evidence.design`);
      }

      const hasBaseline = fragment.baseline != null;
      if (fragment.class === 'create' && hasBaseline) {
        violations.push(`片段 ${name} class=create 但 baseline 非空（D4-8：baseline=null ⇔ create）`);
      }
      if (fragment.class !== 'create' && !hasBaseline) {
        violations.push(`片段 ${name} class=${fragment.class} 但 baseline=null（D4-8：仅 create 允许新表）`);
      }

      const tableRef = fragment.tableRef;
      const tableKey = isTableRef(tableRef) ? refKeyOf(tableRef) : null;
      if (tableKey) {
        if (tableSeen.has(tableKey)) {
          violations.push(`同一引用 ${formatRef(tableRef)} 出现在片段 ${tableSeen.get(tableKey)}.json 与 ${name}`);
        } else {
          tableSeen.set(tableKey, slug);
        }
      }

      let baselineObject = null;
      if (hasBaseline) {
        if (fragment.baseline.tableRef !== undefined && !refEquals(fragment.baseline.tableRef, tableRef)) {
          violations.push(
            `片段 ${name} baseline.tableRef 与 tableRef 不一致：` +
              `${formatRef(fragment.baseline.tableRef)} vs ${formatRef(tableRef)}（D4-7：一个设计表只绑定一个引用）`,
          );
        }
        const found = tableKey ? index.byRefKey.get(tableKey) : null;
        if (!found) {
          violations.push(`片段 ${name} baseline 引用在 code-schema 中不存在：${formatRef(tableRef)}`);
        } else {
          baselineObject = found.object;
          if (baselineBinding.has(tableKey)) {
            violations.push(
              `基线引用 ${formatRef(tableRef)} 被多个设计表绑定：${baselineBinding.get(tableKey)}.json 与 ${name}（D4-7）`,
            );
          } else {
            baselineBinding.set(tableKey, slug);
          }
          if (baselineObject.basis === 'db-only' || baselineObject.diffable === false ||
              !Array.isArray(baselineObject.columns) || baselineObject.columns.length === 0 ||
              (Array.isArray(baselineObject.parseIssues) && baselineObject.parseIssues.length > 0)) {
            if (fragment.class !== 'unsupported') {
              violations.push(
                `片段 ${name} 的基线对象 ${baselineObject.name} 不可 diff（db-only/diffable=false/空列/parseIssues），必须 class=unsupported（D4-4）`,
              );
            }
          }
        }
        if (fragment.baseline.match === 'semantic') {
          const evidence = Array.isArray(fragment.baseline.evidence) ? fragment.baseline.evidence : [];
          if (evidence.length === 0) violations.push(`片段 ${name} match=semantic 但 evidence 为空（D4-9）`);
          const designFile = resolve(designDir, String(fragment.evidence?.design || ''));
          const designSql = existsSync(designFile) ? readSqlBlock(designFile) : null;
          if (!designSql) {
            violations.push(`片段 ${name} 的设计原文不可读：${designFile}`);
          } else if (baselineObject) {
            const pk = tableKey ? pkMap.get(tableKey)?.column : null;
            if (pk && !new RegExp(`(^|[^A-Za-z0-9_])${pk}([^A-Za-z0-9_]|$)`, 'i').test(designSql)) {
              violations.push(`片段 ${name} match=semantic 但设计 DDL 未出现基线主键列 ${pk}（D4-9）`);
            }
          }
        }
      }

      const statements = Array.isArray(fragment.statements) ? fragment.statements : [];
      if (fragment.class === 'alter' && statements.length === 0) {
        violations.push(`片段 ${name} class=alter 但 statements 为空`);
      }
      for (const [i, statement] of statements.entries()) {
        if (!statement || typeof statement !== 'object') {
          violations.push(`片段 ${name} statements[${i}] 非对象`);
          continue;
        }
        if (!DELTA_STATEMENT_KINDS.includes(statement.kind)) {
          violations.push(`片段 ${name} statements[${i}] kind 非法：${JSON.stringify(statement.kind)}`);
        }
        if (!sqlPathSafe(statement.sqlPath)) {
          violations.push(`片段 ${name} statements[${i}].sqlPath 非法：${JSON.stringify(statement.sqlPath)}`);
        }
        if (typeof statement.sql !== 'string' || !statement.sql.trim()) {
          violations.push(`片段 ${name} statements[${i}] 缺 sql`);
        }
      }
      if (fragment.class === 'unsupported' && (!Array.isArray(fragment.unsupported) || fragment.unsupported.length === 0)) {
        violations.push(`片段 ${name} class=unsupported 但 unsupported[] 为空（D4-3）`);
      }
    }

    // 缺失片段：pre-delta 的设计源不被改写；legacy 的 retained 会删 canonical md，故两侧取并集。
    const expected = new Set([...listEntitySlugs(designDir), ...fragments.keys()]);
    for (const slug of expected) {
      if (!fragments.has(slug)) violations.push(`设计表 entity-${slug}.md 缺少片段 migration/_fragments/${slug}.json`);
    }
    for (const [slug, fragment] of fragments) {
      if (fragment.class === 'retained') continue;
      const designFile = resolve(designDir, `entity-${slug}.md`);
      if (!existsSync(designFile)) {
        violations.push(`片段 ${slug}.json 缺设计原文 ${designFile}（非 retained 必须保留完整设计）`);
      }
    }
  }

  // ── operations（D4-1/2/6）────────────────────────────────────────────────
  const operations = [];
  const opTables = new Set();
  if (!existsSync(opsPath)) {
    violations.push(`operations.json 不存在：${opsPath}`);
  } else {
    const parsed = readJson(opsPath);
    if (parsed.ok === false) {
      violations.push(`operations.json 不是合法 JSON：${parsed.message}`);
    } else {
      const doc = parsed.value;
      if (!doc || doc.schemaVersion !== OPERATIONS_SCHEMA_VERSION) {
        violations.push(
          `operations.schemaVersion 必须为 ${OPERATIONS_SCHEMA_VERSION}（v2 及更旧不投影，需重跑机械合并产出 tableRef；得 ${JSON.stringify(doc && doc.schemaVersion)}）`,
        );
      }
      if (doc.scenario !== 'incremental') violations.push(`operations.scenario 必须为 'incremental'`);
      if (typeof doc.iterationId !== 'string' || !doc.iterationId.trim()) violations.push('operations.iterationId 缺失');
      if (typeof doc.inputRevision !== 'string' || !doc.inputRevision.trim()) {
        violations.push('operations.inputRevision 缺失（基线采集批次，必须与 audit 同值）');
      }
      if (!doc.baselineRef || typeof doc.baselineRef !== 'object') {
        violations.push('operations.baselineRef 缺失');
      } else {
        if (doc.baselineRef.path !== BASELINE_REF_PATH) violations.push(`baselineRef.path 必须为 ${BASELINE_REF_PATH}`);
        if (doc.baselineRef.schemaVersion !== CODE_SCHEMA_VERSION_V3) {
          violations.push(`baselineRef.schemaVersion 必须为 ${CODE_SCHEMA_VERSION_V3}`);
        }
        const declared = Array.isArray(doc.baselineRef.sourceIds) ? [...doc.baselineRef.sourceIds].sort() : null;
        if (!declared || stableJson(declared) !== stableJson(sourceIds)) {
          violations.push(`baselineRef.sourceIds 与当前基线不一致：declared=${JSON.stringify(declared)} current=${JSON.stringify(sourceIds)}`);
        }
      }
      if (!Array.isArray(doc.operations)) {
        violations.push('operations.operations 非数组');
      } else {
        const actionIds = new Set();
        for (const [i, operation] of doc.operations.entries()) {
          const tag = `operations[${i}]`;
          if (!operation || typeof operation !== 'object' || Array.isArray(operation)) {
            violations.push(`${tag} 非对象`);
            continue;
          }
          const actionId = String(operation.actionId || '');
          if (!actionId) violations.push(`${tag}.actionId 缺失`);
          else if (actionIds.has(actionId)) violations.push(`${tag}.actionId 重复：${actionId}`);
          actionIds.add(actionId);
          if (typeof operation.moduleId !== 'string' || !operation.moduleId.trim()) violations.push(`${tag}.moduleId 缺失或为空串`);
          if (operation.generatedBy !== undefined && operation.generatedBy !== 'script' && operation.generatedBy !== 'agent') {
            violations.push(`${tag}.generatedBy 非法：${JSON.stringify(operation.generatedBy)}`);
          }
          if (operation.generatedBy === 'agent' && (typeof operation.evidenceRef !== 'string' || !operation.evidenceRef.trim())) {
            violations.push(`${tag} generatedBy=agent 但缺 evidenceRef`);
          }
          if (operation.phase !== 'existing-delta' && operation.phase !== 'new-table') {
            violations.push(`${tag}.phase 非法：${JSON.stringify(operation.phase)}`);
          }
          if (!ALLOWED_OPERATION_KINDS.includes(operation.kind)) {
            violations.push(`${tag}.kind 非法：${JSON.stringify(operation.kind)}`);
          }
          if (!isTableRef(operation.tableRef)) {
            violations.push(`${tag}.tableRef 非法（需四字段引用；旧 sourceId/objectId 身份不再接受）`);
          }
          if (Object.prototype.hasOwnProperty.call(operation, 'objectId')) {
            violations.push(`${tag} 仍含 objectId（已退役）：改用 tableRef`);
          }
          const opRefKey = isTableRef(operation.tableRef) ? refKeyOf(operation.tableRef) : null;
          const found = opRefKey ? index.byRefKey.get(opRefKey) : null;
          if (operation.phase === 'existing-delta') {
            if (!found) violations.push(`${tag} 的 tableRef 在基线中不存在：${formatRef(operation.tableRef)}`);
            else {
              opTables.add(opRefKey);
              if (fragments.size > 0) {
                const boundSlug = baselineBinding.get(opRefKey);
                const boundFragment = boundSlug ? fragments.get(boundSlug) : null;
                if (!boundFragment || boundFragment.class !== 'alter') {
                  violations.push(`${tag} 指向的基线对象没有 alter 片段（不得凭空进 operations）`);
                }
              }
            }
          }

          const sql = operation.sql;
          if (!sql || typeof sql !== 'object' || Array.isArray(sql)) {
            violations.push(`${tag}.sql 缺失`);
            continue;
          }
          if (!sqlPathSafe(sql.path)) {
            violations.push(`${tag}.sql.path 非法：${JSON.stringify(sql.path)}`);
            continue;
          }
          const sqlFile = resolve(migrationDir, ...String(sql.path).split('/'));
          if (!existsSync(sqlFile)) {
            violations.push(`${tag}.sql.path 指向的文件不存在：${sqlFile}`);
            continue;
          }
          const sqlText = readFileSync(sqlFile, 'utf-8');
          if (sql.digest !== sha256OfBytes(sqlText)) {
            violations.push(`${tag}.sql.digest 与文件字节不一致：${sql.path}`);
          }
          if (sql.statements !== 1) violations.push(`${tag}.sql.statements 必须为 1`);
          const statements = splitSqlStatements(sqlText);
          if (statements.length !== 1) {
            violations.push(`${sql.path} 必须恰一条语句（得 ${statements.length} 条）`);
          }
          const normalized = stripSqlLiteralsAndComments(sqlText).toUpperCase();
          if (/\b(DROP|TRUNCATE|MODIFY|CHANGE|RENAME)\b/.test(normalized)) {
            violations.push(`${sql.path} 含禁止的 DDL（只允许 6 种 closed kind：ADD COLUMN/ADD INDEX/ADD UNIQUE/CREATE TABLE/CREATE INDEX/ADD COMMENT）`);
          }
          if (operation.kind === 'add-column') {
            if (!/\bALTER\s+TABLE\b/.test(normalized) || !/\bADD\b/.test(normalized)) {
              violations.push(`${sql.path} 与 kind=add-column 不符：必须是 ALTER TABLE ... ADD [COLUMN] ...`);
            }
          } else if (operation.kind === 'add-index' || operation.kind === 'add-unique') {
            const alterAdd = /\bALTER\s+TABLE\b/.test(normalized) && /\bADD\b/.test(normalized);
            const createIndex = /\bCREATE\s+(?:UNIQUE\s+)?INDEX\b/.test(normalized);
            if (!alterAdd && !createIndex) {
              violations.push(`${sql.path} 与 kind=${operation.kind} 不符：必须是 ALTER TABLE ... ADD ... 或 CREATE INDEX ... ON ...`);
            }
          } else if (operation.kind === 'create-table') {
            if (!/^\s*CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\b/.test(normalized)) {
              violations.push(`${sql.path} 与 kind=create-table 不符：必须 CREATE TABLE IF NOT EXISTS`);
            }
          } else if (operation.kind === 'create-index') {
            if (!/^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\b/.test(normalized)) {
              violations.push(`${sql.path} 与 kind=create-index 不符：必须 CREATE [UNIQUE] INDEX ... ON ...`);
            }
          } else if (operation.kind === 'add-comment') {
            if (!/^\s*(?:ALTER\s+TABLE|COMMENT\s+ON)\b/.test(normalized)) {
              violations.push(`${sql.path} 与 kind=add-comment 不符：必须 ALTER TABLE ... COMMENT 或 COMMENT ON ...`);
            }
          }
          operations.push(operation);
        }

        // dependsOn：禁自依赖 / 悬空 / 环。
        const byId = new Map(operations.map((operation) => [operation.actionId, operation]));
        for (const operation of operations) {
          const deps = Array.isArray(operation.dependsOn) ? operation.dependsOn : [];
          for (const dep of deps) {
            if (dep === operation.actionId) violations.push(`${operation.actionId}.dependsOn 不得自引用`);
            else if (!byId.has(dep)) violations.push(`${operation.actionId}.dependsOn 悬空：${dep}`);
          }
        }
        const visiting = new Set();
        const visited = new Set();
        const visit = (id) => {
          if (visited.has(id)) return;
          if (visiting.has(id)) {
            violations.push(`operations.dependsOn 存在环：${id}`);
            return;
          }
          visiting.add(id);
          const operation = byId.get(id);
          for (const dep of Array.isArray(operation?.dependsOn) ? operation.dependsOn : []) {
            if (byId.has(dep)) visit(dep);
          }
          visiting.delete(id);
          visited.add(id);
        };
        for (const id of byId.keys()) visit(id);
      }
    }
  }

  // ── entity-*.md(ALTER) ↔ operations（D4-2，按 v3 引用）─────────────────────
  const canonicalDir = entityDir;
  const mdAlterRefs = new Map(); // refKey → {ref, file}
  if (existsSync(canonicalDir)) {
    for (const name of readdirSync(canonicalDir).filter((n) => n.startsWith('entity-') && n.endsWith('.md'))) {
      const md = readFileSync(resolve(canonicalDir, name), 'utf-8');
      const hints = headHints(md);
      if (hints.objectId) {
        violations.push(`${name} 头部仍声明 objectId（已退役）：改用 sourceId/数据源 + tableRefs`);
      }
      const metadata = parseTableRefsMetadata(md);
      if (metadata.present && metadata.error) violations.push(`${name}：${metadata.error}`);
      const bindings = metadata.present && !metadata.error ? metadata.bindings : [];
      const sourceId = resolveDocSourceId(hints, codeSchema, violations, name);
      const alterTargets = [];
      const alterRe = /ALTER\s+TABLE\s+(?:ONLY\s+)?([^\s;,()]+)/gi;
      for (const match of md.matchAll(alterRe)) alterTargets.push(splitQualifiedTableName(match[1]));
      for (const target of alterTargets) {
        const ref = resolveDocTargetRef(target, { bindings, sourceId }, index, violations, name);
        if (ref) mdAlterRefs.set(refKeyOf(ref), { ref, file: name });
      }
    }
  }
  for (const [key, entry] of mdAlterRefs) {
    if (!opTables.has(key)) {
      violations.push(`entity-*.md（${entry.file}）有 ALTER ${formatRef(entry.ref)} 但 operations 无 existing-delta 动作`);
    }
  }
  for (const key of opTables) {
    if (mdAlterRefs.has(key)) continue;
    const ref = index.byRefKey.get(key)?.ref || null;
    violations.push(
      `operations 有 existing-delta ${ref ? formatRef(ref) : key} 但 entity-*.md 无 ALTER`,
    );
  }

  // unsupported 片段不得出现在 operations（D4-3，按引用精确比对）。
  for (const [slug, fragment] of fragments) {
    if (fragment.class !== 'unsupported') continue;
    if (!isTableRef(fragment.tableRef)) continue;
    const key = refKeyOf(fragment.tableRef);
    if (opTables.has(key)) {
      violations.push(`unsupported 片段 ${slug}.json 的 ${formatRef(fragment.tableRef)} 不得出现在 operations`);
    }
  }

  // ── post-delta（D4-2/5）────────────────────────────────────────────────
  if (requirePostDelta) {
    const postDeltaPath = resolve(migrationDir, POST_DELTA_FILENAME);
    if (!existsSync(postDeltaPath)) {
      violations.push(`post-delta.json 不存在：${postDeltaPath}（pre-delta 契约必须产出）`);
    } else {
      const parsed = readJson(postDeltaPath);
      if (parsed.ok === false) violations.push(`post-delta.json 不是合法 JSON：${parsed.message}`);
      else {
        const doc = parsed.value;
        if (!doc || typeof doc !== 'object' || Array.isArray(doc)) violations.push('post-delta 顶层必须是对象');
        else {
          if (doc.schemaVersion !== POST_DELTA_SCHEMA_VERSION) {
            violations.push(
              `post-delta.schemaVersion 必须为 ${POST_DELTA_SCHEMA_VERSION}（v1 裸表名分类不投影，须重跑 rebuild）`,
            );
          }
          for (const key of POST_DELTA_KEYS) {
            const value = doc.classes?.[key];
            if (!Array.isArray(value) || value.some((item) => !isTableRef(item))) {
              violations.push(`post-delta.classes.${key} 必须是 v3 tableRef 数组（旧裸表名须重跑 rebuild）`);
            }
          }
          const refKeysOfClass = (cls) =>
            [...fragments.values()]
              .filter((f) => f.class === cls && isTableRef(f.tableRef))
              .map((f) => refKeyOf(f.tableRef))
              .sort();
          const expectedClasses = {
            newTableCreate: refKeysOfClass('create'),
            existingDeltaAlter: refKeysOfClass('alter'),
            designRetainedUnsupported: refKeysOfClass('unsupported'),
          };
          for (const key of POST_DELTA_KEYS) {
            const actual = Array.isArray(doc.classes?.[key])
              ? doc.classes[key].filter((item) => isTableRef(item)).map((item) => refKeyOf(item)).sort()
              : [];
            if (stableJson(actual) !== stableJson(expectedClasses[key])) {
              violations.push(
                `post-delta.classes.${key} 与片段引用不一致：actual=${JSON.stringify(actual)} expected=${JSON.stringify(expectedClasses[key])}`,
              );
            }
          }
          if (!Array.isArray(doc.entries)) violations.push('post-delta.entries 必须是数组');
          else {
            for (const [i, entry] of doc.entries.entries()) {
              if (!entry || typeof entry !== 'object' || !isTableRef(entry.tableRef)) {
                violations.push(`post-delta.entries[${i}] 缺合法 tableRef`);
              }
            }
          }
        }
      }
    }
  }

  // ── REFERENCES 目标主键（D4-6，按引用解析）──────────────────────────────
  // 目标表一律先解析成 v3 引用，再查该引用的主键；同名跨源不合并，歧义直接判红。
  for (const file of [canonicalDir, designDir]) {
    if (!existsSync(file)) continue;
    for (const name of readdirSync(file).filter((n) => n.startsWith('entity-') && n.endsWith('.md'))) {
      const path = resolve(file, name);
      const sql = readSqlBlock(path);
      if (!sql) continue;
      const text = readFileSync(path, 'utf-8');
      const hints = headHints(text);
      if (hints.objectId) {
        violations.push(`${name} 头部仍声明 objectId（已退役）：改用 sourceId/数据源 + tableRefs 引用`);
      }
      const metadata = parseTableRefsMetadata(text);
      if (metadata.present && metadata.error) violations.push(`${name}：${metadata.error}`);
      const bindings = metadata.present && !metadata.error ? metadata.bindings : [];
      const sourceId = resolveDocSourceId(hints, codeSchema, violations, name);

      // REFERENCES <table>(<col>)：目标引用 → 其基线主键列
      const refRe = /REFERENCES\s+(?:ONLY\s+)?`?([^\s`(;,]+)`?\s*\(\s*`?([A-Za-z_]\w*)`?/gi;
      let match;
      while ((match = refRe.exec(sql)) !== null) {
        const parts = splitQualifiedTableName(match[1]);
        if (!parts || !parts.name) continue;
        const ref = resolveDocTargetRef(parts, { bindings, sourceId }, index, violations, name);
        if (!ref) continue;
        const pk = pkMap.get(refKeyOf(ref));
        if (pk && match[2] !== pk.column) {
          violations.push(`${name}: REFERENCES ${formatRef(ref)}(${match[2]}) 应为 ${pk.column}（D4-6）`);
        }
      }

      // DDL 内 <table>.<col>：按引用名 + source 作用域匹配；同名多引用不合并
      const byName = new Map();
      for (const entry of pkMap.values()) {
        if (sourceId && entry.tableRef.sourceId !== sourceId) continue;
        const list = byName.get(entry.tableRef.name) || [];
        list.push(entry);
        byName.set(entry.tableRef.name, list);
      }
      for (const [tableName, entries] of byName) {
        const binding = bindings.find((item) => item.tableRef.name === tableName);
        const boundEntries = binding
          ? entries.filter((entry) => refKeyOf(entry.tableRef) === refKeyOf(binding.tableRef))
          : entries;
        const uniqueKeys = [...new Set(boundEntries.map((entry) => refKeyOf(entry.tableRef)))];
        if (uniqueKeys.length > 1) {
          const probe = new RegExp('\\b' + escapeRegExp(tableName) + '\\s*\\.', 'i');
          if (probe.test(sql)) {
            violations.push(
              `${name}: DDL 内 ${tableName}.<col> 命中 ${uniqueKeys.length} 个引用` +
                `（${boundEntries.map((entry) => formatRef(entry.tableRef)).join(' / ')}）；` +
                '禁按裸表名合并，请用 tableRef 显式消歧（D4-6）',
            );
          }
          continue;
        }
        const entry = boundEntries[0];
        const dotRe = new RegExp('\\b' + escapeRegExp(tableName) + '\\s*\\.\\s*`?([A-Za-z_]\\w*)`?', 'gi');
        while ((match = dotRe.exec(sql)) !== null) {
          if (match[1] !== entry.column) {
            violations.push(
              `${name}: DDL 内 ${formatRef(entry.tableRef)}.${match[1]} 应为 ${entry.column}（D4-6）`,
            );
          }
        }
      }
    }
  }

  return { ok: violations.length === 0, violations };
}

// ─── CLI ─────────────────────────────────────────────────────────────────────
function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.selfTest) {
    // 自测只验证纯函数可加载，不生成、不落盘。
    console.log(JSON.stringify({ ok: true, mode: 'self-test' }, null, 2));
    return;
  }
  if (!args.check) {
    console.log(
      JSON.stringify(
        {
          ok: false,
          mode: 'rebuild',
          violations: [
            '生成器已退役：rebuild-entity-from-baseline.mjs 不再生成 delta。',
            '增量 delta 由按表 agent phase + 合并层产出；本脚本只接受 --check 只读判据。',
          ],
        },
        null,
        2,
      ),
    );
    process.exit(1);
    return;
  }
  if (!args.codeSchema || !args.entityDir) {
    console.log(
      JSON.stringify(
        { ok: false, mode: 'check', violations: ['--check 需要 --code-schema <path> 与 --entity-dir <backend 目录>'] },
        null,
        2,
      ),
    );
    process.exit(1);
    return;
  }
  let codeSchema;
  try {
    codeSchema = loadCodeSchemaV3(args.codeSchema);
  } catch (error) {
    console.log(JSON.stringify({ ok: false, mode: 'check', violations: [error.message] }, null, 2));
    process.exit(1);
    return;
  }
  const result = verifyArtifacts({
    codeSchema,
    entityDir: resolve(args.entityDir),
    entitySource: args.entitySource ? resolve(args.entitySource) : null,
    operationsPath: args.operations ? resolve(args.operations) : null,
  });
  console.log(
    JSON.stringify(
      {
        ok: result.ok,
        mode: 'check',
        operations: args.operations || join(args.entityDir, MIGRATION_REL, 'operations.json'),
        violations: result.violations,
      },
      null,
      2,
    ),
  );
  if (!result.ok) process.exit(1);
}

const isDirectRun =
  process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));
if (isDirectRun) main();
