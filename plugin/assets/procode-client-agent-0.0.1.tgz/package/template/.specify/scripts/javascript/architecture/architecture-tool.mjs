/* Generated from src/architecture/cli.mts — do not edit; rebuild: node scripts/build-architecture-tools.mjs */


// src/architecture/cli.mts
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

// src/architecture/canonical.ts
import { createHash } from "node:crypto";
function sha256Hex(content) {
  return createHash("sha256").update(content, "utf-8").digest("hex");
}
function digestOf(content) {
  return `sha256:${sha256Hex(content)}`;
}
function canonicalJson(value) {
  return JSON.stringify(sortValue(value));
}
function canonicalJsonPretty(value) {
  return `${JSON.stringify(sortValue(value), null, 2)}
`;
}
function digestOfJson(value) {
  return digestOf(canonicalJson(value));
}
function sortValue(value) {
  if (Array.isArray(value)) {
    return value.map((item) => sortValue(item));
  }
  if (typeof value === "object" && value !== null) {
    const source = value;
    const sorted = {};
    for (const key of Object.keys(source).sort()) {
      if (source[key] === void 0) {
        continue;
      }
      sorted[key] = sortValue(source[key]);
    }
    return sorted;
  }
  return value;
}

// src/architecture/issue-factory.ts
function createIssue(category, code, path2, message, hint) {
  const issue = { category, code, message };
  if (path2 !== void 0) {
    issue.path = path2;
  }
  if (hint !== void 0) {
    issue.hint = hint;
  }
  return issue;
}
function modelIssue(code, path2, message, hint) {
  return createIssue("model", code, path2, message, hint);
}
function inputIssue(code, path2, message, hint) {
  return createIssue("input", code, path2, message, hint);
}
function gateIssue(code, path2, message, hint) {
  return createIssue("gate", code, path2, message, hint);
}

// src/architecture/types/model.ts
var LEGAL_ROLES_BY_NODE_KIND = {
  actor: ["client"],
  frontend: ["client"],
  service: ["access", "business"],
  "application-component": ["access", "business", "integration"],
  "external-system": ["integration"],
  datastore: ["data"],
  infrastructure: ["access", "data", "integration"]
};

// src/architecture/domain-ownership.ts
var OWNERSHIP_DECISION_UNUSABLE = "ownership-decision-unusable";
var OWNERSHIP_DECISION_NOT_APPLIED = "ownership-decision-not-applied";
var DOMAIN_UNCLAIMED = "domain-unclaimed";
var DOMAIN_DOUBLE_CLAIMED = "domain-double-claimed";
var DOMAIN_UNKNOWN = "domain-unknown";
var OWNED_DOMAIN_ON_NON_BUSINESS = "owned-domain-on-non-business";
function decisionPath(decisionId) {
  return `decision:${decisionId}`;
}
function isLegalKindRole(kind, role) {
  const roles = LEGAL_ROLES_BY_NODE_KIND[kind];
  return Array.isArray(roles) && roles.includes(role);
}
function nodesOf(model) {
  return Array.isArray(model?.nodes) ? model.nodes : [];
}
function decisionUnusableReasons(decision, declared, nodesById) {
  const reasons = [];
  const raw = decision ?? {};
  const decisionId = typeof raw.decisionId === "string" ? raw.decisionId : "";
  if (decisionId === "") reasons.push("decisionId \u7F3A\u5931\u6216\u4E0D\u662F\u5B57\u7B26\u4E32");
  const domainId = typeof raw.domainId === "string" ? raw.domainId : "";
  if (domainId === "") reasons.push("domainId \u7F3A\u5931\u6216\u4E0D\u662F\u5B57\u7B26\u4E32");
  else if (!declared.has(domainId)) reasons.push(`\u57DF "${domainId}" \u4E0D\u5728 domain.json \u7684 domains[] \u91CC`);
  if (raw.ownershipScope !== "view" && raw.ownershipScope !== "module") {
    reasons.push(`ownershipScope \u5FC5\u987B\u662F 'view' \u6216 'module'\uFF08\u5B9E\u9645 ${JSON.stringify(raw.ownershipScope)}\uFF09`);
  }
  if (raw.applicationState !== "accepted" && raw.applicationState !== "applied") {
    reasons.push(`applicationState \u5FC5\u987B\u662F 'accepted' \u6216 'applied'\uFF08\u5B9E\u9645 ${JSON.stringify(raw.applicationState)}\uFF09`);
  }
  const ownerNodeId = typeof raw.ownerNodeId === "string" ? raw.ownerNodeId : "";
  const nodeKind = typeof raw.nodeKind === "string" ? raw.nodeKind : "";
  const nodeRole = typeof raw.nodeRole === "string" ? raw.nodeRole : "";
  if (ownerNodeId === "") reasons.push("ownerNodeId \u7F3A\u5931\u6216\u4E0D\u662F\u5B57\u7B26\u4E32");
  if (nodeKind === "" || nodeRole === "") reasons.push("\u51B3\u5B9A\u524D\u63D0 nodeKind / nodeRole \u7F3A\u5931\u6216\u4E0D\u662F\u5B57\u7B26\u4E32");
  else if (!isLegalKindRole(nodeKind, nodeRole)) {
    reasons.push(`\u51B3\u5B9A\u524D\u63D0\u7684 kind/role \u7EC4\u5408\u975E\u6CD5\uFF08kind=${nodeKind}, role=${nodeRole}\uFF09`);
  }
  if (ownerNodeId !== "") {
    const node = nodesById.get(ownerNodeId);
    if (!node) {
      reasons.push(`\u8282\u70B9 "${ownerNodeId}" \u4E0D\u5728 model.nodes[] \u91CC`);
    } else if (nodeKind !== "" && nodeRole !== "" && (node.kind !== nodeKind || node.role !== nodeRole)) {
      reasons.push(
        `\u8282\u70B9 "${ownerNodeId}" \u5F53\u524D kind/role\uFF08${node.kind}/${node.role}\uFF09\u4E0E\u51B3\u5B9A\u524D\u63D0\uFF08${nodeKind}/${nodeRole}\uFF09\u4E0D\u4E00\u81F4`
      );
    } else if (raw.ownershipScope === "module" && node.role !== "business") {
      reasons.push(
        `ownershipScope=module \u53EA\u80FD\u6307\u5411 role='business' \u7684\u540E\u7AEF\u6A21\u5757\uFF08\u8282\u70B9 "${ownerNodeId}" \u5F53\u524D role=${node.role}\uFF09`
      );
    } else if (raw.ownershipScope === "view" && node.kind !== "frontend") {
      reasons.push(
        `ownershipScope=view \u53EA\u80FD\u843D\u5728 kind='frontend' \u7684\u8282\u70B9\uFF08\u8282\u70B9 "${ownerNodeId}" \u5F53\u524D kind=${node.kind}\uFF09`
      );
    }
  }
  return reasons;
}
function resolveDomainOwnership(input) {
  const model = input?.model;
  const domainIds = Array.isArray(input?.domainIds) ? input.domainIds : [];
  const decisions = Array.isArray(input?.decisions) ? input.decisions : [];
  const nodes = nodesOf(model);
  const declared = new Set(domainIds);
  const nodesById = /* @__PURE__ */ new Map();
  nodes.forEach((node) => {
    if (typeof node?.id === "string" && !nodesById.has(node.id)) nodesById.set(node.id, node);
  });
  const issues = [];
  const validByDomain = /* @__PURE__ */ new Map();
  decisions.forEach((decision, index) => {
    const reasons = decisionUnusableReasons(decision, declared, nodesById);
    const raw = decision ?? {};
    const decisionId = typeof raw.decisionId === "string" && raw.decisionId !== "" ? raw.decisionId : `#${index}`;
    const ownerNodeId = typeof raw.ownerNodeId === "string" ? raw.ownerNodeId : "";
    const ownerNodeMissing = ownerNodeId !== "" && !nodesById.has(ownerNodeId);
    const decisionRepair = ownerNodeMissing ? `\u6309\u51B3\u5B9A\u521B\u5EFA\u8282\u70B9 \`${ownerNodeId}\`\uFF08id / kind / role / ownedDomainIds \u4E0E\u51B3\u5B9A\u4E00\u81F4\uFF09\u2014\u2014\u8FD9\u662F\u300C\u65B0\u589E\u4E1A\u52A1\u670D\u52A1\u300D\u8DEF\u7EBF\u5C1A\u672A\u843D\u5B9E\uFF0C**\u4E0D\u662F\u6539\u51B3\u5B9A**\uFF1B\u82E5\u8282\u70B9\u5DF2\u6309\u51B3\u5B9A\u5EFA\u597D\u4ECD\u6709\u5176\u5B83\u524D\u63D0\u4E0D\u7B26\uFF08\u57DF\u3001scope\u3001\u5E94\u7528\u72B6\u6001\uFF09\uFF0C\u624D\u4FEE\u51B3\u5B9A\u672C\u8EAB\uFF1B\u4E0D\u8981\u4E3A\u4E86\u7ED5\u8FC7\u5B83\u53BB\u6539\u5DF2\u786E\u8BA4\u8282\u70B9\u7684 kind/role\uFF0C\u4E5F\u4E0D\u8981\u628A\u524D\u7AEF\u6539\u6210 service` : "\u4FEE\u51B3\u5B9A\u672C\u8EAB\uFF08\u57DF\u3001owner \u8282\u70B9\u3001scope\u3001\u5E94\u7528\u72B6\u6001\u4E0E\u8282\u70B9 kind/role \u524D\u63D0\u5FC5\u987B\u4E0E domain.json \u548C\u6A21\u578B\u4E00\u81F4\uFF09\uFF1B\u4E0D\u8981\u4E3A\u4E86\u7ED5\u8FC7\u5B83\u53BB\u6539\u5DF2\u786E\u8BA4\u8282\u70B9\u7684 kind/role\uFF0C\u4E5F\u4E0D\u8981\u628A\u524D\u7AEF\u6539\u6210 service";
    if (reasons.length > 0) {
      issues.push(
        modelIssue(
          OWNERSHIP_DECISION_UNUSABLE,
          decisionPath(decisionId),
          `\u8BA4\u9886\u51B3\u5B9A\u4E0D\u53EF\u7528\uFF08decisionId=${decisionId}\uFF09\uFF1A${reasons.join("\uFF1B")} \u2014\u2014 \u8BE5\u51B3\u5B9A\u4E0D\u53C2\u4E0E\u5F52\u5C5E\u5224\u5B9A`,
          decisionRepair
        )
      );
      return;
    }
    const entry = { decision, index };
    const existing = validByDomain.get(String(raw.domainId));
    if (existing) existing.push(entry);
    else validByDomain.set(String(raw.domainId), [entry]);
  });
  const appliedByDomain = /* @__PURE__ */ new Map();
  const notAppliedByDomain = /* @__PURE__ */ new Map();
  for (const [domainId, entries] of validByDomain) {
    if (entries.length > 1) {
      const ids = entries.map((entry2) => entry2.decision.decisionId).join(", ");
      issues.push(
        modelIssue(
          OWNERSHIP_DECISION_UNUSABLE,
          decisionPath(domainId),
          `\u57DF "${domainId}" \u6709 ${entries.length} \u6761\u6709\u6548\u8BA4\u9886\u51B3\u5B9A\uFF08decisionId=${ids}\uFF09\u2014\u2014 \u540C\u4E00\u57DF\u53EA\u80FD\u6709\u4E00\u6761\u6709\u6548\u51B3\u5B9A\uFF0C\u91CD\u590D/\u51B2\u7A81\u4E0D\u751F\u6548`,
          "\u6309\u57DF\u4FDD\u7559\u552F\u4E00\u4E00\u6761\u51B3\u5B9A\uFF08\u91CD\u7B54\u8BE5\u9898\u5373\u53EF\u8986\u76D6\u65E7\u7B54\u6848\uFF09\uFF1B\u4E0D\u8981\u6309\u201C\u6700\u540E\u4E00\u6761\u65E5\u5FD7\u201D\u731C\u8986\u76D6\u5173\u7CFB"
        )
      );
      continue;
    }
    const entry = entries[0];
    const ownerNodeId = entry.decision.ownerNodeId;
    const ownerNode = nodesById.get(ownerNodeId);
    const owned = Array.isArray(ownerNode?.ownedDomainIds) ? ownerNode.ownedDomainIds : [];
    if (ownerNode && owned.includes(domainId)) appliedByDomain.set(domainId, entry);
    else notAppliedByDomain.set(domainId, entry);
  }
  const claimants = /* @__PURE__ */ new Map();
  for (const domainId of domainIds) {
    if (!claimants.has(domainId)) claimants.set(domainId, []);
  }
  const governedDomains = new Set(appliedByDomain.keys());
  nodes.forEach((node, index) => {
    const owned = Array.isArray(node?.ownedDomainIds) ? node.ownedDomainIds : void 0;
    if (!owned || owned.length === 0) return;
    if (node?.role !== "business") {
      const ungoverned = owned.filter((domainId) => !governedDomains.has(domainId));
      if (ungoverned.length > 0) {
        issues.push(
          modelIssue(
            OWNED_DOMAIN_ON_NON_BUSINESS,
            `/nodes/${index}/ownedDomainIds`,
            `\u8282\u70B9 "${node?.id}"\uFF08role=${node?.role ?? "\u672A\u58F0\u660E"}\uFF09\u58F0\u660E\u4E86 ownedDomainIds \u2014\u2014 \u53EA\u6709 role: 'business' \u7684\u8282\u70B9\u62E5\u6709\u57DF\uFF08D11/D12\uFF09`,
            `\u5220\u6389\u8BE5\u952E\uFF08access/\u57FA\u7840\u8BBE\u65BD\u8282\u70B9\u65E0\u57DF\u65E0\u5E93\uFF09\uFF1B\u82E5\u786E\u4E3A\u4E1A\u52A1\u6A21\u5757\uFF0C\u628A role \u6539\u6210 'business'\uFF08\u987B\u4E0E kind \u7684\u5408\u6CD5\u89D2\u8272\u7EC4\u5408\u4E00\u81F4\uFF09`
          )
        );
      }
    } else {
      for (const domainId of owned) {
        claimants.get(domainId)?.push(node);
      }
    }
    owned.forEach((domainId, position) => {
      if (declared.has(domainId)) return;
      issues.push(
        modelIssue(
          DOMAIN_UNKNOWN,
          `/nodes/${index}/ownedDomainIds/${position}`,
          `\u57DF "${domainId}" \u4E0D\u5728 domain.json \u7684 domains[] \u91CC\uFF08\u89D2\u8272 = ${node?.role ?? "\u672A\u58F0\u660E"}\uFF09\u2014\u2014 \u57DF\u6620\u5C04\u771F\u503C\u53EA\u80FD\u53D6\u81EA domain.json`,
          `\u6539\u7528 domain.json \u91CC\u7684\u57DF id\uFF1A\u7CBE\u786E\u5339\u914D\uFF08\u542B\u8FDE\u5B57\u7B26 / \u70B9 / \u5192\u53F7\uFF09\uFF0C\u4E0D\u505A\u5927\u5C0F\u5199\u6216\u524D\u7F00\u5F52\u4E00`
        )
      );
    });
  });
  const effective = [];
  for (const [domainId, list] of claimants) {
    const applied = appliedByDomain.get(domainId);
    if (applied) {
      const decision = applied.decision;
      effective.push({
        domainId,
        ownerNodeId: decision.ownerNodeId,
        ownershipScope: decision.ownershipScope,
        decisionId: decision.decisionId
      });
      const extra = list.filter((node) => node?.id !== decision.ownerNodeId);
      if (extra.length > 0) {
        const firstIndex = nodes.findIndex((node) => node === extra[0]);
        const extraIds = extra.map((node) => node.id).join(", ");
        issues.push(
          modelIssue(
            DOMAIN_DOUBLE_CLAIMED,
            `/nodes/${firstIndex}/ownedDomainIds`,
            `\u57DF "${domainId}" \u5DF2\u7531\u8BA4\u9886\u51B3\u5B9A\u5F52\u5C5E "${decision.ownerNodeId}"\uFF08scope=${decision.ownershipScope}\uFF09\uFF0C\u4F46 ${extra.length} \u4E2A business \u8282\u70B9\u4E5F\u58F0\u660E\u4E86\u5B83\uFF08${extraIds}\uFF09\u2014\u2014 \u4E00\u4E2A\u57DF\u53EA\u5F52\u4E00\u4E2A\u6A21\u5757\uFF08D12\uFF09\uFF0C\u51B3\u5B9A\u4E0D\u80FD\u88AB\u5176\u5B83\u58F0\u660E\u66FF\u4EE3`,
            `\u4ECE ${extra.map((node) => `"${node.id}"`).join("\u3001")} \u7684 ownedDomainIds \u91CC\u5220\u6389 "${domainId}"\uFF1B\u4E0D\u8981\u53CD\u5411\u6539\u51B3\u5B9A\uFF0C\u4E5F\u4E0D\u8981\u6539\u5DF2\u786E\u8BA4\u8282\u70B9\u7684 kind/role`
          )
        );
      }
      continue;
    }
    const notApplied = notAppliedByDomain.get(domainId);
    if (notApplied) {
      const decision = notApplied.decision;
      const elsewhere = list.filter((node) => node?.id !== decision.ownerNodeId).map((node) => node.id);
      const elsewhereNote = elsewhere.length > 0 ? `\uFF08\u5F53\u524D\u7531 ${elsewhere.join(", ")} \u58F0\u660E\uFF09` : "";
      issues.push(
        modelIssue(
          OWNERSHIP_DECISION_NOT_APPLIED,
          decisionPath(decision.decisionId),
          `\u57DF "${domainId}" \u5DF2\u6709\u6709\u6548\u8BA4\u9886\u51B3\u5B9A\uFF08ownerNodeId=${decision.ownerNodeId}, ownershipScope=${decision.ownershipScope}\uFF09\uFF0C\u4F46\u5F53\u524D\u6A21\u578B\u672A\u843D\u5B9E\uFF1A\u8282\u70B9 "${decision.ownerNodeId}" \u7684 ownedDomainIds \u672A\u5305\u542B\u8BE5\u57DF${elsewhereNote} \u2014\u2014 \u8BE5\u57DF\u4E0D\u88AB\u9ED8\u8BA4\u89C4\u5219\u63A5\u7BA1\uFF0C\u4E5F\u4E0D\u80FD\u6539\u6D3E\u7ED9\u522B\u7684\u6A21\u5757`,
          `\u5728\u8282\u70B9 "${decision.ownerNodeId}"\uFF08kind=${decision.nodeKind}, role=${decision.nodeRole}\uFF09\u7684 ownedDomainIds \u91CC\u4FDD\u7559 "${domainId}"\uFF1B\u4E0D\u8981\u6539\u6210 service/business\u3001\u4E0D\u8981\u5220\u9664\u8BE5\u57DF\u3001\u4E0D\u8981\u628A\u51B3\u5B9A\u6269\u5927\u89E3\u91CA\u5230\u5176\u5B83\u57DF`
        )
      );
      continue;
    }
    if (list.length === 0) {
      issues.push(
        modelIssue(
          DOMAIN_UNCLAIMED,
          "/nodes",
          `\u57DF "${domainId}" \u6CA1\u6709\u88AB\u4EFB\u4F55 business \u8282\u70B9\u8BA4\u9886 \u2014\u2014 \u57DF\u5212\u5206\u6070\u4E00\u6B21\u8981\u6C42\u6BCF\u4E2A\u57DF\u6070\u88AB\u4E00\u4E2A\u6A21\u5757\u62E5\u6709\uFF08D12\uFF0C\u7F3A\u5E2D\u5373\u7EA2\u4E0D\u8C41\u514D\uFF09`,
          `\u5728\u62E5\u6709\u8BE5\u57DF\u7684 business \u8282\u70B9\u4E0A\u8865 ownedDomainIds: ["${domainId}"]\uFF08\u57DF id \u9010\u5B57\u7B26\u7167\u6284 domain.json\uFF09\uFF1B\u82E5\u8FD8\u6CA1\u6709\u4E1A\u52A1\u670D\u52A1\u627F\u8F7D\u5B83\uFF0C\u5148\u65B0\u589E\u4E00\u4E2A business \u670D\u52A1\uFF0C\u4E0D\u8981\u6302\u5230\u63A5\u5165\u5C42/\u524D\u7AEF`
        )
      );
      continue;
    }
    if (list.length > 1) {
      const ownerIds = list.map((node) => node.id).join(", ");
      const firstIndex = nodes.findIndex((node) => node === list[0]);
      issues.push(
        modelIssue(
          DOMAIN_DOUBLE_CLAIMED,
          `/nodes/${firstIndex}/ownedDomainIds`,
          `\u57DF "${domainId}" \u88AB ${list.length} \u4E2A business \u8282\u70B9\u8BA4\u9886\uFF08${ownerIds}\uFF09\u2014\u2014 \u4E00\u4E2A\u57DF\u53EA\u5F52\u4E00\u4E2A\u6A21\u5757\uFF0C\u6A21\u5757\u53EF\u62E5\u6709\u591A\u4E2A\u57DF\uFF08D12\uFF09`,
          `\u53EA\u5728\u5176\u4E2D\u4E00\u4E2A\u8282\u70B9\u4FDD\u7559 "${domainId}"\uFF0C\u5176\u4F59\u8282\u70B9\u4ECE ownedDomainIds \u91CC\u5220\u6389\u5B83\uFF1B\u82E5\u4E24\u4E2A\u6A21\u5757\u786E\u6709\u91CD\u53E0\u804C\u8D23\uFF0C\u5E94\u62C6\u57DF\u6216\u6539\u7531\u4E00\u4E2A\u6A21\u5757\u62E5\u6709`
        )
      );
      continue;
    }
    const soleOwner = list[0];
    effective.push({
      domainId,
      ownerNodeId: soleOwner.id,
      ownershipScope: "module"
    });
  }
  const businessNodeIds = new Set(
    nodes.filter((node) => node?.role === "business" && typeof node?.id === "string").map((node) => node.id)
  );
  return {
    effective,
    backendModules: effective.filter(
      (entry) => entry.ownershipScope === "module" && businessNodeIds.has(entry.ownerNodeId)
    ),
    issues
  };
}

// src/architecture/query.ts
var MODULE_NODE_KINDS = ["service", "application-component"];

// src/architecture/types/issues.ts
function formatIssuesAsFailures(issues) {
  return issues.map((issue) => {
    const where = issue.path ? ` @ ${issue.path}` : "";
    const head = `[${issue.category}] ${issue.code}${where}: ${issue.message}`;
    return issue.hint ? `${head} \u2014\u2014 \u4FEE\u6CD5\uFF1A${issue.hint}` : head;
  });
}

// src/architecture/validate/contract-ref.ts
var CONTRACT_REF_MISSING = "contract-ref-missing";
var CONTRACT_REF_UNEXPECTED = "contract-ref-unexpected";
var CONTRACT_REF_UNREACHABLE = "contract-ref-unreachable";
var CONTRACT_REF_UNRESOLVED = "contract-ref-unresolved";
var CONTRACT_REF_PATH_FORM = "contract-ref-path-form";
var CONTRACT_REF_PROVIDER_MISMATCH = "contract-ref-provider-mismatch";
var moduleDocPathOf = (providerModuleId) => `backend/modules/${providerModuleId}/tech-design.md`;
var mockDocPathOf = (providerModuleId) => `backend/mock/${providerModuleId}.md`;
var thirdPartyDocPathOf = (providerModuleId) => `backend/third-party/${providerModuleId}.md`;
var ID_SEGMENT = "[A-Za-z0-9][A-Za-z0-9._:-]*";
var ALLOWED_DOC_PATH_FORMS = [
  { form: "module", pattern: new RegExp(`^backend/modules/(${ID_SEGMENT})/tech-design\\.md$`) },
  { form: "mock", pattern: new RegExp(`^backend/mock/(${ID_SEGMENT})\\.md$`) },
  { form: "third-party", pattern: new RegExp(`^backend/third-party/(${ID_SEGMENT})\\.md$`) }
];
var docPathFormOf = (docPath) => {
  for (const entry of ALLOWED_DOC_PATH_FORMS) {
    if (entry.pattern.test(docPath)) return entry.form;
  }
  return null;
};
var DOC_PATH_FORMS_TEXT = `\u2460 ${moduleDocPathOf("<providerModuleId>")}\uFF08business \u63D0\u4F9B\u65B9\uFF09\u2461 ${mockDocPathOf(
  "<providerModuleId>"
)} \u2462 ${thirdPartyDocPathOf("<providerModuleId>")}\uFF08external \u63D0\u4F9B\u65B9\uFF09`;
var REF_REQUIRED_KINDS = ["sync-request", "async-notification"];
var REF_FORBIDDEN_KINDS = ["data-access", "dependency"];
function contractRefIssues(model, resolve, ownership) {
  const issues = [];
  const nodes = Array.isArray(model?.nodes) ? model.nodes : [];
  const interactions = Array.isArray(model?.interactions) ? model.interactions : [];
  const nodeById = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    if (typeof node?.id === "string") nodeById.set(node.id, node);
  }
  const domainToModule = /* @__PURE__ */ new Map();
  const businessModuleIds = /* @__PURE__ */ new Set();
  const resolutionMode = ownership !== void 0 && (Array.isArray(ownership.domainIds) || Array.isArray(ownership.decisions));
  if (resolutionMode) {
    const resolution = resolveDomainOwnership({
      model,
      domainIds: Array.isArray(ownership?.domainIds) ? ownership.domainIds : nodes.flatMap(
        (node) => Array.isArray(node?.ownedDomainIds) ? node.ownedDomainIds.filter((id) => typeof id === "string" && id.length > 0) : []
      ),
      decisions: Array.isArray(ownership?.decisions) ? ownership.decisions : [],
      ...ownership?.domainTypes ? { domainTypes: ownership.domainTypes } : {}
    });
    for (const entry of resolution.backendModules) {
      if (!domainToModule.has(entry.domainId)) domainToModule.set(entry.domainId, entry.ownerNodeId);
      businessModuleIds.add(entry.ownerNodeId);
    }
  } else {
    for (const node of nodes) {
      if (node?.role === "business" && Array.isArray(node.ownedDomainIds)) {
        for (const domainId of node.ownedDomainIds) {
          if (!domainToModule.has(domainId)) domainToModule.set(domainId, node.id);
        }
      }
    }
    for (const moduleId of domainToModule.values()) businessModuleIds.add(moduleId);
  }
  const moduleIdOf = (node) => {
    if (!node || typeof node.id !== "string") return void 0;
    if (node.role === "business" || businessModuleIds.has(node.id)) return node.id;
    return void 0;
  };
  const relationOf = (sourceId, targetId) => {
    const source = typeof sourceId === "string" ? nodeById.get(sourceId) : void 0;
    const target = typeof targetId === "string" ? nodeById.get(targetId) : void 0;
    if (!source || !target) return "unresolved";
    const sourceModule = moduleIdOf(source);
    const targetModule = moduleIdOf(target);
    if (sourceModule !== void 0 && targetModule !== void 0) {
      return sourceModule === targetModule ? "same-module" : "cross-module";
    }
    const sourceBoundary = typeof source.boundaryId === "string" ? source.boundaryId : void 0;
    const targetBoundary = typeof target.boundaryId === "string" ? target.boundaryId : void 0;
    if (sourceBoundary !== void 0 && targetBoundary !== void 0) {
      return sourceBoundary === targetBoundary ? "same-module" : "cross-module";
    }
    return "unresolved";
  };
  interactions.forEach((interaction, index) => {
    const kind = typeof interaction?.kind === "string" ? interaction.kind : "";
    const contractRef = interaction?.contractRef;
    const hasRef = contractRef !== void 0 && contractRef !== null;
    const basePath = `/interactions/${index}/contractRef`;
    if (REF_FORBIDDEN_KINDS.includes(kind) && hasRef) {
      issues.push(
        modelIssue(
          CONTRACT_REF_UNEXPECTED,
          basePath,
          `${kind} \u4EA4\u4E92 "${interaction?.id}" \u4E0D\u8BE5\u5E26 contractRef \u2014\u2014 \u670D\u52A1\u95F4\u5951\u7EA6\u6307\u9488\u53EA\u6302\u5728 sync-request / async-notification \u4E0A\uFF08D16\uFF09`,
          "\u5220\u6389\u8BE5 contractRef\uFF08\u6A21\u5757\u5185\u8BBF\u95EE / \u4F9D\u8D56\u6CA1\u6709\u8DE8\u6A21\u5757\u5951\u7EA6\u53EF\u6307\uFF09"
        )
      );
    }
    if (REF_REQUIRED_KINDS.includes(kind)) {
      const targets = Array.isArray(interaction?.targets) ? interaction.targets : [];
      const crossTargets = [];
      const unresolvedTargets = [];
      for (const target of targets) {
        const relation = relationOf(interaction?.source, target);
        if (relation === "cross-module") crossTargets.push(String(target));
        else if (relation === "unresolved") unresolvedTargets.push(String(target));
      }
      if (crossTargets.length > 0) {
        if (!hasRef) {
          issues.push(
            modelIssue(
              CONTRACT_REF_MISSING,
              basePath,
              `${kind} \u4EA4\u4E92 "${interaction?.id}" \u8DE8\u6A21\u5757\uFF08\u2192 ${crossTargets.join(", ")}\uFF09\u5374\u6CA1\u7ED9 contractRef \u2014\u2014 \u670D\u52A1\u95F4\u5951\u7EA6\u7684\u5355\u4E00\u6743\u5A01\u8F7D\u4F53\u662F\u67B6\u6784\u5951\u7EA6\u672C\u4F53\uFF08D16\uFF09`,
              "\u8865 contractRef: { providerModuleId, docPath, anchor }\uFF0C\u6307\u5411\u63D0\u4F9B\u65B9\u6A21\u5757\u6587\u6863\u7684\u63A5\u53E3\u6BB5 / \u4E8B\u4EF6 schema \u6BB5"
            )
          );
        }
      } else if (unresolvedTargets.length > 0) {
        issues.push(
          inputIssue(
            CONTRACT_REF_UNRESOLVED,
            `/interactions/${index}`,
            `${kind} \u4EA4\u4E92 "${interaction?.id}" \u7684\u8DE8\u6A21\u5757\u6027\u5224\u4E0D\u51FA\uFF08\u76EE\u6807 ${unresolvedTargets.join(", ")} \u65E2\u65E0\u6A21\u5757\u8EAB\u4EFD\u3001\u4E5F\u53D6\u4E0D\u5230 boundaryId\uFF09\u2014\u2014 \u4E0D\u731C\uFF08\u4E0E traffic\u300C\u6761\u4EF6\u4E0D\u8DB3\u4E0D\u731C\u300D\u540C\u53E3\u5F84\uFF09`,
            "\u8865\u9F50\u8FD9\u4E9B\u8282\u70B9\u7684\u6A21\u5757\u5F52\u5C5E\uFF08\u5DF2\u786E\u8BA4\u7684 module \u8BA4\u9886\uFF09\u6216 boundaryId\uFF0C\u6216\u786E\u8BA4\u76EE\u6807 id \u662F\u5426\u62FC\u9519\uFF08canonical id \u542B - . : \uFF0C\u52FF\u622A\u65AD\uFF09"
          )
        );
      }
    }
    if (hasRef && resolve) {
      const reachable = resolve(contractRef, interaction);
      if (!reachable) {
        issues.push(
          modelIssue(
            CONTRACT_REF_UNREACHABLE,
            basePath,
            `contractRef \u4E0D\u53EF\u8FBE\uFF1AproviderModuleId="${contractRef?.providerModuleId}" docPath="${contractRef?.docPath}" anchor="${contractRef?.anchor}" \u2014\u2014 \u6307\u9488\u5FC5\u987B\u6307\u5F97\u5230\u63D0\u4F9B\u65B9\u6A21\u5757\u6587\u6863\u7684\u63A5\u53E3\u6BB5 / \u4E8B\u4EF6 schema \u6BB5\uFF08D16 \u5BF9\u8D26\u95E8\uFF09`,
            "\u6539\u7528\u5B58\u5728\u7684\u6A21\u5757 id \u4E0E\u771F\u5B9E docPath + anchor\uFF1B\u6216\u5148\u628A\u63D0\u4F9B\u65B9\u6A21\u5757\u6587\u6863\u5199\u51FA\u6765"
          )
        );
      }
    }
  });
  return issues;
}
var providerCategoryOf = (node) => {
  if (!node) return "other";
  if (node.role === "business") return "business";
  if (node.kind === "external-system") return "external";
  return "other";
};
var EXPECTED_FORM_OF = {
  business: ["module"],
  external: ["mock", "third-party"]
};
function contractRefStaticIssues(model) {
  const issues = [];
  const nodes = Array.isArray(model?.nodes) ? model.nodes : [];
  const interactions = Array.isArray(model?.interactions) ? model.interactions : [];
  const nodeById = /* @__PURE__ */ new Map();
  for (const node of nodes) {
    if (typeof node?.id === "string") nodeById.set(node.id, node);
  }
  interactions.forEach((interaction, index) => {
    const ref = interaction?.contractRef;
    if (ref === void 0 || ref === null) return;
    const basePath = `/interactions/${index}/contractRef`;
    const providerModuleId = typeof ref.providerModuleId === "string" ? ref.providerModuleId : "";
    const docPath = typeof ref.docPath === "string" ? ref.docPath : "";
    if (docPath.length === 0) {
      issues.push(
        modelIssue(
          CONTRACT_REF_PATH_FORM,
          `${basePath}/docPath`,
          `contractRef.docPath \u4E3A\u7A7A \u2014\u2014 \u6307\u9488\u5FC5\u987B\u6307\u5230**\u771F\u5B9E\u4F1A\u88AB\u4EA7\u51FA\u7684**\u63D0\u4F9B\u65B9\u5951\u7EA6\u6587\u6863\uFF08\u4EA4\u4E92 "${interaction?.id}"\uFF09`,
          `\u8865 ${DOC_PATH_FORMS_TEXT}`
        )
      );
    } else if (docPath.startsWith("plans/")) {
      issues.push(
        modelIssue(
          CONTRACT_REF_PATH_FORM,
          `${basePath}/docPath`,
          `contractRef.docPath \u5E26\u4E86 \`plans/\` \u524D\u7F00\uFF1A"${docPath}" \u2014\u2014 docPath \u7684\u89E3\u6790\u57FA\u76EE\u5F55**\u5DF2\u7ECF\u662F** \`<activeSpecDir>/plans\`\uFF08\u6CE2 1 \u6E32\u67D3 / \u6CE2 7 \u5BF9\u8D26\u95E8\u540C\u4E00\u53E3\u5F84\uFF09\uFF0C\u5E26\u524D\u7F00\u4F1A\u88AB\u89E3\u6790\u6210 \`plans/plans/...\`\uFF0C\u6587\u4EF6\u4E0E\u951A\u70B9\u5373\u4FBF\u90FD\u5728\u4E5F\u6052\u5224\u4E0D\u53EF\u8FBE\uFF082026-10-18 \u6848 A \u7684\u5B9E\u6D4B\u7EA2\u56E0\uFF09`,
          `\u53BB\u6389 \`plans/\` \u524D\u7F00\uFF0C\u6539\u6210\u76F8\u5BF9 \`plans/\` \u7684\u5F62\u6001\uFF1A${DOC_PATH_FORMS_TEXT}`
        )
      );
    } else {
      const form = docPathFormOf(docPath);
      if (form === null) {
        issues.push(
          modelIssue(
            CONTRACT_REF_PATH_FORM,
            `${basePath}/docPath`,
            `contractRef.docPath \u4E0D\u5728\u5C01\u95ED\u767D\u540D\u5355\u4E09\u5F62\u6001\u5185\uFF1A"${docPath}" \u2014\u2014 \u5141\u8BB8\u7684\u5F62\u6001\u53EA\u6709\u4E09\u79CD\uFF1A${DOC_PATH_FORMS_TEXT}\u3002\u7406\u7531\u662F\u8FD9\u4E09\u6761\u6B63\u662F\u6574\u6761\u7BA1\u7EBF**\u771F\u5B9E\u4EA7\u51FA**\u63D0\u4F9B\u65B9\u5951\u7EA6\u6587\u6863\u7684\u4E24\u5904\uFF1A\u6A21\u5757\u6587\u6863\u7531\u6CE2 5 \u4EA7\u51FA\u3001\u5916\u90E8\u7CFB\u7EDF\u5951\u7EA6\u7531\u96C6\u6210\u4E13\u5BB6\u4EA7\u51FA\uFF1B\u5176\u4F59\u81EA\u9020\u8DEF\u5F84\uFF08\`plans/backend/...\`\u3001\`backend/integrations/<nodeId>.md\` \u2026\uFF09\u6574\u6761\u7BA1\u7EBF\u65E0\u4EBA\u4EA7\u51FA\uFF0C\u6307\u9488\u5FC5\u7136\u6052\u4E0D\u53EF\u8FBE`,
            `\u6309\u63D0\u4F9B\u65B9\u8EAB\u4EFD\u6362\u6210\u5BF9\u5E94\u5F62\u6001\uFF08business \u21D2 modules\uFF1Bexternal \u21D2 mock \u6216 third-party\uFF09`
          )
        );
      }
    }
    const provider = nodeById.get(providerModuleId);
    if (!provider) {
      issues.push(
        modelIssue(
          CONTRACT_REF_PROVIDER_MISMATCH,
          `${basePath}/providerModuleId`,
          `contractRef.providerModuleId="${providerModuleId}" \u4E0D\u5728\u6A21\u578B nodes[] \u91CC \u2014\u2014 \u62FC\u9519\u5373\u7EA2\uFF08canonical id \u542B \`-\` \`.\` \`:\`\uFF0C\u9010\u5B57\u7B26\u6838\u5BF9\uFF0C\u4E0D\u62FF\u8FD1\u4F3C\u540D\u731C\uFF09`,
          "providerModuleId \u5FC5\u987B\u662F\u63D0\u4F9B\u65B9\u8282\u70B9\u7684 id \u539F\u6837\uFF08\u4E0D\u662F\u6587\u6863\u540D\u3001\u4E0D\u662F\u5C55\u793A\u540D\uFF09"
        )
      );
    } else {
      const category = providerCategoryOf(provider);
      if (category !== "other") {
        const form = docPathFormOf(docPath);
        if (form !== null && !EXPECTED_FORM_OF[category].includes(form)) {
          issues.push(
            modelIssue(
              CONTRACT_REF_PROVIDER_MISMATCH,
              `${basePath}/docPath`,
              `contractRef \u5F62\u6001\u4E0E\u63D0\u4F9B\u65B9\u8EAB\u4EFD\u4E0D\u7B26\uFF1A\u63D0\u4F9B\u65B9 "${providerModuleId}" \u662F ${category === "business" ? "business\uFF08\u4E1A\u52A1\u6A21\u5757\uFF09" : "external\uFF08\u5916\u90E8\u7CFB\u7EDF\uFF09"} \u8282\u70B9\uFF0CdocPath \u5374\u662F ${form} \u5F62\u6001\uFF08"${docPath}"\uFF09\u2014\u2014 business \u63D0\u4F9B\u65B9\u53EA\u8BB8 ${moduleDocPathOf(
                "<providerModuleId>"
              )}\uFF0Cexternal \u63D0\u4F9B\u65B9\u53EA\u8BB8 ${mockDocPathOf("<providerModuleId>")} \u6216 ${thirdPartyDocPathOf(
                "<providerModuleId>"
              )}`,
              "\u6309\u63D0\u4F9B\u65B9\u8EAB\u4EFD\u6539 docPath \u5F62\u6001\uFF08\u4E1A\u52A1\u6A21\u5757\u6587\u6863\u7531\u6CE2 5 \u4EA7\u51FA\uFF1B\u5916\u90E8\u7CFB\u7EDF\u5951\u7EA6\u7531\u96C6\u6210\u4E13\u5BB6\u843D mock / third-party\uFF09"
            )
          );
        }
      }
    }
  });
  return issues;
}

// src/architecture/validate/domain-claim.ts
function domainClaimIssuesResolved(model, domainIds, decisions, domainTypes) {
  return resolveDomainOwnership({ model, domainIds, decisions, ...domainTypes ? { domainTypes } : {} }).issues;
}

// src/architecture/validate/json-schema.ts
var SUPPORTED_KEYWORDS = [
  "$ref",
  "type",
  "required",
  "properties",
  "additionalProperties",
  "items",
  "minItems",
  "maxItems",
  "uniqueItems",
  "enum",
  "const",
  "pattern",
  "minLength",
  "maxLength",
  "minimum",
  "maximum",
  "allOf",
  "if",
  "then",
  "else",
  "$defs",
  "definitions"
];
var ANNOTATION_KEYWORDS = [
  "$schema",
  "$id",
  "$comment",
  "title",
  "description",
  "examples",
  "default",
  "deprecated",
  "readOnly",
  "writeOnly"
];
var SUPPORTED = new Set(SUPPORTED_KEYWORDS);
var ANNOTATED = new Set(ANNOTATION_KEYWORDS);
var MAX_VALIDATION_DEPTH = 64;
function escapePointerSegment(segment) {
  return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}
function unescapePointerSegment(segment) {
  return segment.replace(/~1/g, "/").replace(/~0/g, "~");
}
function joinPointer(base, segment) {
  return `${base}/${escapePointerSegment(String(segment))}`;
}
function lookupPointer(root, pointer) {
  if (pointer === "") return root;
  if (!pointer.startsWith("/")) return void 0;
  let current = root;
  for (const raw of pointer.split("/").slice(1)) {
    const key = unescapePointerSegment(raw);
    if (current === null || typeof current !== "object") return void 0;
    if (Array.isArray(current)) {
      if (!/^(?:0|[1-9][0-9]*)$/.test(key)) return void 0;
      current = current[Number(key)];
    } else {
      current = current[key];
    }
    if (current === void 0) return void 0;
  }
  return current;
}
function createSchemaRegistry(initial = []) {
  const byId = /* @__PURE__ */ new Map();
  const registry = {
    register(schema) {
      if (isPlainObject(schema) && typeof schema.$id === "string") {
        byId.set(schema.$id, schema);
      }
    },
    get(id) {
      return byId.get(id);
    }
  };
  for (const schema of initial) registry.register(schema);
  return registry;
}
function resolveRef(ref, baseRoot, registry) {
  const hashIndex = ref.indexOf("#");
  const uri = hashIndex === -1 ? ref : ref.slice(0, hashIndex);
  const fragment = hashIndex === -1 ? "" : ref.slice(hashIndex + 1);
  let root;
  if (uri === "") {
    root = baseRoot;
  } else {
    root = registry.get(uri);
    if (root === void 0) return void 0;
  }
  if (fragment === "") return { node: root, root };
  const node = lookupPointer(root, fragment);
  if (node === void 0) return void 0;
  return { node, root };
}
function validateJsonSchema(instance, schema, registry = createSchemaRegistry()) {
  const ctx = { registry, errors: [] };
  validateAt(instance, schema, "", "#", schema, ctx, 0);
  return ctx.errors;
}
function validateAt(instance, rawSchema, pointer, schemaPointer, baseRoot, ctx, depth) {
  if (depth > MAX_VALIDATION_DEPTH) {
    ctx.errors.push({
      pointer,
      schemaPointer,
      keyword: "$ref",
      message: `\u6821\u9A8C\u9012\u5F52\u6DF1\u5EA6\u8D85\u8FC7 ${MAX_VALIDATION_DEPTH}\uFF08\u7591\u4F3C schema \u5B58\u5728 $ref \u73AF\uFF09`
    });
    return;
  }
  if (rawSchema === true || rawSchema === void 0 || rawSchema === null) return;
  if (rawSchema === false) {
    ctx.errors.push({ pointer, schemaPointer, keyword: "false", message: "\u8BE5\u4F4D\u7F6E\u88AB schema \u663E\u5F0F\u7981\u6B62\uFF08false schema\uFF09" });
    return;
  }
  if (!isPlainObject(rawSchema)) return;
  const schema = rawSchema;
  if (typeof schema.$ref === "string") {
    const resolved = resolveRef(schema.$ref, baseRoot, ctx.registry);
    if (!resolved) {
      ctx.errors.push({
        pointer,
        schemaPointer: `${schemaPointer}/$ref`,
        keyword: "$ref",
        message: `\u65E0\u6CD5\u89E3\u6790 $ref "${schema.$ref}"\uFF08\u672A\u6CE8\u518C\u7684 $id \u6216\u53D6\u4E0D\u5230\u7684 fragment\uFF09`
      });
      return;
    }
    validateAt(instance, resolved.node, pointer, `${schemaPointer}/$ref`, resolved.root, ctx, depth + 1);
    return;
  }
  if (schema.if !== void 0) {
    const probe = { registry: ctx.registry, errors: [] };
    validateAt(instance, schema.if, pointer, `${schemaPointer}/if`, baseRoot, probe, depth + 1);
    if (probe.errors.length === 0) {
      if (schema.then !== void 0) {
        validateAt(instance, schema.then, pointer, `${schemaPointer}/then`, baseRoot, ctx, depth + 1);
      }
    } else if (schema.else !== void 0) {
      validateAt(instance, schema.else, pointer, `${schemaPointer}/else`, baseRoot, ctx, depth + 1);
    }
  }
  if (Array.isArray(schema.allOf)) {
    schema.allOf.forEach((sub, index) => {
      validateAt(instance, sub, pointer, `${schemaPointer}/allOf/${index}`, baseRoot, ctx, depth + 1);
    });
  }
  const types = normalizeTypes(schema.type);
  if (types.length > 0 && !types.some((t) => matchesType(instance, t))) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/type`,
      keyword: "type",
      message: `\u7C7B\u578B\u4E0D\u7B26\uFF1A\u671F\u671B ${types.join(" | ")}\uFF0C\u5B9E\u9645 ${describeType(instance)}`
    });
    return;
  }
  if ("const" in schema && !deepEqual(instance, schema.const)) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/const`,
      keyword: "const",
      message: `\u53D6\u503C\u5FC5\u987B\u6052\u7B49\u4E8E ${render(schema.const)}\uFF0C\u5B9E\u9645 ${render(instance)}`
    });
  }
  if (Array.isArray(schema.enum) && !schema.enum.some((candidate) => deepEqual(instance, candidate))) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/enum`,
      keyword: "enum",
      message: `\u53D6\u503C ${render(instance)} \u4E0D\u5728\u679A\u4E3E [${schema.enum.map(render).join(", ")}] \u5185`
    });
  }
  if (typeof instance === "string") {
    validateStringKeywords(instance, schema, pointer, schemaPointer, ctx);
  } else if (typeof instance === "number") {
    validateNumberKeywords(instance, schema, pointer, schemaPointer, ctx);
  } else if (Array.isArray(instance)) {
    validateArrayKeywords(instance, schema, pointer, schemaPointer, baseRoot, ctx, depth);
  } else if (isPlainObject(instance)) {
    validateObjectKeywords(instance, schema, pointer, schemaPointer, baseRoot, ctx, depth);
  }
}
function validateStringKeywords(instance, schema, pointer, schemaPointer, ctx) {
  const length = [...instance].length;
  if (typeof schema.minLength === "number" && length < schema.minLength) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/minLength`,
      keyword: "minLength",
      message: `\u957F\u5EA6 ${length} \u5C0F\u4E8E minLength ${schema.minLength}\uFF08\u4E0D\u5F97\u4E3A\u7A7A\u4E32\uFF09`
    });
  }
  if (typeof schema.maxLength === "number" && length > schema.maxLength) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/maxLength`,
      keyword: "maxLength",
      message: `\u957F\u5EA6 ${length} \u8D85\u8FC7 maxLength ${schema.maxLength}`
    });
  }
  if (typeof schema.pattern === "string") {
    let re;
    try {
      re = new RegExp(schema.pattern);
    } catch {
      ctx.errors.push({
        pointer,
        schemaPointer: `${schemaPointer}/pattern`,
        keyword: "pattern",
        message: `schema \u81EA\u5E26\u7684 pattern \u65E0\u6CD5\u7F16\u8BD1\uFF1A${schema.pattern}\uFF08\u5DE5\u5177\u6545\u969C\uFF0C\u4E0D\u662F\u5019\u9009\u9519\u8BEF\uFF09`
      });
      return;
    }
    if (!re.test(instance)) {
      ctx.errors.push({
        pointer,
        schemaPointer: `${schemaPointer}/pattern`,
        keyword: "pattern",
        message: `\u53D6\u503C ${render(instance)} \u4E0D\u5339\u914D pattern ${schema.pattern}\uFF08canonical id \u542B - . : \uFF0C\u7981\u6309 \\w \u53E3\u5F84\u622A\u65AD\uFF09`
      });
    }
  }
}
function validateNumberKeywords(instance, schema, pointer, schemaPointer, ctx) {
  if (typeof schema.minimum === "number" && instance < schema.minimum) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/minimum`,
      keyword: "minimum",
      message: `\u53D6\u503C ${instance} \u5C0F\u4E8E minimum ${schema.minimum}`
    });
  }
  if (typeof schema.maximum === "number" && instance > schema.maximum) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/maximum`,
      keyword: "maximum",
      message: `\u53D6\u503C ${instance} \u5927\u4E8E maximum ${schema.maximum}`
    });
  }
}
function validateArrayKeywords(instance, schema, pointer, schemaPointer, baseRoot, ctx, depth) {
  if (Array.isArray(schema.items)) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/items`,
      keyword: "items",
      message: "\u6570\u7EC4\u5F0F items\uFF08\u524D\u7F00\u6821\u9A8C\u5F62\u6001\uFF09\u4E0D\u5728\u672C\u5F15\u64CE\u652F\u6301\u5B50\u96C6\u5185 \u2014\u2014 \u6539\u7528\u5355 schema \u7684 items"
    });
  } else if (schema.items !== void 0 && schema.items !== true) {
    instance.forEach((item, index) => {
      validateAt(item, schema.items, joinPointer(pointer, index), `${schemaPointer}/items`, baseRoot, ctx, depth + 1);
    });
  }
  if (typeof schema.minItems === "number" && instance.length < schema.minItems) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/minItems`,
      keyword: "minItems",
      message: `\u9879\u6570 ${instance.length} \u5C11\u4E8E minItems ${schema.minItems}\uFF08\u81F3\u5C11 1 \u9879\uFF09`
    });
  }
  if (typeof schema.maxItems === "number" && instance.length > schema.maxItems) {
    ctx.errors.push({
      pointer,
      schemaPointer: `${schemaPointer}/maxItems`,
      keyword: "maxItems",
      message: `\u9879\u6570 ${instance.length} \u8D85\u8FC7 maxItems ${schema.maxItems}`
    });
  }
  if (schema.uniqueItems === true) {
    const seen = /* @__PURE__ */ new Set();
    instance.forEach((item, index) => {
      const key = canonicalJson(item);
      if (seen.has(key)) {
        ctx.errors.push({
          pointer: joinPointer(pointer, index),
          schemaPointer: `${schemaPointer}/uniqueItems`,
          keyword: "uniqueItems",
          message: `\u7B2C ${index} \u9879\u4E0E\u524D\u9762\u67D0\u9879\u91CD\u590D\uFF08uniqueItems \u8981\u6C42\u4E92\u4E0D\u76F8\u540C\uFF09`
        });
      } else {
        seen.add(key);
      }
    });
  }
}
function validateObjectKeywords(instance, schema, pointer, schemaPointer, baseRoot, ctx, depth) {
  if (Array.isArray(schema.required)) {
    for (const key of schema.required) {
      if (typeof key !== "string") continue;
      if (!hasOwn(instance, key)) {
        ctx.errors.push({
          pointer: joinPointer(pointer, key),
          schemaPointer: `${schemaPointer}/required`,
          keyword: "required",
          message: `\u7F3A\u5C11\u5FC5\u586B\u952E \`${key}\``
        });
      }
    }
  }
  const properties = isPlainObject(schema.properties) ? schema.properties : void 0;
  const declared = properties ? Object.keys(properties) : [];
  if (properties) {
    for (const key of declared) {
      if (!hasOwn(instance, key)) continue;
      validateAt(
        instance[key],
        properties[key],
        joinPointer(pointer, key),
        `${schemaPointer}/properties/${escapePointerSegment(key)}`,
        baseRoot,
        ctx,
        depth + 1
      );
    }
  }
  const additional = schema.additionalProperties;
  if (additional === false) {
    for (const key of Object.keys(instance)) {
      if (declared.includes(key)) continue;
      ctx.errors.push({
        pointer: joinPointer(pointer, key),
        schemaPointer: `${schemaPointer}/additionalProperties`,
        keyword: "additionalProperties",
        message: `\u672A\u58F0\u660E\u7684\u952E \`${key}\`${declared.length > 0 ? `\uFF08\u672C\u5C42\u53EA\u6536\uFF1A${declared.join(", ")}\uFF09` : "\uFF08\u672C\u5C42\u4E0D\u6536\u4EFB\u4F55\u952E\uFF09"}`
      });
    }
  } else if (additional !== void 0 && additional !== true) {
    for (const key of Object.keys(instance)) {
      if (declared.includes(key)) continue;
      validateAt(
        instance[key],
        additional,
        joinPointer(pointer, key),
        `${schemaPointer}/additionalProperties`,
        baseRoot,
        ctx,
        depth + 1
      );
    }
  }
}
function collectUnsupportedKeywords(root) {
  const refs = [];
  const seen = /* @__PURE__ */ new Set();
  const walk = (node, pointer) => {
    if (!isPlainObject(node)) return;
    if (seen.has(node)) return;
    seen.add(node);
    for (const key of Object.keys(node)) {
      if (SUPPORTED.has(key) || ANNOTATED.has(key)) continue;
      refs.push({ pointer: joinPointer(pointer, key), keyword: key });
    }
    for (const key of ["$defs", "definitions", "properties", "patternProperties"]) {
      const sub = node[key];
      if (!isPlainObject(sub)) continue;
      for (const name of Object.keys(sub)) {
        walk(sub[name], joinPointer(joinPointer(pointer, key), name));
      }
    }
    for (const key of [
      "items",
      "additionalProperties",
      "additionalItems",
      "if",
      "then",
      "else",
      "not",
      "propertyNames",
      "contains",
      "unevaluatedItems",
      "unevaluatedProperties"
    ]) {
      const sub = node[key];
      if (Array.isArray(sub)) {
        sub.forEach((entry, index) => walk(entry, joinPointer(joinPointer(pointer, key), index)));
      } else {
        walk(sub, joinPointer(pointer, key));
      }
    }
    for (const key of ["allOf", "anyOf", "oneOf", "prefixItems"]) {
      const sub = node[key];
      if (!Array.isArray(sub)) continue;
      sub.forEach((entry, index) => walk(entry, joinPointer(joinPointer(pointer, key), index)));
    }
  };
  walk(root, "#");
  return refs;
}
function isPlainObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function hasOwn(object, key) {
  return Object.prototype.hasOwnProperty.call(object, key);
}
function deepEqual(a, b) {
  return canonicalJson(a) === canonicalJson(b);
}
function normalizeTypes(type) {
  if (typeof type === "string") return [type];
  if (Array.isArray(type)) return type.filter((entry) => typeof entry === "string");
  return [];
}
function matchesType(instance, type) {
  switch (type) {
    case "object":
      return isPlainObject(instance);
    case "array":
      return Array.isArray(instance);
    case "string":
      return typeof instance === "string";
    case "number":
      return typeof instance === "number" && Number.isFinite(instance);
    case "integer":
      return typeof instance === "number" && Number.isInteger(instance);
    case "boolean":
      return typeof instance === "boolean";
    case "null":
      return instance === null;
    default:
      return false;
  }
}
function describeType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}
function render(value) {
  if (typeof value === "string") return JSON.stringify(value);
  if (value === void 0) return "undefined";
  const text = JSON.stringify(value) ?? String(value);
  return text.length > 80 ? `${text.slice(0, 77)}...` : text;
}

// src/architecture/validate/semantic.ts
var DANGLING_REFERENCE = "DANGLING_REFERENCE";
var COVERAGE_INCOMPLETE = "COVERAGE_INCOMPLETE";
var DERIVED_FACT_IN_MODEL = "DERIVED_FACT_IN_MODEL";
var INTERACTION_TARGET_ARITY = "INTERACTION_TARGET_ARITY";
var DATA_ACCESS_MODE_MISSING = "DATA_ACCESS_MODE_MISSING";
var ILLEGAL_ROLE_FOR_KIND = "ILLEGAL_ROLE_FOR_KIND";
var MODEL_SHAPE_INVALID = "MODEL_SHAPE_INVALID";
var OPERATIONAL_SCOPE_UNKNOWN = "OPERATIONAL_SCOPE_UNKNOWN";
var OPERATIONAL_SCOPE_NOT_MODULE = "OPERATIONAL_SCOPE_NOT_MODULE";
var SEMANTIC_VALIDATION_CRASH = "SEMANTIC_VALIDATION_CRASH";
var MODEL_COLLECTION_KEYS = [
  "boundaries",
  "nodes",
  "interactions",
  "flows",
  "views",
  "openQuestions",
  "coverage"
];
var DERIVED_KEY_PATTERNS = [/^traffic/i, /^resolved/i, /^renderId$/];
function validateArchitectureModelSemantics(model, options) {
  const issues = [];
  try {
    if (!isPlainObject2(model)) {
      return [
        modelIssue(
          MODEL_SHAPE_INVALID,
          "",
          `\u6A21\u578B\u6839\u4E0D\u662F\u5BF9\u8C61\uFF08\u5B9E\u9645 ${describeType2(model)}\uFF09\u2014\u2014 \u8BED\u4E49\u6821\u9A8C\u65E0\u6CD5\u8FDB\u884C`,
          "\u6A21\u578B\u6839\u5FC5\u987B\u662F\u542B schemaVersion/boundaries/nodes/interactions/flows/views/openQuestions/coverage \u7684 JSON \u5BF9\u8C61"
        )
      ];
    }
    const collections = collectCollections(model, issues);
    if (!collections) {
      return issues;
    }
    collectDerivedFactIssues(model, issues);
    collectReferenceIssues(collections, issues);
    collectCoverageIssues(collections.coverage, issues);
    collectInteractionIssues(collections.interactions, issues);
    collectNodeRoleIssues(collections.nodes, issues);
    collectOperationalRequirementIssues(collections.operationalRequirements, collections.nodes, issues);
    const domainIds = Array.isArray(options?.domainIds) ? options.domainIds : [];
    const decisions = Array.isArray(options?.decisions) ? options.decisions : [];
    issues.push(...domainClaimIssuesResolved(model, domainIds, decisions, options?.domainTypes));
    issues.push(...contractRefStaticIssues(model));
    issues.push(
      ...contractRefIssues(model, options?.resolveRef, {
        domainIds,
        decisions,
        ...options?.domainTypes ? { domainTypes: options.domainTypes } : {}
      })
    );
  } catch (error) {
    issues.push(
      gateIssue(
        SEMANTIC_VALIDATION_CRASH,
        "",
        `\u8BED\u4E49\u6821\u9A8C\u5185\u90E8\u5F02\u5E38\uFF1A${errorText(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u6A21\u578B\u7ED5\u8FC7`,
        "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
      )
    );
  }
  return issues;
}
function collectCollections(model, issues) {
  let ok = true;
  const picked = {};
  for (const key of MODEL_COLLECTION_KEYS) {
    const value = model[key];
    if (Array.isArray(value)) {
      picked[key] = value;
    } else {
      ok = false;
      issues.push(
        modelIssue(
          MODEL_SHAPE_INVALID,
          joinPointer("", key),
          `\`${key}\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType2(value)}\uFF09\u2014\u2014 \u6A21\u578B\u4E03\u4E2A\u96C6\u5408\u952E\u90FD\u5FC5\u987B\u662F\u6570\u7EC4`,
          "\u6309\u5951\u7EA6\u8865\u9F50\u8BE5\u96C6\u5408\uFF08\u53EF\u4EE5\u662F\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
        )
      );
    }
  }
  if (!ok) return void 0;
  const operationalRequirements = model.operationalRequirements;
  if (operationalRequirements === void 0) {
    picked.operationalRequirements = [];
  } else if (Array.isArray(operationalRequirements)) {
    picked.operationalRequirements = operationalRequirements;
  } else {
    issues.push(
      modelIssue(
        MODEL_SHAPE_INVALID,
        "/operationalRequirements",
        `\`operationalRequirements\` \u5728\u573A\u4F46\u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType2(operationalRequirements)}\uFF09\u2014\u2014 \u53EF\u9009\u5757\u7684\u4E24\u79CD\u5408\u6CD5\u6001\u662F\u300C\u7F3A\u5E2D\u300D\u6216\u300C\u6570\u7EC4\u300D`,
        "\u5220\u6389\u8BE5\u952E\uFF08\u9700\u6C42\u6CA1\u63D0\u5C31\u4E0D\u8981\u5199\uFF09\uFF0C\u6216\u6539\u6210\u6570\u7EC4\uFF08\u6BCF\u6761\u542B capability / scope / reason\uFF09"
      )
    );
    return void 0;
  }
  return picked;
}
function collectDerivedFactIssues(model, issues) {
  const seen = /* @__PURE__ */ new Set();
  const walk = (value, pointer) => {
    if (Array.isArray(value)) {
      value.forEach((item, index) => walk(item, joinPointer(pointer, index)));
      return;
    }
    if (!isPlainObject2(value)) return;
    if (seen.has(value)) return;
    seen.add(value);
    for (const key of Object.keys(value)) {
      const childPointer = joinPointer(pointer, key);
      if (DERIVED_KEY_PATTERNS.some((pattern) => pattern.test(key))) {
        issues.push(
          modelIssue(
            DERIVED_FACT_IN_MODEL,
            childPointer,
            `\u6A21\u578B\u91CC\u51FA\u73B0\u6D3E\u751F\u4E8B\u5B9E\u952E \`${key}\` \u2014\u2014 \u5DF2\u89E3\u6790\u540D\uFF08resolved*\uFF09/ \u6D41\u91CF\u5206\u7C7B\uFF08traffic*\uFF09/ \u6E32\u67D3 id\uFF08renderId\uFF09\u7531\u6295\u5F71\u751F\u6210\uFF0C\u4E0D\u5F97\u8FDB\u6A21\u578B\uFF08plan \xA72.1\uFF09`,
            "\u5220\u6389\u8BE5\u952E\uFF1B\u8FD9\u4E9B\u503C\u7531\u6295\u5F71\u4ECE model + \u6765\u6E90\u5FEB\u7167\u5BFC\u51FA\uFF0C\u5199\u8FDB\u6A21\u578B\u4F1A\u8BA9\u7248\u672C\u6458\u8981\u5931\u53BB\u552F\u4E00\u4F9D\u636E"
          )
        );
      }
      walk(value[key], childPointer);
    }
  };
  walk(model, "");
}
function collectReferenceIssues(collections, issues) {
  const boundaryIds = new Set(collections.boundaries.map((entry) => entry?.id));
  const nodeIds = new Set(collections.nodes.map((entry) => entry?.id));
  const interactionIds = new Set(collections.interactions.map((entry) => entry?.id));
  const questionIds = new Set(collections.openQuestions.map((entry) => entry?.id));
  const check = (value, known, kind, pointer, hint) => {
    if (value === void 0 || value === null) return;
    if (!known.has(value)) {
      issues.push(
        modelIssue(
          DANGLING_REFERENCE,
          pointer,
          `\u5F15\u7528\u4E0D\u5B58\u5728\u7684${kind} "${String(value)}" \u2014\u2014 \u4E00\u5207\u8DE8\u96C6\u5408\u5F15\u7528\u5FC5\u987B\u547D\u4E2D\u771F\u5B9E\u6761\u76EE`,
          hint
        )
      );
    }
  };
  collections.boundaries.forEach((boundary, index) => {
    check(
      boundary?.parentId,
      boundaryIds,
      "\u8FB9\u754C",
      `/boundaries/${index}/parentId`,
      "\u6539\u6210\u5B58\u5728\u7684 boundary id\uFF1B\u7236\u8FB9\u754C\u987B\u4E0E\u672C\u8FB9\u754C\u540C\u8868\uFF08canonical id \u542B - . : \uFF0C\u9010\u5B57\u7B26\u6838\u5BF9\uFF09"
    );
  });
  collections.nodes.forEach((node, index) => {
    check(
      node?.boundaryId,
      boundaryIds,
      "\u8FB9\u754C",
      `/nodes/${index}/boundaryId`,
      "\u8865\u4E00\u4E2A\u5DF2\u58F0\u660E\u7684 boundary\uFF08\u5916\u90E8\u7CFB\u7EDF\u4E5F\u8981\u843D\u5728\u67D0\u4E2A boundary \u4E0B\uFF09"
    );
  });
  collections.interactions.forEach((interaction, index) => {
    check(
      interaction?.source,
      nodeIds,
      "\u8282\u70B9",
      `/interactions/${index}/source`,
      "source \u5FC5\u987B\u662F nodes[] \u91CC\u7684\u8282\u70B9 id"
    );
    const targets = Array.isArray(interaction?.targets) ? interaction.targets : [];
    targets.forEach((target, position) => {
      check(target, nodeIds, "\u8282\u70B9", `/interactions/${index}/targets/${position}`, "targets \u5FC5\u987B\u662F nodes[] \u91CC\u7684\u8282\u70B9 id");
    });
  });
  collections.flows.forEach((flow, index) => {
    const declared = Array.isArray(flow?.interactionIds) ? flow.interactionIds : [];
    declared.forEach((interactionId, position) => {
      check(
        interactionId,
        interactionIds,
        "\u4EA4\u4E92",
        `/flows/${index}/interactionIds/${position}`,
        "interactionIds \u5FC5\u987B\u662F interactions[] \u91CC\u7684 id"
      );
    });
    const links = Array.isArray(flow?.links) ? flow.links : [];
    links.forEach((link, position) => {
      check(
        link?.fromInteractionId,
        interactionIds,
        "\u4EA4\u4E92",
        `/flows/${index}/links/${position}/fromInteractionId`,
        "\u94FE\u8DEF\u7AEF\u70B9\u7684\u4E24\u4E2A id \u90FD\u5FC5\u987B\u5B58\u5728\u4E8E interactions[]"
      );
      check(
        link?.toInteractionId,
        interactionIds,
        "\u4EA4\u4E92",
        `/flows/${index}/links/${position}/toInteractionId`,
        "\u94FE\u8DEF\u7AEF\u70B9\u7684\u4E24\u4E2A id \u90FD\u5FC5\u987B\u5B58\u5728\u4E8E interactions[]"
      );
    });
  });
  collections.views.forEach((view, index) => {
    const viewNodeIds = Array.isArray(view?.nodeIds) ? view.nodeIds : [];
    viewNodeIds.forEach((nodeId, position) => {
      check(nodeId, nodeIds, "\u8282\u70B9", `/views/${index}/nodeIds/${position}`, "views[].nodeIds \u5FC5\u987B\u662F nodes[] \u91CC\u7684 id");
    });
    const viewInteractionIds = Array.isArray(view?.interactionIds) ? view.interactionIds : [];
    viewInteractionIds.forEach((interactionId, position) => {
      check(
        interactionId,
        interactionIds,
        "\u4EA4\u4E92",
        `/views/${index}/interactionIds/${position}`,
        "views[].interactionIds \u5FC5\u987B\u662F interactions[] \u91CC\u7684 id"
      );
    });
    const groups = Array.isArray(view?.groups) ? view.groups : [];
    const groupIds = new Set(groups.map((group) => group?.id));
    groups.forEach((group, position) => {
      const groupNodeIds = Array.isArray(group?.nodeIds) ? group.nodeIds : [];
      groupNodeIds.forEach((nodeId, nodePosition) => {
        check(
          nodeId,
          nodeIds,
          "\u8282\u70B9",
          `/views/${index}/groups/${position}/nodeIds/${nodePosition}`,
          "\u5206\u7EC4\u91CC\u7684 nodeIds \u5FC5\u987B\u662F nodes[] \u91CC\u7684 id"
        );
      });
      check(
        group?.parentId,
        groupIds,
        "\u5206\u7EC4",
        `/views/${index}/groups/${position}/parentId`,
        "\u7236\u5206\u7EC4\u5FC5\u987B\u662F\u540C\u4E00\u4E2A view \u4E0B\u7684\u5206\u7EC4 id"
      );
    });
  });
  collections.coverage.forEach((entry, index) => {
    const coverageNodeIds = Array.isArray(entry?.nodeIds) ? entry.nodeIds : [];
    coverageNodeIds.forEach((nodeId, position) => {
      check(nodeId, nodeIds, "\u8282\u70B9", `/coverage/${index}/nodeIds/${position}`, "coverage[].nodeIds \u5FC5\u987B\u662F nodes[] \u91CC\u7684 id");
    });
    const coverageInteractionIds = Array.isArray(entry?.interactionIds) ? entry.interactionIds : [];
    coverageInteractionIds.forEach((interactionId, position) => {
      check(
        interactionId,
        interactionIds,
        "\u4EA4\u4E92",
        `/coverage/${index}/interactionIds/${position}`,
        "coverage[].interactionIds \u5FC5\u987B\u662F interactions[] \u91CC\u7684 id"
      );
    });
    const coverageQuestionIds = Array.isArray(entry?.questionIds) ? entry.questionIds : [];
    coverageQuestionIds.forEach((questionId, position) => {
      check(
        questionId,
        questionIds,
        "\u672A\u51B3\u9879",
        `/coverage/${index}/questionIds/${position}`,
        "coverage[].questionIds \u5FC5\u987B\u662F openQuestions[] \u91CC\u7684 id"
      );
    });
  });
}
function collectCoverageIssues(coverage, issues) {
  coverage.forEach((entry, index) => {
    const nodeIds = Array.isArray(entry?.nodeIds) ? entry.nodeIds : [];
    const interactionIds = Array.isArray(entry?.interactionIds) ? entry.interactionIds : [];
    const questionIds = Array.isArray(entry?.questionIds) ? entry.questionIds : [];
    const subject = entry?.subject ?? entry?.sourceRef ?? `#${index}`;
    if (entry?.disposition === "represented" && nodeIds.length === 0 && interactionIds.length === 0) {
      issues.push(
        modelIssue(
          COVERAGE_INCOMPLETE,
          `/coverage/${index}`,
          `\u8986\u76D6\u6761\u76EE "${subject}" \u5224\u4E3A represented\uFF0C\u5374\u6CA1\u6709 nodeIds \u4E5F\u6CA1\u6709 interactionIds \u2014\u2014 \u8282\u70B9\u5728\u573A\u4E0D\u7B49\u4E8E\u5173\u7CFB\u5728\u573A\uFF08plan \xA72.1\uFF09`,
          "\u8865 nodeIds \u6216 interactionIds\uFF08\u22651\uFF09\uFF1B\u82E5\u786E\u5B9E\u6CA1\u88AB\u8868\u8FBE\uFF0C\u6539\u5224 out-of-scope \u6216 unresolved"
        )
      );
    }
    if (entry?.disposition === "unresolved" && questionIds.length === 0) {
      issues.push(
        modelIssue(
          COVERAGE_INCOMPLETE,
          `/coverage/${index}`,
          `\u8986\u76D6\u6761\u76EE "${subject}" \u5224\u4E3A unresolved\uFF0C\u5374\u6CA1\u6709 questionIds \u2014\u2014 \u672A\u51B3\u5FC5\u987B\u843D\u6210\u53EF\u56DE\u7B54\u7684 openQuestion\uFF0C\u5426\u5219\u7F3A\u53E3\u65E0\u4EBA\u63A5`,
          "\u5728 openQuestions[] \u91CC\u52A0\u5BF9\u5E94\u95EE\u9898\uFF0C\u5E76\u628A\u5176 id \u586B\u8FDB\u8BE5\u6761 coverage \u7684 questionIds"
        )
      );
    }
  });
}
function collectInteractionIssues(interactions, issues) {
  interactions.forEach((interaction, index) => {
    const targets = Array.isArray(interaction?.targets) ? interaction.targets : [];
    const kind = interaction?.kind;
    if ((kind === "sync-request" || kind === "data-access") && targets.length !== 1) {
      issues.push(
        modelIssue(
          INTERACTION_TARGET_ARITY,
          `/interactions/${index}/targets`,
          `${kind} \u4EA4\u4E92 "${interaction?.id}" \u6709 ${targets.length} \u4E2A target \u2014\u2014 ${kind} \u6070 1 \u4E2A\u76EE\u6807\uFF08plan \xA711.2\uFF09`,
          `\u53EA\u4FDD\u7559 1 \u4E2A target\uFF1B\u8981\u8868\u8FBE\u6247\u51FA\u8BF7\u62C6\u6210\u591A\u6761\u4EA4\u4E92\u6216\u6539\u7528 async-notification`
        )
      );
    }
    if (kind === "data-access" && (interaction?.access === void 0 || interaction?.access === null)) {
      issues.push(
        modelIssue(
          DATA_ACCESS_MODE_MISSING,
          `/interactions/${index}/access`,
          `data-access \u4EA4\u4E92 "${interaction?.id}" \u7F3A access \u2014\u2014 \u6570\u636E\u8BBF\u95EE\u5FC5\u987B\u58F0\u660E\u8BFB/\u5199/\u8BFB\u5199\uFF08plan \xA711.2\uFF09`,
          `\u8865 access: 'read' | 'write' | 'read-write'`
        )
      );
    }
  });
}
function collectNodeRoleIssues(nodes, issues) {
  nodes.forEach((node, index) => {
    if (node?.role === void 0 || node?.role === null) return;
    const legal = LEGAL_ROLES_BY_NODE_KIND[node.kind];
    if (!legal) return;
    if (!legal.includes(node.role)) {
      issues.push(
        modelIssue(
          ILLEGAL_ROLE_FOR_KIND,
          `/nodes/${index}/role`,
          `role "${node.role}" \u4E0D\u662F kind "${node.kind}" \u7684\u5408\u6CD5\u89D2\u8272\uFF08\u5408\u6CD5\uFF1A${legal.join(", ")}\uFF09`,
          `\u6309\u804C\u8D23\u9009\u5408\u6CD5\u89D2\u8272\uFF1B\u63A5\u5165\u804C\u8D23\u5C5E\u4E8E\u89D2\u8272\uFF0C\u4E0D\u80FD\u9760\u4EA7\u54C1\u540D\uFF08BFF / Gateway\uFF09\u63A8\u5BFC`
        )
      );
    }
  });
}
function collectOperationalRequirementIssues(requirements, nodes, issues) {
  if (requirements.length === 0) return;
  const moduleKinds = new Set(MODULE_NODE_KINDS);
  const nodeById = /* @__PURE__ */ new Map();
  nodes.forEach((node) => {
    if (typeof node?.id === "string") nodeById.set(node.id, node);
  });
  requirements.forEach((entry, index) => {
    const scope = Array.isArray(entry?.scope) ? entry.scope : [];
    scope.forEach((value, position) => {
      if (value === "*") return;
      const pointer = `/operationalRequirements/${index}/scope/${position}`;
      const node = nodeById.get(value);
      if (node === void 0) {
        issues.push(
          modelIssue(
            OPERATIONAL_SCOPE_UNKNOWN,
            pointer,
            `\u8FD0\u7EF4\u58F0\u660E ${index} \u7684 scope "${String(value)}" \u4E0D\u662F nodes[] \u91CC\u7684\u8282\u70B9 id\uFF08\u4E5F\u4E0D\u662F \`*\`\uFF09\u2014\u2014 \u58F0\u660E\u6307\u4E0D\u5230\u4EFB\u4F55\u6A21\u5757\u7B49\u4E8E\u6302\u7A7A`,
            "\u6539\u6210 nodes[] \u91CC\u771F\u5B9E\u5B58\u5728\u7684\u6A21\u5757 id\uFF08canonical id \u542B - . : \uFF0C\u9010\u5B57\u7B26\u6838\u5BF9\uFF09\uFF0C\u6216\u5199 `*` \u8868\u793A\u5168\u90E8\u6A21\u5757\uFF1B\u4E0D\u8981\u65B0\u589E\u8282\u70B9\u6765\u51D1"
          )
        );
        return;
      }
      if (!moduleKinds.has(node.kind)) {
        issues.push(
          modelIssue(
            OPERATIONAL_SCOPE_NOT_MODULE,
            pointer,
            `\u8FD0\u7EF4\u58F0\u660E scope="${value}" \u6307\u5411 ${node.kind} \u8282\u70B9\uFF1A\u8FD0\u7EF4\u80FD\u529B\u53EA\u80FD\u58F0\u660E\u5728\u6A21\u5757\u7C7B\u8282\u70B9\uFF08service / application-component\uFF09\u4E0A\uFF0C\u6216\u5199 "*" \u8868\u793A\u5168\u90E8\u6A21\u5757`,
            `\u628A scope \u6539\u6210\u6A21\u5757\u7C7B\u8282\u70B9\uFF08service / application-component\uFF09\u7684 id\uFF0C\u6216\u5199 "*" \u8868\u793A\u5168\u90E8\u6A21\u5757\uFF1B${node.kind} \u8282\u70B9\u4E0D\u662F\u8FD0\u7EF4\u80FD\u529B\u7684\u627F\u8F7D\u5BF9\u8C61`
          )
        );
      }
    });
  });
}
function isPlainObject2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function describeType2(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}
function errorText(error) {
  if (error instanceof Error) return `${error.name}: ${error.message}`;
  return String(error);
}

// src/architecture/project/names.ts
var NODE_NAME_UNRESOLVED = "NODE_NAME_UNRESOLVED";
var NODE_NAME_RESOLUTION_CRASH = "NODE_NAME_RESOLUTION_CRASH";
function resolveNames(model, resolver) {
  const resolvedNodes = [];
  const issues = [];
  try {
    const nodes = model?.nodes;
    if (!Array.isArray(nodes)) {
      return {
        resolvedNodes,
        issues: [
          modelIssue(
            MODEL_SHAPE_INVALID,
            "/nodes",
            `\`nodes\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(nodes)}\uFF09\u2014\u2014 \u540D\u79F0\u89E3\u6790\u65E0\u4ECE\u8FDB\u884C`,
            "\u6309\u5951\u7EA6\u8865\u9F50 nodes\uFF08\u53EF\u4E3A\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
          )
        ]
      };
    }
    nodes.forEach((entry, index) => {
      if (!isPlainObject3(entry)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            `/nodes/${index}`,
            `\u8282\u70B9\u6761\u76EE\u4E0D\u662F\u5BF9\u8C61\uFF08\u5B9E\u9645 ${describeType3(entry)}\uFF09\u2014\u2014 \u8DF3\u8FC7\u8BE5\u6761\uFF0C\u5176\u4F59\u7167\u5E38\u89E3\u6790`,
            "\u6309\u5951\u7EA6\u628A nodes[] \u7684\u6BCF\u4E00\u9879\u5199\u6210\u5BF9\u8C61"
          )
        );
        return;
      }
      const id = typeof entry.id === "string" ? entry.id : "";
      const trafficRole = trafficRoleOf(entry);
      const ref = readAuthorityRef(entry.ref);
      if (ref && typeof resolver === "function") {
        const resolved = safeResolveName(resolver, ref);
        if (typeof resolved === "string" && resolved.length > 0) {
          resolvedNodes.push(withTrafficRole({ id, name: resolved, nameSource: "ref" }, trafficRole));
          return;
        }
        issues.push(
          modelIssue(
            NODE_NAME_UNRESOLVED,
            `/nodes/${index}/ref`,
            `\u8282\u70B9 "${id}" \u5F15\u7528\u7684 ${ref.source}#${ref.id} \u89E3\u6790\u4E0D\u5230\u5C55\u793A\u540D\u79F0 \u2014\u2014 \u5DF2\u6309\u515C\u5E95\u540D\u5904\u7406`,
            "\u786E\u8BA4\u5F15\u7528\u5BF9\u8C61\u5B58\u5728\u4E14\u5DF2\u88AB\u672C\u8F6E\u8F93\u5165\u8986\u76D6\uFF1B\u7F3A\u4EF6\u65F6\u5148\u8865\u4EA7\u518D\u8C03\u7528\uFF0C\u4E0D\u8981\u53E6\u586B\u4E00\u4E2A\u540D\u5B57\u7ED5\u8FC7"
          )
        );
      }
      const declaredName = typeof entry.name === "string" ? entry.name : "";
      if (declaredName.length > 0) {
        resolvedNodes.push(withTrafficRole({ id, name: declaredName, nameSource: "model" }, trafficRole));
        return;
      }
      resolvedNodes.push(withTrafficRole({ id, name: id, nameSource: "fallback-id" }, trafficRole));
    });
    return { resolvedNodes, issues };
  } catch (error) {
    return {
      resolvedNodes,
      issues: [
        ...issues,
        gateIssue(
          NODE_NAME_RESOLUTION_CRASH,
          "",
          `\u540D\u79F0\u89E3\u6790\u5185\u90E8\u5F02\u5E38\uFF1A${errorText2(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u6A21\u578B\u7ED5\u8FC7`,
          "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
        )
      ]
    };
  }
}
function readAuthorityRef(value) {
  if (!isPlainObject3(value)) return void 0;
  const { source, id } = value;
  if (typeof source !== "string" || source.length === 0) return void 0;
  if (typeof id !== "string" || id.length === 0) return void 0;
  return { source, id };
}
function safeResolveName(resolver, ref) {
  try {
    const resolved = resolver({ source: ref.source, id: ref.id });
    return typeof resolved === "string" ? resolved : void 0;
  } catch {
    return void 0;
  }
}
function withTrafficRole(node, trafficRole) {
  return trafficRole === void 0 ? node : { ...node, trafficRole };
}
function isPlainObject3(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function describeType3(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  return typeof value;
}
function errorText2(error) {
  if (error instanceof Error) return `${error.name}: ${error.message}`;
  return String(error);
}
var ALL_NODE_ROLES = ["client", "access", "business", "data", "integration"];
function legalRolesForKind(kind) {
  if (typeof kind !== "string") return [];
  const legal = LEGAL_ROLES_BY_NODE_KIND[kind];
  return Array.isArray(legal) ? legal : [];
}
function possibleNodeRoles(node) {
  const declared = node?.role;
  if (typeof declared === "string" && ALL_NODE_ROLES.includes(declared)) {
    return [declared];
  }
  const legal = legalRolesForKind(node?.kind);
  return legal.length > 0 ? [...legal] : [...ALL_NODE_ROLES];
}
function trafficRoleOf(node) {
  const possible = possibleNodeRoles(node);
  return possible.length === 1 ? possible[0] : void 0;
}

// src/architecture/project/traffic.ts
var TRAFFIC_CLASS_UNRESOLVED = "TRAFFIC_CLASS_UNRESOLVED";
var TRAFFIC_CLASSIFICATION_CRASH = "TRAFFIC_CLASSIFICATION_CRASH";
var MAX_TRAIT_COMBINATIONS = 4096;
var ARROW_BY_TRAFFIC = {
  "north-south": "==>",
  "east-west": "-.->",
  external: "-->"
};
function arrowForTrafficClass(trafficClass) {
  return ARROW_BY_TRAFFIC[trafficClass];
}
function trafficClassLabel(trafficClass) {
  switch (trafficClass) {
    case "north-south":
      return "\u5357\u5317\u5411";
    case "east-west":
      return "\u4E1C\u897F\u5411";
    case "external":
      return "\u5916\u90E8";
    default:
      return "\u672A\u5224\u5B9A";
  }
}
var TRAFFIC_LEGEND_LINES = [
  "\u7EBF\u578B\u56FE\u4F8B\uFF08\u6D41\u91CF\u7C7B\u522B\u7531\u6295\u5F71\u5224\u5B9A\uFF0Cagent \u7981\u586B\uFF09\uFF1A",
  `- \`${arrowForTrafficClass("north-south")}\` ${trafficClassLabel("north-south")}\uFF1A\u5165\u53E3\u6D41\u91CF\uFF08\u5BA2\u6237\u7AEF / \u63A5\u5165 \u2192 \u7CFB\u7EDF\u5185\uFF09`,
  `- \`${arrowForTrafficClass("east-west")}\` ${trafficClassLabel("east-west")}\uFF1A\u7CFB\u7EDF\u5185\u670D\u52A1\u95F4\u6D41\u91CF`,
  `- \`${arrowForTrafficClass("external")}\` ${trafficClassLabel("external")}\uFF1A\u8DE8\u7CFB\u7EDF\u8FB9\u754C\u7684\u6D41\u91CF`
];
function classifyModelTraffic(model) {
  const classifications = [];
  const issues = [];
  try {
    const rawNodes = model?.nodes;
    const rawInteractions = model?.interactions;
    if (!Array.isArray(rawNodes) || !Array.isArray(rawInteractions)) {
      if (!Array.isArray(rawNodes)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            "/nodes",
            `\`nodes\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(rawNodes)}\uFF09\u2014\u2014 \u6D41\u91CF\u5206\u7C7B\u65E0\u4ECE\u8FDB\u884C`,
            "\u6309\u5951\u7EA6\u8865\u9F50 nodes\uFF08\u53EF\u4E3A\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
          )
        );
      }
      if (!Array.isArray(rawInteractions)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            "/interactions",
            `\`interactions\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(rawInteractions)}\uFF09\u2014\u2014 \u6D41\u91CF\u5206\u7C7B\u65E0\u4ECE\u8FDB\u884C`,
            "\u6309\u5951\u7EA6\u8865\u9F50 interactions\uFF08\u53EF\u4E3A\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
          )
        );
      }
      return { classifications, issues };
    }
    const nodeById = /* @__PURE__ */ new Map();
    rawNodes.forEach((entry) => {
      if (!isPlainObject3(entry)) return;
      if (typeof entry.id === "string") nodeById.set(entry.id, entry);
    });
    const boundaryById = buildBoundaryIndex(model);
    rawInteractions.forEach((entry, index) => {
      if (!isPlainObject3(entry)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            `/interactions/${index}`,
            `\u4EA4\u4E92\u6761\u76EE\u4E0D\u662F\u5BF9\u8C61\uFF08\u5B9E\u9645 ${describeType3(entry)}\uFF09\u2014\u2014 \u8DF3\u8FC7\u8BE5\u6761\uFF0C\u5176\u4F59\u7167\u5E38\u5206\u7C7B`,
            "\u6309\u5951\u7EA6\u628A interactions[] \u7684\u6BCF\u4E00\u9879\u5199\u6210\u5BF9\u8C61"
          )
        );
        return;
      }
      const interactionId = typeof entry.id === "string" ? entry.id : "";
      const targets = entry.targets;
      if (interactionId.length === 0 || typeof entry.source !== "string" || !isStringArray(targets)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            `/interactions/${index}`,
            `\u4EA4\u4E92\u6761\u76EE\u5F62\u6001\u65E0\u6548\uFF08\u9700\u8981\u975E\u7A7A\u5B57\u7B26\u4E32 id\u3001\u5B57\u7B26\u4E32 source\u3001\u5B57\u7B26\u4E32\u6570\u7EC4 targets\uFF1B\u5B9E\u9645 id=${describeType3(
              entry.id
            )}, source=${describeType3(entry.source)}, targets=${describeType3(targets)}\uFF09\u2014\u2014 \u8DF3\u8FC7\u8BE5\u6761`,
            "\u6309\u5951\u7EA6\u8865\u9F50 id / source / targets\uFF1B\u5F62\u6001\u65E0\u6548\u7684\u4EA4\u4E92\u4E0D\u53C2\u4E0E\u6D41\u91CF\u5206\u7C7B"
          )
        );
        return;
      }
      const result = classifyEnds(boundaryById, nodeById, entry.source, targets);
      classifications.push({ interactionId, trafficClass: result.trafficClass, reason: result.reason });
      if (result.trafficClass === null) {
        issues.push(
          modelIssue(
            TRAFFIC_CLASS_UNRESOLVED,
            `/interactions/${index}`,
            `\u4EA4\u4E92 "${interactionId}" \u65E0\u6CD5\u5224\u5B9A\u6D41\u91CF\u7C7B\u522B\uFF1A${result.reason}`,
            "\u6309 kind \u8865\u9F50\u7AEF\u70B9\u7684 role\uFF08service / application-component / infrastructure \u6709\u591A\u6761\u5408\u6CD5\u89D2\u8272\uFF0C\u5FC5\u987B\u663E\u5F0F\u58F0\u660E\uFF09\uFF0C\u6216\u4FEE\u6B63 boundaryId \u4E0E\u7236\u7EA7\u94FE\uFF1B\u7981\u9759\u9ED8\u9009\u9ED8\u8BA4\u7EBF\u578B\uFF08plan \xA711.2 \u6761\u4EF6\u4E0D\u8DB3\u4E0D\u731C\uFF09"
          )
        );
      }
    });
    return { classifications, issues };
  } catch (error) {
    return {
      classifications,
      issues: [
        ...issues,
        gateIssue(
          TRAFFIC_CLASSIFICATION_CRASH,
          "",
          `\u6D41\u91CF\u5206\u7C7B\u5185\u90E8\u5F02\u5E38\uFF1A${errorText2(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u6A21\u578B\u7ED5\u8FC7`,
          "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
        )
      ]
    };
  }
}
function classifyEnds(boundaryById, nodeById, sourceId, targetIds) {
  const ends = [];
  const missing = [];
  const source = nodeById.get(sourceId);
  if (!source) {
    missing.push(`\u53D1\u8D77\u65B9 "${sourceId}" \u4E0D\u662F nodes[] \u91CC\u7684\u8282\u70B9\uFF08\u5F15\u7528\u672A\u89E3\u6790\uFF09`);
  } else {
    ends.push(buildEndOptions(boundaryById, source, sourceId));
  }
  for (const targetId of targetIds) {
    const target = nodeById.get(targetId);
    if (!target) {
      missing.push(`\u63A5\u6536\u65B9 "${targetId}" \u4E0D\u662F nodes[] \u91CC\u7684\u8282\u70B9\uFF08\u5F15\u7528\u672A\u89E3\u6790\uFF09`);
      continue;
    }
    ends.push(buildEndOptions(boundaryById, target, targetId));
  }
  if (missing.length > 0) {
    return { trafficClass: null, reason: `\u6761\u4EF6\u4E0D\u8DB3\uFF1A${missing.join("\uFF1B")} \u21D2 \u4E0D\u731C\uFF08plan \xA711.2 \u6761\u4EF6\u4E0D\u8DB3\u4E0D\u731C\uFF09` };
  }
  const worlds = ends.map(worldsOf);
  const total = worlds.reduce((acc, list) => acc * list.length, 1);
  const nodeIds = ends.map((end) => end.nodeId);
  if (total > MAX_TRAIT_COMBINATIONS) {
    return {
      trafficClass: null,
      reason: `\u6761\u4EF6\u4E0D\u8DB3\uFF1A\u7AEF\u70B9\u53EF\u80FD\u53D6\u503C\u7EC4\u5408\u8FC7\u591A\uFF08${total} > ${MAX_TRAIT_COMBINATIONS}\uFF09\u2014\u2014 \u65E0\u6CD5\u5728\u6B64\u5224\u5B9A \u21D2 \u4E0D\u731C\uFF08plan \xA711.2 \u6761\u4EF6\u4E0D\u8DB3\u4E0D\u731C\uFF09`
    };
  }
  const hits = /* @__PURE__ */ new Map();
  const cursor = new Array(worlds.length).fill(0);
  for (let step = 0; step < total; step += 1) {
    const combination = worlds.map((list, position) => list[cursor[position]]);
    const hit = applyRules(combination, nodeIds);
    if (!hits.has(hit.trafficClass)) {
      hits.set(hit.trafficClass, hit);
      if (hits.size > 1) break;
    }
    for (let position = cursor.length - 1; position >= 0; position -= 1) {
      cursor[position] += 1;
      if (cursor[position] < worlds[position].length) break;
      cursor[position] = 0;
    }
  }
  const first = hits.values().next();
  if (hits.size === 1 && !first.done) {
    const hit = first.value;
    const ambiguous = ends.some((end) => end.externalValues.length > 1 || end.roleValues.length > 1);
    const suffix = ambiguous ? "\uFF08\u7AEF\u70B9\u5B58\u5728\u672A\u58F0\u660E\u7684 role / \u672A\u89E3\u6790\u7684\u8FB9\u754C\u5F52\u5C5E\uFF0C\u4F46\u6240\u6709\u53EF\u80FD\u53D6\u503C\u90FD\u5F97\u51FA\u540C\u4E00\u7C7B\u522B\uFF09" : "";
    return { trafficClass: hit.trafficClass, reason: `\u5224\u636E ${hit.rule}\uFF1A${hit.detail}${suffix}` };
  }
  const notes = missingInfoNotes(ends);
  const outcomes = [...hits.keys()].join(" / ");
  return {
    trafficClass: null,
    reason: `\u6761\u4EF6\u4E0D\u8DB3\uFF1A${notes.join("\uFF1B")} \u2014\u2014 \u4E0D\u540C\u53D6\u503C\u4F1A\u5F97\u51FA\u4E0D\u540C\u5206\u7C7B\uFF08${outcomes}\uFF09\u21D2 \u4E0D\u731C\uFF08plan \xA711.2 \u6761\u4EF6\u4E0D\u8DB3\u4E0D\u731C\uFF09`
  };
}
function applyRules(ends, nodeIds) {
  const source = ends[0];
  const targets = ends.slice(1);
  if (source.external && targets.every((target) => target.external)) {
    return {
      trafficClass: "external",
      rule: 1,
      detail: `\u53CC\u7AEF\u5747\u4E3A\u5916\u90E8\uFF08kind=external-system\uFF0C\u6216\u6240\u5728\u8FB9\u754C ownership=external\uFF09\uFF1A${nodeIds.join("\u3001")}`
    };
  }
  if (isClientClassKind(source.kind) || source.role === "client") {
    return {
      trafficClass: "north-south",
      rule: 2,
      detail: `\u53D1\u8D77\u65B9 "${nodeIds[0]}" \u662F\u5BA2\u6237\u7AEF\u7C7B\uFF08kind=${source.kind}\uFF0Crole=${source.role}\uFF09`
    };
  }
  const businessTarget = targets.findIndex((target) => target.role === "business");
  if (source.role === "access" && businessTarget >= 0) {
    return {
      trafficClass: "north-south",
      rule: 3,
      detail: `access \u2192 business \u8F6C\u53D1\uFF08\u53D1\u8D77\u65B9 "${nodeIds[0]}" role=access\uFF1B\u63A5\u6536\u65B9 "${nodeIds[businessTarget + 1]}" role=business\uFF09`
    };
  }
  const externalEnds = ends.map((end, position) => end.external ? nodeIds[position] : void 0).filter((id) => id !== void 0);
  if (externalEnds.length > 0) {
    return {
      trafficClass: "north-south",
      rule: 4,
      detail: `\u540C\u4E00\u4EA4\u4E92\u4E00\u7AEF\u5728\u5185\u90E8\u3001\u4E00\u7AEF\u5728\u5916\u90E8\uFF08\u5916\u90E8\u7AEF\uFF1A${externalEnds.join("\u3001")}\uFF09`
    };
  }
  return {
    trafficClass: "east-west",
    rule: 5,
    detail: `\u5168\u90E8\u7AEF\u70B9\u90FD\u5728\u5185\u90E8\u7CFB\u7EDF\u3001\u4E14\u4E0D\u6784\u6210 access \u2192 business \u8F6C\u53D1\uFF08\u5185\u90E8\u670D\u52A1\u95F4\u6D41\u91CF\uFF09\uFF1A${nodeIds.join("\u3001")}`
  };
}
function isClientClassKind(kind) {
  return kind === "actor" || kind === "frontend";
}
function buildEndOptions(boundaryById, node, nodeId) {
  const kind = typeof node.kind === "string" ? node.kind : "";
  const boundaryId = typeof node.boundaryId === "string" ? node.boundaryId : "";
  const ownership = resolveOwnership(boundaryById, boundaryId);
  const externalValues = kind === "external-system" || ownership === "external" ? [true] : ownership === "internal" ? [false] : [true, false];
  return { nodeId, kind, boundaryId, externalValues, roleValues: possibleNodeRoles(node) };
}
function worldsOf(end) {
  const worlds = [];
  for (const external of end.externalValues) {
    for (const role of end.roleValues) {
      worlds.push({ external, role, kind: end.kind });
    }
  }
  return worlds;
}
function missingInfoNotes(ends) {
  const notes = [];
  for (const end of ends) {
    if (end.roleValues.length > 1) {
      notes.push(
        `\u8282\u70B9 "${end.nodeId}"\uFF08kind=${end.kind}\uFF09\u7684 role \u5224\u4E0D\u51FA\uFF08\u672A\u58F0\u660E\u6216\u4E0D\u5728\u5408\u6CD5\u679A\u4E3E\u5185\uFF1B\u8BE5 kind \u7684\u5408\u6CD5\u89D2\u8272\uFF1A${end.roleValues.join(" / ")}\uFF09`
      );
    }
    if (end.externalValues.length > 1) {
      notes.push(
        `\u8282\u70B9 "${end.nodeId}" \u7684\u8FB9\u754C\u5F52\u5C5E\u672A\u89E3\u6790\uFF08boundaryId "${end.boundaryId}" \u4E0D\u5728 boundaries[] \u6216\u7236\u7EA7\u94FE\u65AD\u88C2\uFF09\u21D2 \u5224\u4E0D\u51FA\u5185 / \u5916`
      );
    }
  }
  return notes;
}
function buildBoundaryIndex(model) {
  const index = /* @__PURE__ */ new Map();
  const boundaries = model?.boundaries;
  if (!Array.isArray(boundaries)) return index;
  for (const entry of boundaries) {
    if (!isPlainObject3(entry)) continue;
    if (typeof entry.id !== "string") continue;
    const facts = {};
    if (typeof entry.ownership === "string") facts.ownership = entry.ownership;
    if (typeof entry.parentId === "string") facts.parentId = entry.parentId;
    index.set(entry.id, facts);
  }
  return index;
}
function resolveOwnership(boundaryById, boundaryId) {
  let boundary = boundaryById.get(boundaryId);
  const seen = /* @__PURE__ */ new Set();
  while (boundary) {
    if (boundary.ownership === "internal" || boundary.ownership === "external") return boundary.ownership;
    if (boundary.parentId === void 0 || seen.has(boundary.parentId)) return void 0;
    seen.add(boundary.parentId);
    boundary = boundaryById.get(boundary.parentId);
  }
  return void 0;
}
function isStringArray(value) {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}

// src/architecture/project/views.ts
var VIEW_BUILD_CRASH = "VIEW_BUILD_CRASH";
var KEY_SEPARATOR = "\0";
var MAX_AGGREGATED_LABELS = 3;
function buildViews(model, names, traffic) {
  const views = [];
  const interactionIndex = [];
  const issues = [];
  try {
    const rawNodes = model?.nodes;
    const rawInteractions = model?.interactions;
    const rawViews = model?.views;
    if (!Array.isArray(rawNodes) || !Array.isArray(rawInteractions)) {
      if (!Array.isArray(rawNodes)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            "/nodes",
            `\`nodes\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(rawNodes)}\uFF09\u2014\u2014 \u89C6\u56FE\u4E0E\u7D22\u5F15\u65E0\u4ECE\u6784\u5EFA`,
            "\u6309\u5951\u7EA6\u8865\u9F50 nodes\uFF08\u53EF\u4E3A\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
          )
        );
      }
      if (!Array.isArray(rawInteractions)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            "/interactions",
            `\`interactions\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(rawInteractions)}\uFF09\u2014\u2014 \u89C6\u56FE\u4E0E\u7D22\u5F15\u65E0\u4ECE\u6784\u5EFA`,
            "\u6309\u5951\u7EA6\u8865\u9F50 interactions\uFF08\u53EF\u4E3A\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
          )
        );
      }
      return { views, interactionIndex, issues };
    }
    const resolvedNodes = readResolvedNodes(names, issues);
    const classifications = readClassifications(traffic, issues);
    const nameById = /* @__PURE__ */ new Map();
    for (const node of resolvedNodes) {
      if (isPlainObject3(node) && typeof node.id === "string") nameById.set(node.id, node);
    }
    const trafficByInteraction = /* @__PURE__ */ new Map();
    for (const entry of classifications) {
      if (isPlainObject3(entry) && typeof entry.interactionId === "string") {
        trafficByInteraction.set(entry.interactionId, readTrafficClass(entry.trafficClass));
      }
    }
    const nodeById = /* @__PURE__ */ new Map();
    rawNodes.forEach((entry) => {
      if (!isPlainObject3(entry)) return;
      if (typeof entry.id === "string") nodeById.set(entry.id, entry);
    });
    const interactionById = /* @__PURE__ */ new Map();
    rawInteractions.forEach((entry) => {
      if (!isPlainObject3(entry)) return;
      if (typeof entry.id === "string") interactionById.set(entry.id, entry);
    });
    const boundaryById = buildBoundaryNameIndex(model);
    interactionIndex.push(...buildInteractionIndex(rawNodes, rawInteractions, trafficByInteraction));
    if (!Array.isArray(rawViews)) {
      issues.push(
        modelIssue(
          MODEL_SHAPE_INVALID,
          "/views",
          `\`views\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(rawViews)}\uFF09\u2014\u2014 \u53EA\u4EA7\u51FA\u4EA4\u4E92\u7D22\u5F15\uFF0C\u4E0D\u4EA7\u51FA\u89C6\u56FE`,
          "\u6309\u5951\u7EA6\u8865\u9F50 views\uFF08\u53EF\u4E3A\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
        )
      );
      return { views, interactionIndex, issues };
    }
    rawViews.forEach((entry, index) => {
      if (!isPlainObject3(entry)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            `/views/${index}`,
            `\u89C6\u56FE\u6761\u76EE\u4E0D\u662F\u5BF9\u8C61\uFF08\u5B9E\u9645 ${describeType3(entry)}\uFF09\u2014\u2014 \u8DF3\u8FC7\u8BE5\u89C6\u56FE`,
            "\u6309\u5951\u7EA6\u628A views[] \u7684\u6BCF\u4E00\u9879\u5199\u6210\u5BF9\u8C61"
          )
        );
        return;
      }
      if (typeof entry.id !== "string" || entry.id.length === 0) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            `/views/${index}/id`,
            `\u89C6\u56FE\u6761\u76EE\u7F3A\u5C11\u975E\u7A7A\u5B57\u7B26\u4E32 id \u2014\u2014 \u8DF3\u8FC7\u8BE5\u89C6\u56FE\uFF08\u89C6\u56FE id \u662F\u6E32\u67D3\u4E0E\u7D22\u5F15\u7684\u952E\uFF0C\u4E0D\u80FD\u7F3A\uFF09`,
            "\u6309\u5951\u7EA6\u8865\u9F50 view.id"
          )
        );
        return;
      }
      views.push(
        buildView(entry, index, {
          nodeById,
          interactionById,
          nameById,
          boundaryById,
          trafficByInteraction,
          issues
        })
      );
    });
    return { views, interactionIndex, issues };
  } catch (error) {
    return {
      views,
      interactionIndex,
      issues: [
        ...issues,
        gateIssue(
          VIEW_BUILD_CRASH,
          "",
          `\u89C6\u56FE\u6784\u5EFA\u5185\u90E8\u5F02\u5E38\uFF1A${errorText2(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u6A21\u578B\u7ED5\u8FC7`,
          "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
        )
      ]
    };
  }
}
function buildView(view, index, context) {
  const viewId = view.id;
  const kind = view.kind === "overview" ? "overview" : "detail";
  const title = typeof view.title === "string" && view.title.length > 0 ? view.title : viewId;
  const declaredNodeIds = readIdList(view.nodeIds, `/views/${index}/nodeIds`, context.issues, "views[].nodeIds");
  const inView = new Set(declaredNodeIds);
  const groups = buildViewGroups(view.groups, index, inView, context.issues);
  const groupIdByNode = membershipByNode(groups);
  const nodes = [];
  for (const nodeId of declaredNodeIds) {
    const node = context.nodeById.get(nodeId);
    if (!node) continue;
    const display = displayNameFor(nodeId, node, context.nameById);
    const trafficRole = trafficRoleOf(node);
    const projected = {
      id: nodeId,
      name: display.name,
      nameSource: display.nameSource,
      kind: kindOf(node),
      boundaryId: typeof node.boundaryId === "string" ? node.boundaryId : "",
      ...declaredRoleOf(node) === void 0 ? {} : { role: declaredRoleOf(node) },
      ...trafficRole === void 0 ? {} : { trafficRole },
      ...context.boundaryById.has(node.boundaryId) ? { boundaryName: context.boundaryById.get(node.boundaryId) } : {},
      ...groupIdByNode.has(nodeId) ? { groupId: groupIdByNode.get(nodeId) } : {}
    };
    nodes.push(projected);
  }
  const inViewExisting = new Set(nodes.map((node) => node.id));
  const declaredInteractionIds = readIdList(
    view.interactionIds,
    `/views/${index}/interactionIds`,
    context.issues,
    "views[].interactionIds"
  );
  const edgeInteractionIds = declaredInteractionIds.length > 0 ? declaredInteractionIds : deriveInteractionIds(inViewExisting, context.interactionById);
  const { edges, endpointsOutsideView } = buildEdges(edgeInteractionIds, inViewExisting, context);
  return {
    viewId,
    title,
    kind,
    direction: kind === "overview" ? "TB" : "LR",
    nodes,
    groups,
    edges,
    endpointsOutsideView
  };
}
function buildEdges(interactionIds, inView, context) {
  const drafts = [];
  for (const interactionId of interactionIds) {
    const interaction = context.interactionById.get(interactionId);
    if (!interaction) continue;
    const source = interaction.source;
    const targets = interaction.targets;
    if (typeof source !== "string" || !isStringArray2(targets)) continue;
    if (!context.nodeById.has(source)) continue;
    const kind = interaction.kind;
    const label = edgeLabelFor(interaction, interactionId);
    const trafficClass = context.trafficByInteraction.get(interactionId) ?? null;
    for (const target of targets) {
      if (!context.nodeById.has(target)) continue;
      drafts.push({ source, target, kind, label, interactionId, trafficClass });
    }
  }
  const order = [];
  const merged = /* @__PURE__ */ new Map();
  for (const draft of drafts) {
    const key = [draft.source, draft.target, draft.trafficClass ?? "null", draft.kind].join(KEY_SEPARATOR);
    const existing = merged.get(key);
    if (existing) {
      if (!existing.interactionIds.includes(draft.interactionId)) existing.interactionIds.push(draft.interactionId);
      if (!existing.labels.includes(draft.label)) existing.labels.push(draft.label);
      continue;
    }
    order.push(key);
    merged.set(key, {
      source: draft.source,
      target: draft.target,
      kind: draft.kind,
      trafficClass: draft.trafficClass,
      labels: [draft.label],
      interactionIds: [draft.interactionId]
    });
  }
  const endpointsOutsideView = [];
  const edges = order.map((key) => {
    const entry = merged.get(key);
    for (const endpoint of [entry.source, entry.target]) {
      if (!inView.has(endpoint) && !endpointsOutsideView.includes(endpoint)) endpointsOutsideView.push(endpoint);
    }
    const label = entry.labels.length <= MAX_AGGREGATED_LABELS ? entry.labels.join("\uFF1B") : `${entry.labels.slice(0, MAX_AGGREGATED_LABELS).join("\uFF1B")} \u7B49 ${entry.interactionIds.length} \u6761`;
    const edge = {
      interactionId: entry.interactionIds[0],
      interactionIds: [...entry.interactionIds],
      kind: entry.kind,
      source: entry.source,
      target: entry.target,
      sourceName: displayNameFor(entry.source, context.nodeById.get(entry.source), context.nameById).name,
      targetName: displayNameFor(entry.target, context.nodeById.get(entry.target), context.nameById).name,
      label,
      trafficClass: entry.trafficClass,
      trafficLabel: trafficClassLabel(entry.trafficClass),
      aggregated: entry.interactionIds.length > 1,
      ...entry.trafficClass === null ? {} : { lineStyle: arrowForTrafficClass(entry.trafficClass) }
    };
    return edge;
  });
  return { edges, endpointsOutsideView };
}
function deriveInteractionIds(inView, interactionById) {
  const derived = [];
  for (const [interactionId, interaction] of interactionById) {
    const source = interaction.source;
    const targets = interaction.targets;
    if (typeof source !== "string" || !isStringArray2(targets) || targets.length === 0) continue;
    if (!inView.has(source)) continue;
    if (!targets.every((target) => inView.has(target))) continue;
    derived.push(interactionId);
  }
  return derived;
}
function edgeLabelFor(interaction, interactionId) {
  const name = typeof interaction.name === "string" && interaction.name.length > 0 ? interaction.name : interactionId;
  if (interaction.kind === "async-notification") {
    return name.startsWith("\u5F02\u6B65") ? name : `\u5F02\u6B65\uFF1A${name}`;
  }
  return name;
}
function buildViewGroups(rawGroups, viewIndex, inView, issues) {
  if (rawGroups === void 0 || rawGroups === null) return [];
  if (!Array.isArray(rawGroups)) {
    issues.push(
      modelIssue(
        MODEL_SHAPE_INVALID,
        `/views/${viewIndex}/groups`,
        `\`groups\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(rawGroups)}\uFF09\u2014\u2014 \u8BE5\u89C6\u56FE\u4E0D\u4EA7\u51FA\u5206\u7EC4`,
        "\u6309\u5951\u7EA6\u628A groups \u5199\u6210\u6570\u7EC4\uFF08\u6216\u7F3A\u5E2D\uFF09"
      )
    );
    return [];
  }
  const declared = [];
  rawGroups.forEach((entry, position) => {
    if (!isPlainObject3(entry) || typeof entry.id !== "string" || entry.id.length === 0) {
      issues.push(
        modelIssue(
          MODEL_SHAPE_INVALID,
          `/views/${viewIndex}/groups/${position}`,
          `\u5206\u7EC4\u6761\u76EE\u5F62\u6001\u65E0\u6548\uFF08\u9700\u8981\u975E\u7A7A\u5B57\u7B26\u4E32 id\uFF09\u2014\u2014 \u8DF3\u8FC7\u8BE5\u5206\u7EC4`,
          "\u6309\u5951\u7EA6\u8865\u9F50 group.id"
        )
      );
      return;
    }
    const draft = {
      id: entry.id,
      name: typeof entry.name === "string" && entry.name.length > 0 ? entry.name : entry.id,
      nodeIds: readIdList(entry.nodeIds, `/views/${viewIndex}/groups/${position}/nodeIds`, issues, "group.nodeIds").filter(
        (nodeId) => inView.has(nodeId)
      )
    };
    if (typeof entry.parentId === "string" && entry.parentId.length > 0) draft.parentId = entry.parentId;
    declared.push(draft);
  });
  const byId = new Map(declared.map((group) => [group.id, group]));
  const kept = /* @__PURE__ */ new Set();
  for (const group of declared) {
    if (group.nodeIds.length === 0) continue;
    let cursor = group;
    const seen = /* @__PURE__ */ new Set();
    while (cursor) {
      if (kept.has(cursor.id)) break;
      kept.add(cursor.id);
      const parentId = cursor.parentId;
      if (parentId === void 0 || seen.has(parentId)) break;
      seen.add(parentId);
      cursor = byId.get(parentId);
    }
  }
  const depthOf = (groupId) => {
    let depth = 0;
    let cursor = byId.get(groupId);
    const seen = /* @__PURE__ */ new Set([groupId]);
    while (cursor?.parentId && seen.has(cursor.parentId) === false) {
      seen.add(cursor.parentId);
      depth += 1;
      cursor = byId.get(cursor.parentId);
    }
    return depth;
  };
  return declared.filter((group) => kept.has(group.id)).map((group) => {
    const projected = {
      id: group.id,
      name: group.name,
      depth: depthOf(group.id),
      nodeIds: [...group.nodeIds]
    };
    if (group.parentId !== void 0 && kept.has(group.parentId)) projected.parentId = group.parentId;
    return projected;
  });
}
function membershipByNode(groups) {
  const membership = /* @__PURE__ */ new Map();
  const depthOf = new Map(groups.map((group) => [group.id, group.depth]));
  for (const group of groups) {
    for (const nodeId of group.nodeIds) {
      const current = membership.get(nodeId);
      if (current === void 0 || depthOf.get(group.id) > depthOf.get(current)) {
        membership.set(nodeId, group.id);
      }
    }
  }
  return membership;
}
function buildInteractionIndex(rawNodes, rawInteractions, trafficByInteraction) {
  const incoming = /* @__PURE__ */ new Map();
  const outgoing = /* @__PURE__ */ new Map();
  for (const entry of rawNodes) {
    if (!isPlainObject3(entry) || typeof entry.id !== "string") continue;
    incoming.set(entry.id, []);
    outgoing.set(entry.id, []);
  }
  for (const entry of rawInteractions) {
    if (!isPlainObject3(entry) || typeof entry.id !== "string" || typeof entry.source !== "string") continue;
    if (!isStringArray2(entry.targets)) continue;
    const ref = (counterpartIds) => ({
      interactionId: entry.id,
      kind: entry.kind,
      trafficClass: trafficByInteraction.get(entry.id) ?? null,
      name: typeof entry.name === "string" && entry.name.length > 0 ? entry.name : entry.id,
      counterpartIds
    });
    outgoing.get(entry.source)?.push(ref([...entry.targets]));
    for (const target of entry.targets) {
      incoming.get(target)?.push(ref([entry.source]));
    }
  }
  return rawNodes.flatMap(
    (entry) => isPlainObject3(entry) && typeof entry.id === "string" ? [{ nodeId: entry.id, incoming: incoming.get(entry.id) ?? [], outgoing: outgoing.get(entry.id) ?? [] }] : []
  );
}
function readResolvedNodes(input, issues) {
  if (Array.isArray(input)) return input;
  const list = input?.resolvedNodes;
  if (Array.isArray(list)) return list;
  issues.push(
    modelIssue(
      MODEL_SHAPE_INVALID,
      "names",
      `\u540D\u79F0\u89E3\u6790\u8F93\u5165\u5F62\u6001\u65E0\u6548\uFF08\u65E2\u4E0D\u662F ResolvedNode[]\uFF0C\u4E5F\u4E0D\u662F\u542B resolvedNodes \u6570\u7EC4\u7684\u7ED3\u679C\u5BF9\u8C61\uFF09\u2014\u2014 \u89C6\u56FE\u5C06\u6309\u515C\u5E95\u540D\u5448\u73B0`,
      "\u5148\u8DD1 resolveNames(model) \u5E76\u628A\u7ED3\u679C\u4F20\u8FDB\u6765"
    )
  );
  return [];
}
function readClassifications(input, issues) {
  if (Array.isArray(input)) return input;
  const list = input?.classifications;
  if (Array.isArray(list)) return list;
  issues.push(
    modelIssue(
      MODEL_SHAPE_INVALID,
      "traffic",
      `\u6D41\u91CF\u5206\u7C7B\u8F93\u5165\u5F62\u6001\u65E0\u6548\uFF08\u65E2\u4E0D\u662F TrafficClassification[]\uFF0C\u4E5F\u4E0D\u662F\u542B classifications \u6570\u7EC4\u7684\u7ED3\u679C\u5BF9\u8C61\uFF09\u2014\u2014 \u663E\u793A\u8FB9\u5C06\u4E0D\u5E26\u7EBF\u578B`,
      "\u5148\u8DD1 classifyModelTraffic(model) \u5E76\u628A\u7ED3\u679C\u4F20\u8FDB\u6765"
    )
  );
  return [];
}
function readTrafficClass(value) {
  return value === "north-south" || value === "east-west" || value === "external" ? value : null;
}
function readIdList(value, path2, issues, what) {
  if (value === void 0 || value === null) return [];
  if (!Array.isArray(value)) {
    issues.push(
      modelIssue(
        MODEL_SHAPE_INVALID,
        path2,
        `\`${what}\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(value)}\uFF09\u2014\u2014 \u6309\u7A7A\u6E05\u5355\u5904\u7406`,
        "\u6309\u5951\u7EA6\u628A\u8BE5\u952E\u5199\u6210 id \u6570\u7EC4\uFF08\u6216\u7F3A\u5E2D\uFF09"
      )
    );
    return [];
  }
  return value.filter((item) => typeof item === "string");
}
function displayNameFor(nodeId, node, nameById) {
  const resolved = nameById.get(nodeId);
  if (resolved && typeof resolved.name === "string" && resolved.name.length > 0) {
    return { name: resolved.name, nameSource: resolved.nameSource };
  }
  const declared = node && typeof node.name === "string" ? node.name : "";
  if (declared.length > 0) return { name: declared, nameSource: "model" };
  return { name: nodeId, nameSource: "fallback-id" };
}
function declaredRoleOf(node) {
  return typeof node.role === "string" && ALL_NODE_ROLES.includes(node.role) ? node.role : void 0;
}
function kindOf(node) {
  return typeof node.kind === "string" ? node.kind : "";
}
function buildBoundaryNameIndex(model) {
  const index = /* @__PURE__ */ new Map();
  const boundaries = model?.boundaries;
  if (!Array.isArray(boundaries)) return index;
  for (const entry of boundaries) {
    if (!isPlainObject3(entry) || typeof entry.id !== "string") continue;
    if (typeof entry.name === "string" && entry.name.length > 0) index.set(entry.id, entry.name);
  }
  return index;
}
function isStringArray2(value) {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}

// src/architecture/project/projection.ts
var PROJECTION_CRASH = "PROJECTION_CRASH";
var MODEL_COLLECTION_KEYS2 = [
  "boundaries",
  "nodes",
  "interactions",
  "flows",
  "views",
  "openQuestions",
  "coverage"
];
function buildProjection(model, options = {}) {
  const issues = [];
  try {
    if (!isPlainObject3(model)) {
      return {
        issues: [
          modelIssue(
            MODEL_SHAPE_INVALID,
            "",
            `\u6A21\u578B\u6839\u4E0D\u662F\u5BF9\u8C61\uFF08\u5B9E\u9645 ${describeType3(model)}\uFF09\u2014\u2014 \u6295\u5F71\u65E0\u4ECE\u8FDB\u884C`,
            "\u6A21\u578B\u6839\u5FC5\u987B\u662F\u542B schemaVersion/boundaries/nodes/interactions/flows/views/openQuestions/coverage \u7684 JSON \u5BF9\u8C61"
          )
        ]
      };
    }
    for (const key of MODEL_COLLECTION_KEYS2) {
      const value = model[key];
      if (!Array.isArray(value)) {
        issues.push(
          modelIssue(
            MODEL_SHAPE_INVALID,
            joinPointer("", key),
            `\`${key}\` \u4E0D\u662F\u6570\u7EC4\uFF08\u5B9E\u9645 ${describeType3(value)}\uFF09\u2014\u2014 \u6A21\u578B\u4E03\u4E2A\u96C6\u5408\u952E\u90FD\u5FC5\u987B\u662F\u6570\u7EC4`,
            "\u6309\u5951\u7EA6\u8865\u9F50\u8BE5\u96C6\u5408\uFF08\u53EF\u4EE5\u662F\u7A7A\u6570\u7EC4\uFF0C\u4F46\u4E0D\u80FD\u7F3A\u5E2D\u6216\u6362\u7C7B\u578B\uFF09"
          )
        );
      }
    }
    if (issues.length > 0) return { issues };
    const names = resolveNames(model, options.nameResolver);
    const traffic = classifyModelTraffic(model);
    const built = buildViews(model, names, traffic);
    const allIssues = [...names.issues, ...traffic.issues, ...built.issues];
    if (allIssues.length > 0) return { issues: allIssues };
    const trafficClassByInteraction = traffic.classifications.filter((entry) => entry.trafficClass !== null).map((entry) => ({
      interactionId: entry.interactionId,
      trafficClass: entry.trafficClass,
      reason: entry.reason
    }));
    return {
      projection: {
        resolvedNodes: names.resolvedNodes,
        trafficClassByInteraction,
        views: built.views,
        interactionIndex: built.interactionIndex
      },
      issues
    };
  } catch (error) {
    return {
      issues: [
        ...issues,
        gateIssue(
          PROJECTION_CRASH,
          "",
          `\u6295\u5F71\u5185\u90E8\u5F02\u5E38\uFF1A${errorText2(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u6A21\u578B\u7ED5\u8FC7`,
          "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
        )
      ]
    };
  }
}

// src/architecture/render/render-id.ts
var SAFE_RENDER_ID = /^[A-Za-z][A-Za-z0-9_]*$/;
var NODE_PREFIX = "n";
var GROUP_PREFIX = "g";
function fnv1a32(input) {
  let hash = 2166136261;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 16777619) >>> 0;
  }
  return hash >>> 0;
}
function compareCodeUnits(left, right) {
  if (left < right) return -1;
  if (left > right) return 1;
  return 0;
}
function assignStableIds(prefix, logicalIds) {
  const unique = [...new Set(logicalIds)].sort(compareCodeUnits);
  const assigned = /* @__PURE__ */ new Map();
  const buckets = /* @__PURE__ */ new Map();
  for (const logicalId of unique) {
    const base = `${prefix}${fnv1a32(logicalId).toString(36)}`;
    const bucket = buckets.get(base);
    if (bucket === void 0) {
      buckets.set(base, [logicalId]);
    } else {
      bucket.push(logicalId);
    }
  }
  for (const [base, bucket] of buckets) {
    bucket.forEach((logicalId, index) => {
      const renderId = bucket.length === 1 ? base : `${base}_${index}`;
      assertSafeRenderId(renderId);
      assigned.set(logicalId, renderId);
    });
  }
  return assigned;
}
function assignNodeRenderIds(ids) {
  return assignStableIds(NODE_PREFIX, ids);
}
function assignGroupRenderIds(ids) {
  return assignStableIds(GROUP_PREFIX, ids);
}
function escapeMermaidLabel(raw) {
  return raw.replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("|", "&#124;").replaceAll("\r\n", "<br/>").replaceAll("\n", "<br/>").replaceAll("\r", "<br/>");
}
function assertSafeRenderId(id) {
  if (!SAFE_RENDER_ID.test(id)) {
    throw new Error(`\u6D3E\u751F renderId \u4E0D\u662F\u5B89\u5168\u7684 Mermaid \u6807\u8BC6\u7B26\uFF1A"${id}"\uFF08\u671F\u671B ${SAFE_RENDER_ID.source}\uFF09`);
  }
}

// src/architecture/render/renderer.ts
var MERMAID_NEUTRAL_ARROW = "---";
var MERMAID_ALLOWED_ARROWS = [
  arrowForTrafficClass("north-south"),
  arrowForTrafficClass("east-west"),
  arrowForTrafficClass("external"),
  MERMAID_NEUTRAL_ARROW
];
var FORBIDDEN_HINTS = [
  "click",
  "linkStyle",
  "style",
  "%%{",
  "%%",
  "config",
  "href",
  "javascript:",
  "callback"
];
var CLASS_STYLES = {
  roleClient: "fill:#eef2ff,stroke:#4f5bd5,color:#1f2452",
  roleAccess: "fill:#fff1e6,stroke:#c9740f,color:#5a3410",
  roleBusiness: "fill:#e8f7ee,stroke:#2f8f57,color:#123f26",
  roleData: "fill:#f3ecff,stroke:#7a4fd0,color:#33205c",
  roleIntegration: "fill:#fdeaea,stroke:#c04c4c,color:#5a1f1f",
  neutral: "fill:#f3f4f6,stroke:#9aa0a6,color:#3c4043"
};
function renderViewToMermaid(view) {
  const direction = view.direction === "LR" ? "LR" : "TB";
  const nodes = Array.isArray(view.nodes) ? view.nodes : [];
  const outsideIds = Array.isArray(view.endpointsOutsideView) ? view.endpointsOutsideView : [];
  const nodeRenderIds = assignNodeRenderIds([...nodes.map((node) => node.id), ...outsideIds]);
  const groups = Array.isArray(view.groups) ? view.groups : [];
  const groupRenderIds = assignGroupRenderIds(groups.map((group) => group.id));
  const lines = [`flowchart ${direction}`];
  const usedClasses = /* @__PURE__ */ new Set();
  const emitNode = (node, indent) => {
    const renderId = nodeRenderIds.get(node.id);
    if (renderId === void 0) {
      throw new Error(`\u89C6\u56FE "${view.viewId}" \u7684\u8282\u70B9 "${node.id}" \u6CA1\u6709\u6D3E\u751F renderId`);
    }
    const classKey = classKeyFor(node);
    usedClasses.add(classKey);
    return `${indent}${renderId}["${escapeMermaidLabel(node.name)}"]:::${classKey}`;
  };
  const groupIds = new Set(groups.map((group) => group.id));
  const childrenOf = /* @__PURE__ */ new Map();
  for (const group of groups) {
    const parentKey = group.parentId !== void 0 && groupIds.has(group.parentId) ? group.parentId : "";
    const bucket = childrenOf.get(parentKey);
    if (bucket === void 0) childrenOf.set(parentKey, [group]);
    else bucket.push(group);
  }
  const emittedGroups = /* @__PURE__ */ new Set();
  const emitGroup = (group, indent) => {
    if (emittedGroups.has(group.id)) return;
    emittedGroups.add(group.id);
    const renderId = groupRenderIds.get(group.id);
    if (renderId === void 0) {
      throw new Error(`\u89C6\u56FE "${view.viewId}" \u7684\u5206\u7EC4 "${group.id}" \u6CA1\u6709\u6D3E\u751F renderId`);
    }
    lines.push(`${indent}subgraph ${renderId}["${escapeMermaidLabel(group.name)}"]`);
    for (const node of nodes) {
      if (node.groupId === group.id) lines.push(emitNode(node, `${indent}  `));
    }
    for (const child of childrenOf.get(group.id) ?? []) emitGroup(child, `${indent}  `);
    lines.push(`${indent}end`);
  };
  for (const group of childrenOf.get("") ?? []) emitGroup(group, "  ");
  for (const node of nodes) {
    if (node.groupId === void 0 || !groupIds.has(node.groupId)) lines.push(emitNode(node, "  "));
  }
  for (const outsideId of outsideIds) {
    const renderId = nodeRenderIds.get(outsideId);
    if (renderId === void 0) continue;
    usedClasses.add("neutral");
    lines.push(`  ${renderId}["${escapeMermaidLabel(outsideId)}"]:::neutral`);
  }
  for (const edge of Array.isArray(view.edges) ? view.edges : []) {
    const sourceRenderId = nodeRenderIds.get(edge.source);
    const targetRenderId = nodeRenderIds.get(edge.target);
    if (sourceRenderId === void 0 || targetRenderId === void 0) continue;
    const arrow = arrowForEdge(edge);
    const label = typeof edge.label === "string" ? edge.label : "";
    const labelPart = label.length > 0 ? `|${escapeMermaidLabel(label)}|` : "";
    lines.push(`  ${sourceRenderId} ${arrow}${labelPart} ${targetRenderId}`);
  }
  for (const classKey of [...usedClasses].sort()) {
    lines.push(`  classDef ${classKey} ${CLASS_STYLES[classKey] ?? CLASS_STYLES.neutral}`);
  }
  return lines.join("\n");
}
function arrowForEdge(edge) {
  if (MERMAID_ALLOWED_ARROWS.includes(edge.lineStyle)) return edge.lineStyle;
  const trafficClass = edge.trafficClass;
  if (trafficClass === "north-south" || trafficClass === "east-west" || trafficClass === "external") {
    return arrowForTrafficClass(trafficClass);
  }
  return MERMAID_NEUTRAL_ARROW;
}
function classKeyFor(node) {
  const role = node.trafficRole ?? node.role;
  if (typeof role === "string") {
    const key = `role${role.charAt(0).toUpperCase()}${role.slice(1)}`;
    if (CLASS_STYLES[key] !== void 0) return key;
  }
  return "neutral";
}
var HEADER_LINE = /^flowchart (?:TB|LR)$/;
var END_LINE = /^end$/;
var SUBGRAPH_LINE = /^subgraph ([A-Za-z][A-Za-z0-9_]*)\["(.*)"\]$/;
var NODE_LINE = /^([A-Za-z][A-Za-z0-9_]*)\["(.*)"\](:::[A-Za-z][A-Za-z0-9_]*)?$/;
var EDGE_LINE = /^([A-Za-z][A-Za-z0-9_]*) (?:==>|-\.->|-->|---)(?:\|(.*)\|)? ([A-Za-z][A-Za-z0-9_]*)$/;
var CLASSDEF_LINE = /^classDef ([A-Za-z][A-Za-z0-9_]*) (.+)$/;
function findMermaidWhitelistViolations(mermaid) {
  const violations = [];
  const lines = typeof mermaid === "string" ? mermaid.split("\n") : [];
  let headerSeen = false;
  let depth = 0;
  lines.forEach((rawLine, index) => {
    const line = rawLine.trim();
    if (line.length === 0) return;
    const where = `\u7B2C ${index + 1} \u884C`;
    if (HEADER_LINE.test(line)) {
      if (headerSeen) violations.push(`${where}\uFF1A\u91CD\u590D\u7684 flowchart \u5934\uFF08${line}\uFF09`);
      headerSeen = true;
      return;
    }
    if (!headerSeen) {
      violations.push(`${where}\uFF1Aflowchart \u5934\u4E4B\u524D\u51FA\u73B0\u8BED\u53E5\uFF08${line}\uFF09`);
      return;
    }
    if (END_LINE.test(line)) {
      depth = Math.max(0, depth - 1);
      return;
    }
    const subgraph = SUBGRAPH_LINE.exec(line);
    if (subgraph) {
      if (!isSafeLabelInner(subgraph[2])) violations.push(`${where}\uFF1Asubgraph \u6807\u9898\u542B\u672A\u8F6C\u4E49\u5B57\u7B26\uFF08${subgraph[2]}\uFF09`);
      depth += 1;
      return;
    }
    const node = NODE_LINE.exec(line);
    if (node) {
      if (!isSafeLabelInner(node[2])) violations.push(`${where}\uFF1A\u8282\u70B9\u6807\u7B7E\u542B\u672A\u8F6C\u4E49\u5B57\u7B26\uFF08${node[2]}\uFF09`);
      return;
    }
    const edge = EDGE_LINE.exec(line);
    if (edge) {
      if (edge[2] !== void 0 && !isSafeLabelInner(edge[2])) {
        violations.push(`${where}\uFF1A\u8FB9\u6807\u7B7E\u542B\u672A\u8F6C\u4E49\u5B57\u7B26\uFF08${edge[2]}\uFF09`);
      }
      return;
    }
    const classDef = CLASSDEF_LINE.exec(line);
    if (classDef) {
      if (/[<>"|;]/.test(classDef[2]) || /url\(/i.test(classDef[2])) {
        violations.push(`${where}\uFF1AclassDef \u6837\u5F0F\u542B\u8D8A\u6743\u5B57\u7B26\uFF08${classDef[2]}\uFF09`);
      }
      return;
    }
    violations.push(`${where}\uFF1A\u4E0D\u5728\u767D\u540D\u5355\u8BED\u6CD5\u5185\uFF08${line}\uFF09${forbiddenHint(line)}`);
  });
  if (!headerSeen) violations.push("\u7F3A\u5C11 flowchart \u5934");
  if (depth !== 0) violations.push(`subgraph \u4E0E end \u4E0D\u914D\u5BF9\uFF08\u672A\u95ED\u5408\u5C42\u6570 ${depth}\uFF09`);
  return violations;
}
function isSafeLabelInner(inner) {
  return !/["<>|]/.test(inner.split("<br/>").join(""));
}
function forbiddenHint(line) {
  const hit = FORBIDDEN_HINTS.find((token) => line.includes(token));
  return hit ? ` \u2014\u2014 \u7591\u4F3C\u8D8A\u6743\u8BED\u6CD5\u300C${hit}\u300D` : "";
}

// src/architecture/render/markdown.ts
function asArray(value) {
  return Array.isArray(value) ? value : [];
}
function renderViewSection(view) {
  const lines = [`## ${typeof view.title === "string" && view.title.length > 0 ? view.title : view.viewId}`, ""];
  const mermaid = typeof view.mermaid === "string" ? view.mermaid : "";
  lines.push("```mermaid");
  lines.push(mermaid);
  lines.push("```", "");
  return lines;
}
function renderNodeTable(model, nameById) {
  const boundaryById = new Map(model.boundaries.map((boundary) => [boundary.id, boundary.name]));
  const lines = [
    "## \u8282\u70B9\u4E0E\u804C\u8D23",
    "",
    "| ID | \u8282\u70B9 | \u7C7B\u578B | \u89D2\u8272 | \u804C\u8D23 | \u5F52\u5C5E\u8FB9\u754C | \u4F9D\u636E |",
    "|---|---|---|---|---|---|---|"
  ];
  for (const node of model.nodes) {
    const boundary = boundaryById.get(node.boundaryId) ?? node.boundaryId;
    lines.push(
      `| \`${node.id}\` | ${nameById.get(node.id) ?? node.name} | ${node.kind} | ${node.role} | ${node.responsibility} | ${boundary} | ${node.basis} |`
    );
  }
  lines.push("");
  return lines;
}
function renderInteractionTable(pkg, nameById) {
  const trafficByInteraction = /* @__PURE__ */ new Map();
  for (const entry of asArray(
    pkg.projection?.trafficClassByInteraction
  )) {
    if (typeof entry?.interactionId === "string" && typeof entry?.trafficClass === "string") {
      trafficByInteraction.set(entry.interactionId, entry.trafficClass);
    }
  }
  const lines = [
    "## \u4EA4\u4E92\u6E05\u5355",
    "",
    "\u6BCF\u4E00\u884C\u4EE5\u4EA4\u4E92 ID \u4E3A\u51C6\uFF1A\u540E\u7EED\u6F84\u6E05\u4E24\u7AEF\u67E5\u540C\u4E00\u6761\u4EA4\u4E92\u65F6\uFF0C\u5E94\u5F97\u5230\u540C\u4E00 interactionId \u4E0E\u540C\u4E00\u4E8B\u5B9E\u3002",
    "",
    "| \u4EA4\u4E92 ID | \u540D\u79F0 | \u79CD\u7C7B | \u53D1\u8D77\u65B9 | \u63A5\u6536\u65B9 | \u6D41\u91CF\u7C7B\u522B |",
    "|---|---|---|---|---|---|"
  ];
  for (const interaction of pkg.model.interactions) {
    const targets = interaction.targets.map((id) => nameById.get(id) ?? id).join("\u3001");
    const source = nameById.get(interaction.source) ?? interaction.source;
    const traffic = trafficClassLabel(trafficByInteraction.get(interaction.id) ?? null);
    lines.push(
      `| ${interaction.id} | ${interaction.name} | ${interaction.kind} | ${source} | ${targets} | ${traffic} |`
    );
  }
  lines.push("");
  return lines;
}
function renderCoverageTable(coverage) {
  if (coverage.length === 0) return [];
  const lines = [
    "## \u8F93\u5165\u8986\u76D6\u58F0\u660E",
    "",
    "\u8FD9\u662F\u5BF9\u672C\u6B21\u8F93\u5165\u4E0E\u626B\u63CF\u8303\u56F4\u7684\u9010\u9879\u4EA4\u4EE3\uFF0C**\u4E0D\u662F**\u300C\u9700\u6C42\u5B8C\u6574\u6027\u5DF2\u673A\u68B0\u8BC1\u660E\u300D\u3002",
    "",
    "| \u6765\u6E90 | \u4E3B\u9898 | \u5904\u7F6E | \u627F\u8F7D\uFF08\u8282\u70B9 / \u4EA4\u4E92 / \u672A\u51B3\u9879\uFF09 | \u7406\u7531 |",
    "|---|---|---|---|---|"
  ];
  for (const entry of coverage) {
    const carriers = [
      ...[...entry.nodeIds ?? []].map((id) => `\u8282\u70B9 ${id}`),
      ...[...entry.interactionIds ?? []].map((id) => `\u4EA4\u4E92 ${id}`),
      ...[...entry.questionIds ?? []].map((id) => `\u672A\u51B3 ${id}`)
    ].join("\uFF1B");
    lines.push(
      `| ${entry.sourceRef} | ${entry.subject} | ${entry.disposition} | ${carriers.length > 0 ? carriers : "\uFF08\u65E0\uFF09"} | ${entry.reason ?? ""} |`
    );
  }
  lines.push("");
  return lines;
}
function renderArchitectureOverview(pkg) {
  const nameById = /* @__PURE__ */ new Map();
  for (const node of asArray(pkg.projection?.resolvedNodes)) {
    if (typeof node?.id === "string" && typeof node?.name === "string") nameById.set(node.id, node.name);
  }
  const lines = ["# \u6574\u4F53\u67B6\u6784\u6982\u89C8", ""];
  lines.push(
    `\u672C\u6587\u4EF6\u7531\u7A0B\u5E8F\u4ECE JSON \u5951\u7EA6\u751F\u6210\uFF08\u6E32\u67D3\u7B56\u7565 ${pkg.metadata.rendererVersion}\uFF0C\u6A21\u578B\u6458\u8981 \`${pkg.metadata.modelDigest}\`\uFF09\uFF0C\u4E0D\u662F\u624B\u5DE5\u7EF4\u62A4\u7684\u6587\u6863\u3002\u56FE\u4E0E\u8868\u540C\u6E90\uFF1A\u6539\u52A8\u53EA\u80FD\u901A\u8FC7\u4FEE\u6539\u6A21\u578B\u540E\u91CD\u65B0\u751F\u6210\u3002`,
    ""
  );
  for (const legend of TRAFFIC_LEGEND_LINES) lines.push(legend);
  lines.push(
    `- \`${MERMAID_NEUTRAL_ARROW}\` \u672A\u5224\u5B9A\uFF1A\u6295\u5F71\u5C42\u65E0\u6CD5\u5224\u5B9A\u6D41\u91CF\u7C7B\u522B\uFF08\`TRAFFIC_CLASS_UNRESOLVED\`\uFF09\u65F6\u7684\u4E2D\u6027\u5F00\u8DEF\uFF0C\u4E0D\u4E0E\u4EFB\u4F55\u6D41\u91CF\u7C7B\u522B\u5BF9\u5E94`,
    ""
  );
  for (const view of asArray(pkg.projection?.views)) lines.push(...renderViewSection(view));
  lines.push(...renderNodeTable(pkg.model, nameById));
  lines.push(...renderInteractionTable(pkg, nameById));
  lines.push(...renderCoverageTable(pkg.model.coverage));
  return lines.join("\n");
}

// src/architecture/schema/architecture.model.schema.json
var architecture_model_schema_default = {
  $schema: "https://json-schema.org/draft/2020-12/schema",
  $id: "https://hicode.local/architecture/architecture.model.schema.json",
  title: "Architecture logical model (agent-authored candidate)",
  description: "agent \u53EF\u5199\u7684\u903B\u8F91\u6A21\u578B\uFF1A\u53EA\u542B\u8BBE\u8BA1\u5224\u65AD\u3001\u8BC1\u636E\u5F15\u7528\u3001\u5C55\u793A\u5206\u7EC4\u610F\u56FE\u4E0E\u672A\u51B3\u9879\u3002\u6D3E\u751F\u4E8B\u5B9E\u4E00\u5F8B\u7981\u5165\u672C\u6A21\u578B\u2014\u2014\u5DF2\u89E3\u6790\u540D\u79F0\uFF08resolved*\uFF09\u3001\u6D41\u91CF\u5206\u7C7B\uFF08traffic*\uFF09\u3001\u6E32\u67D3 ID\uFF08renderId\uFF09\u3001\u4EA4\u4E92\u7D22\u5F15\u7531\u6295\u5F71\u5728\u53D1\u5E03\u5305\u91CC\u751F\u6210\uFF1B\u672C schema \u5168\u5C42 additionalProperties:false\uFF0C\u51E1\u672A\u58F0\u660E\u7684\u952E\uFF08\u542B traffic*/resolved*/renderId\uFF09\u4E00\u5F8B\u6821\u9A8C\u7EA2\u3002\u6743\u5A01\u771F\u6E90\u5373\u672C\u6587\u4EF6\uFF1Aid \u5B57\u7B26\u96C6\u7684\u552F\u4E00\u771F\u6E90\u662F $defs/identifier.pattern\u3002",
  type: "object",
  additionalProperties: false,
  required: ["schemaVersion", "boundaries", "nodes", "interactions", "flows", "views", "openQuestions", "coverage"],
  properties: {
    schemaVersion: { const: 1 },
    boundaries: { type: "array", items: { $ref: "#/$defs/boundary" } },
    nodes: { type: "array", items: { $ref: "#/$defs/node" } },
    interactions: { type: "array", items: { $ref: "#/$defs/interaction" } },
    flows: { type: "array", items: { $ref: "#/$defs/flow" } },
    views: { type: "array", items: { $ref: "#/$defs/view" } },
    openQuestions: { type: "array", items: { $ref: "#/$defs/openQuestion" } },
    coverage: { type: "array", items: { $ref: "#/$defs/coverageEntry" } },
    operationalRequirements: {
      type: "array",
      maxItems: 20,
      items: { $ref: "#/$defs/operationalRequirement" },
      description: "**\u53EF\u9009**\u7684\u96C6\u4E2D\u8FD0\u7EF4\u58F0\u660E\uFF08config / transaction / resilience\uFF09\u3002\u53EA\u7531\u9700\u6C42\u539F\u6587**\u660E\u786E\u63D0\u5230**\u65F6\u8457\u5199\uFF1B\u7F3A\u5E2D\u5408\u6CD5 \u2014\u2014 \u7F3A\u5E2D\u8868\u793A\u300C\u9700\u6C42\u6CA1\u63D0\u300D\uFF0C\u4E0D\u662F\u300C\u4E0D\u9700\u8981\u300D\uFF0C\u4E0B\u6E38 lens \u4E09\u9879\u7EE7\u7EED null\uFF08\u4E0D\u731C\uFF09\u3002\u672C\u5757\u53EA\u662F\u58F0\u660E\u900F\u4F20\uFF1A\u4E0D\u53C2\u4E0E\u6A21\u5757/\u8FB9\u63A8\u5BFC\uFF0C\u4E5F\u4E0D\u53CD\u5411\u751F\u6210\u8282\u70B9\u3002\u540C\u4E00 capability \u53EF\u6709\u591A\u4E2A scope \u4E0D\u540C\u7684\u884C\u3002"
    }
  },
  $defs: {
    identifier: {
      type: "string",
      minLength: 1,
      pattern: "^[A-Za-z0-9][A-Za-z0-9._:-]*$",
      description: "\u7A33\u5B9A ID \u7684\u5B8C\u6574 canonical \u5B57\u7B26\u96C6\uFF1AASCII \u5B57\u6BCD/\u6570\u5B57\u5F00\u5934\uFF0C\u540E\u7EED\u4E3A\u5B57\u6BCD/\u6570\u5B57\u4E0E - _ . :\u3002\u6A21\u5757 id \u4E0E\u57DF id \u542B\u8FDE\u5B57\u7B26\uFF0C\u4EFB\u4F55 `\\w` / `[A-Za-z0-9_]` \u53E3\u5F84\u7684\u622A\u65AD\u90FD\u662F\u4E8B\u6545\u2014\u2014\u4E00\u5207\u6355\u83B7\u6B63\u5219/\u6821\u9A8C\u5FC5\u987B\u6309\u672C pattern \u5199\u3002\u552F\u4E00\u771F\u6E90\u5373\u6B64\u5904\u3002"
    },
    displayName: { type: "string", minLength: 1 },
    basis: {
      type: "string",
      enum: ["requirement", "decision", "observation", "inference"],
      description: "\u4F9D\u636E\u7C7B\u578B\u3002\u6709\u53EF\u5B9A\u4F4D\u5F15\u7528\u53EA\u8BC1\u660E\u51FA\u5904\u5B58\u5728\uFF0C\u4E0D\u8BC1\u660E\u63A8\u65AD\u6210\u7ACB\uFF1Bbasis=inference \u987B\u7ED9 reason\u3002"
    },
    locator: {
      type: "object",
      additionalProperties: false,
      required: ["kind", "value"],
      properties: {
        kind: { type: "string", enum: ["json-pointer", "text", "code"] },
        value: { type: "string", minLength: 1 }
      }
    },
    evidenceRef: {
      type: "object",
      additionalProperties: false,
      required: ["sourceId", "locator"],
      properties: {
        sourceId: { type: "string", minLength: 1 },
        locator: { $ref: "#/$defs/locator" },
        note: { type: "string", minLength: 1 }
      }
    },
    contractRef: {
      type: "object",
      additionalProperties: false,
      required: ["providerModuleId", "docPath", "anchor"],
      properties: {
        providerModuleId: { $ref: "#/$defs/identifier" },
        docPath: { type: "string", minLength: 1 },
        anchor: { type: "string", minLength: 1 }
      },
      description: "D16\uFF1A\u670D\u52A1\u95F4\u5951\u7EA6\u6307\u9488\uFF0C\u6307\u5411\u63D0\u4F9B\u65B9\u5951\u7EA6\u6587\u6863\u7684\u63A5\u53E3\u6BB5 / \u4E8B\u4EF6 schema \u6BB5\u3002\u6309\u63D0\u4F9B\u65B9\u8EAB\u4EFD\u5206\u4E24\u65CF\u5F62\u6001\uFF08**\u5F62\u6001\u4E0E\u8EAB\u4EFD\u5FC5\u987B\u76F8\u7B26**\uFF0C\u8BED\u4E49\u6821\u9A8C\u5224\uFF09\uFF1Abusiness \u63D0\u4F9B\u65B9 \u21D2 `backend/modules/<providerModuleId>/tech-design.md`\uFF08\u6CE2 5 \u6A21\u5757\u6587\u6863\u4EA7\u51FA\uFF09\uFF1Bexternal \u63D0\u4F9B\u65B9 \u21D2 `backend/mock/<providerModuleId>.md` \u6216 `backend/third-party/<providerModuleId>.md`\uFF08\u96C6\u6210\u4E13\u5BB6\u4EA7\u51FA\uFF0C**\u4E0D\u4EA7\u5916\u90E8\u7CFB\u7EDF\u7684\u6A21\u5757\u6587\u6863**\uFF09\u3002`docPath` \u76F8\u5BF9 `plans/`\u3001\u7981\u5E26 `plans/` \u524D\u7F00\u3002\u4E09\u952E\u5FC5\u586B\u3001\u4E0D\u5F97\u589E\u952E\u3002sync/async \u8DE8\u6A21\u5757\u8FB9\u5FC5\u586B\u7531\u8BED\u4E49\u6821\u9A8C\u5224\uFF08\u672C schema \u53EA\u7EA6\u675F\u5F62\u6001\uFF09\u3002"
    },
    boundary: {
      type: "object",
      additionalProperties: false,
      required: ["id", "name", "kind", "ownership", "evidenceRefs"],
      properties: {
        id: { $ref: "#/$defs/identifier" },
        name: { $ref: "#/$defs/displayName" },
        kind: { type: "string", enum: ["system", "group"] },
        ownership: { type: "string", enum: ["internal", "external"] },
        parentId: { $ref: "#/$defs/identifier" },
        evidenceRefs: { type: "array", minItems: 1, items: { $ref: "#/$defs/evidenceRef" } }
      }
    },
    node: {
      type: "object",
      additionalProperties: false,
      required: ["id", "kind", "role", "boundaryId", "responsibility", "name", "evidenceRefs", "basis"],
      properties: {
        id: { $ref: "#/$defs/identifier" },
        kind: {
          type: "string",
          enum: [
            "actor",
            "frontend",
            "service",
            "application-component",
            "external-system",
            "datastore",
            "infrastructure"
          ]
        },
        role: {
          type: "string",
          enum: ["client", "access", "business", "data", "integration"],
          description: "\u804C\u8D23\u89D2\u8272\uFF1A\u5FC5\u586B\uFF08plan \xA72.1 \u7684 nodes \u5B57\u6BB5\u8868\u9010\u5B57\u4E3A {id, kind, role, boundaryId, ...}\uFF0C\u53EA\u6709 ownedDomainIds? \u5E26 ?\uFF09\u3002role \u7F3A\u5E2D \u21D2 \u6295\u5F71\u5224\u4E0D\u51FA\u804C\u8D23\u77E9\u9635\uFF0C\u6D41\u91CF\u7C7B\u522B\u53EA\u80FD\u843D null\uFF08TRAFFIC_CLASS_UNRESOLVED\uFF09\u21D2 \u56FE\u9000\u5316\u3002\u6309\u804C\u8D23\u5224\u5B9A\uFF0C\u7981\u6309\u4EA7\u54C1\u540D\uFF08BFF / Gateway\uFF09\u63A8\u5BFC\uFF08D14\uFF09\u3002"
        },
        boundaryId: { $ref: "#/$defs/identifier" },
        responsibility: { type: "string", minLength: 1 },
        ownedDomainIds: {
          type: "array",
          uniqueItems: true,
          items: { $ref: "#/$defs/identifier" },
          description: "D11\uFF1Abusiness \u8282\u70B9\u58F0\u660E\u6240\u62E5\u6709\u7684\u57DF\uFF08\u57DF\u2192\u6A21\u5757\u6620\u5C04\u5373\u5B9E\u4F53\u7ED1\u5B9A\u771F\u503C\uFF09\u3002\u53EF\u9009\uFF1B\u57DF\u5212\u5206\u6070\u4E00\u6B21\u7531\u8BED\u4E49\u6821\u9A8C\u5224\u3002"
        },
        name: { $ref: "#/$defs/displayName" },
        evidenceRefs: { type: "array", minItems: 1, items: { $ref: "#/$defs/evidenceRef" } },
        basis: { $ref: "#/$defs/basis" },
        reason: { type: "string", minLength: 1 }
      },
      allOf: [
        {
          if: { properties: { basis: { const: "inference" } }, required: ["basis"] },
          then: { required: ["reason"] }
        }
      ]
    },
    interaction: {
      type: "object",
      additionalProperties: false,
      required: ["id", "kind", "source", "targets", "name", "purpose", "evidenceRefs", "basis"],
      properties: {
        id: { $ref: "#/$defs/identifier" },
        kind: {
          type: "string",
          enum: ["sync-request", "async-notification", "data-access", "dependency"]
        },
        source: { $ref: "#/$defs/identifier" },
        targets: {
          type: "array",
          minItems: 1,
          uniqueItems: true,
          items: { $ref: "#/$defs/identifier" }
        },
        name: { $ref: "#/$defs/displayName" },
        purpose: { type: "string", minLength: 1 },
        contractRef: { $ref: "#/$defs/contractRef" },
        access: {
          type: "string",
          enum: ["read", "write", "read-write"],
          description: "data-access \u5FC5\u586B\uFF1B\u5176\u4F59 kind \u4E0D\u6536\u3002"
        },
        evidenceRefs: { type: "array", minItems: 1, items: { $ref: "#/$defs/evidenceRef" } },
        basis: { $ref: "#/$defs/basis" },
        reason: { type: "string", minLength: 1 }
      },
      allOf: [
        {
          if: { properties: { kind: { const: "sync-request" } }, required: ["kind"] },
          then: { properties: { targets: { maxItems: 1 } } }
        },
        {
          if: { properties: { kind: { const: "data-access" } }, required: ["kind"] },
          then: {
            required: ["access"],
            properties: { targets: { maxItems: 1 } }
          }
        },
        {
          if: { properties: { basis: { const: "inference" } }, required: ["basis"] },
          then: { required: ["reason"] }
        }
      ]
    },
    flow: {
      type: "object",
      additionalProperties: false,
      required: ["id", "name", "purpose", "interactionIds", "evidenceRefs"],
      properties: {
        id: { $ref: "#/$defs/identifier" },
        name: { $ref: "#/$defs/displayName" },
        purpose: { type: "string", minLength: 1 },
        interactionIds: {
          type: "array",
          minItems: 1,
          uniqueItems: true,
          items: { $ref: "#/$defs/identifier" }
        },
        links: {
          type: "array",
          description: "\u4E1A\u52A1\u94FE\u8DEF\u5185\u7684\u56E0\u679C / \u8F6C\u4EA4\u5173\u7CFB\uFF1B\u4E0D\u8868\u793A\u5B57\u8282\u7EA7\u6D88\u606F\u7B49\u540C\u3002\u53EF\u9009\u3002",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["fromInteractionId", "toInteractionId", "reason"],
            properties: {
              fromInteractionId: { $ref: "#/$defs/identifier" },
              toInteractionId: { $ref: "#/$defs/identifier" },
              reason: { type: "string", minLength: 1 }
            }
          }
        },
        evidenceRefs: { type: "array", minItems: 1, items: { $ref: "#/$defs/evidenceRef" } }
      }
    },
    view: {
      type: "object",
      additionalProperties: false,
      required: ["id", "title", "kind", "nodeIds", "interactionIds"],
      properties: {
        id: { $ref: "#/$defs/identifier" },
        title: { $ref: "#/$defs/displayName" },
        kind: { type: "string", enum: ["overview", "detail"] },
        nodeIds: {
          type: "array",
          minItems: 1,
          uniqueItems: true,
          items: { $ref: "#/$defs/identifier" }
        },
        interactionIds: { type: "array", uniqueItems: true, items: { $ref: "#/$defs/identifier" } },
        groups: {
          type: "array",
          description: "\u89C6\u89C9\u5206\u7EC4\uFF08\u6E32\u67D3\u5668\u636E\u6B64\u751F\u6210 mermaid subgraph\uFF09\u3002boundaries \u53EA\u8868\u8FBE\u5F52\u5C5E/\u5185\u5916\u90E8\u8BED\u4E49\u3001\u4E0D\u4F1A\u81EA\u52A8\u753B\u6846\u2014\u2014\u753B\u6846\u53EA\u8BA4\u672C\u5B57\u6BB5\u3002nodeIds \u5FC5\u987B\u662F\u672C\u89C6\u56FE nodeIds \u7684\u5B50\u96C6\uFF1B\u5D4C\u5957\u53EA\u9760 parentId\uFF08\u7236\u7EC4\u53EF\u65E0\u76F4\u5C5E\u8282\u70B9\uFF0C\u53EA\u8981\u540E\u4EE3\u6709\u6210\u5458\u5373\u4FDD\u7559\uFF09\uFF1B\u540C\u4E00\u8282\u70B9\u53EA\u5199\u4E00\u6B21\u3002\u5206\u7EC4\u53EA\u5F71\u54CD\u5C55\u793A\uFF0C\u4E0D\u6539\u53D8\u4EA4\u4E92\u3001\u6D41\u91CF\u5206\u7C7B\u6216\u6821\u9A8C\u7ED3\u8BBA\u3002",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["id", "name", "nodeIds"],
            properties: {
              id: { $ref: "#/$defs/identifier" },
              name: { $ref: "#/$defs/displayName" },
              parentId: { $ref: "#/$defs/identifier" },
              nodeIds: { type: "array", uniqueItems: true, items: { $ref: "#/$defs/identifier" } }
            }
          }
        }
      }
    },
    openQuestion: {
      type: "object",
      additionalProperties: false,
      required: ["id", "question", "relatedIds", "stage", "impact"],
      properties: {
        id: { $ref: "#/$defs/identifier" },
        question: { type: "string", minLength: 1 },
        relatedIds: { type: "array", items: { $ref: "#/$defs/identifier" } },
        stage: { type: "string", enum: ["architecture", "technical"] },
        impact: { type: "string", minLength: 1 },
        options: {
          type: "array",
          minItems: 1,
          maxItems: 6,
          items: { type: "string", minLength: 1 }
        }
      }
    },
    coverageEntry: {
      type: "object",
      additionalProperties: false,
      required: ["sourceRef", "subject", "disposition"],
      properties: {
        sourceRef: { type: "string", minLength: 1 },
        subject: { type: "string", minLength: 1 },
        disposition: { type: "string", enum: ["represented", "out-of-scope", "unresolved"] },
        nodeIds: { type: "array", items: { $ref: "#/$defs/identifier" } },
        interactionIds: { type: "array", items: { $ref: "#/$defs/identifier" } },
        questionIds: { type: "array", items: { $ref: "#/$defs/identifier" } },
        reason: { type: "string", minLength: 1 }
      }
    },
    operationalRequirement: {
      type: "object",
      additionalProperties: false,
      required: ["capability", "scope", "reason"],
      properties: {
        capability: {
          type: "string",
          enum: ["config", "transaction", "resilience"],
          description: "\u8FD0\u7EF4\u80FD\u529B\u95ED\u96C6\uFF1Aconfig\uFF08\u914D\u7F6E\u4E2D\u5FC3\uFF09/ transaction\uFF08\u4E8B\u52A1\uFF09/ resilience\uFF08\u9650\u6D41\u7194\u65AD\u7B49\u97E7\u6027\uFF09\u3002"
        },
        scope: {
          type: "array",
          minItems: 1,
          uniqueItems: true,
          items: { type: "string", minLength: 1 },
          description: "\u4F5C\u7528\u8303\u56F4\uFF1A\u5143\u7D20\u662F\u6A21\u5757\u8282\u70B9 id\uFF08`service` / `application-component`\uFF09\u6216 `*`\uFF08= \u5168\u90E8\u6A21\u5757\uFF09\u3002\u6A21\u5757 id \u5FC5\u987B\u5B58\u5728\u4E8E nodes[] \u4E14\u662F\u6A21\u5757\u7C7B\u8282\u70B9\uFF08`*` \u9664\u5916\uFF0C\u8BED\u4E49\u6821\u9A8C\u5224\uFF09\u2014\u2014\u672C\u5C42\u53EA\u7EA6\u675F\u975E\u7A7A\u5B57\u7B26\u4E32\uFF0Cid \u5B57\u7B26\u96C6\u7684\u552F\u4E00\u771F\u6E90\u4ECD\u662F $defs/identifier.pattern\u3002"
        },
        reason: {
          type: "string",
          minLength: 1,
          description: "\u4E00\u53E5\u8BDD\u4F9D\u636E\uFF08\u9700\u6C42\u539F\u6587\u91CC\u7684\u660E\u786E\u63AA\u8F9E\uFF09\u3002\u4E0D\u5199\u4F9D\u636E = \u731C\uFF0C\u7981\u6B62\u3002"
        },
        pattern: {
          type: "string",
          enum: ["local", "distributed"],
          description: "\u4EC5 transaction \u53EF\u7528\uFF08\u672C\u7EA6\u675F\u7531\u4E0B\u65B9 allOf \u5224\uFF09\uFF1Alocal = \u5355\u5E93\u672C\u5730\u4E8B\u52A1\uFF0Cdistributed = \u5206\u5E03\u5F0F\u4E8B\u52A1\uFF08\u5982 SCA / Seata \u7B49\u660E\u786E\u8981\u6C42\uFF09\u3002"
        },
        kind: {
          type: "string",
          enum: ["rate-limit", "circuit-break", "degrade", "bulkhead", "retry", "timeout"],
          description: "\u4EC5 resilience \u53EF\u7528\uFF08\u672C\u7EA6\u675F\u7531\u4E0B\u65B9 allOf \u5224\uFF09\uFF1Arate-limit \u9650\u6D41 / circuit-break \u7194\u65AD / degrade \u964D\u7EA7 / bulkhead \u9694\u79BB / retry \u91CD\u8BD5 / timeout \u8D85\u65F6\u3002**\u63CF\u8FF0\u5B57\u6BB5\uFF1A\u4E0D\u53C2\u4E0E\u4EA7\u54C1/\u4F9D\u8D56\u6620\u5C04**\uFF08\u9009\u54EA\u4E2A\u7EC4\u4EF6\u7531\u522B\u7684\u5224\u636E\u5B9A\uFF09\u3002\u53D6\u820D\u672A\u5B9A\u65F6\u4E0D\u5199\u8BE5\u952E\uFF0C\u4E0D\u8981\u731C\u3002"
        }
      },
      allOf: [
        {
          if: { properties: { capability: { const: "transaction" } }, required: ["capability"] },
          then: { properties: { pattern: { enum: ["local", "distributed"] } } }
        },
        {
          if: {
            properties: { capability: { enum: ["config", "resilience"] } },
            required: ["capability"]
          },
          then: { properties: { pattern: false } }
        },
        {
          if: { properties: { capability: { const: "resilience" } }, required: ["capability"] },
          then: {
            properties: {
              kind: { enum: ["rate-limit", "circuit-break", "degrade", "bulkhead", "retry", "timeout"] }
            }
          }
        },
        {
          if: {
            properties: { capability: { enum: ["config", "transaction"] } },
            required: ["capability"]
          },
          then: { properties: { kind: false } }
        }
      ]
    }
  }
};

// src/architecture/schema/architecture.schema.json
var architecture_schema_default = {
  $schema: "https://json-schema.org/draft/2020-12/schema",
  $id: "https://hicode.local/architecture/architecture.schema.json",
  title: "Architecture published package (program-generated)",
  description: "\u7A0B\u5E8F\u751F\u6210\u7684\u53D1\u5E03\u5305\uFF1Amodel \u4E3A\u901A\u8FC7\u68C0\u67E5\u7684\u539F\u5019\u9009\uFF08\u6309 architecture.model.schema.json \u6821\u9A8C\uFF09\uFF0Cprojection \u4E3A\u53EA\u7531 model + \u6765\u6E90\u5FEB\u7167\u5BFC\u51FA\u7684\u6D3E\u751F\u7ED3\u679C\u3002projection \u4E0D\u5141\u8BB8 agent \u6539\u5199\u3002\u6D3E\u751F\u4E8B\u5B9E\u53EA\u51FA\u73B0\u5728 projection \u91CC\uFF0C\u7EDD\u4E0D\u56DE\u5199\u8FDB model\u3002",
  type: "object",
  additionalProperties: false,
  required: ["schemaVersion", "metadata", "model", "projection"],
  properties: {
    schemaVersion: {
      enum: [1, 2],
      description: "v1 = \u65E7\u53D1\u5E03\u5305\uFF08**\u65E0** ownership \u6295\u5F71\uFF0C\u8BFB\u4FA7\u6309\u65E7\u89C4\u5219\u6D88\u8D39\uFF09\uFF1Bv2 = \u542B\u6709\u6548\u8BA4\u9886\u6295\u5F71\u3002\u65E7\u5DE5\u5177\u9047\u5230 v2 \u5FC5\u987B\u62A5\u7248\u672C\u4E0D\u652F\u6301\uFF0C\u7981\u6309\u65E7\u89C4\u5219\u5FFD\u7565\u65B0\u51B3\u5B9A\uFF08plan D5\uFF09\u3002"
    },
    metadata: { $ref: "#/$defs/metadata" },
    model: {
      $ref: "https://hicode.local/architecture/architecture.model.schema.json",
      description: "\u5019\u9009\u539F\u6837\u900F\u4F20\uFF08\u542B\u53EF\u9009\u7684 `model.operationalRequirements`\uFF09\u3002\u8BE5\u5757\u7684\u5F62\u6001/required/enum/maxItems \u7531\u6A21\u578B schema \u7684 `$defs/operationalRequirement` \u5355\u70B9\u5B9A\u4E49\u2014\u2014\u672C\u6587\u4EF6**\u4E0D\u518D\u6284\u4E00\u4EFD**\uFF08\u4E24\u5904\u5B9A\u4E49\u5FC5\u7136\u6F02\u79FB\uFF09\uFF0C\u53D1\u5E03\u5305\u4FA7\u7ECF\u8FD9\u6761 `$ref` \u81EA\u52A8\u83B7\u5F97\u540C\u4E00\u7EA6\u675F\u3002"
    },
    projection: { $ref: "#/$defs/projection" }
  },
  allOf: [
    {
      if: { properties: { schemaVersion: { const: 2 } }, required: ["schemaVersion"] },
      then: {
        properties: { projection: { required: ["ownership"] } },
        description: "v2 \u5FC5\u987B\u5E26 ownership \u6295\u5F71\uFF1A\u6CA1\u6709\u5B83\u5C31\u4E0D\u80FD\u79F0\u4E3A v2\uFF08\u5426\u5219\u4E0B\u6E38\u8BFB\u4FA7\u4F1A\u5728\u201C\u65B0\u7248\u672C\u3001\u65E7\u8BED\u4E49\u201D\u4E4B\u95F4\u8BEF\u5224\uFF09\u3002"
      }
    },
    {
      if: { properties: { schemaVersion: { const: 1 } }, required: ["schemaVersion"] },
      then: {
        properties: { projection: { properties: { ownership: false } } },
        description: "v1 \u4E0D\u5F97\u5E26 ownership \u6295\u5F71\uFF1A\u5E26\u65B0\u6295\u5F71\u7684\u5305\u5FC5\u987B\u662F v2\uFF0C\u65E7\u5DE5\u5177\u636E\u6B64\u62D2\u7EDD\u6D88\u8D39\u3002"
      }
    }
  ],
  $defs: {
    metadata: {
      type: "object",
      additionalProperties: false,
      required: ["applicationId", "rendererVersion", "generatedAt", "modelDigest"],
      properties: {
        applicationId: { type: "string", minLength: 1 },
        rendererVersion: {
          type: "integer",
          minimum: 1,
          description: "\u6E32\u67D3\u5668\u7248\u672C\uFF1BMermaid \u6B63\u6587\u786E\u5B9A\u6027\u7684\u4E00\u90E8\u5206\uFF08\u5E42\u7B49\u9501\uFF1A\u540C\u5951\u7EA6 + \u540C rendererVersion \u9010\u5B57\u8282\u4E00\u81F4\uFF09\u3002"
        },
        generatedAt: { type: "string", minLength: 1 },
        modelDigest: { type: "string", minLength: 1 }
      }
    },
    projection: {
      type: "object",
      additionalProperties: false,
      required: ["resolvedNodes", "trafficClassByInteraction", "views", "interactionIndex"],
      properties: {
        resolvedNodes: {
          type: "array",
          description: "\u5360\u4F4D\u5F62\u6001\uFF1A\u5143\u7D20\u5B57\u6BB5\u7531 C \u6BB5\uFF08\u6295\u5F71\u5B9E\u73B0\uFF09\u5728\u6536\u7D27 schema \u65F6\u8865\u9F50\u3002",
          items: { type: "object" }
        },
        trafficClassByInteraction: {
          type: "array",
          description: "\u6D41\u91CF\u4E09\u5206\u7C7B\uFF08\u5357\u5317 / \u4E1C\u897F / \u5916\u90E8\uFF09\uFF0C\u7531\u6295\u5F71\u6309\u804C\u8D23\u77E9\u9635\u5224\u3001\u6761\u4EF6\u4E0D\u8DB3\u4E0D\u731C\uFF1Bagent \u7981\u76F4\u586B\u3002\u5143\u7D20\u5176\u4F59\u5B57\u6BB5\u7531 C \u6BB5\u8865\u9F50\u3002",
          items: {
            type: "object",
            required: ["interactionId", "trafficClass"],
            properties: {
              interactionId: { type: "string", minLength: 1 },
              trafficClass: { type: "string", enum: ["north-south", "east-west", "external"] }
            }
          }
        },
        views: {
          type: "array",
          description: "\u5360\u4F4D\u5F62\u6001\uFF1A\u5143\u7D20\u5B57\u6BB5\uFF08\u542B\u786E\u5B9A\u6027\u6E32\u67D3\u4EA7\u7269 mermaid\uFF09\u7531 C \u6BB5\u5728\u6536\u7D27 schema \u65F6\u8865\u9F50\u3002",
          items: { type: "object" }
        },
        interactionIndex: {
          type: "array",
          description: "\u5360\u4F4D\u5F62\u6001\uFF1A\u6309 nodeId \u67E5 incoming/outgoing \u7684\u7D22\u5F15\uFF0C\u5143\u7D20\u5B57\u6BB5\u7531 C \u6BB5\u8865\u9F50\u3002",
          items: { type: "object" }
        },
        ownership: {
          $ref: "#/$defs/ownershipProjection",
          description: "\u53EF\u9009\uFF1A\u6709\u6548\u8BA4\u9886\u6295\u5F71\u3002v1 \u7F3A\u5E2D\uFF08\u65E7\u884C\u4E3A\uFF09\uFF1B\u542B\u672C\u952E = v2\u3002\u7A0B\u5E8F\u751F\u6210\uFF0Cagent \u7981\u6539\u3002"
        }
      }
    },
    effectiveOwnership: {
      type: "object",
      additionalProperties: false,
      required: ["domainId", "ownerNodeId", "ownershipScope"],
      properties: {
        domainId: { type: "string", minLength: 1 },
        ownerNodeId: { type: "string", minLength: 1 },
        ownershipScope: { type: "string", enum: ["view", "module"] },
        decisionId: { type: "string", minLength: 1 }
      }
    },
    ownershipProjection: {
      type: "object",
      additionalProperties: false,
      required: ["effective", "backendModules", "decisions"],
      properties: {
        effective: {
          type: "array",
          description: "domain \u2192 node \u7684\u6709\u6548\u5F52\u5C5E\uFF08\u542B view \u8BA4\u9886\u4E0E\u9ED8\u8BA4 business \u8BA4\u9886\uFF09\u3002",
          items: { $ref: "#/$defs/effectiveOwnership" }
        },
        backendModules: {
          type: "array",
          description: "\u53EA\u542B ownershipScope==='module' \u7684\u5F52\u5C5E\uFF1Bview \u8BA4\u9886\u4E0D\u5F97\u51FA\u73B0\u5728\u540E\u7AEF\u6A21\u5757\u9762\uFF08plan D4\uFF09\u3002",
          items: { $ref: "#/$defs/effectiveOwnership" }
        },
        decisions: {
          type: "array",
          description: "\u6295\u5F71\u5F15\u7528\u7684\u51B3\u5B9A\u6458\u8981\uFF08\u4E00\u81F4\u6027\u6838\u9A8C\u4E0E\u8BC1\u636E\uFF0C\u4E0D\u662F\u6743\u5A01\uFF09\u3002",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["decisionId", "domainId", "ownerNodeId", "ownershipScope"],
            properties: {
              decisionId: { type: "string", minLength: 1 },
              domainId: { type: "string", minLength: 1 },
              ownerNodeId: { type: "string", minLength: 1 },
              ownershipScope: { type: "string", enum: ["view", "module"] },
              sourceRef: { type: "string", minLength: 1 }
            }
          }
        }
      }
    }
  }
};

// src/architecture/schema/index.ts
var MODEL_SCHEMA_ID = architecture_model_schema_default.$id;
var PUBLISHED_SCHEMA_ID = architecture_schema_default.$id;
var cachedValidator;
function createArchitectureValidator() {
  if (cachedValidator) return cachedValidator;
  const schemas = [architecture_model_schema_default, architecture_schema_default];
  const registry = createSchemaRegistry(schemas);
  const unsupported = [
    ...collectUnsupportedKeywords(architecture_model_schema_default).map((ref) => ({ ...ref, schemaId: MODEL_SCHEMA_ID })),
    ...collectUnsupportedKeywords(architecture_schema_default).map((ref) => ({ ...ref, schemaId: PUBLISHED_SCHEMA_ID }))
  ];
  cachedValidator = {
    validateModel(value) {
      return validateJsonSchema(value, architecture_model_schema_default, registry);
    },
    validatePublished(value) {
      return validateJsonSchema(value, architecture_schema_default, registry);
    },
    unsupportedKeywords() {
      return unsupported.slice();
    }
  };
  return cachedValidator;
}
function validateAgainstModelSchema(value) {
  return createArchitectureValidator().validateModel(value);
}
function validateAgainstPublishedSchema(value) {
  return createArchitectureValidator().validatePublished(value);
}

// src/architecture/validate/feedback.ts
var MODEL_SCHEMA_VIOLATION = "MODEL_SCHEMA_VIOLATION";
var UNSUPPORTED_SCHEMA_KEYWORD = "UNSUPPORTED_SCHEMA_KEYWORD";
var HINTS = {
  required: "\u8865\u4E0A\u8FD9\u4E2A\u5FC5\u586B\u952E \u2014\u2014 \u7F3A\u5E2D\u5373\u7EA2\uFF0C\u4E0D\u8C41\u514D",
  additionalProperties: "\u5220\u6389\u672A\u58F0\u660E\u7684\u952E\uFF1B\u6D3E\u751F\u4E8B\u5B9E\uFF08traffic*/resolved*/renderId\uFF09\u4E00\u5F8B\u7981\u5165\u6A21\u578B\uFF0C\u7531\u6295\u5F71\u751F\u6210",
  type: "\u6309\u5951\u7EA6\u671F\u671B\u7684\u7C7B\u578B\u6539\u5199\u8BE5\u5B57\u6BB5",
  const: "\u8BE5\u952E\u53D6\u503C\u88AB\u5951\u7EA6\u9489\u6B7B\uFF08schemaVersion \u6052\u4E3A 1\uFF09",
  enum: "\u53EA\u80FD\u53D6\u679A\u4E3E\u91CC\u5217\u51FA\u7684\u503C\u4E4B\u4E00",
  pattern: "\u6309\u5951\u7EA6\u7684 canonical id \u5B57\u7B26\u96C6\u6539\u5199\uFF1AASCII \u5B57\u6BCD/\u6570\u5B57\u5F00\u5934\uFF0C\u540E\u7EED\u53EF\u542B - _ . :\uFF08\u7981\u628A\u8FDE\u5B57\u7B26 id \u622A\u65AD\u6216\u6539\u5199\uFF09",
  minLength: "\u8865\u8DB3\u5185\u5BB9\uFF08\u4E0D\u5F97\u4E3A\u7A7A\u4E32\uFF09",
  maxLength: "\u7F29\u77ED\u5185\u5BB9",
  minItems: "\u81F3\u5C11\u8865\u4E00\u9879",
  maxItems: "\u5220\u6389\u591A\u4F59\u9879",
  uniqueItems: "\u53BB\u6389\u91CD\u590D\u9879",
  minimum: "\u8C03\u5927\u8BE5\u6570\u503C",
  maximum: "\u8C03\u5C0F\u8BE5\u6570\u503C",
  false: "\u8BE5\u4F4D\u7F6E\u88AB schema \u663E\u5F0F\u7981\u6B62 \u2014\u2014 \u79FB\u9664\u5B83",
  $ref: "schema \u5F15\u7528\u89E3\u4E0D\u5F00\uFF08\u5DE5\u5177/schema \u6545\u969C\uFF09\uFF1B\u5148\u786E\u8BA4\u5F15\u64CE\u652F\u6301\u8303\u56F4\uFF0C\u522B\u6539\u5019\u9009\u7ED5"
};
function schemaErrorsToIssues(errors) {
  return errors.map(
    (error) => modelIssue(
      MODEL_SCHEMA_VIOLATION,
      error.pointer,
      `schema \u6821\u9A8C\u5931\u8D25\uFF08${error.keyword}\uFF09\uFF1A${error.message}`,
      HINTS[error.keyword]
    )
  );
}
function unsupportedKeywordsToIssues(refs) {
  return refs.map(
    (ref) => gateIssue(
      UNSUPPORTED_SCHEMA_KEYWORD,
      ref.pointer,
      `\u6821\u9A8C\u5F15\u64CE\u4E0D\u652F\u6301 schema \u5173\u952E\u5B57 \`${ref.keyword}\`${ref.schemaId ? `\uFF08\u51FA\u73B0\u5728 ${ref.schemaId}\uFF09` : ""} \u2014\u2014 \u8BE5\u7EA6\u675F\u4E0D\u4F1A\u88AB\u6821\u9A8C\uFF0C\u7981\u6B62\u5F53\u4F5C\u901A\u8FC7\uFF1B\u987B\u6269\u5F15\u64CE\u6216\u4ECE schema \u79FB\u9664`,
      "\u6269 src/architecture/validate/json-schema.ts \u7684\u652F\u6301\u5B50\u96C6\uFF08\u5E76\u5728 SUPPORTED_KEYWORDS \u767B\u8BB0\uFF09\uFF0C\u6216\u6362\u6389\u8BE5\u5173\u952E\u5B57\uFF1B\u4E0D\u8981\u6539\u5019\u9009\u6765\u7ED5"
    )
  );
}

// src/architecture/types/published.ts
var PUBLISHED_SCHEMA_VERSION = 1;
var PUBLISHED_SCHEMA_VERSION_WITH_OWNERSHIP = 2;
var RENDERER_VERSION = 1;

// src/architecture/version.ts
var UNSUPPORTED_SCHEMA_VERSION = "unsupported-schema-version";
var SUPPORTED_PUBLISHED_SCHEMA_VERSIONS = [
  PUBLISHED_SCHEMA_VERSION,
  PUBLISHED_SCHEMA_VERSION_WITH_OWNERSHIP
];
function isSupportedPublishedSchemaVersion(v) {
  return SUPPORTED_PUBLISHED_SCHEMA_VERSIONS.includes(v);
}
function publishedSchemaVersionHasOwnership(v) {
  return v === PUBLISHED_SCHEMA_VERSION_WITH_OWNERSHIP;
}
function unsupportedVersionIssues(found, expected, where) {
  const wanted = Array.isArray(expected) ? expected.join(" / ") : String(expected);
  return [
    gateIssue(
      UNSUPPORTED_SCHEMA_VERSION,
      where,
      `\u4E0D\u652F\u6301\u7684 schemaVersion\uFF1A${JSON.stringify(found)}\uFF08${where} \u671F\u671B ${wanted}\uFF09\u2014\u2014 \u505C\u6B62\u672C\u8F6E\uFF0C\u4E0D\u8981\u6309\u8001\u5B57\u6BB5\u731C\u3001\u4E5F\u4E0D\u8981\u9759\u9ED8\u91CD\u6E32\u67D3`
    )
  ];
}

// src/architecture/pipeline.ts
var ARCHITECTURE_PIPELINE_CRASH = "ARCHITECTURE_PIPELINE_CRASH";
var ARCHITECTURE_DIGEST_UNSTABLE = "ARCHITECTURE_DIGEST_UNSTABLE";
var RENDERER_WHITELIST_VIOLATION = "RENDERER_WHITELIST_VIOLATION";
var PUBLISHED_SCHEMA_SELFCHECK_FAILED = "PUBLISHED_SCHEMA_SELFCHECK_FAILED";
var UNSUPPORTED_RENDERER_VERSION = "UNSUPPORTED_RENDERER_VERSION";
var OVERVIEW_CONSISTENCY_CRASH = "OVERVIEW_CONSISTENCY_CRASH";
var OVERVIEW_VIEW_MISSING = "overview-view-missing";
var OVERVIEW_VIEW_DRIFTED = "overview-view-drifted";
var OVERVIEW_INTERACTION_MISSING = "overview-interaction-missing";
var OWNERSHIP_PROJECTION_INVALID = "ownership-projection-invalid";
var UNSTABLE_DIGEST = digestOf("<model-not-serializable>");
var OVERVIEW_PATH = "backend/clarify/architecture-overview.md";
function buildPublishedPackage(input) {
  let modelDigest;
  try {
    modelDigest = digestOfJson(input?.model);
  } catch (error) {
    return {
      modelDigest: UNSTABLE_DIGEST,
      issues: [
        gateIssue(
          ARCHITECTURE_DIGEST_UNSTABLE,
          "",
          `\u5019\u9009\u6A21\u578B\u65E0\u6CD5 canonical \u5E8F\u5217\u5316\uFF08${errorText3(error)}\uFF09\u2014\u2014 \u6458\u8981\u4E0D\u53EF\u7528\uFF0C\u505C\u6B62\u672C\u8F6E`,
          "\u786E\u8BA4\u5019\u9009\u662F JSON \u53EF\u5E8F\u5217\u5316\u7684\u666E\u901A\u5BF9\u8C61\uFF08\u65E0\u5FAA\u73AF\u5F15\u7528 / \u65E0 BigInt / \u65E0\u51FD\u6570\uFF09"
        )
      ]
    };
  }
  try {
    const unsupported = unsupportedKeywordsToIssues(createArchitectureValidator().unsupportedKeywords());
    if (unsupported.length > 0) return { modelDigest, issues: unsupported };
    const schemaErrors = validateAgainstModelSchema(input.model);
    if (schemaErrors.length > 0) return { modelDigest, issues: schemaErrorsToIssues(schemaErrors) };
    const model = input.model;
    if (!Array.isArray(input.domains)) {
      return {
        modelDigest,
        issues: [
          inputIssue(
            "domains-missing",
            "domains",
            "\u771F\u5B9E\u57DF\u6E05\u5355\uFF08plans/domain.json \u7684 domains[]\uFF09\u7F3A\u5E2D\u6216\u4E0D\u662F\u6570\u7EC4 \u2014\u2014 D12\u300C\u57DF\u5212\u5206\u6070\u4E00\u6B21\u300D\u65E0\u4ECE\u5224\u5B9A",
            "\u8C03\u7528\u65B9\u628A domain.json \u7684 domains[] \u539F\u6837\u4F20\u8FDB\u6765\uFF1B\u786E\u65E0\u57DF\u65F6\u4F20\u7A7A\u6570\u7EC4\uFF08\u7A7A\u6570\u7EC4 = \u672C\u9879\u76EE\u6CA1\u6709\u57DF\uFF0C\u4E0D\u662F\u8DF3\u8FC7\uFF09"
          )
        ]
      };
    }
    const semanticIssues = validateArchitectureModelSemantics(model, {
      domainIds: input.domains,
      decisions: Array.isArray(input.decisions) ? input.decisions : [],
      ...input.domainTypes ? { domainTypes: input.domainTypes } : {}
    });
    if (semanticIssues.length > 0) return { modelDigest, issues: semanticIssues };
    const projection = buildProjection(model, input.nameResolver ? { nameResolver: input.nameResolver } : {});
    if (!projection.projection) return { modelDigest, issues: projection.issues };
    const views = projection.projection.views;
    const whitelistIssues = [];
    for (const view of views) {
      const mermaid = renderViewToMermaid(view);
      view.mermaid = mermaid;
      const violations = findMermaidWhitelistViolations(mermaid);
      if (violations.length > 0) {
        whitelistIssues.push(
          gateIssue(
            RENDERER_WHITELIST_VIOLATION,
            `/projection/views/${view.viewId}/mermaid`,
            `\u89C6\u56FE "${view.viewId}" \u7684\u6E32\u67D3\u4EA7\u7269\u8D85\u51FA\u767D\u540D\u5355\u8BED\u6CD5\uFF1A${violations.join("\uFF1B")} \u2014\u2014 \u6E32\u67D3\u5668\u552F\u4E00\u7684\u5199\u56FE\u5904\u5374\u5199\u51FA\u4E86\u8D8A\u6743\u8BED\u6CD5\uFF0C\u662F\u5DE5\u5177\u6545\u969C`,
            "\u4FEE\u6E32\u67D3\u5668/\u8F6C\u4E49\u903B\u8F91\u5E76\u8865\u56DE\u5F52\uFF1B\u4E0D\u8981\u6539\u5019\u9009\u6A21\u578B\u7ED5\u8FC7\uFF08\u56FE\u5FC5\u987B\u7531\u6E32\u67D3\u5668\u751F\u6210\uFF09"
          )
        );
      }
    }
    if (whitelistIssues.length > 0) return { modelDigest, issues: whitelistIssues };
    const decisions = Array.isArray(input.decisions) ? input.decisions : [];
    let ownership;
    if (decisions.length > 0) {
      const resolution = resolveDomainOwnership({
        model,
        domainIds: input.domains,
        decisions,
        ...input.domainTypes ? { domainTypes: input.domainTypes } : {}
      });
      if (resolution.issues.length > 0) return { modelDigest, issues: resolution.issues };
      ownership = {
        effective: resolution.effective,
        backendModules: resolution.backendModules,
        decisions: ownershipDecisionRefsOf(resolution.effective, decisions)
      };
    }
    const pkg = {
      schemaVersion: ownership ? PUBLISHED_SCHEMA_VERSION_WITH_OWNERSHIP : PUBLISHED_SCHEMA_VERSION,
      metadata: { ...input.metadata, rendererVersion: RENDERER_VERSION, modelDigest },
      model,
      projection: projection.projection
    };
    if (ownership) pkg.projection.ownership = ownership;
    const publishedErrors = validateAgainstPublishedSchema(pkg);
    if (publishedErrors.length > 0) {
      return {
        modelDigest,
        issues: [
          gateIssue(
            PUBLISHED_SCHEMA_SELFCHECK_FAILED,
            "",
            `\u7EC4\u51FA\u7684\u53D1\u5E03\u5305\u4E0D\u5408 architecture.schema.json\uFF1A${publishedErrors.slice(0, 5).map((error) => `${error.pointer || "/"} ${error.keyword}: ${error.message}`).join("\uFF1B")}${publishedErrors.length > 5 ? `\uFF08\u5171 ${publishedErrors.length} \u6761\uFF09` : ""}`,
            "\u8FD9\u662F\u5DE5\u5177\u4E0E\u53D1\u5E03\u5305 schema \u7684\u9519\u4F4D\uFF08gate\uFF09\uFF1A\u4FEE schema/\u7EC4\u5305\u4EE3\u7801\uFF0C\u4E0D\u8981\u6539\u5019\u9009\u6A21\u578B"
          )
        ]
      };
    }
    const overviewMarkdown = renderArchitectureOverview(pkg);
    const consistencyIssues = verifyPublishedConsistency(pkg);
    if (consistencyIssues.length > 0) return { modelDigest, issues: consistencyIssues };
    return { pkg, overviewMarkdown, modelDigest, issues: [] };
  } catch (error) {
    return {
      modelDigest,
      issues: [
        gateIssue(
          ARCHITECTURE_PIPELINE_CRASH,
          "",
          `\u67B6\u6784\u7BA1\u7EBF\u5185\u90E8\u5F02\u5E38\uFF1A${errorText3(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u6A21\u578B\u7ED5\u8FC7`,
          "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
        )
      ]
    };
  }
}
function digestPublishedArtifacts(pkg, overviewMarkdown) {
  return digestOf(
    [digestOfJson(pkg.model), digestOfJson(pkg.projection), `md:${digestOf(overviewMarkdown)}`].join("\n")
  );
}
function ownershipDecisionRefsOf(effective, decisions) {
  const byId = /* @__PURE__ */ new Map();
  decisions.forEach((decision) => {
    if (typeof decision?.decisionId === "string" && decision.decisionId !== "" && !byId.has(decision.decisionId)) {
      byId.set(decision.decisionId, decision);
    }
  });
  const refs = [];
  const seen = /* @__PURE__ */ new Set();
  for (const entry of effective) {
    const decisionId = entry.decisionId;
    if (typeof decisionId !== "string" || seen.has(decisionId)) continue;
    const decision = byId.get(decisionId);
    if (!decision) continue;
    seen.add(decisionId);
    const ref = {
      decisionId,
      domainId: entry.domainId,
      ownerNodeId: entry.ownerNodeId,
      ownershipScope: entry.ownershipScope
    };
    if (typeof decision.sourceRef === "string" && decision.sourceRef.length > 0) ref.sourceRef = decision.sourceRef;
    refs.push(ref);
  }
  return refs;
}
function ownershipProjectionIssues(pkg) {
  const issues = [];
  const projection = pkg?.projection;
  const raw = projection?.ownership;
  const hasOwnership = publishedSchemaVersionHasOwnership(pkg?.schemaVersion);
  if (!hasOwnership) {
    if (raw !== void 0) {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          "/projection/ownership",
          `\u53D1\u5E03\u5305 schemaVersion=${JSON.stringify(pkg?.schemaVersion)}\uFF08v1\uFF09\u5374\u5E26 ownership \u6295\u5F71 \u2014\u2014 \u5E26\u65B0\u6295\u5F71\u7684\u5305\u5FC5\u987B\u662F v2\uFF0C\u5426\u5219\u65E7\u8BFB\u4FA7\u4F1A\u6309\u65E7\u89C4\u5219\u5FFD\u7565\u5DF2\u786E\u8BA4\u51B3\u5B9A`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF08\u7531\u6784\u5EFA\u5668\u51B3\u5B9A\u7248\u672C\uFF09\uFF1B\u4E0D\u8981\u624B\u6539 schemaVersion \u6216\u5220\u6295\u5F71\u6765\u300C\u4FEE\u300D\u7248\u672C"
        )
      );
    }
    return issues;
  }
  if (raw === void 0 || raw === null || typeof raw !== "object" || Array.isArray(raw)) {
    return [
      gateIssue(
        OWNERSHIP_PROJECTION_INVALID,
        "/projection/ownership",
        "\u53D1\u5E03\u5305 schemaVersion=2\uFF08v2\uFF09\u5374\u6CA1\u6709 ownership \u6295\u5F71 \u2014\u2014 \u300C\u65B0\u7248\u672C\u3001\u65E7\u8BED\u4E49\u300D\u4F1A\u8BA9\u4E0B\u6E38\u8BEF\u5224\u5DF2\u786E\u8BA4\u51B3\u5B9A\u4E0D\u5B58\u5728",
        "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1Bv2 \u5FC5\u987B\u7531\u6784\u5EFA\u5668\u5199\u5165 effective / backendModules / decisions"
      )
    ];
  }
  const ownership = raw;
  const effective = Array.isArray(ownership.effective) ? ownership.effective : [];
  const backendModules = Array.isArray(ownership.backendModules) ? ownership.backendModules : [];
  const decisions = Array.isArray(ownership.decisions) ? ownership.decisions : [];
  if (!Array.isArray(ownership.effective) || !Array.isArray(ownership.backendModules) || !Array.isArray(ownership.decisions)) {
    issues.push(
      gateIssue(
        OWNERSHIP_PROJECTION_INVALID,
        "/projection/ownership",
        "ownership \u6295\u5F71\u7684 effective / backendModules / decisions \u5FC5\u987B\u90FD\u662F\u6570\u7EC4 \u2014\u2014 \u5F62\u6001\u4E0D\u7B26\u8BF4\u660E\u5305\u4E0D\u662F\u6784\u5EFA\u5668\u4EA7\u51FA\u7684",
        "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1B\u4E0D\u8981\u624B\u6539\u6295\u5F71\uFF08\u5B83\u662F\u6D3E\u751F\u5FEB\u7167\uFF09"
      )
    );
    return issues;
  }
  const expectedBackendModules = effective.filter((entry) => entry?.ownershipScope === "module");
  if (digestOfJson(backendModules) !== digestOfJson(expectedBackendModules)) {
    issues.push(
      gateIssue(
        OWNERSHIP_PROJECTION_INVALID,
        "/projection/ownership/backendModules",
        "backendModules \u4E0D\u7B49\u4E8E effective \u4E2D ownershipScope=module \u7684\u5B50\u5E8F\u5217 \u2014\u2014 \u540E\u7AEF\u6A21\u5757\u9762\u88AB\u6539\u5199\uFF08view \u8BA4\u9886\u6216\u9ED8\u8BA4\u5F52\u5C5E\u88AB\u632A\u52A8\uFF09",
        "\u91CD\u65B0\u6295\u5F71\u5E76\u91CD\u5EFA\u53D1\u5E03\u5305\uFF1B\u4E0D\u8981\u624B\u6539\u6295\u5F71\uFF08\u524D\u7AEF view \u8BA4\u9886\u4E0D\u5F97\u8FDB\u5165\u540E\u7AEF\u6A21\u5757\u9762\uFF09"
      )
    );
  }
  const nodes = Array.isArray(pkg.model?.nodes) ? pkg.model.nodes : [];
  const nodeById = /* @__PURE__ */ new Map();
  nodes.forEach((node) => {
    if (typeof node?.id === "string" && !nodeById.has(node.id)) nodeById.set(node.id, node);
  });
  effective.forEach((entry, index) => {
    const where = `/projection/ownership/effective/${index}`;
    if (entry?.ownershipScope !== "view" && entry?.ownershipScope !== "module") {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          `${where}/ownershipScope`,
          `\u6295\u5F71\u5F52\u5C5E\u7684 ownershipScope \u975E\u6CD5\uFF08${JSON.stringify(entry?.ownershipScope)}\uFF09`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1Bscope \u53EA\u80FD\u662F view / module"
        )
      );
    }
    const node = typeof entry?.ownerNodeId === "string" ? nodeById.get(entry.ownerNodeId) : void 0;
    if (!node) {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          `${where}/ownerNodeId`,
          `\u6295\u5F71\u5F52\u5C5E\u5F15\u7528\u7684\u8282\u70B9 "${String(entry?.ownerNodeId)}" \u4E0D\u5728\u5305\u5185 model.nodes[] \u91CC \u2014\u2014 \u6D3E\u751F\u5FEB\u7167\u6307\u5411\u4E0D\u5B58\u5728\u7684 owner`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1B\u6295\u5F71\u5FC5\u987B\u7531\u5F53\u524D model + \u6709\u6548\u51B3\u5B9A\u91CD\u65B0\u5BFC\u51FA"
        )
      );
      return;
    }
    const owned = Array.isArray(node.ownedDomainIds) ? node.ownedDomainIds : [];
    if (!owned.includes(entry.domainId)) {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          `${where}/domainId`,
          `\u6295\u5F71\u58F0\u79F0\u57DF "${String(entry?.domainId)}" \u5F52\u5C5E\u8282\u70B9 "${node.id}"\uFF0C\u4F46\u8BE5\u8282\u70B9\u7684 ownedDomainIds \u672A\u5305\u542B\u8BE5\u57DF \u2014\u2014 \u8BA4\u9886\u672A\u843D\u5B9E\u5374\u5199\u8FDB\u4E86\u6295\u5F71`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1B\u672A\u843D\u5B9E\u7684\u51B3\u5B9A\u5E94\u62A5 ownership-decision-not-applied\uFF0C\u800C\u4E0D\u662F\u4EA7\u51FA\u5F52\u5C5E"
        )
      );
    }
  });
  const effectiveById = /* @__PURE__ */ new Map();
  effective.forEach((entry) => {
    if (typeof entry?.decisionId === "string" && entry.decisionId !== "" && !effectiveById.has(entry.decisionId)) {
      effectiveById.set(entry.decisionId, entry);
    }
  });
  decisions.forEach((ref, index) => {
    const where = `/projection/ownership/decisions/${index}`;
    const entry = typeof ref?.decisionId === "string" ? effectiveById.get(ref.decisionId) : void 0;
    if (!entry) {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          `${where}/decisionId`,
          `\u6295\u5F71\u5F15\u7528\u4E86\u51B3\u5B9A "${String(ref?.decisionId)}"\uFF0C\u4F46\u5B83\u6CA1\u6709\u51FA\u73B0\u5728 effective \u91CC \u2014\u2014 \u672A\u751F\u6548\u7684\u51B3\u5B9A\u4E0D\u5F97\u8FDB\u5165\u6295\u5F71`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1B\u6295\u5F71\u7684 decisions \u53EA\u6536\u5B9E\u9645\u751F\u6548\uFF08effective \u5E26 decisionId\uFF09\u7684\u51B3\u5B9A"
        )
      );
      return;
    }
    if (entry.domainId !== ref.domainId || entry.ownerNodeId !== ref.ownerNodeId || entry.ownershipScope !== ref.ownershipScope) {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          where,
          `\u6295\u5F71\u51B3\u5B9A\u7684\u6458\u8981\uFF08\u57DF ${String(ref.domainId)} / owner ${String(ref.ownerNodeId)} / scope ${String(ref.ownershipScope)}\uFF09\u4E0E effective \u4E2D\u7684\u751F\u6548\u9879\u4E0D\u4E00\u81F4`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1B\u51B3\u5B9A\u5F15\u7528\u5FC5\u987B\u662F\u751F\u6548\u5F52\u5C5E\u7684\u539F\u6837\u6458\u8981"
        )
      );
    }
  });
  effective.forEach((entry, index) => {
    const decisionId = entry?.decisionId;
    if (typeof decisionId !== "string" || decisionId === "") return;
    if (!decisions.some((ref) => ref?.decisionId === decisionId)) {
      issues.push(
        gateIssue(
          OWNERSHIP_PROJECTION_INVALID,
          `/projection/ownership/effective/${index}/decisionId`,
          `effective \u5F15\u7528\u4E86\u51B3\u5B9A "${decisionId}"\uFF0C\u4F46 decisions[] \u6CA1\u6709\u5B83\u7684\u6458\u8981 \u2014\u2014 \u6295\u5F71\u7F3A\u5C11\u8BC1\u636E\u5F15\u7528`,
          "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1Beffective \u5E26 decisionId \u65F6 decisions[] \u5FC5\u987B\u6709\u5BF9\u5E94\u6458\u8981"
        )
      );
    }
  });
  return issues;
}
function verifyPublishedConsistency(pkg) {
  const issues = [];
  try {
    const rendererVersion = pkg?.metadata?.rendererVersion;
    if (rendererVersion !== RENDERER_VERSION) {
      return [
        gateIssue(
          UNSUPPORTED_RENDERER_VERSION,
          "/metadata/rendererVersion",
          `\u4E0D\u652F\u6301\u7684 rendererVersion\uFF1A${JSON.stringify(rendererVersion)}\uFF08\u672C\u5DE5\u5177\u652F\u6301 ${RENDERER_VERSION}\uFF09\u2014\u2014 \u505C\u6B62\u672C\u8F6E\uFF0C\u4E0D\u8981\u9759\u9ED8\u91CD\u6E32\u67D3`,
          "\u7528\u4EA7\u51FA\u8BE5\u5305\u7684\u6E32\u67D3\u5668\u7248\u672C\u91CD\u8DD1\uFF0C\u6216\u663E\u5F0F\u8FC1\u79FB\u8BE5\u5305\uFF1B\u4E0D\u8981\u7528\u5F53\u524D\u6E32\u67D3\u5668\u628A\u5B83\u91CD\u753B\u4E00\u904D\u5192\u5145\u4E00\u81F4"
        )
      ];
    }
    const markdown = renderArchitectureOverview(pkg);
    issues.push(...ownershipProjectionIssues(pkg));
    const views = Array.isArray(pkg?.projection?.views) ? pkg.projection.views : [];
    views.forEach((view, index) => {
      const mermaid = typeof view?.mermaid === "string" ? view.mermaid : "";
      const where = `/projection/views/${index}`;
      if (mermaid.length === 0) {
        issues.push(
          gateIssue(
            OVERVIEW_VIEW_MISSING,
            `${where}/mermaid`,
            `\u89C6\u56FE "${String(view?.viewId ?? index)}" \u7684\u53D1\u5E03\u5305\u91CC\u6CA1\u6709 mermaid \u6B63\u6587 \u2014\u2014 \u6E32\u67D3\u672A\u843D\u8FDB\u5305`,
            "\u68C0\u67E5\u6E32\u67D3\u6B65\u9AA4\u662F\u5426\u771F\u7684\u628A renderViewToMermaid \u7684\u7ED3\u679C\u5199\u56DE\u53D1\u5E03\u5305"
          )
        );
        return;
      }
      if (renderViewToMermaid(view) !== mermaid) {
        issues.push(
          gateIssue(
            OVERVIEW_VIEW_DRIFTED,
            `${where}/mermaid`,
            `\u89C6\u56FE "${String(view?.viewId ?? index)}" \u7684\u5305\u5185 mermaid \u4E0E\u6E32\u67D3\u5668\u91CD\u7B97\u7ED3\u679C\u4E0D\u4E00\u81F4 \u2014\u2014 \u6D3E\u751F\u6F02\u79FB\uFF08\u5305\u88AB\u6539\u52A8\u8FC7\uFF0C\u6216\u6E32\u67D3\u5668\u4E0E\u5305\u4E0D\u540C\u7248\uFF09`,
            "\u91CD\u65B0\u6E32\u67D3\u5E76\u91CD\u5EFA\u53D1\u5E03\u5305\uFF1B\u4E0D\u8981\u624B\u6539\u53D1\u5E03\u5305\u91CC\u7684 mermaid \u6B63\u6587"
          )
        );
        return;
      }
      if (!markdown.includes(mermaid)) {
        issues.push(
          gateIssue(
            OVERVIEW_VIEW_MISSING,
            `${where}/mermaid`,
            `\u6982\u89C8\u6B63\u6587\u4E2D\u627E\u4E0D\u5230\u89C6\u56FE "${String(view?.viewId ?? index)}" \u7684 Mermaid \u6E90\u7801\uFF08\u987B\u9010\u5B57\u51FA\u73B0\uFF09`,
            `\u68C0\u67E5 ${OVERVIEW_PATH} \u7684\u751F\u6210\u5668\uFF1A\u56FE\u4E0E\u8868\u5FC5\u987B\u540C\u6E90`
          )
        );
      }
    });
    const interactions = Array.isArray(pkg?.model?.interactions) ? pkg.model.interactions : [];
    interactions.forEach((interaction, index) => {
      if (!markdown.includes(`| ${interaction.id} |`)) {
        issues.push(
          gateIssue(
            OVERVIEW_INTERACTION_MISSING,
            `/model/interactions/${index}`,
            `\u6982\u89C8\u4EA4\u4E92\u8868\u4E2D\u7F3A\u5C11\u4EA4\u4E92 "${interaction.id}"\uFF08\u987B\u4EE5 \`| <id> |\` \u539F\u6837\u51FA\u73B0\uFF09`,
            `\u68C0\u67E5 ${OVERVIEW_PATH} \u7684\u4EA4\u4E92\u8868\u751F\u6210\u5668\uFF1A\u6BCF\u884C\u7B2C\u4E00\u4E2A\u5355\u5143\u683C\u5FC5\u987B\u662F interaction id \u539F\u6837`
          )
        );
      }
    });
    return issues;
  } catch (error) {
    return [
      ...issues,
      gateIssue(
        OVERVIEW_CONSISTENCY_CRASH,
        "",
        `\u53D1\u5E03\u5305\u4E00\u81F4\u6027\u590D\u9A8C\u5185\u90E8\u5F02\u5E38\uFF1A${errorText3(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09`,
        "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1"
      )
    ];
  }
}
function errorText3(error) {
  if (error instanceof Error) return `${error.name}: ${error.message}`;
  return String(error);
}

// src/architecture/cli-args.ts
var FLAG_KEYS = {
  "--model": "model",
  "--out": "out",
  "--application": "application",
  "--domains": "domains",
  "--name-resolver": "nameResolver",
  "--decisions": "decisions",
  "--verify-contract-refs": "verifyContractRefs",
  "--verify-published": "verifyPublished"
};
var BOOLEAN_FLAGS = /* @__PURE__ */ new Set(["--verify-contract-refs"]);
var BUILD_REQUIRED = ["model", "out", "application", "domains"];
var FLAG_LABEL = {
  model: "--model",
  out: "--out",
  application: "--application",
  domains: "--domains",
  nameResolver: "--name-resolver",
  decisions: "--decisions",
  verifyContractRefs: "--verify-contract-refs",
  verifyPublished: "--verify-published"
};
var USAGE = "\u7528\u6CD5\uFF1A--model <path> --out <dir> --application <id> --domains <path|list> [--name-resolver <path>] [--decisions <path>] [--verify-contract-refs]\uFF1B\u6216 --verify-published <pkgPath>";
function parseDomainsSpec(value) {
  const raw = typeof value === "string" ? value : "";
  if (raw.includes(",")) {
    const ids = raw.split(",").map((item) => item.trim()).filter((item) => item.length > 0);
    return { kind: "list", ids };
  }
  if (raw.endsWith(".json") || raw.includes("/") || raw.includes("\\")) {
    return { kind: "file", path: raw };
  }
  return { kind: "list", ids: raw.trim().length > 0 ? [raw.trim()] : [] };
}
function parseArchitectureCliArgs(argv) {
  const tokens = Array.isArray(argv) ? argv : [];
  const values = {};
  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index];
    if (typeof token !== "string" || !token.startsWith("--")) {
      return {
        error: {
          message: `\u672A\u77E5\u53C2\u6570\uFF1A${String(token)}\uFF08\u53C2\u6570\u5FC5\u987B\u4EE5 -- \u5F00\u5934\uFF09`,
          hint: USAGE
        }
      };
    }
    const equals = token.indexOf("=");
    const flag = equals >= 0 ? token.slice(0, equals) : token;
    const inlineValue = equals >= 0 ? token.slice(equals + 1) : void 0;
    const key = FLAG_KEYS[flag];
    if (key === void 0) {
      return {
        error: {
          message: `\u672A\u77E5\u53C2\u6570\uFF1A${flag}\uFF08\u53EF\u7528\uFF1A${Object.keys(FLAG_KEYS).join(" / ")}\uFF09`,
          hint: USAGE
        }
      };
    }
    if (values[key] !== void 0) {
      return {
        error: {
          message: `\u91CD\u590D\u53C2\u6570\uFF1A${flag} \u2014\u2014 \u540C\u4E00\u53C2\u6570\u53EA\u80FD\u7ED9\u4E00\u6B21\uFF08\u6700\u540E\u4E00\u6B21\u80DC\u51FA\u4F1A\u8BA9\u524D\u4E00\u6B21\u9759\u9ED8\u5931\u6548\uFF09`,
          hint: "\u5220\u6389\u91CD\u590D\u7684\u90A3\u6B21\uFF1B\u786E\u8981\u6539\u503C\u8BF7\u6539\u5728\u552F\u4E00\u7684\u90A3\u4E2A\u53C2\u6570\u4E0A"
        }
      };
    }
    if (BOOLEAN_FLAGS.has(flag)) {
      if (inlineValue !== void 0) {
        return {
          error: {
            message: `\u53C2\u6570 ${flag} \u662F\u5F00\u5173\uFF0C\u4E0D\u5E26\u503C\uFF08\u6536\u5230 ${flag}=${inlineValue}\uFF09`,
            hint: `\u5F00\u542F\u5C31\u5199 ${flag}\uFF0C\u5173\u95ED\u5C31\u6574\u4E2A\u7701\u7565\uFF1B\u5199 ${flag}=false \u4F1A\u628A\u300C\u5173\u300D\u8868\u8FBE\u6210\u4E00\u4E2A\u4E0D\u5B58\u5728\u7684\u53D6\u503C`
          }
        };
      }
      values[key] = "true";
      continue;
    }
    let value = inlineValue;
    if (value === void 0) {
      const next = tokens[index + 1];
      if (next === void 0 || typeof next === "string" && next.startsWith("--")) {
        return {
          error: { message: `\u53C2\u6570 ${flag} \u7F3A\u503C`, hint: `\u6309 ${flag} <\u503C> \u7ED9\u51FA\uFF08${USAGE}\uFF09` }
        };
      }
      value = typeof next === "string" ? next : String(next);
      index += 1;
    }
    if (value.trim().length === 0) {
      return {
        error: {
          message: `\u53C2\u6570 ${flag} \u7684\u503C\u4E3A\u7A7A \u2014\u2014 \u663E\u5F0F\u4F20\u53C2\u5FC5\u987B\u5E26\u975E\u7A7A\u503C\uFF08\u7F3A\u7701\u8BF7\u6574\u4E2A\u7701\u7565\u8BE5\u53C2\u6570\uFF09`,
          hint: USAGE
        }
      };
    }
    values[key] = value;
  }
  if (values.verifyPublished !== void 0) {
    const conflicting = Object.keys(values).filter((key) => key !== "verifyPublished").map((key) => FLAG_LABEL[key] ?? String(key));
    if (conflicting.length > 0) {
      return {
        error: {
          message: `--verify-published \u4E0E\u6784\u5EFA\u53C2\u6570\u5E76\u5B58\uFF08${conflicting.join(" / ")}\uFF09\u2014\u2014 \u4E24\u4E2A\u6A21\u5F0F\u7684\u53C2\u6570\u9762\u4E92\u65A5`,
          hint: "\u590D\u9A8C\u6A21\u5F0F\u53EA\u7ED9 --verify-published <pkgPath>\uFF1B\u8981\u4EA7\u51FA\u53D1\u5E03\u5305\u8BF7\u7528\u6784\u5EFA\u6A21\u5F0F\u7684\u90A3\u7EC4\u53C2\u6570"
        }
      };
    }
    return { args: { mode: "verify", verifyPublished: values.verifyPublished } };
  }
  const missing = BUILD_REQUIRED.filter((key) => values[key] === void 0).map(
    (key) => FLAG_LABEL[key] ?? String(key)
  );
  if (missing.length > 0) {
    return {
      error: {
        message: `\u6784\u5EFA\u6A21\u5F0F\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570\uFF1A${missing.join(" / ")}`,
        hint: `${USAGE}\uFF1B--domains \u5FC5\u586B\uFF08\u62FF\u4E0D\u5230\u771F\u5B9E\u57DF\u6E05\u5355\u65F6\u987B\u663E\u5F0F\u62A5\u9519\uFF0C\u4E0D\u5F97\u9759\u9ED8\u4F20\u7A7A\u6E05\u5355\uFF09`
      }
    };
  }
  const args = {
    mode: "build",
    model: values.model,
    out: values.out,
    application: values.application,
    domains: values.domains
  };
  if (values.nameResolver !== void 0) args.nameResolver = values.nameResolver;
  if (values.decisions !== void 0) args.decisions = values.decisions;
  if (values.verifyContractRefs !== void 0) args.verifyContractRefs = true;
  return { args };
}

// src/architecture/cli.mts
var CLI_ARG_ERROR = "CLI_ARG_ERROR";
var CLI_CRASH = "CLI_CRASH";
var CLI_MODEL_UNREADABLE = "CLI_MODEL_UNREADABLE";
var CLI_MODEL_PARSE_ERROR = "CLI_MODEL_PARSE_ERROR";
var CLI_DOMAINS_UNREADABLE = "CLI_DOMAINS_UNREADABLE";
var CLI_DOMAINS_INVALID = "CLI_DOMAINS_INVALID";
var CLI_DOMAINS_EMPTY = "CLI_DOMAINS_EMPTY";
var CLI_DECISIONS_UNREADABLE = "CLI_DECISIONS_UNREADABLE";
var CLI_DECISIONS_INVALID = "CLI_DECISIONS_INVALID";
var CLI_NAME_RESOLVER_UNREADABLE = "CLI_NAME_RESOLVER_UNREADABLE";
var CLI_PACKAGE_UNREADABLE = "CLI_PACKAGE_UNREADABLE";
var CLI_PACKAGE_PARSE_ERROR = "CLI_PACKAGE_PARSE_ERROR";
var CLI_PUBLISHED_PACKAGE_INVALID = "CLI_PUBLISHED_PACKAGE_INVALID";
var CLI_OUTPUT_UNWRITABLE = "CLI_OUTPUT_UNWRITABLE";
var CLI_PIPELINE_NO_OUTPUT = "CLI_PIPELINE_NO_OUTPUT";
var ARTIFACT_PACKAGE_REL = "backend/_meta/architecture.json";
var ARTIFACT_OVERVIEW_REL = "backend/clarify/architecture-overview.md";
function runArchitectureCli(argv, io = {}) {
  const resolved = {
    cwd: io.cwd ?? process.cwd(),
    stdout: io.stdout ?? ((line) => process.stdout.write(`${line}
`)),
    stderr: io.stderr ?? ((line) => process.stderr.write(`${line}
`)),
    now: io.now ?? (() => (/* @__PURE__ */ new Date()).toISOString())
  };
  const parsed = parseArchitectureCliArgs(argv);
  if (!parsed.args) {
    return emit(resolved, [
      gateIssue(CLI_ARG_ERROR, "args", parsed.error?.message ?? "\u53C2\u6570\u89E3\u6790\u5931\u8D25", parsed.error?.hint)
    ]);
  }
  try {
    return parsed.args.mode === "verify" ? runVerify(parsed.args, resolved) : runBuild(parsed.args, resolved);
  } catch (error) {
    return emit(resolved, [
      gateIssue(
        CLI_CRASH,
        "",
        `\u67B6\u6784 tool \u5185\u90E8\u5F02\u5E38\uFF1A${describeError(error)} \u2014\u2014 \u8FD9\u662F\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u8981\u9760\u6539\u5019\u9009\u7ED5\u8FC7`,
        "\u4FEE\u5DE5\u5177\u6216\u6362\u6784\u5EFA\u4EA7\u7269\u540E\u91CD\u8DD1\uFF1B\u4E0D\u8981\u4E3A\u4E86\u8FC7\u5173\u53CD\u590D\u6539\u5019\u9009\uFF08\u4F1A\u628A\u4E1A\u52A1\u4E8B\u5B9E\u6539\u574F\uFF09"
      )
    ]);
  }
}
function runBuild(args, io) {
  const modelPath = resolvePath(io.cwd, args.model);
  const modelText = readTextFile(modelPath);
  if (modelText === null) {
    return emit(io, [
      gateIssue(
        CLI_MODEL_UNREADABLE,
        modelPath,
        `\u5019\u9009\u6A21\u578B\u4E0D\u53EF\u8BFB\uFF1A${modelPath} \u2014\u2014 \u8F93\u5165\u6E90\u4E0D\u53EF\u8BFB\u5C5E\u73AF\u5883\u95EE\u9898\uFF08gate\uFF09`,
        "\u786E\u8BA4 --model \u6307\u5411\u7684\u6587\u4EF6\u5B58\u5728\u4E14\u53EF\u8BFB\uFF1B\u4E0D\u8981\u628A\u300C\u6587\u4EF6\u6CA1\u4EA7\u51FA\u6765\u300D\u5F53\u6210\u300C\u6A21\u578B\u5199\u9519\u4E86\u300D\u53BB\u6539\u5019\u9009"
      )
    ]);
  }
  let model;
  try {
    model = JSON.parse(modelText);
  } catch (error) {
    return emit(io, [
      modelIssue(
        CLI_MODEL_PARSE_ERROR,
        modelPath,
        `\u5019\u9009\u6A21\u578B\u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${describeError(error)}`,
        "\u4FEE JSON \u8BED\u6CD5\uFF08\u5C3E\u9017\u53F7 / \u6CE8\u91CA / \u5F15\u53F7\uFF09\u540E\u91CD\u8DD1\uFF1B\u8FD9\u662F\u5019\u9009\u81EA\u8EAB\u7684\u95EE\u9898"
      )
    ]);
  }
  const domains = resolveDomains(args.domains, io);
  if ("issues" in domains) return emit(io, domains.issues);
  let decisions = [];
  if (args.decisions !== void 0) {
    const loaded = resolveDecisions(args.decisions, io);
    if ("issues" in loaded) return emit(io, loaded.issues);
    decisions = loaded.decisions;
  }
  let nameResolver;
  if (args.nameResolver !== void 0) {
    const resolverPath = resolvePath(io.cwd, args.nameResolver);
    const resolverText = readTextFile(resolverPath);
    if (resolverText === null) {
      return emit(io, [
        gateIssue(
          CLI_NAME_RESOLVER_UNREADABLE,
          resolverPath,
          `\u540D\u79F0\u89E3\u6790\u8868\u4E0D\u53EF\u8BFB\uFF1A${resolverPath}`,
          "\u786E\u8BA4 --name-resolver \u6307\u5411\u7684 JSON \u6587\u4EF6\u5B58\u5728\u4E14\u53EF\u8BFB\uFF0C\u6216\u6574\u4E2A\u7701\u7565\u8BE5\u53C2\u6570"
        )
      ]);
    }
    let table;
    try {
      table = JSON.parse(resolverText);
    } catch (error) {
      return emit(io, [
        gateIssue(
          CLI_NAME_RESOLVER_UNREADABLE,
          resolverPath,
          `\u540D\u79F0\u89E3\u6790\u8868\u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${describeError(error)}`,
          '\u8868\u5F62\u6001\u4E3A { "<source>#<id>": "<\u5C55\u793A\u540D>" }'
        )
      ]);
    }
    const map = /* @__PURE__ */ new Map();
    if (typeof table === "object" && table !== null && !Array.isArray(table)) {
      for (const [key, value] of Object.entries(table)) {
        if (typeof value === "string" && value.length > 0) map.set(key, value);
      }
    }
    nameResolver = (ref) => map.get(`${ref.source}#${ref.id}`);
  }
  const outDir = resolvePath(io.cwd, args.out);
  const built = buildPublishedPackage({
    model,
    metadata: { applicationId: args.application, generatedAt: io.now() },
    domains: domains.ids,
    decisions,
    ...domains.types ? { domainTypes: domains.types } : {},
    ...nameResolver ? { nameResolver } : {}
  });
  if (built.issues.length > 0) {
    return emit(io, built.issues, { modelDigest: built.modelDigest });
  }
  if (built.pkg === void 0 || built.overviewMarkdown === void 0) {
    return emit(io, [
      gateIssue(
        CLI_PIPELINE_NO_OUTPUT,
        "",
        "\u67B6\u6784\u7BA1\u7EBF\u62A5\u4E86\u300C\u65E0\u95EE\u9898\u300D\u5374\u6CA1\u6709\u4EA7\u51FA\u53D1\u5E03\u5305 \u2014\u2014 \u5DE5\u5177\u81EA\u76F8\u77DB\u76FE\uFF08gate\uFF09",
        "\u8FD9\u662F\u5DE5\u5177\u6545\u969C\uFF1A\u67E5 pipeline.ts \u7684\u77ED\u8DEF\u5206\u652F\uFF0C\u4E0D\u8981\u6539\u5019\u9009\u7ED5\u8FC7"
      )
    ]);
  }
  if (args.verifyContractRefs === true) {
    const reachability = validateArchitectureModelSemantics(model, {
      domainIds: domains.ids,
      decisions,
      ...domains.types ? { domainTypes: domains.types } : {},
      resolveRef: createContractRefResolver(outDir)
    });
    if (reachability.length > 0) {
      return emit(io, reachability, { modelDigest: built.modelDigest });
    }
  }
  const pkg = built.pkg;
  const packagePath = path.join(outDir, ...ARTIFACT_PACKAGE_REL.split("/"));
  const overviewPath = path.join(outDir, ...ARTIFACT_OVERVIEW_REL.split("/"));
  const writeError = writeArtifacts([
    { abs: packagePath, content: canonicalJsonPretty(pkg) },
    { abs: overviewPath, content: built.overviewMarkdown }
  ]);
  if (writeError !== null) {
    return emit(io, [
      gateIssue(
        CLI_OUTPUT_UNWRITABLE,
        writeError.path,
        `\u4EA7\u7269\u5199\u4E0D\u51FA\u53BB\uFF1A${writeError.path}\uFF08${writeError.message}\uFF09\u2014\u2014 \u8F93\u51FA\u76EE\u5F55\u4E0D\u53EF\u5199\u5C5E\u73AF\u5883\u95EE\u9898\uFF08gate\uFF09`,
        "\u786E\u8BA4 --out \u6307\u5411\u7684\u76EE\u5F55\u53EF\u5199\u3001\u4E14\u4E0D\u662F\u4E00\u4E2A\u5DF2\u5B58\u5728\u7684\u6587\u4EF6"
      )
    ]);
  }
  return emit(io, [], {
    modelDigest: built.modelDigest,
    packageDigest: digestPublishedArtifacts(pkg, built.overviewMarkdown),
    artifacts: [ARTIFACT_PACKAGE_REL, ARTIFACT_OVERVIEW_REL]
  });
}
function resolveDomains(raw, io) {
  const spec = parseDomainsSpec(raw);
  let ids;
  let types;
  if (spec.kind === "list") {
    ids = spec.ids;
  } else {
    const domainsPath = resolvePath(io.cwd, spec.path);
    const text = readTextFile(domainsPath);
    if (text === null) {
      return {
        issues: [
          gateIssue(
            CLI_DOMAINS_UNREADABLE,
            domainsPath,
            `\u57DF\u6E05\u5355\u6587\u4EF6\u4E0D\u53EF\u8BFB\uFF1A${domainsPath}\uFF08--domains \u5224\u4E3A\u6587\u4EF6\u5F62\u6001\uFF09`,
            "\u786E\u8BA4\u8DEF\u5F84\u5B58\u5728\u4E14\u53EF\u8BFB\uFF1B\u6216\u7528\u9017\u53F7\u5206\u9694\u7684\u57DF id \u6E05\u5355\uFF08--domains a,b\uFF1B\u6E05\u5355\u5F62\u6001\u4E0D\u542B\u57DF\u7C7B\u578B\uFF0C\u4E0D\u53C2\u4E0E\u901A\u7528\u57DF\u8C41\u514D\uFF09"
          )
        ]
      };
    }
    let parsedJson;
    try {
      parsedJson = JSON.parse(text);
    } catch (error) {
      return {
        issues: [
          gateIssue(
            CLI_DOMAINS_UNREADABLE,
            domainsPath,
            `\u57DF\u6E05\u5355\u6587\u4EF6\u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${describeError(error)}`,
            "domain.json \u7531 outline \u4EA7\u51FA\uFF1B\u574F\u6587\u4EF6\u5C5E\u4E0A\u6E38\u4EA7\u7269\u95EE\u9898\uFF0C\u5148\u4FEE\u4E0A\u6E38\u518D\u91CD\u8DD1"
          )
        ]
      };
    }
    const rawDomains = parsedJson?.domains;
    if (!Array.isArray(rawDomains)) {
      return {
        issues: [
          gateIssue(
            CLI_DOMAINS_INVALID,
            domainsPath,
            "`domains` \u7F3A\u5E2D\u6216\u4E0D\u662F\u6570\u7EC4 \u2014\u2014 D12\u300C\u57DF\u5212\u5206\u6070\u4E00\u6B21\u300D\u7684\u53D6\u503C\u57DF\u65E0\u4ECE\u6784\u9020",
            "\u4F20 outline \u4EA7\u51FA\u7684 plans/domain.json\uFF08\u542B\u975E\u7A7A domains[]\uFF0C\u6BCF\u9879\u6709\u5B57\u7B26\u4E32 id\uFF09"
          )
        ]
      };
    }
    const collected = [];
    const collectedTypes = {};
    for (let index = 0; index < rawDomains.length; index += 1) {
      const entry = rawDomains[index];
      const id = typeof entry === "string" ? entry : entry?.id;
      if (typeof id !== "string" || id.length === 0) {
        return {
          issues: [
            gateIssue(
              CLI_DOMAINS_INVALID,
              `${domainsPath}#/domains/${index}`,
              `domains[${index}] \u53D6\u4E0D\u5230\u5B57\u7B26\u4E32 id \u2014\u2014 \u57DF\u6E05\u5355\u5F62\u6001\u4E0D\u7B26\uFF08D12 \u7684\u53D6\u503C\u57DF\u5FC5\u987B\u662F\u57DF id \u6E05\u5355\uFF09`,
              "\u6539\u7528 outline \u4EA7\u51FA\u7684 domain.json\uFF1B\u6216\u7528\u9017\u53F7\u5206\u9694\u7684\u57DF id \u6E05\u5355\uFF08--domains a,b\uFF1B\u6E05\u5355\u5F62\u6001\u4E0D\u542B\u57DF\u7C7B\u578B\uFF0C\u4E0D\u53C2\u4E0E\u901A\u7528\u57DF\u8C41\u514D\uFF09"
            )
          ]
        };
      }
      collected.push(id);
      const type = typeof entry === "string" ? void 0 : entry?.type;
      if (type === "core" || type === "support" || type === "common") collectedTypes[id] = type;
    }
    ids = collected;
    if (Object.keys(collectedTypes).length > 0) types = collectedTypes;
  }
  if (ids.length === 0) {
    return {
      issues: [
        gateIssue(
          CLI_DOMAINS_EMPTY,
          "domains",
          "\u771F\u5B9E\u57DF\u6E05\u5355\u4E3A\u7A7A \u2014\u2014 \u62D2\u7EDD\u9759\u9ED8\u6309\u300C\u672C\u9879\u76EE\u6CA1\u6709\u4EFB\u4F55\u57DF\u300D\u7EE7\u7EED\uFF08\u4F1A\u8BEF\u5224\u6240\u6709 ownedDomainIds \u4E3A domain-unknown\uFF09",
          "\u4F20 outline \u4EA7\u51FA\u7684 domain.json\uFF08check-domain.mjs \u8981\u6C42 domains[] \u975E\u7A7A\uFF09\uFF0C\u6216\u7ED9\u51FA\u9017\u53F7\u5206\u9694\u7684\u57DF id \u6E05\u5355\uFF08\u6E05\u5355\u5F62\u6001\u4E0D\u542B\u57DF\u7C7B\u578B\uFF0C\u4E0D\u53C2\u4E0E\u901A\u7528\u57DF\u8C41\u514D\uFF09"
        )
      ]
    };
  }
  return { ids, ...types ? { types } : {} };
}
function resolveDecisions(raw, io) {
  const decisionsPath = resolvePath(io.cwd, raw);
  const text = readTextFile(decisionsPath);
  if (text === null) {
    return {
      issues: [
        gateIssue(
          CLI_DECISIONS_UNREADABLE,
          decisionsPath,
          `\u8BA4\u9886\u51B3\u5B9A\u6587\u4EF6\u4E0D\u53EF\u8BFB\uFF1A${decisionsPath} \u2014\u2014 \u7ED9\u4E86 --decisions \u5C31\u5FC5\u987B\u53EF\u8BFB\uFF08\u4E0D\u5F97\u5F53\u6210\u300C\u6CA1\u6709\u51B3\u5B9A\u300D\u7EE7\u7EED\uFF09`,
          "\u786E\u8BA4\u8DEF\u5F84\u5B58\u5728\u4E14\u53EF\u8BFB\uFF1B\u672C\u9879\u76EE\u6CA1\u6709\u8BA4\u9886\u51B3\u5B9A\u65F6\u6574\u4E2A\u7701\u7565 --decisions\uFF08\u7F3A\u7701 = \u6309\u9ED8\u8BA4\u89C4\u5219\u6821\u9A8C\u3001\u53D1\u5E03\u5305\u5199 v1\uFF09"
        )
      ]
    };
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (error) {
    return {
      issues: [
        gateIssue(
          CLI_DECISIONS_UNREADABLE,
          decisionsPath,
          `\u8BA4\u9886\u51B3\u5B9A\u6587\u4EF6\u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${describeError(error)} \u2014\u2014 \u574F\u6587\u4EF6\u5C5E\u8F93\u5165\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u80FD\u6309\u300C\u6CA1\u6709\u51B3\u5B9A\u300D\u56DE\u9000`,
          "\u51B3\u5B9A\u6587\u4EF6\u7531\u51B3\u7B56\u8D26\u672C\u5BFC\u51FA\uFF08ArchitectureOwnershipDecision[]\uFF09\uFF1B\u5148\u4FEE\u4E0A\u6E38\u5BFC\u51FA\u518D\u91CD\u8DD1\uFF0C\u4E0D\u8981\u624B\u6539\u534A\u622A\u6587\u4EF6"
        )
      ]
    };
  }
  if (!Array.isArray(parsed)) {
    return {
      issues: [
        gateIssue(
          CLI_DECISIONS_INVALID,
          decisionsPath,
          "\u8BA4\u9886\u51B3\u5B9A\u6587\u4EF6\u5FC5\u987B\u662F JSON \u6570\u7EC4\uFF08ArchitectureOwnershipDecision[]\uFF09\u2014\u2014 \u5F62\u6001\u4E0D\u7B26\u65F6\u4E0D\u731C\u5B83\u7684\u610F\u56FE",
          "\u7531\u51B3\u7B56\u8D26\u672C\u5BFC\u51FA\u6570\u7EC4\uFF1B\u6CA1\u6709\u51B3\u5B9A\u5C31\u6574\u4E2A\u7701\u7565 --decisions"
        )
      ]
    };
  }
  const decisions = [];
  for (let index = 0; index < parsed.length; index += 1) {
    const normalized = normalizeDecision(parsed[index]);
    if ("problem" in normalized) {
      return {
        issues: [
          gateIssue(
            CLI_DECISIONS_INVALID,
            `${decisionsPath}#/${index}`,
            `decisions[${index}] \u5F62\u6001\u4E0D\u7B26\uFF1A${normalized.problem} \u2014\u2014 \u574F\u51B3\u5B9A\u6587\u4EF6\u662F\u8F93\u5165\u6545\u969C\uFF08gate\uFF09\uFF0C\u4E0D\u5F97\u9759\u9ED8\u4E22\u5F03\u8BE5\u6761`,
            "\u51B3\u5B9A\u7531\u51B3\u7B56\u8D26\u672C\u5BFC\u51FA\uFF1B\u7F3A\u5B57\u6BB5 / \u7C7B\u578B\u4E0D\u7B26\u5148\u4FEE\u4E0A\u6E38\u5BFC\u51FA\uFF0C\u4E0D\u8981\u5728\u5DE5\u5177\u4FA7\u731C\u6216\u8865\u9ED8\u8BA4\u503C"
          )
        ]
      };
    }
    decisions.push(normalized.decision);
  }
  return { decisions };
}
function normalizeDecision(entry) {
  if (typeof entry !== "object" || entry === null || Array.isArray(entry)) return { problem: "\u4E0D\u662F\u5BF9\u8C61" };
  const raw = entry;
  const problems = [];
  for (const field of ["decisionId", "domainId", "ownerNodeId", "nodeKind", "nodeRole"]) {
    if (typeof raw[field] !== "string" || raw[field].length === 0) {
      problems.push(`${field} \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32`);
    }
  }
  if (raw.ownershipScope !== "view" && raw.ownershipScope !== "module") {
    problems.push(`ownershipScope \u5FC5\u987B\u662F 'view' \u6216 'module'\uFF08\u5B9E\u9645 ${JSON.stringify(raw.ownershipScope)}\uFF09`);
  }
  if (raw.applicationState !== "accepted" && raw.applicationState !== "applied") {
    problems.push(`applicationState \u5FC5\u987B\u662F 'accepted' \u6216 'applied'\uFF08\u5B9E\u9645 ${JSON.stringify(raw.applicationState)}\uFF09`);
  }
  if (raw.sourceRef !== void 0 && (typeof raw.sourceRef !== "string" || raw.sourceRef.length === 0)) {
    problems.push("sourceRef \u7ED9\u51FA\u65F6\u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
  }
  if (problems.length > 0) return { problem: problems.join("\uFF1B") };
  const decision = {
    decisionId: raw.decisionId,
    domainId: raw.domainId,
    ownerNodeId: raw.ownerNodeId,
    ownershipScope: raw.ownershipScope,
    nodeKind: raw.nodeKind,
    nodeRole: raw.nodeRole,
    applicationState: raw.applicationState
  };
  if (typeof raw.sourceRef === "string") decision.sourceRef = raw.sourceRef;
  return { decision };
}
function createContractRefResolver(baseDir) {
  const cache = /* @__PURE__ */ new Map();
  const read = (abs) => {
    if (cache.has(abs)) return cache.get(abs);
    const content = readTextFile(abs);
    cache.set(abs, content);
    return content;
  };
  return (ref) => {
    if (ref === null || typeof ref !== "object") return false;
    const docPath = ref.docPath;
    const anchor = ref.anchor;
    if (typeof docPath !== "string" || docPath.length === 0) return false;
    if (typeof anchor !== "string" || anchor.length === 0) return false;
    const abs = path.isAbsolute(docPath) ? docPath : path.resolve(baseDir, docPath);
    const content = read(abs);
    if (content === null) return false;
    return content.includes(anchor);
  };
}
function runVerify(args, io) {
  const pkgPath = resolvePath(io.cwd, args.verifyPublished);
  const text = readTextFile(pkgPath);
  if (text === null) {
    return emit(io, [
      gateIssue(
        CLI_PACKAGE_UNREADABLE,
        pkgPath,
        `\u53D1\u5E03\u5305\u4E0D\u53EF\u8BFB\uFF1A${pkgPath}`,
        "\u786E\u8BA4\u8DEF\u5F84\u5B58\u5728\u4E14\u53EF\u8BFB\uFF1B\u590D\u9A8C\u53EA\u8BFB\u53D1\u5E03\u5305\uFF0C\u4E0D\u4EA7\u51FA\u4EFB\u4F55\u6587\u4EF6"
      )
    ]);
  }
  let pkg;
  try {
    pkg = JSON.parse(text);
  } catch (error) {
    return emit(io, [
      gateIssue(
        CLI_PACKAGE_PARSE_ERROR,
        pkgPath,
        `\u53D1\u5E03\u5305\u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${describeError(error)} \u2014\u2014 \u673A\u5668\u4EA7\u51FA\u7684\u5305\u574F\u6210\u8FD9\u6837\u5C5E\u5DE5\u5177/\u73AF\u5883\u6545\u969C\uFF08gate\uFF09`,
        "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF08\u4E0D\u8981\u624B\u6539\u63D0\u4EA4\uFF09\uFF1B\u4E0D\u8981\u6309\u8001\u5B57\u6BB5\u731C\u5B83\u7684\u5185\u5BB9"
      )
    ]);
  }
  const schemaVersion = pkg?.schemaVersion;
  if (!isSupportedPublishedSchemaVersion(schemaVersion)) {
    return emit(io, unsupportedVersionIssues(schemaVersion, PUBLISHED_SCHEMA_VERSION, pkgPath));
  }
  const schemaErrors = validateAgainstPublishedSchema(pkg);
  if (schemaErrors.length > 0) {
    return emit(io, [
      gateIssue(
        CLI_PUBLISHED_PACKAGE_INVALID,
        pkgPath,
        `\u53D1\u5E03\u5305\u4E0D\u5408 architecture.schema.json\uFF1A${schemaErrors.slice(0, 5).map((error) => `${error.pointer || "/"} ${error.keyword}: ${error.message}`).join("\uFF1B")}${schemaErrors.length > 5 ? `\uFF08\u5171 ${schemaErrors.length} \u6761\uFF09` : ""} \u2014\u2014 \u673A\u5668\u4EA7\u51FA\u7684\u5305\u81EA\u76F8\u77DB\u76FE\u5C5E\u5DE5\u5177\u6545\u969C\uFF08gate\uFF09`,
        "\u91CD\u65B0\u6784\u5EFA\u8BE5\u5305\uFF1B\u53D1\u5E03\u5305\u4E0D\u662F\u5019\u9009\uFF0C\u4E0D\u8981\u624B\u6539\u5B83\u6765\u300C\u4FEE\u300D\u6821\u9A8C"
      )
    ]);
  }
  const consistency = verifyPublishedConsistency(pkg);
  if (consistency.length > 0) return emit(io, consistency);
  return emit(io, [], {
    modelDigest: readModelDigest(pkg),
    packageDigest: digestPublishedArtifacts(
      pkg,
      renderArchitectureOverview(pkg)
    )
  });
}
function emit(io, issues, extras = {}) {
  const report = { ok: issues.length === 0, failures: formatIssuesAsFailures(issues) };
  if (issues.length > 0) report.issues = issues;
  if (extras.modelDigest !== void 0) report.modelDigest = extras.modelDigest;
  if (extras.packageDigest !== void 0) report.packageDigest = extras.packageDigest;
  if (extras.artifacts !== void 0) report.artifacts = extras.artifacts;
  io.stdout(JSON.stringify(report));
  if (issues.length > 0) io.stderr(report.failures.join("\n"));
  if (issues.length === 0) return 0;
  return issues.some((issue) => issue.category === "gate") ? 2 : 1;
}
function readModelDigest(pkg) {
  const digest = pkg?.metadata?.modelDigest;
  return typeof digest === "string" && digest.length > 0 ? digest : void 0;
}
function resolvePath(cwd, target) {
  return path.isAbsolute(target) ? target : path.resolve(cwd, target);
}
function readTextFile(abs) {
  try {
    return fs.readFileSync(abs, "utf-8");
  } catch {
    return null;
  }
}
function writeArtifacts(artifacts) {
  for (const artifact of artifacts) {
    try {
      fs.mkdirSync(path.dirname(artifact.abs), { recursive: true });
      fs.writeFileSync(artifact.abs, artifact.content);
    } catch (error) {
      return { path: artifact.abs, message: describeError(error) };
    }
  }
  return null;
}
function describeError(error) {
  if (error instanceof Error) return `${error.name}: ${error.message}`;
  return String(error);
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(fs.realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  process.exitCode = runArchitectureCli(process.argv.slice(2));
}
export {
  ARTIFACT_OVERVIEW_REL,
  ARTIFACT_PACKAGE_REL,
  CLI_ARG_ERROR,
  CLI_CRASH,
  CLI_DECISIONS_INVALID,
  CLI_DECISIONS_UNREADABLE,
  CLI_DOMAINS_EMPTY,
  CLI_DOMAINS_INVALID,
  CLI_DOMAINS_UNREADABLE,
  CLI_MODEL_PARSE_ERROR,
  CLI_MODEL_UNREADABLE,
  CLI_NAME_RESOLVER_UNREADABLE,
  CLI_OUTPUT_UNWRITABLE,
  CLI_PACKAGE_PARSE_ERROR,
  CLI_PACKAGE_UNREADABLE,
  CLI_PIPELINE_NO_OUTPUT,
  CLI_PUBLISHED_PACKAGE_INVALID,
  createContractRefResolver,
  runArchitectureCli
};
