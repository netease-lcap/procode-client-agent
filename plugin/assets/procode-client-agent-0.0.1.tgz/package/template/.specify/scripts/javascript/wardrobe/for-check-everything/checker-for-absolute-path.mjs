import fs from 'fs';

import { readFileSync, getPathReg, getActiveSpecDir, toAbsoluteFilePath } from '../../shared/index.mjs';

import { combine, isPathOrQuote, startsByCores } from './tools.mjs';

export const checkerForAbsolutePath = {
  callback:
    (rootDir) =>
    (bundle = {}) => {
      const { absoluteFilePath } = bundle;

      const prefix = '[\\n（][\\s\\-\\*]\*';
      const suffix = '[^\\n：]{0,64}：[^\\n]*';

      const keywords = startsByCores.concat('关联文档');
      const joined = keywords.join('|');

      const combined = `${prefix}(${joined})${suffix}`;
      const reg = new RegExp(combined, 'g');

      const source = readFileSync(absoluteFilePath) || '';
      const replaced = source.replace(/#\s*被前端调用[^#]+/g, '');
      const matched = replaced.match(reg) || [];

      if (absoluteFilePath?.includes?.('specs/checklist-')) {
        return;
      }

      const messages = matched.reduce((result, item = '') => {
        item = item.replace(/^[\n\s]*/, '');

        let suffix = '';
        let [main, extra] = item.split('：');

        if (!extra) {
          return result;
        }

        if (main.startsWith('（')) {
          extra = extra.replace(/）$/g, '');
          suffix = '）';
        }

        const useful = isPathOrQuote(extra);

        if (!useful) {
          const prefix = '根据以下内容生成完整的绝对路径';
          const familiar = extra.includes(prefix);

          const current = (() => {
            if (familiar) {
              return combine('<!-- 请严格遵守不规范内容的要求，生成内容替换占位符。 -->', '', '#### 不规范内容', item);
            }

            const reg = getPathReg();
            const [matchdFilePath = ''] = extra.match(reg) || [];
            const matchedAbsoluteFilePath = toAbsoluteFilePath(rootDir)(matchdFilePath);

            const onlyPathReg = /^[a-zA-Z]+\/[\s\S]+\.[a-zA-Z]+$/;
            const isOnlyPath = item.endsWith(matchdFilePath) && onlyPathReg.test(matchdFilePath);

            if (isOnlyPath && !matchedAbsoluteFilePath) {
              return;
            }

            const hopeConetnt = matchedAbsoluteFilePath
              ? matchedAbsoluteFilePath.replace(`${rootDir}/`, '')
              : `[${prefix}：\`${extra}\`]${suffix}`;

            return combine('', '#### 预期格式', `${main}：${hopeConetnt}`, '', '#### 不规范内容', item);
          })();

          current && result.push(current);
        }

        return result;
      }, []);

      if (!messages.length) {
        return;
      }

      return combine('### 必须严格按照以下格式补充绝对路径', ...messages);
    },
};

export default checkerForAbsolutePath;
