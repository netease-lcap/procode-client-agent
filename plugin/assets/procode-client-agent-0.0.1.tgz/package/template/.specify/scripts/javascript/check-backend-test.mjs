#!/usr/bin/env node

/**
 * 方案 D 段 B1｜后端单测 executor checker（跑 + 判绿 + 指向 surefire 产物）。
 *
 * 砍掉归桶压缩层（parseDomainModuleMap/domainOf/structuredFailures/test-buckets.json）后，
 * 脚本只做三件事：
 *   1) 跑 `mvn test`（编译 + 全实体单测）
 *   2) 判绿：全绿 exit 0；有编译错/单测失败/无法运行 exit 1
 *   3) emit 失败计数 + surefire-reports 目录绝对路径 + 失败的 .txt 文件名清单 + failureDetails 截断摘要
 * 协调者读 emit 的 failureDetails（每个失败方法的精简摘要：方法名 + 异常/expected-was +
 * 业务调用栈行号，框架栈已砍、同根因已去重），直接定位根因；摘要不够时再 cat 全量 .txt 兜底。
 * 不恢复旧的归桶压缩层（domainOf/structuredXxx）——failureDetails 只做行过滤+去重，不域归桶、不路径推断。
 *
 * 三用：
 *   1) 段 B1 波诊断步骤：跑一次 → emit JSON（exit 1 不抛错，协调者读 failureDetails）。
 *   2) 段 B1 波 executor checker（createBackendTestChecker，全量 gate）：exit 0 当且仅当全绿；
 *      失败时 emit surefireDir + reportFiles + failureDetails，协调者读摘要拿失败，无需 grep 目录扫描。
 *   3) 段 B1 波后台模式（plan 2026-09-21/build-stage3-test-fix-stall-background-progress）：全量
 *      10~15 分钟的前台跑会被会话看门狗 720s 砍杀（bash 中间输出不产协议事件，8029 实证），拆成
 *      「start 秒回 + status 轮询」——每次 status 短调用 = 一次 tool completed = 双看门狗重置。
 *      后台子进程跑的是本脚本完整同步逻辑（--internal-run），emit JSON 契约（failureDetails 等）
 *      原样保留，不是裸 spawn mvnd（那会丢 mvnd 崩溃兜底与 surefire 解析）。
 *
 * 用法：
 *   node check-backend-test.mjs                                    （无参=同步全量，默认行为不变）
 *   node check-backend-test.mjs --background start --log <path>    （后台启动，秒回 JSON）
 *   node check-backend-test.mjs --background status --log <path>   （轮询：RUNNING/DONE/UNKNOWN）
 *   node check-backend-test.mjs --internal-run --log <path>        （内部：start 的子进程入口，prompt 不直接用）
 *
 * 后台产物（均以 <log> 为前缀）：.pid（pid + lstart，start 写）；.json（完整 emit JSON，子进程
 * emit 时写）；.exit（真实退出码，子进程 emit 时写——SIGKILL/崩溃没走到 emit 则无此文件，status
 * 判 UNKNOWN 红）。status 退出码：RUNNING=0；DONE=<子进程真实退出码>；UNKNOWN=3（证据不可判必须
 * 当红，禁静默跳过）。DONE 幂等可重放（进程死 + exit 文件存在即 DONE，pid 文件保留不清，防协调者
 * DONE 后复查 status 被误判 UNKNOWN；旧 pid/exit/json 由下一次 start 覆盖启动时清理）。
 * 历史兼容：本脚本此前不解析 argv（--gate=domains 一直被无声忽略），其它参数开头的调用保持
 * 「忽略参数、同步跑」旧语义零破坏；只有以 --background / --internal-run 开头才进新 CLI 面，
 * 此时缺子命令/未知 flag/缺 --log 一律 exit 2 fail loud（防拼错参数静默走同步全量复现 stall）。
 *
 * 退出码约定（与 createCommandCheckerByExitCode 对齐）：
 *   有编译错/单测失败/无法运行 → exit 1；全绿 → exit 0。
 *   失败时 emit JSON 含：failures（汇总行）、summary（totalFailures/totalErrors/compileErrors）、
 *     surefireDir（绝对路径）、reportFiles（有失败的 .txt 文件名清单，文件名=测试类 FQN）、
 *     failureDetails（key=文件名，value=截断摘要，协调者优先读此字段，不够再 cat .txt 兜底）。
 */

import { existsSync, readdirSync, readFileSync, statSync, writeFileSync, mkdirSync, rmSync, openSync, closeSync } from 'fs';
import { resolve, dirname, sep } from 'path';
import { fileURLToPath } from 'url';
import { spawnSync, execSync, spawn } from 'child_process';
import { parsePomJavaMajor, parseJavaVersionOutput } from './shared/java-version.mjs';
import {
  findBackendDir,
  findPlanBackendDir,
  collectSurefireReportDirs,
  resolveDeclaredBackendRoots,
  resolveProjectRoot,
} from './shared/backend-common.mjs';

// ESM 下无 __filename；start 需以自身绝对路径 re-spawn --internal-run 子进程
const SCRIPT_PATH = fileURLToPath(import.meta.url);

// ── CLI 解析（后台模式）───────────────────────────────────────────────
// 无参 = 原同步语义（所有既有调用方零感知）。--background start/status / --internal-run 见文件头。
// fail loud 只作用于新 CLI 面（首个参数是 --background / --internal-run）：缺子命令/未知 flag/
// 缺 --log → exit 2。其它参数开头（历史 --gate=domains 等）维持「忽略参数、同步跑」旧语义。
function failLoud(msg) {
  console.error(`[check-backend-test] ${msg}`);
  process.exit(2);
}

function parseLogArg(argv, startIdx) {
  let log = null;
  for (let i = startIdx; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--log') {
      log = argv[++i];
      if (!log) failLoud('--log 缺路径');
    } else {
      failLoud(`未知参数: ${a}（新 CLI 面仅支持 --log <path>）`);
    }
  }
  if (!log) failLoud('必须传 --log <path>');
  return log;
}

function parseCli(argv) {
  if (argv.length === 0 || (argv[0] !== '--background' && argv[0] !== '--internal-run')) {
    return { kind: 'sync' };
  }
  if (argv[0] === '--background') {
    const sub = argv[1];
    if (sub !== 'start' && sub !== 'status') {
      failLoud(`--background 缺子命令或子命令非法（仅 start/status），收到: ${sub ?? '(空)'}`);
    }
    return { kind: 'background', sub, log: parseLogArg(argv, 2) };
  }
  return { kind: 'internal-run', log: parseLogArg(argv, 1) };
}

const cli = parseCli(process.argv.slice(2));
const INTERNAL_LOG = cli.kind === 'internal-run' ? resolve(cli.log) : null;

// finally 语义兜底（plan §2.1，dual-review 2026-09-21 #1）：emit() 正常路径已写 .json/.exit 时
// 本钩子跳过；异常崩溃/未走到 emit 的退出路径，至少落真实退出码到 .exit——status 在「有 exit
// 无 .json」时仍判 UNKNOWN 红（证据不完整），但崩溃与 SIGKILL（钩子不执行、无文件）从此可区分，
// 且「json 已写、exit 未写」的窗口不再误判。
if (INTERNAL_LOG) {
  process.on('exit', (code) => {
    try {
      const exitPath = `${INTERNAL_LOG}.exit`;
      if (!existsSync(exitPath)) {
        writeFileSync(exitPath, String(typeof code === 'number' ? code : 1));
      }
    } catch { /* 落盘失败无补救，status 走 UNKNOWN 红 */ }
  });
}

// ps -o lstart= 同时充当存活与 pid 回收判据：输出非空且与 pid 文件记录一致 = 我们的子进程活着；
// 无输出（进程不存在）或 lstart 不符（pid 被系统复用）= 视为已退。
function psLstart(pid) {
  try {
    const out = execSync(`ps -o lstart= -p ${pid}`, {
      encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5000,
    }).trim();
    return out || null;
  } catch {
    return null;
  }
}

function readPidFile(pidPath) {
  try {
    const obj = JSON.parse(readFileSync(pidPath, 'utf-8'));
    return obj && typeof obj.pid === 'number' ? obj : null;
  } catch {
    return null;
  }
}

function pidFileAlive(pidFile) {
  if (!pidFile || !pidFile.lstart) return false;
  return psLstart(pidFile.pid) === pidFile.lstart;
}

// ── --background start：detached spawn 本脚本完整同步逻辑，秒级返回 ─────
function handleBackgroundStart(log) {
  const logAbs = resolve(log);
  const pidPath = `${logAbs}.pid`;
  const exitPath = `${logAbs}.exit`;
  const jsonPath = `${logAbs}.json`;
  mkdirSync(dirname(logAbs), { recursive: true });

  if (existsSync(pidPath)) {
    const pidFile = readPidFile(pidPath);
    if (pidFile && pidFileAlive(pidFile)) {
      // 真并发防重入：同 log 已有活跃后台任务 → 拒绝，指向既有 log 继续轮询
      console.log(JSON.stringify({
        ok: false, mode: 'background', state: 'RUNNING', pid: pidFile.pid, logPath: logAbs,
        error: '该 log 已有活跃后台任务，拒绝重复 start——对既有 log 继续 --background status 轮询',
      }, null, 2));
      process.exit(1);
    }
    // stale：进程已死或 pid 文件损坏 → 视为上次崩溃残留，覆盖启动（拒绝会让一次残留永久锁死 workspace）
    console.error(`[check-backend-test] pid 文件存在但进程已死或不可解析（${
      pidFile ? `pid=${pidFile.pid}` : '文件损坏'}），视为残留，覆盖启动`);
  }
  for (const p of [exitPath, jsonPath]) {
    try { rmSync(p); } catch { /* 不存在即跳过 */ }
  }

  // 'w' 截断打开（dual-review 2026-09-21 #4）：复用 log 路径时清掉上一轮输出，防 RUNNING 态
  // logTail/recentTestsRun 把上一轮的 Tests run:/emit JSON 当当前进度展示（陈旧证据展示）
  const out = openSync(logAbs, 'w');
  const child = spawn(process.execPath, [SCRIPT_PATH, '--internal-run', '--log', logAbs], {
    detached: true,
    stdio: ['ignore', out, out],
    env: process.env,
  });
  child.unref();
  // lstart 捕获重试（dual-review 2026-09-21 #5）：ps 瞬时失败会落 lstart=null → 活进程永远判死
  // （status 误报 UNKNOWN + 后续 start 走 stale 覆盖 = 双跑全量，绕过防重入）。重试后仍拿不到
  // 且子进程活着 → 杀掉本次子进程、start 失败退出（宁可重试不可双跑）；子进程已瞬退（秒级
  // emit 完成/崩溃）则 null 无害——status 走死路径按 exit/json 判 DONE/UNKNOWN。
  let lstart = null;
  for (let i = 0; i < 4 && !lstart; i++) {
    lstart = psLstart(child.pid);
    if (!lstart) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 300);
  }
  if (!lstart) {
    let alive = false;
    try { process.kill(child.pid, 0); alive = true; } catch { /* 已退出 */ }
    if (alive) {
      try { child.kill('SIGKILL'); } catch { /* 已退出 */ }
      closeSync(out);
      console.log(JSON.stringify({
        ok: false, mode: 'background',
        error: `无法捕获子进程 lstart（ps -o lstart 持续失败），已终止子进程 pid=${child.pid}，start 失败请重试`,
      }, null, 2));
      process.exit(1);
    }
  }
  writeFileSync(pidPath, JSON.stringify({
    pid: child.pid, lstart, startedAt: new Date().toISOString(),
  }, null, 2));
  closeSync(out);
  console.log(JSON.stringify({ ok: true, mode: 'background', pid: child.pid, logPath: logAbs }, null, 2));
  process.exit(0);
}

// ── --background status：RUNNING / DONE / UNKNOWN（红）三态轮询 ────────
// 退出码：RUNNING=0；DONE=<子进程真实退出码>；UNKNOWN=3（证据不可判必须当红，
// 禁静默跳过——knowledge verification-gate-unparseable-evidence-must-red-not-skip）。
function failStatusUnknown(reason) {
  console.log(JSON.stringify({ ok: false, mode: 'background', state: 'UNKNOWN', reason }, null, 2));
  process.exit(3);
}

function readLogTail(logAbs) {
  try {
    const lines = readFileSync(logAbs, 'utf-8').split('\n').filter(Boolean);
    return lines.slice(-30).join('\n');
  } catch {
    return '(log 文件不可读或不存在)';
  }
}

function readRecentTestsRun(logAbs) {
  try {
    const lines = readFileSync(logAbs, 'utf-8').split('\n');
    const hit = lines.filter((l) => /Tests run:/.test(l));
    return hit.length ? hit[hit.length - 1].trim() : null;
  } catch {
    return null;
  }
}

function handleBackgroundStatus(log) {
  const logAbs = resolve(log);
  const pidPath = `${logAbs}.pid`;
  const exitPath = `${logAbs}.exit`;
  const jsonPath = `${logAbs}.json`;

  if (!existsSync(pidPath)) failStatusUnknown(`pid 文件缺失（${pidPath}）——从未 start、log 路径不对或文件被删`);
  const pidFile = readPidFile(pidPath);
  if (!pidFile) failStatusUnknown(`pid 文件损坏（${pidPath}）——无法解析`);

  if (pidFileAlive(pidFile)) {
    console.log(JSON.stringify({
      ok: true, mode: 'background', state: 'RUNNING', pid: pidFile.pid, logPath: logAbs,
      recentTestsRun: readRecentTestsRun(logAbs), logTail: readLogTail(logAbs),
    }, null, 2));
    process.exit(0);
  }

  // 进程已退（或 pid 被复用 lstart 不符）：DONE 判据只依赖脚本自产文件，禁从 mvnd 输出反推
  if (!existsSync(exitPath)) {
    failStatusUnknown(`子进程已退但无 exit 文件（${exitPath}）——疑似 SIGKILL/崩溃没走到 emit，或 pid 被复用。证据不可判必须当红`);
  }
  const codeStr = readFileSync(exitPath, 'utf-8').trim();
  if (!/^\d+$/.test(codeStr)) {
    failStatusUnknown(`exit 文件内容不可解析（${codeStr.slice(0, 50)}）`);
  }
  if (!existsSync(jsonPath)) {
    failStatusUnknown(`exit 文件存在但 ${jsonPath} 缺失——emit JSON 未落盘，证据不完整`);
  }
  let payload;
  try {
    payload = JSON.parse(readFileSync(jsonPath, 'utf-8'));
  } catch {
    failStatusUnknown(`${jsonPath} 不可解析——exit 0 但证据不可判，必须当红`);
  }
  // DONE 幂等可重放：pid 文件保留（不清），再次 status 仍返回同一 DONE 结果
  console.log(JSON.stringify({
    mode: 'background', state: 'DONE', exitCode: Number(codeStr), logPath: logAbs, ...payload,
  }, null, 2));
  process.exit(Number(codeStr));
}

if (cli.kind === 'background') {
  if (cli.sub === 'start') handleBackgroundStart(cli.log);
  handleBackgroundStatus(cli.log);
}

const cwd = process.cwd();

// ── 自动解析项目所需 JDK 的 JAVA_HOME ──────────────────────────────────
// 从 plans 阶段确认的 tech-stack.json 读 Java 版本（权威来源）→ JAVA_XX_HOME 环境变量 → /usr/lib/jvm 扫描。
// 消除「agent 用 JDK21 修绿 → checker 用默认 JDK8 跑 mvn 报 UnsupportedClassVersionError」死锁。

function resolveJavaHome(backendDir) {
  let javaVersion = null;
  // 优先从 pom.xml <java.version> 读取（不再依赖 plans/tech-stack.json 路径解析）
  const pomPath = resolve(backendDir, 'pom.xml');
  if (existsSync(pomPath)) {
    try {
      const pom = readFileSync(pomPath, 'utf-8');
      // 归一在 shared/java-version.mjs 单点实现（1.8→8；旧 (\d+) 解析不到 "1.8" 致回退系统 JAVA_HOME）。
      javaVersion = parsePomJavaMajor(pom);
    } catch { /* ignore */ }
  }
  if (!javaVersion) return null;

  // 优先用环境变量（沙箱可能注入 JAVA_HOME / JAVA21_HOME / JAVA_21_HOME）
  const envCandidates = [
    process.env[`JAVA_${javaVersion}_HOME`],   // JAVA_21_HOME
    process.env[`JAVA${javaVersion}_HOME`],    // JAVA21_HOME（沙箱常见）
    process.env.JAVA_HOME,                      // 系统默认 JAVA_HOME（需验证版本匹配）
  ].filter(Boolean);
  for (const home of envCandidates) {
    if (!existsSync(resolve(home, 'bin', 'java'))) continue;
    // 验证大版本匹配（JAVA_HOME 可能指向错误版本如 Java 8）
    try {
      const verOut = execSync(`"${resolve(home, 'bin', 'java')}" -version 2>&1`, {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5000,
      });
      if (parseJavaVersionOutput(verOut) === javaVersion) return home;
    } catch {
      // 无法验证版本，跳过该候选
    }
  }

  // 扫描 /usr/lib/jvm/temurin-XX-jdk-current
  const jvmRoot = '/usr/lib/jvm';
  if (existsSync(jvmRoot)) {
    try {
      const dirs = readdirSync(jvmRoot);
      const found = dirs.find((n) => n.startsWith(`temurin-${javaVersion}`));
      if (found) return resolve(jvmRoot, found);
    } catch { /* ignore */ }
  }
  return null;
}

// emit 在 internal-run 模式下额外落 <log>.json（完整 emit JSON，status DONE 时原样回放给协调者）
// 与 <log>.exit（真实退出码）——子进程崩溃没走到 emit 时两文件皆缺，status 判 UNKNOWN 红。
function emit(ok, payload) {
  const json = JSON.stringify({ ok, ...payload }, null, 2);
  if (INTERNAL_LOG) {
    try {
      writeFileSync(`${INTERNAL_LOG}.json`, `${json}\n`);
      writeFileSync(`${INTERNAL_LOG}.exit`, String(ok ? 0 : 1));
    } catch (e) {
      console.error(`[check-backend-test] 后台产物落盘失败: ${e.message}`);
    }
  }
  console.log(json);
  process.exit(ok ? 0 : 1);
}

/** 读 `--backend-root`（可重复）/ `--active-spec-dir`；未知/缺值忽略。 */
function collectRootArgs(argv) {
  const explicitRoots = [];
  let activeSpecDir;
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === '--backend-root') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) explicitRoots.push(resolve(value));
    } else if (argv[i] === '--active-spec-dir') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) activeSpecDir = resolve(value);
    }
  }
  return { explicitRoots, activeSpecDir };
}

/** 单根直接采用；多根只认声明里本身是其余所有根祖先的聚合根，否则无法唯一确定（null）。 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/** 代码根定位（D5）：声明/显式根优先；findBackendDir 仅兜底并打 warning；歧义不猜。 */
function resolveBackendRoot() {
  const baseRoot = resolveProjectRoot(cwd) ?? cwd;
  const { explicitRoots, activeSpecDir } = collectRootArgs(process.argv.slice(2));
  // 未显式传 --active-spec-dir 时由最新 plans/backend 反推 active spec 目录，使工程方案声明生效。
  const planBackendDir = findPlanBackendDir(cwd);
  // planBackendDir = <activeSpecDir>/plans/backend ⇒ activeSpecDir 需再上溯一层（plans 的父目录）。
  const specDir = activeSpecDir ?? (planBackendDir ? dirname(dirname(planBackendDir)) : undefined);
  const declared = resolveDeclaredBackendRoots({ activeSpecDir: specDir, rootDir: baseRoot, explicitRoots });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[check-backend-test] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[check-backend-test] 代码根存在多个且无声明聚合根，无法唯一确定：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root，或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[check-backend-test] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(cwd);
  if (legacy) console.warn(`[check-backend-test] 未找到代码根声明，回落启发式 findBackendDir：${legacy}`);
  return legacy;
}

// 截断 surefire .txt 内容为精简摘要（砍框架栈 + 删超长无定位价值行 + 同根因去重）。
// 协调者读 failureDetails 摘要即可定位根因（方法名/异常/expected-was/业务栈行号），
// 摘要不够时再 cat 全量 .txt 兜底——避免全量堆栈（框架栈占 60-65%）灌进上下文。
// 经 build 213326 实测样本验证：Failure 9 行/方法、Error ~10 行/方法，同根因去重后大文件砍 79%+。
// 业务栈只有 com.company——只保留 at com.company 行，砍所有其他 at 行（java/org.*/com.mysql/com.zaxxer/jdk 等框架/驱动栈）。
const NOISE_STACK_RE = /^\s+at (?!com\.company[/.])/;
const DROP_LINE_RE = /^(### SQL:|### The error occurred while setting parameters)/;
const CAUSE_FINGERPRINT_RE = /^(### Cause:|Caused by:)\s*(.*)/;

function extractFailureDigest(content) {
  const lines = content.split('\n');
  // 切分为「失败方法块」：以方法名行（含 -- FAILURE!/ERROR!）为块起始边界
  // surefire .txt 结构：每个失败方法一段，段首是「类名.方法名 -- Time elapsed -- FAILURE!/ERROR!」
  const blocks = [];
  let cur = [];
  let sawHeader = false; // 跳过文件头的 Test set/分隔线/汇总行
  for (const line of lines) {
    if (/-- Time elapsed.*?(?:FAILURE!|ERROR!)/.test(line)) {
      if (cur.length) blocks.push(cur);
      cur = [line];
      sawHeader = true;
    } else if (sawHeader) {
      cur.push(line);
    }
  }
  if (cur.length) blocks.push(cur);

  // 逐块过滤 + 提取根因指纹
  const processed = blocks.map((blk) => {
    const kept = blk.filter((l) => !NOISE_STACK_RE.test(l) && !DROP_LINE_RE.test(l));
    // 根因指纹：取第一个 ### Cause: 或 Caused by: 行
    let fingerprint = null;
    for (const l of blk) {
      const m = l.match(CAUSE_FINGERPRINT_RE);
      if (m) { fingerprint = m[2].trim(); break; }
    }
    return { kept: kept.slice(0, 30), fingerprint };
  });

  // 同根因去重：指纹相同的后续块只保留方法名行 + （同根因）
  const seenFingerprints = new Set();
  const digests = [];
  for (const { kept, fingerprint } of processed) {
    const methodLine = kept[0] || '';
    if (fingerprint && seenFingerprints.has(fingerprint)) {
      digests.push(`${methodLine}\n  （同根因：${fingerprint.slice(0, 80)}）`);
    } else {
      if (fingerprint) seenFingerprints.add(fingerprint);
      digests.push(kept.join('\n'));
    }
  }
  return digests.join('\n\n');
}

// 1. 定位 backend 工程目录（声明根优先，findBackendDir 仅兜底）
const backendDir = resolveBackendRoot();

if (!backendDir) {
  emit(false, { failures: ['未找到后端工程（pom.xml / build.gradle）'] });
}
const javaHome = resolveJavaHome(backendDir);

// 2. 真跑一次全工程测试
const isMaven = existsSync(resolve(backendDir, 'pom.xml'));
let cmd;
let args;
if (isMaven) {
  cmd = existsSync(resolve(backendDir, 'mvnw')) ? resolve(backendDir, 'mvnw')
    : (() => { try { execSync('which mvnd', { stdio: 'ignore' }); return 'mvnd'; } catch { return 'mvn'; } })();
  // 不用 -q：-q 会吞掉 [ERROR]/BUILD FAILURE/Tests run 等输出，脚本靠 stdout 匹配编译错/
  // COMPILATION ERROR/Tests run 兜底/Skipped 四件事全失效，判绿只靠 surefire .txt。
  // mvn 退出码非0但 surefire 全绿时，-q 让脚本和协调者都看不见真实原因（build 171208 R4 卡死根因）。
  args = ['-B', 'test'];
} else {
  cmd = existsSync(resolve(backendDir, 'gradlew')) ? resolve(backendDir, 'gradlew') : 'gradle';
  args = ['test', '--console=plain'];
}

let run = spawnSync(cmd, args, {
  cwd: backendDir,
  encoding: 'utf-8',
  maxBuffer: 64 * 1024 * 1024,
  env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
});

// ── mvnd 崩溃退化到 mvn ──────────────────────────────────────────
// mvnd 因 /root/.m2/mvnd/registry 只读 mount 启动即崩（DaemonException: Read-only file system），
// 从未真正编译/测试；崩溃输出非 [ERROR]/BUILD FAILURE 格式，会读旧 surefire 报告产生假信号
// （退出码非0但 surefire 全绿）。识别到 mvnd 崩溃签名时，重跑一次标准 mvn，覆盖第一次结果。
// resolveJavaHome 已注入 JAVA_HOME=对应版本，fallback 的 mvn 同样用正确 JDK，文本块可正常解析。
const _firstOut = `${run.stdout || ''}\n${run.stderr || ''}`;
if (cmd === 'mvnd' && run.status !== 0
    && /Read-only file system|DaemonException/.test(_firstOut)) {
  run = spawnSync('mvn', args, {
    cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024,
    env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
  });
}

if (run.error) {
  emit(false, { failures: [`无法执行测试命令 ${cmd} ${args.join(' ')}：${run.error.message}`] });
}

const stdout = run.stdout || '';
const stderr = run.stderr || '';
const combined = `${stdout}\n${stderr}`;

// internal-run 模式：mvn 原始输出由管道捕获用于解析、RUNNING 期间不落 log（spawnSync 非流式，
// 进度只看 state 转移）；跑完后经自身 stdout fd 写入（与 emit JSON 同一 fd，dup 共享偏移、顺序
// 有序），使「完整测试输出落 log」承诺在 DONE 态成立，协调者/人可 cat log 看全量输出。
if (INTERNAL_LOG) {
  try { process.stdout.write(`\n--- 测试命令原始输出 ---\n${combined}\n`); } catch { /* 落盘失败不阻塞判绿 */ }
}

// 3. 编译错：[ERROR] .../Xxx.java:[line,col] ...
const compileErrorLines = combined.match(/\[ERROR\][^\n]*\.java[^\n]*/g) || [];

// 4. 读 surefire-reports/*.txt 汇总行算 totalFailures/totalErrors + 收集有失败的 .txt 文件名
//    文件名即测试类 FQN（<根包>.<域>.XxxServiceTest.txt）；不归桶——
//    对失败 .txt 调 extractFailureDigest 生成截断摘要（failureDetails），协调者优先读摘要，
//    摘要不够再 cat 全量 .txt 兜底。摘要只砍框架栈+删###SQL超长行+同根因去重，不域归桶不路径推断。
let sawSummary = false;
let totalFailures = 0;
let totalErrors = 0;
// 多模块 Maven reactor：surefire .txt 落在各子模块 target/surefire-reports/，根 target/（packaging=pom、无测试）没有。
// collectSurefireReportDirs 扫全模块（含根），合并所有目录的 .txt（文件名=测试类 FQN，跨模块去重）。
// 旧「只读根 target/surefire-reports」致多模块下失败 .txt 扫不到 → failureDetails/reportFiles 空、协调者无法按测试类切片派 subAgent。
const surefireDirs = collectSurefireReportDirs(backendDir);
const surefireDir = surefireDirs.length > 0 ? surefireDirs[0] : resolve(backendDir, 'target', 'surefire-reports');
let reportFiles = [];
for (const sfDir of surefireDirs) {
  let files;
  try {
    files = readdirSync(sfDir).filter((n) => n.endsWith('.txt') && !n.startsWith('TEST-'));
  } catch {
    continue;
  }
  for (const repFile of files) {
    if (!reportFiles.includes(repFile)) reportFiles.push(repFile); // 跨模块同名 FQN 去重（同 FQN 不应跨模块出现，保底去重）
  }
}

// 有失败的 .txt 文件名清单（供协调者直接 cat，不必扫描全目录）
// failureDetails：key=文件名，value=截断摘要（砍框架栈+删###SQL行+同根因去重），协调者优先读此摘要
const failingReportFiles = [];
const failureDetails = {};
for (const repFile of reportFiles) {
  // 同 FQN 去重后，在所有 surefireDirs 里找首个命中目录读内容
  let content;
  for (const sfDir of surefireDirs) {
    const repPath = resolve(sfDir, repFile);
    if (existsSync(repPath)) {
      try { content = readFileSync(repPath, 'utf-8'); } catch { continue; }
      break;
    }
  }
  if (content === undefined) continue;
  // 该类的汇总行（surefire .txt 末尾：Tests run: N, Failures: F, Errors: E, Skipped: S, ...）
  const sumM = content.match(/Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+)(?:,\s*Skipped:\s*(\d+))?/);
  if (sumM) {
    sawSummary = true;
    totalFailures += Number(sumM[2] || 0);
    totalErrors += Number(sumM[3] || 0);
  }
  const f = Number(sumM?.[2] || 0);
  const e = Number(sumM?.[3] || 0);
  if (f + e > 0) {
    failingReportFiles.push(repFile);
    failureDetails[repFile] = extractFailureDigest(content);
  }
}

// stdout 兜底：若全模块都没扫到 surefire .txt（测试未运行/报告未落盘），从 stdout 的 Tests run 汇总行兜底算计数
if (reportFiles.length === 0) {
  const sumRe = /Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+)(?:,\s*Skipped:\s*(\d+))?/g;
  let m;
  while ((m = sumRe.exec(combined)) !== null) {
    sawSummary = true;
    totalFailures += Number(m[2] || 0);
    totalErrors += Number(m[3] || 0);
  }
}

// ── 0 测试机械区分（plan 2026-09-13/build-stage3-unit-test-llm-verify-and-zero-test-pass）──────
// 统计全工程 src/test 下非空 *Test.java（空包目录不算——iot 0913 实证包目录齐全但 0 文件）。
// 递归全深度：collectModuleDirs 只到一级子模块，嵌套多级 Maven reactor 的测试会漏计、误走 0 测试
// 判过（dual-review 2026-09-13 #4——collectSurefireReportDirs 是递归的，计数侧必须同深度）。
// 0 测试 + 无编译错 + mvn 退出码 0 → 判过（emit noTests:true 留痕）：单测生成校验归段A兜底波（LLM），
// checker 不再以「未找到 Tests run 汇总行」反蒙混卡死（B1 只会修失败测试不会补缺失测试，0 测试时恒红死锁）。
// 有测试却没跑（testFileCount>0 且无报告无汇总行）仍判红——那是真异常，反蒙混语义保留。
function countTestFiles(backendDir) {
  let count = 0;
  const SKIP = new Set(['node_modules', '.git', 'target', 'build', 'dist']);
  const walk = (dir, segments) => {
    let entries;
    try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (SKIP.has(e.name)) continue;
      const p = resolve(dir, e.name);
      if (e.isDirectory()) { walk(p, [...segments, e.name]); continue; }
      if (!e.isFile() || !/Test\.java$/.test(e.name)) continue;
      const srcIdx = segments.indexOf('src');
      if (srcIdx === -1 || segments[srcIdx + 1] !== 'test') continue; // 只认 */src/test/ 下的
      try { if (statSync(p).size > 0) count += 1; } catch { /* ignore */ }
    }
  };
  walk(backendDir, []);
  return count;
}
const testFileCount = countTestFiles(backendDir);

const hasCompilationError = /COMPILATION ERROR/i.test(combined);
const hasTestFailure = totalFailures > 0 || totalErrors > 0;
const isFullyGreen = !hasCompilationError && !hasTestFailure && sawSummary && run.status === 0;
// 0 测试判过：无报告/无汇总行、无编译错、src/test 无非空 *Test.java、mvn 退出码 0。
// （有测试却没跑不在此列——testFileCount>0 时走原反蒙混红分支。）
const zeroTestsPass = !sawSummary && !hasCompilationError && testFileCount === 0 && run.status === 0;

// mvn 退出码非 0 时，抓 combined 末尾的 [ERROR]/BUILD FAILURE 段供协调者诊断
// （-q 已去掉，combined 含完整 mvn 输出；surefire 全绿但 mvn 退出码非 0 时，
//   协调者靠这段判断是 tests 外的构建问题还是 surefire 报告落盘不全）
function extractMvnFailureTail() {
  if (run.status === 0) return null;
  const lines = combined.split('\n');
  const errIdxs = lines.map((l, i) => /^\[ERROR\]/.test(l) || /BUILD FAILURE/.test(l) ? i : -1).filter((i) => i >= 0);
  if (errIdxs.length === 0) return null;
  const start = Math.max(0, errIdxs[0]);
  const end = Math.min(lines.length, errIdxs[errIdxs.length - 1] + 1);
  return lines.slice(start, end).join('\n').slice(0, 2000);
}
const mvnFailureTail = extractMvnFailureTail();

// @Disabled 蒙混防线（供人看，不单独判失败）
const skippedMatch = combined.match(/Tests run:\s*\d+,\s*Failures:\s*\d+,\s*Errors:\s*\d+,\s*Skipped:\s*(\d+)/);
const skippedWarning = skippedMatch && Number(skippedMatch[1]) > 0
  ? `⚠️ 检测到 Skipped=${skippedMatch[1]}：确认未用 @Disabled/注释规避失败测试`
  : null;

// 5. emit：全绿 exit 0，否则 exit 1 + 失败计数 + surefireDir + reportFiles
if (zeroTestsPass) {
  // 0 测试判过（非静默：noTests:true + summary 说明进协调者可见的 emit JSON，留痕可审计）。
  // 单测生产义务由段A硬自检 + 段AT兜底波（LLM）承接，checker 不再越权语义判断。
  emit(true, {
    summary: '本轮未运行任何单测（src/test 无测试文件）；单测生成校验归段A兜底波（LLM），此处不判红',
    noTests: true,
    mvnExitCode: run.status,
    surefireDir: existsSync(surefireDir) ? surefireDir : null,
    surefireDirs: surefireDirs.filter((d) => existsSync(d)),
    reportFiles: [],
  });
}
if (!isFullyGreen) {
  const failures = [];
  if (hasCompilationError) failures.push(`存在 COMPILATION ERROR（编译未通过）：${compileErrorLines.length} 行`);
  if (hasTestFailure) failures.push(`单测未全绿：Failures=${totalFailures}, Errors=${totalErrors}`);
  if (!sawSummary && !hasCompilationError) failures.push('未找到 "Tests run: ..." 汇总行——可能全部测试被跳过/未编译运行（防 @Disabled/skipTests 蒙混）');
  if (run.status !== 0 && failures.length === 0) {
    // surefire 全绿但 mvn 退出码非 0：附 mvn [ERROR]/BUILD FAILURE 尾部输出，让协调者看真实原因
    const tail = mvnFailureTail ? `\n--- mvn 输出尾部 ---\n${mvnFailureTail}` : '';
    if (surefireDirs.length === 0) {
      // 全模块都没扫到 surefire 报告 + mvn 非 0：疑似测试未运行/前阶段失败/报告未落盘——禁判绿（防多模块假绿）
      failures.push(`mvn/gradle test 退出码 ${run.status}（非 0），且全模块扫描未扫到任何 surefire 报告目录（多模块 reactor 报告应落子模块 target/surefire-reports/）。疑似测试未运行/编译前阶段失败/报告未落盘。看下方 mvnFailureTail 定位根因，禁直接判绿收尾。${tail}`);
    } else {
      // 已扫到 surefire 报告且全绿 + mvn 非 0：大概率 tests 外的构建问题，可判绿收尾
      failures.push(`mvn/gradle test 退出码 ${run.status}（非 0），但 surefire 全绿（Failures=0, Errors=0，已扫 ${surefireDirs.length} 个报告目录）。可能 tests 外的构建问题或 surefire 报告落盘不全。先看下方 mvnFailureTail 判断，若无真实测试问题则判绿收尾，不要继续派 subAgent 改 impl。${tail}`);
    }
  }
  if (skippedWarning) failures.push(skippedWarning);
  emit(false, {
    failures,
    summary: { totalFailures, totalErrors, compileErrors: compileErrorLines.length },
    mvnExitCode: run.status,
    surefireDir: existsSync(surefireDir) ? surefireDir : null,
    surefireDirs: surefireDirs.filter((d) => existsSync(d)),
    reportFiles: failingReportFiles,
    failureDetails,
    compileErrorLines: compileErrorLines.slice(0, 50),
    mvnFailureTail,
  });
}
emit(true, {
  summary: `所有实体单测通过（Failures=0, Errors=0）`,
  mvnExitCode: run.status,
  surefireDir: existsSync(surefireDir) ? surefireDir : null,
  surefireDirs: surefireDirs.filter((d) => existsSync(d)),
  reportFiles: [],
});
