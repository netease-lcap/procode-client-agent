#!/usr/bin/env node

/**
 * 1-1.1 存量事实基线校验器（JSON 契约 · 结构/字段/凭据规则）
 *
 * 职责：机械校验 plans 入口 LLM 产出的 `plans/backend/_meta/inventory-baseline.json`。
 *   只校验**代码钉死集**（栈无关）：通用信封字段与枚举、五域键、`ds:<name>` id 规则、
 *   stack 节比对键名表、evidence 字段形状与长度、凭据红线、degraded 分支。
 *   不读取源码、不定位工程根、不核验事实语义。证据真实性由扫描 agent 按规约负责。
 *   不读知识文档、不含任何栈专有逻辑——新栈注册 = 新文档，本脚本零改动。
 *   漏报（该列未列）无机械判据，不属本脚本职责（见 plan D8-3）。
 *
 * 失败消息三要素（防死循环主手段，95fd060da 教训：门要求 prompt 没教的东西必死循环）：
 *   每条错误 = 违例定位 + 期望 + 通过示例。
 *
 * 用法：
 *   node verify-inventory-baseline.mjs [--cwd <dir>] [--baseline <abs>]
 *   成功：exit 0，stdout 单行 JSON { ok, action, baseline, degraded, counts }
 *   失败：exit 1，stdout 多行人类可读错误清单（供 checker 原样回灌 agent）
 *
 * 详见 docs/hicode-spec/plan/2026-09-01/inventory-baseline-5-domain-expert-reuse.md（D1/D2/D3）
 */

import { existsSync, readdirSync, readFileSync } from 'fs';
import { resolve, isAbsolute } from 'path';
import { resolveProjectRoot } from './shared/backend-common.mjs';

// ─── 代码钉死集（栈无关常量，全链唯一硬编码；与知识文档 schema 围栏块一致，文档不得改信封）──
const TOP_KEYS = ['schemaVersion', 'generatedBy', 'generatedAt', 'degraded', 'stack', 'dataSources', 'domains', 'observedIdentity'];
const DOMAIN_KEYS = ['authz', 'security', 'integration', 'middleware', 'observability'];
const STATUS_ENUM = ['used', 'configured', 'declared'];
const STACK_KEYS = ['language', 'stackId', 'buildTool', 'runtime', 'framework', 'dataAccess', 'layout', 'chainSupported', 'evidence'];
// degraded=true 时 stack 节最小集（未注册栈的已定义态，不是错误；chainSupported 供下游能力边界裁决读取）
const STACK_MIN_KEYS = ['language', 'stackId', 'chainSupported'];
const GROUP_KEYS = ['name', 'version'];
const LAYOUT_KEYS = ['multiModule', 'modules', 'entryModule'];
const DS_KEYS = ['id', 'name', 'type', 'primary', 'evidence'];
const ITEM_KEYS = ['id', 'capability', 'status', 'evidence', 'summary'];
const EVIDENCE_KEYS = ['file', 'quote'];
const QUOTE_MAX = 200;
// observedIdentity（增量 micro P1）：存量真实服务身份，供架构 1a/2a 继承；可选块。
const OBSERVED_IDENTITY_KEYS = ['services'];
const OBSERVED_SERVICE_KEYS = ['serviceName', 'serviceType', 'sourceDir', 'buildUnits', 'port', 'evidence'];

// 凭据红线：键命中且值为非空字符串 → 违例；字符串值命中连接串/赋值形态（URL userinfo、password= 参数、
// `password: xxx` 行——含 evidence quote 里的原文）→ 违例。占位与掩码值（${ENV} / <your-password> /
// xxxx / *** / your_xxx）放行——红线禁的是明文值落盘，不是键名出现。错误回显只给键名/形态不给原值。
const CRED_KEY_RE = /(password|passwd|pwd|token|secret|credential|private[_-]?key|access[_-]?key|api[_-]?key|user[_-]?name)/i;
const CRED_VALUE_RES = [/\w+:\/\/[^/\s:@]+:[^/\s@]+@/, /[?&](password|passwd|pwd)=[^&\s]+/i];
const CRED_ASSIGN_RE = /(password|passwd|pwd|username|user_name|access[_-]?token|refresh[_-]?token|token|secret|credential|api[_-]?key|access[_-]?key|private[_-]?key)\s*[:=]\s*([^\s,;)"'&]{4,})/gi;
const CRED_MASK_RE = /^(?:x{3,}|\*+|<[^>]*>|\$\{[^}]*\}|#\{[^}]*\}|%\w|\{\{[^}]*\}\}|your[-_].*|\[[^\]]*\])$/i;

/** 字符串值是否含明文凭据；命中返回红acted 形态描述（绝不回显原值），否则 null。 */
function credValueHit(s) {
  if (CRED_VALUE_RES.some((re) => re.test(s))) return '连接串含 userinfo/密码参数';
  CRED_ASSIGN_RE.lastIndex = 0;
  let m;
  while ((m = CRED_ASSIGN_RE.exec(s)) !== null) {
    if (!CRED_MASK_RE.test(m[2])) return `${m[1]}=<明文值>`;
  }
  return null;
}

// ─── 通用工具 ───
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isNonEmptyStr = (v) => typeof v === 'string' && v.trim().length > 0;
const label = (v) => {
  if (typeof v === 'string') return v.length > 80 ? `${v.slice(0, 80)}…` : v;
  if (v === null) return 'null';
  if (Array.isArray(v)) return `Array(${v.length})`;
  if (typeof v === 'object') return `{${Object.keys(v).join(',')}}`;
  return String(v);
};

/** 违例定位 + 期望 + 通过示例（三要素）。 */
function push(errors, where, expect, example, got) {
  errors.push({ where, expect, example, got: got === undefined ? '' : label(got) });
}

// 通过示例（每条错误附带，确保 agent 无先验知识也能修对）
const EXAMPLE_EVIDENCE =
  'evidence 通过示例: [{"file":"pom.xml","quote":"<artifactId>spring-boot-starter-data-redis</artifactId>"}]（file=相对锚定根目录的路径；锚定根与所需前缀以本轮任务提示为准；quote=该文件内≤200字符逐字原文）';
const EXAMPLE_ITEM =
  '条目通过示例: {"id":"middleware:redis","capability":"Redis 缓存","status":"used","evidence":[{"file":"src/main/java/…/RedisService.java","quote":"@Autowired private RedisTemplate<String, Object> redisTemplate;"}],"summary":"存量已实装 RedisTemplate 封装"}';
const EXAMPLE_DS =
  '数据源通过示例: {"id":"ds:master","name":"master","type":"mysql","primary":true,"evidence":[{"file":"src/main/resources/application.yml","quote":"driver-class-name: com.mysql.cj.jdbc.Driver"}]}';
const EXAMPLE_FULL =
  '整文件通过示例(最小骨架): {"schemaVersion":1,"generatedBy":"plans/inventory-baseline","generatedAt":"2026-09-01T00:00:00Z","degraded":false,' +
  '"stack":{"language":"java","stackId":"java-spring-mybatis","buildTool":"maven","runtime":{"name":"jdk","version":"21"},' +
  '"framework":{"name":"spring-boot","version":"3.2.5"},"dataAccess":{"name":"mybatis-plus","version":null},' +
  '"layout":{"multiModule":false,"modules":[],"entryModule":null},"chainSupported":true,' +
  '"evidence":[{"file":"pom.xml","quote":"<artifactId>spring-boot-starter-web</artifactId>"}]},' +
  '"dataSources":[],"domains":{"authz":[],"security":[],"integration":[],"middleware":[],"observability":[]}}';

// ─── evidence JSON 字段校验 ───
/**
 * 校验一个 evidence 数组。
 * @param where   违例定位前缀（JSON 路径）
 * @param minOne  是否要求至少一条
 */
function checkEvidence(errors, where, ev, minOne) {
  const ex = (i) => `${where}#${i}`;
  if (!Array.isArray(ev)) {
    push(errors, where, minOne ? 'evidence 必须是数组且至少 1 条' : 'evidence 必须是数组', EXAMPLE_EVIDENCE, ev);
    return;
  }
  if (minOne && ev.length === 0) {
    push(errors, where, 'evidence 至少 1 条', EXAMPLE_EVIDENCE, ev);
    return;
  }
  ev.forEach((item, i) => {
    if (!isObj(item)) { push(errors, ex(i), 'evidence 项必须是对象', EXAMPLE_EVIDENCE, item); return; }
    const extra = Object.keys(item).filter((k) => !EVIDENCE_KEYS.includes(k));
    if (extra.length) push(errors, ex(i), `evidence 项只允许键 file/quote，发现多余键: ${extra.join(',')}`, EXAMPLE_EVIDENCE);
    const { file, quote } = item;
    if (!isNonEmptyStr(file)) { push(errors, `${ex(i)}.file`, 'file 为非空字符串，相对锚定根目录（不允许绝对路径与 ..）', EXAMPLE_EVIDENCE, file); return; }
    if (isAbsolute(file) || file.split('/').includes('..')) {
      push(errors, `${ex(i)}.file`, `file 必须是锚定根目录内相对路径: ${file}`, EXAMPLE_EVIDENCE); return;
    }
    if (!isNonEmptyStr(quote)) { push(errors, `${ex(i)}.quote`, `quote 为非空字符串: ${file}`, EXAMPLE_EVIDENCE, quote); return; }
    if (quote.length > QUOTE_MAX) {
      push(errors, `${ex(i)}.quote`, `quote ≤${QUOTE_MAX} 字符（当前 ${quote.length}）: ${file}`, EXAMPLE_EVIDENCE);
    }
  });
}

// ─── 凭据红线（全对象深扫：键命中 或 字符串值命中连接串/赋值形态；回显一律红acted）──
function checkNoCredentials(errors, node, pathStr) {
  if (typeof node === 'string') {
    const hit = credValueHit(node);
    if (hit) {
      push(errors, pathStr, '凭据红线：字符串值含明文凭据形态（' + hit + '），值不落盘——evidence 换用不含凭据的行（如 driver-class-name），只记 name/type/primary', '通过形态: {"file":"application.yml","quote":"driver-class-name: com.mysql.cj.jdbc.Driver"}；占位写法放行: ${DB_PASSWORD} / <your-password>');
    }
    return;
  }
  if (Array.isArray(node)) { node.forEach((v, i) => checkNoCredentials(errors, v, `${pathStr}[${i}]`)); return; }
  if (isObj(node)) {
    for (const [k, v] of Object.entries(node)) {
      const p = `${pathStr}.${k}`;
      if (CRED_KEY_RE.test(k) && typeof v === 'string' && v.trim() && !CRED_MASK_RE.test(v.trim())) {
        push(errors, p, `凭据红线：键 ${k} 的值不落盘（连接值只允许 name/type/primary；引用环境变量的占位写法放行）`, EXAMPLE_DS);
      }
      checkNoCredentials(errors, v, p);
    }
  }
}

/** observedIdentity 通过示例（增量 micro：存量真实服务身份）。 */
const EXAMPLE_OBSERVED_IDENTITY =
  'observedIdentity 通过示例: {"services":[{"serviceName":"ruoyi-system","serviceType":"backend",' +
  '"sourceDir":"backend/ruoyi-modules/ruoyi-system","buildUnits":["ruoyi-modules-system"],' +
  '"evidence":[{"file":"backend/ruoyi-modules/ruoyi-system/pom.xml","quote":"<artifactId>ruoyi-modules-system</artifactId>"}]}]}';

/**
 * observedIdentity 校验（可选块）：只校验字段形状、唯一性、相对路径字符串和 evidence 结构。
 */
function checkObservedIdentity(errors, obj) {
  if (obj.observedIdentity === undefined) return;
  const oi = obj.observedIdentity;
  if (!isObj(oi)) {
    push(errors, 'observedIdentity', 'observedIdentity 必须为对象', EXAMPLE_OBSERVED_IDENTITY, oi);
    return;
  }
  const extra = Object.keys(oi).filter((k) => !OBSERVED_IDENTITY_KEYS.includes(k));
  if (extra.length) {
    push(errors, 'observedIdentity', `只允许键 ${OBSERVED_IDENTITY_KEYS.join('/')}，发现多余键: ${extra.join(',')}`, EXAMPLE_OBSERVED_IDENTITY);
  }
  const services = oi.services;
  if (!Array.isArray(services)) {
    push(errors, 'observedIdentity.services', 'services 必须是数组（无服务清单时可缺省该块，不写空数组）', EXAMPLE_OBSERVED_IDENTITY, services);
    return;
  }
  const seen = new Set();
  services.forEach((s, i) => {
    const w = `observedIdentity.services[${i}]`;
    if (!isObj(s)) {
      push(errors, w, 'service 必须是对象', EXAMPLE_OBSERVED_IDENTITY, s);
      return;
    }
    const extraKeys = Object.keys(s).filter((k) => !OBSERVED_SERVICE_KEYS.includes(k));
    if (extraKeys.length) {
      push(errors, w, `只允许键 ${OBSERVED_SERVICE_KEYS.join('/')}，发现多余键: ${extraKeys.join(',')}`, EXAMPLE_OBSERVED_IDENTITY);
    }
    if (!isNonEmptyStr(s.serviceName)) {
      push(errors, `${w}.serviceName`, 'serviceName 为非空字符串（存量服务名原样）', EXAMPLE_OBSERVED_IDENTITY, s.serviceName);
    } else if (seen.has(s.serviceName)) {
      push(errors, `${w}.serviceName`, `serviceName 唯一，重复: ${s.serviceName}`, EXAMPLE_OBSERVED_IDENTITY, s.serviceName);
    } else {
      seen.add(s.serviceName);
    }
    if (s.serviceType !== 'backend' && s.serviceType !== 'frontend') {
      push(errors, `${w}.serviceType`, 'serviceType ∈ {backend|frontend}', EXAMPLE_OBSERVED_IDENTITY, s.serviceType);
    }
    if (!isNonEmptyStr(s.sourceDir)) {
      push(errors, `${w}.sourceDir`, 'sourceDir 为非空字符串', EXAMPLE_OBSERVED_IDENTITY, s.sourceDir);
    } else if (isAbsolute(s.sourceDir) || s.sourceDir.split('/').includes('..')) {
      push(errors, `${w}.sourceDir`, `sourceDir 必须是锚定根内相对路径: ${s.sourceDir}`, EXAMPLE_OBSERVED_IDENTITY);
    }
    if (s.buildUnits !== undefined && !Array.isArray(s.buildUnits)) {
      push(errors, `${w}.buildUnits`, 'buildUnits 必须是数组（构建单元名）', EXAMPLE_OBSERVED_IDENTITY, s.buildUnits);
    }
    if (s.port !== undefined && !(Number.isInteger(s.port) && s.port > 0 && s.port <= 65535)) {
      push(errors, `${w}.port`, 'port 若填写必须是 1..65535 的整数', EXAMPLE_OBSERVED_IDENTITY, s.port);
    }
    checkEvidence(errors, `${w}.evidence`, s.evidence, true);
  });
}

// ─── 主校验 ───
function verify(obj) {
  const degraded = isObj(obj) && obj.degraded === true;
  const errors = [];
  const seenIds = new Map();
  const uniq = (where, id) => {
    if (typeof id !== 'string' || !id) return;
    if (seenIds.has(id)) push(errors, where, `id 全局唯一，与 ${seenIds.get(id)} 重复`, EXAMPLE_ITEM, id);
    else seenIds.set(id, where);
  };

  // 顶层信封
  if (!isObj(obj)) {
    push(errors, '<root>', '基线必须为 JSON 对象', EXAMPLE_FULL, obj);
    return errors;
  }
  const topExtra = Object.keys(obj).filter((k) => !TOP_KEYS.includes(k));
  if (topExtra.length) push(errors, '<root>', `只允许键 ${TOP_KEYS.join('/')}，发现多余键: ${topExtra.join(',')}。栈专有事实进 stack/domains 的 summary 文字，不加新顶层键`, EXAMPLE_FULL);
  if (obj.schemaVersion !== 1) push(errors, 'schemaVersion', 'schemaVersion 恒为数字 1', EXAMPLE_FULL, obj.schemaVersion);
  if (!isNonEmptyStr(obj.generatedBy)) push(errors, 'generatedBy', 'generatedBy 为非空字符串', EXAMPLE_FULL, obj.generatedBy);
  if (!isNonEmptyStr(obj.generatedAt)) push(errors, 'generatedAt', 'generatedAt 为非空字符串（ISO 时间）', EXAMPLE_FULL, obj.generatedAt);
  if (typeof obj.degraded !== 'boolean') push(errors, 'degraded', 'degraded 为布尔（知识库无本栈规程时 true，是已定义态不是错误）', EXAMPLE_FULL, obj.degraded);

  // stack 节（键名表代码钉死；取值规程在知识文档。degraded 只要最小集，已给字段仍按信封校验）
  const stack = obj.stack;
  if (!isObj(stack)) {
    push(errors, 'stack', 'stack 必须为对象', EXAMPLE_FULL, stack);
  } else {
    const stackExtra = Object.keys(stack).filter((k) => !STACK_KEYS.includes(k));
    if (stackExtra.length) push(errors, 'stack', `stack 只允许键 ${STACK_KEYS.join('/')}，发现多余键: ${stackExtra.join(',')}。未注册栈的专有事实写进条目 summary/evidence，不加新键`, EXAMPLE_FULL);
    const required = degraded ? STACK_MIN_KEYS : STACK_KEYS;
    for (const k of required) if (!(k in stack)) push(errors, `stack.${k}`, `stack 缺少必需键 ${k}（degraded=${degraded} 的必需集: ${required.join('/')}）`, EXAMPLE_FULL);
    for (const k of ['language', 'stackId', 'buildTool']) {
      if (k in stack && !isNonEmptyStr(stack[k])) push(errors, `stack.${k}`, `${k} 为非空字符串（language 取小写基础 token，如 "java"）`, EXAMPLE_FULL, stack[k]);
    }
    for (const g of ['runtime', 'framework', 'dataAccess']) {
      if (!(g in stack)) continue;
      const node = stack[g];
      if (!isObj(node)) { push(errors, `stack.${g}`, `${g} 为 {name, version} 对象（version 未知用 null）`, '"framework":{"name":"spring-boot","version":"3.2.5"}', node); continue; }
      const gExtra = Object.keys(node).filter((k) => !GROUP_KEYS.includes(k));
      if (gExtra.length) push(errors, `stack.${g}`, `只允许键 name/version，发现: ${gExtra.join(',')}`, '"dataAccess":{"name":"mybatis-plus","version":null}');
      if (!isNonEmptyStr(node.name)) push(errors, `stack.${g}.name`, 'name 为非空字符串', '"runtime":{"name":"jdk","version":"21"}', node.name);
      if ('version' in node && node.version !== null && !isNonEmptyStr(node.version) && typeof node.version !== 'number') {
        push(errors, `stack.${g}.version`, 'version 为字符串或 null', '"framework":{"name":"spring-boot","version":"3.2.5"}', node.version);
      }
    }
    if ('layout' in stack) {
      const layout = stack.layout;
      if (!isObj(layout)) push(errors, 'stack.layout', 'layout 为 {multiModule, modules, entryModule} 对象', '"layout":{"multiModule":true,"modules":["app-core","app-admin"],"entryModule":"app-admin"}', layout);
      else {
        const lExtra = Object.keys(layout).filter((k) => !LAYOUT_KEYS.includes(k));
        if (lExtra.length) push(errors, 'stack.layout', `只允许键 ${LAYOUT_KEYS.join('/')}，发现: ${lExtra.join(',')}`);
        if ('multiModule' in layout && typeof layout.multiModule !== 'boolean') push(errors, 'stack.layout.multiModule', 'multiModule 为布尔', '"layout":{"multiModule":false,"modules":[],"entryModule":null}', layout.multiModule);
        if ('modules' in layout && (!Array.isArray(layout.modules) || layout.modules.some((m) => !isNonEmptyStr(m)))) push(errors, 'stack.layout.modules', 'modules 为字符串数组（可空数组）', '"layout":{"multiModule":false,"modules":[],"entryModule":null}', layout.modules);
        if ('entryModule' in layout && layout.entryModule !== null && !isNonEmptyStr(layout.entryModule)) push(errors, 'stack.layout.entryModule', 'entryModule 为字符串或 null', '"layout":{"multiModule":true,"modules":["app-admin"],"entryModule":"app-admin"}', layout.entryModule);
      }
    }
    if ('chainSupported' in stack && typeof stack.chainSupported !== 'boolean') push(errors, 'stack.chainSupported', 'chainSupported 为布尔（false=超出生成链能力边界，下游强制人裁决）', '"chainSupported":true', stack.chainSupported);
    if ('evidence' in stack) checkEvidence(errors, 'stack.evidence', stack.evidence, true);
  }

  // dataSources（比对键名表钉 name/type；连接值不落盘）
  if (!Array.isArray(obj.dataSources)) {
    push(errors, 'dataSources', 'dataSources 必须为数组（无数据源时为空数组）', EXAMPLE_DS, obj.dataSources);
  } else {
    const names = new Set();
    obj.dataSources.forEach((ds, i) => {
      const w = `dataSources[${i}]`;
      if (!isObj(ds)) { push(errors, w, '数据源项必须是对象', EXAMPLE_DS, ds); return; }
      const extra = Object.keys(ds).filter((k) => !DS_KEYS.includes(k));
      if (extra.length) push(errors, w, `数据源只允许键 ${DS_KEYS.join('/')}（url/host/port/username 等连接值不落盘），发现: ${extra.join(',')}`, EXAMPLE_DS);
      if (!isNonEmptyStr(ds.name)) push(errors, `${w}.name`, 'name 为非空字符串', EXAMPLE_DS, ds.name);
      else {
        if (names.has(ds.name)) push(errors, `${w}.name`, `数据源 name 唯一，已存在: ${ds.name}`, EXAMPLE_DS);
        names.add(ds.name);
        if (ds.id !== `ds:${ds.name}`) push(errors, `${w}.id`, `id 恒为 "ds:" + name（当前 name=${ds.name}）`, EXAMPLE_DS, ds.id);
      }
      if (!isNonEmptyStr(ds.type)) push(errors, `${w}.type`, 'type 为非空字符串（如 mysql/redis，取 driver 基础名，不含连接信息）', EXAMPLE_DS, ds.type);
      if (typeof ds.primary !== 'boolean') push(errors, `${w}.primary`, 'primary 为布尔（整个数组至多一个 true）', EXAMPLE_DS, ds.primary);
      checkEvidence(errors, `${w}.evidence`, ds.evidence, true);
      uniq(w, ds.id);
    });
    const primaries = obj.dataSources.filter((d) => isObj(d) && d.primary === true).length;
    if (primaries > 1) push(errors, 'dataSources', `primary=true 至多一个，当前 ${primaries} 个`, EXAMPLE_DS);
  }

  // domains 五域（degraded=true 允许子集，未知键两态皆红）
  const domains = obj.domains;
  if (!isObj(domains)) {
    push(errors, 'domains', `domains 必须为对象（${DOMAIN_KEYS.join('/')}）`, EXAMPLE_ITEM, domains);
  } else {
    const dExtra = Object.keys(domains).filter((k) => !DOMAIN_KEYS.includes(k));
    if (dExtra.length) push(errors, 'domains', `domains 只允许五域键 ${DOMAIN_KEYS.join('/')}，发现: ${dExtra.join(',')}（新域须改本校验器，属独立 plan）`, EXAMPLE_ITEM);
    if (!degraded) {
      for (const k of DOMAIN_KEYS) if (!(k in domains)) push(errors, `domains.${k}`, `degraded=false 时五域键必须齐全（本域无存量也要给空数组 ${k}:[]）`, EXAMPLE_ITEM);
    }
    for (const [k, arr] of Object.entries(domains)) {
      if (!DOMAIN_KEYS.includes(k)) continue;
      if (!Array.isArray(arr)) { push(errors, `domains.${k}`, '每域必须为条目数组（可空）', EXAMPLE_ITEM, arr); continue; }
      arr.forEach((item, i) => {
        const w = `domains.${k}[${i}]`;
        if (!isObj(item)) { push(errors, w, '条目必须是对象', EXAMPLE_ITEM, item); return; }
        const extra = Object.keys(item).filter((kk) => !ITEM_KEYS.includes(kk));
        if (extra.length) push(errors, w, `条目只允许键 ${ITEM_KEYS.join('/')}，发现: ${extra.join(',')}`, EXAMPLE_ITEM);
        if (typeof item.id !== 'string' || !new RegExp(`^${k}:[a-z0-9][a-z0-9._-]*$`).test(item.id)) {
          push(errors, `${w}.id`, `id 形如 "${k}:<slug>"，slug 为小写字母数字开头、可含 . _ -（如 ${k}:redis）`, EXAMPLE_ITEM, item.id);
        }
        if (!isNonEmptyStr(item.capability)) push(errors, `${w}.capability`, 'capability 为非空字符串（一句话能力名）', EXAMPLE_ITEM, item.capability);
        if (!STATUS_ENUM.includes(item.status)) push(errors, `${w}.status`, `status ∈ {${STATUS_ENUM.join('|')}}（used=源码有锚点 / configured=配置有块无代码 / declared=仅构建清单）`, EXAMPLE_ITEM, item.status);
        if (!isNonEmptyStr(item.summary)) push(errors, `${w}.summary`, 'summary 为非空字符串', EXAMPLE_ITEM, item.summary);
        checkEvidence(errors, `${w}.evidence`, item.evidence, true);
        uniq(w, item.id);
      });
    }
  }

  // observedIdentity（可选；增量 micro P1 的存量真实服务身份）
  checkObservedIdentity(errors, obj);

  // 凭据红线（深扫全对象：类凭据键的值不落盘 + 连接串 userinfo/password= 形态）
  checkNoCredentials(errors, obj, '$');

  // 汇总输出用计数
  const counts = {
    dataSources: Array.isArray(obj.dataSources) ? obj.dataSources.length : null,
    services:
      isObj(obj.observedIdentity) && Array.isArray(obj.observedIdentity.services)
        ? obj.observedIdentity.services.length
        : null,
    domains: isObj(domains)
      ? Object.fromEntries(DOMAIN_KEYS.map((k) => [k, Array.isArray(domains[k]) ? domains[k].length : null]))
      : null,
  };
  return { errors, counts };
}

// ─── 基线产物定位（只查 docs/plans，不查源码目录）──
// 项目根由共享 resolveProjectRoot 上溯定位（唯一实现）；docs 根仍按 appName-aware 平铺/嵌套候选。
function findDocsRoot() {
  const cwd = process.env.PROJECT_CWD || process.cwd();
  const projectRoot = resolveProjectRoot(cwd);
  if (!projectRoot) return null;
  const appName = process.env.APP_NAME || process.env.APP_ID || 'project';
  for (const candidate of [resolve(projectRoot, appName, 'docs'), resolve(projectRoot, 'docs')]) {
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

/** 列 docs 下含 plans/ 的 run 目录（时间戳名 = 时序，取最新）。入口先于 outline，故只要求 plans/。 */
function listRunDirs(docsRoot) {
  try {
    return readdirSync(docsRoot)
      .filter((n) => !n.startsWith('.') && existsSync(resolve(docsRoot, n, 'plans')))
      .sort();
  } catch {
    return [];
  }
}

function main() {
  const argv = process.argv.slice(2);
  const opts = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--cwd') process.chdir(argv[++i]);
    else if (argv[i] === '--baseline') opts.baseline = argv[++i];
    // 兼容旧平台调用：消费旧参数但不读取源码，允许新脚本接受旧平台的调用参数。
    else if (argv[i] === '--backend-root') i++;
  }

  // 定位基线文件
  let baselinePath = opts.baseline;
  if (!baselinePath) {
    const docsRoot = findDocsRoot();
    if (!docsRoot) return fatal('无法定位 docs 根（尝试 <cwd>/<APP_NAME>/docs 与 <cwd>/docs 均不存在）。用 --baseline <绝对路径> 显式指定。');
    const runs = listRunDirs(docsRoot);
    if (!runs.length) return fatal(`docs 根 ${docsRoot} 下无含 plans/ 的 run 目录。`);
    baselinePath = resolve(docsRoot, runs[runs.length - 1], 'plans', 'backend', '_meta', 'inventory-baseline.json');
  }

  if (!existsSync(baselinePath)) {
    return fatal(`基线文件不存在: ${baselinePath}。期望：先按知识文档规程扫描存量代码并写入该文件（仅此一个产物），再重试。${EXAMPLE_FULL}`);
  }
  let obj;
  try {
    obj = JSON.parse(readFileSync(baselinePath, 'utf-8'));
  } catch (e) {
    return fatal(`基线文件 JSON 解析失败: ${baselinePath} — ${e && e.message}。${EXAMPLE_FULL}`);
  }
  const degraded = isObj(obj) && obj.degraded === true;
  const result = verify(obj);
  const errors = Array.isArray(result) ? result : result.errors;

  if (errors.length === 0) {
    process.stdout.write(JSON.stringify({
      ok: true,
      action: 'verified',
      baseline: baselinePath,
      degraded,
      counts: result.counts,
    }) + '\n');
    return;
  }

  const lines = [
    `inventory-baseline 校验失败（${errors.length} 处，文件: ${baselinePath}）。`,
    '修复方式：只重写该 JSON 文件本身（其余文件不动），按字段契约修正后自动重跑校验；事实与引用真实性由扫描 agent 自检。',
    '',
  ];
  errors.forEach((e, i) => {
    lines.push(`[${i + 1}] 违例 ${e.where}${e.got ? ` = ${e.got}` : ''}`);
    lines.push(`    期望: ${e.expect}`);
    lines.push(`    ${e.example}`);
  });
  process.stdout.write(lines.join('\n') + '\n');
  process.exit(1);
}

function fatal(message) {
  process.stdout.write([`inventory-baseline 校验失败（定位错误）: ${message}`, '', `  ${EXAMPLE_FULL}`].join('\n') + '\n');
  process.exit(1);
}

main();
