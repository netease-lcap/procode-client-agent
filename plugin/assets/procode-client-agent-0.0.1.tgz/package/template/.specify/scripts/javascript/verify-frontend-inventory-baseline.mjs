#!/usr/bin/env node

/**
 * 1-1.1 前端存量事实基线校验器（零栈知识 · 形状/锚点/凭据红线/底座在场）
 *
 * 职责：机械校验 plans 入口 LLM 产出的 `plans/frontend/_meta/inventory-baseline.json`。
 *   只校验**代码钉死集**（栈无关）：通用信封字段与枚举、stack 五维键、entrypoints 键与 kind 枚举、
 *   structure 键、evidence 逐条 quote-grep（空白归一化）、entrypoint 文件在场性（build 前端底座
 *   「先校验再复用」红线的数据源）、凭据红线、degraded 分支。
 *   不读知识文档、不含任何栈专有逻辑。漏报（该列未列）无机械判据，不属本脚本职责。
 *
 * 失败消息三要素（防死循环主手段，同 verify-inventory-baseline.mjs 95fd060da 教训）：
 *   每条错误 = 违例定位 + 期望 + 通过示例。
 *
 * 用法：
 *   node verify-frontend-inventory-baseline.mjs [--cwd <dir>] [--baseline <abs>]
 *        [--frontend-root <abs> | --no-frontend-root [--prototype-root <abs>]]
 *   成功：exit 0，stdout 单行 JSON { ok, action, baseline, frontendRoot, degraded, counts }
 *   失败：exit 1，stdout 多行人类可读错误清单（供 checker 原样回灌 agent）
 *
 *   前端根定位的**唯一判据方是编排侧**（tasks.ts 的 findFrontendRoot，消费
 *   resolveInitializedRootNames 的规范名）：命中则传 --frontend-root，判定为不存在则传
 *   --no-frontend-root（并尽可能带 --prototype-root 说明为何被拒）。
 *   本脚本的 findFrontendRoot 只在**手工直跑且未传 --baseline** 时兜底，不参与生产判定
 *   （plan 2026-09-17/scenario-docs-signal-and-frontend-root-convention-fix S2：两份同名 finder
 *   漂移是 0917 事故温床，收敛为单一判据方）。
 *
 * 详见 docs/hicode-spec/plan/2026-09-14/frontend-existing-baseline-fidelity-gate.md（S1）
 * 与 docs/hicode-spec/plan/2026-09-17/scenario-docs-signal-and-frontend-root-convention-fix.md（S2）
 */

import { existsSync, readdirSync, readFileSync } from 'fs';
import { resolve, dirname, join, isAbsolute } from 'path';

// ─── 代码钉死集（栈无关常量，全链唯一硬编码；与知识文档 schema 围栏块一致，文档不得改信封）──
const TOP_KEYS = ['schemaVersion', 'generatedBy', 'generatedAt', 'degraded', 'appRoot', 'dependencies', 'stack', 'entrypoints', 'structure'];
const STACK_KEYS = ['runtime', 'buildTool', 'language', 'framework', 'componentLibrary', 'chainSupported', 'evidence'];
// degraded=true 时 stack 节最小集（前端目录缺失/非 package.json 工程的已定义态，不是错误）
const STACK_MIN_KEYS = ['language', 'chainSupported'];
const GROUP_KEYS = ['name', 'version'];
const ENTRYPOINT_KEYS = ['path', 'kind', 'references', 'evidence'];
const ENTRY_KINDS = ['package-manifest', 'entry-html', 'entry-script', 'build-config', 'router', 'state', 'api-client', 'app-root'];
const STRUCTURE_KEYS = ['pages', 'components', 'router', 'state', 'api', 'styles', 'notes'];
const PAGE_KEYS = ['path', 'name', 'status', 'evidence'];
const ROUTER_KEYS = ['mode', 'paths', 'evidence'];
const ROUTER_MODES = ['hash', 'history', 'none'];
const APPROACH_KEYS = ['approach', 'evidence'];
const API_KEYS = ['approach', 'baseUrls', 'evidence'];
const STYLES_KEYS = ['approach', 'entry', 'evidence'];
const EVIDENCE_KEYS = ['file', 'quote'];
const QUOTE_MAX = 200;

// 凭据红线（同 verify-inventory-baseline.mjs：键命中或字符串值命中连接串/赋值形态即违例；掩码/占位放行）
const CRED_KEY_RE = /(password|passwd|pwd|token|secret|credential|private[_-]?key|access[_-]?key|api[_-]?key|user[_-]?name)/i;
const CRED_VALUE_RES = [/\w+:\/\/[^/\s:@]+:[^/\s@]+@/, /[?&](password|passwd|pwd)=[^&\s]+/i];
const CRED_ASSIGN_RE = /(password|passwd|pwd|username|user_name|access[_-]?token|refresh[_-]?token|token|secret|credential|api[_-]?key|access[_-]?key|private[_-]?key)\s*[:=]\s*([^\s,;)"'&]{4,})/gi;
const CRED_MASK_RE = /^(?:x{3,}|\*+|<[^>]*>|\$\{[^}]*\}|#\{[^}]*\}|%\w|\{\{[^}]*\}\}|your[-_].*|\[[^\]]*\])$/i;

/** 字符串值是否含明文凭据；命中返回红acted 形态描述（绝不回显原值），否则 null。 */
function credValueHit(s) {
  if (CRED_VALUE_RES.some((re) => re.test(s))) return '连接串含 userinfo/密码参数';
  CRED_ASSIGN_RE.lastIndex = 0;
  let m;
  while ((m = CRED_ASSIGN_RE.exec(s)) !== null) {
    if (!CRED_MASK_RE.test(m[2])) return `${m[1]}=<明文值>`;
  }
  return null;
}

// ─── 通用工具 ───
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isNonEmptyStr = (v) => typeof v === 'string' && v.trim().length > 0;
const norm = (s) => String(s).replace(/\s+/g, ' ').trim();
const label = (v) => {
  if (typeof v === 'string') return v.length > 80 ? `${v.slice(0, 80)}…` : v;
  if (v === null) return 'null';
  if (Array.isArray(v)) return `Array(${v.length})`;
  if (typeof v === 'object') return `{${Object.keys(v).join(',')}}`;
  return String(v);
};

/** 违例定位 + 期望 + 通过示例（三要素）。 */
function push(errors, where, expect, example, got) {
  errors.push({ where, expect, example, got: got === undefined ? '' : label(got) });
}

// 通过示例（每条错误附带，确保 agent 无先验知识也能修对）
const EXAMPLE_EVIDENCE =
  'evidence 通过示例: [{"file":"package.json","quote":"\\"vue\\": \\"^3.4.31\\""}]（file=相对前端根目录路径；quote=该文件内≤200字符逐字原文）';
const EXAMPLE_EP =
  'entrypoint 通过示例: {"path":"index.html","kind":"entry-html","references":"/src/main.js","evidence":[{"file":"index.html","quote":"<script type=\\"module\\" src=\\"/src/main.js\\">"}]}';
const EXAMPLE_PAGE =
  '页面通过示例: {"path":"src/views/Login.vue","name":"登录","status":"used","evidence":[{"file":"src/router.js","quote":"component: Login"}]}';
const EXAMPLE_FULL =
  '整文件通过示例(最小骨架): {"schemaVersion":1,"generatedBy":"plans/inventory-baseline (LLM, doc-guided)","generatedAt":"2026-09-14T00:00:00Z","degraded":false,' +
  '"appRoot":"myapp-frontend",' +
  '"dependencies":{"dependencies":{"vue":"^3.4.31"},"devDependencies":{"vite":"^5.3.4"}},' +
  '"stack":{"runtime":{"name":"Node.js","version":"20"},"buildTool":{"name":"vite","version":"5.3.4"},"language":"javascript",' +
  '"framework":{"name":"vue","version":"3.4.31"},"componentLibrary":{"name":"element-plus","version":"2.7.5"},"chainSupported":true,' +
  '"evidence":[{"file":"package.json","quote":"\\"vite\\": \\"^5.3.4\\""}]},' +
  '"entrypoints":[{"path":"package.json","kind":"package-manifest","references":null,"evidence":[{"file":"package.json","quote":"\\"name\\""}]},' +
  '{"path":"index.html","kind":"entry-html","references":"/src/main.js","evidence":[{"file":"index.html","quote":"src=\\"/src/main.js\\""}]},' +
  '{"path":"src/main.js","kind":"entry-script","references":null,"evidence":[{"file":"src/main.js","quote":"createApp"}]}],' +
  '"structure":{"pages":[],"components":[],"router":{"mode":"history","paths":[],"evidence":[]},"state":{"approach":"none","evidence":[]},' +
  '"api":{"approach":"fetch","baseUrls":[],"evidence":[]},"styles":{"approach":"css","entry":null,"evidence":[]},"notes":[]}}';

// ─── evidence 校验（锚点存在性 + quote 逐字 grep，空白归一化）──
function makeFileReader(frontendRoot) {
  const cache = new Map();
  return (rel) => {
    if (cache.has(rel)) return cache.get(rel);
    let content = null;
    try {
      const abs = join(frontendRoot, rel);
      if (frontendRoot && existsSync(abs)) content = readFileSync(abs, 'utf-8');
    } catch { /* 读失败视为不存在 */ }
    cache.set(rel, content);
    return content;
  };
}

/**
 * 校验一个 evidence 数组。
 * @param where   违例定位前缀（JSON 路径）
 * @param minOne  是否要求至少一条
 */
function checkEvidence(errors, read, where, ev, minOne) {
  const ex = (i) => `${where}#${i}`;
  if (!Array.isArray(ev)) {
    push(errors, where, minOne ? 'evidence 必须是数组且至少 1 条' : 'evidence 必须是数组', EXAMPLE_EVIDENCE, ev);
    return;
  }
  if (minOne && ev.length === 0) {
    push(errors, where, 'evidence 至少 1 条（每条断言都必须可锚定到存量代码原文）', EXAMPLE_EVIDENCE, ev);
    return;
  }
  ev.forEach((item, i) => {
    if (!isObj(item)) { push(errors, ex(i), 'evidence 项必须是对象', EXAMPLE_EVIDENCE, item); return; }
    const extra = Object.keys(item).filter((k) => !EVIDENCE_KEYS.includes(k));
    if (extra.length) push(errors, ex(i), `evidence 项只允许键 file/quote，发现多余键: ${extra.join(',')}`, EXAMPLE_EVIDENCE);
    const { file, quote } = item;
    if (!isNonEmptyStr(file)) { push(errors, `${ex(i)}.file`, 'file 为非空字符串，相对前端根目录（不允许绝对路径与 ..）', EXAMPLE_EVIDENCE, file); return; }
    if (isAbsolute(file) || file.split('/').includes('..')) {
      push(errors, `${ex(i)}.file`, `file 必须是前端根目录内相对路径: ${file}`, EXAMPLE_EVIDENCE); return;
    }
    if (!isNonEmptyStr(quote)) { push(errors, `${ex(i)}.quote`, `quote 为非空字符串（文件内逐字原文）: ${file}`, EXAMPLE_EVIDENCE, quote); return; }
    if (quote.length > QUOTE_MAX) {
      push(errors, `${ex(i)}.quote`, `quote ≤${QUOTE_MAX} 字符（当前 ${quote.length}）: ${file}`, EXAMPLE_EVIDENCE);
    }
    const content = read(file);
    if (content === null) {
      push(errors, `${ex(i)}.file`, `evidence 锚定文件不存在（相对前端根目录）: ${file}`, EXAMPLE_EVIDENCE); return;
    }
    if (!norm(content).includes(norm(quote))) {
      push(errors, `${ex(i)}.quote`,
        `quote 在 ${file} 中未逐字命中（校验只做空白归一化，其余必须原文一致；不得改写/拼接/加删空格之外的字符）`,
        EXAMPLE_EVIDENCE);
    }
  });
}

// ─── 凭据红线（全对象深扫：键命中 或 字符串值命中连接串/赋值形态；回显一律红acted）──
function checkNoCredentials(errors, node, pathStr) {
  if (typeof node === 'string') {
    const hit = credValueHit(node);
    if (hit) {
      push(errors, pathStr, '凭据红线：字符串值含明文凭据形态（' + hit + '），值不落盘——evidence 换用不含凭据的行，只记 approach/name/version', '占位写法放行: ${ENV_PASSWORD} / <your-password>');
    }
    return;
  }
  if (Array.isArray(node)) { node.forEach((v, i) => checkNoCredentials(errors, v, `${pathStr}[${i}]`)); return; }
  if (isObj(node)) {
    for (const [k, v] of Object.entries(node)) {
      const p = `${pathStr}.${k}`;
      if (CRED_KEY_RE.test(k) && typeof v === 'string' && v.trim() && !CRED_MASK_RE.test(v.trim())) {
        push(errors, p, `凭据红线：键 ${k} 的值不落盘（只记 approach/name/version 等形态字段），占位写法放行`);
      }
      checkNoCredentials(errors, v, p);
    }
  }
}

// ─── 主校验 ───
function verify(obj, ctx) {
  const { read, frontendRoot, degraded, baselinePath } = ctx;
  const errors = [];

  // 顶层信封
  if (!isObj(obj)) {
    push(errors, '<root>', '基线必须为 JSON 对象', EXAMPLE_FULL, obj);
    return { errors, counts: {} };
  }
  const topExtra = Object.keys(obj).filter((k) => !TOP_KEYS.includes(k));
  if (topExtra.length) push(errors, '<root>', `只允许键 ${TOP_KEYS.join('/')}，发现多余键: ${topExtra.join(',')}。栈专有事实进 structure.notes，不加新顶层键`, EXAMPLE_FULL);
  if (obj.schemaVersion !== 1) push(errors, 'schemaVersion', 'schemaVersion 恒为数字 1', EXAMPLE_FULL, obj.schemaVersion);
  if (!isNonEmptyStr(obj.generatedBy)) push(errors, 'generatedBy', 'generatedBy 为非空字符串', EXAMPLE_FULL, obj.generatedBy);
  if (!isNonEmptyStr(obj.generatedAt)) push(errors, 'generatedAt', 'generatedAt 为非空字符串（ISO 时间）', EXAMPLE_FULL, obj.generatedAt);
  if (typeof obj.degraded !== 'boolean') push(errors, 'degraded', 'degraded 为布尔（前端目录缺失/非 package.json 工程时 true，是已定义态不是错误）', EXAMPLE_FULL, obj.degraded);
  if (!degraded && !isNonEmptyStr(obj.appRoot)) push(errors, 'appRoot', 'appRoot 为非空字符串（前端根相对项目产物目录的目录名）', EXAMPLE_FULL, obj.appRoot);

  // dependencies 依赖快照（build 前端底座「只增不删」机械判定的地板；逐包名逐版本串原样抄写）
  const depsNode = obj.dependencies;
  const DEP_EXAMPLE = '"dependencies":{"dependencies":{"vue":"^3.4.31"},"devDependencies":{"vite":"^5.3.4"}}';
  if (!isObj(depsNode)) {
    push(errors, 'dependencies', 'dependencies 必须为对象 {dependencies, devDependencies}（package.json 逐包名逐版本串原样快照，禁止去 ^/~、禁止改写；degraded 时两键为空对象）', DEP_EXAMPLE, depsNode);
  } else {
    const dExtra = Object.keys(depsNode).filter((k) => k !== 'dependencies' && k !== 'devDependencies');
    if (dExtra.length) push(errors, 'dependencies', `只允许键 dependencies/devDependencies，发现多余键: ${dExtra.join(',')}`, DEP_EXAMPLE);
    let total = 0;
    for (const k of ['dependencies', 'devDependencies']) {
      const m = depsNode[k];
      if (m !== undefined && !isObj(m)) { push(errors, `dependencies.${k}`, `${k} 必须为对象（包名 → 版本区间原文）`, DEP_EXAMPLE, m); continue; }
      if (isObj(m)) {
        for (const [name, range] of Object.entries(m)) {
          if (!/^[a-z@][a-z0-9._/@-]*$/i.test(name)) push(errors, `dependencies.${k}.${name}`, '包名形态非法（npm 包名字符集）', DEP_EXAMPLE, name);
          if (range !== null && typeof range !== 'string') push(errors, `dependencies.${k}.${name}`, '版本区间为字符串原文（如 "^3.4.31"）或 null（workspace:* 等非串形态）', DEP_EXAMPLE, range);
        }
        total += Object.keys(m).length;
      }
    }
    if (!degraded && total === 0) {
      push(errors, 'dependencies', 'degraded=false 时 dependencies/devDependencies 至少其一非空（package.json 依赖快照禁止为空）', DEP_EXAMPLE);
    }
  }

  // stack 节（键名表代码钉死；取值规程在知识文档。degraded 只要最小集，已给字段仍按信封校验）
  const stack = obj.stack;
  if (!isObj(stack)) {
    push(errors, 'stack', 'stack 必须为对象', EXAMPLE_FULL, stack);
  } else {
    const stackExtra = Object.keys(stack).filter((k) => !STACK_KEYS.includes(k));
    if (stackExtra.length) push(errors, 'stack', `stack 只允许键 ${STACK_KEYS.join('/')}，发现多余键: ${stackExtra.join(',')}`, EXAMPLE_FULL);
    const required = degraded ? STACK_MIN_KEYS : STACK_KEYS;
    for (const k of required) if (!(k in stack)) push(errors, `stack.${k}`, `stack 缺少必需键 ${k}（degraded=${degraded} 的必需集: ${required.join('/')}）`, EXAMPLE_FULL);
    if ('language' in stack) {
      const lang = stack.language;
      const allowed = degraded ? ['none', 'javascript', 'typescript'] : ['javascript', 'typescript'];
      if (!allowed.includes(lang)) {
        push(errors, 'stack.language', `language ∈ {${allowed.join('|')}}（degraded 时允许 none；判定规程见知识文档 §3——按 tsconfig/入口扩展名/devDeps 真实锚定，禁止凭 README 口径）`, '"language":"javascript"', lang);
      }
    }
    for (const g of ['runtime', 'buildTool', 'framework', 'componentLibrary']) {
      if (!(g in stack)) continue;
      const node = stack[g];
      if (!isObj(node)) { push(errors, `stack.${g}`, `${g} 为 {name, version} 对象（version 未知用 null）`, '"buildTool":{"name":"vite","version":"5.3.4"}', node); continue; }
      const gExtra = Object.keys(node).filter((k) => !GROUP_KEYS.includes(k));
      if (gExtra.length) push(errors, `stack.${g}`, `只允许键 name/version，发现: ${gExtra.join(',')}`, '"framework":{"name":"vue","version":"3.4.31"}');
      if (!isNonEmptyStr(node.name)) push(errors, `stack.${g}.name`, 'name 为非空字符串（小写包基础名；runtime 固定人类写法 Node.js；无则 none）', '"componentLibrary":{"name":"element-plus","version":"2.7.5"}', node.name);
      if ('version' in node && node.version !== null && !isNonEmptyStr(node.version) && typeof node.version !== 'number') {
        push(errors, `stack.${g}.version`, 'version 为字符串或 null', '"buildTool":{"name":"vite","version":"5.3.4"}', node.version);
      }
    }
    if ('chainSupported' in stack && typeof stack.chainSupported !== 'boolean') push(errors, 'stack.chainSupported', 'chainSupported 为布尔（false=超出生成链能力边界，下游强制人裁决）', '"chainSupported":true', stack.chainSupported);
    if ('evidence' in stack) checkEvidence(errors, read, 'stack.evidence', stack.evidence, true);
  }

  // entrypoints（build 前端底座红线数据源：文件在场性 + kind 枚举 + entry-script ↔ entry-html.references 互证）
  if (!Array.isArray(obj.entrypoints)) {
    push(errors, 'entrypoints', 'entrypoints 必须为数组（degraded 时为空数组）', EXAMPLE_EP, obj.entrypoints);
  } else {
    const entryScriptPaths = new Set();
    obj.entrypoints.forEach((ep, i) => {
      const w = `entrypoints[${i}]`;
      if (!isObj(ep)) { push(errors, w, 'entrypoint 项必须是对象', EXAMPLE_EP, ep); return; }
      const extra = Object.keys(ep).filter((k) => !ENTRYPOINT_KEYS.includes(k));
      if (extra.length) push(errors, w, `entrypoint 只允许键 ${ENTRYPOINT_KEYS.join('/')}，发现: ${extra.join(',')}`, EXAMPLE_EP);
      if (!isNonEmptyStr(ep.path)) { push(errors, `${w}.path`, 'path 为非空字符串，相对前端根（不允许绝对路径与 ..）', EXAMPLE_EP, ep.path); }
      else if (isAbsolute(ep.path) || ep.path.split('/').includes('..')) {
        push(errors, `${w}.path`, `path 必须是前端根目录内相对路径: ${ep.path}`, EXAMPLE_EP);
      } else if (!existsSync(join(frontendRoot, ep.path))) {
        // 底座在场性：entrypoint 登记的文件必须真实存在于存量前端根（build 保真门按此判红）
        push(errors, `${w}.path`, `entrypoint 文件在前端根不存在: ${ep.path}（只列真实存在的存量底座文件，禁止臆造）`, EXAMPLE_EP);
      }
      if (!ENTRY_KINDS.includes(ep.kind)) {
        push(errors, `${w}.kind`, `kind ∈ {${ENTRY_KINDS.join('|')}}`, EXAMPLE_EP, ep.kind);
      }
      if ('references' in ep && ep.references !== null && !isNonEmptyStr(ep.references)) {
        push(errors, `${w}.references`, 'references 为非空字符串（entry-html 的 entry script src 逐字值）或 null', EXAMPLE_EP, ep.references);
      }
      checkEvidence(errors, read, `${w}.evidence`, ep.evidence, true);
      if (ep.kind === 'entry-script' && isNonEmptyStr(ep.path)) entryScriptPaths.add(ep.path);
    });

    if (!degraded) {
      const countOf = (kind) => obj.entrypoints.filter((e) => isObj(e) && e.kind === kind).length;
      for (const kind of ['package-manifest', 'entry-html', 'entry-script']) {
        if (countOf(kind) === 0) {
          push(errors, 'entrypoints', `degraded=false 时必须含至少 1 条 kind=${kind}（package-manifest=package.json、entry-html=入口 HTML、entry-script=入口源文件）`, EXAMPLE_EP);
        }
      }
      // 互证：每条 entry-html 的 references 必须指向某条 entry-script 的 path（HTML 引什么就列什么）
      obj.entrypoints.forEach((ep, i) => {
        if (!isObj(ep) || ep.kind !== 'entry-html') return;
        if (!isNonEmptyStr(ep.references)) {
          push(errors, `entrypoints[${i}].references`, 'entry-html 的 references 必须写该 HTML 引用的 entry script src 逐字值（无模块入口的纯静态页应走 degraded）', EXAMPLE_EP, ep.references);
          return;
        }
        const target = String(ep.references).replace(/^\//, '');
        if (!entryScriptPaths.has(target)) {
          push(errors, `entrypoints[${i}].references`, `references="${ep.references}" 未被任何 kind=entry-script 条目登记（需补一条 path="${target}" 的 entry-script，HTML 引什么就列什么，禁止按惯例猜）`, EXAMPLE_EP);
        }
      });
    }
  }

  // structure（阶段二前端设计「挂靠策略」输入；键名钉死、approach 形态校验）
  const structure = obj.structure;
  if (!isObj(structure)) {
    push(errors, 'structure', `structure 必须为对象（${STRUCTURE_KEYS.join('/')}）`, EXAMPLE_FULL, structure);
  } else {
    const sExtra = Object.keys(structure).filter((k) => !STRUCTURE_KEYS.includes(k));
    if (sExtra.length) push(errors, 'structure', `structure 只允许键 ${STRUCTURE_KEYS.join('/')}，发现: ${sExtra.join(',')}`, EXAMPLE_FULL);
    for (const k of ['pages', 'components']) {
      const arr = structure[k];
      if (!Array.isArray(arr)) { push(errors, `structure.${k}`, `${k} 必须为数组（可空）`, EXAMPLE_PAGE, arr); continue; }
      arr.forEach((item, i) => {
        const w = `structure.${k}[${i}]`;
        if (!isObj(item)) { push(errors, w, '条目必须是对象', EXAMPLE_PAGE, item); return; }
        const extra = Object.keys(item).filter((kk) => !PAGE_KEYS.includes(kk));
        if (extra.length) push(errors, w, `条目只允许键 ${PAGE_KEYS.join('/')}，发现: ${extra.join(',')}`, EXAMPLE_PAGE);
        if (!isNonEmptyStr(item.path)) push(errors, `${w}.path`, 'path 为非空字符串，相对前端根', EXAMPLE_PAGE, item.path);
        if (!isNonEmptyStr(item.name)) push(errors, `${w}.name`, 'name 为非空字符串（路由语义名，无则文件名）', EXAMPLE_PAGE, item.name);
        if (item.status !== 'used') push(errors, `${w}.status`, `存量扫描条目 status 恒为 "used"（非 used 形态不落基线）`, EXAMPLE_PAGE, item.status);
        checkEvidence(errors, read, `${w}.evidence`, item.evidence, true);
      });
    }
    if ('router' in structure) {
      const r = structure.router;
      if (!isObj(r)) { push(errors, 'structure.router', `router 为 {mode, paths, evidence} 对象`, '{"router":{"mode":"history","paths":["/login"],"evidence":[]}}', r); }
      else {
        const rExtra = Object.keys(r).filter((k) => !ROUTER_KEYS.includes(k));
        if (rExtra.length) push(errors, 'structure.router', `只允许键 ${ROUTER_KEYS.join('/')}，发现: ${rExtra.join(',')}`);
        if (!ROUTER_MODES.includes(r.mode)) push(errors, 'structure.router.mode', `mode ∈ {${ROUTER_MODES.join('|')}}`, '"mode":"history"', r.mode);
        if (!Array.isArray(r.paths) || r.paths.some((p) => typeof p !== 'string')) push(errors, 'structure.router.paths', 'paths 为字符串数组（≤30 条，从路由配置逐条读）', '"paths":["/login"]', r.paths);
        checkEvidence(errors, read, 'structure.router.evidence', r.evidence, false);
      }
    }
    for (const [k, keys, example] of [
      ['state', APPROACH_KEYS, '{"state":{"approach":"pinia","evidence":[{"file":"src/stores/app.ts","quote":"defineStore"}]}}'],
      ['api', API_KEYS, '{"api":{"approach":"fetch","baseUrls":["/api"],"evidence":[{"file":"src/api.js","quote":"fetch("}]}}'],
      ['styles', STYLES_KEYS, '{"styles":{"approach":"scss","entry":"src/styles/index.scss","evidence":[]}}'],
    ]) {
      if (!(k in structure)) continue;
      const node = structure[k];
      if (!isObj(node)) { push(errors, `structure.${k}`, `${k} 为 ${keys.join('/')} 形态对象（判定不出时 approach:"none"）`, example, node); continue; }
      const extra = Object.keys(node).filter((kk) => !keys.includes(kk));
      if (extra.length) push(errors, `structure.${k}`, `只允许键 ${keys.join('/')}，发现: ${extra.join(',')}`, example);
      if (!isNonEmptyStr(node.approach)) push(errors, `structure.${k}.approach`, 'approach 为非空字符串（判定不出时写 "none"）', example, node.approach);
      checkEvidence(errors, read, `structure.${k}.evidence`, node.evidence, false);
    }
    if ('notes' in structure && (!Array.isArray(structure.notes) || structure.notes.some((n) => typeof n !== 'string'))) {
      push(errors, 'structure.notes', 'notes 为字符串数组（多应用取舍/截断说明）', '"notes":["另有 second-app 前端目录，与主 API 消费无关"]', structure.notes);
    }
  }

  // 凭据红线（深扫全对象）
  checkNoCredentials(errors, obj, '$');

  // 汇总输出用计数
  const counts = {
    entrypoints: Array.isArray(obj.entrypoints) ? obj.entrypoints.length : null,
    pages: isObj(structure) && Array.isArray(structure.pages) ? structure.pages.length : null,
    components: isObj(structure) && Array.isArray(structure.components) ? structure.components.length : null,
  };
  return { errors, counts };
}

// ─── 运行环境定位（house 纯 fs 约定，同 verify-inventory-baseline.mjs）──
function findDocsRoot() {
  const cwd = process.env.PROJECT_CWD || process.cwd();
  const appName = process.env.APP_NAME || process.env.APP_ID || 'project';
  for (const candidate of [resolve(cwd, appName, 'docs'), resolve(cwd, 'docs')]) {
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

/** 列 docs 下含 plans/ 的 run 目录（时间戳名 = 时序，取最新）。 */
function listRunDirs(docsRoot) {
  try {
    return readdirSync(docsRoot)
      .filter((n) => !n.startsWith('.') && existsSync(resolve(docsRoot, n, 'plans')))
      .sort();
  } catch {
    return [];
  }
}

/** 前端根：<appDir>/<appName>-frontend 优先，兜底 appDir 下含 package.json 的 *-frontend。
 *  **仅手工直跑兜底**（生产路径由编排侧显式传参，见文件头用法）；仍不认 <appName>-prototype。 */
function findFrontendRoot(docsRoot) {
  const appDir = dirname(docsRoot);
  const appName = process.env.APP_NAME || process.env.APP_ID || '';
  const named = join(appDir, `${appName}-frontend`);
  if (appName && existsSync(join(named, 'package.json'))) return named;
  try {
    const hit = readdirSync(appDir, { withFileTypes: true })
      .filter((e) => e.isDirectory() && e.name.endsWith('-frontend') && existsSync(join(appDir, e.name, 'package.json')))
      .map((e) => e.name)
      .sort();
    if (hit.length) return join(appDir, hit[0]);
    // 兜底：appName-frontend 目录存在但无 package.json（degraded 场景仍需锚定根）
    if (appName && existsSync(named)) return named;
  } catch { /* appDir 不可读 */ }
  return null;
}

function main() {
  const argv = process.argv.slice(2);
  const opts = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--cwd') process.chdir(argv[++i]);
    else if (argv[i] === '--baseline') opts.baseline = argv[++i];
    else if (argv[i] === '--frontend-root') opts.frontendRoot = argv[++i];
    // 编排侧显式判定「无前端根」（plan 2026-09-17/scenario-docs-signal-and-frontend-root-convention-fix S2）：
    // 与「没传 --frontend-root」严格区分——后者是手工直跑，本脚本兜底自扫；前者是判定结论，禁止再猜。
    else if (argv[i] === '--no-frontend-root') opts.noFrontendRoot = true;
    else if (argv[i] === '--prototype-root') opts.prototypeRoot = argv[++i];
  }

  // 定位基线文件
  let baselinePath = opts.baseline;
  let frontendRoot = opts.frontendRoot || null;
  if (!baselinePath) {
    const docsRoot = findDocsRoot();
    if (!docsRoot) return fatal('无法定位 docs 根（尝试 <cwd>/<APP_NAME>/docs 与 <cwd>/docs 均不存在）。用 --baseline <绝对路径> 显式指定。');
    const runs = listRunDirs(docsRoot);
    if (!runs.length) return fatal(`docs 根 ${docsRoot} 下无含 plans/ 的 run 目录。`);
    baselinePath = resolve(docsRoot, runs[runs.length - 1], 'plans', 'frontend', '_meta', 'inventory-baseline.json');
    if (!frontendRoot) frontendRoot = findFrontendRoot(docsRoot);
  }

  if (!existsSync(baselinePath)) {
    return fatal(`基线文件不存在: ${baselinePath}。期望：先按知识文档规程扫描存量前端代码并写入该文件（仅此一个产物），再重试。${EXAMPLE_FULL}`);
  }
  let obj;
  try {
    obj = JSON.parse(readFileSync(baselinePath, 'utf-8'));
  } catch (e) {
    return fatal(`基线文件 JSON 解析失败: ${baselinePath} — ${e && e.message}。${EXAMPLE_FULL}`);
  }
  // degraded 先于根定位裁决（dual-review 2026-09-14 #5/#7）：前端目录完全缺失是合法 degraded 态
  // （知识规程 §7「已定义态不是错误」）——degraded 基线 entrypoints 为空、structure evidence 全空，
  // 不需要任何文件锚定，root 缺失放行；非 degraded 仍 fatal（evidence 无处锚定=上游故障）。
  const degradedEarly = isObj(obj) && obj.degraded === true;
  if (!frontendRoot && !degradedEarly) {
    // 编排侧已判定无根（--no-frontend-root）时给出**可理解**的拒绝理由：0917 事故形态是 agent 把
    // 原型目录当存量前端（其 package.json 的 name 字面就是 "frontend"），只说「无法定位」它会一直
    // 重试同一个错误锚点直到 stale 红停——必须点明原型的存在与身份。
    if (opts.noFrontendRoot) {
      const protoHint = opts.prototypeRoot
        ? `\n注意：探测到原型目录 ${opts.prototypeRoot} —— 它是 prototype 阶段由前端模板整体改名生成的**原型产物，不是存量前端**` +
          `（其 package.json 的 name 字面恰为 "frontend"，易误认；里面的源码也不是存量证据）。` +
          `存量前端根只认 <appDir>/<appName>-frontend。`
        : '';
      return fatal(
        `编排侧已判定前端根不存在（<appDir>/<appName>-frontend 与 <appDir>/*-frontend 均未命中），非 degraded 基线的 evidence 无处锚定。` +
        `${protoHint}\n若确实没有存量前端，请按 §7 degraded 规程产出基线（degraded:true、stack.language:"none"、entrypoints 空数组）——这是对环境事实的如实记录，不是失败。`,
      );
    }
    return fatal('无法定位前端根目录（<appDir>/<appName>-frontend 或 <appDir>/*-frontend 均不存在），evidence 无法锚定。前端目录缺失时请按 degraded 规程产出基线。用 --frontend-root <绝对路径> 显式指定。');
  }

  const degraded = isObj(obj) && obj.degraded === true;
  const read = makeFileReader(frontendRoot);
  const result = verify(obj, { read, frontendRoot, degraded, baselinePath });
  const errors = Array.isArray(result) ? result : result.errors;

  if (errors.length === 0) {
    process.stdout.write(JSON.stringify({
      ok: true,
      action: 'verified',
      baseline: baselinePath,
      frontendRoot,
      degraded,
      counts: result.counts,
    }) + '\n');
    return;
  }

  const lines = [
    `前端 inventory-baseline 校验失败（${errors.length} 处，文件: ${baselinePath}；前端根: ${frontendRoot}）。`,
    '修复方式：只重写该 JSON 文件本身（其余文件不动，禁止为过校验改存量源码），每条断言保持可 grep 的逐字 quote；改完自动重跑校验。',
    '',
  ];
  errors.forEach((e, i) => {
    lines.push(`[${i + 1}] 违例 ${e.where}${e.got ? ` = ${e.got}` : ''}`);
    lines.push(`    期望: ${e.expect}`);
    lines.push(`    ${e.example}`);
  });
  process.stdout.write(lines.join('\n') + '\n');
  process.exit(1);
}

function fatal(message) {
  process.stdout.write([`前端 inventory-baseline 校验失败（定位错误）: ${message}`, '', `  ${EXAMPLE_FULL}`].join('\n') + '\n');
  process.exit(1);
}

main();
