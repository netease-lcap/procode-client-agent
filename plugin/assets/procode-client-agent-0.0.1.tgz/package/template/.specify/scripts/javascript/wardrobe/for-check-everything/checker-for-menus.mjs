import path from 'node:path';
import fs from 'node:fs';
import { parseMenus, readFileSync } from '../../shared/index.mjs';

import { combine } from './tools.mjs';

/**
 * 检查菜单项是否为中文
 * @param {string} text - 要检查的文本
 * @returns {boolean} 是否为纯中文
 */
const isChineseOnly = (text = '') => {
  if (!text) return false;
  const chineseRegex = /^[\u4e00-\u9fa5]+$/;
  return chineseRegex.test(text);
};

/**
 * 从解析前的原始功能单元格中检测使用 "-" 合并层级的名称。
 * parseMenus 会清理标点，因此必须读取 compressedRaw，避免连字符被清理后漏检。
 */
export const detectHyphenatedMenuNames = (menus = []) => {
  return (Array.isArray(menus) ? menus : []).flatMap((item = {}) => {
    const rawCells = Array.isArray(item.compressedRaw) ? item.compressedRaw : [];
    const categoryIndex = rawCells.findIndex((cell) => cell === item.category);
    const menuCells = categoryIndex >= 0 ? rawCells.slice(0, categoryIndex) : rawCells;

    return menuCells
      .map((name) => String(name || '').trim())
      .filter((name) => name.includes('-'));
  });
};

/** 有可用 serviceTitle 时校验一级功能；无可用数据时跳过，不承担工程清单结构校验。 */
export const detectServiceTitleErrors = (menus = [], menusFile = '') => {
  const absoluteMenusFile = path.resolve(menusFile);
  const endsFile = path.resolve(path.dirname(absoluteMenusFile), '../ends.json');
  let ends;
  try {
    ends = JSON.parse(fs.readFileSync(endsFile, 'utf8'));
  } catch {
    return [];
  }
  if (!Array.isArray(ends)) return [];
  const titles = new Set(ends
    .filter((end) => typeof end?.serviceTitle === 'string' && end.serviceTitle.trim())
    .map((end) => end.serviceTitle));
  if (!titles.size) return [];
  // 使用原始单元格，避免 parseMenus 去除标点后把不一致的名称误判为匹配。
  const firstLevels = [...new Set(menus.map((item) => item.compressedRaw?.[0] ?? item.first))];
  return firstLevels.filter((title) => !titles.has(title)).map((title) =>
    `${absoluteMenusFile} 的一级功能「${title || '空名称'}」在 ${endsFile} 中没有对应的 serviceTitle。` +
    `允许的一级功能：${[...titles].join('、')}。请将菜单归入对应工程并使用其完整标题，禁止修改 ends.json 来绕过校验。`,
  );
};

/** 检查菜单名称、层级及工程归属。 */
export const checkerForMenus = {
  filter: (bundle = {}) => {
    return bundle.absoluteFilePath?.includes?.('specs/menus.md');
  },
  callback:
    (rootDir) =>
    (bundle = {}) => {
      const { absoluteFilePath } = bundle;
      const parsed = parseMenus(absoluteFilePath) || {};
      const { menus = [] } = parsed;

      if (!menus || menus.length === 0) {
        return;
      }

      const errors = detectServiceTitleErrors(menus, absoluteFilePath);

      const source = readFileSync(absoluteFilePath);
      const splitted = source?.split?.('\n') || [];
      const filtered = splitted.filter((item) => item.includes('---'));

      if (filtered.length > 1) {
        errors.push(
          `功能模块目录禁止出现多个表格，必须严格参考 功能模块目录 对应模板，将多个表格合并成一个表格。`
        );
      }

      const hyphenatedNames = [...new Set(detectHyphenatedMenuNames(menus))];

      if (hyphenatedNames.length > 0) {
        errors.push(
          `❌ 功能名称禁止使用 "-" 合并多个功能层级：${hyphenatedNames.join('、')}。` +
            `请将每一级功能拆分到独立的功能层级列中，例如分别填写一级功能、二级功能及后续层级。`
        );
      }

      // 所有菜单项必须是中文
      const nonChineseNames = [];

      menus.forEach((item) => {
        const { compressed = [] } = item;
        compressed.forEach((name) => {
          if (name && !isChineseOnly(name)) {
            nonChineseNames.push(name);
          }
        });
      });

      if (nonChineseNames.length > 0) {
        const uniqueNonChinese = [...new Set(nonChineseNames)];
        const nonChineseList = uniqueNonChinese.join('、');
        errors.push(
          `❌ 菜单功能项包含非中文名称：${nonChineseList}。` +
            `所有菜单项的功能名称必须使用纯中文，不允许使用英文、数字、特殊符号或混合文本。`
        );
      }

      if (errors.length > 0) {
        return combine('### 菜单功能项检查失败', '', ...errors);
      }

      return;
    },
};

export default checkerForMenus;
