// 公共日志机制（脚本 / 沙箱侧形态）——与 TS 源 `src/utils/customWaveAgent/speckit/config/shared/logger/logger.ts`
// 同构的逐字镜像：同一格式契约的两种语言实现（`manifest.md` §9.5.2 / §6.7.7），
// 两侧由 `tests/.../logger/logger-consistency.test.ts` 钉死（改动格式必须同步两处）。
//
// 格式契约（**字节级**，不得二义）：
//     [YYYY-MM-DD HH:mm:ss] [<component>] [<LEVEL>] <message>
//   - 时间戳为**本地时间**（禁 toISOString()——UTC 会让沙箱 UTC+8 的排查时间错位）；
//   - `[<LEVEL>]` **整体**左对齐补空格至 **7 列**，补位在**方括号之外**（`[INFO]` 后 2 空格 /
//     `[ERROR]` 后 1 空格——含各字段间那一空格）。规范 §9.5.4 原文字面（「补至 5 字符」+「单空格
//     分隔」）会读成补在括号内，与本文件所据的示例读法字节不同；本实现以示例为准
//     （`grep '\[INFO\] '` 类消费者只在后者成立）；
//   - 各字段间单个空格；message 单行（多行由调用方压缩/截断）；
//   - TOOL 行 message 渲染为 `<message> → exit=<exit> (<ms>ms)`。
//
// 内容禁忌（§9.5.5）：日志**不得**记录凭证类字段的值。这是**写入方义务**——本机制**不做**
// 敏感字段过滤（魔法过滤会掩盖错误）；meta 也不得扩展（额外上下文一律写进 message，§9.5.3）。
//
// 目录定位：cwd = 工作空间根（§4.4），**不使用** import.meta.url——脚本被拷进工作空间后
// 自身位置与工作空间根无固定关系。日志落在 `<cwd>/workflow.log`。
// 归档用 `link` + `unlink` 的**原子「判定 + 占用」**原语（§9.5.6），**禁止** `existsSync` + `rename`：
// 检查与动作之间的窗口会让两个进程互相覆盖归档（**丢整天数据**）。
//
// 与 TS 侧的有意差异：`tool()` 在 meta 非 `{exit, ms}` 数值对时**抛 TypeError**。TS 侧由类型系统
// 在编译期挡住（运行时静默退化），mjs 侧无类型系统、漏传会渲染成 `cmd → exit=undefined (undefinedms)`，
// 故在此把同一契约降级为运行时断言——两侧对**合法调用**行为逐字相同（一致性测试覆盖）。
//
// 入库提示：本文件是**手写源**，但位于 `template/.specify/**`，被 `template/.gitignore` 的
// `.specify/*` 规则忽略（§6.7.4 第一种情形）。提交时须 `git add -f`；**不**在 .gitignore 加
// negation（`.specify/*` 已排除父目录，逐级 negation 会牵动整棵树并重新包含生成产物）。
//
// 依赖：零外部依赖，只用 `node:` 内置（§6.1）。

import fs from 'node:fs';
import path from 'node:path';

const LOG_BASENAME = 'workflow.log';

/** 归档文件名前缀——`workflow-<mtime 本地日期>.log`（§9.5.6）；与 `LOG_BASENAME` 同名基。 */
const ARCHIVE_PREFIX = 'workflow-';

/** `[<LEVEL>]` 整体宽度——补位在方括号之外（§9.5.4）。 */
const LEVEL_FIELD_WIDTH = 7;

const pad2 = (n) => String(n).padStart(2, '0');

/** 本地日期（YYYY-MM-DD）；归档判定与归档文件名用。 */
const formatLocalDate = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

/** 本地时间戳（YYYY-MM-DD HH:mm:ss）。必须走本地 getter，不得用 toISOString()（UTC）。 */
const formatLocalTimestamp = (d) =>
  `${formatLocalDate(d)} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;

/**
 * 纯渲染函数（不碰 fs）——格式契约的单点实现，也是两侧一致性测试的比对入口。
 *
 * `meta` 仅 TOOL 行消费（§9.5.3）。TOOL 级未传 `meta` 时退化为无后缀行：公开入口
 * `tool()` 恒传 meta，该分支只在直接调用本函数（测试/诊断）时可达。
 */
export function formatLogLine(ts, component, level, message, meta) {
  const stamp = `[${formatLocalTimestamp(ts)}]`;
  const comp = `[${component}]`;
  const lvl = `[${level}]`.padEnd(LEVEL_FIELD_WIDTH, ' ');
  const body = level === 'TOOL' && meta ? `${message} → exit=${meta.exit} (${meta.ms}ms)` : message;
  return `${stamp} ${comp} ${lvl} ${body}`;
}

/**
 * 归档判定（§9.5.6）：活跃文件 mtime 非今天 → 归档成 `workflow-<mtime 日期>.log`。
 *
 * 归档走 **`link` + `unlink`** 的**原子「判定 + 占用」**原语，**不用** `existsSync` + `rename`：
 * 后者的检查与动作之间存在窗口——两个进程都判定「目标不存在」，P1 归档并继续向新活跃文件追加
 * 今日行后，P2 才 `rename`，会把**已含今日行**的活跃文件盖到同一目标名上（POSIX `rename` 静默
 * 覆盖），**昨天的整日归档被抹掉**（数据丢失）。`link` 在目标已存在时由内核返回 `EEXIST`，
 * 判定与占用一步完成，窗口不存在。
 *
 * - `EEXIST` = 守卫命中（别人已归档）→ 跳过归档，由调用方 append **现存**活跃文件（正常路径）；
 * - 其它错误（跨设备 EXDEV / 权限 / 文件系统不支持硬链）→ 吞掉、继续 append（§9.5.7①）；
 * - `unlink` 失败（罕见）→ 归档已成而活跃文件仍在，此后 append 会同时落进归档：属 §9.5.6
 *   已接受的**位置偏差**，不是数据丢失；
 * - `statSync` 失败（不存在 / 不可读）→ 跳过归档、由调用方 append。
 */
function archiveIfNeeded(logPath) {
  let mtime;
  try {
    mtime = fs.statSync(logPath).mtime;
  } catch {
    return; // 无活跃文件或不可读 → 无需归档
  }

  const mtimeDay = formatLocalDate(mtime);
  if (mtimeDay === formatLocalDate(new Date())) return; // mtime 是今天 → 不归档

  const target = path.join(path.dirname(logPath), `${ARCHIVE_PREFIX}${mtimeDay}.log`);
  try {
    fs.linkSync(logPath, target); // 目标已存在 → EEXIST（内核级，不覆盖）
    fs.unlinkSync(logPath); // 归档成功 → 移除活跃文件，下次 append 新建
  } catch (err) {
    if (err && err.code === 'EEXIST') return; // 守卫命中：别人已归档，直接 append 现存活跃文件
    /* 其它失败：归档不成立，继续向活跃文件追加（位置偏差可接受，数据不丢） */
  }
}

/**
 * 写一行（归档判定 + 追加），**任何 fs 错误 warn-and-continue**（§9.5.7①，降级为静默）。
 * 静默是刻意的：logger 位于 checker / 脚本的输出链路上，向 stderr 抱怨会污染调用方的诊断面，
 * 而「日志没法写」不应翻转调用方的业务语义。
 */
function appendLine(line) {
  try {
    const logPath = path.join(process.cwd(), LOG_BASENAME);
    archiveIfNeeded(logPath);
    fs.appendFileSync(logPath, `${line}\n`, 'utf8');
  } catch {
    /* warn-and-continue：绝不向调用方抛 */
  }
}

/**
 * 创建 logger（component 在创建时绑定，§9.5.3——两侧接口只差这一处绑定位置）。
 *
 * 不缓存任何目录状态：每次调用重新判定归档（进程独立、状态在文件系统上）。只写不读。
 */
export function createLogger(component) {
  const write = (level, message, meta) => appendLine(formatLogLine(new Date(), component, level, message, meta));

  return {
    info: (message) => write('INFO', message),
    warn: (message) => write('WARN', message),
    error: (message) => write('ERROR', message),
    /**
     * TOOL 行（§9.5.3）——`meta` 是**必填**的 `{ exit: number, ms: number }`。
     *
     * mjs 无类型系统，漏传/传错会让 `formatLogLine` 静默退化成 `cmd → exit=undefined (undefinedms)`
     * （日志没有崩溃但内容失真），故与 `formatLogLine` 对非 `Date` 抛错的既有原则一致，
     * 在**公开入口**显式抛 `TypeError`：编程错误应响亮，不静默。
     */
    tool: (message, meta) => {
      if (!meta || typeof meta.exit !== 'number' || typeof meta.ms !== 'number') {
        throw new TypeError(
          `createLogger().tool(message, meta): meta 必填且须为 { exit: number, ms: number }，收到 ${JSON.stringify(meta)}`,
        );
      }
      write('TOOL', message, meta);
    },
  };
}
