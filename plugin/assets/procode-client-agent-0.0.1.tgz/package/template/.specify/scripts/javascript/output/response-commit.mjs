/**
 * /speckit.commit 后置总结脚本（cwd = 沙箱工作区根）。
 * 读取 docs/.commit/current.json 指针 + runDir/commit-message.txt + git log，
 * stdout 输出即用户可见的提交摘要。任何异常都 exit 0（降级输出，不产生 error block）。
 */
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const say = (lines) => console.log(lines.filter(Boolean).join('\n'));

function resolveAppDir(rootDir) {
  const appName = (process.env.APP_NAME || process.env.APP_ID || '').trim();
  if (appName && !appName.includes('/') && appName !== '.' && appName !== '..') {
    const candidate = path.join(rootDir, appName);
    if (fs.existsSync(candidate)) return candidate;
  }
  return rootDir;
}

function gitLogOne(appDir, format) {
  try {
    return execSync(`git -C ${JSON.stringify(appDir)} log -1 --format=${JSON.stringify(format)}`, {
      encoding: 'utf-8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim();
  } catch {
    return '';
  }
}

try {
  const rootDir = process.cwd();
  const appDir = resolveAppDir(rootDir);
  const pointerPath = path.join(appDir, 'docs', '.commit', 'current.json');

  if (!fs.existsSync(pointerPath)) {
    say(['### 代码提交', '', '当前没有进行中的代码提交记录。']);
    process.exit(0);
  }

  const pointer = JSON.parse(fs.readFileSync(pointerPath, 'utf-8'));
  const runDir = pointer.runDir || '';
  const messagePath = runDir ? path.join(runDir, 'commit-message.txt') : '';
  const message = messagePath && fs.existsSync(messagePath) ? fs.readFileSync(messagePath, 'utf-8') : '';
  const lines = message.split('\n');
  const subject = (lines[0] || '').trim();
  const body = lines.slice(1).join('\n').trim();
  const sha = gitLogOne(appDir, '%h');
  const author = pointer.author || gitLogOne(appDir, '%an <%ae>') || '';

  say([
    '### 代码提交',
    '',
    `- 分支：${pointer.branch || gitLogOne(appDir, '%(refname:short)') || '未知'}`,
    `- 提交：${sha ? `${sha} ${subject}` : subject || '（未读取到提交信息）'}`,
    author ? `- 提交人：${author}` : null,
    body ? `\n${body}` : null,
  ]);
} catch (error) {
  say([`### 代码提交`, '', `提交摘要生成失败：${(error && error.message) || error}`]);
}
process.exit(0);
