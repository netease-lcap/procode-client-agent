import fs from 'fs';
import path from 'path';

import {
  PENDING,
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  writeToFileSync,
  formatWritedFiles,
  parseMenusToTable,
  auto,
} from './shared/index.mjs';

export const findMenus = (item) => item.endsWith('specs/menus.md');
export const filterModule = (item) => item.includes('specs/module-');
export const filterChecklist = (item) => item.includes('specs/checklist-');

export const tableToStore = (table = []) => {
  const store = {};

  table?.forEach((item = []) => {
    const [key] = item;
    const label = item.join('-');

    store[label] = store[label] || [];
    store[label].push(label);
  });

  return store;
};

export const itemToSegments = (rootDir) => (item = '', found = {}) => {
  const activeSpecDir = getActiveSpecDir(rootDir);

  const merged = [
    `<!-- ${item} -->`,
    '- **[验收功能]**：',
    '  - **[验收类别]**：',
    '    - [验收规则]',
  ].join('\n');

  return [
    `# ${item}`,
    '',
    `[详细描述 ${item} 的业务需求]`,
    '',
    '## 验收列表',
    '',
    '<!-- 角色权限：以最终需求分析和术语表中实际存在的角色、权限为准；纯匿名或无角色差异时不得强行添加角色限制。-->',
    '',
    `<!-- 验收功能：阅读并充分理解 关键内容-${item} 对应功能要点的业务描述，严格根据业务描述划分的当前功能要点的各个子功能点。禁止遗漏任何子功能点。禁止遗漏任何可能的验收功能。  -->`,
    '',
    '<!-- 验收规则的中禁止出现任何日期时间格式相关细节。 -->',
    `<!-- 阅读并充分理解文档 **[关键内容-${item}](${activeSpecDir}/pieces/content-${item}.md)**，必须要严格根据 **[关键内容-${item}](${activeSpecDir}/pieces/content-${item}.md)** 描述的业务内容生成详细的验收规则。 -->`,
    `<!-- 阅读并充分理解文档 **[视觉需求-${item}](${activeSpecDir}/pieces/design-${item}.md)**，必须要严格根据 **[视觉需求-${item}](${activeSpecDir}/pieces/design-${item}.md)** 描述的业务内容生成详细的验收规则。 -->`,
    '',
    merged,
    '',
  ];
};

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  removeUnderSpecs(rootDir)(filterModule);
  removeUnderSpecs(rootDir)(filterChecklist);

  const { absoluteDir: menusAbsoluteDir, absoluteFilePath: menusAbsoluteFilePath } =
    findUnderSpecs(rootDir)(findMenus) || {};
  const activeSpecDir = getActiveSpecDir(rootDir);
  const piecesAbsoluteDir = path.resolve(activeSpecDir, 'pieces');

  if (!menusAbsoluteFilePath || !menusAbsoluteDir) {
    throw new Error(`缺少功能模块目录：${activeSpecDir}/specs/menus.md`);
  }

  const parsedMenus = parseMenusToTable(menusAbsoluteFilePath);
  const store = tableToStore(parsedMenus);

  const map = (key) => {
    const segments = itemToSegments(rootDir)(key);

    const name = `checklist-${key}.md`;
    const absoluteFilePath = path.resolve(menusAbsoluteDir, name);

    const content = (() => {
      const filename = `content-${key}.md`;
      const contentFilePath = path.resolve(piecesAbsoluteDir, filename);

      return readFileSync(contentFilePath);
    })();

    const suffix = content?.length > 50 ? PENDING : '';

    return writeToFileSync(name, absoluteFilePath)(segments, suffix);
  };

  const files = Object.keys(store).map(map);

  return formatWritedFiles('验收内容文档列表')(files);
};

auto(import.meta, true)(toRaw);
export default toRaw;
