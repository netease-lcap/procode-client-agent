/**
 * MCP SQL 执行 client（纯 Node 内置，无第三方依赖）。
 *
 * 对接远端 lite-mcp-spring-boot-starter 的 InternalWebSqlController.executeSqlDirect 工具。
 * 传输：SSE（GET sse 端点拿 message URL + sessionId，向 message 端点 POST JSON-RPC 请求，
 *       响应回到 SSE 流，按 JSON-RPC id 关联）。
 *
 * 协议契约（实测 tools/list schema）：
 *   - 握手：initialize（id:1）→ notifications/initialized（无 id）→ tools/call
 *   - 工具入参：{ statementDTO: { sql, dataSourceName, dbName, env, appId, offset?, limit? } }
 *     本 client 的必填校验（与实现同口径）：sql + dataSourceName + dbName + appId（env 缺省 'dev'）。
 *     ⚠ 平台 direct 对 dbName 的必填性尚未在本仓库内核实（见 plan 2026-11-09 §5.2 未决项）；
 *     在拿到平台 schema/只读回执前保持收紧，不放宽为可选，也不为通过本地检查把 owner/SID/
 *     连接服务名塞进 dbName。
 *     dataSourceName = 数据源标识（内部 websql 链路按此选库，如 default-dev-1）
 *     dbName = 真实库名（页面 websql 链路按此选库，如 defaulttenant-dev-XXX）
 *   - executeSqlDirect 是**同步**执行：直接返回 FINISHED/FAILED；
 *     旧 executeSql 是异步（只提交、返回 taskGroupId），SQL 失败仍报 success=true 致误判——故切 direct。
 *     ⚠ 实测 executeSqlDirect 顶层 structuredContent.success 恒为 true（仅表 task 提交成功），
 *     真实执行结果在 structuredContent.result.status：FINISHED=成功，FAILED=失败（result.result 装错误原文）；
 *     故归一化 success 须由 result.status 推导（见 normalizeSqlResult），不能取顶层 success。
 *     且**只认已确认的成功终态**：仅 `status === 'FINISHED'` 才算 success；FAILED 与
 *     RUNNING/PENDING/QUEUED/UNKNOWN/空串/缺 status 一律失败——任务未到终态时返回的空结果
 *     不能当「空库」，否则查库失败会冒充采集成功。
 *   - 返回（标准 MCP CallToolResult → 归一化为下述 {success,result,msg,raw}）：
 *       isError：MCP 层异常；success：仅 result.status === 'FINISHED' 为 true；
 *       result：透传 task 详情（{taskId,sql,status,progress,result}）；msg：失败时取错误原文或终态说明。
 *
 * `executeSqlViaMcp` 单次调用建独立 SSE 会话（sql-exec 是 CLI 短进程，一次调用完即退）。
 * 批量采集（如 extract-code-schema 的逐表 SHOW CREATE TABLE）用 `openMcpSession` 复用**一条**
 * 会话；会话内按递增 JSON-RPC id 并发 `tools/call`，响应乱序由 pendingById 路由。
 */

import http from 'node:http';
import https from 'node:https';
import mcpConfig from './mcp-sql-config.mjs';

// 优先级：SQL_EXEC_MCP_ENDPOINT 环境变量 > mcp-sql-config.mjs.defaultEndpoint > 空（报错）。
// 配置值承载于同目录 mcp-sql-config.mjs（tracked 静态配置，不写死代码）。

/**
 * 按 URL 取 http/https 模块 + 默认选项（https 跳过证书校验，兜底自签/代理场景）。
 */
function requestModule(url) {
  if (url.startsWith('https://')) {
    return { mod: https, defaults: { rejectUnauthorized: false } };
  }
  return { mod: http, defaults: {} };
}

/**
 * 读沙箱/运行时 HTTP 代理环境变量（curl 同款）。沙箱把 lcap.low-code 等虚拟域名
 * 经代理路由（127.0.0.1:7000 → 127.0.0.1:22988），Node http 默认不读代理 env，
 * 不显式走代理则 getaddrinfo 解析虚拟域名失败（EAI_AGAIN）。
 * targetUrl 是 http 时读 *_PROXY/http_proxy；NO_PROXY/no_proxy 命中则不用代理。
 */
function resolveHttpProxy(targetUrl) {
  const isHttps = targetUrl.startsWith('https://');
  const proxyEnv = isHttps
    ? (process.env.HTTPS_PROXY || process.env.https_proxy)
    : (process.env.HTTP_PROXY || process.env.http_proxy);
  if (!proxyEnv) return null;
  // NO_PROXY / no_proxy 匹配 target host 则直连
  const noProxy = process.env.NO_PROXY || process.env.no_proxy || '';
  try {
    const targetHost = new URL(targetUrl).hostname;
    const hit = noProxy.split(',').map((s) => s.trim()).filter(Boolean).some((pat) => {
      if (pat === '*') return true;
      return targetHost === pat || targetHost.endsWith(pat.startsWith('.') ? pat : '.' + pat);
    });
    if (hit) return null;
  } catch { /* URL 解析失败，走代理 */ }
  try { return new URL(proxyEnv); } catch { return null; }
}

/**
 * 构造经 HTTP 代理转发 http 目标的请求选项。
 * 无代理：返回 null（调用方走原 mod.get(url)/mod.request({hostname,port,path}) 直连）。
 * 有代理：代理收到完整 URL 的 GET/POST，按 Host 头转发到目标（标准 HTTP 代理对 http 目标的方式）。
 * 注：https 目标 + http 代理需 CONNECT 隧道，当前 mcp endpoint 是 http，不实现 CONNECT。
 */
function buildProxyRequestOpts(targetUrl, { method, defaults, headers = {} }) {
  const proxy = resolveHttpProxy(targetUrl);
  if (!proxy) return null;
  return {
    ...defaults,
    method,
    hostname: proxy.hostname,
    port: proxy.port || (proxy.protocol === 'https:' ? 443 : 80),
    path: targetUrl, // 完整目标 URL，代理按此转发
    headers: { ...headers, Host: new URL(targetUrl).host },
  };
}

/**
 * 从 buffer 首部解析一个完整 SSE 帧（以空行结尾）。
 * 返回 { frame: { event, data }, consumed } 或 null（不成帧）。
 * data 多行以 \n 拼接。
 */
function takeSseFrame(buffer) {
  const end = buffer.indexOf('\n\n');
  if (end < 0) return null;
  const block = buffer.slice(0, end);
  const consumed = end + 2;
  let event = null;
  const dataLines = [];
  for (const raw of block.split('\n')) {
    const line = raw.replace(/\r$/, '');
    if (line.startsWith('event:')) event = line.slice(6).trim();
    else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
  }
  return { frame: { event, data: dataLines.join('\n') }, consumed };
}

/**
 * SSE 会话：单一 data 监听器 + 帧分发。
 * - endpoint 帧解析出 messageUrl（resolve openPromise）。
 * - 带 JSON-RPC id 的 result/error 帧路由到 pendingById。
 * 设计为单监听器，避免多监听器抢数据导致响应丢失。
 */
class SseSession {
  constructor(endpoint, { timeoutMs }) {
    this.endpoint = endpoint;
    this.timeoutMs = timeoutMs;
    this.buf = '';
    this.messageUrl = null;
    this.res = null;
    this.pendingById = new Map(); // id → { resolve, reject }
    this.openPromise = new Promise((resolve, reject) => { this._resolveOpen = resolve; this._rejectOpen = reject; });
    this._timer = null;
    // 会话级不可恢复错误（连接断开/SSE 失败）：批量采集据此整轮失败，不把 1348 条请求记成假失败。
    this.broken = false;
  }

  start() {
    const { mod, defaults } = requestModule(this.endpoint);
    this._timer = setTimeout(() => this._fail(new Error(`MCP SSE 端点连接超时（${this.endpoint}）`)), this.timeoutMs);
    // 沙箱 HTTP 代理：lcap.low-code 是代理虚拟域名，经 HTTP_PROXY 转发才可达。
    const proxyOpts = buildProxyRequestOpts(this.endpoint, { method: 'GET', defaults, headers: {} });
    const req = proxyOpts
      ? mod.request({ ...proxyOpts, timeout: this.timeoutMs }, (res) => {
          this.res = res;
          res.setEncoding('utf-8');
          res.on('data', (chunk) => this._onData(chunk));
          res.on('error', (e) => this._fail(e));
        })
      : mod.get(this.endpoint, { ...defaults, timeout: this.timeoutMs }, (res) => {
          this.res = res;
          res.setEncoding('utf-8');
          res.on('data', (chunk) => this._onData(chunk));
          res.on('error', (e) => this._fail(e));
        });
    this.req = req;
    if (proxyOpts) req.end(); // http.request 不会自动 end（http.get 会），不调则请求不发，SSE 端等不到→超时
    req.on('error', (e) => this._fail(e));
    req.on('timeout', () => this._fail(new Error(`MCP SSE 端点连接超时（${this.endpoint}）`)));
    return this.openPromise;
  }

  _onData(chunk) {
    this.buf += chunk;
    while (true) {
      const r = takeSseFrame(this.buf);
      if (!r) break;
      this.buf = this.buf.slice(r.consumed);
      const { event, data } = r.frame;
      if (!data) continue; // keepalive 等空帧
      if (event === 'endpoint' && !this.messageUrl) {
        this.messageUrl = data;
        clearTimeout(this._timer);
        // 握手完成后禁用 socket 空闲超时（M20 修复 C+D）：SSE 连接在 tools/call 响应前是
        // 静默的，req 'timeout'（idle 超时）会在平台建库耗时 > timeoutMs 时先于
        // waitForResult 的 per-id 计时器触发，误报「端点连接超时」并杀死会话。
        // 握手后超时语义统一交给 waitForResult（区分「连接超时」vs「响应超时」）。
        this.req?.setTimeout?.(0);
        this._resolveOpen();
        continue;
      }
      // JSON-RPC 帧
      let msg;
      try { msg = JSON.parse(data); } catch { continue; }
      const id = msg.id;
      if (id == null) continue;
      const w = this.pendingById.get(id);
      if (!w) continue;
      this.pendingById.delete(id);
      if (msg.error) w.reject(new Error(`MCP id=${id} 返回错误：${JSON.stringify(msg.error)}`));
      else w.resolve(msg.result);
    }
  }

  _fail(e) {
    this.broken = true;
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    if (!this.messageUrl) this._rejectOpen(e);
    for (const [, w] of this.pendingById) w.reject(e);
    this.pendingById.clear();
    this.res?.destroy?.();
  }

  async post(body) {
    if (!this.messageUrl) await this.openPromise;
    return new Promise((resolve, reject) => {
      const { mod, defaults } = requestModule(this.messageUrl);
      const payload = JSON.stringify(body);
      const baseHeaders = { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) };
      // 沙箱 HTTP 代理：messageUrl 经 HTTP_PROXY 转发（与 start() 同款）。
      const proxyOpts = buildProxyRequestOpts(this.messageUrl, { method: 'POST', defaults, headers: baseHeaders });
      const u = new URL(this.messageUrl);
      const opts = proxyOpts
        ? { ...proxyOpts, timeout: this.timeoutMs }
        : {
            ...defaults, method: 'POST', hostname: u.hostname,
            port: u.port || (u.protocol === 'https:' ? 443 : 80),
            path: u.pathname + u.search,
            headers: baseHeaders,
            timeout: this.timeoutMs,
          };
      const req = mod.request(opts, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('MCP message POST 超时')); });
      req.write(payload); req.end();
    });
  }

  waitForResult(id, timeoutMs) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => {
        this.pendingById.delete(id);
        reject(new Error(`MCP 等待 id=${id} 响应超时`));
      }, timeoutMs);
      this.pendingById.set(id, {
        resolve: (v) => { clearTimeout(t); resolve(v); },
        reject: (e) => { clearTimeout(t); reject(e); },
      });
    });
  }

  close() {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    this.res?.destroy?.();
  }
}

/**
 * 归一化 executeSqlDirect 的 CallToolResult 业务体（形态② structuredContent / 形态③ parsed text）。
 *
 * 实测（2026-08-25 沙箱）：executeSqlDirect 顶层 `success` 恒为 true（仅表示 task 提交成功），
 * 真实执行结果在 `result.status`：`FINISHED`=SQL 成功；`FAILED`=SQL 失败（`result.result` 装错误原文）。
 * 故 `success` 须由 `result.status` 推导，不能取顶层 `success`——否则 FAILED 的 SQL 也被当成功，
 * 绕过 sql-exec.mjs「执行失败不落归档」的门禁。
 *
 * 只认已确认的成功终态：**仅 `status === 'FINISHED'` 才算 success**。FAILED 与
 * RUNNING/PENDING/QUEUED/UNKNOWN/空串/缺 status/非字符串 status 一律 failure，msg 带实际
 * status 与「任务未到终态，不可当空结果」的恢复提示。不再回退外层 `success`：
 * 外层 success 只代表 task 提交成功，不能证明 SQL 执行完成。
 *
 * @param {object} body  parsed 业务体 {code,msg,result,success}（result 形如 {taskId,sql,status,progress,result}）
 * @returns {{success:boolean, result:unknown, msg:string}}
 */
function normalizeSqlResult(body) {
  const sc = body || {};
  const task = (sc.result && typeof sc.result === 'object') ? sc.result : null;
  const rawStatus = task ? task.status : undefined;
  const status = typeof rawStatus === 'string' && rawStatus.trim() ? rawStatus.trim() : null;
  const success = status === 'FINISHED';
  const failReason = (task && typeof task.result === 'string' && task.result) ? task.result : '';
  let msg;
  if (success) {
    msg = typeof sc.msg === 'string' ? sc.msg : '';
  } else if (status === 'FAILED') {
    msg = failReason || (typeof sc.msg === 'string' ? sc.msg : '') || 'SQL 执行失败 status=FAILED';
  } else {
    const shown = status === null
      ? (rawStatus === undefined ? '<缺失>' : JSON.stringify(rawStatus))
      : status;
    msg =
      `SQL 执行结果不可确认成功：status=${shown}（只接受 FINISHED）。` +
      '任务未到终态，不可当空结果；请确认 MCP 任务执行完成后重试，勿把空 rows 当空库。' +
      (failReason ? ` 详情：${failReason}` : '');
  }
  return { success, result: task ?? sc.result ?? null, msg };
}

/**
 * 解析 executeSqlDirect 的 CallToolResult（形态② structuredContent / 形态③ parsed text）。
 *
 * 调用方可用它把「同一会话上的并发 tools/call 结果」归一化为 {success,result,msg}，
 * 与 `executeSqlViaMcp` 的单次解析保持同一口径。
 */
export function parseExecuteSqlDirectResult(callResult) {
  const sc = callResult.structuredContent || {};
  if (callResult.isError === true) {
    const text = callResult.content?.[0]?.text || JSON.stringify(sc);
    return { success: false, result: sc.result ?? null, msg: `MCP isError: ${text}` };
  }
  if (!callResult.structuredContent) {
    // 形态③：direct 仅回 content[].text；text 必须是能确认 status 的 JSON 业务体。
    const text = callResult.content?.[0]?.text || '';
    let parsed = null;
    try { parsed = JSON.parse(text); } catch { /* 非 JSON：无法确认 FINISHED，按失败处理 */ }
    if (parsed && typeof parsed === 'object') return normalizeSqlResult(parsed);
    return {
      success: false,
      result: null,
      msg:
        'SQL 执行结果不可解析：content[].text 非 JSON 业务体，无法确认 status=FINISHED；' +
        '任务未到终态或通道异常，不可当空结果。' +
        (text ? ` 原文：${text}` : '（text 为空）'),
    };
  }
  return normalizeSqlResult(sc);
}

/**
 * 打开**一条**可复用的 MCP SSE 会话（initialize 只做一次）。
 *
 * 供批量采集使用：同一会话上可并发发多个 `tools/call`，每次分配递增 JSON-RPC id；
 * 响应乱序由 SseSession.pendingById 按 id 路由。调用方负责 `close()`。
 *
 * @returns {Promise<{callTool:Function, isBroken:Function, close:Function}>}
 */
export async function openMcpSession({
  endpoint = process.env.SQL_EXEC_MCP_ENDPOINT || mcpConfig.defaultEndpoint || '',
  timeoutMs = mcpConfig.defaultTimeoutMs || 30_000,
  clientName = 'mcp-session',
} = {}) {
  if (!endpoint) throw new Error('openMcpSession: MCP endpoint 为空');
  const session = new SseSession(endpoint, { timeoutMs });
  session.start();
  await session.openPromise;
  try {
    // 必须先注册 waitForResult 再 POST，否则响应可能先到、pendingById 还没登记 → 丢失。
    const initPromise = session.waitForResult(1, timeoutMs);
    await session.post({
      jsonrpc: '2.0',
      id: 1,
      method: 'initialize',
      params: {
        protocolVersion: '2024-11-05',
        capabilities: {},
        clientInfo: { name: clientName, version: '1.0.0' },
      },
    });
    await initPromise;
    await session.post({ jsonrpc: '2.0', method: 'notifications/initialized' });
  } catch (error) {
    session.close();
    throw error;
  }

  let nextId = 2;
  let closed = false;
  return {
    async callTool(toolName, args, { timeoutMs: callTimeoutMs = timeoutMs } = {}) {
      if (closed) throw new Error('MCP session 已关闭');
      if (!toolName) throw new Error('MCP session callTool: toolName 为空');
      const id = nextId++;
      const resultPromise = session.waitForResult(id, callTimeoutMs);
      try {
        await session.post({
          jsonrpc: '2.0',
          id,
          method: 'tools/call',
          params: { name: toolName, arguments: args || {} },
        });
      } catch (error) {
        // POST 失败时 waitForResult 仍挂着，挂一个 noop catch 防 unhandled rejection。
        resultPromise.catch(() => {});
        throw error;
      }
      return resultPromise;
    },
    isBroken: () => session.broken === true,
    close() {
      if (closed) return;
      closed = true;
      session.close();
    },
  };
}

/**
 * 在已打开的会话上执行一条 SQL（与 executeSqlViaMcp 同解析）。
 */
export async function executeSqlDirectOnSession(session, { sql, dataSourceName, dbName, appId, env = 'dev' }, timeoutMs = mcpConfig.defaultTimeoutMs || 30_000) {
  if (!sql) throw new Error('executeSqlDirectOnSession: sql 为空');
  if (!dataSourceName) throw new Error('executeSqlDirectOnSession: dataSourceName 为空');
  if (!dbName) throw new Error('executeSqlDirectOnSession: dbName 为空');
  if (!appId) throw new Error('executeSqlDirectOnSession: appId 为空');
  const callResult = await session.callTool(
    'InternalWebSqlController.executeSqlDirect',
    { statementDTO: { sql, dataSourceName, dbName, env, appId } },
    { timeoutMs },
  );
  return { ...parseExecuteSqlDirectResult(callResult), raw: callResult };
}

/**
 * 通过 MCP 端点执行一条 SQL（单次调用建独立会话；批量采集请用 openMcpSession 复用）。
 *
 * @param {object} p
 * @param {string} p.sql        单条 SQL（调用方负责拆分）
 * @param {string} p.dataSourceName  数据源标识（沙箱逻辑分桶名，如 default-dev-1，远端内部 websql 链路按此选库）
 * @param {string} p.dbName     真实库名（数据源契约条目的连接目标库，如 defaulttenant-dev-XXX，远端页面 websql 链路按此选库）
 * @param {string} p.appId      应用 ID（沙箱 env `APP_ID` 注入）
 * @param {string} [p.env]      环境，缺省 'dev'
 * @param {string} [p.endpoint] MCP SSE 端点，缺省内置
 * @param {number} [p.timeoutMs] 超时 ms，缺省 60s（executeSqlDirect 同步执行，重型 DDL 需更长余量）
 * @returns {Promise<{success:boolean, result:unknown, msg:string, raw:object}>}
 *   success 由 structuredContent.result.status 推导（只有 FINISHED=成功；FAILED 及其它未到终态的
 *   status 均失败，顶层 success 恒 true 不可用）；
 *   失败时 msg 取 result.result（SQL 错误原文，供 sql-exec 幂等 skip 判定）；result 透传 task 详情。
 *   若 MCP 层 isError 或结构异常，success=false、msg 含原始信息。
 *   网络/超时错误抛 Error，由调用方 catch 后按失败处理。
 */
export async function executeSqlViaMcp({ sql, dataSourceName, dbName, appId, env = 'dev', endpoint = process.env.SQL_EXEC_MCP_ENDPOINT || mcpConfig.defaultEndpoint || '', timeoutMs = mcpConfig.defaultTimeoutMs || 30_000 }) {
  if (!sql) throw new Error('executeSqlViaMcp: sql 为空');
  if (!dataSourceName) throw new Error('executeSqlViaMcp: dataSourceName 为空');
  if (!dbName) throw new Error('executeSqlViaMcp: dbName 为空');
  if (!appId) throw new Error('executeSqlViaMcp: appId 为空');

  const session = await openMcpSession({ endpoint, timeoutMs, clientName: 'sql-exec' });
  try {
    return await executeSqlDirectOnSession(session, { sql, dataSourceName, dbName, appId, env }, timeoutMs);
  } finally {
    session.close();
  }
}

// ============== Generic MCP tool dispatcher（argsKey 参数化）==============
// 用途：sql-exec.mjs --database 模式调 ProAppDatabaseController.create；
//      其它 controller（executeSql 已有专用 wrapper executeSqlViaMcp）按需也可改写。
// 设计：platform controller method 入参 key 不稳 (executeSql 用 'statementDTO'，
//      ProAppDatabaseController.create 用 'arg0')；本 dispatcher 通过 argsKey 参数化
//      使 caller 传具体 key 字符串，避免硬编码。
// 复用：与 executeSqlViaMcp 共享 SseSession + takeSseFrame + resolveHttpProxy 等通用代码。
export async function callMcpTool(toolName, argsKey, argsBody, opts = {}) {
  const endpoint = opts.endpoint || process.env.SQL_EXEC_MCP_ENDPOINT || mcpConfig.defaultEndpoint || '';
  const timeoutMs = opts.timeoutMs || mcpConfig.defaultTimeoutMs || 30_000;
  if (!endpoint) throw new Error(`callMcpTool: endpoint empty (SQL_EXEC_MCP_ENDPOINT env not set and no mcp-sql-config default)`);
  if (!toolName) throw new Error('callMcpTool: toolName empty');
  if (!argsKey) throw new Error('callMcpTool: argsKey empty');

  const session = new SseSession(endpoint, { timeoutMs });
  session.start();
  await session.openPromise;
  try {
    // 同 executeSqlViaMcp 流程：先注册 pending handler 再 POST，避免响应被 _onData 丢弃
    const initPromise = session.waitForResult(1, timeoutMs);
    await session.post({ jsonrpc: '2.0', id: 1, method: 'initialize',
      params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'sql-exec-generic', version: '1.0.0' } } });
    await initPromise;

    await session.post({ jsonrpc: '2.0', method: 'notifications/initialized' });

    const callPromise = session.waitForResult(2, timeoutMs);
    await session.post({ jsonrpc: '2.0', id: 2, method: 'tools/call',
      params: { name: toolName, arguments: { [argsKey]: argsBody } } });
    const callResult = await callPromise;

    // 解析 structuredContent
    const sc = callResult.structuredContent || {};
    if (callResult.isError === true) {
      const text = callResult.content?.[0]?.text || JSON.stringify(sc);
      return { success: false, result: sc.result ?? null, msg: `MCP isError: ${text}`, code: undefined, raw: callResult };
    }
    const success = typeof sc.success === 'boolean' ? sc.success : (sc.result != null);
    return {
      success,
      result: sc.result ?? null,
      msg: typeof sc.msg === 'string' ? sc.msg : (success ? '' : 'MCP 返回 success=false'),
      code: typeof sc.code === 'number' ? sc.code : undefined,
      raw: callResult,
    };
  } finally {
    session.close();
  }
}
