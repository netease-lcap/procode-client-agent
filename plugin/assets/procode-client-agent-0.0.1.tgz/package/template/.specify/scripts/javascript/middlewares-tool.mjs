globalThis.__SPECKIT_BAKED_MAPPING_REFS__ = [{"file":"datasources.json","list":"$.dataSources","host":"$.config.host","port":"$.config.port"},{"file":"middlewares.json","extractor":"middleware-endpoints"}];
/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/cli.mts
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/commands.ts
import path2 from "node:path";
import { createLogger } from "./shared/logger.mjs";

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/middlewares-io.ts
import fs from "node:fs";
import path from "node:path";
var MANIFEST_DIR = ".manifest";
var MIDDLEWARES_FILE_NAME = "middlewares.json";
var MiddlewaresFileError = class extends Error {
  exitCode = 3;
  constructor(message) {
    super(message);
    this.name = "MiddlewaresFileError";
  }
};
var MiddlewaresWriteError = class extends Error {
  exitCode = 5;
  constructor(message) {
    super(message);
    this.name = "MiddlewaresWriteError";
  }
};
function middlewaresFilePath(cwd) {
  return path.join(cwd, MANIFEST_DIR, MIDDLEWARES_FILE_NAME);
}
function emptyMiddlewares() {
  return { schemaVersion: 1, list: [] };
}
function readMiddlewares(cwd) {
  const file = middlewaresFilePath(cwd);
  if (!fs.existsSync(file)) return emptyMiddlewares();
  let raw;
  try {
    raw = fs.readFileSync(file, "utf-8");
  } catch (err) {
    throw new MiddlewaresFileError(`${MIDDLEWARES_FILE_NAME} \u8BFB\u53D6\u5931\u8D25\uFF1A${errMessage(err)}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new MiddlewaresFileError(`${MIDDLEWARES_FILE_NAME} \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage(err)}`);
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed) || !Array.isArray(parsed.list)) {
    throw new MiddlewaresFileError(
      `${MIDDLEWARES_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08\u9700 { schemaVersion, list } \u5F62\u6001\uFF0Clist \u5FC5\u987B\u4E3A\u6570\u7EC4\uFF09`
    );
  }
  const f = parsed;
  if (f.list.some((item) => item === null || typeof item !== "object" || Array.isArray(item))) {
    throw new MiddlewaresFileError(
      `${MIDDLEWARES_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08list \u6761\u76EE\u5FC5\u987B\u4E3A\u5BF9\u8C61\uFF0C\u5B58\u5728 null/\u975E\u5BF9\u8C61\u6761\u76EE\uFF09`
    );
  }
  return f;
}
function assertSchemaVersion(f) {
  if (f.schemaVersion !== 1) {
    throw new MiddlewaresFileError(`schemaVersion \u672A\u77E5\uFF08= ${f.schemaVersion}\uFF09\uFF0C\u4EC5\u652F\u6301 1\uFF0C\u62D2\u7EDD\u5199\u5165`);
  }
}
function atomicWriteMiddlewares(cwd, data) {
  const file = middlewaresFilePath(cwd);
  const dir = path.dirname(file);
  const tmp = path.join(dir, `.${MIDDLEWARES_FILE_NAME}.${process.pid}.${Date.now()}.tmp`);
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(tmp, `${JSON.stringify(data, null, 2)}
`, { mode: 384 });
    fs.renameSync(tmp, file);
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {
    }
    throw new MiddlewaresWriteError(`\u539F\u5B50\u5199\u5931\u8D25\uFF1A${errMessage(err)}`);
  }
}
function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/scheme.ts
var SCHEME_PATTERN = /^[a-z][a-z0-9+.-]*$/;
var HOST_PROTOCOL_PATTERN = /^([a-z][a-z0-9+.-]*):\/\/(.*)$/;
function normalizeEntry(entry) {
  const ep = entry.endpoint;
  if (!isPlainObject(ep)) return entry;
  const applyPair = (node) => {
    if (!isPlainObject(node) || typeof node.host !== "string") return;
    const m = node.host.match(HOST_PROTOCOL_PATTERN);
    if (m && m[2] !== "") {
      node.host = m[2];
      node.scheme = m[1];
    }
    if (node.scheme === "") delete node.scheme;
  };
  if (ep.kind === "host-port") {
    applyPair(ep);
  } else if (ep.kind === "generic") {
    if (Array.isArray(ep.targets)) ep.targets.forEach((t) => applyPair(t));
  }
  return entry;
}
function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/validate.ts
import { URL } from "node:url";

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/family-templates.ts
var DEFAULT_PORTS = {
  redis: 6379,
  sentinel: 26379,
  cluster: 6379,
  http: 80,
  https: 443,
  kafka: 9092,
  rabbitmq: 5672
};
function resolveDefaultPort(input) {
  switch (input.kind) {
    case "host-port":
    case "generic": {
      const table = DEFAULT_PORTS;
      if (!Object.prototype.hasOwnProperty.call(table, input.middleware)) return void 0;
      return table[input.middleware];
    }
    case "node-list":
      if (input.role === "sentinel") return DEFAULT_PORTS.sentinel;
      if (input.role === "cluster") return DEFAULT_PORTS.cluster;
      return void 0;
    case "url":
      if (input.urlScheme === "http") return DEFAULT_PORTS.http;
      if (input.urlScheme === "https") return DEFAULT_PORTS.https;
      return void 0;
    default:
      return void 0;
  }
}
var passwordTemplate = Object.freeze({
  key: "password",
  name: "\u5BC6\u7801",
  required: false,
  order: 10,
  lineRegion: "whole",
  inputType: "password",
  value: null,
  placeholder: "\u7559\u7A7A\u8868\u793A\u65E0\u5BC6\u7801"
});
var accessKeyTemplate = Object.freeze({
  key: "accessKey",
  name: "Access Key",
  required: true,
  order: 10,
  lineRegion: "half",
  inputType: "text",
  value: null
});
var accessSecretTemplate = Object.freeze({
  key: "accessSecret",
  name: "Secret Key",
  required: true,
  order: 11,
  lineRegion: "half",
  inputType: "password",
  value: null
});
var middlewareFamilyTemplates = {
  redis: [
    {
      middleware: "redis",
      label: "Redis \u5355\u673A",
      endpointKind: "host-port",
      requiredEndpointFields: ["host"],
      // port 可空 = 默认 6379
      propertyTemplate: [passwordTemplate],
      defaultPort: DEFAULT_PORTS.redis
    },
    {
      middleware: "redis",
      label: "Redis Sentinel",
      endpointKind: "node-list",
      role: "sentinel",
      requiredEndpointFields: ["masterName", "nodes"],
      // sentinel 时 masterName 必填
      propertyTemplate: [passwordTemplate],
      defaultPort: DEFAULT_PORTS.sentinel
    },
    {
      middleware: "redis",
      label: "Redis Cluster",
      endpointKind: "node-list",
      role: "cluster",
      requiredEndpointFields: ["nodes"],
      // 惯例 ≥3、门槛 ≥1
      propertyTemplate: [passwordTemplate],
      defaultPort: DEFAULT_PORTS.cluster
    }
  ],
  s3: [
    {
      middleware: "s3",
      label: "S3 \u5BF9\u8C61\u5B58\u50A8",
      endpointKind: "url",
      requiredEndpointFields: ["endPoint", "bucketName", "pathStyleAccess"],
      propertyTemplate: [accessKeyTemplate, accessSecretTemplate]
      // accessKey/accessSecret required=true
      // 无 defaultPort：url 族端口按 URL scheme 默认（http 80 / https 443）
    }
  ]
};

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/validate-types.ts
function isNonEmptyString(v) {
  return typeof v === "string" && v.length > 0;
}
function isPlainObject2(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/validate.ts
var PRIVATE_HOST_PATTERNS = [/^127\./, /^10\./, /^192\.168\./, /^172\.(1[6-9]|2\d|3[01])\./];
function isPrivateHost(hostname) {
  return hostname === "localhost" || PRIVATE_HOST_PATTERNS.some((re) => re.test(hostname));
}
function checkPairSchemeHost(node, target, errors, warnings) {
  if (!isPlainObject2(node)) return;
  if (node.scheme !== void 0) {
    if (typeof node.scheme !== "string" || node.scheme !== "" && !SCHEME_PATTERN.test(node.scheme)) {
      errors.push({ target: `${target}.scheme`, message: "scheme \u683C\u5F0F\u975E\u6CD5\uFF08\u987B\u5339\u914D ^[a-z][a-z0-9+.-]*$\uFF09" });
    }
  }
  if (isNonEmptyString(node.host)) {
    const m = node.host.match(HOST_PROTOCOL_PATTERN);
    if (m) {
      if (m[2] === "") {
        errors.push({ target: `${target}.host`, message: "host \u5265\u79BB\u534F\u8BAE\u524D\u7F00\u540E\u4E3A\u7A7A\uFF0C\u8BF7\u586B\u5199\u6709\u6548\u4E3B\u673A\u5730\u5740" });
      } else if (m[2].includes(":")) {
        errors.push({ target: `${target}.host`, message: "host \u4E0D\u5E94\u5305\u542B\u7AEF\u53E3\uFF0C\u8BF7\u628A\u7AEF\u53E3\u586B\u5230\u7AEF\u53E3\u5B57\u6BB5" });
      } else {
        warnings.push({ target: `${target}.host`, message: "host \u643A\u5E26\u534F\u8BAE\u524D\u7F00\uFF0C\u843D\u76D8\u65F6\u5C06\u5265\u79BB\u4E3A scheme \u5B57\u6BB5" });
      }
    } else if (node.host.includes("://")) {
      warnings.push({ target: `${target}.host`, message: "host \u542B\u7591\u4F3C\u534F\u8BAE\u524D\u7F00\u4F46\u683C\u5F0F\u975E\u6CD5\uFF0C\u5C06\u6309\u539F\u6837\u843D\u76D8\uFF0C\u8BF7\u786E\u8BA4" });
    } else if (node.host.includes(":")) {
      errors.push({ target: `${target}.host`, message: "host \u4E0D\u5E94\u5305\u542B\u7AEF\u53E3\uFF0C\u8BF7\u628A\u7AEF\u53E3\u586B\u5230\u7AEF\u53E3\u5B57\u6BB5" });
    }
  }
}
function validateEntry(e, opts = {}) {
  const requireFilled = opts.requireFilled === true;
  const errors = [];
  const warnings = [];
  if (!isNonEmptyString(e.name)) errors.push({ target: "name", message: "name \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32" });
  if (!isNonEmptyString(e.middleware)) errors.push({ target: "middleware", message: "middleware \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32" });
  if (!["init", "failed", "ok"].includes(e.status)) {
    errors.push({ target: "status", message: `status \u975E\u6CD5\uFF08= ${JSON.stringify(e.status)}\uFF09\uFF0C\u5408\u6CD5\u503C init|failed|ok` });
  }
  if (e.status === "failed" && !isNonEmptyString(e.lastError)) {
    errors.push({ target: "lastError", message: "status=failed \u65F6 lastError \u5FC5\u586B\uFF08\u975E\u7A7A\u5B57\u7B26\u4E32\uFF09" });
  }
  if (!isPlainObject2(e.endpoint)) {
    errors.push({ target: "endpoint", message: "endpoint \u5FC5\u987B\u4E3A\u5BF9\u8C61" });
  }
  if (!Array.isArray(e.properties)) {
    errors.push({ target: "properties", message: "properties \u5FC5\u987B\u4E3A\u6570\u7EC4" });
  }
  if (e.askError !== void 0) {
    if (!Array.isArray(e.askError)) {
      errors.push({ target: "askError", message: "askError \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A\u6570\u7EC4" });
    } else {
      e.askError.forEach((item, i) => {
        if (!isPlainObject2(item) || !isNonEmptyString(item.target) || !isNonEmptyString(item.message)) {
          errors.push({ target: `askError[${i}]`, message: "askError \u6BCF\u9879\u5FC5\u987B\u4E3A { target: string, message: string }" });
        }
      });
    }
  }
  if (e.updatedAt !== void 0 && typeof e.updatedAt !== "string") {
    errors.push({ target: "updatedAt", message: "updatedAt \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A string" });
  }
  if (isPlainObject2(e.endpoint)) {
    const endpoint = e.endpoint;
    const kind = endpoint.kind;
    if (!["host-port", "node-list", "url", "generic"].includes(kind)) {
      errors.push({
        target: "endpoint.kind",
        message: `endpoint.kind \u975E\u6CD5\uFF08= ${JSON.stringify(kind)}\uFF09\uFF0C\u5408\u6CD5\u503C host-port|node-list|url|generic`
      });
    } else if (kind === "host-port") {
      if (requireFilled && !isNonEmptyString(endpoint.host)) errors.push({ target: "endpoint.host", message: "host-port \u65CF host \u5FC5\u586B\uFF08\u975E\u7A7A\u5B57\u7B26\u4E32\uFF09" });
      if (endpoint.port !== void 0 && typeof endpoint.port !== "number") {
        errors.push({ target: "endpoint.port", message: "port \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A number" });
      }
      if (endpoint.port === void 0) {
        const p = resolveDefaultPort({ middleware: e.middleware, kind });
        if (p === void 0) {
          errors.push({ target: "endpoint.port", message: `\u672A\u77E5\u7C7B\u578B\uFF08middleware=${e.middleware}\uFF09\u5FC5\u987B\u663E\u5F0F\u7AEF\u53E3\uFF08Q10\uFF09` });
        }
      }
      checkPairSchemeHost(endpoint, "endpoint", errors, warnings);
    } else if (kind === "node-list") {
      if (!["sentinel", "cluster"].includes(endpoint.role)) {
        errors.push({
          target: "endpoint.role",
          message: `node-list \u65CF role \u975E\u6CD5\uFF08= ${JSON.stringify(endpoint.role)}\uFF09\uFF0C\u5408\u6CD5\u503C sentinel|cluster`
        });
      }
      if (requireFilled && endpoint.role === "sentinel" && !isNonEmptyString(endpoint.masterName)) {
        errors.push({ target: "endpoint.masterName", message: "sentinel \u65F6 masterName \u5FC5\u586B\uFF08\u975E\u7A7A\u5B57\u7B26\u4E32\uFF09" });
      }
      if (!Array.isArray(endpoint.nodes) || endpoint.nodes.length < 1) {
        errors.push({ target: "endpoint.nodes", message: "node-list \u65CF nodes \u5FC5\u987B\u4E3A\u975E\u7A7A\u6570\u7EC4\uFF08\u95E8\u69DB \u22651\uFF09" });
      } else {
        endpoint.nodes.forEach((node, i) => {
          if (!isPlainObject2(node)) {
            errors.push({ target: `endpoint.nodes[${i}]`, message: "\u8282\u70B9\u5FC5\u987B\u4E3A\u5BF9\u8C61" });
            return;
          }
          if (requireFilled && !isNonEmptyString(node.host)) {
            errors.push({ target: `endpoint.nodes[${i}].host`, message: "\u8282\u70B9 host \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32" });
          }
          if (isNonEmptyString(node.host) && node.host.includes("://")) {
            errors.push({ target: `endpoint.nodes[${i}].host`, message: "\u8282\u70B9\u5730\u5740\u4E0D\u5141\u8BB8\u643A\u5E26\u534F\u8BAE\u524D\u7F00\uFF0C\u8BF7\u53BB\u6389 http:// \u6216\u6539\u7528 url \u7AEF\u70B9" });
          }
          if (isNonEmptyString(node.host) && !node.host.includes("://") && node.host.includes(":")) {
            errors.push({ target: `endpoint.nodes[${i}].host`, message: "host \u4E0D\u5E94\u5305\u542B\u7AEF\u53E3\uFF0C\u8BF7\u628A\u7AEF\u53E3\u586B\u5230\u7AEF\u53E3\u5B57\u6BB5" });
          }
          if (node.scheme !== void 0) {
            errors.push({ target: `endpoint.nodes[${i}].scheme`, message: "node-list \u65CF\u4E0D\u4F7F\u7528 scheme \u5B57\u6BB5" });
          }
          if (node.port !== void 0 && typeof node.port !== "number") {
            errors.push({ target: `endpoint.nodes[${i}].port`, message: "\u8282\u70B9 port \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A number" });
          }
          if (node.port === void 0) {
            const p = resolveDefaultPort({ middleware: e.middleware, kind, role: endpoint.role });
            if (p === void 0) {
              errors.push({ target: `endpoint.nodes[${i}].port`, message: `\u672A\u77E5\u7C7B\u578B\uFF08role=${endpoint.role}\uFF09\u5FC5\u987B\u663E\u5F0F\u7AEF\u53E3\uFF08Q10\uFF09` });
            }
          }
        });
      }
    } else if (kind === "url") {
      if (requireFilled && !isNonEmptyString(endpoint.endPoint)) {
        errors.push({ target: "endpoint.endPoint", message: "url \u65CF endPoint \u5FC5\u586B\uFF08\u975E\u7A7A\u5B57\u7B26\u4E32\uFF09" });
      }
      if (requireFilled && !isNonEmptyString(endpoint.bucketName)) {
        errors.push({ target: "endpoint.bucketName", message: "url \u65CF bucketName \u5FC5\u586B\uFF08\u975E\u7A7A\u5B57\u7B26\u4E32\uFF09" });
      }
      if (typeof endpoint.pathStyleAccess !== "boolean") {
        errors.push({ target: "endpoint.pathStyleAccess", message: "url \u65CF pathStyleAccess \u5FC5\u987B\u4E3A boolean" });
      }
      if (endpoint.mapped !== void 0 && typeof endpoint.mapped !== "boolean") {
        errors.push({ target: "endpoint.mapped", message: "mapped \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A boolean" });
      }
      if (isNonEmptyString(endpoint.endPoint)) {
        let u = null;
        try {
          u = new URL(endpoint.endPoint);
        } catch {
          u = null;
        }
        if (!u) {
          errors.push({ target: "endpoint.endPoint", message: "endPoint \u65E0\u6CD5 URL \u89E3\u6790" });
        } else {
          if (!u.port) {
            const p = resolveDefaultPort({ middleware: e.middleware, kind, urlScheme: u.protocol.replace(/:$/, "") });
            if (p === void 0) {
              errors.push({
                target: "endpoint.endPoint",
                message: `url \u65CF\u65E0\u663E\u5F0F\u7AEF\u53E3\u4E14 scheme \u975E\u6CD5\uFF08${u.protocol}\uFF09\uFF0C\u4EC5 http/https \u6709\u9ED8\u8BA4\u7AEF\u53E3\uFF08Q10\uFF09`
              });
            }
          }
          if (isPrivateHost(u.hostname) && endpoint.mapped !== true) {
            warnings.push({ target: "endpoint.endPoint", message: "\u5185\u7F51 S3 \u5730\u5740\uFF0C\u8BF7\u786E\u8BA4 mapped=true \u8D70\u7AEF\u53E3\u6620\u5C04\uFF08Q9\uFF09" });
          }
        }
      }
    } else if (kind === "generic") {
      if (!Array.isArray(endpoint.targets)) {
        errors.push({ target: "endpoint.targets", message: "generic \u65CF targets \u5FC5\u987B\u4E3A\u6570\u7EC4\uFF08\u53EF\u4E3A\u7A7A\uFF0CQ3 \u7EAF HTTP \u4E2D\u95F4\u4EF6\uFF09" });
      } else {
        endpoint.targets.forEach((t, i) => {
          if (!isPlainObject2(t)) {
            errors.push({ target: `endpoint.targets[${i}]`, message: "target \u5FC5\u987B\u4E3A\u5BF9\u8C61" });
            return;
          }
          if (requireFilled && !isNonEmptyString(t.host)) {
            errors.push({ target: `endpoint.targets[${i}].host`, message: "target host \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32" });
          }
          checkPairSchemeHost(t, `endpoint.targets[${i}]`, errors, warnings);
          if (t.port !== void 0 && typeof t.port !== "number") {
            errors.push({ target: `endpoint.targets[${i}].port`, message: "target port \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A number" });
          }
          if (t.port === void 0) {
            const p = resolveDefaultPort({ middleware: e.middleware, kind });
            if (p === void 0) {
              errors.push({ target: `endpoint.targets[${i}].port`, message: `\u672A\u77E5\u7C7B\u578B\uFF08middleware=${e.middleware}\uFF09\u5FC5\u987B\u663E\u5F0F\u7AEF\u53E3\uFF08Q10\uFF09` });
            }
          }
        });
      }
    }
  }
  if (Array.isArray(e.properties)) {
    const seenKeys = /* @__PURE__ */ new Set();
    e.properties.forEach((p, i) => {
      const at = (field) => `properties[${i}].${field}`;
      if (!isPlainObject2(p)) {
        errors.push({ target: `properties[${i}]`, message: "properties \u6BCF\u9879\u5FC5\u987B\u4E3A\u5BF9\u8C61" });
        return;
      }
      if (!isNonEmptyString(p.key)) errors.push({ target: at("key"), message: "key \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32" });
      if (!isNonEmptyString(p.name)) errors.push({ target: at("name"), message: "name \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32" });
      if (typeof p.required !== "boolean") errors.push({ target: at("required"), message: "required \u5FC5\u987B\u4E3A boolean" });
      if (typeof p.order !== "number") errors.push({ target: at("order"), message: "order \u5FC5\u987B\u4E3A number" });
      if (!["whole", "half"].includes(p.lineRegion)) {
        errors.push({ target: at("lineRegion"), message: `lineRegion \u975E\u6CD5\uFF08= ${JSON.stringify(p.lineRegion)}\uFF09\uFF0C\u5408\u6CD5\u503C whole|half` });
      }
      if (!["text", "textarea", "number", "password", "select"].includes(p.inputType)) {
        errors.push({
          target: at("inputType"),
          message: `inputType \u975E\u6CD5\uFF08= ${JSON.stringify(p.inputType)}\uFF09\uFF0C\u5408\u6CD5\u503C text|textarea|number|password|select`
        });
      }
      if (p.inputType === "select") {
        if (!Array.isArray(p.selectValues) || p.selectValues.length < 1) {
          errors.push({ target: at("selectValues"), message: "inputType=select \u65F6 selectValues \u5FC5\u987B\u4E3A\u975E\u7A7A\u6570\u7EC4" });
        } else {
          p.selectValues.forEach((sv, j) => {
            if (!isPlainObject2(sv) || !isNonEmptyString(sv.name) || typeof sv.value !== "string") {
              errors.push({ target: `${at("selectValues")}[${j}]`, message: "selectValues \u6BCF\u9879\u5FC5\u987B\u4E3A { name: string, value: string }" });
            }
          });
        }
      }
      if (p.value !== null && p.value !== void 0 && typeof p.value !== "string" && typeof p.value !== "number") {
        errors.push({ target: at("value"), message: "value \u5FC5\u987B\u4E3A string | number | null" });
      }
      if (isNonEmptyString(p.key)) {
        if (seenKeys.has(p.key)) {
          errors.push({ target: at("key"), message: `properties \u5185 key \u91CD\u590D\uFF1A${p.key}` });
        } else {
          seenKeys.add(p.key);
        }
      }
      if (requireFilled && isNonEmptyString(p.key)) {
        if (p.required === true && p.value == null) {
          errors.push({ target: `properties.${p.key}`, message: `${p.name || p.key} \u4E3A\u5FC5\u586B\u9879\uFF0C\u5F53\u524D\u672A\u586B\u7B54` });
        }
        if (typeof p.regex === "string" && p.value !== null && p.value !== void 0 && p.value !== "") {
          if (!new RegExp(p.regex).test(String(p.value))) {
            errors.push({ target: `properties.${p.key}`, message: p.validateMessage || `\u503C\u4E0D\u7B26\u5408\u683C\u5F0F\u8981\u6C42\uFF08regex: ${p.regex}\uFF09` });
          }
        }
      }
    });
  }
  return { errors, warnings };
}
function validateFile(f, opts = {}) {
  const errors = [];
  const warnings = [];
  if (f.schemaVersion !== 1) {
    errors.push({ target: "schemaVersion", message: `\u672A\u77E5 schemaVersion\uFF08= ${JSON.stringify(f.schemaVersion)}\uFF09\uFF0C\u4EC5\u652F\u6301 1` });
  }
  if (!Array.isArray(f.list)) {
    errors.push({ target: "list", message: "list \u5FC5\u987B\u4E3A\u6570\u7EC4" });
    return { errors, warnings };
  }
  const seenNames = /* @__PURE__ */ new Set();
  f.list.forEach((item, i) => {
    const r = validateEntry(isPlainObject2(item) ? item : {}, opts);
    errors.push(...r.errors);
    warnings.push(...r.warnings);
    if (isNonEmptyString(item && item.name)) {
      if (seenNames.has(item.name)) {
        errors.push({ target: `list[${i}].name`, message: `name \u91CD\u590D\uFF1A${item.name}` });
      } else {
        seenNames.add(item.name);
      }
    }
  });
  return { errors, warnings };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/commands.ts
var EXIT = {
  OK: 0,
  USAGE: 2,
  INVALID: 3,
  NOT_FOUND: 4
};
var log = createLogger("middleware");
function workspaceRoot() {
  const home = process.env.HOME?.trim();
  if (!home) {
    process.stderr.write("HOME is unset; cannot resolve $HOME/resources\n");
    process.exit(2);
  }
  return path2.join(home, "resources");
}
var SUBCOMMAND_SPECS = {
  validate: {
    values: { "--entry": "entry" },
    switches: { "--require-filled": "requireFilled" },
    usage: "validate [--entry <json>] [--require-filled]",
    summary: "\u6821\u9A8C\u6574\u6587\u4EF6\u6216\u5355\u6761\u76EE\uFF1B--require-filled \u8FFD\u52A0\u7AEF\u70B9\u5FC5\u586B\u4E0E properties \u503C\u586B\u7B54\u6821\u9A8C"
  },
  upsert: {
    values: { "--entry": "entry" },
    switches: {},
    usage: "upsert --entry <json>",
    summary: "\u6309 name \u63D2\u5165\u6216\u6574\u6761\u76EE\u66FF\u6362\uFF08\u4EC5\u63A5\u53D7 status=init\uFF09"
  },
  delete: {
    values: { "--name": "name" },
    switches: {},
    usage: "delete --name <n>",
    summary: "\u6309\u540D\u5220\u9664\u6761\u76EE\uFF08\u672A\u547D\u4E2D exit 4\uFF09"
  },
  "set-status": {
    values: { "--name": "name", "--status": "status", "--last-error": "lastError" },
    switches: {},
    usage: "set-status --name <n> --status <ok|failed> [--last-error <e>]",
    summary: "\u72B6\u6001\u673A\u552F\u4E00\u5199\u5165\u53E3\uFF08failed \u5FC5\u5E26 --last-error\uFF09"
  },
  get: {
    values: { "--name": "name" },
    switches: {},
    usage: "get [--name <n>]",
    summary: "\u65E0\u53C2 = \u6574\u8868\uFF1B\u5E26\u53C2 = \u5355\u6761\u76EE\uFF08\u672A\u547D\u4E2D exit 4\uFF09"
  }
};
var USAGE_COLUMN_WIDTH = Math.max(...Object.values(SUBCOMMAND_SPECS).map((spec) => spec.usage.length)) + 2;
function usage(reason) {
  const lines = Object.entries(SUBCOMMAND_SPECS).map(
    ([, spec]) => `  ${spec.usage.padEnd(USAGE_COLUMN_WIDTH)}${spec.summary}`
  );
  process.stderr.write(
    `usage: middlewares-tool <${Object.keys(SUBCOMMANDS).join("|")}> ...
${lines.join("\n")}
\u53C2\u6570\u975E\u6CD5\uFF1A${reason}
`
  );
  log.error(`\u53C2\u6570\u975E\u6CD5\uFF1A${reason}`);
  process.exit(EXIT.USAGE);
}
function parseFlags(rest, subcommand) {
  const spec = SUBCOMMAND_SPECS[subcommand];
  const allowed = [...Object.keys(spec.values), ...Object.keys(spec.switches)];
  const values = {};
  const switches = {};
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    if (!allowed.includes(arg)) {
      usage(`\u672A\u77E5\u6216\u8D8A\u6743 flag\uFF1A${arg}\uFF08${subcommand} \u7684\u5141\u8BB8\u96C6\uFF1A${allowed.join(" ") || "(\u65E0)"}\uFF09`);
    }
    if (Object.prototype.hasOwnProperty.call(spec.switches, arg)) {
      switches[spec.switches[arg]] = true;
      continue;
    }
    if (i + 1 >= rest.length) usage(`flag \u7F3A\u503C\uFF1A${arg}`);
    values[spec.values[arg]] = rest[++i];
  }
  return { values, switches };
}
function exitWith(code, message, logMessage) {
  if (message) {
    process.stderr.write(`${message}
`);
    if (code !== EXIT.NOT_FOUND) log.error(logMessage ?? message);
  }
  process.exit(code);
}
function reportValidation({ errors, warnings }) {
  if (errors.length > 0) {
    process.stdout.write(`${JSON.stringify({ ok: false, errors })}
`);
    const summary = `\u6821\u9A8C\u5931\u8D25\uFF1A${errors.length} \u5904\u9519\u8BEF\uFF08\u9996\u5904\uFF1A${errors[0].target} ${errors[0].message}\uFF09`;
    process.stderr.write(`${summary}
`);
    log.error(summary);
    process.exit(EXIT.INVALID);
  }
  process.stdout.write(`${JSON.stringify({ ok: true, warnings })}
`);
  return EXIT.OK;
}
function persist(cwd, file, action) {
  const startedAt = Date.now();
  try {
    atomicWriteMiddlewares(cwd, file);
  } catch (err) {
    log.error(`${action} \u843D\u76D8\u5931\u8D25\uFF1A${errMessage2(err)}`);
    throw err;
  }
  log.tool(`${action} count=${file.list.length}`, {
    exit: EXIT.OK,
    ms: Date.now() - startedAt
  });
}
function cmdValidate(argv) {
  const { values, switches } = parseFlags(argv, "validate");
  const requireFilled = switches.requireFilled === true;
  if (values.entry !== void 0) {
    let parsed;
    try {
      parsed = JSON.parse(values.entry);
    } catch (err) {
      exitWith(EXIT.USAGE, `--entry \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage2(err)}`, "\u53C2\u6570\u975E\u6CD5\uFF1A--entry \u4E0D\u662F\u5408\u6CD5 JSON");
    }
    if (parsed === null) {
      exitWith(EXIT.USAGE, "--entry \u4E0D\u80FD\u4E3A null\uFF08\u5FC5\u987B\u4E3A\u5355\u4E2A\u6761\u76EE\u5BF9\u8C61 JSON\uFF09");
    }
    return reportValidation(validateEntry(parsed, { requireFilled }));
  }
  return reportValidation(validateFile(readMiddlewares(workspaceRoot()), { requireFilled }));
}
function cmdUpsert(argv) {
  const { values } = parseFlags(argv, "upsert");
  if (values.entry === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --entry");
  let entry;
  try {
    entry = JSON.parse(values.entry);
  } catch (err) {
    exitWith(EXIT.USAGE, `--entry \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage2(err)}`, "\u53C2\u6570\u975E\u6CD5\uFF1A--entry \u4E0D\u662F\u5408\u6CD5 JSON");
  }
  if (entry === null) {
    exitWith(EXIT.USAGE, "--entry \u4E0D\u80FD\u4E3A null\uFF08\u5FC5\u987B\u4E3A\u5355\u4E2A\u6761\u76EE\u5BF9\u8C61 JSON\uFF09");
  }
  const cwd = workspaceRoot();
  const file = readMiddlewares(cwd);
  assertSchemaVersion(file);
  if (entry.status !== "init") {
    return reportValidation({
      errors: [{ target: "status", message: "\u4EC5\u63A5\u53D7 status=init \u7684\u6761\u76EE\uFF08\u7EC8\u6001\u7F6E\u4F4D\u8D70 set-status\uFF0CG-1\uFF09" }],
      warnings: []
    });
  }
  const { errors } = validateEntry(entry);
  if (errors.length > 0) {
    return reportValidation({ errors, warnings: [] });
  }
  entry = normalizeEntry(entry);
  entry.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  file.list = file.list.filter((x) => x.name !== entry.name).concat([entry]);
  persist(cwd, file, `upsert name=${entry.name} status=${entry.status}`);
  process.stdout.write('{"ok":true}\n');
  return EXIT.OK;
}
function cmdDelete(argv) {
  const { values } = parseFlags(argv, "delete");
  if (values.name === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --name");
  const cwd = workspaceRoot();
  const file = readMiddlewares(cwd);
  assertSchemaVersion(file);
  const idx = file.list.findIndex((x) => x.name === values.name);
  if (idx === -1) exitWith(EXIT.NOT_FOUND, `\u672A\u627E\u5230\u6761\u76EE\uFF1A${values.name}`);
  file.list.splice(idx, 1);
  persist(cwd, file, `delete name=${values.name}`);
  process.stdout.write('{"ok":true}\n');
  return EXIT.OK;
}
function cmdSetStatus(argv) {
  const { values } = parseFlags(argv, "set-status");
  if (values.name === void 0 || values.status === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --name \u4E0E --status");
  if (values.status !== "ok" && values.status !== "failed") {
    exitWith(EXIT.USAGE, "--status \u4EC5\u652F\u6301 ok|failed\uFF08\u56DE init \u8D70 upsert\u2014\u2014\u7EC8\u6001\u7F6E\u4F4D\u552F\u4E00\u5199\u5165\u53E3\uFF0CC-1\uFF09");
  }
  if (values.status === "failed" && !values.lastError) {
    exitWith(EXIT.USAGE, "--status failed \u5FC5\u987B\u643A\u5E26 --last-error\uFF08failed \u5FC5\u586B lastError\uFF09");
  }
  const cwd = workspaceRoot();
  const file = readMiddlewares(cwd);
  assertSchemaVersion(file);
  const entry = file.list.find((x) => x.name === values.name);
  if (entry === void 0) exitWith(EXIT.NOT_FOUND, `\u672A\u627E\u5230\u6761\u76EE\uFF1A${values.name}`);
  entry.status = values.status;
  if (values.status === "failed") entry.lastError = values.lastError;
  else delete entry.lastError;
  entry.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  persist(cwd, file, `set-status name=${values.name} status=${values.status}`);
  process.stdout.write('{"ok":true}\n');
  return EXIT.OK;
}
function cmdGet(argv) {
  const { values } = parseFlags(argv, "get");
  const file = readMiddlewares(workspaceRoot());
  assertSchemaVersion(file);
  if (values.name === void 0) {
    process.stdout.write(`${JSON.stringify(file)}
`);
    return EXIT.OK;
  }
  const entry = file.list.find((x) => x.name === values.name);
  if (entry === void 0) exitWith(EXIT.NOT_FOUND, `\u672A\u627E\u5230\u6761\u76EE\uFF1A${values.name}`);
  process.stdout.write(`${JSON.stringify(entry)}
`);
  return EXIT.OK;
}
function guarded(fn) {
  return (argv) => {
    try {
      return fn(argv);
    } catch (err) {
      if (err instanceof MiddlewaresFileError || err instanceof MiddlewaresWriteError) {
        const category = err instanceof MiddlewaresWriteError ? "\u5199\u5931\u8D25" : "\u6821\u9A8C\u5931\u8D25";
        exitWith(err.exitCode, err.message, `${category}\uFF08exit ${err.exitCode}\uFF09\uFF1A${MIDDLEWARES_FILE_NAME}`);
      }
      throw err;
    }
  };
}
var SUBCOMMANDS = {
  validate: guarded(cmdValidate),
  upsert: guarded(cmdUpsert),
  delete: guarded(cmdDelete),
  "set-status": guarded(cmdSetStatus),
  get: guarded(cmdGet)
};
function errMessage2(err) {
  return err instanceof Error ? err.message : String(err);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/middleware/cli.mts
function main() {
  const [sub, ...rest] = process.argv.slice(2);
  const handler = sub !== void 0 && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, sub) ? SUBCOMMANDS[sub] : void 0;
  if (handler === void 0) {
    console.error(`\u672A\u77E5\u5B50\u547D\u4EE4\uFF1A${sub ?? "(\u65E0)"}\uFF1B\u53EF\u7528\uFF1A${Object.keys(SUBCOMMANDS).join(", ")}`);
    process.exit(2);
  }
  process.exit(handler(rest));
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  main();
}
export {
  SUBCOMMANDS
};
