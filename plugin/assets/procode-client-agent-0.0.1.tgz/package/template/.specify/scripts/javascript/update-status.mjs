import fs from 'fs';
import path from 'path';

import {
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  correctToFile,
  writeToLog,
  readFile,
  readdirSync,
  readFileSync,
  readJSONSync,
  auto,
} from './shared/index.mjs';

import phases from './output/phases.json' with { type: 'json' };

import checkMenus from './check-menus.mjs';
import checkPendings from './check-pendings.mjs';
import checkEverything from './check-everything.mjs';

const suffix = process?.env?.USE_SPECKIT_AGENT
  ? '，**必须**立刻终止所有操作（不要向用户输出任何信息），禁止执行下一阶段任务'
  : '';

export const STATUSES = ['running', 'done'];

export const updateStatus = async (rootDir) => {
  rootDir = rootDir || process.cwd();

  correctToFile();

  const [, , information = ''] = process.argv;

  const parts = information.split('/');
  const [rawCommand, current, predict, status] = parts;

  const command = rawCommand;

  const activeSpecDir = getActiveSpecDir();

  if (!activeSpecDir) {
    return '';
  }

  const activeSpecList = readdirSync(activeSpecDir);
  const statusFilePath = activeSpecList.find((item) => item.endsWith('status.json'));

  if (!statusFilePath) {
    return '缺少文件 status.json';
  }

  if (!STATUSES.includes(status)) {
    const prefix = command || 'plans';
    const merged = STATUSES.join('、');

    return `更新错误：状态只支持 ${merged}，示例输入数据，仅供参考：\`${prefix}/阶段一/阶段二/running\``;
  }

  // merge/commit 相位是纯机械 git/脚本步（merge 末段自带报告门、commit 自带语义提交），无
  // specs/plans 文档交付物——done 验收检查对它们无语义，且检查失败静默不落盘会触发外层
  // running 分支同阶段无限重跑（2026-09-20 沙箱 8046 实证 318 轮，见 plan 同日
  // merge-commit-skip-done-acceptance-checks）。prototype 同理（沙箱部署版先行，此处对齐）。
  const SKIP_DONE_CHECKS_COMMANDS = new Set(['build', 'client', 'tasks', 'menus', 'plan', 'specify', 'prototype', 'merge', 'commit']);
  const shouldSkipDoneChecks = SKIP_DONE_CHECKS_COMMANDS.has(command);

  if (status === 'done' && !shouldSkipDoneChecks) {
    // 在更新状态之前，先执行检查
    const checkResults = [
      {
        name: '文件验收检查',
        successMessage: '所有文件均已修改验收',
        result: await checkPendings(rootDir, ''),
      },
      {
        name: '不规范内容检查',
        successMessage: '未检测到任何不规范内容',
        result: await checkEverything(rootDir, ''),
      },
    ];

    // 如果有menus点markdown，则添加menus检查
    const menusMarkdownPath = `${activeSpecDir}/specs/menus.md`;
    if (command === 'specify' && fs.existsSync(menusMarkdownPath)) {
      checkResults.push({
        name: '功能模块目录检查',
        successMessage: '验收成功',
        result: await checkMenus(rootDir, ''),
      });
    }

    // 检查是否有任何检查失败
    for (const { name, result, successMessage } of checkResults) {
      const isSuccess = result?.includes?.(successMessage);

      if (!isSuccess) {
        const parts = [`# 必须先修复以下问题然后进行状态更新：`, '', result];

        writeToLog('update-status-check-failed', name, result);
        return parts.join('\n');
      }
    }
  }

  const statusAbsoluteFilePath = path.resolve(activeSpecDir, statusFilePath);
  const object = readJSONSync(statusAbsoluteFilePath) || {};

  const find = (item) => item.command === rawCommand;
  const found = phases.find(find) || {};

  const { phases: foundPhases = [] } = found;
  const { length } = foundPhases;

  const findPhase = (item = {}) => item.title === current;
  const foundPhase = foundPhases.find(findPhase);

  if (!foundPhase) {
    // 阶段未登记于 phases.json：历史上直接解构 undefined 裸抛 TypeError——无摘要、status.json
    // 永远写不进去 → 外层驱动读到 done+next 非空无限重派（2026-09-09 沙箱 plan 阶段四 45+ 轮实证）。
    // fail-loud 三要素（缺哪个阶段/注册表现有标题/可能原因）+ 非零 exit 让 wave status cmd 红停：
    // auto() 只 console.log 返回值、exit 恒 0，return 错误字符串过不了红门，必须显式 exit。
    const registered = foundPhases.map((item) => item.title).join('、') || '（空）';
    const digest = [
      `阶段未登记：\`${command}/${current}\` 不在 phases.json 的 ${command} 阶段列表中，状态未写入。`,
      `注册表现有阶段：${registered}。`,
      '可能原因：① 注册表过期——应由命令入口 rewritePhasesJsonFromGetPhases 按当前 workflow 重写（检查该调用是否执行或失败降级）；② 编排派发了未登记阶段——workflow 与注册表漂移，需对齐 spec-execute-service 的 getPhases 与 phases.json。',
    ].join('\n');
    writeToLog('update-status', '阶段未登记', information, statusAbsoluteFilePath);
    console.error(digest);
    process.exit(1);
  }

  const index = foundPhases.indexOf(foundPhase);
  const nextPhase = foundPhases[index + 1];

  const count = status === 'done' ? index + 1 : index || 0.5;
  const percent = count / length;
  // `key` 是阶段注册表的稳定身份（fresh micro 六阶段树为 outline/design-*/overview），不是
  // status 字段——从 `rest` 剥离，避免随 `...rest` 落进 status.json。
  const { title, description, key: registeredStageKey, ...rest } = foundPhase;

  const next = predict || nextPhase?.title || '';
  const prevStatus = object?.[command]?.status;

  writeToLog('update-status', '更新记录', prevStatus);

  // C0 阶段树 schema（plan 2026-10-21/design-blocked-repair-clarify-loop §6.2）：
  // `planStageSchemaVersion` / `planStageKey` / `planStageSkipArchitectureWave` 由旧断点迁移写入。
  // 本脚本按标题更新状态并**原样保留**版本/架构波跳过标记——否则一次 done 写回就会抹掉版本/
  // 架构波跳过标记，下次续跑会把已迁移的断点重新当成旧树（或重复进入架构波删除有效回执）。
  // `planStageKey` 例外：它是 current 标题的镜像，由下方 D4 从 phases.json 的条目 `key` 同步；
  // 条目缺 key 时才退化为保留既有值（不猜）。done 后下一步的 key 跟随仍由 getPhase 侧对账。
  const PLAN_STAGE_FIELD_NAMES = [
    'planStageSchemaVersion',
    'planStageKey',
    'planStageSkipArchitectureWave',
  ];
  const preservedPlanStageFields = {};
  for (const fieldName of PLAN_STAGE_FIELD_NAMES) {
    const previous = object?.[command]?.[fieldName];
    if (previous !== undefined) preservedPlanStageFields[fieldName] = previous;
  }

  // D4（plan 2026-10-21/toolchain-normalization-and-fixed-role-routing §D4）：`planStageKey` 是
  // current 标题的镜像，唯一来源是**同一份注册表** `phases.json` 里对应条目的 `key`。只写标题不写
  // key 会让首次迁移按证据判定的阶段（如 design-public）在后续`阶段三`运行时永久漂移。
  // 不复用 `preservedPlanStageFields.planStageKey`：那是上一次断点的值，正是漂移的来源。
  const syncedPlanStageKey =
    command === 'plan' && typeof registeredStageKey === 'string' && registeredStageKey
      ? registeredStageKey
      : '';
  if (command === 'plan' && !syncedPlanStageKey) {
    // 不发明 key、不从标题反推：保持既有字段（preservedPlanStageFields 原样保留）并走既有告警通道。
    // phases.json 由 rewritePhasesJsonFromGetPhases 按 getPhases 重写；条目缺 key 说明注册表序列化
    // 丢了稳定身份，需从注册表侧修复，而不是在本脚本里猜。
    const missingKeyMessage = `阶段 key 缺失：phases.json 的 plan/${current} 条目没有 key，status.planStageKey 保持既有值（未按标题反推）。`;
    console.warn(`[update-status] ${missingKeyMessage}`);
    writeToLog('update-status', '阶段 key 缺失', `${command}/${current}`, statusAbsoluteFilePath);
  }

  object[command] = {
    current,
    next,
    status,
    percent,
    ...rest,
    ...preservedPlanStageFields,
    ...(syncedPlanStageKey ? { planStageKey: syncedPlanStageKey } : {}),
  };

  const json = JSON.stringify(object, null, 2);

  writeToLog('update-status', '更新成功', information, statusAbsoluteFilePath);
  fs.writeFileSync(statusAbsoluteFilePath, json);

  if (status === 'done') {
    return `状态已更新${suffix}`;
  }

  return '';
};

auto(import.meta)(updateStatus);
export default updateStatus;
