/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/platform/cli.mts
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { createLogger } from "./shared/logger.mjs";

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/channel.ts
import http from "node:http";
import https from "node:https";

// src/utils/customWaveAgent/speckit/config/shared/platform/errors.ts
var PlatformError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "PlatformError";
  }
};

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/channel.ts
var DEFAULT_BASE_URL = "http://lcap.low-code:22988";
var DEFAULT_TIMEOUT_MS = 6e4;
var MAX_RETRIES = 3;
var INITIAL_RETRY_DELAY_MS = 500;
var TRANSIENT_NETWORK_CODES = /* @__PURE__ */ new Set(["ECONNREFUSED", "ECONNRESET", "EPIPE", "ETIMEDOUT", "EAI_AGAIN"]);
var TransientPlatformError = class extends PlatformError {
};
function isTransientNetworkError(error) {
  if (!error || typeof error !== "object" || !("code" in error)) return false;
  return TRANSIENT_NETWORK_CODES.has(String(error.code));
}
function retryDelayMs(retryIndex) {
  const base = INITIAL_RETRY_DELAY_MS * 2 ** retryIndex;
  return Math.round(base * (0.8 + Math.random() * 0.4));
}
function exhausted(error, attempts) {
  return new PlatformError(`${error.message}\uFF08\u5DF2\u5C1D\u8BD5 ${attempts} \u6B21\uFF09`, { cause: error });
}
var LOCAL_RUN_HINT = "\uFF1B\u672C\u5730\u590D\u8DD1\u8BF7 `node scripts/mock-platform.mjs` \u5E76\u8BBE `PLATFORM_DB_API_BASE_URL`\uFF08\u6216\u7528 `npm run plan:local-mock -- <\u547D\u4EE4>`\uFF09\uFF0C\u6C99\u7BB1\u9ED8\u8BA4\u8D70 `lcap.low-code:22988`";
var testTransport = null;
function resolveBaseUrl() {
  return process.env.PLATFORM_DB_API_BASE_URL?.trim() || process.env.SBX_LCAP_BASE_URL?.trim() || DEFAULT_BASE_URL;
}
function resolveTimeoutMs() {
  const raw = Number(process.env.PLATFORM_DB_API_TIMEOUT_MS);
  return Number.isFinite(raw) && raw > 0 ? raw : DEFAULT_TIMEOUT_MS;
}
function resolveHttpProxy(targetUrl) {
  const proxyEnv = process.env.HTTP_PROXY || process.env.http_proxy;
  if (!proxyEnv) return null;
  const noProxy = process.env.NO_PROXY || process.env.no_proxy || "";
  try {
    const targetHost = new URL(targetUrl).hostname;
    const hit = noProxy.split(",").map((s) => s.trim()).filter(Boolean).some((pat) => {
      if (pat === "*") return true;
      return targetHost === pat || targetHost.endsWith(pat.startsWith(".") ? pat : "." + pat);
    });
    if (hit) return null;
  } catch {
  }
  try {
    return new URL(proxyEnv);
  } catch {
    return null;
  }
}
async function callPlatformApi(req) {
  if (!req.path.startsWith("/internal/")) {
    throw new PlatformError(`\u5E73\u53F0 internal path \u975E\u6CD5\uFF1A${req.path}`);
  }
  if (testTransport) {
    return testTransport(req);
  }
  return realHttpTransport(req);
}
async function realHttpTransport(req) {
  const baseUrl = resolveBaseUrl();
  const url = `${baseUrl}${req.path}`;
  const bodyText = req.body === void 0 ? void 0 : JSON.stringify(req.body);
  if (!req.retry) {
    try {
      return await requestPlatform(req, url, resolveTimeoutMs(), bodyText);
    } catch (error) {
      if (error instanceof TransientPlatformError) {
        throw new PlatformError(error.message, error.cause === void 0 ? void 0 : { cause: error.cause });
      }
      throw error;
    }
  }
  let attempts = 0;
  for (; ; ) {
    attempts += 1;
    try {
      return await requestPlatform(req, url, resolveTimeoutMs(), bodyText, true);
    } catch (error) {
      if (!(error instanceof TransientPlatformError)) throw error;
      if (attempts > MAX_RETRIES) throw exhausted(error, attempts);
      await new Promise((resolve) => setTimeout(resolve, retryDelayMs(attempts - 1)));
    }
  }
}
async function requestPlatform(req, url, timeoutMs, bodyText, enforceWallClockTimeout = false) {
  const isHttps = url.startsWith("https://");
  const mod = isHttps ? https : http;
  let requestUrl;
  try {
    requestUrl = new URL(url);
  } catch (error) {
    throw new PlatformError(`\u5E73\u53F0 base url \u914D\u7F6E\u975E\u6CD5\uFF08PLATFORM_DB_API_BASE_URL/SBX_LCAP_BASE_URL \u89E3\u6790\u5931\u8D25\uFF09`, {
      cause: error
    });
  }
  const headers = { Accept: "application/json" };
  if (req.body !== void 0) {
    headers["Content-Type"] = "application/json";
    headers["Content-Length"] = String(Buffer.byteLength(bodyText));
  }
  const proxy = isHttps ? null : resolveHttpProxy(url);
  const options = proxy ? {
    method: req.method,
    hostname: proxy.hostname,
    port: proxy.port || (proxy.protocol === "https:" ? 443 : 80),
    path: url,
    headers: { ...headers, Host: requestUrl.host },
    timeout: timeoutMs
  } : {
    method: req.method,
    hostname: requestUrl.hostname,
    port: requestUrl.port || (isHttps ? 443 : 80),
    path: `${requestUrl.pathname}${requestUrl.search}`,
    headers,
    timeout: timeoutMs
  };
  return new Promise((resolve, reject) => {
    const clientReq = mod.request(options, (res) => {
      const chunks = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("error", (error) => {
        const ErrorClass = isTransientNetworkError(error) ? TransientPlatformError : PlatformError;
        reject(new ErrorClass(`\u5E73\u53F0\u63A5\u53E3\u54CD\u5E94\u4E2D\u65AD\uFF08${req.method} ${req.path}\uFF09`, { cause: error }));
      });
      res.on("end", () => {
        const status = res.statusCode ?? 0;
        const text = Buffer.concat(chunks).toString("utf-8");
        if (status < 200 || status >= 300) {
          const ErrorClass = status >= 500 && status < 600 ? TransientPlatformError : PlatformError;
          reject(new ErrorClass(`\u5E73\u53F0\u63A5\u53E3\u8FD4\u56DE HTTP ${status}\uFF08${req.method} ${req.path}\uFF09${LOCAL_RUN_HINT}`));
          return;
        }
        try {
          resolve(JSON.parse(text));
        } catch (error) {
          reject(
            new PlatformError(`\u5E73\u53F0\u63A5\u53E3\u8FD4\u56DE\u975E JSON \u54CD\u5E94\uFF08${req.method} ${req.path}\uFF09`, {
              cause: error
            })
          );
        }
      });
    });
    clientReq.on("timeout", () => {
      clientReq.destroy(
        new TransientPlatformError(`\u5E73\u53F0\u63A5\u53E3\u8C03\u7528\u8D85\u65F6 ${timeoutMs}ms\uFF08${req.method} ${req.path}\uFF09${LOCAL_RUN_HINT}`)
      );
    });
    if (enforceWallClockTimeout) {
      const timer = setTimeout(() => {
        clientReq.destroy(new TransientPlatformError(
          `\u5E73\u53F0\u63A5\u53E3\u8C03\u7528\u8D85\u65F6 ${timeoutMs}ms\uFF08${req.method} ${req.path}\uFF09${LOCAL_RUN_HINT}`
        ));
      }, timeoutMs);
      clientReq.on("close", () => clearTimeout(timer));
    }
    clientReq.on("error", (error) => {
      if (error instanceof PlatformError) {
        reject(error);
        return;
      }
      const ErrorClass = isTransientNetworkError(error) ? TransientPlatformError : PlatformError;
      reject(new ErrorClass(`\u5E73\u53F0\u63A5\u53E3\u7F51\u7EDC\u8C03\u7528\u5931\u8D25\uFF08${req.method} ${req.path}\uFF09${LOCAL_RUN_HINT}`, { cause: error }));
    });
    if (bodyText !== void 0) {
      clientReq.write(bodyText);
    }
    clientReq.end();
  });
}

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/appconfig/client.ts
var APPCONFIG_API_PATH_PREFIX = "/internal/v3/cwportal/procode/appconfig";
async function callAppConfigApi(req) {
  return callPlatformApi({
    ...req,
    path: `${APPCONFIG_API_PATH_PREFIX}${req.path}`
  });
}

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/normalize.ts
var TARGET_KEY = {
  mysql8: "database",
  oracle: "connectionTarget",
  postgresql: "database",
  sqlserver: "database"
};
var SCHEMA_NAME_TYPES = /* @__PURE__ */ new Set(["postgresql", "sqlserver"]);
var CONNECTED_MODE_TYPES = /* @__PURE__ */ new Set(["oracle"]);
var FALLBACK_TARGET_KEY = "database";
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function nonEmptyString(value) {
  return typeof value === "string" && value.length > 0 ? value : null;
}
function stringOrNull(value) {
  return typeof value === "string" ? value : null;
}
function normalizeDataSourceEntry(response) {
  if (!isRecord(response) || typeof response.code !== "number") {
    throw new PlatformError("\u5E73\u53F0\u6570\u636E\u6E90\u67E5\u8BE2\u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF08\u7F3A code \u5B57\u6BB5\uFF09");
  }
  const envelope = response;
  if (envelope.code === 401750) {
    return null;
  }
  if (envelope.code !== 200) {
    throw new PlatformError(
      `\u5E73\u53F0\u67E5\u8BE2\u6570\u636E\u6E90\u914D\u7F6E\u5931\u8D25\uFF08code=${envelope.code}\uFF09\uFF1A${envelope.msg ?? ""}`
    );
  }
  if (envelope.result === null || envelope.result === void 0) {
    return null;
  }
  if (!isRecord(envelope.result)) {
    throw new PlatformError("\u5E73\u53F0\u6570\u636E\u6E90\u67E5\u8BE2\u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF08result \u975E object\uFF09");
  }
  const config2 = buildConfig(envelope.result);
  if (config2 === null) {
    return null;
  }
  return {
    config: config2,
    // 原样取值（**不枚举**）：平台类型与模式都是动态的，门面不维护白名单——未给即 `null`。
    databaseType: nonEmptyString(envelope.result.databaseType),
    databaseMode: nonEmptyString(envelope.result.databaseMode)
  };
}
function resolveTargetKey(databaseType) {
  if (databaseType === null) return FALLBACK_TARGET_KEY;
  return TARGET_KEY[databaseType] ?? FALLBACK_TARGET_KEY;
}
function buildConfig(raw) {
  const host = nonEmptyString(raw.databaseHost);
  const port = nonEmptyString(
    typeof raw.databasePort === "number" ? String(raw.databasePort) : raw.databasePort
  );
  const username = nonEmptyString(raw.databaseUsername);
  const password = nonEmptyString(raw.databasePassword);
  if (host === null || port === null || username === null || password === null) {
    return null;
  }
  const config2 = { host, port, username, password };
  const customSetting = nonEmptyString(raw.customSetting);
  if (customSetting !== null) config2.customSetting = customSetting;
  const databaseType = nonEmptyString(raw.databaseType);
  const target = nonEmptyString(raw.databaseName);
  if (target !== null) {
    config2[resolveTargetKey(databaseType)] = target;
  }
  if (databaseType !== null && SCHEMA_NAME_TYPES.has(databaseType)) {
    const schemaName = stringOrNull(raw.databaseSchemaName);
    if (schemaName !== null) config2.schemaName = schemaName;
  }
  if (databaseType !== null && CONNECTED_MODE_TYPES.has(databaseType)) {
    const connectedMode = nonEmptyString(raw.databaseDriverType);
    if (connectedMode !== null) config2.connectedMode = connectedMode;
  }
  return config2;
}

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/proapp/service-domains.ts
var SERVICE_DOMAINS_PATH = "/internal/v3/cwportal/procode/proapp/preview-domains";
function nonEmptyString2(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}
function normalizeDomain(value) {
  const raw = nonEmptyString2(value);
  if (!raw) return null;
  try {
    return new URL(raw.includes("://") ? raw : `https://${raw}`).hostname;
  } catch {
    return null;
  }
}
function joinUrl(source, basePath) {
  const raw = source.includes("://") ? source : `https://${source}`;
  const url = new URL(raw);
  const currentPath = url.pathname.replace(/\/$/, "") || "/";
  const normalizedBasePath = basePath === "/" ? "/" : basePath.replace(/\/$/, "");
  const hasBasePath = normalizedBasePath === "/" || currentPath === normalizedBasePath || currentPath.endsWith(normalizedBasePath) && currentPath.charAt(currentPath.length - normalizedBasePath.length - 1) === "/";
  if (!hasBasePath) {
    url.pathname = `${currentPath === "/" ? "" : currentPath}${basePath}`;
  }
  url.search = "";
  url.hash = "";
  return url.toString().replace(/\/$/, "");
}
function normalizeServiceDomains(result) {
  if (!Array.isArray(result)) throw new PlatformError("LCAP \u670D\u52A1\u57DF\u540D\u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF1Aresult \u5E94\u4E3A\u6570\u7EC4");
  const output = [];
  const seen = /* @__PURE__ */ new Set();
  for (const [index, value] of result.entries()) {
    if (!value || typeof value !== "object" || Array.isArray(value))
      throw new PlatformError(`LCAP \u670D\u52A1\u57DF\u540D\u6761\u76EE\u975E\u6CD5\uFF1Aresult[${index}]`);
    const raw = value;
    const serviceName = nonEmptyString2(raw.serviceName);
    if (!serviceName && nonEmptyString2(raw.domain) && raw.frontends == null) continue;
    const domain = normalizeDomain(raw.domain);
    if (!serviceName || !domain || seen.has(serviceName) || !Array.isArray(raw.frontends) || !raw.frontends.length)
      throw new PlatformError(`LCAP \u670D\u52A1\u57DF\u540D\u6761\u76EE\u975E\u6CD5\uFF1Aresult[${index}]`);
    seen.add(serviceName);
    const endpoints = raw.frontends.map((value2, endpointIndex) => {
      if (!value2 || typeof value2 !== "object" || Array.isArray(value2))
        throw new PlatformError(`LCAP \u670D\u52A1\u57DF\u540D\u5165\u53E3\u975E\u6CD5\uFF1Aresult[${index}].frontends[${endpointIndex}]`);
      const frontend = value2;
      const type = nonEmptyString2(frontend.frontendType);
      const businessType = nonEmptyString2(frontend.businessType);
      const title = nonEmptyString2(frontend.frontendTitle);
      const basePath = nonEmptyString2(frontend.basePath);
      const frontendUrl = nonEmptyString2(frontend.frontendUrl);
      if (!["pc", "h5", "api"].includes(type ?? "") || !["application", "prototype"].includes(businessType ?? "") || !title || !basePath?.startsWith("/") || !frontendUrl || normalizeDomain(frontendUrl) !== domain)
        throw new PlatformError(`LCAP \u670D\u52A1\u57DF\u540D\u5165\u53E3\u975E\u6CD5\uFF1Aresult[${index}].frontends[${endpointIndex}]`);
      let url;
      try {
        url = joinUrl(frontendUrl, basePath);
      } catch {
        throw new PlatformError(`LCAP \u670D\u52A1\u57DF\u540D\u5165\u53E3 URL \u975E\u6CD5\uFF1Aresult[${index}].frontends[${endpointIndex}]`);
      }
      return {
        type,
        businessType,
        title,
        basePath,
        url
      };
    });
    output.push({ serviceName, domain, endpoints });
  }
  return output;
}
async function getServiceDomainsFromPlatform(context) {
  for (const [key, value] of Object.entries(context)) {
    if (!nonEmptyString2(value)) throw new PlatformError(`\u670D\u52A1\u57DF\u540D\u67E5\u8BE2\u4E0A\u4E0B\u6587\u7F3A\u5931\uFF1A${key}`);
  }
  const query = new URLSearchParams({
    appId: context.appId,
    collaborationId: context.collaborationId
  });
  const response = await callPlatformApi({
    method: "GET",
    path: `${SERVICE_DOMAINS_PATH}?${query.toString()}`,
    retry: true
  });
  if (!response || typeof response !== "object" || Array.isArray(response) || typeof response.code !== "number") {
    throw new PlatformError("LCAP \u670D\u52A1\u57DF\u540D\u67E5\u8BE2\u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF1A\u54CD\u5E94\u4FE1\u5C01\u975E\u6CD5");
  }
  if (response.code !== 200) {
    throw new PlatformError(`LCAP \u670D\u52A1\u57DF\u540D\u67E5\u8BE2\u5931\u8D25\uFF1Acode=${response.code ?? "N/A"} msg=${response.msg || "(\u65E0 msg)"}`);
  }
  return normalizeServiceDomains(response.result);
}

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/proapp/frontends.ts
var REGISTER_APP_FRONTENDS_PATH = "/internal/v3/cwportal/procode/proapp/frontend/register";
async function registerAppFrontends(request) {
  const response = await callPlatformApi({
    method: "POST",
    path: REGISTER_APP_FRONTENDS_PATH,
    body: request,
    retry: true
  });
  if (!response || typeof response !== "object" || Array.isArray(response) || typeof response.code !== "number")
    throw new PlatformError("LCAP \u4E1A\u52A1\u7AEF\u6CE8\u518C\u54CD\u5E94\u7ED3\u6784\u5F02\u5E38\uFF1A\u54CD\u5E94\u4FE1\u5C01\u975E\u6CD5");
  if (response.code !== 200) {
    throw new PlatformError(`LCAP \u4E1A\u52A1\u7AEF\u6CE8\u518C\u5931\u8D25\uFF1Acode=${response.code ?? "N/A"} msg=${response.msg || "(\u65E0 msg)"}`);
  }
  if (response.result == null) return void 0;
  return normalizeServiceDomains(response.result);
}

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/queries.ts
var SUPPORTED_MODES = [
  "Platform_Generation",
  "Manual_Configuration"
];
async function listDatabaseTypeInfos() {
  const response = await callAppConfigApi({ method: "GET", path: "/database/types", retry: true });
  if (response.code !== 200) {
    throw new PlatformError(`\u5E73\u53F0\u67E5\u8BE2\u6570\u636E\u5E93\u7C7B\u578B\u6E05\u5355\u5931\u8D25\uFF08code=${response.code}\uFF09\uFF1A${response.msg ?? ""}`);
  }
  const list = Array.isArray(response.result) ? response.result : [];
  return list.filter((entry) => {
    return typeof entry === "object" && entry !== null;
  }).map((entry) => {
    if (typeof entry.databaseName !== "string" || typeof entry.displayName !== "string") {
      throw new PlatformError("\u5E73\u53F0\u7C7B\u578B\u6E05\u5355\u6761\u76EE\u7ED3\u6784\u5F02\u5E38\uFF08databaseName/displayName \u7F3A\u5931\uFF09");
    }
    return {
      // 不枚举数据库名称、无别名映射——接口返回什么字面值，type 就是什么（2026-09-17 用户裁定）
      type: entry.databaseName,
      displayName: entry.displayName,
      modes: [...SUPPORTED_MODES]
    };
  });
}
async function checkDatabaseTypeSupported(type) {
  const infos = await listDatabaseTypeInfos();
  return infos.some((info) => info.type === type);
}

// src/utils/customWaveAgent/speckit/config/shared/platform/platform.ts
async function isDatabaseTypeSupported(type) {
  return checkDatabaseTypeSupported(type);
}
async function listDatabaseTypes() {
  return listDatabaseTypeInfos();
}
async function getDataSourceEntry(appId, dataSourceName) {
  return normalizeDataSourceEntry(await queryDataSource(appId, dataSourceName));
}
async function queryDataSource(appId, dataSourceName) {
  return callAppConfigApi({
    method: "POST",
    path: "/database/plaintext/query",
    body: { appId, dataSourceName },
    retry: true
  });
}
async function registerAppFrontends2(request) {
  return registerAppFrontends(request);
}
async function getServiceDomains(context) {
  return getServiceDomainsFromPlatform(context);
}

// src/utils/customWaveAgent/speckit/config/shared/platform/impl/proapp/local-mock.ts
import fs from "node:fs/promises";
import fsSync from "node:fs";
import path from "node:path";
import os from "node:os";
import { createHash, randomUUID } from "node:crypto";
function localMockServiceDomain(serviceName) {
  if (/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/.test(serviceName))
    return `${serviceName.toLowerCase()}.deploy.local.test`;
  const hex = Buffer.from(serviceName, "utf8").toString("hex");
  if (!hex) throw new Error("\u672C\u5730 deploy mock \u670D\u52A1\u540D\u4E0D\u80FD\u4E3A\u7A7A");
  return `encoded.${hex.match(/.{1,60}/g).map((part) => "x" + part).join(".")}.deploy.local.test`;
}
var STATE_FILE = "deploy-local-mock-state.json";
var LOCK_DIR = ".deploy-local-mock.lock";
var nonEmpty = (value) => typeof value === "string" && value.trim().length > 0;
var record = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
function config(cwd, env) {
  const override = env.DEPLOY_MOCK_STATE_DIR;
  if (override !== void 0 && !path.isAbsolute(override))
    throw new Error("DEPLOY_MOCK_STATE_DIR \u5FC5\u987B\u662F\u5DF2\u5B58\u5728\u7684\u7EDD\u5BF9\u76EE\u5F55");
  const stateDir = override ?? path.join(
    os.tmpdir(),
    "hicode-deploy-local-mock",
    createHash("sha256").update(fsSync.realpathSync(cwd)).digest("hex").slice(0, 20)
  );
  if (override === void 0) fsSync.mkdirSync(stateDir, { recursive: true });
  try {
    if (!fsSync.statSync(stateDir).isDirectory()) throw new Error("not-directory");
    fsSync.accessSync(stateDir, fsSync.constants.W_OK);
  } catch {
    throw new Error("DEPLOY_MOCK_STATE_DIR \u4E0D\u5B58\u5728\u6216\u4E0D\u53EF\u5199");
  }
  const domainsFile = env.DEPLOY_MOCK_DOMAINS_FILE;
  if (domainsFile && !path.isAbsolute(domainsFile)) throw new Error("DEPLOY_MOCK_DOMAINS_FILE \u5FC5\u987B\u662F\u7EDD\u5BF9\u8DEF\u5F84");
  return domainsFile ? { stateDir, domainsFile } : { stateDir };
}
function validTarget(value) {
  if (!record(value)) return false;
  return nonEmpty(value.appId) && nonEmpty(value.collaborationId) && nonEmpty(value.branchName) && Array.isArray(value.frontends) && value.frontends.every((item) => record(item) && nonEmpty(item.serviceName) && nonEmpty(item.title) && nonEmpty(item.basePath) && item.basePath.startsWith("/") && typeof item.type === "string" && ["pc", "h5", "api"].includes(item.type) && typeof item.businessType === "string" && ["application", "prototype"].includes(item.businessType)) && Array.isArray(value.serviceMappings) && value.serviceMappings.every((item) => record(item) && nonEmpty(item.serviceName) && nonEmpty(item.inboundBasePath) && item.inboundBasePath.startsWith("/"));
}
async function readState(stateDir) {
  let content;
  try {
    content = await fs.readFile(path.join(stateDir, STATE_FILE), "utf8");
  } catch (error) {
    if (error.code === "ENOENT")
      return { version: 1, mappings: {}, lastTarget: null, submissions: [] };
    throw error;
  }
  let value;
  try {
    value = JSON.parse(content);
  } catch {
    throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u6587\u4EF6\u4E0D\u662F JSON");
  }
  if (!record(value) || value.version !== 1 || !record(value.mappings) || !("lastTarget" in value) || !Array.isArray(value.submissions) || value.lastTarget !== null && !validTarget(value.lastTarget) || value.submissions.some((item) => !record(item) || !nonEmpty(item.at) || !validTarget(item.target)) || Object.entries(value.mappings).some(([key, mapping]) => !record(mapping) || !Number.isInteger(Number(key)) || String(Number(key)) !== key || mapping.listen !== Number(key) || !Number.isInteger(mapping.connect) || mapping.connect < 1 || mapping.connect > 65535 || typeof mapping.key !== "string" && typeof mapping.key !== "number" || !nonEmpty(String(mapping.key)) || !nonEmpty(mapping.path) || !mapping.path.startsWith("/")))
    throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u5185\u5BB9\u635F\u574F");
  return value;
}
function project(target) {
  if (!validTarget(target)) throw new Error("\u672C\u5730 deploy mock \u9884\u89C8\u76EE\u6807\u7ED3\u6784\u975E\u6CD5");
  const grouped = /* @__PURE__ */ new Map();
  for (const frontend of target.frontends) {
    let service = grouped.get(frontend.serviceName);
    if (!service) {
      service = { serviceName: frontend.serviceName, domain: localMockServiceDomain(frontend.serviceName), endpoints: [] };
      grouped.set(frontend.serviceName, service);
    }
    const type = frontend.type;
    const businessType = frontend.businessType;
    const url = new URL(frontend.basePath, `https://${service.domain}`).toString();
    if (new URL(url).hostname !== service.domain) throw new Error("\u672C\u5730 deploy mock \u670D\u52A1\u57DF\u540D\u975E\u6CD5");
    service.endpoints.push({ type, businessType, title: frontend.title, basePath: frontend.basePath, url });
  }
  return [...grouped.values()];
}
function validDomains(value) {
  if (!Array.isArray(value)) return false;
  const names = /* @__PURE__ */ new Set();
  return value.every((service) => {
    if (!record(service) || !nonEmpty(service.serviceName) || !nonEmpty(service.domain) || !Array.isArray(service.endpoints) || service.endpoints.length === 0 || names.has(service.serviceName)) return false;
    names.add(service.serviceName);
    try {
      const host = new URL(`https://${service.domain}`);
      if (host.host !== service.domain || host.pathname !== "/") return false;
    } catch {
      return false;
    }
    return service.endpoints.every((entry) => {
      if (!record(entry) || typeof entry.type !== "string" || !["pc", "h5", "api"].includes(entry.type) || typeof entry.businessType !== "string" || !["application", "prototype"].includes(entry.businessType) || !nonEmpty(entry.title) || !nonEmpty(entry.basePath) || !entry.basePath.startsWith("/") || !nonEmpty(entry.url)) return false;
      try {
        const url = new URL(entry.url);
        return ["http:", "https:"].includes(url.protocol) && url.hostname === service.domain;
      } catch {
        return false;
      }
    });
  });
}
function processAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error.code !== "ESRCH";
  }
}
async function recoverAbandonedLock(lock) {
  const owner = path.join(lock, "owner");
  let data;
  try {
    data = await fs.readFile(owner, "utf8");
  } catch (error) {
    if (error.code !== "ENOENT") return;
  }
  let pid;
  try {
    pid = data ? JSON.parse(data).pid : void 0;
  } catch {
  }
  if (typeof pid === "number" && Number.isInteger(pid) && pid > 0) {
    if (processAlive(pid)) return;
  } else {
    const age = Date.now() - (await fs.stat(lock).catch(() => ({ mtimeMs: Date.now() }))).mtimeMs;
    if (age < 3e4) return;
  }
  const claim = path.join(lock, ".recovery");
  try {
    await fs.mkdir(claim);
  } catch (error) {
    if (error.code !== "EEXIST") return;
    const age = Date.now() - (await fs.stat(claim).catch(() => ({ mtimeMs: Date.now() }))).mtimeMs;
    if (age < 3e4) return;
    await fs.rmdir(claim).catch(() => {
    });
    return;
  }
  try {
    if (await fs.readFile(owner, "utf8").catch(() => void 0) !== data) return;
    if (data !== void 0) await fs.unlink(owner).catch(() => {
    });
  } finally {
    await fs.rmdir(claim).catch(() => {
    });
  }
  await fs.rmdir(lock).catch(() => {
  });
}
async function updateState(stateDir, target) {
  const lock = path.join(stateDir, LOCK_DIR);
  const owner = path.join(lock, "owner");
  const token = randomUUID();
  const deadline = Date.now() + 1e4;
  for (; ; ) {
    try {
      await fs.mkdir(lock);
      try {
        await fs.writeFile(owner, JSON.stringify({ pid: process.pid, token }), { flag: "wx" });
      } catch (error) {
        await fs.rmdir(lock).catch(() => {
        });
        throw error;
      }
      break;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      await recoverAbandonedLock(lock);
      if (Date.now() > deadline) throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u9501\u7B49\u5F85\u8D85\u65F6");
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
  }
  const temp = path.join(stateDir, `.${STATE_FILE}.${randomUUID()}.tmp`);
  try {
    const state = await readState(stateDir);
    const copy = structuredClone(target);
    state.lastTarget = copy;
    state.submissions.push({ target: copy, at: (/* @__PURE__ */ new Date()).toISOString() });
    await fs.writeFile(temp, JSON.stringify(state, null, 2) + "\n", { flag: "wx" });
    await fs.rename(temp, path.join(stateDir, STATE_FILE));
  } finally {
    await fs.unlink(temp).catch(() => {
    });
    if (await fs.readFile(owner, "utf8").catch(() => "") === JSON.stringify({ pid: process.pid, token })) {
      await fs.unlink(owner);
      await fs.rmdir(lock);
    }
  }
}
async function submitLocalMockFrontends(cwd, env, request) {
  const domains = project(request);
  await updateState(config(cwd, env).stateDir, request);
  return domains;
}
async function queryLocalMockDomains(cwd, env) {
  const { stateDir, domainsFile } = config(cwd, env);
  const state = await readState(stateDir);
  if (state.lastTarget) return project(state.lastTarget);
  if (!domainsFile) return [];
  const value = JSON.parse(await fs.readFile(domainsFile, "utf8"));
  if (!record(value) || !validDomains(value.domains)) throw new Error("DEPLOY_MOCK_DOMAINS_FILE \u5FC5\u987B\u5305\u542B\u6709\u6548\u7684 domains \u6570\u7EC4");
  return value.domains;
}

// src/utils/customWaveAgent/speckit/config/shared/platform/cli.mts
var log = createLogger("platform");
var EXIT = {
  OK: 0,
  FAILURE: 1,
  USAGE: 2,
  INVALID: 3,
  NOT_FOUND: 4
};
var SUBCOMMAND_SPECS = {
  "is-database-type-supported": {
    values: { "--type": "type" },
    /** **必填**取值 flag（冻结面：`--type` / `--app` / `--name` 均必填——无「无参 = 全部」的语义）。 */
    required: ["type"],
    usage: "is-database-type-supported --type <t>",
    summary: '\u67D0\u6570\u636E\u5E93\u7C7B\u578B\u662F\u5426\u53D7\u5E73\u53F0\u652F\u6301\uFF08\u4E0D\u652F\u6301 = {"supported":false} + exit 0\uFF09'
  },
  "list-database-types": {
    values: {},
    required: [],
    usage: "list-database-types",
    summary: "\u5E73\u53F0\u652F\u6301\u7684\u6570\u636E\u5E93\u7C7B\u578B\u6E05\u5355"
  },
  "get-data-source-config": {
    values: { "--app": "app", "--name": "name" },
    required: ["app", "name"],
    usage: "get-data-source-config --app <a> --name <n>",
    summary: "\u6309 appId + dataSourceName \u67E5\u914D\u7F6E\u4E0E\u6761\u76EE\u7EA7\u5B57\u6BB5\uFF08\u672A\u547D\u4E2D = exit 4\uFF1B\u672A\u547D\u4E2D\u4E0D\u8BB0 ERROR\uFF09"
  },
  "register-app-frontends": {
    values: { "--payload": "payload" },
    required: ["payload"],
    usage: "register-app-frontends --payload <json>",
    summary: "\u5411 LCAP \u5168\u91CF\u6CE8\u518C\u5E94\u7528\u4E1A\u52A1\u7AEF\u4E0E Sandbox \u5165\u7AD9\u6620\u5C04"
  },
  "get-service-domains": {
    values: {},
    required: [],
    usage: "get-service-domains",
    summary: "\u67E5\u8BE2\u5F53\u524D\u534F\u4F5C\u4E0A\u4E0B\u6587\u4E0B\u5168\u90E8\u53EF\u7528\u670D\u52A1\u57DF\u540D"
  }
};
function fail(code, message) {
  process.stderr.write(`${message}
`);
  if (code !== EXIT.NOT_FOUND) log.error(message.split("\n")[0]);
  return code;
}
function usage(reason) {
  const lines = Object.keys(SUBCOMMAND_SPECS).map(
    (name) => `  ${SUBCOMMAND_SPECS[name].usage.padEnd(46)}${SUBCOMMAND_SPECS[name].summary}`
  );
  process.exit(
    fail(
      EXIT.USAGE,
      `\u53C2\u6570\u975E\u6CD5\uFF1A${reason}
\u7528\u6CD5\uFF1Aplatform-tool <${Object.keys(SUBCOMMANDS).join("|")}> [flags]
${lines.join("\n")}`
    )
  );
}
function parseFlags(rest, subcommand) {
  const spec = SUBCOMMAND_SPECS[subcommand];
  const values = {};
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    const valueKey = Object.prototype.hasOwnProperty.call(spec.values, arg) ? spec.values[arg] : void 0;
    if (valueKey === void 0) {
      const allowed = Object.keys(spec.values);
      usage(`\u672A\u77E5\u6216\u8D8A\u6743 flag\uFF1A${arg}\uFF08${subcommand} \u7684\u5141\u8BB8\u96C6\uFF1A${allowed.join(" ") || "(\u65E0)"}\uFF09`);
    }
    if (i + 1 >= rest.length) usage(`flag \u7F3A\u503C\uFF1A${arg}`);
    values[valueKey] = rest[++i];
  }
  for (const key of spec.required) {
    if (values[key] === void 0) {
      const flag = Object.keys(spec.values).find((f) => spec.values[f] === key) ?? key;
      usage(`\u7F3A\u5C11\u5FC5\u586B flag\uFF1A${flag}\uFF08${subcommand} \u7684\u7528\u6CD5\uFF1A${spec.usage}\uFF09`);
    }
  }
  return values;
}
function emit(payload) {
  process.stdout.write(`${JSON.stringify(payload)}
`);
}
function describeValue(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "\u6570\u7EC4";
  return typeof value;
}
async function handlerIsDatabaseTypeSupported(rest) {
  const flags = parseFlags(rest, "is-database-type-supported");
  const supported = await isDatabaseTypeSupported(flags.type);
  if (typeof supported !== "boolean") {
    return fail(EXIT.INVALID, `\u5E73\u53F0\u8FD4\u56DE\u6570\u636E\u5F62\u6001\u8FDD\u7EA6\uFF1Asupported \u5E94\u4E3A boolean\uFF08\u5F53\u524D ${describeValue(supported)}\uFF09`);
  }
  emit({ supported });
  return EXIT.OK;
}
async function handlerListDatabaseTypes(rest) {
  parseFlags(rest, "list-database-types");
  const types = await listDatabaseTypes();
  if (!Array.isArray(types)) {
    return fail(EXIT.INVALID, `\u5E73\u53F0\u8FD4\u56DE\u6570\u636E\u5F62\u6001\u8FDD\u7EA6\uFF1Atypes \u5E94\u4E3A\u6570\u7EC4\uFF08\u5F53\u524D ${describeValue(types)}\uFF09`);
  }
  emit({ types });
  return EXIT.OK;
}
async function handlerGetDataSourceConfig(rest) {
  const flags = parseFlags(rest, "get-data-source-config");
  const entry = await getDataSourceEntry(flags.app, flags.name);
  if (entry === null) {
    return fail(EXIT.NOT_FOUND, `\u672A\u627E\u5230\u6570\u636E\u6E90\u914D\u7F6E\uFF1A${flags.name}`);
  }
  const { config: config2, databaseType, databaseMode } = entry;
  if (typeof config2 !== "object" || config2 === null || Array.isArray(config2)) {
    return fail(EXIT.INVALID, `\u5E73\u53F0\u8FD4\u56DE\u6570\u636E\u5F62\u6001\u8FDD\u7EA6\uFF1Aconfig \u5E94\u4E3A\u5BF9\u8C61\uFF08\u5F53\u524D ${describeValue(config2)}\uFF09`);
  }
  emit({ config: config2, databaseType, databaseMode });
  return EXIT.OK;
}
async function handlerRegisterAppFrontends(rest) {
  const flags = parseFlags(rest, "register-app-frontends");
  let request;
  try {
    request = JSON.parse(flags.payload);
  } catch {
    return fail(EXIT.INVALID, "\u4E1A\u52A1\u7AEF\u6CE8\u518C payload \u4E0D\u662F\u5408\u6CD5 JSON");
  }
  if (typeof request !== "object" || request === null || typeof request.appId !== "string" || !request.appId.trim() || typeof request.collaborationId !== "string" || !request.collaborationId.trim() || typeof request.branchName !== "string" || !request.branchName.trim() || !Array.isArray(request.frontends) || !Array.isArray(request.serviceMappings)) {
    return fail(
      EXIT.INVALID,
      "\u4E1A\u52A1\u7AEF\u6CE8\u518C payload \u7ED3\u6784\u975E\u6CD5\uFF1A\u9700\u8981\u975E\u7A7A appId\u3001collaborationId\u3001branchName \u53CA frontends[]\u3001serviceMappings[] \u6570\u7EC4"
    );
  }
  const mode = process.env.DEPLOY_EXTERNAL_MODE ?? "real";
  if (!["real", "local-mock"].includes(mode))
    throw new Error(`DEPLOY_EXTERNAL_MODE \u65E0\u6548\uFF1A${mode}`);
  const domains = mode === "local-mock" ? await submitLocalMockFrontends(process.cwd(), process.env, request) : await registerAppFrontends2(request);
  emit(domains === void 0 ? { ok: true } : { ok: true, domains });
  return EXIT.OK;
}
async function handlerGetServiceDomains(rest) {
  parseFlags(rest, "get-service-domains");
  const mode = process.env.DEPLOY_EXTERNAL_MODE ?? "real";
  if (!["real", "local-mock"].includes(mode))
    throw new Error(`DEPLOY_EXTERNAL_MODE \u65E0\u6548\uFF1A${mode}`);
  if (mode === "local-mock") {
    emit({ domains: await queryLocalMockDomains(process.cwd(), process.env) });
    return EXIT.OK;
  }
  const context = {
    appId: process.env.APP_ID,
    collaborationId: process.env.PRD_ID,
    branchName: process.env.CURRENT_BRANCH
  };
  for (const [variable, value] of [
    ["APP_ID", context.appId],
    ["PRD_ID", context.collaborationId],
    ["CURRENT_BRANCH", context.branchName]
  ]) {
    if (typeof value !== "string" || !value.trim()) return fail(EXIT.USAGE, `\u73AF\u5883\u53D8\u91CF ${variable} \u7F3A\u5931`);
  }
  const domains = await getServiceDomains({
    appId: context.appId,
    collaborationId: context.collaborationId,
    branchName: context.branchName
  });
  if (!Array.isArray(domains)) {
    return fail(EXIT.INVALID, `\u5E73\u53F0\u8FD4\u56DE\u6570\u636E\u5F62\u6001\u8FDD\u7EA6\uFF1Adomains \u5E94\u4E3A\u6570\u7EC4\uFF08\u5F53\u524D ${describeValue(domains)}\uFF09`);
  }
  emit({ domains });
  return EXIT.OK;
}
var SUBCOMMANDS = {
  "is-database-type-supported": handlerIsDatabaseTypeSupported,
  "list-database-types": handlerListDatabaseTypes,
  "get-data-source-config": handlerGetDataSourceConfig,
  "register-app-frontends": handlerRegisterAppFrontends,
  "get-service-domains": handlerGetServiceDomains
};
async function main() {
  const startedAt = Date.now();
  const [sub, ...rest] = process.argv.slice(2);
  const handler = sub !== void 0 && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, sub) ? SUBCOMMANDS[sub] : void 0;
  if (handler === void 0) {
    usage(`\u672A\u77E5\u5B50\u547D\u4EE4\uFF1A${sub ?? "(\u65E0)"}\uFF08\u53EF\u7528\uFF1A${Object.keys(SUBCOMMANDS).join(" / ")}\uFF09`);
  }
  let code;
  try {
    code = await handler(rest);
  } catch (err) {
    process.exit(fail(EXIT.FAILURE, `platform-tool: ${errorMessage(err)}`));
  }
  if (code === EXIT.OK) {
    log.tool(sub, { exit: code, ms: Date.now() - startedAt });
  }
  process.exit(code);
}
function errorMessage(err) {
  return err instanceof Error ? err.message : String(err);
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  void main();
}
export {
  SUBCOMMANDS
};
