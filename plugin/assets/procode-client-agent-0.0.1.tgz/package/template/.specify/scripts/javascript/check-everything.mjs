import { PENDING, readFileSync, filterUnderSpecs, auto } from './shared/index.mjs';

import {
  combine,
  filter,
  checkerForAbsolutePath,
  checkerForLineReference,
  checkerForMenus,
  checkerForPlaceholder,
} from './wardrobe/for-check-everything/index.mjs';

export const handlers = [
  checkerForAbsolutePath,
  checkerForLineReference,
  checkerForPlaceholder,
  checkerForMenus,
];

export const toRaw = async (rootDir, filePath) => {
  rootDir = rootDir || process.cwd();
  filePath = filePath ?? process.argv[2];

  const filterForCheck = (item) => {
    const useful = filter(item);
    const matched = filePath && filePath.endsWith(item);

    if (filePath) {
      return matched && useful;
    }

    return useful;
  };

  const store = {};
  const bundles = filterUnderSpecs(rootDir)(filterForCheck);

  for (const hanlder of handlers) {
    const { filter, callback } = hanlder;

    const filtered = filter ? bundles.filter(filter) : bundles;

    for (const bundle of filtered) {
      const { absoluteFilePath } = bundle;
      const source = readFileSync(absoluteFilePath);
      const pending = source.includes(PENDING);

      if (pending && !filePath) {
        continue;
      }

      const got = await callback(rootDir)(bundle);

      if (!got) {
        continue;
      }

      const reg = /(?<=[^#]*#\s+)([^#\n]+)/g;
      const [name = '文件'] = source.match(reg) || [];
      const title = `## [${name}](${absoluteFilePath})`;

      const key = absoluteFilePath;

      store[key] = store[key] || [title];
      store[key].push('', got);
    }
  }

  const values = Object.values(store);
  const map = (item) => combine(...item, '');
  const messages = values.map(map);

  if (!messages.length) {
    return '未检测到任何不规范内容';
  }

  return combine(
    '# 不规范内容检测结果',
    '',
    '<!-- **特别注意/关键规则**：你有充足的时间与资源，必须严格按照任务要求，对以下文件内容进行验收改正。禁止出于任何理由，导致没有严格遵守任务要求验收文件内容。 -->',
    '<!-- **特别注意/关键规则**：必须严格按照占位符的内容描述，生成文本来**替换**对应占位符，禁止文件中出现 `[***]` 格式的占位符文本。 -->',
    '',
    ...messages
  );
};

auto(import.meta)(toRaw);

export default toRaw;
