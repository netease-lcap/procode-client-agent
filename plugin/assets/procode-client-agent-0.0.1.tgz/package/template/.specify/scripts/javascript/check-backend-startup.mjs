#!/usr/bin/env node

/**
 * 段 C0｜后端启动 executor checker（跑 + 判绿 + 指向日志/surefire 产物）。
 *
 * 砍掉归桶压缩层（domainOf/bucket/startup-buckets.json/structuredContextLoadErrors）后，
 * 脚本只做：跑 `mvn spring-boot:run` 验启动 + contextLoad 验证 → 判绿 →
 * emit 启动错误行（扁平清单）+ applicationLog 路径 + contextLoad 的 surefireDir + 失败 .txt 文件名。
 *
 * 两层验证：
 *   1) 跑 `mvn spring-boot:run` 验主应用启动（BindingException / Bean 缺失 / NOT NULL / 外键 / 配置错）。
 *      启动判定：异步 spawn + 轮询端口→/actuator/health，health 返回 UP 即判启动成功、立即 kill 前台进程继续
 *      （Spring 实际 ~1-4s 启动完；旧 spawnSync(timeout:60s) 固定空等满 60s 才判成功，单次浪费 ~55s）。
 *      启动失败（进程自退 status≠0）则收集 stdout/stderr 提取异常行。
 *   2) 启动绿后 contextLoad 验证：跑 test-compile + mvnd test，挑 Errors——
 *      主应用 spring-boot:run 不 @Autowired 未用 Service，缺 @Service 不报错；
 *      @SpringBootTest 测试类 @Autowired Service 触发 No qualifying bean → contextLoad 失败。
 *      把 @Service/@Repository 缺失等 Bean 注入类 Error 前移到 C0 修，业务断言 Failures 留 B1 修。
 *      只 gate Errors（contextLoad/Bean 注入），Failures 不计入 C0 退出码。
 *
 * SQL 冒烟已迁出（plan 2026-09-21 §B5 rev2）：Mapper 引用表/列与库结构比对改为 build 波
 * 段 AS（agent 经 sql-exec 执行探测 + 机械门校验产物），本脚本不再连库、方言无关。
 *
 * 协调者读 emit 的 startupErrors（启动异常行）+ applicationLog（Spring 日志路径，grep 异常关键字）+
 * surefireDir + contextLoadReportFiles（contextLoad 失败的 .txt，文件名=测试类 FQN，cat 即见 No qualifying bean of type 'XxxService'）。
 *
 * 用法：node check-backend-startup.mjs                    （全量 gate：启动+contextLoad，有错 exit 1）
 *       node check-backend-startup.mjs --kill-port         （仅清理端口残留进程，不跑启动）
 *
 * 退出码约定（与 createCommandCheckerByExitCode 对齐）：
 *   启动失败 / contextLoad Errors>0 → exit 1；全绿 → exit 0。
 */

import { existsSync, mkdirSync, writeFileSync, readdirSync, readFileSync, statSync } from 'fs';
import { resolve, join, basename, dirname, sep } from 'path';
import { execSync, spawnSync, spawn } from 'child_process';
import * as net from 'net';
import * as http from 'http';
import { parsePomJavaMajor, parseJavaVersionOutput } from './shared/java-version.mjs';
import {
  findBackendDir,
  findBootModuleDir,
  findPlanBackendDir,
  collectSurefireReportDirs,
  resolveDeclaredBackendRoots,
  resolveProjectRoot,
} from './shared/backend-common.mjs';

const cwd = process.cwd();
const killPortOnly = process.argv.includes('--kill-port');
let serverPort = null;


function resolveJavaHome(backendDir) {
  let javaVersion = null;
  // 从 pom.xml <java.version> 读取（不再依赖 plans/tech-stack.json 路径解析）
  const pomPath = resolve(backendDir, 'pom.xml');
  if (existsSync(pomPath)) {
    try {
      const pom = readFileSync(pomPath, 'utf-8');
      // 归一在 shared/java-version.mjs 单点实现（1.8→8；旧 (\d+) 解析不到 "1.8" 致回退系统 JAVA_HOME）。
      javaVersion = parsePomJavaMajor(pom);
    } catch { /* ignore */ }
  }
  if (!javaVersion) return null;

  // 优先用环境变量（沙箱可能注入 JAVA_HOME / JAVA21_HOME / JAVA_21_HOME）
  const envCandidates = [
    process.env[`JAVA_${javaVersion}_HOME`],   // JAVA_21_HOME
    process.env[`JAVA${javaVersion}_HOME`],    // JAVA21_HOME（沙箱常见）
    process.env.JAVA_HOME,                      // 系统默认 JAVA_HOME（需验证版本匹配）
  ].filter(Boolean);
  for (const home of envCandidates) {
    if (!existsSync(resolve(home, 'bin', 'java'))) continue;
    try {
      const verOut = execSync(`"${resolve(home, 'bin', 'java')}" -version 2>&1`, {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5000,
      });
      if (parseJavaVersionOutput(verOut) === javaVersion) return home;
    } catch { /* 跳过该候选 */ }
  }

  const jvmRoot = '/usr/lib/jvm';
  if (existsSync(jvmRoot)) {
    try {
      const dirs = readdirSync(jvmRoot);
      const found = dirs.find((n) => n.startsWith(`temurin-${javaVersion}`));
      if (found) return resolve(jvmRoot, found);
    } catch { /* ignore */ }
  }
  return null;
}

function resolveServerPort(backendDir) {
  const portFromEnv = process.env.SERVER_PORT;
  if (portFromEnv) return parseInt(portFromEnv, 10);

  // 尝试 application.yml
  const ymlPath = resolve(backendDir, 'src/main/resources/application.yml');
  if (existsSync(ymlPath)) {
    try {
      let yml = readFileSync(ymlPath, 'utf-8');
      // 解析 Spring 占位符 ${VAR:default}（如 ${PORT:6003} → 6003）
      yml = yml.replace(/\$\{(\w+):([^}]*)\}/g, (_, varName, defaultVal) =>
        process.env[varName] || defaultVal
      );
      const m = yml.match(/port:\s*(\d{2,5})/);
      if (m) return parseInt(m[1], 10);
    } catch { /* ignore */ }
  }

  // 尝试 application.properties
  const propPath = resolve(backendDir, 'src/main/resources/application.properties');
  if (existsSync(propPath)) {
    try {
      const prop = readFileSync(propPath, 'utf-8');
      const m = prop.match(/server\.port\s*=\s*(\d{2,5})/);
      if (m) return parseInt(m[1], 10);
    } catch { /* ignore */ }
  }

  return 8080; // Spring Boot 默认端口
}

function killPortProcessSync(port) {
  // 多次尝试多种工具，确保端口释放（lsof/fuser/ss 任一可用即可）
  const killers = [
    // 1) lsof + kill -9
    () => {
      const stdout = execSync(`lsof -nP -iTCP:${port} -sTCP:LISTEN -t`, {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 3000,
      });
      const pids = stdout.trim().split(/\s+/).filter(Boolean);
      for (const pid of pids) {
        try { process.kill(Number(pid), 'SIGKILL'); } catch { /* ignore */ }
      }
      return pids.length > 0;
    },
    // 2) fuser -k（fallback，直接杀）
    () => {
      execSync(`fuser -k ${port}/tcp 2>/dev/null`, {
        stdio: ['ignore', 'pipe', 'pipe'], timeout: 3000,
      });
      return true;
    },
    // 3) ss + sed 取 pid（POSIX 兼容，不需要 grep -P）
    () => {
      const stdout = execSync(
        `ss -tlnp 'sport = :${port}' 2>/dev/null | awk 'NR>1 {print $NF}' | sed -n 's/.*pid=\\([0-9]\\{1,\\}\\).*/\\1/p'`,
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 3000 },
      );
      const pids = stdout.trim().split(/\s+/).filter(Boolean);
      for (const pid of pids) {
        try { process.kill(Number(pid), 'SIGKILL'); } catch { /* ignore */ }
      }
      return pids.length > 0;
    },
    // 4) netstat 检测 + fuser 优先杀（netstat -tlnp 无 root 取不到 PID）
    () => {
      const check = execSync(`netstat -tln 2>/dev/null | grep -c ':${port} ' || echo 0`, {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 3000,
      });
      if (check.trim() === '0') return false;
      try {
        execSync(`fuser -k ${port}/tcp 2>/dev/null`, { stdio: ['ignore', 'pipe', 'pipe'], timeout: 3000 });
        return true;
      } catch { /* fuser 不可用，回退到 netstat -tlnp 解析 PID（需 root 才能看到 PID） */ }
      const stdout = execSync('netstat -tlnp 2>/dev/null', {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 3000,
      });
      const pids = [];
      const portRe = new RegExp(`:${port}\\b`);
      for (const line of stdout.split('\n')) {
        if (portRe.test(line)) {
          const cols = line.trim().split(/\s+/);
          const lastCol = cols[cols.length - 1];
          const pidMatch = lastCol.match(/^(\d+)/);
          if (pidMatch) pids.push(pidMatch[1]);
        }
      }
      for (const pid of pids) {
        try { process.kill(Number(pid), 'SIGKILL'); } catch { /* ignore */ }
      }
      return pids.length > 0;
    },
  ];

  const portInUse = () => {
    try {
      const check = execSync(
        `lsof -nP -iTCP:${port} -sTCP:LISTEN -t 2>/dev/null || fuser ${port}/tcp 2>/dev/null || ss -tlnp 'sport = :${port}' 2>/dev/null | grep -c LISTEN || netstat -tlnp 2>/dev/null | grep -c ':${port} ' || echo 0`,
        { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 2000 },
      );
      const t = check.trim();
      return t !== '' && t !== '0';
    } catch {
      return false;
    }
  };

  const awaitRelease = () => {
    const deadline = Date.now() + 3000;
    while (Date.now() < deadline) {
      if (!portInUse()) return true;
      const waited = spawnSync('sleep', ['0.5'], { timeout: 1000 });
    }
    return !portInUse();
  };

  // 双向轮询：杀 → 等释放 → 等重占 → 再杀（孤儿 JVM 被 kill 后可能由 fork 子进程延迟重绑）
  for (let round = 0; round < 3; round++) {
    for (const fn of killers) {
      try { fn(); } catch { /* 工具不可用 */ }
    }
    const released = awaitRelease();
    if (!released && round < 2) continue;
    if (released) {
      spawnSync('sleep', ['0.5'], { timeout: 1000 });
      if (!portInUse()) return;
    }
  }
}

// ── 启动健康探测：替代旧的「等满 60s 超时=成功」判定 ──
// Spring 实际 ~1.2s 启动完，但 spring-boot:run 是前台进程不退出，旧逻辑 spawnSync(timeout:60s) 固定空等 58.8s。
// 改为异步 spawn + 轮询端口/health，启动成功立即 kill 进程继续，失败（进程自退）立即收集异常。

/** 探测端口是否 LISTEN（net.connect，无外部依赖）。通则 resolve(true)，不通 resolve(false)。 */
function probePort(port, host = '127.0.0.1', timeoutMs = 1500) {
  return new Promise((resolve) => {
    const sock = net.connect({ port, host });
    let done = false;
    const finish = (ok) => { if (done) return; done = true; sock.destroy(); resolve(ok); };
    sock.once('connect', () => finish(true));
    sock.once('error', () => finish(false));
    setTimeout(() => finish(false), timeoutMs).unref();
  });
}

/** 探测 /actuator/health（Spring 上下文就绪标志）。status=200 且 body 含 "UP" → resolve(true)。
 *  无 actuator 时 fallback：端口通即视为就绪（由调用方保证先 probePort）。 */
function probeHealth(port, host = '127.0.0.1', timeoutMs = 2000) {
  return new Promise((resolve) => {
    const req = http.get({ host, port, path: '/actuator/health', timeout: timeoutMs }, (res) => {
      let body = '';
      res.once('data', (d) => { body += d; if (body.length > 4096) res.destroy(); });
      res.once('end', () => resolve(res.statusCode === 200 && /"status"\s*:\s*"UP"/i.test(body)));
      res.once('error', () => resolve(false));
    });
    req.once('error', () => resolve(false));
    req.once('timeout', () => { req.destroy(); resolve(false); });
  });
}

/** 异步 spawn spring-boot:run，轮询端口→health，启动成功立即 kill。
 *  返回 { startupOk, stdout, stderr, killed }。进程自退（status≠0）= 启动失败，收集输出供异常提取。 */
function runSpringBootAndWait(mvnCmd, mvnArgs, backendDir, port, env, deadlineMs = 90_000) {
  // mvnd 在本沙箱因 /root/.m2/mvnd/registry 只读 mount 启动即崩（DaemonException: Read-only file system），
  // spring-boot:run 进程自退 → startupOk=false + 崩溃栈被 [CausedBy] 收录 → 误判「应用启动失败」。
  // 把单次 attempt 抽成闭包（参数化 cmd），mvnd 首次 attempt 命中崩溃签名时用 mvn 重跑一次。
  // 非 mvnd（mvnw/mvn）时 fallbackCmd=null，行为与原逻辑完全一致。
  const fallbackCmd = mvnCmd === 'mvnd' ? 'mvn' : null;
  const attempt = (cmd) => new Promise((resolveP) => {
    const child = spawn(cmd, mvnArgs, { cwd: backendDir, env, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    let settled = false;
    const chunks = { out: [], err: [] };
    child.stdout.on('data', (d) => { chunks.out.push(d); });
    child.stderr.on('data', (d) => { chunks.err.push(d); });

    const finish = (startupOk) => {
      if (settled) return; settled = true;
      clearTimeout(pollTimer);
      clearTimeout(deadlineTimer);
      // 启动成功则 kill 前台进程（否则它一直跑）；失败则进程已自退，kill 无害
      try { child.kill('SIGKILL'); } catch { /* 已退出 */ }
      // 给进程一点时间 flush 输出
      setTimeout(() => {
        stdout = Buffer.concat(chunks.out).toString('utf-8');
        stderr = Buffer.concat(chunks.err).toString('utf-8');
        resolveP({ startupOk, stdout, stderr });
      }, 200);
    };

    // 进程自退（编译错/启动异常致 exit）= 启动失败
    child.once('exit', (code, signal) => {
      if (!settled) finish(false);
    });

    // 兜底超时：防启动卡死无限轮询（非常规路径）
    const deadlineTimer = setTimeout(() => {
      if (!settled) finish(false);
    }, deadlineMs).unref();

    // 轮询：先端口，通了再 health（health 200+UP = Spring 上下文就绪）
    let pollRound = 0;
    const poll = async () => {
      if (settled) return;
      pollRound++;
      const portUp = await probePort(port);
      if (settled) return;
      if (portUp) {
        // 端口通 → 确认 health（Spring 上下文就绪）。无 actuator 时 health 探测失败仍判定成功（端口通=Tomcat 起来了）
        const healthy = await probeHealth(port);
        if (settled) return;
        if (healthy || pollRound > 40) {
          // health UP，或端口已持续通 20s（~40×0.5s）仍无 health（可能无 actuator）→ 判定成功
          finish(true);
          return;
        }
        // 端口通但 health 还没 UP → 再等一轮（窗口很短）
      }
      pollTimer = setTimeout(poll, 500);
    };
    let pollTimer = setTimeout(poll, 800); // 首次延迟 0.8s 给 Spring 启动时间
    pollTimer.unref();
  });
  return attempt(mvnCmd).then((r) => {
    const out = `${r.stdout || ''}\n${r.stderr || ''}`;
    if (mvnCmd === 'mvnd' && !r.startupOk && fallbackCmd
        && /Read-only file system|DaemonException/.test(out)) {
      return attempt(fallbackCmd);   // mvnd daemon 起不来 → 用 mvn 重跑同一 spring-boot:run
    }
    return r;
  });
}


/** 服务健康：优先 /actuator/health，回退 /health；两者都接受 {"status":"UP"}。 */
function probeServiceHealth(port, host = '127.0.0.1', timeoutMs = 2500) {
  const paths = ['/actuator/health', '/health'];
  return new Promise((res) => {
    const tryPath = (i) => {
      if (i >= paths.length) return res(false);
      const req = http.get({ host, port, path: paths[i], timeout: timeoutMs }, (r) => {
        let body = '';
        r.once('data', (d) => { body += d; if (body.length > 8192) r.destroy(); });
        r.once('end', () => {
          if (r.statusCode === 200 && /"status"\s*:\s*"UP"/i.test(body)) return res(true);
          tryPath(i + 1);
        });
        r.once('error', () => tryPath(i + 1));
      });
      req.once('error', () => tryPath(i + 1));
      req.once('timeout', () => { req.destroy(); tryPath(i + 1); });
    };
    tryPath(0);
  });
}

/** 轮询健康直到就绪或超时（多服务托管模式用：ensure 返回后实例可能仍在启动中）。 */
async function waitForServiceHealth(port, deadlineMs = 90_000) {
  const started = Date.now();
  while (Date.now() - started < deadlineMs) {
    if (await probeServiceHealth(port)) return true;
    await new Promise((r) => setTimeout(r, 2_000));
  }
  return false;
}


/**
 * 每服务挑**最小测试集**（与单端 C0 的“跑测试顺带验装载”语义对齐，但不全量重复）：
 *   优先启动类/上下文测试（*ApplicationTests / *ContextLoad* / *SmokeTest）；
 *   否则取该服务任意一个 <Entity>ServiceTest。
 * 只用于 C0 的 contextLoad 验证；Failures 仍留给 B1 全量单测。
 */
function collectPerServiceSmokeTests(backendDir, backends) {
  const byShort = new Map(); // short -> { moduleDir, className, packageName, priority }
  const priorityOf = (name) => (/ApplicationTests|ContextLoad|SmokeTest/.test(name) ? 0 : /ServiceTest/.test(name) ? 1 : 2);
  const walkJava = (dir, moduleDir) => {
    let entries = [];
    try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      const abs = join(dir, e.name);
      if (e.isDirectory()) { walkJava(abs, moduleDir); continue; }
      if (!e.name.endsWith('.java')) continue;
      let content = '';
      try { content = readFileSync(abs, 'utf-8'); } catch { continue; }
      const pkg = (content.match(/^package\s+([\w.]+);/m) || [])[1];
      if (!pkg) continue;
      const short = pkg.split('.').pop();
      const className = e.name.replace(/\.java$/, '');
      const priority = priorityOf(className);
      if (priority === 2) continue;
      const prev = byShort.get(short);
      if (!prev || priority < prev.priority) {
        byShort.set(short, { moduleDir, className, packageName: pkg, priority });
      }
    }
  };
  let moduleDirs = [];
  try { moduleDirs = readdirSync(backendDir, { withFileTypes: true }).filter((e) => e.isDirectory()).map((e) => e.name); } catch { return []; }
  for (const mod of moduleDirs) walkJava(join(backendDir, mod, 'src', 'test', 'java'), mod);
  const result = [];
  for (const svc of backends) {
    const short = String(svc.serviceName || '').replace(/^.*-backend-/, '');
    const hit = byShort.get(short);
    if (hit) result.push({ serviceName: svc.serviceName, moduleDir: hit.moduleDir, className: hit.className });
  }
  return result;
}

function emit(ok, payload) {
  // 清理本次启动产生的后端进程，避免孤儿进程阻塞后续 checker 重跑
  if (serverPort) { try { killPortProcessSync(serverPort); } catch { /* 不因清理失败影响判定结果 */ } }
  console.log(JSON.stringify({ ok, ...payload }, null, 2));
  process.exit(ok ? 0 : 1);
}

/** 读 `--backend-root`（可重复）/ `--active-spec-dir`；未知/缺值忽略。 */
function collectRootArgs(argv) {
  const explicitRoots = [];
  let activeSpecDir;
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === '--backend-root') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) explicitRoots.push(resolve(value));
    } else if (argv[i] === '--active-spec-dir') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) activeSpecDir = resolve(value);
    }
  }
  return { explicitRoots, activeSpecDir };
}

/** 单根直接采用；多根只认声明里本身是其余所有根祖先的聚合根，否则无法唯一确定（null）。 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/** 代码根定位（D5）：声明/显式根优先；findBackendDir 仅兜底并打 warning；歧义不猜。 */
function resolveBackendRoot() {
  const baseRoot = resolveProjectRoot(cwd) ?? cwd;
  const { explicitRoots, activeSpecDir } = collectRootArgs(process.argv.slice(2));
  // 未显式传 --active-spec-dir 时由最新 plans/backend 反推 active spec 目录，使工程方案声明生效。
  const planBackendDir = findPlanBackendDir(cwd);
  // planBackendDir = <activeSpecDir>/plans/backend ⇒ activeSpecDir 需再上溯一层（plans 的父目录）。
  const specDir = activeSpecDir ?? (planBackendDir ? dirname(dirname(planBackendDir)) : undefined);
  const declared = resolveDeclaredBackendRoots({ activeSpecDir: specDir, rootDir: baseRoot, explicitRoots });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[check-backend-startup] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[check-backend-startup] 代码根存在多个且无声明聚合根，无法唯一确定：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root，或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[check-backend-startup] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(cwd);
  if (legacy) console.warn(`[check-backend-startup] 未找到代码根声明，回落启发式 findBackendDir：${legacy}`);
  return legacy;
}

// 截断 surefire .txt 内容为精简摘要（砍框架栈 + 删超长无定位价值行 + 同根因去重）。
// 协调者读 failureDetails 摘要即可定位根因（方法名/异常/业务栈行号），
// 摘要不够时再 cat 全量 .txt 兜底——避免全量堆栈灌进上下文。
// 业务栈只有 com.company——只保留 at com.company 行，砍所有其他 at 行。
const NOISE_STACK_RE = /^\s+at (?!com\.company[/.])/;
const DROP_LINE_RE = /^(### SQL:|### The error occurred while setting parameters)/;
const CAUSE_FINGERPRINT_RE = /^(### Cause:|Caused by:)\s*(.*)/;

function extractFailureDigest(content) {
  const lines = content.split('\n');
  const blocks = [];
  let cur = [];
  let sawHeader = false;
  for (const line of lines) {
    if (/-- Time elapsed.*?(?:FAILURE!|ERROR!)/.test(line)) {
      if (cur.length) blocks.push(cur);
      cur = [line];
      sawHeader = true;
    } else if (sawHeader) {
      cur.push(line);
    }
  }
  if (cur.length) blocks.push(cur);
  const processed = blocks.map((blk) => {
    const kept = blk.filter((l) => !NOISE_STACK_RE.test(l) && !DROP_LINE_RE.test(l));
    let fingerprint = null;
    for (const l of blk) {
      const m = l.match(CAUSE_FINGERPRINT_RE);
      if (m) { fingerprint = m[2].trim(); break; }
    }
    return { kept: kept.slice(0, 30), fingerprint };
  });
  const seenFingerprints = new Set();
  const digests = [];
  for (const { kept, fingerprint } of processed) {
    const methodLine = kept[0] || '';
    if (fingerprint && seenFingerprints.has(fingerprint)) {
      digests.push(`${methodLine}\n  （同根因：${fingerprint.slice(0, 80)}）`);
    } else {
      if (fingerprint) seenFingerprints.add(fingerprint);
      digests.push(kept.join('\n'));
    }
  }
  return digests.join('\n\n');
}

// 定位「含 @SpringBootApplication 启动类」的子模块目录（多模块聚合工程：根 pom packaging=pom，
// 启动类在子模块，父 POM 上裸跑 spring-boot:run 会报 Unable to find a suitable main class）。
// findBootModuleDir 已上提 shared/backend-common.mjs（与 check-backend-test 共用，消除本地副本漂移）。
// 未命中（单模块工程）返回 null，调用方退化为在 backendDir 上直接执行。

// 1. 定位 backend 工程目录（声明根优先，findBackendDir 仅兜底）
const backendDir = resolveBackendRoot();

if (!backendDir) {
  emit(false, { failures: ['未找到后端工程（pom.xml / build.gradle）'] });
}
const javaHome = resolveJavaHome(backendDir);
// 端口解析需从「含 application.yml 的启动模块」（RuoYi 多模块工程里为 ruoyi-admin）读 server.port，
// 而非父 POM 目录（父 POM 无 src/main/resources/application.yml，resolveServerPort 读到默认 8080）。
// 用 findBootModuleDir 定位启动模块，读到它的 application.yml 里的真实端口（如 6003）。
const bootModuleDirForPort = findBootModuleDir(backendDir);
serverPort = resolveServerPort(bootModuleDirForPort || backendDir);

// --kill-port：只清理端口残留进程，不跑启动验证
if (killPortOnly) {
  killPortProcessSync(serverPort);
  console.log(JSON.stringify({ ok: true, action: 'port-killed', port: serverPort }));
  process.exit(0);
}


// ── 多服务（微服务）托管模式 ────────────────────────────────────────────────────
// 一个后端产物根下含多个可部署服务时，逐个 `service-manager ensure` 并探活：
//   ① 覆盖全部服务（不再只抽样第一个 boot module）；
//   ② 不自己 spawn / 不 kill 正式端口，生命周期始终归 Runtime；
//   ③ 结果按服务聚合 emit（serviceName / port / status / detail / logDir）。
// 单服务 / 老工程（无 {appName}-services.json 或多于 1 个后端服务不成立）保持下方 legacy 全流程。
const appNameEnv = String(process.env.APP_NAME || process.env.APP_ID || '').trim();
// 应用根定位：从后端根向上最多 2 层找 `{appName}-services.json`（兼容 projectName 自定义目录名，
// 不再假设目录名一定是 `${appName}-backend`）。
const appRootCandidate = appNameEnv
  ? (() => {
      let dir = resolve(backendDir);
      for (let i = 0; i < 3; i += 1) {
        if (existsSync(resolve(dir, `${appNameEnv}-services.json`))) return dir;
        const parent = resolve(dir, '..');
        if (parent === dir) break;
        dir = parent;
      }
      return null;
    })()
  : null;
const servicesFile = appRootCandidate ? resolve(appRootCandidate, `${appNameEnv}-services.json`) : null;
let managedBackends = [];
if (servicesFile && existsSync(servicesFile)) {
  try {
    const parsed = JSON.parse(readFileSync(servicesFile, 'utf-8'));
    if (Array.isArray(parsed)) {
      managedBackends = parsed.filter((s) =>
        s && s.serviceType === 'backend' && s.businessType !== 'prototype'
        && Number.isInteger(Number(s.port)) && Number(s.port) > 0);
    }
  } catch { /* 清单损坏走 legacy，由上层报错 */ }
}

// Client 逐服务执行同一真实启动/contextLoad 检查，不依赖共享脚本工具。
// 子检查显式传根目录且禁止再次 fan-out；未选择该模式的流水线保持原行为。
if (process.argv.includes('--native-runtime') && !process.argv.includes('--native-runtime-child')
  && appRootCandidate && managedBackends.length > 1) {
  const results = [];
  for (const service of managedBackends) {
    const name = String(service.serviceName || '');
    const projectName = service.projectName ?? name;
    const serviceRoot = typeof projectName === 'string' ? resolve(appRootCandidate, projectName) : '';
    if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]*$/.test(name) || !serviceRoot
      || !serviceRoot.startsWith(`${resolve(appRootCandidate)}${sep}`)
      || !(existsSync(join(serviceRoot, 'pom.xml')) || existsSync(join(serviceRoot, 'build.gradle'))
        || existsSync(join(serviceRoot, 'build.gradle.kts')))) {
      results.push({ serviceName: name, ok: false, detail: '服务源码根目录无效或缺少实际构建入口' });
      continue;
    }
    const logDir = resolve(appRootCandidate, '.log', name);
    mkdirSync(logDir, { recursive: true });
    const logFile = join(logDir, 'native-startup-check.log');
    const result = spawnSync(process.execPath, [resolve(process.argv[1]), '--native-runtime',
      '--native-runtime-child', '--backend-root', serviceRoot], {
      cwd: serviceRoot, env: process.env, encoding: 'utf8', timeout: 900_000, maxBuffer: 64 * 1024 * 1024,
    });
    writeFileSync(logFile, `${result.stdout || ''}\n${result.stderr || ''}\n${result.error?.message || ''}`);
    results.push({ serviceName: name, ok: result.status === 0 && !result.error, exitCode: result.status, logFile });
  }
  emit(results.every(result => result.ok), {
    mode: 'native', services: results,
    startupErrors: results.filter(result => !result.ok).map(result => `${result.serviceName}: ${result.detail || result.logFile}`),
  });
}
if (!process.argv.includes('--native-runtime') && appRootCandidate && managedBackends.length > 1) {
  // legacy 段稍后才定义 isMaven/mvnCmd；托管分支自带一份，避免 TDZ
  const isMavenManaged = existsSync(resolve(backendDir, 'pom.xml'));
  const mvnCmdManaged = existsSync(resolve(backendDir, 'mvnw'))
    ? resolve(backendDir, 'mvnw')
    : (() => { try { execSync('which mvnd', { stdio: 'ignore' }); return 'mvnd'; } catch { return 'mvn'; } })();
  const serviceResults = [];
  const startupErrorsManaged = [];
  for (const svc of managedBackends) {
    const serviceName = String(svc.serviceName || '');
    const port = Number(svc.port);
    const ensure = spawnSync('service-manager', ['ensure', '--service', serviceName], {
      cwd: appRootCandidate, encoding: 'utf-8', timeout: 900_000, maxBuffer: 16 * 1024 * 1024,
      env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}) },
    });
    const ensureTail = `${ensure.stdout || ''}\n${ensure.stderr || ''}`.trim().split('\n').filter(Boolean).slice(-6).join(' | ');
    let ok = ensure.status === 0;
    let detail = ok ? '' : `ensure exit ${ensure.status}：${ensureTail || '（无输出）'}`;
    if (ok) {
      ok = await waitForServiceHealth(port, 120_000);
      if (!ok) detail = `ensure 成功但 ${port}/health 在 120s 内未就绪`;
    }
    serviceResults.push({
      serviceName, port, status: ok ? 'UP' : 'DOWN', detail,
      logDir: resolve(appRootCandidate, '.log', serviceName),
    });
    if (!ok) startupErrorsManaged.push(`[服务启动] ${serviceName}（端口 ${port}）失败：${detail}`);
  }
  const startupOkManaged = startupErrorsManaged.length === 0;

  // contextLoad 冒烟：只跑启动类/上下文测试（*ApplicationTests / *ContextLoad* / *SmokeTest），
  // 全量单测与业务断言留给 B1（避免 C0 与 B1 重复跑同一批测试）。
  // contextLoad 验证（与单端语义对齐）：每服务跑「最小测试集」，只 gate Errors；
  // 全量测试与业务断言（Failures）留给 B1，不在 C0 重复。
  const contextLoadResults = [];
  const contextLoadReportFiles = [];
  let contextLoadSkipped = false;
  if (startupOkManaged && isMavenManaged) {
    const targets = collectPerServiceSmokeTests(backendDir, managedBackends);
    if (!targets.length) contextLoadSkipped = true;
    for (const target of targets) {
      const smokeStartedAt = Date.now();
      const run = spawnSync(mvnCmdManaged, ['-q', '-B', '-pl', target.moduleDir, 'test',
        `-Dtest=${target.className}`, '-DfailIfNoTests=false', '-Dsurefire.failIfNoSpecifiedTests=false'], {
        cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024, timeout: 300_000,
        env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}) },
      });
      let errors = 0;
      const reports = [];
      // 只扫**本服务模块**的 surefire 目录：跨模块扫描会把别的服务的报告错记到本服务名下
      const moduleSurefireDir = join(backendDir, target.moduleDir, 'target', 'surefire-reports');
      for (const dir of (existsSync(moduleSurefireDir) ? [moduleSurefireDir] : [])) {
        let files = [];
        try { files = readdirSync(dir).filter((n) => n.endsWith('.txt') && !n.startsWith('TEST-')); } catch { continue; }
        for (const f of files) {
          const absReport = resolve(dir, f);
          // 只统计本次运行新产出的报告，避免旧 surefire .txt 误判
          try { if (statSync(absReport).mtimeMs < smokeStartedAt - 5_000) continue; } catch { continue; }
          let content = '';
          try { content = readFileSync(absReport, 'utf-8'); } catch { continue; }
          const m = content.match(/Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+)/);
          if (!m) continue;
          const errCount = Number(m[3] || 0);
          if (errCount > 0) { errors += errCount; reports.push(f); }
        }
      }
      if (run.status !== 0 && errors === 0) {
        // 编译/装配失败且无 surefire 报告：优先取编译错误行（含 .java 路径/找不到符号）
        const output = `${run.stdout || ''}\n${run.stderr || ''}`;
        const compileLines = output.split('\n').filter((line) => /\[ERROR\].*\.java|找不到符号|cannot find symbol|COMPILATION ERROR/.test(line)).slice(0, 5);
        errors = 1;
        reports.push(`(mvn exit ${run.status}) ${(compileLines.join(' | ') || output.trim().split('\n').slice(-4).join(' | ')).slice(0, 500)}`);
      }
      contextLoadResults.push({
        serviceName: target.serviceName, moduleDir: target.moduleDir,
        testClass: target.className, status: errors > 0 ? 'FAILED' : 'OK', errors,
      });
      if (errors > 0) {
        contextLoadReportFiles.push(...reports.filter((r) => r.endsWith('.txt')));
        startupErrorsManaged.push(`[contextLoad] ${target.serviceName} / ${target.className}（Errors=${errors}）`
          + (reports.length ? `：${reports.slice(0, 3).join('；')}` : ''));
      }
      // Failures 不计入 C0（业务断言失败留给 B1）
    }
  }
  const contextLoadErrorsManaged = contextLoadResults.reduce((sum, item) => sum + item.errors, 0);

  const allErrors = [...startupErrorsManaged];
  const isFullyGreenManaged = startupOkManaged && allErrors.length === 0;
  const payload = {
    mode: 'managed',
    services: serviceResults,
    startupErrors: allErrors,
    contextLoadErrors: contextLoadErrorsManaged,
    contextLoadSkipped,
    contextLoadResults,
    contextLoadReportFiles,
    totals: {
      services: serviceResults.length,
      up: serviceResults.filter((s) => s.status === 'UP').length,
      down: serviceResults.filter((s) => s.status === 'DOWN').length,
      errorCount: allErrors.length,
    },
  };
  if (isFullyGreenManaged) {
    emit(true, {
      ...payload,
      summary: `托管启动验证通过：${payload.totals.up}/${payload.totals.services} 个后端服务健康`
        + (contextLoadSkipped
          ? '；每服务未找到可用 ServiceTest（contextLoad 交由 B1 全量单测覆盖）'
          : `；contextLoad 每服务最小测试集 Errors=0（${contextLoadResults.length} 个服务）`),
    });
  } else {
    emit(false, {
      ...payload,
      failures: [
        `托管启动验证失败：${payload.totals.up}/${payload.totals.services} 个服务健康，共 ${allErrors.length} 条错误`,
        ...allErrors.slice(0, 60),
      ],
    });
  }
  process.exit(isFullyGreenManaged ? 0 : 1);
}

// 2. 跑 mvn spring-boot:run
const isMaven = existsSync(resolve(backendDir, 'pom.xml'));
const mvnCmd = existsSync(resolve(backendDir, 'mvnw'))
  ? resolve(backendDir, 'mvnw')
  : (() => { try { execSync('which mvnd', { stdio: 'ignore' }); return 'mvnd'; } catch { return 'mvn'; } })();

// 多模块聚合工程（根 pom packaging=pom）时，spring-boot:run / test-compile 必须落在「含 @SpringBootApplication
// 启动类」的子模块，否则父 POM 无 main class 报 Unable to find a suitable main class。
// 追加 -pl <模块相对名> -am：-pl 指定启动模块，-am 一并构建其依赖模块（spring-boot:run 需要依赖模块 artifact 可解析）。
const bootModuleDir = findBootModuleDir(backendDir);
// spring-boot:run 是 default-cli goal，带 -am 会从根 POM（packaging=pom，无 main class）也执行一次而报错；
// 故 run 只用 -pl 启动模块（无 -am）。install/test-compile 则需 -am 一并构建依赖模块，否则依赖链 artifact 缺失。
const bootModuleIndex = bootModuleDir && resolve(bootModuleDir) !== resolve(backendDir)
  ? ['-pl', basename(bootModuleDir)]
  : [];
const runSelector = bootModuleIndex;
const buildSelector = bootModuleIndex.length ? [...bootModuleIndex, '-am'] : [];
const mvnArgs = ['-q', '-B', ...runSelector, 'spring-boot:run'];

// 类路径不匹配：先确保 target/classes 存在（spring-boot:run 依赖已编译的类）
if (isMaven && existsSync(resolve(bootModuleDir || backendDir, 'target', 'classes'))) {
  // classes 已就绪，直接跑
} else if (isMaven) {
  let preCompile = spawnSync(mvnCmd, ['-q', '-B', ...buildSelector, 'install', '-DskipTests'], {
    cwd: backendDir,
    encoding: 'utf-8',
    maxBuffer: 64 * 1024 * 1024,
    timeout: 120_000,
    env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
  });
  // ── mvnd 崩溃退化到 mvn（preCompile 是 target/classes 缺失时的首个 mvnd 使用点）──
  const _pcOut = `${preCompile.stdout || ''}\n${preCompile.stderr || ''}`;
  if (mvnCmd === 'mvnd' && preCompile.status !== 0
      && /Read-only file system|DaemonException/.test(_pcOut)) {
    preCompile = spawnSync('mvn', ['-q', '-B', ...buildSelector, 'install', '-DskipTests'], {
      cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024, timeout: 120_000,
      env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
    });
  }
  if (preCompile.error || preCompile.status !== 0) {
    emit(false, {
      failures: [
        `启动前强制编译失败（${mvnCmd} install -DskipTests exit ${preCompile.status}）：启动需要依赖链已安装的 jar`,
        (preCompile.stderr || '').slice(-2000),
      ],
    });
  }
}

// 启动前清理端口旧占用（上次脚本运行残留的孤儿 Java 进程）
killPortProcessSync(serverPort);

// 异步 spawn spring-boot:run + 轮询端口/health，启动成功立即 kill 进程继续（不再等满 60s 超时）。
// 启动失败（进程自退 status≠0）时收集 stdout/stderr 供异常提取。
const springEnv = { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' };
const { startupOk, stdout, stderr } = await runSpringBootAndWait(mvnCmd, mvnArgs, backendDir, serverPort, springEnv);
let combined = `${stdout}\n${stderr}`;

// 4. 启动失败 → 提取异常行（扁平清单，不归桶）；启动成功 → 跳过
const startupErrors = [];
let beanErrors = 0;
let bindingErrors = 0;
if (!startupOk) {
  // 4a. Bean 创建失败：Error creating bean / UnsatisfiedDependency
  beanErrors = (combined.match(/(?:Error creating bean|UnsatisfiedDependency|No qualifying bean|BeanCreationException).*$/gm) || []).length;
  for (const match of combined.match(/(?:Error creating bean|UnsatisfiedDependency|No qualifying bean|BeanCreationException).*$/gm) || []) {
    startupErrors.push(`[Bean创建] ${match.trim()}`);
  }

  // 4b. BindingException：Mapper XML 缺绑定
  bindingErrors = (combined.match(/Invalid bound statement/g) || []).length;
  for (const match of combined.match(/Invalid bound statement \(not found\)[^\n]*/g) || []) {
    startupErrors.push(`[MyBatis缺绑定] ${match.trim()}`);
  }

  // 4c. APPLICATION FAILED TO START 块 — 核心错误段
  const appFailIdx = combined.indexOf('APPLICATION FAILED TO START');
  if (appFailIdx >= 0) {
    const descBlock = combined.slice(appFailIdx, appFailIdx + 6000);
    for (const descLine of descBlock.split(/\n/)) {
      const trimmed = descLine.trim();
      if (!trimmed) continue;
      if (/^\s*(?:Description|Action):/.test(trimmed)) continue;
      if (/^\*+$/.test(trimmed) || /^:/.test(trimmed)) continue;
      if (trimmed === 'APPLICATION FAILED TO START') continue;
      startupErrors.push(`[启动失败] ${trimmed}`);
    }
  }

  // 4d. Caused by 链（只取顶层 cause，防噪音）
  const causedByRe = /\nCaused by: [^\n]+/g;
  const seenCauses = new Set();
  let m2;
  while ((m2 = causedByRe.exec(combined)) !== null) {
    const line = m2[0].trim();
    const simple = line.replace(/Caused by: /, '').slice(0, 120);
    if (seenCauses.has(simple)) continue;
    seenCauses.add(simple);
    // 跳过嵌套 HikariPool / JDBC driver / Tomcat 等框架内部异常
    if (/HikariPool|Tomcat|JDBC|jdbc|Driver|ClassNotFound/.test(simple)) continue;
    startupErrors.push(`[CausedBy] ${line}`);
  }

  // 4e. SQL 约束/完整性错误
  for (const line of combined.split(/\n/)) {
    const trimmed = line.trim();
    if (/SQLIntegrityConstraintViolationException|DataIntegrityViolationException|Cannot add or update a child row|Duplicate entry|Column .* cannot be null|Data too long for column|doesn't have a default value/.test(trimmed)) {
      startupErrors.push(`[SQL约束] ${trimmed}`);
    }
  }
}

// 4f. 启动失败但 stdout/stderr 无解析到错误 → 尝试读 Spring Boot 日志文件回退。
let logTail = '';
let applicationLog = null;
if (!startupOk && startupErrors.length === 0) {
  try {
    const ymlPath = resolve(backendDir, 'src', 'main', 'resources', 'application.yml');
    let logFilePath = null;
    if (existsSync(ymlPath)) {
      const yml = readFileSync(ymlPath, 'utf-8');
      const m = yml.match(/logging:\s*\n\s*file(?:\.name)?:\s*(\S+)/) ||
               yml.match(/logging\.file(?:\.name)?=(\S+)/);
      if (m) logFilePath = m[1];
    }
    if (!logFilePath) {
      const devYmlPath = resolve(backendDir, 'src', 'main', 'resources', 'application-dev.yml');
      if (existsSync(devYmlPath)) {
        const devYml = readFileSync(devYmlPath, 'utf-8');
        const m = devYml.match(/logging:\s*\n\s*file(?:\.name)?:\s*(\S+)/) ||
                 devYml.match(/logging\.file(?:\.name)?=(\S+)/);
        if (m) logFilePath = m[1];
      }
    }
    if (logFilePath) {
      logFilePath = logFilePath.replace(/\$\{(\w+):([^}]*)\}/g, (_, varName, defaultVal) =>
        process.env[varName] || defaultVal
      );
      const absLog = resolve(backendDir, logFilePath);
      if (existsSync(absLog)) {
        applicationLog = absLog;
        const logContent = readFileSync(absLog, 'utf-8');
        const tailLines = logContent.split('\n').slice(-100).join('\n');
        if (tailLines.trim()) {
          logTail = tailLines;
          combined = `${combined}\n--- Spring Boot 日志(${logFilePath})末尾 100 行 ---\n${tailLines}`;
          if (/Error creating bean|UnsatisfiedDependency|No qualifying bean|BeanCreationException/i.test(tailLines)) {
            for (const match of (tailLines.match(/(?:Error creating bean|UnsatisfiedDependency|No qualifying bean|BeanCreationException).*$/gm) || [])) {
              startupErrors.push(`[日志-Bean创建] ${match.trim()}`);
            }
          }
          if (/Invalid bound statement/i.test(tailLines)) {
            for (const match of (tailLines.match(/Invalid bound statement \(not found\)[^\n]*/g) || [])) {
              startupErrors.push(`[日志-MyBatis缺绑定] ${match.trim()}`);
            }
          }
          const appFailIdx = tailLines.indexOf('APPLICATION FAILED TO START');
          if (appFailIdx >= 0) {
            const descBlock = tailLines.slice(appFailIdx, appFailIdx + 6000);
            for (const descLine of descBlock.split(/\n/)) {
              const trimmed = descLine.trim();
              if (!trimmed || /^\s*(?:Description|Action):/.test(trimmed) || /^\*+$/.test(trimmed) || /^:/.test(trimmed) || trimmed === 'APPLICATION FAILED TO START') continue;
              startupErrors.push(`[日志-启动失败] ${trimmed}`);
            }
          }
          const causedByRe = /\nCaused by: [^\n]+/g;
          const bcSet = new Set();
          let m2;
          while ((m2 = causedByRe.exec(tailLines)) !== null) {
            const line = m2[0].trim();
            const simple = line.replace(/Caused by: /, '').slice(0, 120);
            if (bcSet.has(simple) || /HikariPool|Tomcat|JDBC|jdbc|Driver|ClassNotFound/.test(simple)) continue;
            bcSet.add(simple);
            startupErrors.push(`[日志-CausedBy] ${line}`);
          }
          for (const line of tailLines.split(/\n/)) {
            if (/SQLIntegrityConstraintViolationException|DataIntegrityViolationException|Cannot add or update a child row|Duplicate entry|Column .* cannot be null|Data too long for column|doesn't have a default value/.test(line)) {
              startupErrors.push(`[日志-SQL约束] ${line.trim()}`);
            }
          }
        }
      }
    }
  } catch { /* 日志文件读取失败不阻断主流程 */ }
}

// 5. contextLoad 验证（启动成功后）：跑 test-compile + mvnd test，挑 Errors。
// 主应用 spring-boot:run 只加载被 @Autowired 的 bean，缺 @Service 的类不被扫描也不报错；
// 而 @SpringBootTest 测试类 @Autowired Service 会触发 No qualifying bean → contextLoad 失败。
// 故 C0 启动绿后加跑全量 test，把 Bean 注入类错误（Errors）前移到 C0 修，业务断言（Failures）留 B1。
// 只 gate Errors，Failures 不计入 C0 退出码。
let contextLoadErrors = 0;
let contextLoadFailures = 0; // 业务断言失败，仅统计（留 B1）
const contextLoadReportFiles = []; // 有 Error 的 .txt 文件名清单（供协调者 cat 兜底）
const failureDetails = {}; // key=文件名，value=截断摘要（砍框架栈+删###SQL行+同根因去重），协调者优先读
let surefireDir = null;
let surefireDirs = []; // 多模块：所有 surefire-reports 目录（含根 + 子模块），emit 供协调者按模块 cat 兜底
if (startupOk) {
  // 6-1. test-compile：确保测试类编译过
  let testCompile = spawnSync(mvnCmd, ['-q', '-B', ...buildSelector, 'test-compile', '-DskipTests'], {
    cwd: backendDir,
    encoding: 'utf-8',
    maxBuffer: 64 * 1024 * 1024,
    timeout: 180_000,
    env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
  });
  // ── mvnd 崩溃退化到 mvn（contextLoad 前置 test-compile）──
  const _tcOut = `${testCompile.stdout || ''}\n${testCompile.stderr || ''}`;
  if (mvnCmd === 'mvnd' && testCompile.status !== 0
      && /Read-only file system|DaemonException/.test(_tcOut)) {
    testCompile = spawnSync('mvn', ['-q', '-B', ...buildSelector, 'test-compile', '-DskipTests'], {
      cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024, timeout: 180_000,
      env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
    });
  }
  if (testCompile.error || testCompile.status !== 0) {
    // 测试类编译失败：暴露编译错行
    const tcOut = `${testCompile.stdout || ''}\n${testCompile.stderr || ''}`;
    const tcErrorLines = tcOut.match(/\[ERROR\][^\n]*\.java[^\n]*/g) || [];
    if (tcErrorLines.length === 0 && tcOut.trim()) {
      tcErrorLines.push(`[测试编译] test-compile exit ${testCompile.status}：${tcOut.slice(-1500)}`);
    }
    for (const l of tcErrorLines) {
      startupErrors.push(`[测试编译] ${l.trim()}`);
    }
    contextLoadErrors += tcErrorLines.length || 1;
  } else {
    // 6-2. mvnd test：跑全量单测，解析 surefire .txt 挑 Errors（Failures 不计入 C0）
    let testRun = spawnSync(mvnCmd, ['-q', '-B', 'test', '-DfailIfNoTests=false'], {
      cwd: backendDir,
      encoding: 'utf-8',
      maxBuffer: 64 * 1024 * 1024,
      timeout: 300_000,
      env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
    });
    // ── mvnd 崩溃退化到 mvn（contextLoad 全量 test）──
    const _trOut = `${testRun.stdout || ''}\n${testRun.stderr || ''}`;
    if (mvnCmd === 'mvnd' && testRun.status !== 0
        && /Read-only file system|DaemonException/.test(_trOut)) {
      testRun = spawnSync('mvn', ['-q', '-B', 'test', '-DfailIfNoTests=false'], {
        cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024, timeout: 300_000,
        env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
      });
    }
    // 多模块 reactor：surefire .txt 落各子模块 target/surefire-reports/，根 target/（packaging=pom）无报告。
    // collectSurefireReportDirs 扫全模块（含根），合并所有目录的 .txt（文件名=测试类 FQN 去重）。
    // 旧「只读根 target」致多模块下 contextLoad Error 的 .txt 扫不到 → 退化 stdout 尾部兜底，丢 per-test FQN + failureDetails 粒度。
    const _surefireDirs = collectSurefireReportDirs(backendDir);
    surefireDirs = _surefireDirs;
    surefireDir = _surefireDirs.length > 0 ? _surefireDirs[0] : resolve(backendDir, 'target', 'surefire-reports');
    let sfFiles = [];
    for (const sfDir of surefireDirs) {
      let files;
      try {
        files = readdirSync(sfDir).filter((n) => n.endsWith('.txt') && !n.startsWith('TEST-'));
      } catch { continue; }
      for (const repFile of files) {
        if (!sfFiles.includes(repFile)) sfFiles.push(repFile); // 跨模块同名 FQN 去重
      }
    }
    for (const repFile of sfFiles) {
      let content;
      for (const sfDir of surefireDirs) {
        const repPath = resolve(sfDir, repFile);
        if (existsSync(repPath)) {
          try { content = readFileSync(repPath, 'utf-8'); } catch { continue; }
          break;
        }
      }
      if (content === undefined) continue;
      const testFQN = basename(repFile, '.txt');
      const sumM = content.match(/Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+)/);
      const f = Number(sumM?.[2] || 0);
      const e = Number(sumM?.[3] || 0);
      if (e === 0) {
        // 该类无 Error（Failures 是业务断言，留 B1，不计 C0）
        if (f > 0) contextLoadFailures += f;
        continue;
      }
      // 该类有 Error：记录 .txt 文件名 + 截断摘要（协调者优先读 failureDetails，不够再 cat .txt 兜底）
      const isContextLoad = /Failed to load ApplicationContext/i.test(content);
      const isBeanIssue = /No qualifying bean|UnsatisfiedDependency|BeanCreationException|Error creating bean/i.test(content);
      const beanMissingMatch = content.match(/No qualifying bean of type ['"]([^'"]+)['"]/);
      const beanMissingType = beanMissingMatch ? beanMissingMatch[1] : null;
      const tag = isContextLoad || isBeanIssue ? 'contextLoad' : '测试Error';
      const detail = beanMissingType ? ` 缺 bean: ${beanMissingType}（impl 缺 @Service/@Repository 注解）` : '';
      startupErrors.push(`[${tag}] ${testFQN}（Errors=${e}${detail}）`);
      contextLoadReportFiles.push(repFile);
      failureDetails[repFile] = extractFailureDigest(content);
      contextLoadErrors += e;
    }
    // testRun 非零退出但全模块无 surefire 报告（极端：测试未运行/报告未落盘）→ 兜底
    if (testRun.status !== 0 && sfFiles.length === 0) {
      const trOut = `${testRun.stdout || ''}\n${testRun.stderr || ''}`;
      startupErrors.push(`[测试运行] mvnd test exit ${testRun.status}（全模块扫描无 surefire 报告）：${trOut.slice(-1500)}`);
      contextLoadErrors += 1;
    }
  }
}

// 7. emit：全绿 exit 0，否则 exit 1
const errorCount = startupErrors.length;
const isFullyGreen = startupOk && errorCount === 0;

if (!isFullyGreen) {
  const lead = startupOk
    ? (contextLoadErrors > 0
        ? `应用启动成功但 contextLoad/Bean 注入验证发现 ${contextLoadErrors} 条 Error（多为 impl 缺 @Service/@Repository 注解）`
        : `应用启动成功但发现错误`)
    : `应用启动失败：${errorCount - contextLoadErrors} 条启动错误`;
  emit(false, {
    failures: [
      `${lead}；共 ${errorCount} 条错误` +
      (contextLoadFailures > 0 ? `（另有 ${contextLoadFailures} 条业务断言 Failures 不计入 C0，留 B1 修）` : ''),
      ...startupErrors.slice(0, 100),
      // 0 错误但启动失败 → 暴露 raw output 让 agent 看到真实输出
      ...(!startupOk && errorCount === 0 && combined.trim()
        ? [`启动进程原始输出（stdout+stderr 末尾 3000 字符，供定位根因）：\n${combined.slice(-3000)}`]
        : []),
    ],
    startupErrors: startupErrors.slice(0, 200),
    applicationLog,
    surefireDir: existsSync(surefireDir || '') ? surefireDir : null,
    surefireDirs: (surefireDirs || []).filter((d) => existsSync(d)),
    contextLoadReportFiles,
    failureDetails,
    contextLoadErrors,
    contextLoadFailures,
    totals: { errorCount, beanErrors, bindingErrors, contextLoadErrors, contextLoadFailures },
  });
}

emit(true, {
  summary: startupOk
    ? `应用启动成功，contextLoad 验证通过（Errors=0${contextLoadFailures > 0 ? `，业务断言 Failures=${contextLoadFailures} 留 B1` : ''}）`
    : '应用启动成功，无错误',
  surefireDir: existsSync(surefireDir || '') ? surefireDir : null,
  surefireDirs: (surefireDirs || []).filter((d) => existsSync(d)),
});
