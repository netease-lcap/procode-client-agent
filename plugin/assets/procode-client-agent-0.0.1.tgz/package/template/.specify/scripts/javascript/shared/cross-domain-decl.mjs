// 跨域关系成文判据（check-backend-design.mjs cross-domain-decl）的归一/抽取/文件解析单源
// （plan 2026-10-24/stage5-repair-chain-convergence D2/D3/D5/D6）。
//
// 单源纪律：check-backend-design.mjs 与本仓脚本测试共用本文件；判据比对前必须过 normalizeDeclText，
// 禁在别处再写一份空白/反引号/全半角/基数归一（两份判据各自绿却互相矛盾是本仓已知复发形态）。

import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { isTableRef, refEquals, formatRef } from '../lib/entity-pk-resolver.mjs';

/** 台账相对路径（与 TS 侧 checkers/cross-domain.ts 同值）。 */
export const RELATIONS_LEDGER_REL_PATH = join('_meta', 'cross-domain-relations.json');

/** 成文小节标题（prompt 钉死的行模板所在小节；判据只认二级标题）。 */
export const DECL_SECTION_HEADING = '## 跨域关系';

/**
 * 表名归一比较（与 TS 侧 checkers/cross-domain.ts#normalizeTableNameForCompare 同值同判据）：
 * 剥尾部 6 位 hex hash 后缀 + 小写 + 去下划线（ForumReply_ab8c6f ↔ forum_reply）。
 * 增量轮存量表名带 hash 后缀，纯直命名匹配会漏；两运行时禁互相 import，靠逐值镜像兜底。
 *
 * ⚠ v3 起本函数**只用于展示/人读定位**，禁止作为对象身份比较：身份一律走
 * `{sourceId, owner, kind, name}` 四字段逐字相等（见 `relationTouchesTableRef`）。
 */
export const normalizeTableNameForCompare = (name) =>
  String(name ?? '')
    .trim()
    .toLowerCase()
    .replace(/_[0-9a-f]{6}$/i, '')
    .replace(/_/g, '');

/**
 * 归属判据的扫描范围：实体文档**「## DDL」小节内**的 CREATE/ALTER 表名（与 TS 侧
 * checkers/cross-domain.ts 逐字同源；plan 2026-10-26/carrier-multitable-entity-resolution §5.0/§5.1）。
 *
 * 为什么限小节而非全文：归属在前段 DDL，后段「## 跨域关系」对目标表只是引用性提及；全文扫描会把引用
 * 当归属，重现 F2 要防的「查错文件还绿」。为什么不再只取**首个**表名：一份实体文档可合法承载多张表
 * （1:N 子表与父表同文件），"首表=归属"会把同文件第二张表判成无对应实体文件
 * （2026-10-26 沙箱 carrier=wb_device_status_overview_item 实证恒红 3 轮重试）。
 */
const DDL_SECTION_HEADING_RE = /^## DDL\s*$/m;
const DDL_DECL_TABLE_RE =
  /(?:CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?|ALTER\s+TABLE)\s+[`"]?([a-zA-Z0-9_]+)[`"]?/gi;

/** 抽「## DDL」小节正文（到下一个二级标题为止）；无该标题 → 全文兜底（结构门已对缺标题判红）。 */
function extractDdlSection(text) {
  const raw = String(text ?? '');
  const heading = raw.match(DDL_SECTION_HEADING_RE);
  if (!heading || heading.index === undefined) return raw;
  const rest = raw.slice(heading.index + heading[0].length);
  const nextHeading = rest.search(/^##\s/m);
  return nextHeading === -1 ? rest : rest.slice(0, nextHeading);
}

/** 该实体文档在「## DDL」小节内声明的全部表名（多表文档逐张列出）。 */
export function declaredTablesInEntityDoc(text) {
  const section = extractDdlSection(text);
  const names = [];
  // 共享带 g 的正则：matchAll 从 lastIndex 起算，调用前复位，防跨调用串味。
  DDL_DECL_TABLE_RE.lastIndex = 0;
  for (const m of section.matchAll(DDL_DECL_TABLE_RE)) if (m[1]) names.push(m[1]);
  return names;
}

/** 归属判定：该文档的 DDL 小节声明了 carrier（精确或 hash 归一相等）。 */
export function entityDocDeclaresCarrier(text, carrier) {
  const carrierNorm = normalizeTableNameForCompare(carrier);
  return declaredTablesInEntityDoc(text).some(
    (table) => table === carrier || normalizeTableNameForCompare(table) === carrierNorm,
  );
}

// 台账 file 字段白名单（与 TS 侧逐字同口径）：只接受纯实体文档 basename，禁路径分隔符/穿越/元字符。
const LEDGER_FILE_NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]*\.md$/;

/**
 * 归一函数（全域唯一实现）。
 * 覆盖 D5 的四类合法变体：
 *   ① 空白（含制表/换行）——全删，展示形态不参与比较；
 *   ② 反引号与 markdown 粗体/零宽字符——剥掉，模型加不加格式不算判据差异；
 *   ③ 全半角——NFKC 统一（全角冒号/括号/字母/数字/点全部转半角，`N：1` ≡ `N:1`）；
 *   ④ 箭头形态——→ / ⇒ / —> 统一成 `->`。
 * 大小写一并折叠：表名/字段的展示大小写不构成语义差异（ForumReply_ab8c6f）。
 * 注意：`_` 与 `-` 是 canonical id 的组成部分，不能当格式符号剥掉。
 */
export const normalizeDeclText = (value = '') =>
  String(value)
    .normalize('NFKC')
    .replace(/[​-‍﻿`*]/g, '')
    .replace(/[→⇒⟶]/g, '->')
    .replace(/[–—]{1,2}>/g, '->')
    .replace(/\s+/g, '')
    .toLowerCase();

// 四元组 token：连字符、下划线、数字、CJK 均可出现（canonical id 形态），禁按旧夹具的纯 \w 写死。
const DECL_TOKEN = '[a-z0-9_\\-\\u4e00-\\u9fff]+';
const DECL_TUPLE_RE = new RegExp(
  `(${DECL_TOKEN})\\.(${DECL_TOKEN})->(${DECL_TOKEN})\\.(${DECL_TOKEN})`,
);

/**
 * 从 relationDecl 原文解出四元组（D3：期望值单源 = 清单的 relationDecl，checker 不按 action 重推字段名——
 * `promote-fk-keep-varchar` 的 newField、`mark-snapshot` 的原 field 都已由 detect 编进 relationDecl）。
 * 解析先过归一（全角箭头/空白/反引号均可）；解不出返回 null，由调用方判红（证据不可判禁静默）。
 */
export function parseRelationDecl(decl) {
  const m = normalizeDeclText(decl).match(DECL_TUPLE_RE);
  if (!m) return null;
  return { carrier: m[1], field: m[2], targetTable: m[3], targetField: m[4] };
}

/**
 * 成文义务谓词（脚本侧单源；与 TS 侧 checkers/cross-domain.ts 的同口径谓词 isDeclBlockingRelation
 * 逐值镜像——两运行时禁互相 import，改任一侧须同步另一侧，否则两边各自绿却互相矛盾）。
 *
 * 当前契约：只有「非 merge-into 且 targetTable 为非空串」的关系进入阻断层。
 * 为什么：阻断层判的是「目标表名 + carrier 字段 token 在场」，期望值只能取材于 targetTable/field。
 * targetTable 为空的条目（manual-review 多态待人工确认 / 未建模快照）没有可机械比对的目标表名，
 * 判据给不出 agent 能满足的期望值 ⇒ 纳入即成恒红（2026-10-30 沙箱实证：这类条目被当成成文义务后
 * checker 恒红、apply agent 无权改清单判定字段，4 轮逐字相同输出 stale-abort，整轮 plan error）。
 * 口径与 merge-into 的既有排除、以及 check-backend-design.mjs:895 的 manual-review 豁免一致。
 *
 * parseRelationDecl 解不出四元组不再等于 blocker（证据不可解析 ≠ 产物缺失）：解析仍可返回 null，
 * 由调用方把该条降级为 advisory；本谓词不依赖 relationDecl 的可解析性。
 */
export function hasDeclObligation(relation) {
  return Boolean(
    relation
      && relation.action !== 'merge-into'
      && typeof relation.targetTable === 'string'
      && relation.targetTable.trim() !== '',
  );
}

/**
 * 抽「## 跨域关系」小节。
 * 返回 { present, entries }：present=false ⇒ 小节缺失（D6 判红）；entries 为小节内全部非空行
 * （bullet / 表格 / prose 一视同仁，判据不做格式校验）；entries.length===0 ⇒ 空小节（D6 判红）。
 * 只在小节边界（下一个一级/二级标题）处截断，`###` 子标题属小节内容。
 */
export function extractCrossDomainSection(text) {
  const lines = String(text ?? '').split(/\r?\n/);
  const start = lines.findIndex((line) => /^##\s*跨域关系/.test(line.trim()));
  if (start === -1) return { present: false, entries: [] };
  const entries = [];
  for (let i = start + 1; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (/^#{1,2}\s/.test(trimmed)) break;
    if (trimmed) entries.push(trimmed);
  }
  return { present: true, entries };
}

/**
 * carrier（DDL 表名）→ entity 文件名（只读版，与 TS 侧 resolveEntityFileNameByCarrier 三级同源）：
 *   1. 台账对账：relations[] 中本 carrier 条目自报的 file（须过 basename 白名单，且该文件「## DDL」
 *      小节**声明了** carrier——LLM 自报可能幻觉，无条件信会「查错文件还绿」）；
 *   2. 直命名 entity-${carrier}.md；
 *   3. 扫描兜底：每文件取「## DDL」小节内全部声明表名（多表文档逐张比对），全目录唯一命中才算数
 *      （多命中=两个实体都主张该 carrier）。
 * 归属判据是「DDL 小节声明集包含 carrier」，不是「首个 DDL 表名相等」——一份实体文档可合法承载多张表，
 * 后者会把同文件第二张表判成无对应实体文件（见 entityDocDeclaresCarrier 注释）。
 * 解析不到仍回直命名，保留可观察 ENOENT 信号，不静默跳过。
 * 与 TS 侧的差异：本版本**不写回台账**（checker 只读，自愈写回归 TS 侧单写者）。
 * 调用方只对返回的这一个文件跑判据——除定位所需的扫描外不评测任何其它实体文件（禁目录全扫口径）。
 */
export function resolveEntityFileNameByCarrier(entityDir, carrier, relationsDoc = null) {
  let doc = relationsDoc;
  if (!doc) {
    try {
      doc = JSON.parse(readFileSync(join(entityDir, RELATIONS_LEDGER_REL_PATH), 'utf8'));
    } catch {
      doc = null;
    }
  }
  const ledgerRelations = Array.isArray(doc?.relations) ? doc.relations : [];
  const fromLedger = ledgerRelations.find(
    (r) => r?.carrier === carrier && typeof r?.file === 'string' && LEDGER_FILE_NAME_RE.test(r.file),
  )?.file;
  if (fromLedger) {
    try {
      const text = readFileSync(join(entityDir, fromLedger), 'utf8');
      if (entityDocDeclaresCarrier(text, carrier)) return fromLedger;
    } catch {
      // 台账指向的文件读不到 → 落直命名/扫描
    }
  }
  const direct = `entity-${carrier}.md`;
  try {
    if (existsSync(join(entityDir, direct))) return direct;
    const files = readdirSync(entityDir).filter((f) => /^entity-.*\.md$/.test(f));
    const hits = [];
    for (const f of files) {
      const text = readFileSync(join(entityDir, f), 'utf8');
      if (entityDocDeclaresCarrier(text, carrier)) hits.push(f);
    }
    if (hits.length === 1) return hits[0];
  } catch {
    // entityDir 不可读等异常 → 回直命名，让调用方以可观察的 ENOENT 判红
  }
  return direct;
}

// ─── v3 引用：实体文档 tableRefs 元数据 / DDL 段绑定 / 关系端点 ────────────────

/** 多表实体文档的引用元数据小节标题（二级标题，JSON fenced block 在其内）。 */
export const TABLE_REFS_SECTION_HEADING = '## tableRefs';

const SQL_IDENTIFIER_PART = '`(?:[^`]|``)+`|"(?:[^"]|"")*"|\\[[^\\]]+\\]|[A-Za-z0-9_$#]+';
const CREATE_TABLE_ANCHOR_RE = new RegExp(
  `CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?((?:${SQL_IDENTIFIER_PART})(?:\\s*\\.\\s*(?:${SQL_IDENTIFIER_PART}))*)`,
  'gi',
);

function unquoteSqlIdentifier(token) {
  const text = String(token || '').trim();
  if ((text.startsWith('`') && text.endsWith('`')) || (text.startsWith('"') && text.endsWith('"'))) {
    return text.slice(1, -1).replace(/``/g, '`').replace(/""/g, '"');
  }
  if (text.startsWith('[') && text.endsWith(']')) return text.slice(1, -1);
  return text;
}

/** `dbo.orders` → { owner:'dbo', name:'orders' }；无 owner → owner:null。按 SQL 语法解析，不猜身份。 */
export function splitQualifiedTableName(qualified) {
  const parts = String(qualified || '')
    .split(/\s*\.\s*/)
    .filter(Boolean)
    .map(unquoteSqlIdentifier);
  if (parts.length === 0) return { owner: null, name: '' };
  return { owner: parts.length > 1 ? parts[parts.length - 2] : null, name: parts[parts.length - 1] };
}

/** 抽 `## tableRefs` 小节内的 JSON fenced block 原文；无小节/无块 → null。 */
function extractTableRefsJsonBlock(text) {
  const raw = String(text ?? '');
  const lines = raw.split(/\r?\n/);
  const start = lines.findIndex((line) => line.trim().replace(/\s+/g, ' ') === TABLE_REFS_SECTION_HEADING);
  if (start === -1) return null;
  let inFence = false;
  let fenceLang = '';
  const collected = [];
  for (let i = start + 1; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (!inFence && /^#{1,2}\s/.test(trimmed)) break;
    if (!inFence) {
      const opening = trimmed.match(/^```\s*([A-Za-z0-9_-]*)\s*$/);
      if (opening) {
        inFence = true;
        fenceLang = opening[1].toLowerCase();
        continue;
      }
      continue;
    }
    if (trimmed === '```') {
      if (fenceLang && fenceLang !== 'json') return null;
      return collected.join('\n');
    }
    collected.push(lines[i]);
  }
  return null;
}

/**
 * 解析多表实体文档的 `tableRefs` 元数据。
 *
 * 支持两种等价写法（都在 `## tableRefs` 小节内、```json 块中）：
 *   ① `{"schemaVersion":1,"tableRefs":[ref1, ref2]}` —— 按 CREATE TABLE 出现顺序逐段绑定；
 *   ② `{"schemaVersion":1,"bindings":[{"segment":1,"tableRef":ref1}, ...]}` —— 显式段号绑定。
 *
 * 返回 `{ present:false }` / `{ present:true, bindings:[{segment, tableRef}] }` / `{ present:true, error }`。
 * 引用必须是四字段合法值；**不接受裸表名或 objectId**。
 */
export function parseTableRefsMetadata(text) {
  const block = extractTableRefsJsonBlock(text);
  if (block === null) return { present: false };
  let parsed;
  try {
    parsed = JSON.parse(block);
  } catch (error) {
    return { present: true, error: `${TABLE_REFS_SECTION_HEADING} 的 JSON 不可解析：${error.message}` };
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { present: true, error: `${TABLE_REFS_SECTION_HEADING} 元数据顶层必须是对象` };
  }
  const bindings = [];
  const push = (segment, tableRef, label) => {
    if (!isTableRef(tableRef)) {
      bindings.push({
        error:
          `${label} 不是合法 tableRef（需 {sourceId, owner, kind:'table', name}；owner 无值写 null）。` +
          '恢复：按 v3 引用重写元数据，禁止写裸表名/objectId。',
      });
      return;
    }
    bindings.push({ segment, tableRef });
  };

  if (Array.isArray(parsed.tableRefs)) {
    parsed.tableRefs.forEach((tableRef, index) => push(index + 1, tableRef, `tableRefs[${index}]`));
  } else if (Array.isArray(parsed.bindings)) {
    parsed.bindings.forEach((item, index) => {
      if (!item || typeof item !== 'object') {
        bindings.push({ error: `bindings[${index}] 必须是对象` });
        return;
      }
      const segment = Number(item.segment);
      if (!Number.isInteger(segment) || segment < 1) {
        bindings.push({ error: `bindings[${index}].segment 必须是 ≥1 的整数` });
        return;
      }
      push(segment, item.tableRef, `bindings[${index}].tableRef`);
    });
  } else {
    return { present: true, error: `${TABLE_REFS_SECTION_HEADING} 必须含 tableRefs 数组或 bindings 数组` };
  }

  const error = bindings.find((item) => item.error);
  if (error) return { present: true, error: error.error };
  return { present: true, bindings: bindings.map(({ segment, tableRef }) => ({ segment, tableRef })) };
}

/**
 * 抽实体文档中全部 CREATE TABLE 段（按出现顺序），每段带表名与完整定义文本。
 * 段文本 = `CREATE TABLE ... (...)` 原文；括号匹配考虑引号内字符，避免被列注释里的括号带偏。
 * @returns {Array<{ ordinal:number, tableName:string, owner:string|null, text:string }>}
 */
export function extractCreateTableSegments(text) {
  const raw = String(text ?? '');
  const segments = [];
  CREATE_TABLE_ANCHOR_RE.lastIndex = 0;
  let match;
  while ((match = CREATE_TABLE_ANCHOR_RE.exec(raw)) !== null) {
    const qualified = match[1];
    const openParen = raw.indexOf('(', match.index + match[0].length);
    if (openParen === -1) continue;
    let depth = 0;
    let quote = null;
    let end = -1;
    for (let i = openParen; i < raw.length; i++) {
      const ch = raw[i];
      if (quote) {
        if (ch === quote) {
          if (raw[i + 1] === quote) i++;
          else quote = null;
        }
        continue;
      }
      if (ch === "'" || ch === '"' || ch === '`') {
        quote = ch;
        continue;
      }
      if (ch === '(') depth++;
      else if (ch === ')') {
        depth--;
        if (depth === 0) {
          end = i;
          break;
        }
      }
    }
    if (end === -1) continue;
    const { owner, name } = splitQualifiedTableName(qualified);
    segments.push({ ordinal: segments.length + 1, tableName: name, owner, text: raw.slice(match.index, end + 1) });
    CREATE_TABLE_ANCHOR_RE.lastIndex = end + 1;
  }
  return segments;
}

/**
 * 把 DDL 段与 `tableRefs` 元数据逐段绑定（R18：多表文档禁「首表代表全部」）。
 *
 * 返回 `{ ok, failures, bindings:[{segment, tableRef}] }`。
 * 无元数据 → `{ ok:false, needsMetadata:true }`，由调用方按单表兜底或判红。
 */
export function bindCreateTableSegmentsToTableRefs(text) {
  const segments = extractCreateTableSegments(text);
  const metadata = parseTableRefsMetadata(text);
  if (!metadata.present) {
    return { ok: false, needsMetadata: true, failures: [], segments, bindings: [] };
  }
  if (metadata.error) return { ok: false, failures: [metadata.error], segments, bindings: [] };

  const failures = [];
  const byOrdinal = new Map();
  for (const binding of metadata.bindings) {
    if (byOrdinal.has(binding.segment)) {
      failures.push(`tableRefs 元数据段号 ${binding.segment} 重复绑定`);
      continue;
    }
    byOrdinal.set(binding.segment, binding.tableRef);
  }
  for (const segment of segments) {
    if (!byOrdinal.has(segment.ordinal)) {
      failures.push(
        `第 ${segment.ordinal} 个 CREATE TABLE（${segment.tableName}）在 tableRefs 元数据中无绑定：` +
          '多表文档必须逐段绑定引用，禁止让首表代表全部',
      );
    }
  }
  for (const segment of byOrdinal.keys()) {
    if (segment > segments.length) {
      failures.push(`tableRefs 元数据段号 ${segment} 超出文档 CREATE TABLE 数 ${segments.length}`);
    }
  }
  return {
    ok: failures.length === 0,
    failures,
    segments,
    bindings: segments
      .filter((segment) => byOrdinal.has(segment.ordinal))
      .map((segment) => ({ segment, tableRef: byOrdinal.get(segment.ordinal) })),
  };
}

/**
 * 关系条目的端点引用（v3）：`carrierRef`/`targetRef`（或 `tableRef`/`targetTableRef` 别名）。
 * 返回 `[{ role:'carrier'|'target', tableRef }]`；裸表名端点不产出引用。
 */
export function relationEndpointRefs(relation) {
  if (!relation || typeof relation !== 'object') return [];
  const refs = [];
  const carrier = relation.carrierRef ?? relation.tableRef;
  const target = relation.targetRef ?? relation.targetTableRef;
  if (isTableRef(carrier)) refs.push({ role: 'carrier', tableRef: carrier });
  if (isTableRef(target)) refs.push({ role: 'target', tableRef: target });
  return refs;
}

/** 关系是否触及某引用：端点四字段逐字相等（跨源同名绝不命中）。 */
export function relationTouchesTableRef(relation, tableRef) {
  return relationEndpointRefs(relation).some((endpoint) => refEquals(endpoint.tableRef, tableRef));
}

/** 按引用分组关系（键=refKeyOf，进程内）：同名跨源各归各的桶，禁止按裸表名归并。 */
export function groupRelationsByTableRef(relations, tableRef) {
  return (relations || []).filter((relation) => relationTouchesTableRef(relation, tableRef));
}

/** 缺引用端点的人读描述（用于报错，不参与身份比较）。 */
export function describeMissingRelationRef(relation) {
  const name = relation && (relation.carrier || relation.targetTable || relation.target);
  return name ? `关系端点「${name}」缺 v3 引用` : '关系端点缺 v3 引用';
}

/** 引用人读格式转发（避免调用方各写一套）。 */
export { formatRef };
