import { handle } from './tools.mjs';
import check from '../check-ends.mjs';

handle(check);
