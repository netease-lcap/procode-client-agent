#!/usr/bin/env node

/**
 * 1-1.1 增量设计 · 基准合成脚本（纯库 fetcher，code-schema v3）
 *
 * 职责：只连库取每张表的 SHOW CREATE TABLE 原文 + 库表全集，产出 **code-schema v3**
 * （plan-objectid-retirement-and-table-reference §3.1/§3.2：
 *   `{ schemaVersion: 3, inputRevision, generatedAt, sources[] }`，**无全局 tables**）。
 *   不读代码、不做代码字段名反推、不识别脏字段——代码侧字段分类由后续 generate task 处理。
 *
 * 关键收口（FZ-06/07/08、F3 §1.1/§1.2/§4、plan 2026-11-09 §3.1）：
 *   - **objectId 已退役**：对象身份只由引用四元组 `sourceId + owner + kind + name` 表达；
 *     正常路径不派生、不重算、不落任何对象 id；写盘前按四元组校验唯一性，重复即失败。
 *   - sourceId 仍保留：stableJson → sha256 → base64url 截 32 位（采集分组身份，不是连接身份）；
 *   - 绑定身份只来自已确认 binding（`dataSourceName` + `datasources.json#<name>`）；
 *   - 未支持方言（Oracle/PostgreSQL/unknown）显式拒绝，不再落入 MySQL introspection；
 *   - 坐标只来自已确认数据源契约（`$HOME/resources/.manifest/datasources.json` 条目），
 *     不读已退役的本地派生连接配置产物；删除 mcp→local 静默回退；回执记录目标；
 *   - 采集不完整/失败写失败回执（`_meta/code-schema.failure.json`），**不写成功壳**。
 *
 * 产出 plans/backend/_meta/code-schema.json：
 *   { schemaVersion: 3, inputRevision, generatedAt, sources: [{
 *       sourceId, binding:{dataSourceName, entryRef}, databaseType, dialect,
 *       serverVersion, capabilities, scope, channel:"mcp", collectedAt,
 *       completeness:{status,catalogExpected,catalogReturned,objectsParsed,truncated,
 *                     missingPermissions,evidenceRefs},
 *       objects:[{owner,name,quoted,kind,rawDdl,columns,indexes,constraints,
 *                 foreignKeys,comments,tableOptions,parseIssues,diffable,basis}]
 *   }]}
 *   （objects[] 不再有 objectId；引用由程序按 sourceId+owner+kind+name 组装。）
 *
 * 用法：
 *   node extract-code-schema.mjs [--cwd <dir>] [--active-spec-dir <dir>] [--data-source-name <name>]
 *       [--module-id <id>] [--channel mcp] [--app-id <id>] [--include a,b] [--exclude a,b] [--self-test]
 *   `--active-spec-dir` 只决定失败回执落点（`<dir>/plans/backend/_meta/code-schema.failure.json`），
 *   不参与 plans 目录/代码根定位。
 *   采集通道恒为 mcp（本地 MySQL 直连通道已退役，传其它值 → exit 1，不回退）。
 *   坐标来源 = `$HOME/resources/.manifest/datasources.json` 已确认条目（不读任何本地派生连接配置）。
 *   mcp 的 appId 取 `--app-id` > APP_ID > LCAP_APP_ID > NASL_STORAGE_APP_ID。
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync, rmSync } from 'fs';
import { resolve } from 'path';
import { createHash } from 'crypto';
import { resolveIncrementalDatasource } from './shared/mysql-client.mjs';
import {
  executeSqlDirectOnSession,
  openMcpSession,
} from './shared/mcp-sql-client.mjs';
import { findBackendDir, findPlanBackendDir } from './shared/backend-common.mjs';
import {
  assertSingleOwner,
  canonicalDialect,
  foldIdentifierForDialect,
  isQuotedIdentifier,
  stripIdentifierQuotes,
} from './shared/schema/dialect-rules.mjs';

export const CODE_SCHEMA_SCHEMA_VERSION = 3;
const DIALECTS = new Set(['mysql', 'oracle', 'postgresql', 'unknown']);

/**
 * D17：code-schema 的 `inputRevision`（输入批次标识）。
 *
 * 规则：`<generatedAt>#<递增序号>`。同一 `generatedAt` 下续旧值 +1（读不到旧值从 1 开始），
 * 不同 `generatedAt` 自然变化。不引入随机数：值可重放、可对账，且每次生成都会变化，
 * 用于判定 operations/audit 是否基于旧输入批次（变化 ⇒ 旧产物失效，必须重跑 merge/audit）。
 *
 * @param {string} [generatedAt]
 * @param {string} [previousInputRevision]
 * @returns {string}
 */
export function nextInputRevision(generatedAt, previousInputRevision) {
  const prefix =
    typeof generatedAt === 'string' && generatedAt.trim() ? generatedAt : new Date().toISOString();
  let seq = 0;
  if (typeof previousInputRevision === 'string') {
    const sep = previousInputRevision.lastIndexOf('#');
    if (sep >= 0 && previousInputRevision.slice(0, sep) === prefix) {
      const parsed = Number(previousInputRevision.slice(sep + 1));
      if (Number.isSafeInteger(parsed) && parsed >= 0) seq = parsed;
    }
  }
  return `${prefix}#${seq + 1}`;
}

const OBJECT_KINDS = new Set(['table', 'view', 'sequence', 'other']);

export const EVIDENCE_REL = 'plans/backend/_meta/table-structure.evidence.json';
export const TABLE_RAW_REL = 'plans/backend/_meta/table-structure.raw.json';
export const CODE_TABLE_INVENTORY_REL = 'plans/backend/_meta/code-table-inventory.json';
export const DB_TABLE_LIST_REL = 'plans/backend/_meta/db-table-list.json';

// ─── 参数解析 ──────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = {
    selfTest: false,
    dataSourceName: null,
    moduleId: null,
    channel: null,
    appId: null,
    include: null,
    exclude: null,
    objectKind: null,
    pageSize: 80,
    fromEvidence: false,
    evidence: null,
    raw: null,
    inventory: null,
    dbTableList: null,
    activeSpecDir: null,
  };
  for (let i = 2; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--self-test') args.selfTest = true;
    else if (a === '--from-evidence') args.fromEvidence = true;
    else if (a === '--evidence') args.evidence = argv[++i];
    else if (a === '--raw') args.raw = argv[++i];
    else if (a === '--inventory') args.inventory = argv[++i];
    else if (a === '--db-table-list') args.dbTableList = argv[++i];
    else if (a === '--active-spec-dir') args.activeSpecDir = argv[++i];
    else if (a === '--cwd') process.chdir(argv[++i]);
    else if (a === '--data-source-name') args.dataSourceName = argv[++i];
    else if (a === '--module-id') args.moduleId = argv[++i];
    else if (a === '--channel') args.channel = argv[++i];
    else if (a === '--app-id') args.appId = argv[++i];
    else if (a === '--include') args.include = argv[++i];
    else if (a === '--exclude') args.exclude = argv[++i];
    else if (a === '--object-kind') args.objectKind = argv[++i];
    else if (a === '--page-size') args.pageSize = Number(argv[++i]) || 80;
    else if (a === '--legacy-datasource') {
      throw new Error('--legacy-datasource 已退役（本地 MySQL 直连通道已删除）；只允许经 MCP 采集');
    }
  }
  return args;
}

// ─── 稳定序列化 / 哈希 / 身份派生（F3 §1.2）─────────────────────────────────
/** 递归按 key 排序的稳定 JSON；数组保序。 */
export function stableJson(value) {
  const normalize = (v) => {
    if (Array.isArray(v)) return v.map(normalize);
    if (v && typeof v === 'object') {
      const out = {};
      for (const key of Object.keys(v).sort()) {
        if (v[key] !== undefined) out[key] = normalize(v[key]);
      }
      return out;
    }
    return v;
  };
  return JSON.stringify(normalize(value));
}

export function sha256Hex(text) {
  return createHash('sha256').update(String(text), 'utf8').digest('hex');
}

function shortBase64UrlHash(text) {
  return createHash('sha256').update(String(text), 'utf8').digest('base64url').slice(0, 32);
}

/**
 * F3 §1.2：sourceId = "src1." + base64url(sha256(utf8(sourceKey))).slice(0,32)
 * sourceKey = stableJson({dataSourceName, dialect, database, owners(sorted), objectFilter})
 */
export function deriveSourceId({ dataSourceName, dialect, scope }) {
  const key = stableJson({
    dataSourceName,
    dialect,
    database: scope && scope.database != null ? scope.database : null,
    owners: [...((scope && scope.owners) || [])].sort(),
    objectFilter: (scope && scope.objectFilter) || null,
  });
  return 'src1.' + shortBase64UrlHash(key);
}

/** F3 §1.2：objectId = "obj1." + base64url(sha256(utf8(sourceId + "\u0000" + objectKey))).slice(0,32) */
export function deriveObjectId(sourceId, { owner, name, quoted }) {
  const objectKey = stableJson({
    owner: owner == null ? null : owner,
    name,
    quoted: { name: Boolean(quoted && quoted.name), owner: Boolean(quoted && quoted.owner) },
  });
  return 'obj1.' + shortBase64UrlHash(sourceId + '\u0000' + objectKey);
}

/**
 * 写盘前引用唯一性校验（v3 契约；替代已退役的 objectId 机械重算）。
 *
 * 唯一身份 = `sourceId + owner + kind + name` 四元组逐字相等（quoted/rawDdl 不参与身份）。
 * 同一 source 内出现重复引用直接抛错：不静默合并、不按下标任选其一。
 * 键只在进程内使用，**不落盘**（不得变成新的持久化 id）。
 */
export function assertUniqueObjectRefs(schema) {
  for (const source of (schema && schema.sources) || []) {
    if (!source || typeof source.sourceId !== 'string' || !Array.isArray(source.objects)) continue;
    const seen = new Map();
    for (const object of source.objects) {
      if (!object || typeof object !== 'object') {
        throw new Error('对象引用形状非法：object 必须是对象');
      }
      const owner = object.owner == null ? null : object.owner;
      const kind = object.kind;
      const name = object.name;
      if (typeof kind !== 'string' || !kind) {
        throw new Error('对象引用形状非法：kind 必须是非空字符串');
      }
      if (typeof name !== 'string' || !name.trim()) {
        throw new Error('对象引用形状非法：name 必须是非空字符串');
      }
      if (owner !== null && typeof owner !== 'string') {
        throw new Error('对象引用形状非法：owner 必须是字符串或显式 null');
      }
      const key = JSON.stringify([source.sourceId, owner, kind, name]);
      const duplicate = seen.get(key);
      if (duplicate !== undefined) {
        throw new Error(
          `对象引用重复（sourceId+owner+kind+name）：${source.sourceId} ${owner === null ? '<null>' : owner}.${name} ` +
            `kind=${kind} 出现两次；禁止静默合并或按下标任选其一，先修采集/装配输入。`,
        );
      }
      seen.set(key, name);
    }
  }
}

/**
 * 引用排序键（仅进程内稳定排序；四字段逐字拼接，不做大小写/去 schema 归一）。
 * 用于 code-schema 对象数组的确定性顺序，不落盘、不参与身份相等。
 */
function objectRefSortKey(object) {
  return JSON.stringify([object && object.owner == null ? null : object && object.owner, object && object.kind, object && object.name]);
}

export const SOURCE_ID_RE = /^src1\.[A-Za-z0-9_-]{32}$/;
export const OBJECT_ID_RE = /^obj1\.[A-Za-z0-9_-]{32}$/;

/**
 * 平台原始类型 → 归一方言；已知别名归一，非空未知原样透传（不猜 MySQL，不设白名单）。
 * 空值仍返回历史哨兵 `unknown`（legacy/fresh 调用方 A8 兼容锁；不把它当方言别名猜测）。
 */
export function normalizeDialect(databaseType) {
  return canonicalDialect(databaseType) || 'unknown';
}

// ─── DDL 归一（F3 §3.1：保留大小写/引号/字符串字面量，只折叠引号外空白）──────
function isQuoteChar(ch) {
  return ch === "'" || ch === '"' || ch === '`';
}

/** 去首尾空白；引号外连续空白折叠为一个空格；统一 LF。不转小写、不剥引号。 */
export function normalizeDdlFragment(raw) {
  if (!raw || typeof raw !== 'string') return '';
  const src = raw.replace(/\r\n?/g, '\n');
  let out = '';
  let inQuote = null;
  let pendingSpace = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inQuote) {
      out += ch;
      if (ch === inQuote) {
        // '' / "" / `` 是转义引号，保持 quote 状态
        if (src[i + 1] === inQuote) {
          out += src[i + 1];
          i++;
        } else {
          inQuote = null;
        }
      }
      continue;
    }
    if (/\s/.test(ch)) {
      pendingSpace = true;
      continue;
    }
    if (pendingSpace && out.length > 0) out += ' ';
    pendingSpace = false;
    out += ch;
    if (isQuoteChar(ch)) inQuote = ch;
  }
  return out.trim();
}

/**
 * 仅用于“是否同一存量定义”的比较键：忽略引号标识符与大小写，但保留单/双引号字符串字面量。
 * 不用于 digest（digest 用 normalizeDdlFragment）。
 */
export function foldDdlForCompare(raw) {
  const src = normalizeDdlFragment(raw);
  let out = '';
  let inQuote = null;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inQuote) {
      out += ch;
      if (ch === inQuote) {
        if (src[i + 1] === inQuote) {
          out += src[i + 1];
          i++;
        } else {
          inQuote = null;
        }
      }
      continue;
    }
    if (ch === "'" || ch === '"') {
      inQuote = ch;
      out += ch;
      continue;
    }
    if (ch === '`') continue;
    out += ch.toLowerCase();
  }
  // MySQL 对可空列总显式回显 `DEFAULT NULL`；设计侧常省略。语义等价 ⇒ 比较键里归一掉。
  return out.replace(/\bdefault\s+null\b/g, '').replace(/\s+/g, ' ').trim();
}

// ─── plans/backend 目录定位统一走 shared/findPlanBackendDir（上溯 + appName-aware）───
// 不再保留私有 findLatestPlansBackendDir：私有副本不认 `<app>/docs/<ts>/plans/backend`，
// 且把裸 `<root>/plans/backend` 当候选会让 stray 目录遮蔽真实轮（plan 2026-11-04 §3 D2）。

// ─── D13：设计期数据源解析策略（per-module 粒度下**禁**回退默认库）────────────────────
//
// 返回：
//   { ok:true,  granularity, dataSourceName, source:'explicit'|'binding'|'fallback'|'reference' }
//   { ok:false, granularity, reason }
//
// 非 per-module（单体 / shared / 粒度未定）：本轮引用取 `plans/tech-stack.json#/database/dataSourceName`。
//   · 显式 --data-source-name 与引用同时在场且不一致 ⇒ 红（禁跨库采集，点名两个值与文件）；
//   · 只有引用 ⇒ 用引用（source='reference'）；只有显式 ⇒ 保持原样（source='fallback'，兼容旧消费面）；
//   · 都没有 ⇒ dataSourceName=''，不在本函数新增失败——下游 `main()` 既有「缺已确认 dataSourceName」
//     分支负责红停，失败位置与文案保持不变；
//   · 技术栈存在但不可解析 / 引用类型非法 ⇒ 红（损坏不能当作字段缺席继续）。
// per-module（micro）逐字保持原判据，不读技术栈引用。
export function resolveDesignTimeDatasource({ planBackendDir, dataSourceName, moduleId } = {}) {
  const granularity = readGranularityFromLedger(planBackendDir);
  const explicit = typeof dataSourceName === 'string' && dataSourceName.trim() ? dataSourceName.trim() : '';
  if (granularity !== 'per-module') {
    const reference = readTechStackDatasourceReference(planBackendDir);
    if (reference.state === 'invalid') {
      return { ok: false, granularity, reason: reference.reason };
    }
    if (explicit && reference.state === 'present' && explicit !== reference.dataSourceName) {
      return {
        ok: false,
        granularity,
        reason:
          `显式参数与本轮技术栈引用冲突，禁跨库采集：--data-source-name="${explicit}"，` +
          `本轮技术栈引用（${reference.filePath}#/database/dataSourceName）="${reference.dataSourceName}"。` +
          '请修正其中之一后重跑。',
      };
    }
    if (explicit) return { ok: true, granularity, dataSourceName: explicit, source: 'fallback' };
    if (reference.state === 'present') {
      return { ok: true, granularity, dataSourceName: reference.dataSourceName, source: 'reference' };
    }
    return { ok: true, granularity, dataSourceName: '', source: 'fallback' };
  }
  if (explicit) return { ok: true, granularity, dataSourceName: explicit, source: 'explicit' };

  const wantedModule = typeof moduleId === 'string' && moduleId.trim() ? moduleId.trim() : '';
  if (!wantedModule) {
    return {
      ok: false,
      granularity,
      reason:
        'per-module 粒度下禁省略数据源参数：未给 --data-source-name，也未给 --module-id 供按模块解析 ' +
        'binding envelope ⇒ 拒绝回退默认库（本地派生连接配置不是 micro 真值；' +
        '沙箱双数据源错库事故在案）。请给 --module-id <模块 id>（从 datasource-binding.json 解析）或显式 --data-source-name。',
    };
  }
  const envelope = readBindingEnvelope(planBackendDir);
  if (envelope.state !== 'present') {
    return {
      ok: false,
      granularity,
      reason:
        `per-module 粒度下按模块解析失败：绑定 envelope 不可用（state=${envelope.state}，` +
        '_meta/datasource-binding.json）——2d 契约闭包是设计期数据源真值的来源，缺失/空/坏一律显式红，禁回退默认库。',
    };
  }
  const entry = envelope.entries.find((item) => item && item.moduleId === wantedModule);
  if (!entry) {
    return {
      ok: false,
      granularity,
      reason:
        `per-module 粒度下按模块解析失败：模块 "${wantedModule}" 不在绑定 envelope（` +
        `${envelope.entries.map((item) => item.moduleId).filter(Boolean).join(', ') || '空'}）——模块 id 须逐字符照抄契约 canonical id。`,
    };
  }
  const resolved = typeof entry.dataSourceName === 'string' && entry.dataSourceName.trim() ? entry.dataSourceName.trim() : '';
  if (!resolved) {
    return {
      ok: false,
      granularity,
      reason: `per-module 粒度下按模块解析失败：模块 "${wantedModule}" 的 envelope 条目缺 dataSourceName（半写）。`,
    };
  }
  return { ok: true, granularity, dataSourceName: resolved, source: 'binding' };
}

/** 读粒度台账（`_meta/clarify-decisions.json` 的 `db-binding-granularity` answer）。 */
function readGranularityFromLedger(planBackendDir) {
  const p = planBackendDir ? resolve(planBackendDir, '_meta', 'clarify-decisions.json') : null;
  if (!p || !existsSync(p)) return null;
  let doc;
  try {
    doc = JSON.parse(readFileSync(p, 'utf-8'));
  } catch {
    return null;
  }
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) return null;
  const decisions = doc.decisions;
  if (!Array.isArray(decisions)) return null;
  for (const item of decisions) {
    if (!item || typeof item !== 'object') continue;
    if (item.id !== 'db-binding-granularity') continue;
    const answer = typeof item.answer === 'string' ? item.answer.trim() : '';
    return answer === 'shared' || answer === 'per-module' ? answer : null;
  }
  return null;
}

/**
 * 读本轮技术栈实例引用（`plans/tech-stack.json#/database/dataSourceName`）三态。
 *
 * `planBackendDir` 是 `<轮>/plans/backend`，tech-stack.json 在其上一级 `plans/` 根，
 * 故路径为 `resolve(planBackendDir, '..', 'tech-stack.json')`。
 *   · present：非空字符串（trim 后）；
 *   · absent ：字段缺失 / 空串（含纯空白）；`database` 整块缺失同属未填写；
 *   · invalid：文件不可解析、顶层或 `database` 形态非法、引用不是字符串。
 * 本脚本是模板内独立 .mjs，不跨 import src（`shared/datasource-reference.ts` 是 TS 侧单源）；
 * 这里只读引用，不验契约、不 resolve、不做来源指纹。
 */
function readTechStackDatasourceReference(planBackendDir) {
  const filePath = planBackendDir ? resolve(planBackendDir, '..', 'tech-stack.json') : null;
  if (!filePath || !existsSync(filePath)) return { state: 'absent', dataSourceName: '', filePath };

  let doc;
  try {
    doc = JSON.parse(readFileSync(filePath, 'utf-8'));
  } catch (error) {
    return {
      state: 'invalid',
      dataSourceName: '',
      filePath,
      reason:
        `本轮技术栈不可解析：${filePath}（${(error && error.message) || error}）` +
        '——引用不可判，禁按字段缺席继续；请修复 tech-stack.json 后重跑。',
    };
  }
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) {
    return {
      state: 'invalid',
      dataSourceName: '',
      filePath,
      reason: `本轮技术栈形态非法：${filePath} 顶层须为对象——引用不可判，禁按字段缺席继续。`,
    };
  }
  const database = doc.database;
  if (database === undefined) return { state: 'absent', dataSourceName: '', filePath };
  if (!database || typeof database !== 'object' || Array.isArray(database)) {
    return {
      state: 'invalid',
      dataSourceName: '',
      filePath,
      reason: `本轮技术栈形态非法：${filePath}#/database 须为对象——引用不可判，禁按字段缺席继续。`,
    };
  }
  const raw = database.dataSourceName;
  if (raw === undefined) return { state: 'absent', dataSourceName: '', filePath };
  if (typeof raw === 'string') {
    const value = raw.trim();
    return value
      ? { state: 'present', dataSourceName: value, filePath }
      : { state: 'absent', dataSourceName: '', filePath };
  }
  return {
    state: 'invalid',
    dataSourceName: '',
    filePath,
    reason:
      `本轮技术栈引用类型非法：${filePath}#/database/dataSourceName 须为非空字符串` +
      `（实际 ${JSON.stringify(raw)}）——引用不可判，禁按字段缺席继续。`,
  };
}

/** 读绑定 envelope 三态 + 条目（`_meta/datasource-binding.json`；形态与 2d 机器写对齐）。 */
function readBindingEnvelope(planBackendDir) {
  const p = planBackendDir ? resolve(planBackendDir, '_meta', 'datasource-binding.json') : null;
  if (!p || !existsSync(p)) return { state: 'absent', entries: [] };
  let doc;
  try {
    doc = JSON.parse(readFileSync(p, 'utf-8'));
  } catch {
    return { state: 'malformed', entries: [] };
  }
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) return { state: 'malformed', entries: [] };
  const bindings = doc.bindings;
  if (!Array.isArray(bindings)) return { state: 'malformed', entries: [] };
  if (bindings.length === 0) return { state: 'empty', entries: [] };
  return { state: 'present', entries: bindings.filter((item) => item && typeof item === 'object') };
}

// ─── DDL 解析（保留原文；引号状态 + 括号配对，不用贪婪正则吞表 COMMENT）──────
export function parseShowCreateTable(ddl) {
  const parsed = parseTableStructure(ddl);
  if (!parsed) {
    return {
      tableName: null,
      tableQuoted: false,
      columns: [],
      indexes: [],
      constraints: [],
      foreignKeys: [],
      comments: { table: null, columns: {} },
      tableOptions: typeof ddl === 'string' ? ddl : '',
      ddl,
      parseIssues: ['无法解析 CREATE TABLE 结构'],
      error: '无法解析 CREATE TABLE 结构',
    };
  }

  const { tableName, tableQuoted, body, tail } = parsed;
  const parts = splitTopLevelCommas(body);
  const columns = [];
  const indexes = [];
  const constraints = [];
  const foreignKeys = [];
  const parseIssues = [];
  const columnComments = {};
  let ordinal = 0;

  for (const raw of parts) {
    const part = raw.trim();
    if (!part) continue;
    const upper = part.toUpperCase();
    if (/^(PRIMARY\s+KEY|UNIQUE\s+(KEY|INDEX)|KEY|INDEX|FULLTEXT|SPATIAL)\b/.test(upper)) {
      indexes.push(part);
      if (/^(PRIMARY\s+KEY|UNIQUE\s+(KEY|INDEX))\b/.test(upper)) constraints.push(part);
      continue;
    }
    if (/^CONSTRAINT\b|FOREIGN\s+KEY\b/.test(upper)) {
      if (/\bFOREIGN\s+KEY\b/.test(upper)) foreignKeys.push(part);
      else constraints.push(part);
      continue;
    }
    if (/^(CHECK)\b/.test(upper)) {
      constraints.push(part);
      continue;
    }
    const colM = part.match(/^(`((?:[^`]|``)+)`|([^\s`]+))\s+/);
    if (colM) {
      const name = colM[2] != null ? colM[2].replace(/``/g, '`') : colM[3];
      const comment = extractColumnComment(part);
      if (comment != null) columnComments[name] = comment;
      columns.push({
        name,
        ddl: part,
        source: 'db',
        ordinal: ++ordinal,
        hidden: false,
        virtual: /\b(VIRTUAL|STORED|GENERATED\s+ALWAYS)\b/i.test(part),
      });
      continue;
    }
    parseIssues.push(`无法识别的表体片段：${part.slice(0, 120)}`);
  }

  return {
    tableName,
    tableQuoted,
    columns,
    indexes,
    constraints,
    foreignKeys,
    comments: { table: extractTableComment(tail), columns: columnComments },
    tableOptions: tail,
    ddl,
    parseIssues,
    error: null,
  };
}

/** 定位 CREATE TABLE 表头/表体；引号状态 + 括号配对，避免贪婪正则吞掉 COMMENT 中的括号。 */
function parseTableStructure(ddl) {
  if (!ddl || typeof ddl !== 'string') return null;
  const m = /CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?/i.exec(ddl);
  if (!m) return null;
  let i = m.index + m[0].length;

  const parseIdentifier = () => {
    while (i < ddl.length && /\s/.test(ddl[i])) i++;
    if (ddl[i] === '`') {
      i++;
      let name = '';
      while (i < ddl.length) {
        if (ddl[i] === '`') {
          if (ddl[i + 1] === '`') {
            name += '`';
            i += 2;
            continue;
          }
          i++;
          return { name, quoted: true };
        }
        name += ddl[i++];
      }
      return null;
    }
    const start = i;
    while (i < ddl.length && !/[\s(]/.test(ddl[i])) i++;
    return i > start ? { name: ddl.slice(start, i), quoted: false } : null;
  };

  const first = parseIdentifier();
  if (!first) return null;
  const nameParts = [first.name];
  let anyQuoted = first.quoted;
  while (ddl[i] === '.') {
    i++;
    const next = parseIdentifier();
    if (!next) return null;
    nameParts.push(next.name);
    anyQuoted = anyQuoted || next.quoted;
  }
  const tableName = nameParts.join('.');

  while (i < ddl.length && /\s/.test(ddl[i])) i++;
  if (ddl[i] !== '(') return null;
  const bodyStart = i + 1;
  let depth = 1;
  let inStr = null;
  let bodyEnd = -1;
  for (i = bodyStart; i < ddl.length; i++) {
    const ch = ddl[i];
    if (inStr) {
      if (inStr !== '`' && ch === '\\') {
        i++;
        continue;
      }
      if (ch === inStr) {
        if (ddl[i + 1] === inStr) {
          i++;
          continue;
        }
        inStr = null;
      }
      continue;
    }
    if (isQuoteChar(ch)) {
      inStr = ch;
      continue;
    }
    if (ch === '(') depth++;
    else if (ch === ')') {
      depth--;
      if (depth === 0) {
        bodyEnd = i;
        break;
      }
    }
  }
  if (bodyEnd < 0) return null;
  return {
    tableName,
    tableQuoted: anyQuoted,
    body: ddl.slice(bodyStart, bodyEnd),
    tail: ddl.slice(bodyEnd + 1).trim(),
  };
}

function unescapeSqlString(raw) {
  return String(raw).replace(/''/g, "'").replace(/\\(.)/g, '$1');
}

export function extractColumnComment(ddl) {
  const m = String(ddl || '').match(/\bCOMMENT\s+'((?:[^'\\]|''|\\.)*)'/i);
  return m ? unescapeSqlString(m[1]) : null;
}

export function extractTableComment(tail) {
  const m = String(tail || '').match(/\bCOMMENT\s*=\s*'((?:[^'\\]|''|\\.)*)'/i);
  return m ? unescapeSqlString(m[1]) : null;
}

/** 按顶层逗号切分（括号/引号内的逗号不算）。 */
function splitTopLevelCommas(s) {
  const parts = [];
  let depth = 0;
  let inStr = null;
  let start = 0;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (inStr !== '`' && ch === '\\') {
        i++;
        continue;
      }
      if (ch === inStr) {
        if (s[i + 1] === inStr) {
          i++;
          continue;
        }
        inStr = null;
      }
      continue;
    }
    if (isQuoteChar(ch)) {
      inStr = ch;
      continue;
    }
    if (ch === '(') depth++;
    else if (ch === ')') depth--;
    else if (ch === ',' && depth === 0) {
      parts.push(s.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(s.slice(start));
  return parts;
}

// ─── v3 对象 / v2 legacy 夹具 / fingerprint / baseline digest ────────────────
/**
 * parseShowCreateTable 结果 → SchemaObjectV3（**无 objectId**；正常路径唯一构造器）。
 *
 * 身份由调用方按 `sourceId + owner + kind + name` 组装引用，本函数只落对象事实；
 * `quoted`/`rawDdl` 保留为语法与证据，不参与身份相等。
 */
export function toSchemaObjectV3(parsed, { owner = null, kind = 'table' } = {}) {
  const name = parsed.tableName;
  const quoted = { name: Boolean(parsed.tableQuoted), owner: false };
  return {
    owner: owner == null ? null : owner,
    name,
    quoted,
    kind: OBJECT_KINDS.has(kind) ? kind : 'other',
    rawDdl: typeof parsed.ddl === 'string' ? parsed.ddl : '',
    columns: (parsed.columns || []).map((c, idx) => ({
      name: c.name,
      ddl: c.ddl,
      source: 'db',
      ordinal: Number.isInteger(c.ordinal) ? c.ordinal : idx + 1,
      hidden: Boolean(c.hidden),
      virtual: Boolean(c.virtual),
    })),
    indexes: [...(parsed.indexes || [])],
    constraints: [...(parsed.constraints || [])],
    foreignKeys: [...(parsed.foreignKeys || [])],
    comments: {
      table: (parsed.comments && parsed.comments.table) ?? null,
      columns: { ...((parsed.comments && parsed.comments.columns) || {}) },
    },
    tableOptions: parsed.tableOptions == null ? null : String(parsed.tableOptions),
    parseIssues: [...(parsed.parseIssues || [])],
    diffable: !parsed.error && (parsed.parseIssues || []).length === 0,
  };
}

/**
 * legacy v2 对象夹具：**只为尚未迁移的旧消费方/迁移测试**构造 `SchemaObjectV2`。
 *
 * 正常产出路径（collect / evidence 装配 / 写盘）一律用 `toSchemaObjectV3`，不得调用本函数。
 * 保留它是因为其他脚本仍导出消费 `deriveObjectId`/v2 夹具；`objectId` 不再参与新产物身份。
 */
export function toSchemaObjectV2(parsed, { sourceId, owner = null, kind = 'table' } = {}) {
  const object = toSchemaObjectV3(parsed, { owner, kind });
  return {
    objectId: deriveObjectId(sourceId, { owner: object.owner, name: object.name, quoted: object.quoted }),
    ...object,
  };
}

/** F3 §3.1 fingerprint（不含 objectId，便于链式 before/after 复制）。 */
export function buildObjectFingerprint(object) {
  return {
    owner: object.owner == null ? null : object.owner,
    name: object.name,
    quoted: {
      name: Boolean(object.quoted && object.quoted.name),
      owner: Boolean(object.quoted && object.quoted.owner),
    },
    columns: [...(object.columns || [])]
      .sort((a, b) => (a.ordinal || 0) - (b.ordinal || 0))
      .map((c) => ({
        name: c.name,
        ddlNormalized: normalizeDdlFragment(c.ddl),
        ordinal: c.ordinal,
        hidden: Boolean(c.hidden),
        virtual: Boolean(c.virtual),
      })),
    indexes: (object.indexes || []).map((idx) => normalizeDdlFragment(typeof idx === 'string' ? idx : idx && idx.ddl)),
    constraints: (object.constraints || []).map((c) => normalizeDdlFragment(typeof c === 'string' ? c : c && c.ddl)),
    comments: {
      table: (object.comments && object.comments.table) ?? null,
      columns: { ...((object.comments && object.comments.columns) || {}) },
    },
    tableOptions: object.tableOptions == null ? null : object.tableOptions,
  };
}

export function computeFingerprintDigest(fingerprint) {
  return 'sha256:' + sha256Hex(stableJson(fingerprint));
}

export function computeObjectDigest(object) {
  return computeFingerprintDigest(buildObjectFingerprint(object));
}

/**
 * baseline 口径（code-schema v3）：对 {schemaVersion, sources[按 sourceId 排序],
 * objects[按引用四元组排序]} 稳定序列化取 sha256；排除 generatedAt / collectedAt /
 * evidenceRefs / parseIssues。对象投影**不含 objectId**（v3 已退役）。
 */
const compareCodepoint = (left, right) => (String(left) < String(right) ? -1 : String(left) > String(right) ? 1 : 0);

export function computeBaselineDigest(schema) {
  const sources = [...((schema && schema.sources) || [])]
    .sort((a, b) => compareCodepoint(a.sourceId, b.sourceId))
    .map((s) => ({
      sourceId: s.sourceId,
      binding: s.binding,
      databaseType: s.databaseType,
      dialect: s.dialect,
      serverVersion: s.serverVersion,
      capabilities: s.capabilities,
      scope: s.scope,
      channel: s.channel,
      completeness: {
        status: s.completeness && s.completeness.status,
        catalogExpected: s.completeness && s.completeness.catalogExpected,
        catalogReturned: s.completeness && s.completeness.catalogReturned,
        objectsParsed: s.completeness && s.completeness.objectsParsed,
        truncated: s.completeness && s.completeness.truncated,
        missingPermissions: (s.completeness && s.completeness.missingPermissions) || [],
      },
      objects: [...(s.objects || [])]
        .sort((a, b) => compareCodepoint(objectRefSortKey(a), objectRefSortKey(b)))
        .map((o) => ({
          owner: o.owner,
          name: o.name,
          quoted: o.quoted,
          kind: o.kind,
          rawDdl: o.rawDdl,
          columns: o.columns,
          indexes: o.indexes,
          constraints: o.constraints,
          foreignKeys: o.foreignKeys,
          comments: o.comments,
          tableOptions: o.tableOptions,
          diffable: o.diffable,
        })),
    }));
  return 'sha256:' + sha256Hex(stableJson({ schemaVersion: schema && schema.schemaVersion, sources }));
}

// ─── SQL 语句切分（引号内分号不算）──────────────────────────────────────────
export function splitSqlStatements(text) {
  const src = String(text || '');
  const stmts = [];
  let cur = '';
  let inStr = null;
  let inLineComment = false;
  let inBlockComment = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    const next = src[i + 1];
    if (inLineComment) {
      if (ch === '\n') {
        inLineComment = false;
        cur += ch;
      }
      continue;
    }
    if (inBlockComment) {
      if (ch === '*' && next === '/') {
        inBlockComment = false;
        i++;
      }
      continue;
    }
    if (inStr) {
      cur += ch;
      if (ch === '\\' && inStr !== '`') {
        if (next != null) cur += next;
        i++;
        continue;
      }
      if (ch === inStr) {
        if (next === inStr) {
          cur += next;
          i++;
          continue;
        }
        inStr = null;
      }
      continue;
    }
    if (ch === '-' && next === '-') {
      inLineComment = true;
      i++;
      continue;
    }
    if (ch === '#') {
      inLineComment = true;
      continue;
    }
    if (ch === '/' && next === '*') {
      inBlockComment = true;
      i++;
      continue;
    }
    if (isQuoteChar(ch)) {
      inStr = ch;
      cur += ch;
      continue;
    }
    if (ch === ';') {
      if (cur.trim()) stmts.push(cur.trim());
      cur = '';
      continue;
    }
    cur += ch;
  }
  if (cur.trim()) stmts.push(cur.trim());
  return stmts;
}

// ─── 采集适配器 ─────────────────────────────────────────────────────────────
function quoteLiteral(value) {
  return "'" + String(value == null ? '' : value).replace(/\\/g, '\\\\').replace(/'/g, "''") + "'";
}

function quoteIdentifier(value) {
  return '`' + String(value == null ? '' : value).replace(/`/g, '``') + '`';
}

function firstRowValue(rows) {
  if (!Array.isArray(rows) || rows.length === 0) return null;
  const row = rows[0];
  if (row == null) return null;
  if (typeof row !== 'object') return row;
  const keys = Object.keys(row);
  if (keys.length === 0) return null;
  return row[keys[0]];
}

/** objectFilter → 额外 WHERE 片段（只支持精确名单；过滤范围与 completeness 口径一致）。 */
function buildObjectFilterSql(objectFilter) {
  if (!objectFilter || typeof objectFilter !== 'object') return '';
  const include = Array.isArray(objectFilter.include) ? objectFilter.include.filter(Boolean) : null;
  const exclude = Array.isArray(objectFilter.exclude) ? objectFilter.exclude.filter(Boolean) : null;
  let sql = '';
  if (include && include.length > 0) {
    sql += ` AND TABLE_NAME IN (${include.map(quoteLiteral).join(', ')})`;
  }
  if (exclude && exclude.length > 0) {
    sql += ` AND TABLE_NAME NOT IN (${exclude.map(quoteLiteral).join(', ')})`;
  }
  return sql;
}

/**
 * 解析真实 MCP `executeSqlDirect` 的**文本结果表**（task.result 为 string 时）：
 *
 *   header[,header2]\nvalue[,value2]\n...
 *
 * 为什么不能直接 `[task]`：文本结果未加引号，第一列是 header 对应的值；若把 task 对象
 * 当成一行，`firstRowValue` 会取到 `taskId`（沙箱实测 1587685/1587686/1587687 即 taskId，
 * 不是 version/COUNT/表名）。
 *
 * 特殊形态：`SHOW CREATE TABLE` 返回两列 `Table,Create Table`，第二列 DDL 内含逗号与换行，
 * 文本未转义 ⇒ 必须按 `,CREATE TABLE` 切分，不能按普通 CSV 逐行切。
 */
export function parseMcpTableText(text) {
  if (typeof text !== 'string') return [];
  const normalized = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const firstNewline = normalized.indexOf('\n');
  if (firstNewline < 0) return [];
  const headerLine = normalized.slice(0, firstNewline);
  if (!headerLine.trim()) return [];
  const columns = headerLine.split(',').map((name) => name.trim());
  const body = normalized.slice(firstNewline + 1).replace(/\n+$/, '');
  if (!body) return [];

  // SHOW CREATE TABLE：第二列 DDL 含逗号/换行；按首个 `,CREATE TABLE` 切出表名与 DDL。
  if (columns.length === 2 && /^create table$/i.test(columns[1])) {
    const marker = /,(?=CREATE\s+TABLE\b)/i.exec(body);
    if (!marker) return [];
    return [
      {
        [columns[0]]: body.slice(0, marker.index).trim(),
        [columns[1]]: body.slice(marker.index + 1),
      },
    ];
  }

  // 普通结果：一行一记录；最后一列容纳未转义的逗号。
  return body
    .split('\n')
    .filter((line) => line.length > 0)
    .map((line) => {
      const values = line.split(',');
      const row = {};
      columns.forEach((column, index) => {
        row[column] =
          index === columns.length - 1 && values.length > columns.length
            ? values.slice(index).join(',')
            : (values[index] ?? null);
      });
      return row;
    });
}

/** MCP executeSqlDirect 的 task.result 可能是数组 / 文本表 / {rows} / {data} / 嵌套 result。 */
export function extractMcpRows(result) {
  if (result == null) return [];
  if (Array.isArray(result)) return result;
  if (typeof result === 'string') return parseMcpTableText(result);
  if (typeof result === 'object') {
    for (const key of ['rows', 'data', 'records', 'result']) {
      if (Array.isArray(result[key])) return result[key];
    }
    // 真实 MCP：{taskId,sql,status,progress,result:"header\nvalue"}；result 是文本表。
    if (typeof result.result === 'string') {
      const parsed = parseMcpTableText(result.result);
      if (parsed.length > 0) return parsed;
    }
    if (result.result && typeof result.result === 'object') {
      const nested = extractMcpRows(result.result);
      if (nested.length > 0) return nested;
    }
    return [result];
  }
  return [];
}

function createMcpAdapter(ds) {
  const mcpEndpoint = process.env.SQL_EXEC_MCP_ENDPOINT || null;
  const mcpEnv = process.env.SQL_EXEC_MCP_ENV || 'dev';
  return {
    channel: 'mcp',
    withSession: async (fn) => {
      // 整轮采集只建一条 SSE 会话；所有 catalog / DDL 查询复用，避免 1348 次 initialize。
      const session = await openMcpSession(mcpEndpoint ? { endpoint: mcpEndpoint } : {});
      try {
        const query = async (sql) => {
          const r = await executeSqlDirectOnSession(session, {
            sql,
            dataSourceName: ds.dataSourceName,
            dbName: ds.db,
            appId: ds.appId,
            env: mcpEnv,
          });
          if (!r.success) {
            const error = new Error(`MCP 查询失败：${r.msg || ''}`);
            // SQL 业务失败：按单表失败处理；会话断开由 isBroken() 区分。
            error.mcpSqlFailure = true;
            throw error;
          }
          return extractMcpRows(r.result);
        };
        return await fn({ query, isBroken: () => session.isBroken() });
      } finally {
        session.close();
      }
    },
  };
}

/** DDL 并发度：默认 4；环境变量可调，上限 8；非法值回落默认。 */
function resolveDdlConcurrency() {
  const raw = Number(process.env.CODE_SCHEMA_DDL_CONCURRENCY);
  if (!Number.isFinite(raw) || raw < 1) return 4;
  return Math.min(Math.floor(raw), 8);
}

/** 单表读取失败时的占位 object（v3：无 objectId；引用由 sourceId+owner+kind+name 组装）。 */
function buildFailedTableObject(tableName, message) {
  return {
    owner: null,
    name: tableName,
    quoted: { name: true, owner: false },
    kind: 'table',
    rawDdl: '',
    columns: [],
    indexes: [],
    constraints: [],
    foreignKeys: [],
    comments: { table: null, columns: {} },
    tableOptions: null,
    parseIssues: [`读取/解析失败：${message}`],
    diffable: false,
  };
}

/** 采集一张表：只做网络/解析，不碰共享计数；结果由 fan-in 按索引汇总。 */
async function collectOneTable({ tableName, query, sourceId }) {
  const ddlSql = `SHOW CREATE TABLE ${quoteIdentifier(tableName)}`;
  try {
    const rows = await query(ddlSql);
    const row = Array.isArray(rows) ? rows[0] : null;
    let ddl = null;
    if (row && typeof row === 'object') {
      const key = Object.keys(row).find((k) => k.toLowerCase() === 'create table');
      if (key) ddl = row[key];
    }
    if (typeof ddl !== 'string' || !ddl.trim()) throw new Error('MCP/驱动未返回 Create Table 原文');
    const parsed = parseShowCreateTable(ddl);
    if (parsed.tableName != null && parsed.tableName !== tableName && parsed.tableName.toLowerCase() !== tableName.toLowerCase()) {
      parsed.parseIssues.push(`SHOW CREATE TABLE 返回表名 ${parsed.tableName} 与请求 ${tableName} 不一致`);
    }
    const object = toSchemaObjectV3(parsed, { owner: null, kind: 'table' });
    if (parsed.error || parsed.parseIssues.length > 0) {
      return {
        object,
        parsed: false,
        failure: `对象 ${tableName} 解析不完整：${parsed.error || parsed.parseIssues.join('；')}`,
        evidenceRef: `collect:${sourceId}:ddl:${tableName}`,
        capability: null,
      };
    }
    return {
      object,
      parsed: true,
      failure: null,
      evidenceRef: `collect:${sourceId}:ddl:${tableName}`,
      capability: 'show_create_table',
    };
  } catch (error) {
    const message = (error && error.message) || error;
    return {
      object: buildFailedTableObject(tableName, message),
      parsed: false,
      failure: `对象 ${tableName} 读取/解析失败：${message}`,
      evidenceRef: null,
      capability: null,
      error,
    };
  }
}

/**
 * 采集单个 source 的 **v3** 形状（可注入 adapter，测试不连库）。
 *
 * 产出 `schemaVersion: 3`、`sources[].channel: "mcp"`、`objects[]` **无 objectId**；
 * 写盘前的引用唯一性由调用方用 `assertUniqueObjectRefs` 校验。
 *
 * @param {object} p
 * @param {{channel:string, withSession:Function}} p.adapter
 * @param {{dataSourceName:string, entryRef:string}} p.binding
 * @param {string} p.databaseType 平台原始类型
 * @param {'mysql'|'oracle'|'postgresql'|'unknown'} p.dialect
 * @param {{database:string|null, owners:string[], objectFilter:object|null}} p.scope
 * @param {number} [p.pageSize]
 * @param {string} [p.generatedAt]
 * @param {string} [p.collectedAt]
 * @param {string} [p.previousInputRevision] 旧 code-schema 的 inputRevision（用于递增；读不到从 1 开始）
 */
export async function collectCodeSchemaV3({
  adapter,
  binding,
  databaseType,
  dialect,
  scope,
  pageSize = 80,
  generatedAt = new Date().toISOString(),
  collectedAt = new Date().toISOString(),
  previousInputRevision = undefined,
}) {
  const sourceId = deriveSourceId({ dataSourceName: binding.dataSourceName, dialect, scope });
  const failures = [];
  const missingPermissions = [];
  const capabilities = [];
  const evidenceRefs = [`collect:${sourceId}:catalog`];
  let serverVersion = '';
  let catalogExpected = null;
  let catalogReturned = 0;
  let truncated = false;
  let objectsParsed = 0;
  let tableNames = [];
  const objects = [];

  await adapter.withSession(async ({ query, isBroken }) => {
    // 1. 实际服务端版本
    try {
      const rows = await query('SELECT VERSION() AS version');
      serverVersion = String(firstRowValue(rows) == null ? '' : firstRowValue(rows)).trim();
      if (serverVersion) capabilities.push('server_version');
      else missingPermissions.push('server_version');
    } catch (e) {
      missingPermissions.push('server_version');
      failures.push(`读取服务端版本失败：${(e && e.message) || e}`);
    }

    // 2. 目录 COUNT 证据（读不到为 null，不得 complete）
    const filterSql = buildObjectFilterSql(scope.objectFilter);
    if (scope.database != null) {
      try {
        const rows = await query(
          `SELECT COUNT(*) AS cnt FROM information_schema.TABLES WHERE TABLE_SCHEMA = ${quoteLiteral(scope.database)} AND TABLE_TYPE = 'BASE TABLE'${filterSql}`,
        );
        const raw = firstRowValue(rows);
        const num = Number(raw);
        if (raw != null && Number.isFinite(num) && num >= 0) {
          catalogExpected = num;
          capabilities.push('information_schema');
        } else {
          missingPermissions.push('information_schema.tables.count');
          failures.push('目录 COUNT 结果不可解析，不能证明表全集');
        }
      } catch (e) {
        missingPermissions.push('information_schema.tables.count');
        failures.push(`目录 COUNT 读取失败：${(e && e.message) || e}`);
      }
    } else {
      missingPermissions.push('scope.database');
      failures.push('MySQL 采集缺已确认 database 范围，不能证明表全集');
    }

    // 3. 分页取全表清单（>100 表也取全；不依赖 SHOW TABLES 的截断行为）
    if (scope.database != null) {
      try {
        const lit = quoteLiteral(scope.database);
        const names = [];
        let offset = 0;
        for (let page = 0; page < 10000; page++) {
          const rows = await query(
            `SELECT TABLE_NAME AS table_name FROM information_schema.TABLES ` +
              `WHERE TABLE_SCHEMA = ${lit} AND TABLE_TYPE = 'BASE TABLE'${filterSql} ` +
              `ORDER BY TABLE_NAME LIMIT ${Number(pageSize) || 80} OFFSET ${offset}`,
          );
          const pageNames = rows
            .map((row) => firstRowValue([row]))
            .filter((v) => v != null && String(v).trim() !== '')
            .map((v) => String(v));
          names.push(...pageNames);
          if (pageNames.length < (Number(pageSize) || 80)) break;
          offset += Number(pageSize) || 80;
        }
        tableNames = [...new Set(names)].sort();
        catalogReturned = tableNames.length;
        if (!capabilities.includes('information_schema')) capabilities.push('information_schema');
      } catch (e) {
        throw new Error(`目录表清单读取失败（不完整基线不得降级为空库）：${(e && e.message) || e}`);
      }
    }

    // 4. 逐表 SHOW CREATE TABLE 原文：单会话 + 有界 worker pool。
    //    结果按 tableNames 索引落槽，fan-in 顺序与串行一致；并发只影响在途请求数，不影响输出顺序。
    const ddlConcurrency = resolveDdlConcurrency();
    const ddlResults = new Array(tableNames.length);
    let nextTableIndex = 0;
    let completedTables = 0;
    let sessionBroken = null;

    const worker = async () => {
      while (true) {
        if (sessionBroken) return;
        const index = nextTableIndex++;
        if (index >= tableNames.length) return;
        const tableName = tableNames[index];
        const result = await collectOneTable({ tableName, query, sourceId });
        if (
          result.error &&
          !result.error.mcpSqlFailure &&
          typeof isBroken === 'function' &&
          isBroken()
        ) {
          sessionBroken = result.error;
          return;
        }
        ddlResults[index] = result;
        completedTables++;
        if (completedTables % 100 === 0) {
          console.error(`[extract-code-schema] ddl ${completedTables}/${tableNames.length}`);
        }
      }
    };

    await Promise.all(
      Array.from({ length: Math.min(ddlConcurrency, tableNames.length) }, () => worker()),
    );
    if (sessionBroken) {
      throw new Error(`MCP 会话已断开，采集中止（不把剩余表记成假失败）：${sessionBroken.message || sessionBroken}`);
    }

    for (const result of ddlResults) {
      if (!result) continue;
      if (result.failure) failures.push(result.failure);
      if (result.parsed) objectsParsed++;
      if (result.evidenceRef) evidenceRefs.push(result.evidenceRef);
      if (result.capability) capabilities.push(result.capability);
      objects.push(result.object);
    }
  });

  if (catalogExpected != null && catalogReturned !== catalogExpected) {
    truncated = catalogReturned < catalogExpected;
    failures.push(`目录 COUNT=${catalogExpected} 与返回表数=${catalogReturned} 不一致`);
  }
  if (!serverVersion) failures.push('缺服务端版本，completeness 不得为 complete');
  if (missingPermissions.length > 0) failures.push(`采集存在缺失权限/能力：${missingPermissions.join(', ')}`);

  const status = failures.length === 0 && !truncated && serverVersion && catalogExpected != null ? 'complete' : 'partial';
  const source = {
    sourceId,
    binding: { dataSourceName: binding.dataSourceName, entryRef: binding.entryRef },
    databaseType: String(databaseType == null ? '' : databaseType),
    dialect,
    serverVersion,
    capabilities: [...new Set(capabilities)],
    scope: {
      database: scope.database == null ? null : scope.database,
      owners: [...(scope.owners || [])].sort(),
      objectFilter: scope.objectFilter || null,
    },
    channel: 'mcp',
    collectedAt,
    completeness: {
      status,
      catalogExpected,
      catalogReturned,
      objectsParsed,
      truncated,
      missingPermissions: [...new Set(missingPermissions)],
      evidenceRefs,
    },
    objects,
  };
  return {
    status,
    failures,
    schema: {
      schemaVersion: CODE_SCHEMA_SCHEMA_VERSION,
      inputRevision: nextInputRevision(generatedAt, previousInputRevision),
      generatedAt,
      sources: [source],
    },
  };
}

/**
 * @deprecated 兼容旧 import 名：输出已升级为 code-schema v3（无 objectId）。
 * 新代码请用 `collectCodeSchemaV3`。
 */
export const collectCodeSchemaV2 = collectCodeSchemaV3;

/** evidence 装配错误（fail-loud；不写成功壳）。 */
export class EvidenceAssemblyError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'EvidenceAssemblyError';
    this.code = code;
    this.details = details;
  }
}

const isPlainObject = (value) => value != null && typeof value === 'object' && !Array.isArray(value);

function definitionTexts(items, label, table) {
  if (items === undefined || items === null) return [];
  if (!Array.isArray(items)) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_DEFINITION_SHAPE',
      `表 ${table} 的 ${label} 必须是数组`,
      { table, label },
    );
  }
  return items.map((item, index) => {
    if (typeof item === 'string') {
      if (!item.trim()) {
        throw new EvidenceAssemblyError(
          'EVIDENCE_DEFINITION_SHAPE',
          `表 ${table} 的 ${label}[${index}] 为空字符串`,
          { table, label, index },
        );
      }
      return item.trim();
    }
    if (!isPlainObject(item)) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_DEFINITION_SHAPE',
        `表 ${table} 的 ${label}[${index}] 必须是字符串或对象`,
        { table, label, index },
      );
    }
    const ddl = typeof item.ddl === 'string' ? item.ddl.trim() : '';
    if (ddl) return ddl;
    const name = typeof item.name === 'string' ? item.name.trim() : '';
    if (name) return name;
    throw new EvidenceAssemblyError(
      'EVIDENCE_DEFINITION_SHAPE',
      `表 ${table} 的 ${label}[${index}] 缺 ddl/name（不得静默丢弃）`,
      { table, label, index },
    );
  });
}

function columnDdlOf(column, table, index) {
  if (typeof column === 'string') {
    const name = column.trim();
    if (!name) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_COLUMNS_EMPTY',
        `表 ${table} 的 columns[${index}] 为空`,
        { table, index },
      );
    }
    return { name, ddl: name, quoted: false, hidden: false, virtual: false, ordinal: index + 1 };
  }
  if (!isPlainObject(column)) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_COLUMN_SHAPE',
      `表 ${table} 的 columns[${index}] 必须是字符串或对象`,
      { table, index },
    );
  }
  const name = typeof column.name === 'string' ? column.name.trim() : '';
  if (!name) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_COLUMN_SHAPE',
      `表 ${table} 的 columns[${index}] 缺 name`,
      { table, index },
    );
  }
  let ddl = typeof column.ddl === 'string' ? column.ddl.trim() : '';
  if (!ddl) {
    const type = column.type ?? column.dataType ?? '';
    if (typeof type === 'string' && type.trim()) {
      const parts = [name, type.trim()];
      if (column.nullable === false) parts.push('NOT NULL');
      if (column.default != null) parts.push(`DEFAULT ${column.default}`);
      ddl = parts.join(' ');
    }
  }
  if (!ddl) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_COLUMN_DDL',
      `表 ${table} 的列 "${name}" 缺 ddl（无法装配 code-schema）`,
      { table, column: name },
    );
  }
  return {
    name,
    ddl,
    quoted: column.quoted === true,
    hidden: column.hidden === true,
    virtual: column.virtual === true,
    ordinal: Number.isInteger(column.ordinal) ? column.ordinal : index + 1,
  };
}

function ddlFromRawRecord(record) {
  if (!record) return '';
  if (record.expectedShape === 'ddl' && typeof record.rawResult === 'string') return record.rawResult;
  const payload = record.rawResult;
  if (typeof payload === 'string') return payload;
  if (Array.isArray(payload)) {
    const text = payload.find((item) => typeof item === 'string' && item.trim());
    if (text) return text;
    for (const item of payload) {
      if (!isPlainObject(item)) continue;
      const nested = Object.values(item).find((value) => typeof value === 'string' && /\bcreate\s+table\b/i.test(value));
      if (nested) return nested;
    }
  }
  if (isPlainObject(payload)) {
    const nested = Object.values(payload).find((value) => typeof value === 'string' && /\bcreate\s+table\b/i.test(value));
    if (nested) return nested;
  }
  return '';
}

/**
 * 多数据源产物选择：同一个文件既可能是单源 legacy 形态，也可能是
 * `sources:[{dataSourceName, ...}]` 聚合形态。C 只装配当前 binding 的那一份。
 */
function selectSourceDocument(doc, bindingName, { label, code }) {
  const sources = Array.isArray(doc.sources) ? doc.sources.filter(isPlainObject) : [];
  if (sources.length > 0) {
    const single = sources.length === 1 && !sourceTagOf(sources[0]);
    if (single) return { source: sources[0], multiSource: false };
    const untagged = sources.filter((entry) => !sourceTagOf(entry));
    if (untagged.length > 0) {
      throw new EvidenceAssemblyError(
        code,
        `${label}.sources 每个来源条目必须带 dataSourceName（多数据源不得出现无归属来源）`,
      );
    }
    const matched = sources.find((entry) => sourceTagOf(entry) === bindingName);
    if (!matched) {
      throw new EvidenceAssemblyError(
        code,
        `${label} 缺少 dataSourceName=${bindingName} 的来源（逐源产物必须每个绑定齐全）`,
      );
    }
    return { source: matched, multiSource: sources.length > 1 };
  }
  const tag = sourceTagOf(doc);
  if (tag && tag !== bindingName) {
    throw new EvidenceAssemblyError(
      code,
      `${label} 的 dataSourceName=${tag} 与已确认绑定 ${bindingName} 不一致（不得跨源装配）`,
    );
  }
  // legacy 单源：evidence/raw 的来源元信息在 doc.source，db-table-list 则在顶层。
  const nested = isPlainObject(doc.source) ? doc.source : null;
  const source = nested ? { ...nested, ...(tag ? { dataSourceName: tag } : {}) } : doc;
  return { source, multiSource: false };
}

function sourceTagOf(value) {
  return isPlainObject(value) && typeof value.dataSourceName === 'string'
    ? value.dataSourceName.trim()
    : '';
}

function distinctSourceTags(records) {
  return new Set(
    (Array.isArray(records) ? records : [])
      .map((record) => sourceTagOf(record))
      .filter(Boolean),
  );
}

/**
 * 按 dataSourceName 过滤明细记录。多源聚合产物里缺归属的记录一律红：
 * 猜源会把 ds2 的表塞进 ds1 的基线。
 */
function filterRecordsBySource(records, bindingName, { label, code, multiSource }) {
  const out = [];
  for (const record of records) {
    if (!isPlainObject(record)) {
      out.push(record);
      continue;
    }
    const tag = sourceTagOf(record);
    if (tag) {
      if (tag === bindingName) out.push(record);
      continue;
    }
    if (multiSource) {
      throw new EvidenceAssemblyError(
        code,
        `${label} 条目缺 dataSourceName：多数据源聚合产物必须逐条标注归属`,
        { table: typeof record.table === 'string' ? record.table : null },
      );
    }
    out.push(record);
  }
  return out;
}

/**
 * 证据装配（§5.5 的 C；M3 先落 code-schema 侧）：
 *   code-table-inventory + db-table-list + runner raw + Agent B evidence → code-schema v3。
 *
 * 不解析 DDL、不做方言 introspection、不调用旧 MySQL parser；所有结构来自 evidence，
 * 并用 raw 记录补 rawDdl / serverVersion。任何缺口 fail-loud。
 *
 * @param {object} input
 * @param {object} input.evidence Agent B 输出
 * @param {object} input.raw runner 输出
 * @param {object} input.inventory Agent A 输出
 * @param {object} input.dbTableList runner catalog preflight 输出
 * @param {{dataSourceName:string, entryRef:string}} input.binding
 * @param {string} [input.databaseType]
 * @param {object} [input.scope] {database, owners, objectFilter}
 * @param {string} [input.previousInputRevision] 旧 code-schema 的 inputRevision（用于递增；读不到从 1 开始）
 */
export function assembleCodeSchemaFromEvidence({
  evidence,
  raw,
  inventory,
  dbTableList,
  binding,
  databaseType = '',
  scope = {},
  generatedAt = new Date().toISOString(),
  collectedAt = new Date().toISOString(),
  previousInputRevision = undefined,
} = {}) {
  if (!isPlainObject(evidence)) {
    throw new EvidenceAssemblyError('EVIDENCE_MISSING', 'table-structure.evidence.json 不可读');
  }
  if (evidence.kind !== 'table-structure.evidence' || evidence.schemaVersion !== 1) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_SCHEMA',
      `evidence 形状非法（kind=${JSON.stringify(evidence.kind)} schemaVersion=${JSON.stringify(evidence.schemaVersion)}）`,
    );
  }
  if (evidence.normalization !== 'agent') {
    throw new EvidenceAssemblyError(
      'EVIDENCE_NORMALIZATION',
      `evidence.normalization 必须是 "agent"（实际 ${JSON.stringify(evidence.normalization)}）`,
    );
  }
  if (!isPlainObject(raw) || raw.kind !== 'table-structure.raw') {
    throw new EvidenceAssemblyError('RAW_MISSING', 'table-structure.raw.json 不可读或 kind 非法');
  }
  if (!isPlainObject(dbTableList) || dbTableList.kind !== 'db-table-list') {
    throw new EvidenceAssemblyError(
      'EVIDENCE_DB_LIST',
      'db-table-list.json 不可读或 kind 非法（catalog preflight 未跑？）',
    );
  }
  if (!isPlainObject(inventory) || !Array.isArray(inventory.tables)) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_INVENTORY',
      'code-table-inventory.json 不可读或缺 tables（门 A 未跑？）',
    );
  }
  // inventory v2 是唯一可消费形状：v1 的 unresolved 无法可靠投影成 bound/external，
  // 不做猜测式升级，直接要求重跑 Agent A（与门 A 版本守卫同口径）。
  if (inventory.schemaVersion !== 2) {
    throw new EvidenceAssemblyError(
      'inventory-version-legacy',
      `code-table-inventory.json schemaVersion=${JSON.stringify(inventory.schemaVersion)}：只接受 v2。` +
        '旧 v1 产物不做自动投影（unresolved 里的具体表无法可靠判定 bound/external）；' +
        '请重跑 Agent A 产出 inventory v2（tables[].scope + dynamicPatterns[]，禁止 unresolved）。',
    );
  }
  // v2 禁止 unresolved：非空即红，迁移指引必须指向 external / dynamicPatterns。
  if (Array.isArray(inventory.unresolved) && inventory.unresolved.length > 0) {
    const labels = inventory.unresolved
      .map((item) => (isPlainObject(item) ? item.table || item.pattern || item.reason : item))
      .filter(Boolean)
      .join(', ');
    throw new EvidenceAssemblyError(
      'inventory-unresolved-forbidden',
      `code-table-inventory.unresolved 非空（${inventory.unresolved.length} 项${labels ? `：${labels}` : ''}）：` +
        'inventory v2 禁止 unresolved。具体表 → tables[] scope:"external"（附 SQL 独立库证据）；' +
        '动态表名 → dynamicPatterns[]；然后重跑 Agent A 产出 inventory v2。',
    );
  }
  // 动态表名独立桶：不参与 codeOnly/codeExpected，非空时 completeness 只能 partial。
  const dynamicPatterns = (() => {
    if (inventory.dynamicPatterns === undefined) return [];
    if (!Array.isArray(inventory.dynamicPatterns)) {
      throw new EvidenceAssemblyError(
        'inventory-dynamic-patterns-invalid',
        'code-table-inventory.dynamicPatterns 必须是数组（inventory v2 契约）',
      );
    }
    return inventory.dynamicPatterns.map((item, index) => {
      if (!isPlainObject(item)) {
        throw new EvidenceAssemblyError(
          'inventory-dynamic-patterns-invalid',
          `code-table-inventory.dynamicPatterns[${index}] 必须是对象（pattern/path/line/reason）`,
        );
      }
      const pattern = typeof item.pattern === 'string' ? item.pattern.trim() : '';
      if (!pattern) {
        throw new EvidenceAssemblyError(
          'inventory-dynamic-patterns-invalid',
          `code-table-inventory.dynamicPatterns[${index}] 缺 pattern（动态表名必须保留可复核模式）`,
        );
      }
      const normalized = { pattern };
      if (item.path != null && String(item.path).trim()) normalized.path = String(item.path).trim();
      if (item.line != null) normalized.line = String(item.line);
      if (item.reason != null && String(item.reason).trim()) normalized.reason = String(item.reason).trim();
      return normalized;
    });
  })();
  if (!isPlainObject(binding) || !String(binding.dataSourceName || '').trim()) {
    throw new EvidenceAssemblyError('EVIDENCE_BINDING', '缺已确认 dataSourceName');
  }
  const bindingName = String(binding.dataSourceName).trim();
  if (!Array.isArray(evidence.tables)) {
    throw new EvidenceAssemblyError('EVIDENCE_SCHEMA', 'evidence.tables 必须是数组');
  }
  if (!Array.isArray(raw.tables)) {
    throw new EvidenceAssemblyError('RAW_SCHEMA', 'raw.tables 必须是数组');
  }

  // 多源聚合产物：先选当前 binding 的来源，再按记录归属过滤；不跨源装配。
  const evidenceDoc = selectSourceDocument(evidence, bindingName, {
    label: 'table-structure.evidence',
    code: 'EVIDENCE_DATASOURCE',
  });
  const rawDoc = selectSourceDocument(raw, bindingName, {
    label: 'table-structure.raw',
    code: 'RAW_DATASOURCE',
  });
  const dbDoc = selectSourceDocument(dbTableList, bindingName, {
    label: 'db-table-list',
    code: 'EVIDENCE_DB_LIST',
  });
  const dbLegacy = !Array.isArray(dbTableList.sources) || dbTableList.sources.length === 0;
  const evidenceMulti = evidenceDoc.multiSource || distinctSourceTags(evidence.tables).size > 1;
  const rawMulti = rawDoc.multiSource || distinctSourceTags(raw.tables).size > 1;
  const evidenceTables = filterRecordsBySource(evidence.tables, bindingName, {
    label: 'table-structure.evidence.tables',
    code: 'EVIDENCE_DATASOURCE',
    multiSource: evidenceMulti,
  });
  const rawTables = filterRecordsBySource(raw.tables, bindingName, {
    label: 'table-structure.raw.tables',
    code: 'RAW_DATASOURCE',
    multiSource: rawMulti,
  });

  const dialect = canonicalDialect(evidence.dialect);
  if (!dialect) {
    throw new EvidenceAssemblyError('EVIDENCE_DIALECT', 'evidence.dialect 必须非空');
  }
  // 通道已收口为 MCP：旧 local 证据在装配层也必须红停，不能只靠 CLI 入口拦。
  if (raw.channel === 'local') {
    throw new EvidenceAssemblyError(
      'EVIDENCE_CHANNEL_RETIRED_LOCAL',
      'local 通道已退役，请重跑阶段四经 MCP 重新采集（旧 local 证据只能作为历史展示）',
    );
  }
  const channel = raw.channel === 'mcp' ? raw.channel : '';
  if (!channel) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_CHANNEL',
      `raw.channel 非法（${JSON.stringify(raw.channel)}；只支持 mcp）`,
    );
  }

  const rawKey = (name) => foldIdentifierForDialect(dialect, name, { quoted: false });
  const rawByName = new Map();
  const rawByExactName = new Map();
  rawTables.forEach((record, index) => {
    if (!isPlainObject(record) || !String(record.table || '').trim()) {
      throw new EvidenceAssemblyError('RAW_SCHEMA', `raw.tables[${index}] 缺 table`);
    }
    const key = rawKey(record.table);
    if (!rawByName.has(key)) rawByName.set(key, []);
    rawByName.get(key).push({ record, index });
    // 逐字表名优先（大小写变体是不同的物理表；折叠只作唯一命中时的兜底）。
    const exact = String(record.table).trim();
    if (!rawByExactName.has(exact)) rawByExactName.set(exact, { record, index });
  });

  // 零存量语义：只有「该源 codeExpected===0 且目录完整/未截断」才允许空 evidence/raw；
  // 有 code table 但采到空集仍然是采集失败（EVIDENCE_EMPTY / RAW_EMPTY）。
  const emptyAllowed = (() => {
    if (dbDoc.source.catalogComplete !== true && !(dbLegacy && dbDoc.source.catalogComplete === undefined)) {
      return false;
    }
    if (dbDoc.source.truncated === true) return false;
    const codeNames = new Set(
      (Array.isArray(dbDoc.source.tableNames) ? dbDoc.source.tableNames : [])
        .filter((name) => typeof name === 'string' && name.trim())
        .map((name) => rawKey(name)),
    );
    return inventory.tables
      .filter(isPlainObject)
      .filter((entry) => entry.scope === 'bound')
      .filter((entry) => !sourceTagOf(entry) || sourceTagOf(entry) === bindingName)
      .every((entry) => !String(entry.table || '').trim() || !codeNames.has(rawKey(entry.table)));
  })();
  if (evidenceTables.length === 0 && !emptyAllowed) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_EMPTY',
      'evidence.tables 为空且该数据源仍有 code table（不得以空集当作基线）',
    );
  }
  if (rawTables.length === 0 && !emptyAllowed) {
    throw new EvidenceAssemblyError(
      'RAW_EMPTY',
      'raw.tables 为空且该数据源仍有 code table（不得以空集当作基线）',
    );
  }

  const seenEvidenceKeys = new Set();
  const codeObjects = evidenceTables.map((entry, index) => {
    if (!isPlainObject(entry) || !String(entry.table || '').trim()) {
      throw new EvidenceAssemblyError('EVIDENCE_TABLE', `evidence.tables[${index}] 缺 table`);
    }
    const table = entry.table.trim();
    const tableKey = foldIdentifierForDialect(dialect, table, { quoted: false });
    if (!tableKey) {
      throw new EvidenceAssemblyError('EVIDENCE_TABLE', `evidence.tables[${index}].table 折叠后为空`);
    }
    if (seenEvidenceKeys.has(tableKey)) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_DUPLICATE_KEY',
        `同一 source 内 evidence 表 key 重复：${table}（禁静默去重；同名不同 owner/引号是不同的对象）`,
        { table, key: tableKey },
      );
    }
    seenEvidenceKeys.add(tableKey);
    // rawRef 命中/唯一性、raw 截断、parseIssues 均由门 B 裁决；C 只做「找得到就用」的宽松定位。
    const rawRef = isPlainObject(entry.rawRef) ? entry.rawRef : null;
    const refName = rawRef && typeof rawRef.table === 'string' && rawRef.table.trim() ? rawRef.table.trim() : table;
    const inScope = (record) =>
      isPlainObject(record) && (!sourceTagOf(record) || sourceTagOf(record) === bindingName);
    let hit = null;
    // ① rawRef.index 命中且**逐字同名**：最精确，直接采纳。
    if (rawRef && rawRef.index !== undefined && rawRef.index !== null) {
      const record = raw.tables[Number(rawRef.index)];
      if (inScope(record) && String(record.table || '').trim() === refName) {
        hit = record;
      }
    }
    // ② 逐字表名唯一命中（大小写变体各自独立，不跨大小写借用）。
    if (!hit) {
      const exact = rawByExactName.get(refName);
      if (exact && inScope(exact.record)) hit = exact.record;
    }
    // ③ 折叠兜底：仅当折叠结果唯一（多候选=歧义，宁可不借 DDL，也不接错表）。
    if (!hit) {
      const hits = (rawByName.get(rawKey(refName)) || []).filter((item) => inScope(item.record));
      if (hits.length === 1) hit = hits[0].record;
    }

    if (!Array.isArray(entry.columns) || entry.columns.length === 0) {
      throw new EvidenceAssemblyError('EVIDENCE_COLUMNS_EMPTY', `表 ${table} 的 columns 为空（不得放行）`, {
        table,
      });
    }
    const columns = entry.columns.map((column, columnIndex) => columnDdlOf(column, table, columnIndex));
    const rawDdl = typeof entry.rawDdl === 'string' && entry.rawDdl.trim() ? entry.rawDdl.trim() : ddlFromRawRecord(hit);
    // parseIssues 属于门 B 的职责，C 不重复裁决。
    const parseIssues = [];

    const owner = typeof entry.owner === 'string' && entry.owner.trim()
      ? entry.owner.trim()
      : typeof entry.schema === 'string' && entry.schema.trim()
        ? entry.schema.trim()
        : null;
    const quotedName =
      typeof entry.quoted === 'boolean' ? entry.quoted : Boolean(entry.quoted && entry.quoted.name === true);
    const quotedOwner = Boolean(entry.quoted && entry.quoted.owner === true);
    const parsed = {
      tableName: table,
      tableQuoted: quotedName,
      ddl: rawDdl,
      columns: columns.map((column) => ({
        name: column.name,
        ddl: column.ddl,
        ordinal: column.ordinal,
        hidden: column.hidden,
        virtual: column.virtual,
      })),
      indexes: definitionTexts(entry.indexes, 'indexes', table),
      constraints: definitionTexts(entry.constraints, 'constraints', table),
      foreignKeys: definitionTexts(entry.foreignKeys, 'foreignKeys', table),
      comments: {
        table:
          entry.comments && typeof entry.comments.table === 'string' ? entry.comments.table : null,
        columns:
          entry.comments && isPlainObject(entry.comments.columns) ? { ...entry.comments.columns } : {},
      },
      tableOptions:
        entry.tableOptions == null ? null : String(entry.tableOptions),
      parseIssues,
      error: null,
    };
    const object = toSchemaObjectV3(parsed, {
      owner,
      kind: OBJECT_KINDS.has(entry.kind) ? entry.kind : 'table',
    });
    object.quoted = { name: quotedName, owner: quotedOwner };
    object.diffable = parseIssues.length === 0 && rawDdl.trim() !== '';
    object.basis = 'code';
    return { object, owner, key: tableKey };
  });

  const evidenceSource = evidenceDoc.source;
  const ownerVerdict = assertSingleOwner(dialect, [
    ...(isPlainObject(evidenceSource) && Array.isArray(evidenceSource.owners) ? evidenceSource.owners : []),
    ...(isPlainObject(evidenceSource) && typeof evidenceSource.owner === 'string' ? [evidenceSource.owner] : []),
    ...codeObjects.map((item) => item.owner),
  ]);
  if (!ownerVerdict.ok) {
    throw new EvidenceAssemblyError('EVIDENCE_MULTI_OWNER', ownerVerdict.reason, {
      owners: ownerVerdict.owners,
    });
  }

  const dbSource = dbDoc.source;
  const names = Array.isArray(dbSource.tableNames)
    ? dbSource.tableNames.filter((name) => typeof name === 'string' && name.trim())
    : [];
  const catalogExpected = Number.isInteger(dbSource.catalogExpected)
    ? dbSource.catalogExpected
    : Number.isInteger(dbSource.rowCount)
      ? dbSource.rowCount
      : names.length;
  const catalogReturned = Number.isInteger(dbSource.catalogReturned) ? dbSource.catalogReturned : names.length;
  const catalogComplete =
    dbSource.catalogComplete === true || (dbLegacy && dbSource.catalogComplete === undefined);
  const catalogTruncated = dbSource.truncated === true;

  const probe = isPlainObject(rawDoc.source.probe)
    ? rawDoc.source.probe
    : isPlainObject(raw.probe)
      ? raw.probe
      : null;
  const probeVersion =
    probe && probe.ok === true && typeof probe.value === 'string' ? probe.value.trim() : '';
  const evidenceVersion =
    isPlainObject(evidenceSource) && typeof evidenceSource.serverVersion === 'string'
      ? evidenceSource.serverVersion.trim()
      : '';
  const serverVersion = probeVersion || evidenceVersion;

  const declaredDatabase =
    isPlainObject(evidenceSource) && Object.prototype.hasOwnProperty.call(evidenceSource, 'database')
      ? evidenceSource.database
      : scope.database !== undefined
        ? scope.database
        : null;
  const database = declaredDatabase == null ? null : String(declaredDatabase);
  const owners = ownerVerdict.owners.length > 0 ? ownerVerdict.owners : [...(scope.owners || [])];
  const objectFilter = scope.objectFilter || null;

  const sourceId = deriveSourceId({
    dataSourceName: binding.dataSourceName,
    dialect,
    scope: { database, owners, objectFilter },
  });

  // ── 分类（§4.1/§5.5）：codeTables / codeOnly / dbOnly，按方言折叠后的表名 key 判等 ──
  // 身份不是裸表名：这里只做装配期分类匹配；最终身份仍由 sourceId + owner + name + quoted 派生。
  const candidateByKey = new Map();
  const candidates = [];
  const boundEntries = [];
  for (let index = 0; index < inventory.tables.length; index++) {
    const entry = inventory.tables[index];
    if (!isPlainObject(entry) || !String(entry.table || '').trim()) {
      throw new EvidenceAssemblyError('EVIDENCE_INVENTORY', `code-table-inventory.tables[${index}] 缺 table`);
    }
    // inventory v2 每条具体表必须声明 scope；缺省/非法不得默认按 bound 处理。
    if (entry.scope !== 'bound' && entry.scope !== 'external') {
      throw new EvidenceAssemblyError(
        'inventory-scope-invalid',
        `code-table-inventory.tables[${index}].scope=${JSON.stringify(entry.scope)}：只允许 bound|external（inventory v2 契约）`,
      );
    }
    const entrySource = typeof entry.dataSourceName === 'string' ? entry.dataSourceName.trim() : '';
    // external 是「具体表 + 无绑定连接」：永不进 codeOnly/codeExpected，也不产生 create/delta。
    if (entry.scope === 'external') continue;
    boundEntries.push(entry);
    if (entrySource && entrySource !== bindingName) continue;
    const table = entry.table.trim();
    const key = foldIdentifierForDialect(dialect, table, { quoted: false });
    if (!key) {
      throw new EvidenceAssemblyError('EVIDENCE_INVENTORY', `code-table-inventory.tables[${index}] 表名折叠后为空`);
    }
    if (candidateByKey.has(key)) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_DUPLICATE_KEY',
        `同一 source 内 code-table-inventory 表 key 重复：${table}（禁静默去重）`,
        { table, key },
      );
    }
    const candidate = { entry, key, table };
    candidateByKey.set(key, candidate);
    candidates.push(candidate);
  }
  if (boundEntries.length > 0 && candidates.length === 0) {
    const allExplicit = boundEntries.every((entry) => Boolean(sourceTagOf(entry)));
    if (!allExplicit) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_INVENTORY_DATASOURCE',
        `code-table-inventory 没有任何属于 dataSourceName=${bindingName} 的 bound 表，且存在无归属条目（不按别名合并表清单）`,
      );
    }
    // 全部 bound 条目都显式属于其它数据源 ⇒ 本数据源零代码表是合法形态（目录完整性另行校验）。
  }
  // 新产物恒空：inventory v2 的 unresolved 已在入口红停；保留字段只为旧 code-schema 兼容。
  const unresolved = [];

  // ── 库表身份：按**原始表名**（大小写敏感）判等；折叠 key 只用于「代码表 ↔ 库表」匹配 ──
  // MySQL 在 Linux 下表名大小写敏感：`QRTZ_BLOB_TRIGGERS` 与 `qrtz_blob_triggers` 是两张不同
  // 物理表（沙箱实跑 11 组）。用折叠 key 判身份会把真实多对象误判成「采集损坏」并红停。
  // 不变量不变：**完全同名**出现两次仍是损坏 ⇒ fail-loud；大小写变体是两个独立对象，不去重。
  const dbByExactName = new Set();
  const dbNamesByFold = new Map(); // 折叠 key -> 原始表名[]（>1 = 大小写变体）
  for (let index = 0; index < names.length; index++) {
    const rawName = names[index].trim();
    const folded = rawKey(rawName);
    if (!folded) {
      throw new EvidenceAssemblyError('EVIDENCE_DB_LIST', `db-table-list.tableNames[${index}] 折叠后为空`);
    }
    if (dbByExactName.has(rawName)) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_DUPLICATE_KEY',
        `db-table-list 同一 source 内表名完全重复：${rawName}（禁静默去重）`,
        { table: rawName, key: folded },
      );
    }
    dbByExactName.add(rawName);
    if (!dbNamesByFold.has(folded)) dbNamesByFold.set(folded, []);
    dbNamesByFold.get(folded).push(rawName);
  }
  // 大小写变体 = 真实多对象（非重复）：留痕供下游识别"折叠同值"的歧义面。
  const identityCaseCollisions = [...dbNamesByFold.entries()]
    .filter(([, exactNames]) => exactNames.length > 1)
    .map(([key, exactNames]) => ({ key, names: [...exactNames] }))
    .sort((left, right) => (left.key < right.key ? -1 : left.key > right.key ? 1 : 0));

  // 代码表 → 库表：逐字优先；未命中再折叠匹配，且必须唯一（多候选=歧义，不猜）。
  const dbMatchByCandidateKey = new Map(); // 折叠 key -> 命中到的原始库表名
  const ambiguousCodeTables = [];
  for (const candidate of candidates) {
    if (dbByExactName.has(candidate.table)) {
      dbMatchByCandidateKey.set(candidate.key, candidate.table);
      continue;
    }
    const hits = dbNamesByFold.get(candidate.key) || [];
    if (hits.length === 1) dbMatchByCandidateKey.set(candidate.key, hits[0]);
    else if (hits.length > 1) {
      ambiguousCodeTables.push({ table: candidate.table, key: candidate.key, candidates: [...hits] });
    }
  }

  // 真歧义（代码表既无逐字命中、折叠后又对多张库表）不得猜：结构化失败交修复环，
  // 由 agent 把 inventory/evidence 的表名改成物理名（大小写明确）后重采。
  if (ambiguousCodeTables.length > 0) {
    throw new EvidenceAssemblyError(
      'EVIDENCE_AMBIGUOUS_IDENTITY',
      `代码表折叠后命中多张库表（大小写歧义，不得猜）：${ambiguousCodeTables
        .map((item) => `${item.table} → ${item.candidates.join(' / ')}`)
        .join('；')}`,
      { ambiguous: ambiguousCodeTables },
    );
  }

  const codeTableKeys = new Set();
  const codeOnlyKeys = new Set();
  for (const key of candidateByKey.keys()) {
    if (dbMatchByCandidateKey.has(key)) codeTableKeys.add(key);
    else codeOnlyKeys.add(key);
  }
  const consumedDbNames = new Set(dbMatchByCandidateKey.values());
  const dbOnlyNames = [...dbByExactName].filter((name) => !consumedDbNames.has(name));
  for (const item of codeObjects) {
    if (!codeTableKeys.has(item.key)) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_UNCLASSIFIED',
        `evidence 表 ${item.object.name} 不在 codeTables 清单内（分类为 ${codeOnlyKeys.has(item.key) ? 'codeOnly' : '未知'}）：` +
          'C 只装配门 A/分类确认过的 code table，不得自行扩表',
        { table: item.object.name },
      );
    }
  }

  // ── identity-only db-only：只保证表名/owner 进入 retained/gaps 铁律，不伪造列结构 ──
  const dbOnlyObjects = dbOnlyNames.map((rawName) => {
    const name = stripIdentifierQuotes(rawName);
    const quoted = { name: isQuotedIdentifier(rawName), owner: false };
    const owner = owners.length === 1 ? owners[0] : null;
    return {
      object: {
        owner,
        name,
        quoted,
        kind: 'table',
        rawDdl: '',
        columns: [],
        indexes: [],
        constraints: [],
        foreignKeys: [],
        comments: { table: null, columns: {} },
        tableOptions: null,
        parseIssues: [],
        diffable: false,
        basis: 'db-only',
      },
    };
  });

  const objects = [...codeObjects, ...dbOnlyObjects];
  // v3 身份 = sourceId + owner + kind + name（quoted/rawDdl 不参与）；重复即红，不静默合并。
  const seenRefs = new Map();
  for (const item of objects) {
    const owner = item.object.owner == null ? null : item.object.owner;
    const key = JSON.stringify([sourceId, owner, item.object.kind, item.object.name]);
    if (seenRefs.has(key)) {
      throw new EvidenceAssemblyError(
        'EVIDENCE_DUPLICATE_KEY',
        `同一 source 内对象引用重复（sourceId+owner+kind+name）：${item.object.name} 与 ${seenRefs.get(key)} ` +
          '指向同一引用；禁止静默去重或按下标任选其一。',
        { sourceId, owner, kind: item.object.kind, name: item.object.name },
      );
    }
    seenRefs.set(key, item.object.name);
  }
  objects.sort((left, right) =>
    compareCodepoint(objectRefSortKey(left.object), objectRefSortKey(right.object)),
  );

  const failures = [];
  // 目录完整性是 C 的装配职责（Gate A 已先行判定）；raw 截断/parseIssues 不在这里重复裁决。
  if (catalogTruncated) failures.push('db-table-list 被字节截断（truncated=true）');
  if (!catalogComplete) failures.push('目录不完整（catalogComplete!==true）：不得视为完整基线');
  if (catalogExpected !== catalogReturned) {
    failures.push(`目录 COUNT=${catalogExpected} 与返回表数=${catalogReturned} 不一致`);
  }
  if (!serverVersion) failures.push('缺服务端版本（probe 与 evidence 均未提供），completeness 不得为 complete');

  const missingPermissions = isPlainObject(evidenceSource) && Array.isArray(evidenceSource.missingPermissions)
    ? evidenceSource.missingPermissions.map((item) => String(item))
    : [];
  if (missingPermissions.length > 0) {
    failures.push(`采集存在缺失权限/能力：${missingPermissions.join(', ')}`);
  }

  const codeExpected = codeTableKeys.size;
  const codeCollected = codeObjects.length;
  const dbOnly = dbOnlyNames.length;
  const dbOnlyCollected = dbOnlyObjects.length;
  const codeOnly = codeOnlyKeys.size;
  // 零存量结构：该源确认没有任何 code table/db-only 对象时，空对象集是合法基线。
  const zeroStock = codeExpected === 0 && dbOnly === 0 && catalogComplete && catalogExpected === 0;
  if (objects.length === 0 && !zeroStock) failures.push('未装配出任何对象');
  if (codeCollected !== codeExpected) {
    const missing = [...codeTableKeys]
      .filter((key) => !seenEvidenceKeys.has(key))
      .map((key) => dbMatchByCandidateKey.get(key) || key);
    failures.push(
      `code tables 采集不完整：codeExpected=${codeExpected} codeCollected=${codeCollected}` +
        (missing.length > 0 ? `（缺 ${missing.join(', ')}）` : ''),
    );
  }
  if (dbOnlyCollected !== dbOnly) {
    failures.push(`db-only identity-only 对象未全覆盖：dbOnly=${dbOnly} dbOnlyCollected=${dbOnlyCollected}`);
  }
  if (unresolved.length > 0) {
    failures.push(
      `code-table-inventory 仍有 ${unresolved.length} 个 unresolved 项（先清零或显式判定 external/ignore）：` +
        unresolved.map((item) => item.table || item.pattern || '?').join(', '),
    );
  }

  // 动态表名是"已声明的边界"（DML 上下文运行时只能命中已存在的表），不是基线不完整信号；
  // dynamicPatterns 仍原样写入 completeness 供追溯，但不参与 status 判定。
  // Entailment（plan 2026-11-09 §3.2）：消费侧放行全部 dynamicPatterns 的前提，是门 A 已保证
  // 进入 inventory 的动态模式只有 dml 上下文——ddl / unknown 上下文在门 A 即红停
  // （TABLE_INVENTORY_DYNAMIC_DDL_UNRESOLVED / TABLE_INVENTORY_DYNAMIC_CONTEXT_UNKNOWN），
  // 消费侧不重复解析源码。若未来出现绕过门 A 的入口，必须回到 plan §3.2 补判据
  // （redundant-gate-must-declare-entailment）。
  const status =
    failures.length === 0 &&
    codeCollected === codeExpected &&
    unresolved.length === 0 &&
    dbOnlyCollected === dbOnly
      ? 'complete'
      : 'partial';
  const capabilities = [
    'agent_plan',
    'normalization:agent',
    `channel:${channel}`,
    'catalog_preflight',
    'basis:code',
    'classification:code-table-inventory',
  ];
  if (serverVersion) capabilities.push('server_version');
  const evidenceRefs = [
    'runner:table-structure.raw.json',
    'agent_b:table-structure.evidence.json',
    'gate_a:code-table-inventory.json',
    'gate_a:db-table-list.json',
  ];
  if (raw.plan && typeof raw.plan.sha256 === 'string' && raw.plan.sha256) {
    evidenceRefs.push(`runner_plan:${raw.plan.sha256}`);
  }

  const source = {
    sourceId,
    binding: { dataSourceName: binding.dataSourceName, entryRef: binding.entryRef || '' },
    databaseType: String(databaseType || (isPlainObject(evidenceSource) ? evidenceSource.databaseType || '' : '')),
    dialect,
    serverVersion,
    capabilities: [...new Set(capabilities)],
    scope: { database, owners: [...owners].sort(), objectFilter, basis: 'code' },
    channel,
    collectedAt,
    // 折叠同值的库表（大小写变体）：引用含原始名，身份仍各自独立，此处只留痕。
    identity: { caseCollisions: identityCaseCollisions },
    completeness: {
      status,
      catalogExpected,
      catalogReturned,
      codeExpected,
      codeCollected,
      dbOnly,
      dbOnlyCollected,
      codeOnly,
      unresolved,
      dynamicPatterns,
      objectsParsed: objects.length,
      truncated: catalogTruncated,
      missingPermissions: [...new Set(missingPermissions)],
      evidenceRefs,
    },
    objects: objects.map((item) => item.object),
  };

  return {
    status,
    failures,
    schema: {
      schemaVersion: CODE_SCHEMA_SCHEMA_VERSION,
      inputRevision: nextInputRevision(generatedAt, previousInputRevision),
      generatedAt,
      sources: [source],
    },
  };
}

/** 失败/部分采集回执（不写成功壳；目标记录在 receipt.target / source.binding+scope）。 */
export function buildFailureReceipt({ state = 'failed', generatedAt = new Date().toISOString(), binding = null, channel = null, target = null, stage = null, error = null, failures = [], schema = null } = {}) {
  return {
    schemaVersion: CODE_SCHEMA_SCHEMA_VERSION,
    state,
    generatedAt,
    binding,
    channel,
    target,
    stage,
    error: error == null ? null : String(error),
    failures: [...failures],
    ...(schema ? { sources: schema.sources } : {}),
  };
}

// ─── 自测（纯函数，不连库）────────────────────────────────────────────────────
function assert(cond, msg) {
  if (!cond) {
    console.error(`[self-test] FAIL: ${msg}`);
    process.exit(1);
  }
}

function runSelfTest() {
  // 1. DDL 原文解析：按列切分、索引/约束/外键分流、表 COMMENT 含括号不被吞
  const ddl = `CREATE TABLE \`project\` (
  \`id\` bigint NOT NULL AUTO_INCREMENT,
  \`project_code\` varchar(64) NOT NULL COMMENT '项目编号',
  \`name\` varchar(255) DEFAULT NULL,
  \`status\` tinyint DEFAULT '1',
  PRIMARY KEY (\`id\`),
  UNIQUE KEY \`uk_project_code\` (\`project_code\`),
  CONSTRAINT \`fk_status\` FOREIGN KEY (\`status\`) REFERENCES \`dict\` (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目(含括号)表'`;
  const parsed = parseShowCreateTable(ddl);
  assert(parsed.tableName === 'project', `tableName got ${parsed.tableName}`);
  assert(parsed.tableQuoted === true, 'tableQuoted');
  assert(parsed.columns.length === 4, `columns len ${parsed.columns.length}`);
  assert(parsed.columns[0].name === 'id', 'col0 name');
  assert(parsed.columns.every((c) => c.source === 'db'), 'col source db');
  assert(parsed.columns[0].ordinal === 1 && parsed.columns[3].ordinal === 4, 'ordinal');
  assert(parsed.indexes.length === 2, `indexes len ${parsed.indexes.length}`);
  assert(parsed.constraints.length === 2, `constraints len ${parsed.constraints.length}`);
  assert(parsed.foreignKeys.length === 1, `fk len ${parsed.foreignKeys.length}`);
  assert(parsed.comments.table === '项目(含括号)表', `table comment got ${parsed.comments.table}`);
  assert(parsed.comments.columns.project_code === '项目编号', 'column comment');
  assert(parsed.tableOptions.includes('ENGINE=InnoDB'), 'tableOptions');
  assert(parsed.parseIssues.length === 0, 'no parse issues');

  // 2. 带小数精度的列 / 无表选项
  const p2 = parseShowCreateTable('CREATE TABLE `amount` (`id` bigint NOT NULL,`money` decimal(18,2) NOT NULL) ENGINE=InnoDB');
  assert(p2.columns.length === 2, `p2 cols ${p2.columns.length}`);
  assert(p2.columns[1].ddl === '`money` decimal(18,2) NOT NULL', `p2 col1 ddl: ${p2.columns[1].ddl}`);

  // 3. 方言归一：已知别名归一，未知原样透传（不猜 MySQL）
  assert(normalizeDialect('Oracle') === 'oracle', 'oracle');
  assert(normalizeDialect('PostgreSQL') === 'postgresql', 'pg');
  assert(normalizeDialect('') === 'unknown', 'empty -> legacy unknown sentinel');
  assert(normalizeDialect('CustomDB') === 'CustomDB', 'unknown passthrough');
  assert(normalizeDialect('MySQL8') === 'mysql', 'mysql alias');

  // 4. 采集分组身份（sourceId 保留）+ v3 对象无 objectId、引用唯一性
  const scope = { database: 'db1', owners: [], objectFilter: null };
  const sid = deriveSourceId({ dataSourceName: 'ds-order', dialect: 'mysql', scope });
  assert(SOURCE_ID_RE.test(sid), `sourceId pattern ${sid}`);
  assert(sid === deriveSourceId({ dataSourceName: 'ds-order', dialect: 'mysql', scope }), 'sourceId deterministic');
  const v3Object = toSchemaObjectV3(parsed, { owner: null });
  assert(!('objectId' in v3Object), 'v3 object has no objectId');
  assert(v3Object.name === 'project', `v3 object name ${v3Object.name}`);
  const uniqueSchema = { schemaVersion: CODE_SCHEMA_SCHEMA_VERSION, sources: [{ sourceId: sid, objects: [v3Object] }] };
  assertUniqueObjectRefs(uniqueSchema);
  let duplicateRefRejected = false;
  try {
    assertUniqueObjectRefs({ schemaVersion: CODE_SCHEMA_SCHEMA_VERSION, sources: [{ sourceId: sid, objects: [v3Object, { ...v3Object }] }] });
  } catch {
    duplicateRefRejected = true;
  }
  assert(duplicateRefRejected, 'duplicate ref must be rejected');
  const sid2 = deriveSourceId({ dataSourceName: 'ds-order', dialect: 'mysql', scope: { ...scope, database: 'db2' } });
  assert(sid !== sid2, 'different scope → different sourceId');

  // 5. DDL 归一：保留大小写/引号/字符串字面量，只折叠引号外空白
  const norm = normalizeDdlFragment("`Name`   VARCHAR(64)   DEFAULT 'A  B'");
  assert(norm === "`Name` VARCHAR(64) DEFAULT 'A  B'", `normalizeDdlFragment got ${norm}`);
  assert(foldDdlForCompare('`Name` INT') === foldDdlForCompare('name int'), 'fold ignores identifier quote/case');
  assert(foldDdlForCompare("DEFAULT 'A'") !== foldDdlForCompare("DEFAULT 'a'"), 'fold keeps string literal case');

  // 6. fingerprint / baseline digest：排除 volatile 字段；v3 投影不含 objectId
  const object = toSchemaObjectV3(parsed);
  const digest1 = computeObjectDigest(object);
  const digest2 = computeObjectDigest({ ...object, parseIssues: ['volatile'] });
  assert(digest1 === digest2, 'objectDigest excludes parseIssues');
  const schema = { schemaVersion: CODE_SCHEMA_SCHEMA_VERSION, generatedAt: 't1', sources: [{ sourceId: sid, binding: { dataSourceName: 'ds-order', entryRef: 'datasources.json#ds-order' }, databaseType: 'mysql', dialect: 'mysql', serverVersion: '8.0', capabilities: [], scope, channel: 'mcp', collectedAt: 't1', completeness: { status: 'complete', catalogExpected: 1, catalogReturned: 1, objectsParsed: 1, truncated: false, missingPermissions: [], evidenceRefs: ['x'] }, objects: [object] }] };
  const base1 = computeBaselineDigest(schema);
  const base2 = computeBaselineDigest({ ...schema, generatedAt: 't2', sources: [{ ...schema.sources[0], collectedAt: 't2', completeness: { ...schema.sources[0].completeness, evidenceRefs: ['y'] } }] });
  assert(base1 === base2, 'baseline digest excludes generatedAt/collectedAt/evidenceRefs');
  assert(base1.startsWith('sha256:'), 'baseline digest prefix');

  // 7. 单语句切分：引号内分号不算
  assert(splitSqlStatements("ALTER TABLE t ADD c varchar(10) DEFAULT ';';").length === 1, 'semicolon in literal');
  assert(splitSqlStatements('ALTER TABLE t ADD a int; ALTER TABLE t ADD b int;').length === 2, 'two statements');

  console.log('[self-test] PASS — DDL 切分/表注释括号/方言拒绝/sourceId/引用唯一性/归一/fingerprint/单语句切分 全通过');
  process.exit(0);
}

// ─── 主流程 ─────────────────────────────────────────────────────────────────
function resolveChannel(args) {
  const explicit = typeof args.channel === 'string' && args.channel.trim() ? args.channel.trim() : '';
  const channel = explicit || 'mcp';
  if (channel === 'local') {
    throw new Error('local 通道已退役，请经 MCP 重新采集');
  }
  if (channel !== 'mcp') {
    throw new Error(`未知采集通道 "${channel}"：只允许 mcp（local 通道已退役；不回退）`);
  }
  return channel;
}

function buildScope(args) {
  const splitList = (value) =>
    typeof value === 'string' && value.trim() ? value.split(',').map((s) => s.trim()).filter(Boolean) : null;
  const include = splitList(args.include);
  const exclude = splitList(args.exclude);
  const hasFilter = include != null || exclude != null;
  return {
    database: null, // 由调用方填 ds.db
    owners: [],
    objectFilter: hasFilter
      ? { kind: args.objectKind === 'all' ? 'all' : 'table', include: include || null, exclude: exclude || null }
      : null,
  };
}

/**
 * 读旧 `code-schema.json` 的 `inputRevision`（D17 递增）；文件缺失/不可解析/字段缺失
 * 一律返回 undefined（调用方从 1 开始），不影响采集。
 */
function readPreviousInputRevision(plansBackendDir) {
  if (!plansBackendDir) return undefined;
  try {
    const file = resolve(plansBackendDir, '_meta', 'code-schema.json');
    if (!existsSync(file)) return undefined;
    const parsed = JSON.parse(readFileSync(file, 'utf-8'));
    return parsed && typeof parsed.inputRevision === 'string' ? parsed.inputRevision : undefined;
  } catch {
    return undefined;
  }
}

/**
 * 失败回执落点（plan 2026-11-04 §3 D3）：
 *   ① 已定位的 plansBackendDir；② `--active-spec-dir` 派生的 `<activeSpecDir>/plans/backend`；
 *   ③ 都没有 ⇒ 不写（只在 stderr 输出原因）。
 * 禁止 `<backendDir>/../plans/backend` 这类回退：它会把失败回执写成 `<app>/plans/backend` stray 目录，
 * 下一轮遮蔽真实 docs 轮（plan §1.2）。
 */
function writeFailureReceipt({ plansBackendDir, activeSpecDir, receipt }) {
  const target = plansBackendDir || (activeSpecDir ? resolve(activeSpecDir, 'plans', 'backend') : null);
  if (!target) return null;
  const metaDir = resolve(target, '_meta');
  try {
    mkdirSync(metaDir, { recursive: true });
    const file = resolve(metaDir, 'code-schema.failure.json');
    writeFileSync(file, JSON.stringify(receipt, null, 2) + '\n', 'utf-8');
    return file;
  } catch {
    return null;
  }
}

function evidenceStageError(stage, message, extra = {}) {
  const error = new Error(message);
  error.stage = stage;
  return Object.assign(error, extra);
}

function readEvidenceDocument(filePath, label) {
  if (!existsSync(filePath)) {
    throw evidenceStageError('evidence', `缺 ${label}：${filePath}（拒绝静默跳过）`);
  }
  try {
    return JSON.parse(readFileSync(filePath, 'utf-8'));
  } catch (error) {
    throw evidenceStageError('evidence', `${label} JSON 解析失败：${(error && error.message) || error}`);
  }
}

function evidenceMetaPath(args, plansBackendDir, key, rel) {
  const explicit = typeof args[key] === 'string' && args[key].trim() ? args[key].trim() : '';
  if (explicit) return resolve(explicit);
  return resolve(plansBackendDir, rel.slice('plans/backend/'.length));
}

/**
 * 收集一份证据文档上的显式通道声明（与 `check-table-structure-evidence.mjs` 同口径）。
 * 通道真值可出现在顶层 `channel`、`source.channel` 与 `sources[].channel`。
 */
function evidenceChannelDeclarations(document) {
  const list = [];
  if (!isPlainObject(document)) return list;
  const add = (path, value) => {
    if (value === undefined || value === null) return;
    list.push({ path, value });
  };
  add('channel', document.channel);
  if (isPlainObject(document.source)) add('source.channel', document.source.channel);
  for (const [index, source] of (Array.isArray(document.sources) ? document.sources : []).entries()) {
    if (isPlainObject(source)) add(`sources[${index}].channel`, source.channel);
  }
  return list;
}

/**
 * 写盘前的通道闸门：raw / evidence / db-table-list 三类输入统一裁决。
 *   · raw 是新批次唯一通道事实来源：没有任何声明 ⇒ 红停（不能靠「没写」蒙混）；
 *   · 任意文档的顶层 / source / sources[] 声明 local ⇒ 退役红停（P4 重采入口）；
 *   · 其它非 mcp 值 ⇒ 非法红停。
 * 必须在任何成功产物（code-schema.json）写盘之前调用。
 */
function assertEvidenceChannels({ raw, evidence, dbTableList }) {
  if (evidenceChannelDeclarations(raw).length === 0) {
    throw evidenceStageError(
      'evidence',
      `raw.channel 非法（${JSON.stringify(raw && raw.channel)}；只支持 mcp）`,
    );
  }
  for (const [prefix, document] of [
    ['$raw', raw],
    ['$evidence', evidence],
    ['$dbTableList', dbTableList],
  ]) {
    for (const { path, value } of evidenceChannelDeclarations(document)) {
      const channel = typeof value === 'string' ? value.trim() : '';
      if (channel === 'mcp') continue;
      if (channel === 'local') {
        throw evidenceStageError(
          'evidence',
          `${prefix}.${path}="local"：通道已退役，请重跑阶段四经 MCP 重新采集（旧 local 证据只能作为历史展示）`,
          { channel: 'local' },
        );
      }
      // 保持历史错误文案：raw 顶层缺失/非法都以「raw.channel 非法」呈现。
      if (prefix === '$raw' && path === 'channel') {
        throw evidenceStageError(
          'evidence',
          `raw.channel 非法（${JSON.stringify(value)}；只支持 mcp）`,
          { channel: channel || null },
        );
      }
      throw evidenceStageError(
        'evidence',
        `${prefix}.${path}=${JSON.stringify(value)} 非法：结构证据通道只允许 "mcp"（local 已退役）`,
        { channel: channel || null },
      );
    }
  }
}

/**
 * P4 新路径：Agent A → preflight → 门 A → Agent B → runner → 门 B 之后，
 * 由 evidence + raw 装配 code-schema v3（不再走 MySQL introspection）。
 */
async function runFromEvidence({ args, policy, plansBackendDir, workCwd }) {
  if (!plansBackendDir) {
    throw evidenceStageError('evidence', '未定位 plans/backend 目录（无法读取 table-structure.evidence.json）');
  }
  // D17：成功写出前先读旧批次的 inputRevision，保证每次生成都递增变化。
  const previousInputRevision = readPreviousInputRevision(plansBackendDir);
  const evidencePath = evidenceMetaPath(args, plansBackendDir, 'evidence', EVIDENCE_REL);
  const rawPath = evidenceMetaPath(args, plansBackendDir, 'raw', TABLE_RAW_REL);
  const inventoryPath = evidenceMetaPath(args, plansBackendDir, 'inventory', CODE_TABLE_INVENTORY_REL);
  const dbTableListPath = evidenceMetaPath(args, plansBackendDir, 'dbTableList', DB_TABLE_LIST_REL);

  const evidence = readEvidenceDocument(evidencePath, 'table-structure.evidence.json');
  const raw = readEvidenceDocument(rawPath, 'table-structure.raw.json');
  const inventory = readEvidenceDocument(inventoryPath, 'code-table-inventory.json');
  const dbTableList = readEvidenceDocument(dbTableListPath, 'db-table-list.json');

  // 写盘前统一通道闸门：raw / evidence / db-table-list（顶层与逐源）任一处 local 即红停，
  // 不得只检查 raw.channel 就写出 channel=mcp 的成功基线覆盖旧 code-schema.json。
  assertEvidenceChannels({ raw, evidence, dbTableList });
  const channel = 'mcp';

  // 通道已收敛为 mcp：resolver 只做契约条目 → MCP 请求上下文，不再按通道分叉。
  const strict = resolveIncrementalDatasource(workCwd, {
    dataSourceName: policy.dataSourceName || '',
    appId: args.appId,
  });
  if (!strict.ok) {
    throw evidenceStageError('resolve-datasource', strict.reason, { channel });
  }
  const ds = strict.ds;
  const dataSourceName = String(policy.dataSourceName || ds.dataSourceName || '').trim();
  if (!dataSourceName) {
    throw evidenceStageError(
      'resolve-binding',
      '缺已确认 dataSourceName（绑定 envelope/显式参数），拒绝以默认实例采集',
      { channel },
    );
  }
  const binding = {
    dataSourceName,
    entryRef: `datasources.json#${dataSourceName}`,
  };

  const dialect = canonicalDialect(evidence && evidence.dialect);
  const scope = buildScope(args);
  scope.database = dialect === 'oracle' ? null : ds.db || null;
  // 多源聚合 evidence：owner 只取当前数据源的来源条目。
  let evidenceSourceForScope = null;
  if (isPlainObject(evidence)) {
    try {
      evidenceSourceForScope = selectSourceDocument(evidence, dataSourceName, {
        label: 'table-structure.evidence',
        code: 'EVIDENCE_DATASOURCE',
      }).source;
    } catch {
      evidenceSourceForScope = null;
    }
  }
  scope.owners = isPlainObject(evidenceSourceForScope) && Array.isArray(evidenceSourceForScope.owners)
    ? evidenceSourceForScope.owners.filter((owner) => typeof owner === 'string' && owner.trim())
    : [];

  let assembled;
  try {
    assembled = assembleCodeSchemaFromEvidence({
      evidence,
      raw,
      inventory,
      dbTableList,
      binding,
      databaseType: ds.databaseType || '',
      scope,
      previousInputRevision,
    });
  } catch (error) {
    if (error instanceof EvidenceAssemblyError) {
      throw evidenceStageError('assemble-evidence', error.message, {
        channel,
        binding,
        failures: [error.message],
        details: error.details,
      });
    }
    throw error;
  }

  // dynamicPatterns 是已声明的边界，不再降 partial；其它 partial/failed 仍拒绝写成功壳。
  if (assembled.status !== 'complete') {
    throw evidenceStageError('assemble-evidence', '证据装配不完整，拒绝写成功壳/不把表标 rebuild', {
      channel,
      binding,
      status: 'partial',
      failures: assembled.failures,
      schema: assembled.schema,
    });
  }

  const metaDir = resolve(plansBackendDir, '_meta');
  mkdirSync(metaDir, { recursive: true });
  const outFile = resolve(metaDir, 'code-schema.json');
  // 写盘前引用唯一性校验（v3）：sourceId+owner+kind+name 重复即失败，不静默合并。
  assertUniqueObjectRefs(assembled.schema);
  writeFileSync(outFile, JSON.stringify(assembled.schema, null, 2) + '\n', 'utf-8');
  rmSync(resolve(metaDir, 'code-schema.failure.json'), { force: true });
  const source = assembled.schema.sources[0];
  console.log(
    JSON.stringify({
      ok: true,
      mode: 'from-evidence',
      file: outFile,
      schemaVersion: CODE_SCHEMA_SCHEMA_VERSION,
      sourceId: source.sourceId,
      sources: 1,
      objects: source.objects.length,
      dialect: source.dialect,
      channel: source.channel,
      completeness: source.completeness.status,
    }),
  );
  return 0;
}

async function main() {
  let args;
  try {
    args = parseArgs(process.argv);
  } catch (e) {
    console.error(`[extract-code-schema] ${e.message}`);
    process.exit(1);
    return;
  }
  if (args.selfTest) return runSelfTest();
  const workCwd = process.cwd();
  // plans 目录 = 证据/产物所在；代码根只在 legacy 扫代码分支解析（plan §3 D2）。
  const plansBackendDir = findPlanBackendDir(workCwd);
  const activeSpecDir = typeof args.activeSpecDir === 'string' && args.activeSpecDir.trim()
    ? resolve(args.activeSpecDir.trim())
    : null;

  // ── 新编排路径：evidence 装配（P4：A → preflight → 门 A → B → runner → 门 B 之后）──
  // 本分支只读 evidence/binding，不读代码 ⇒ 不得调用 findBackendDir。
  if (args.fromEvidence) {
    const policy = resolveDesignTimeDatasource({
      planBackendDir: plansBackendDir,
      dataSourceName: args.dataSourceName,
      moduleId: args.moduleId,
    });
    if (!policy.ok) {
      const file = writeFailureReceipt({
        plansBackendDir,
        activeSpecDir,
        receipt: buildFailureReceipt({
          state: 'failed',
          stage: 'resolve-datasource',
          error: policy.reason,
        }),
      });
      console.error(`[extract-code-schema] ${policy.reason}${file ? `（失败回执：${file}）` : ''}`);
      process.exit(1);
    }
    try {
      await runFromEvidence({ args, policy, plansBackendDir, workCwd });
      return;
    } catch (error) {
      const failures = Array.isArray(error.failures) ? error.failures : [];
      const receipt = buildFailureReceipt({
        state: error.status === 'partial' ? 'partial' : 'failed',
        stage: error.stage || 'from-evidence',
        channel: error.channel || null,
        binding: error.binding || null,
        target: null,
        error: (error && error.message) || String(error),
        failures,
        schema: error.schema || null,
      });
      const file = writeFailureReceipt({ plansBackendDir, activeSpecDir, receipt });
      console.error(
        `[extract-code-schema] evidence 装配失败：${(error && error.message) || error}` +
          `${failures.length > 0 ? `（${failures.join('；')}）` : ''}` +
          `${file ? `（失败回执：${file}）` : ''}`,
      );
      process.exit(1);
    }
  }

  // legacy 扫代码路径：只有这里才需要代码根（findBackendDir 仅作 legacy 兜底）。
  const backendDir = findBackendDir(workCwd);
  if (!backendDir) {
    console.error('[extract-code-schema] 未定位后端工程目录（缺 pom.xml/build.gradle）');
    process.exit(1);
  }
  const policy = resolveDesignTimeDatasource({
    planBackendDir: plansBackendDir,
    dataSourceName: args.dataSourceName,
    moduleId: args.moduleId,
  });
  if (!policy.ok) {
    console.error(`[extract-code-schema] ${policy.reason}`);
    process.exit(1);
  }

  let channel;
  try {
    channel = resolveChannel(args);
  } catch (e) {
    console.error(`[extract-code-schema] ${e.message}`);
    process.exit(1);
  }

  // 通道已收敛为 mcp：resolver 只做契约条目 → MCP 请求上下文，不再按通道分叉。
  const strict = resolveIncrementalDatasource(backendDir, {
    dataSourceName: policy.dataSourceName || '',
    appId: args.appId,
  });
  if (!strict.ok) {
    const receipt = buildFailureReceipt({
      state: 'failed',
      stage: 'resolve-datasource',
      channel,
      binding: policy.dataSourceName
        ? { dataSourceName: policy.dataSourceName, entryRef: `datasources.json#${policy.dataSourceName}` }
        : null,
      error: strict.reason,
    });
    const file = writeFailureReceipt({ plansBackendDir, activeSpecDir, receipt });
    console.error(`[extract-code-schema] ${strict.reason}${file ? `（失败回执：${file}）` : ''}`);
    process.exit(1);
  }
  const ds = strict.ds;

  if (!ds.db) {
    console.error('[extract-code-schema] 未解析出目标库名（增量 micro 需已确认 database）');
    process.exit(1);
  }

  const databaseType = String(ds.databaseType || '').trim();
  const dialect = normalizeDialect(databaseType);
  const binding = {
    dataSourceName: String(policy.dataSourceName || ds.dataSourceName || '').trim(),
    entryRef: `datasources.json#${String(policy.dataSourceName || ds.dataSourceName || '').trim()}`,
  };
  if (!binding.dataSourceName) {
    const reason = '缺已确认 dataSourceName（绑定 envelope/显式参数），拒绝以默认实例采集';
    const file = writeFailureReceipt({
      plansBackendDir,
      activeSpecDir,
      receipt: buildFailureReceipt({ state: 'failed', stage: 'resolve-binding', channel, error: reason }),
    });
    console.error(`[extract-code-schema] ${reason}${file ? `（失败回执：${file}）` : ''}`);
    process.exit(1);
  }

  // 未支持方言显式拒绝：Oracle / PostgreSQL / unknown 一律不落 MySQL introspection。
  if (dialect !== 'mysql') {
    const reason =
      dialect === 'unknown'
        ? `未知/缺失方言（databaseType="${databaseType}"）：增量采集只实现 MySQL introspection，禁止猜 MySQL。`
        : `未支持方言 ${dialect}（databaseType="${databaseType}"）：Oracle/PostgreSQL 明确拒绝，不以 MySQL 形态代查；Oracle 验收属切片 2/3。`;
    const receipt = buildFailureReceipt({
      state: 'failed',
      stage: 'dialect-guard',
      channel,
      binding,
      target: { dialect, database: ds.db || null, owner: null },
      error: reason,
    });
    const file = writeFailureReceipt({ plansBackendDir, activeSpecDir, receipt });
    console.error(`[extract-code-schema] ${reason}${file ? `（失败回执：${file}）` : ''}`);
    process.exit(1);
  }

  const scope = buildScope(args);
  scope.database = ds.db;

  // D17：成功壳落点固定，据此读旧批次的 inputRevision（读不到从 1 开始）。
  const plansBackendDirForWrite =
    plansBackendDir || (activeSpecDir ? resolve(activeSpecDir, 'plans', 'backend') : null);
  const previousInputRevision = readPreviousInputRevision(plansBackendDirForWrite);

  const adapter = createMcpAdapter(ds);
  let collected;
  try {
    collected = await collectCodeSchemaV2({
      adapter,
      binding,
      databaseType,
      dialect,
      scope,
      pageSize: args.pageSize,
      previousInputRevision,
    });
  } catch (e) {
    const receipt = buildFailureReceipt({
      state: 'failed',
      stage: 'collect',
      channel,
      binding,
      target: { dialect, database: scope.database, owner: null },
      error: (e && e.message) || e,
    });
    const file = writeFailureReceipt({ plansBackendDir, activeSpecDir, receipt });
    console.error(`[extract-code-schema] 采集失败：${(e && e.message) || e}${file ? `（失败回执：${file}）` : ''}`);
    process.exit(1);
  }

  if (collected.status !== 'complete') {
    const receipt = buildFailureReceipt({
      state: 'partial',
      stage: 'collect',
      channel,
      binding,
      target: { dialect, database: scope.database, owner: null },
      error: '采集不完整，拒绝写成功壳/不把表标 rebuild',
      failures: collected.failures,
      schema: collected.schema,
    });
    const file = writeFailureReceipt({ plansBackendDir, activeSpecDir, receipt });
    console.error(
      `[extract-code-schema] 采集不完整（${collected.status}），不写 code-schema.json：${collected.failures.join('；')}` +
        `${file ? `（失败回执：${file}）` : ''}`,
    );
    process.exit(1);
  }

  // 成功壳落点同 D3：plansBackendDir 或 --active-spec-dir 派生；定位不到就失败，
  // 不在 `<backendDir>/../plans/backend` 造 stray 目录（plan §1.2 / §3 D3）。
  if (!plansBackendDirForWrite) {
    console.error('[extract-code-schema] 未定位 plans/backend 目录，拒绝在 <backend>/../plans/backend 创建 stray 目录');
    process.exit(1);
  }
  const metaDir = resolve(plansBackendDirForWrite, '_meta');
  mkdirSync(metaDir, { recursive: true });
  const outFile = resolve(metaDir, 'code-schema.json');
  // 写盘前引用唯一性校验（v3）：sourceId+owner+kind+name 重复即失败，不静默合并。
  assertUniqueObjectRefs(collected.schema);
  writeFileSync(outFile, JSON.stringify(collected.schema, null, 2) + '\n', 'utf-8');
  // 成功后清掉旧失败回执：否则上一轮 partial/failed 的回执会与成功壳并存，下游误判。
  rmSync(resolve(metaDir, 'code-schema.failure.json'), { force: true });
  const source = collected.schema.sources[0];
  console.log(
    JSON.stringify({
      ok: true,
      file: outFile,
      schemaVersion: CODE_SCHEMA_SCHEMA_VERSION,
      sourceId: source.sourceId,
      sources: 1,
      objects: source.objects.length,
      dialect,
      channel,
      completeness: source.completeness.status,
    }),
  );
}

// 仅当作为主入口直接执行时才跑 main（被 rebuild/checker import 时不自动执行）。
import { fileURLToPath } from 'url';
const _isMainEntry = process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]);
if (_isMainEntry) {
  main().catch((e) => {
    console.error(`[extract-code-schema] 异常：${e && e.stack ? e.stack : e}`);
    process.exit(1);
  });
}
