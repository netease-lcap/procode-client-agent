#!/usr/bin/env node

/**
 * check-seed-tables.mjs — 种子表清单 seed-tables.json 机械校验（build 波前置种子表识别任务 checker 脚本）。
 *
 * 分工（对齐 inventory-baseline 哲学：扫描者=LLM，校验者=零栈知识脚本）：
 *   LLM 在识别阶段判定「哪些表是种子表」并写清单；本脚本只做机械可验断言——
 *   1. 信封：JSON 可解析、必填字段、tables 数组每项 {table,reason} 非空、table 合法标识符、表名大小写折叠唯一；
 *   2. 集合门：tables[].table ⊆ 已知表集
 *      （known = entity-*.md ```sql 块的 CREATE/ALTER 表名 ∪ code-schema.json tables 键 ∪ delta*.sql 序号族表名，
 *        后两者仅文件存在时并入）——清单出现未知表名 = 幻觉表 = 红。
 * 不校验"归类判得对不对"（语义判定无机械判据，人审兜底，见 plan 2026-09-01/seed-tables-identify-stage-and-sql-archive-routing D7）。
 *
 * 用法：
 *   node check-seed-tables.mjs --manifest <abs seed-tables.json> --entity-dir <abs plans/backend>
 *     [--code-schema <abs code-schema.json>] [--delta-sql <abs path>]（显式传值按原样读取，缺文件软跳过）
 *   未显式传 --code-schema/--delta-sql 时按约定软探测：
 *     <entity-dir>/_meta/code-schema.json、<entity-dir>/migration/ 下 delta.sql 与 delta-NN.sql 序号族
 *     （单语句门禁配套拆分，每文件恰一条；增量轮产物，fresh 无 → 跳过）。
 *
 * stdout 单行 JSON { ok, failures[] }；exit 0 = 全绿，1 = 有红。
 * 失败消息三要素（违例定位 + 期望 + 通过示例）——防 checker 死循环规范，见 memory todowrite-completion-gate-regression。
 */

import { readFileSync, readdirSync, existsSync } from 'fs';
import { dirname, join } from 'path';

// ── 参数 ─────────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = { manifest: null, entityDir: null, codeSchema: null, deltaSql: null };
  for (let i = 0; i < argv.length; i++) {
    switch (argv[i]) {
      case '--manifest': args.manifest = argv[++i]; break;
      case '--entity-dir': args.entityDir = argv[++i]; break;
      case '--code-schema': args.codeSchema = argv[++i]; break;
      case '--delta-sql': args.deltaSql = argv[++i]; break;
      default: break;
    }
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));
if (!args.manifest || !args.entityDir) {
  console.log(JSON.stringify({ ok: false, failures: ['缺必填参数 --manifest <abs path> 与 --entity-dir <abs plans/backend>'] }));
  process.exit(1);
}

const failures = [];

// ── 1. 信封校验 ──────────────────────────────────────────────────────────────
const EXPECTED_SHAPE =
  '期望形状（通过示例；<表名>/<判定依据> 是形状占位，须换成设计产物的真实值）：{"schemaVersion":1,"generatedBy":"build/seed-tables","scenario":"fresh",' +
  '"tables":[{"table":"<表名>","reason":"<判定依据>"}]}；' +
  '可选字段仅 dataSourceName（字符串，多数据源轮标注归属，单源省略）。空清单合法：{"tables":[]}（全库确无种子表）。';

let raw;
try {
  raw = readFileSync(args.manifest, 'utf-8');
} catch (e) {
  console.log(JSON.stringify({ ok: false, failures: [
    `读不到清单文件：${args.manifest}（${e.message}）。本文件必须且仅由 plans/seed-inventory 识别阶段产出；禁止臆造路径，禁止由其他阶段手写。`,
  ] }));
  process.exit(1);
}

let doc;
try {
  doc = JSON.parse(raw);
} catch (e) {
  console.log(JSON.stringify({ ok: false, failures: [`清单不是合法 JSON：${args.manifest}（${e.message}）。${EXPECTED_SHAPE}`] }));
  process.exit(1);
}

if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
  console.log(JSON.stringify({ ok: false, failures: [`清单顶层必须是对象。${EXPECTED_SHAPE}`] }));
  process.exit(1);
}
if (doc.schemaVersion !== 1) {
  failures.push(`schemaVersion 必须为数字 1，实为 ${JSON.stringify(doc.schemaVersion)}。${EXPECTED_SHAPE}`);
}
if (typeof doc.generatedBy !== 'string' || !doc.generatedBy.trim()) {
  failures.push(`generatedBy 必须为非空字符串（如 "build/seed-tables"），实为 ${JSON.stringify(doc.generatedBy)}`);
}
if (!['fresh', 'incremental'].includes(doc.scenario)) {
  failures.push(`scenario 必须为 "fresh" 或 "incremental"（当轮真实场景），实为 ${JSON.stringify(doc.scenario)}`);
}
if (!Array.isArray(doc.tables)) {
  console.log(JSON.stringify({ ok: false, failures: [...failures, `tables 必须是数组（无种子表时为空数组），实为 ${JSON.stringify(doc.tables) && typeof doc.tables}。${EXPECTED_SHAPE}`] }));
  process.exit(1);
}

const TABLE_IDENT = /^[A-Za-z_][A-Za-z0-9_$]*$/;
const seenLower = new Map(); // duplicate key → 首次出现下标（有 dataSourceName 时按源隔离）
const claims = []; // { lower, dataSourceName, index } → 集合门比对
doc.tables.forEach((entry, i) => {
  const at = `tables[${i}]`;
  if (entry === null || typeof entry !== 'object' || Array.isArray(entry)) {
    failures.push(`${at} 必须是对象 {table, reason[, dataSourceName]}，实为 ${JSON.stringify(entry)}`);
    return;
  }
  const t = entry.table;
  if (typeof t !== 'string' || !t.trim()) {
    failures.push(`${at}.table 必须为非空字符串表名，实为 ${JSON.stringify(t)}`);
  } else if (!TABLE_IDENT.test(t)) {
    failures.push(`${at}.table="${t}" 非合法表名（仅字母/数字/下划线/$，不带库名前缀与反引号）。期望示例："<表名>"（取 entity DDL / code-schema 的实际表名，不照抄占位符）`);
  } else {
    const k = t.toLowerCase();
    const ds = typeof entry.dataSourceName === 'string' && entry.dataSourceName.trim()
      ? entry.dataSourceName.trim()
      : null;
    claims.push({ lower: k, dataSourceName: ds, index: i });
    // 有 dataSourceName 时 duplicate key 带源：同名表在不同库是两张表，不得按裸表名误判重复。
    const dupKey = ds ? `${ds.toLowerCase()}\u0000${k}` : k;
    if (seenLower.has(dupKey)) {
      failures.push(`${at}.table="${t}" 与 tables[${seenLower.get(dupKey)}] 重复（${ds ? `同一数据源 ${ds} 下` : '未写数据源时'}大小写折叠后同名）。一个表只登记一条。`);
    } else {
      seenLower.set(dupKey, i);
    }
  }
  if (typeof entry.reason !== 'string' || !entry.reason.trim()) {
    failures.push(`${at}.reason 必须为非空字符串（写明判定依据：表名/DDL 注释/spec 字典/checklist 哪个信号支持它是种子表），实为 ${JSON.stringify(entry.reason)}。期望示例："数据字典明细表，系统运行前必须预置（spec §4.1 字典）"`);
  }
  if (entry.dataSourceName !== undefined && (typeof entry.dataSourceName !== 'string' || !entry.dataSourceName.trim())) {
    failures.push(`${at}.dataSourceName 省略时不写；写了必须为非空字符串（micro 工程取 datasource-binding.json 绑定的 dataSourceName；单体工程取数据源契约条目的 dataSourceName），实为 ${JSON.stringify(entry.dataSourceName)}`);
  }
  const extraKeys = Object.keys(entry).filter((kk) => !['table', 'reason', 'dataSourceName'].includes(kk));
  if (extraKeys.length) {
    failures.push(`${at} 含未知字段 ${extraKeys.join(', ')}——只允许 table/reason/dataSourceName。${EXPECTED_SHAPE}`);
  }
});

// ── 2. 已知表集 ──────────────────────────────────────────────────────────────
// entity-*.md ```sql 块内 CREATE/ALTER 表名（正则口径对齐 check-incremental-schema.mjs retained 模式，扩展为 matchAll + ALTER）。
// knownByName: lower name → { sources:Set<dataSourceName>, labels:Set<来源说明> }
//   · sources 空 = 仅 entity/delta 声明（无数据源归属，允许）；
//   · sources 非空 = code-schema v2 的 sources[].objects[] 事实（按 source 计，不按裸名合并）。
const knownByName = new Map();
function addKnown(t, src, sourceName = null) {
  if (!t) return;
  const k = String(t).replace(/`/g, '').toLowerCase();
  if (!k) return;
  if (!knownByName.has(k)) knownByName.set(k, { sources: new Set(), labels: new Set() });
  const entry = knownByName.get(k);
  entry.labels.add(src);
  if (sourceName) entry.sources.add(sourceName);
}

let entityFiles = [];
try {
  entityFiles = readdirSync(args.entityDir).filter((f) => /^entity-.*\.md$/.test(f));
} catch (e) {
  failures.push(`无法读取 entity 目录：${args.entityDir}（canonical entity-*.md 应在此目录，设计阶段产物）：${e.message}`);
}
for (const f of entityFiles) {
  const md = readFileSync(join(args.entityDir, f), 'utf-8');
  const sqlBlocks = md.match(/```sql\s*\n[\s\S]*?```/g) || [];
  for (const block of sqlBlocks) {
    for (const m of block.matchAll(/(?:CREATE\s+TABLE|ALTER\s+TABLE)\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([A-Za-z_][A-Za-z0-9_$]*)`?/gi)) {
      addKnown(m[1], `entity/${f}`);
    }
  }
}

// code-schema.json：软探测 <entity-dir>/_meta/code-schema.json（增量轮必有，fresh 无 → 跳过）。
// v2 契约：sources[].objects[]；**版本守卫**（缺版本/v1/未知版本一律红，不回退顶层 tables）。
const codeSchemaPath = args.codeSchema || join(args.entityDir, '_meta', 'code-schema.json');
if (existsSync(codeSchemaPath)) {
  try {
    const cs = JSON.parse(readFileSync(codeSchemaPath, 'utf-8'));
    if (!cs || typeof cs !== 'object' || Array.isArray(cs)) {
      failures.push(`code-schema.json 顶层不是对象，无法并入已知表集：${codeSchemaPath}`);
    } else if (Object.prototype.hasOwnProperty.call(cs, 'tables')) {
      failures.push(
        `code-schema.json 是历史 v1 形状（顶层 tables 已退役），拒绝按 tables 猜 sources：${codeSchemaPath}。` +
          `修法=跑 extract-code-schema.mjs 重采 v2（sources[].objects[]），本 checker 不提供 v1 回退。`,
      );
    } else if (cs.schemaVersion === undefined || cs.schemaVersion === 1) {
      failures.push(
        `code-schema.json 缺 schemaVersion / schemaVersion=1（历史 v1 已退役），无法并入已知表集：${codeSchemaPath}。` +
          `修法=重采 v2（sources[].objects[]），不得自动升级或按裸表名猜。`,
      );
    } else if (cs.schemaVersion !== 2) {
      failures.push(
        `code-schema.json 未知版本 ${JSON.stringify(cs.schemaVersion)}（只接受 2），拒绝消费：${codeSchemaPath}。`,
      );
    } else if (!Array.isArray(cs.sources)) {
      failures.push(`code-schema.json v2 缺 sources 数组，无法并入已知表集：${codeSchemaPath}`);
    } else {
      for (const source of cs.sources) {
        if (!source || typeof source !== 'object') continue;
        const dataSourceName =
          source.binding && typeof source.binding.dataSourceName === 'string'
            ? source.binding.dataSourceName.trim()
            : '';
        if (!dataSourceName) {
          failures.push(
            `code-schema.json source ${JSON.stringify(source.sourceId)} 缺 binding.dataSourceName，` +
              `无法建立表→数据源归属（禁止按裸表名合并）：${codeSchemaPath}`,
          );
          continue;
        }
        const objects = Array.isArray(source.objects) ? source.objects : [];
        for (const object of objects) {
          if (!object || typeof object !== 'object' || object.kind !== 'table') continue;
          if (typeof object.name === 'string' && object.name) {
            addKnown(object.name, `code-schema/${dataSourceName}`, dataSourceName);
          }
        }
      }
    }
  } catch (e) {
    failures.push(`code-schema.json 不可解析（并入已知表集失败）：${codeSchemaPath}（${e.message}）`);
  }
}

// delta*.sql 序号族：软探测 <entity-dir>/migration/delta.sql 与 delta-NN.sql（增量轮 ALTER 集；
// 单语句门禁配套拆分，每文件一条；表名本在 code-schema 内，双保险并入）。
// 显式 --delta-sql（文档口径为绝对路径）按原样读取、保留 existsSync 软跳过——不得 join 进 migrationDir
// （path.join 不因绝对段重置，会拼出 <migrationDir>/abs/... 废路径，dual-review 0907 #2）。
{
  const migrationDir = join(args.entityDir, 'migration');
  const files = args.deltaSql
    ? (existsSync(args.deltaSql) ? [{ p: args.deltaSql, label: 'delta.sql(显式)' }] : [])
    : existsSync(migrationDir)
      ? readdirSync(migrationDir)
          .filter((f) => f === 'delta.sql' || /^delta-\d+\.sql$/.test(f))
          .sort()
          .map((f) => ({ p: join(migrationDir, f), label: f }))
      : [];
  for (const { p, label } of files) {
    const sql = readFileSync(p, 'utf-8');
    for (const m of sql.matchAll(/(?:CREATE\s+TABLE|ALTER\s+TABLE)\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([A-Za-z_][A-Za-z0-9_$]*)`?/gi)) {
      addKnown(m[1], label);
    }
  }
}

// 集合门：claims ⊆ known（v2 按 source 归属比对；同名跨源且未写 dataSourceName ⇒ 红，禁按裸表名合并）
const unknown = [];
for (const claim of claims) {
  const knownEntry = knownByName.get(claim.lower);
  if (!knownEntry) {
    unknown.push(claim.lower);
    continue;
  }
  const at = `tables[${claim.index}]`;
  const sourceList = [...knownEntry.sources].sort();
  if (!claim.dataSourceName) {
    if (sourceList.length > 1) {
      failures.push(
        `${at}.table="${claim.lower}" 同名表在多个数据源（${sourceList.join(', ')}）；` +
          `必须在 dataSourceName 写明归属，禁止按裸表名合并。` +
          `（来源=${[...knownEntry.labels].join(', ')}）`,
      );
    }
    continue;
  }
  if (sourceList.length > 0 && !knownEntry.sources.has(claim.dataSourceName)) {
    failures.push(
      `${at}.dataSourceName=${JSON.stringify(claim.dataSourceName)} 与 code-schema v2 中的归属不一致：` +
        `该表只出现在 ${sourceList.join(', ')}。禁按裸表名合并/臆造归属；` +
        `修法=按表实际所在 source 的 binding.dataSourceName 逐字填写。`,
    );
  }
}
if (unknown.length) {
  failures.push(
    `清单出现已知表集之外的表名（幻觉表/拼写错）：${[...new Set(unknown)].join(', ')}。` +
    `已知表集=entity-*.md 的 CREATE/ALTER 表名 ∪ code-schema v2 sources[].objects[].name ∪ delta.sql 表名` +
    `（本环境共 ${knownByName.size} 张，来源示例：${[...knownByName.entries()].slice(0, 5).map(([k, v]) => `${k}(${[...v.labels].join('|')})`).join(', ')} …）。` +
    `修法=删除或改正这些表名（表以设计/库为准，清单不得发明表），而不是往 entity/code-schema 里造表。`,
  );
}

// ── 3. dataSourceName 真值门（工程存在数据源绑定时）─────────────────────────
// micro 工程的绑定真值：`backend/_meta/datasource-binding.json` =
//   `{schemaVersion, bindings:[{moduleId, databaseType, dataSourceName, entryRef}]}`。
// 落点由 manifest 路径推出（同级 `_meta` 目录）：checker 调用约定只有 --manifest/--entity-dir，
// 不为新门加参数。文件不存在（单体工程 / 该步未产）⇒ 保持原行为，不校验 dataSourceName 取值；
// 文件存在 ⇒ 清单里写了该字段的值必须 ∈ 绑定声明的集合（防 `default-dev-1` 一类臆造值）。
{
  const bindingPath = join(dirname(args.manifest), 'datasource-binding.json');
  if (existsSync(bindingPath)) {
    let allowed = null; // null = 绑定不可用（已记红），不重复判成员
    let parsed;
    try {
      parsed = JSON.parse(readFileSync(bindingPath, 'utf-8'));
    } catch (e) {
      failures.push(
        `datasource-binding.json 存在但不可解析，无法校验 dataSourceName 归属：${bindingPath}（${e.message}）。` +
        `修法=修复该绑定产物（模块→数据源），不得删改种子表清单来绕过。`,
      );
    }
    if (parsed !== undefined) {
      const bindings =
        parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed.bindings : undefined;
      if (!Array.isArray(bindings)) {
        failures.push(
          `datasource-binding.json 在场但形状不合规（顶层须为对象且 bindings 为数组），无法校验 dataSourceName 归属：${bindingPath}。` +
          `修法=补齐绑定产物，不得删改种子表清单来绕过。`,
        );
      } else {
        allowed = new Set();
        for (const item of bindings) {
          const name = item && typeof item === 'object' ? item.dataSourceName : undefined;
          if (typeof name === 'string' && name.trim()) allowed.add(name.trim());
        }
      }
    }
    if (allowed) {
      const legal = [...allowed].sort();
      doc.tables.forEach((entry, i) => {
        if (entry === null || typeof entry !== 'object' || Array.isArray(entry)) return;
        const name = entry.dataSourceName;
        if (typeof name !== 'string' || !name.trim()) return; // 省略合法（单绑定/多绑定但模块判不出）
        if (!allowed.has(name.trim())) {
          failures.push(
            `tables[${i}].dataSourceName=${JSON.stringify(name)} 不在本工程数据源绑定的取值集合内（臆造值）。` +
            `合法取值：${legal.length ? JSON.stringify(legal) : '（绑定的 bindings[] 未声明任何 dataSourceName）'}；` +
            `来源=${bindingPath} 的 bindings[].dataSourceName。` +
            `修法=按该表所属模块逐字采用绑定里的 dataSourceName（禁按库名猜、禁写 default-dev-1 一类臆造值）。`,
          );
        }
      });
    }
  }
}

// ── 输出 ─────────────────────────────────────────────────────────────────────
const ok = failures.length === 0;
console.log(JSON.stringify({ ok, failures }));
process.exit(ok ? 0 : 1);
