import fs from 'fs';
import path from 'path';

import {
  PENDING,
  getActiveSpecDir,
  getTextInBetween,
  readFileSync,
  getRawSpecAbsoluteFilePath,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  parse,
  parseMenus,
  writeToFileSync,
  formatWritedFiles,
  auto,
} from './shared/index.mjs';

export const findRangesInSource =
  (rootDir) =>
  (keyword = '') => {
    const sourceAbsolutePath = getRawSpecAbsoluteFilePath(rootDir);
    const source = readFileSync(sourceAbsolutePath);
    const sourceRelativePath = sourceAbsolutePath.replace(`${rootDir}/`, '');

    const reduce = (result = [], next = {}) => {
      const rest = result.slice(0, -1);
      const last = result[result.length - 1];

      if (!last) {
        return [next];
      }

      const { range: lastRange = [] } = last;
      const { range: nextRange = [] } = next;

      if (lastRange[1] + 1 === nextRange[0]) {
        const range = [lastRange[0], nextRange[1]];

        return [...rest, { ...last, range }];
      }

      return [...result, next];
    };

    const placeholderForText = '当前关联段落完全通过关键字匹配，可能不符合关联主题，当不符合时，必须移除该关联段落';
    const placeholderForTitle =
      '当前关联段落是 **标题**，**必须读取标题附近的内容**，找到标题对应的描述内容，再判断是否符合关联主题';

    return source
      .split('\n')
      .map((content, index) => ({ content, index }))
      .filter((item) => item?.content?.includes(keyword))
      .map((item) => ({ ...item, range: [item.index, item.index] }))
      .reduce(reduce, [])
      .map((item) => ({ ...item, segment: `L${item.range[1]},${item.range[1]}` }))
      .map((item) => {
        const matched = /^\s*#/.test(item.content || '');
        const placeholder = matched ? placeholderForTitle : placeholderForText;

        return `  - **[${item.segment}](${sourceRelativePath}#${item.segment})**：[${placeholder}]`;
      });
  };

export const findMenus = (item) => item.endsWith('specs/menus.md');
export const findHidden = (item) => item.endsWith('pieces/hidden.md');
export const findQuotes = (item) => item.endsWith('pieces/quotes.md');
export const findContent = (item) => item.endsWith('pieces/content.md');
export const filterPoint = (item) => item.includes('pieces/point-');
export const filterDesign = (item) => item.includes('pieces/design-');
export const filterContent = (item) => item.includes('pieces/content-');
export const filterIgnored = (item) => item.includes('pieces/ignored-');
export const filterStandardDesign = (item) => item.includes('specs/design-');
export const filterStandardContent = (item) => item.includes('specs/content-');

export const itemToPart =
  (rootDir, getDescription) =>
  (item = '') => {
    const findRanges = findRangesInSource(rootDir);
    const descritpion = getDescription?.(item);

    const titles = item.split('-');
    const lastTitle = titles[titles.length - 1];

    const ranges = findRanges(lastTitle) || [];
    const factor = Math.ceil(ranges.length / 50);
    const filtered = ranges.length > 50 ? ranges.filter((a, i) => i % factor === 0) : ranges;
    const merged = [`- **${item}**：`, ...filtered, '  - [根据原始需求内容匹配补充关联段落]'];

    if (item === '整体业务') {
      merged.unshift(
        '<!-- 整体业务相关关联段落，不需要提取具体功能点的业务细节。 -->'
      );
    }

    if (item === '视觉规范、页面组件') {
      merged.unshift('<!-- **特别注意/Important**：视觉规范、页面组件 只允许匹配整体视觉规范、通用页面布局、通用页面结构、通用页面组件、通用交互样式、跨页面可复用的展示规范。同时，凡是原始需求、补充材料、页面规范中已经明确出现的主流设计稿地址（如 MasterGo、Figma 等），也必须提取到这里，并视为设计规范的一部分。禁止把某个底层功能节点、某个功能模块明细、某个单独业务页面的局部逻辑、某个业务流程步骤、某个具体功能操作说明、某个具体功能的（样式、布局、组件、展示、交互规范），当成 视觉规范、页面组件 的关联段落。禁止包含任何流程图、软件工程、系统架构 等相关内容。 -->');
    }

    if (descritpion) {
      merged.unshift(
        `<!-- ${item} 包含以下子功能：${descritpion}。必须重点找到每个子功能对应的关联段落，禁止遗漏任何子功能对应的关联段落。 -->`
      );
    }

    return merged.join('\n');
  };

export const itemToDesignPart =
  (rootDir, getDescription) =>
  (item = '') => {
    const findRanges = findRangesInSource(rootDir);
    const descritpion = getDescription?.(item);

    const merged = [
      descritpion ? `<!-- ${item} 包含以下子功能：${descritpion}。-->` : '',
      '<!-- 视觉规范、页面组件 禁止包含任何流程图、软件工程、系统架构 等相关内容。 -->',
      `- **${item}**：`,
      `  - [根据原始需求内容匹配补充 ${item} 关联段落]`,
    ];

    return merged.join('\n');
  };

export const tableToStore = (menus = []) => {
  const store = {
    整体需求: ['项目背景', '整体业务'],
    design: ['视觉规范、页面组件'],
  };

  menus?.forEach((item = {}) => {
    const label = item.combined;

    store[label] = store[label] || [];
    store[label].push(label);
  });

  menus?.forEach((item = {}) => {
    const label = item.combined;
    const key = `design-${label}`;

    store[key] = store[key] || [];
    store[key].push(`${label}-视觉规范页面组件`);
  });

  return store;
};

export const getDescriptionFromHidden = (rootDir) => {
  const { absoluteDir: hiddenAbsoluteDir, absoluteFilePath: hiddenAbsoluteFilePath } =
    findUnderSpecs(rootDir)(findHidden) || {};

  const store = {};
  const source = readFileSync(hiddenAbsoluteFilePath) || '';
  const matched = source.match(/\n\-[^\n]+/g) || [];

  matched.forEach((item = '') => {
    const getText = getTextInBetween(item);
    const got = getText('**', '**：') || getText('-', '：');
    const key = got.replace(/\s/g, '');
    const [, descritpion] = item.split('：');

    if (!key || !descritpion) {
      return;
    }

    store[key] = descritpion;
  });

  return (key = '') => {
    const [last = ''] = key.match(/(?<=\-)[^\-]+$/g) || [];
    const got = store[key] || store[last];

    if (got) {
      return got;
    }

    const find = (item) => item?.includes?.(key);
    const keys = Object.keys(store);
    const found = keys.find(find);

    return found?.descritpion;
  };
};

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  removeUnderSpecs(rootDir)(findQuotes);
  removeUnderSpecs(rootDir)(findContent);
  removeUnderSpecs(rootDir)(filterPoint);
  removeUnderSpecs(rootDir)(filterDesign);
  removeUnderSpecs(rootDir)(filterContent);
  removeUnderSpecs(rootDir)(filterIgnored);
  removeUnderSpecs(rootDir)(filterStandardDesign);
  removeUnderSpecs(rootDir)(filterStandardContent);

  const activeSpecDir = getActiveSpecDir(rootDir);
  const { absoluteFilePath: menusAbsoluteFilePath } = findUnderSpecs(rootDir)(findMenus) || {};
  const piecesAbsoluteDir = path.resolve(activeSpecDir, 'pieces');

  if (!menusAbsoluteFilePath) {
    throw new Error(`缺少功能模块目录：${activeSpecDir}/specs/menus.md`);
  }

  const parsedMenus = parseMenus(menusAbsoluteFilePath);
  const getDescription = getDescriptionFromHidden(rootDir);

  const store = tableToStore(parsedMenus?.menus);
  const toPart = itemToPart(rootDir, getDescription);
  const toDesignPart = itemToDesignPart(rootDir, getDescription);

  const writeFile = (key) => {
    const { [key]: value = [] } = store;

    const designable = key.includes('design-');
    const map = designable ? toDesignPart : toPart;

    const segments = ['# 关联主题'];
    const mapped = value.map(map);

    const name = `point-${key}.md`;
    const contentAbsolutePath = path.resolve(piecesAbsoluteDir, name);

    const suffix = name === 'point-design.md' ? '' : PENDING;

    return writeToFileSync(name, contentAbsolutePath)(segments, mapped, suffix);
  };

  const files = Object.keys(store).map(writeFile);

  return formatWritedFiles('需求要点文档列表')(files);
};

auto(import.meta, true)(toRaw);
export default toRaw;
