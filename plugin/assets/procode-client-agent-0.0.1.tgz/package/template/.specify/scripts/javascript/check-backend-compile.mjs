#!/usr/bin/env node

/**
 * 方案 C 段 B0｜后端编译 executor checker（跑 + 判绿 + emit 编译错行）。
 *
 * 砍掉归桶压缩层（parseDomainModuleMap/domainOf/compile-buckets.json）后，
 * 脚本只做三件事：
 *   1) 跑 `mvn test-compile`（只编译不跑测试，单次 ≈3s）；传 `--main-only` 时降为
 *      `mvn compile`（只编译主源码，连测试源码都不编译——git merge/commit 编译门专用：
 *      测试源码的编译问题不拦合并/推送；build workflow 段 B0 仍走默认 test-compile，
 *      那是段 B1 跑 `mvn test` 的前置分层）
 *   2) 判绿：全绿 exit 0；有 COMPILATION ERROR 或退出码非 0 → exit 1
 *   3) emit 编译错行清单（`[ERROR] /path/Xxx.java:[line,col] msg`）
 * 协调者读 emit 的 compileErrorLines（或协调者自己跑 `mvnd test-compile 2>&1 | tee .log`），
 * grep `^\[ERROR\]` 拿全部编译错——每行含 .java 路径 + 行号 + 消息，天然文本，无需归桶压缩。
 *
 * 两用：
 *   1) 段 B0 波诊断步骤：跑一次 → emit JSON（exit 1 不抛错，协调者读 compileErrorLines）。
 *   2) 段 B0 波 executor checker（createBackendCompileFinalChecker）：再跑一次 → 以退出码判编译全绿。
 *      即使修复 agent 谎报编译通过，脚本独立复跑即打回，由 runWithChecker 重跑整个波。
 *
 * 用法：node check-backend-compile.mjs [--main-only]
 *
 * 退出码约定（与 createCommandCheckerByExitCode 对齐）：
 *   有任何 COMPILATION ERROR / 退出码非 0 → exit 1；全绿 → exit 0。
 *   失败时 emit JSON 含：failures（汇总行）、compileErrorLines（[ERROR] .java 行，前 100 条）。
 */

import { existsSync, readdirSync, readFileSync } from 'fs';
import { resolve, dirname, sep } from 'path';
import { spawnSync, execSync } from 'child_process';
import { parsePomJavaMajor, parseJavaVersionOutput } from './shared/java-version.mjs';
import {
  findBackendDir,
  findPlanBackendDir,
  resolveDeclaredBackendRoots,
  resolveProjectRoot,
} from './shared/backend-common.mjs';

const cwd = process.cwd();

// ── 自动解析项目所需 JDK 的 JAVA_HOME ──────────────────────────────────
// 消除「agent 用 JDK21 修绿 → checker 用默认 JDK8 跑 mvn 报 UnsupportedClassVersionError」死锁。

function resolveJavaHome(backendDir) {
  let javaVersion = null;
  // 从 pom.xml <java.version> 读取（不再依赖 plans/tech-stack.json 路径解析）
  const pomPath = resolve(backendDir, 'pom.xml');
  if (existsSync(pomPath)) {
    try {
      const pom = readFileSync(pomPath, 'utf-8');
      // 归一在 shared/java-version.mjs 单点实现（1.8→8；旧 (\d+) 解析不到 "1.8" 致回退系统 JAVA_HOME）。
      javaVersion = parsePomJavaMajor(pom);
    } catch { /* ignore */ }
  }
  if (!javaVersion) return null;

  // 优先用环境变量（沙箱可能注入 JAVA_HOME / JAVA21_HOME / JAVA_21_HOME）
  const envCandidates = [
    process.env[`JAVA_${javaVersion}_HOME`],   // JAVA_21_HOME
    process.env[`JAVA${javaVersion}_HOME`],    // JAVA21_HOME（沙箱常见）
    process.env.JAVA_HOME,                      // 系统默认 JAVA_HOME（需验证版本匹配）
  ].filter(Boolean);
  for (const home of envCandidates) {
    if (!existsSync(resolve(home, 'bin', 'java'))) continue;
    try {
      const verOut = execSync(`"${resolve(home, 'bin', 'java')}" -version 2>&1`, {
        encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5000,
      });
      if (parseJavaVersionOutput(verOut) === javaVersion) return home;
    } catch { /* 跳过该候选 */ }
  }

  const jvmRoot = '/usr/lib/jvm';
  if (existsSync(jvmRoot)) {
    try {
      const dirs = readdirSync(jvmRoot);
      const found = dirs.find((n) => n.startsWith(`temurin-${javaVersion}`));
      if (found) return resolve(jvmRoot, found);
    } catch { /* ignore */ }
  }
  return null;
}

function emit(ok, payload) {
  console.log(JSON.stringify({ ok, ...payload }, null, 2));
  process.exit(ok ? 0 : 1);
}

/** 读 `--backend-root`（可重复）/ `--active-spec-dir`；未知/缺值忽略。 */
function collectRootArgs(argv) {
  const explicitRoots = [];
  let activeSpecDir;
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === '--backend-root') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) explicitRoots.push(resolve(value));
    } else if (argv[i] === '--active-spec-dir') {
      const value = argv[++i];
      if (value && !value.startsWith('--')) activeSpecDir = resolve(value);
    }
  }
  return { explicitRoots, activeSpecDir };
}

/** 单根直接采用；多根只认声明里本身是其余所有根祖先的聚合根，否则无法唯一确定（null）。 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/** 代码根定位（D5）：声明/显式根优先；findBackendDir 仅兜底并打 warning；歧义不猜。 */
function resolveBackendRoot() {
  const baseRoot = resolveProjectRoot(cwd) ?? cwd;
  const { explicitRoots, activeSpecDir } = collectRootArgs(process.argv.slice(2));
  // 未显式传 --active-spec-dir 时由最新 plans/backend 反推 active spec 目录，使工程方案声明生效。
  const planBackendDir = findPlanBackendDir(cwd);
  // planBackendDir = <activeSpecDir>/plans/backend ⇒ activeSpecDir 需再上溯一层（plans 的父目录）。
  const specDir = activeSpecDir ?? (planBackendDir ? dirname(dirname(planBackendDir)) : undefined);
  const declared = resolveDeclaredBackendRoots({ activeSpecDir: specDir, rootDir: baseRoot, explicitRoots });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[check-backend-compile] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[check-backend-compile] 代码根存在多个且无声明聚合根，无法唯一确定：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root，或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[check-backend-compile] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(cwd);
  if (legacy) console.warn(`[check-backend-compile] 未找到代码根声明，回落启发式 findBackendDir：${legacy}`);
  return legacy;
}

// 1. 定位 backend 工程目录（声明根优先，findBackendDir 仅兜底）
const backendDir = resolveBackendRoot();

if (!backendDir) {
  emit(false, { failures: ['未找到后端工程（pom.xml / build.gradle）'] });
}
const javaHome = resolveJavaHome(backendDir);

// 2. 只编译不跑测试（不加 -o 以免离线仓未预热失败）。
// --main-only：只编译主源码（mvn compile / gradle classes），测试源码不参与——
// 旧调用方不传该参数 → 行为不变（默认仍 test-compile，含测试源码编译）。
const mainOnly = process.argv.includes('--main-only');
const isMaven = existsSync(resolve(backendDir, 'pom.xml'));
let cmd;
let args;
if (isMaven) {
  cmd = existsSync(resolve(backendDir, 'mvnw')) ? resolve(backendDir, 'mvnw')
    : (() => { try { execSync('which mvnd', { stdio: 'ignore' }); return 'mvnd'; } catch { return 'mvn'; } })();
  args = ['-q', '-B', mainOnly ? 'compile' : 'test-compile'];
} else {
  cmd = existsSync(resolve(backendDir, 'gradlew')) ? resolve(backendDir, 'gradlew') : 'gradle';
  args = [mainOnly ? 'classes' : 'testClasses', '--console=plain'];
}

let run = spawnSync(cmd, args, {
  cwd: backendDir,
  encoding: 'utf-8',
  maxBuffer: 64 * 1024 * 1024,
  env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
});

// ── mvnd 崩溃退化到 mvn ──────────────────────────────────────────
// mvnd 因 /root/.m2/mvnd/registry 只读 mount 启动即崩（DaemonException: Read-only file system），
// 从未真正编译；崩溃输出非 [ERROR] .java 格式，会误判为「0 行编译错+退出码非0=环境/依赖错误」。
// 识别到 mvnd 崩溃签名时重跑一次标准 mvn，覆盖假信号。resolveJavaHome 已注入正确 JDK。
const _firstOut = `${run.stdout || ''}\n${run.stderr || ''}`;
if (cmd === 'mvnd' && run.status !== 0
    && /Read-only file system|DaemonException/.test(_firstOut)) {
  run = spawnSync('mvn', args, {
    cwd: backendDir, encoding: 'utf-8', maxBuffer: 64 * 1024 * 1024,
    env: { ...process.env, ...(javaHome ? { JAVA_HOME: javaHome } : {}), MAVEN_OPTS: process.env.MAVEN_OPTS || '' },
  });
}

if (run.error) {
  emit(false, { failures: [`无法执行编译命令 ${cmd} ${args.join(' ')}：${run.error.message}`] });
}

const stdout = run.stdout || '';
const stderr = run.stderr || '';
const combined = `${stdout}\n${stderr}`;

// 3. 抽取编译报错行：[ERROR] .../src/main/java/<根包>/<域>/.../Xxx.java:[line,col] message
const errorLines = combined.match(/\[ERROR\][^\n]*\.java[^\n]*/g) || [];
const hasCompilationError = /COMPILATION ERROR/i.test(combined) || run.status !== 0;

// 4. emit：全绿 exit 0，否则 exit 1 + 编译错行清单
if (hasCompilationError) {
  const failures = [
    `存在编译错误：${errorLines.length} 行 [ERROR]` +
      (run.status !== 0 && errorLines.length === 0 ? `（mvn/gradle 退出码 ${run.status}，无 [ERROR] .java 行——可能是环境/依赖错误，见 stderr）` : ''),
  ];
  emit(false, {
    failures,
    compileErrorLines: errorLines.slice(0, 100),
    errorLineCount: errorLines.length,
  });
}

emit(true, { summary: '编译全绿（无 COMPILATION ERROR）' });
