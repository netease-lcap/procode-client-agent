#!/usr/bin/env node

/**
 * 1-1.1 增量设计 · 单实体自检 checker
 *
 * 根（见 docs/hicode-spec/plan/2026-08-20/split-incremental-entity-checker-from-greenfield-data-model.md）：
 *   增量场景的 entity-*.md 自检不再共用 greenfield data-model——存量表（如 sys_user）会被
 *   #8 保留字（password 是 RuoYi/Spring Security 硬依赖列不可改名）/ #9 id 强制倒逼改名进死循环。
 *   本脚本 import check-backend-design.mjs 的结构 helper（#1-#7），按存量/新建分类：
 *     存量表（∈ code-schema.tables）→ 跑结构 #1-#7 + 豁免 #8/#9（照搬不改名/不改主键）
 *                              + 基线对照（entity 列集 ⊇ code-schema 列集，防漏保）
 *                              + 新增列可空（存量表新增列 ddl 不得含 NOT NULL，历史行不违约）；
 *     新建表（∉ code-schema.tables）→ 跑结构 #1-#7 + #8 + #9（greenfield 全套，与 fresh 一致）。
 *
 * 用法：
 *   node check-incremental-entity.mjs <entity-*.md 绝对路径> --code-schema <code-schema.json 绝对路径>
 *   node check-incremental-entity.mjs --self-test
 *
 * stdout JSON { ok, failures[] }，契约 mimic check-backend-design.mjs。
 * 不重复 diff backstop 的职责：diff 仍做库 vs 设计字段级差集（dropCol/modifyCol + needsHumanReview）；
 * 本 checker 只验 entity 文档侧「存量列没被漏保/改名」+ 结构合规 + 新增列可空，两层互补。
 */

import { readFileSync, existsSync, readdirSync } from 'fs';
import { resolve, dirname } from 'path';
import { createHash } from 'crypto';
import {
  checkEntityStructure,
  checkReservedIdentifiers,
  checkIdMandate,
  resolveDialectFromEntityPath,
} from './check-backend-design.mjs';
import { splitSqlStatements, stableJson, SOURCE_ID_RE } from './extract-code-schema.mjs';
import {
  isSchemaObjectRef,
  isTableRef,
  refKeyOf,
  refEquals,
  formatRef,
  toTableRef,
} from './lib/entity-pk-resolver.mjs';
import {
  extractCreateTableSegments,
  parseTableRefsMetadata,
  splitQualifiedTableName,
} from './shared/cross-domain-decl.mjs';

// v3 版本常量（放在 --self-test 之前：顶层 self-test 先于下方函数/常量执行，避免 TDZ）。
const CODE_SCHEMA_VERSION = 3;

// 门 D 常量（顶层 gate-d 分发会调用 runGateD，必须早于分发完成初始化）。
// Delta v3：operations/audit 均为 schemaVersion 3；v2 及更旧产物不投影，必须重迁移/重跑。
const GATE_D_SCHEMA_VERSION = 3;
const GATE_D_AUDIT_SCHEMA_VERSION = 3;
const GATE_D_BASELINE_REF_PATH = 'backend/_meta/code-schema.json';
const GATE_D_GAP_CLASSES = new Set(['G0', 'G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8', 'G9']);
const GATE_D_CLASSIFICATIONS = new Set(['operation', 'unsupported', 'skip']);
const GATE_D_KINDS = new Set([
  'add-column',
  'add-index',
  'add-unique',
  'create-table',
  'create-index',
  'add-comment',
]);
const GATE_D_PHASES_BY_KIND = {
  'add-column': ['existing-delta'],
  'add-index': ['existing-delta'],
  'add-unique': ['existing-delta'],
  'create-table': ['new-table'],
  'create-index': ['new-table'],
  'add-comment': ['existing-delta', 'new-table'],
};
const GATE_D_UNSUPPORTED_KINDS = new Set([
  'drop-column',
  'modify-column',
  'add-primary-key',
  'unparseable-alter',
  'unparseable',
]);
const GATE_D_UNSUPPORTED_STATES = new Set([
  'pending',
  'accepted-manual',
  'design-applied',
  'withdrawn',
]);
const GATE_D_SKIP_REASONS = new Set([
  'baseline-only',
  'no-operation-sql-produced',
  'retained-unchanged',
]);
// 结构异常回 producer（D11：Agent D 已退役，Gate D 是终态）。
const GATE_D_PRODUCER_TABLE = 'single-table-agent';
const GATE_D_PRODUCER_MERGE = 'merge-layer';
const GATE_D_PRODUCER_AUDIT = 'audit-agent';
// 表名解析（CREATE TABLE ... 支持引号/owner）。必须在 gate-d 顶层分发之前初始化。
const GATE_D_IDENTIFIER_PART = '`(?:[^`]|``)+`|"(?:[^"]|"")*"|\\[[^\\]]+\\]|[A-Za-z0-9_$#]+';
const GATE_D_CREATE_TABLE_RE = new RegExp(
  `^\\s*CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?((?:${GATE_D_IDENTIFIER_PART})(?:\\s*\\.\\s*(?:${GATE_D_IDENTIFIER_PART}))*)`,
  'i',
);

const args = process.argv.slice(2);

// ── self-test ──────────────────────────────────────────────────────────────
if (args[0] === '--self-test') {
  const failures = selfTest();
  if (failures.length) {
    console.error('✗ check-incremental-entity self-test 失败:\n' + failures.join('\n'));
    process.exit(1);
  }
  console.log('✓ check-incremental-entity self-test PASS');
  process.exit(0);
}

// ── gate-d：独立 CLI（门 D；结构化 JSON + 失败 exit 1）────────────────────────
if (args[0] === 'gate-d') {
  const result = runGateD(parseGateDArgs(args));
  // 单行 JSON：编排侧 parseTrailingJson 取末行解析（gate 失败仍要可读可回灌）。
  console.log(JSON.stringify(result));
  process.exit(result.ok ? 0 : 1);
}

const entityPath = args[0];
const csIdx = args.indexOf('--code-schema');
const codeSchemaPath = csIdx >= 0 ? args[csIdx + 1] : null;

if (!entityPath || !codeSchemaPath) {
  console.error('Usage: node check-incremental-entity.mjs <entity-*.md> --code-schema <code-schema.json>');
  process.exit(1);
}

let content;
try {
  content = readFileSync(entityPath, 'utf-8');
} catch (e) {
  console.log(JSON.stringify({ ok: false, failures: [`无法读取 entity 文件: ${entityPath}`] }));
  process.exit(0);
}

let codeSchema;
try {
  codeSchema = JSON.parse(readFileSync(codeSchemaPath, 'utf-8'));
} catch (e) {
  // code-schema 不可读：增量链必须有 code-schema 才能分类；报失败 + 仍跑结构检查兜底
  const failures = [`无法读取/解析 code-schema.json: ${codeSchemaPath}（${e.message}）`, ...checkEntityStructure(content).failures];
  console.log(JSON.stringify({ ok: false, failures }));
  process.exit(0);
}

console.log(JSON.stringify(checkIncrementalEntity(content, codeSchema, entityPath), null, 2));

// ── 门 D v2：audit ↔ operations 对账 / 结构异常路由 ────────────────────────────
// 独立 CLI：node check-incremental-entity.mjs gate-d --code-schema <...> --migration-dir <...>
//   [--audit <delta-audit.json>] [--inventory <code-table-inventory.json>] [--scope gate|agent]
// 结构化 JSON；任一失败 exit 1。`--scope` 仅为兼容旧编排保留，Gate D 是终态：
// 不再有 Agent D，也不再按 scope 过滤失败。
// （常量定义在文件头部，避免 gate-d 顶层分发早于 const 初始化触发 TDZ。）

function parseGateDArgs(argv) {
  const get = (flag) => {
    const index = argv.indexOf(flag);
    return index >= 0 ? argv[index + 1] : null;
  };
  const migrationDir = get('--migration-dir');
  const entityDir = get('--entity-dir') || (migrationDir ? dirname(resolve(migrationDir)) : null);
  return {
    codeSchema: get('--code-schema') || (entityDir ? resolve(entityDir, '_meta', 'code-schema.json') : null),
    migrationDir: migrationDir ? resolve(migrationDir) : null,
    audit: get('--audit') || (migrationDir ? resolve(migrationDir, 'delta-audit.json') : null),
    inventory: get('--inventory') || (entityDir ? resolve(entityDir, '_meta', 'code-table-inventory.json') : null),
    scope: get('--scope') === 'agent' ? 'agent' : 'gate',
  };
}

function gateReadJson(filePath, add, code) {
  if (!filePath || !existsSync(filePath)) {
    add(code || 'GATE_D_MISSING_ARTIFACT', `产物不存在：${filePath || '<未指定>'}`);
    return null;
  }
  try {
    return JSON.parse(readFileSync(filePath, 'utf-8'));
  } catch (error) {
    add('GATE_D_MISSING_ARTIFACT', `产物不可解析：${filePath}（${error.message}）`);
    return null;
  }
}

function gateSha256(text) {
  return 'sha256:' + createHash('sha256').update(Buffer.from(String(text), 'utf8')).digest('hex');
}

/** 去掉 SQL 字符串字面量与注释后做禁用词检查（避免注释里的 DROP 误报）。 */
function gateStripLiteralsAndComments(sql) {
  let out = '';
  let i = 0;
  const text = String(sql || '');
  while (i < text.length) {
    const ch = text[i];
    if (ch === '-' && text[i + 1] === '-') {
      while (i < text.length && text[i] !== '\n') i++;
      continue;
    }
    if (ch === '/' && text[i + 1] === '*') {
      i += 2;
      while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++;
      i += 2;
      continue;
    }
    if (ch === "'" || ch === '"') {
      const quote = ch;
      i++;
      while (i < text.length) {
        if (text[i] === quote) {
          if (text[i + 1] === quote) {
            i += 2;
            continue;
          }
          i++;
          break;
        }
        if (text[i] === '\\') i += 2;
        else i++;
      }
      out += ' ';
      continue;
    }
    out += ch;
    i++;
  }
  return out;
}

/** 只去注释、保留引号标识符原样（用于解析带引号/owner 的表名）。 */
function gateStripComments(sql) {
  let out = '';
  let i = 0;
  const text = String(sql || '');
  while (i < text.length) {
    const ch = text[i];
    if (ch === '-' && text[i + 1] === '-') {
      while (i < text.length && text[i] !== '\n') i++;
      continue;
    }
    if (ch === '#') {
      while (i < text.length && text[i] !== '\n') i++;
      continue;
    }
    if (ch === '/' && text[i + 1] === '*') {
      i += 2;
      while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++;
      i += 2;
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') {
      const quote = ch;
      out += ch;
      i++;
      while (i < text.length) {
        out += text[i];
        if (text[i] === quote) {
          if (text[i + 1] === quote) {
            out += text[i + 1];
            i += 2;
            continue;
          }
          i++;
          break;
        }
        if (text[i] === '\\' && quote !== '`') {
          i++;
          if (i < text.length) out += text[i];
        }
        i++;
      }
      continue;
    }
    out += ch;
    i++;
  }
  return out;
}

/** 解析 CREATE TABLE 目标表名；支持 `` `db`.`t` `` / `"schema"."t"` / `[dbo].[t]`，返回末段裸名。 */
function gateCreateTableName(sql) {
  const match = String(sql || '').match(GATE_D_CREATE_TABLE_RE);
  if (!match) return null;
  const text = match[1];
  const segments = [];
  let i = 0;
  while (i < text.length) {
    while (i < text.length && /\s/.test(text[i])) i++;
    if (i >= text.length) break;
    const ch = text[i];
    let segment = '';
    if (ch === '`' || ch === '"') {
      const quote = ch;
      i++;
      while (i < text.length) {
        if (text[i] === quote) {
          if (text[i + 1] === quote) {
            segment += quote;
            i += 2;
            continue;
          }
          i++;
          break;
        }
        segment += text[i];
        i++;
      }
    } else if (ch === '[') {
      const close = text.indexOf(']', i + 1);
      if (close < 0) break;
      segment = text.slice(i + 1, close);
      i = close + 1;
    } else {
      const m = text.slice(i).match(/^[A-Za-z0-9_$#]+/);
      if (!m) break;
      segment = m[0];
      i += segment.length;
    }
    segments.push(segment);
    while (i < text.length && /\s/.test(text[i])) i++;
    if (text[i] === '.') i++;
    else break;
  }
  return segments.length > 0 ? segments[segments.length - 1] : null;
}

/** SQL 目标表 → {owner,name}（按 SQL 语法解析；owner 缺省 null）。 */
function gateSqlTargetParts(sql) {
  const match = String(sql || '').match(GATE_D_CREATE_TABLE_RE);
  return match ? splitQualifiedTableName(match[1]) : null;
}

/** 引用是否描述该 SQL 目标：name 逐字精确；DDL 指明 owner 时 owner 也必须逐字精确。 */
function gateRefMatchesSqlTarget(tableRef, target) {
  if (!isTableRef(tableRef) || !target || !target.name) return false;
  if (tableRef.name !== target.name) return false;
  if (target.owner !== null && target.owner !== undefined && tableRef.owner !== target.owner) return false;
  return true;
}

/** v3 actionId：`sql3:<phase>:<encodeURIComponent(refKeyOf(tableRef))>:<kind>:<ordinal>`。 */
function gateParseActionIdV3(actionId) {
  const parts = String(actionId || '').split(':');
  if (parts.length !== 5 || parts[0] !== 'sql3') return null;
  let refKey;
  try {
    refKey = decodeURIComponent(parts[2]);
  } catch {
    return null;
  }
  if (!parts[1] || !parts[3] || !parts[4]) return null;
  return { phase: parts[1], refKey, kind: parts[3], ordinal: parts[4] };
}

/** v3 unsupportedKey：`unsupported3:<encodeURIComponent(refKeyOf(tableRef))>:<target>:<changeKind>`。 */
function gateBuildUnsupportedKeyV3(entry) {
  if (!entry || typeof entry !== 'object' || !isTableRef(entry.tableRef)) return null;
  const changeKind = typeof entry.changeKind === 'string' ? entry.changeKind : '';
  if (!changeKind) return null;
  const target =
    typeof entry.target === 'string' ? entry.target : typeof entry.column === 'string' ? entry.column : '';
  return `unsupported3:${encodeURIComponent(refKeyOf(entry.tableRef))}:${encodeURIComponent(target)}:${changeKind}`;
}

function gateSafeSqlPath(sqlPath, sourceId) {
  if (typeof sqlPath !== 'string' || !sqlPath) return '路径为空';
  if (sqlPath.includes('\\') || sqlPath.startsWith('/')) return '路径必须是相对 POSIX 路径';
  const parts = sqlPath.split('/');
  if (parts.includes('..') || parts.includes('.')) return '路径含 . / .. 段';
  if (!/^[A-Za-z0-9._/-]+$/.test(sqlPath)) return '路径含非法字符';
  if (!sqlPath.startsWith(sourceId + '/')) return `路径不以 <sourceId>/ 开头（期望 ${sourceId}/）`;
  return null;
}

function runGateD(options) {
  const failures = [];
  const add = (code, message, extra = {}) => failures.push({ code, message, ...extra });
  const addProducer = (producer, code, message, extra = {}) =>
    add(code, `[producer=${producer}] ${message}`, { producer, ...extra });
  const nonEmpty = (value) => typeof value === 'string' && value.trim().length > 0;

  if (!options.migrationDir) {
    return {
      ok: false,
      mode: 'gate-d',
      scope: options.scope,
      failures: [{ code: 'GATE_D_MISSING_ARTIFACT', message: '缺 --migration-dir' }],
    };
  }
  const operationsPath = resolve(options.migrationDir, 'operations.json');
  const schema = gateReadJson(options.codeSchema, add, 'GATE_D_MISSING_ARTIFACT');
  const operationsDoc = gateReadJson(operationsPath, add, 'GATE_D_MISSING_ARTIFACT');
  const auditDoc = gateReadJson(options.audit, add, 'GATE_D_MISSING_ARTIFACT');
  const inventory = gateReadJson(options.inventory, add, 'GATE_D_MISSING_ARTIFACT');

  const schemaSources = schema && Array.isArray(schema.sources) ? schema.sources : [];
  const expectedSourceIds = [
    ...new Set(schemaSources.map((source) => source && source.sourceId).filter(Boolean)),
  ].sort();
  const sourceDialectById = new Map(
    schemaSources
      .filter(Boolean)
      .map((source) => [source.sourceId, String(source.dialect || source.databaseType || 'unknown')]),
  );
  // 基线引用索引（v3）：refKey → ref；按精确名 + source 的唯一命中用于 inventory 等旧输入收敛。
  const baselineRefKeys = new Set();
  const baselineRefByKey = new Map();
  const baselineRefsByName = new Map();
  for (const source of schemaSources) {
    if (!source || !Array.isArray(source.objects)) continue;
    for (const object of source.objects) {
      if (!object || typeof object.name !== 'string' || !object.name) continue;
      const ref = {
        sourceId: source.sourceId,
        owner: object.owner === undefined ? null : object.owner,
        kind: object.kind === undefined ? 'table' : object.kind,
        name: object.name,
      };
      if (!isSchemaObjectRef(ref)) {
        add('GATE_D_SCHEMA', `code-schema 对象 ${source.sourceId}/${object.name} 不是合法 v3 引用`);
        continue;
      }
      const key = refKeyOf(ref);
      if (baselineRefKeys.has(key)) {
        add('GATE_D_SCHEMA', `code-schema 引用重复：${formatRef(ref)}`);
        continue;
      }
      baselineRefKeys.add(key);
      baselineRefByKey.set(key, ref);
      const nameKey = `${source.sourceId}\u0000${object.name}`;
      if (!baselineRefsByName.has(nameKey)) baselineRefsByName.set(nameKey, []);
      baselineRefsByName.get(nameKey).push(ref);
    }
  }

  /** 旧输入（inventory）名称 → v3 引用：显式 sourceId+精确名唯一；无 sourceId 时全基线唯一精确名。 */
  const resolveInventoryRef = (entry) => {
    if (isTableRef(entry.tableRef)) return { ref: entry.tableRef };
    if (typeof entry.table !== 'string' || !entry.table) return { missing: true };
    if (entry.sourceId) {
      const hits = (baselineRefsByName.get(`${entry.sourceId}\u0000${entry.table}`) || []).filter(
        (ref) => entry.owner === undefined || ref.owner === entry.owner,
      );
      if (hits.length === 1) return { ref: hits[0] };
      if (hits.length === 0) return { missing: true };
      return { failure: `inventory ${entry.sourceId}/${entry.table} 命中多个引用，请写 tableRef 显式消歧` };
    }
    const hits = [...baselineRefsByName.values()].flat().filter((ref) => ref.name === entry.table);
    if (hits.length === 1) return { ref: hits[0] };
    if (hits.length === 0) return { missing: true };
    return {
      failure:
        `inventory 表「${entry.table}」在基线中命中 ${hits.length} 个同名引用（${hits.map(formatRef).join(' / ')}）：` +
        '禁按裸表名跨源合并，请写 tableRef 或 sourceId。',
    };
  };

  const checkBaselineRef = (doc, label) => {
    if (!doc.baselineRef || typeof doc.baselineRef !== 'object' || Array.isArray(doc.baselineRef)) {
      add('GATE_D_SCHEMA', `${label}.baselineRef 缺失`);
      return;
    }
    if (doc.baselineRef.path !== GATE_D_BASELINE_REF_PATH) {
      add(
        'GATE_D_BASELINE_REF_MISMATCH',
        `${label}.baselineRef.path 必须为 ${GATE_D_BASELINE_REF_PATH}，得 ${JSON.stringify(doc.baselineRef.path)}`,
      );
    }
    if (doc.baselineRef.schemaVersion !== CODE_SCHEMA_VERSION) {
      add(
        'GATE_D_BASELINE_REF_MISMATCH',
        `${label}.baselineRef.schemaVersion 必须为 ${CODE_SCHEMA_VERSION}，得 ${JSON.stringify(doc.baselineRef.schemaVersion)}`,
      );
    }
    const declared = Array.isArray(doc.baselineRef.sourceIds) ? [...doc.baselineRef.sourceIds].sort() : null;
    if (!declared || stableJson(declared) !== stableJson(expectedSourceIds)) {
      add(
        'GATE_D_BASELINE_REF_MISMATCH',
        `${label}.baselineRef.sourceIds 与 code-schema 不一致：declared=${JSON.stringify(declared)} expected=${JSON.stringify(expectedSourceIds)}`,
      );
    }
  };

  if (operationsDoc) {
    if (operationsDoc.schemaVersion !== GATE_D_SCHEMA_VERSION) {
      add(
        'GATE_D_SCHEMA',
        `operations.schemaVersion 必须为 ${GATE_D_SCHEMA_VERSION}（v1 不投影，需重跑机械合并），得 ${JSON.stringify(operationsDoc.schemaVersion)}`,
      );
    }
    if (operationsDoc.scenario !== 'incremental') {
      add('GATE_D_SCHEMA', `operations.scenario 必须为 incremental，得 ${JSON.stringify(operationsDoc.scenario)}`);
    }
    if (!nonEmpty(operationsDoc.iterationId)) add('GATE_D_SCHEMA', 'operations.iterationId 缺失');
    if (!nonEmpty(operationsDoc.inputRevision)) {
      add('GATE_D_SCHEMA', 'operations.inputRevision 缺失（基线采集批次）');
    }
    checkBaselineRef(operationsDoc, 'operations');
  }
  if (auditDoc) {
    if (auditDoc.schemaVersion !== GATE_D_AUDIT_SCHEMA_VERSION) {
      add(
        'GATE_D_SCHEMA',
        `delta-audit.schemaVersion 必须为 ${GATE_D_AUDIT_SCHEMA_VERSION}（v1 不投影，必须重跑 audit agent），得 ${JSON.stringify(auditDoc.schemaVersion)}`,
      );
    }
    if (!nonEmpty(auditDoc.iterationId)) add('GATE_D_SCHEMA', 'delta-audit.iterationId 缺失');
    if (!nonEmpty(auditDoc.inputRevision)) add('GATE_D_SCHEMA', 'delta-audit.inputRevision 缺失');
    if (operationsDoc) {
      if (auditDoc.iterationId !== operationsDoc.iterationId) {
        add(
          'GATE_D_ITERATION_MISMATCH',
          `delta-audit.iterationId 与 operations.iterationId 不一致：${JSON.stringify(auditDoc.iterationId)} vs ${JSON.stringify(operationsDoc.iterationId)}`,
        );
      }
      if (auditDoc.inputRevision !== operationsDoc.inputRevision) {
        add(
          'GATE_D_INPUT_REVISION_MISMATCH',
          `delta-audit.inputRevision 与 operations.inputRevision 不一致：${JSON.stringify(auditDoc.inputRevision)} vs ${JSON.stringify(operationsDoc.inputRevision)}；上游输入变化须重跑 merge/audit`,
        );
      }
    }
    checkBaselineRef(auditDoc, 'delta-audit');
    const unsupportedDialects = Array.isArray(auditDoc.unsupportedDialects) ? auditDoc.unsupportedDialects : [];
    for (const entry of unsupportedDialects) {
      const sourceId = typeof entry === 'string' ? entry : entry && entry.sourceId;
      const dialect = typeof entry === 'string' ? null : entry && entry.dialect;
      add(
        'GATE_D_DIALECT_UNSUPPORTED',
        `source ${sourceId} 方言 ${dialect} 无执行通道：本轮不得产 delta，必须人工/专用通道迁移`,
        { sourceId, ...(dialect ? { dialect } : {}) },
      );
    }
  }

  const operations = operationsDoc && Array.isArray(operationsDoc.operations) ? operationsDoc.operations : [];
  const unsupported = operationsDoc && Array.isArray(operationsDoc.unsupported) ? operationsDoc.unsupported : [];
  if (operationsDoc && !Array.isArray(operationsDoc.operations)) {
    add('GATE_D_SCHEMA', 'operations.operations 必须是数组');
  }
  if (operationsDoc && operationsDoc.unsupported !== undefined && !Array.isArray(operationsDoc.unsupported)) {
    add('GATE_D_SCHEMA', 'operations.unsupported 必须是数组');
  }
  const auditItems = auditDoc && Array.isArray(auditDoc.items) ? auditDoc.items : [];
  if (auditDoc && !Array.isArray(auditDoc.items)) {
    add('GATE_D_SCHEMA', 'delta-audit.items 必须是数组');
  }

  const inventoryTables = inventory && Array.isArray(inventory.tables) ? inventory.tables : [];
  const inventoryCreateTableKeys = new Set();
  const inventoryCreateRefs = new Map();
  for (const entry of inventoryTables) {
    if (!entry || typeof entry !== 'object') continue;
    if (entry.decision !== 'create') continue;
    const resolved = resolveInventoryRef(entry);
    if (resolved.failure) add('GATE_D_SCHEMA', resolved.failure);
    else if (resolved.ref) {
      inventoryCreateTableKeys.add(refKeyOf(resolved.ref));
      inventoryCreateRefs.set(refKeyOf(resolved.ref), resolved.ref);
    }
  }

  // ── create-table 合法集合：inventory codeOnly decision=create ∪ 设计新增表 ──────
  // 设计新增表 = post-delta.classes.newTableCreate ∪ 片段 class=create。
  // 集合必须在 operations / audit / 片段三处判据之前算全（先算集合、后判据），
  // 故这里同时读取 post-delta 与片段；片段不可解析仍按结构红，不静默跳过。
  const postDeltaPath = resolve(options.migrationDir, 'post-delta.json');
  let postDelta = null;
  if (!existsSync(postDeltaPath)) {
    addProducer(
      GATE_D_PRODUCER_MERGE,
      'GATE_D_POST_DELTA_MISSING',
      `缺 post-delta.json：${postDeltaPath}（合并必须产表分类）`,
    );
  } else {
    try {
      postDelta = JSON.parse(readFileSync(postDeltaPath, 'utf-8'));
    } catch (error) {
      addProducer(GATE_D_PRODUCER_MERGE, 'GATE_D_POST_DELTA_UNREADABLE', `post-delta.json 不可解析：${error.message}`);
    }
  }
  const fragmentRecords = [];
  const fragmentsDir = resolve(options.migrationDir, '_fragments');
  if (!existsSync(fragmentsDir)) {
    addProducer(
      GATE_D_PRODUCER_TABLE,
      'GATE_D_FRAGMENTS_MISSING',
      `缺片段目录：${fragmentsDir}（Gate D 需要 _fragments/*.json 做结构异常路由）`,
    );
  } else {
    for (const name of readdirSync(fragmentsDir).filter((entry) => entry.endsWith('.json')).sort()) {
      const file = resolve(fragmentsDir, name);
      try {
        const fragment = JSON.parse(readFileSync(file, 'utf-8'));
        if (!fragment || typeof fragment !== 'object' || Array.isArray(fragment)) {
          addProducer(GATE_D_PRODUCER_TABLE, 'GATE_D_FRAGMENTS_UNREADABLE', `片段不是对象：${name}`);
          continue;
        }
        fragmentRecords.push({ file: name, slug: name.slice(0, -'.json'.length), fragment });
      } catch (error) {
        addProducer(
          GATE_D_PRODUCER_TABLE,
          'GATE_D_FRAGMENTS_UNREADABLE',
          `片段不可解析：${name}（${error.message}）`,
        );
      }
    }
  }
  const designCreateTableKeys = new Set();
  const postDeltaClasses =
    postDelta && typeof postDelta === 'object' && postDelta.classes && typeof postDelta.classes === 'object'
      ? postDelta.classes
      : null;
  if (postDeltaClasses && Array.isArray(postDeltaClasses.newTableCreate)) {
    for (const tableRef of postDeltaClasses.newTableCreate) {
      if (isTableRef(tableRef)) designCreateTableKeys.add(refKeyOf(tableRef));
      else {
        addProducer(
          GATE_D_PRODUCER_MERGE,
          'GATE_D_POST_DELTA_MISMATCH',
          `post-delta.classes.newTableCreate 含非 v3 tableRef：${JSON.stringify(tableRef)}（旧裸表名须重跑 rebuild）`,
        );
      }
    }
  }
  // 片段 class=create 是设计新增表的权威来源：并入合法集合（三处判据同源）。
  for (const record of fragmentRecords) {
    if (record.fragment.class === 'create' && isTableRef(record.fragment.tableRef)) {
      designCreateTableKeys.add(refKeyOf(record.fragment.tableRef));
    }
  }
  const allowedCreateTableKeys = new Set([...inventoryCreateTableKeys, ...designCreateTableKeys]);

  // ── operations v2（无 before/after/digest/resolvesDiffKeys）──────────────────
  const opsById = new Map();
  const opTableByActionId = new Map();
  const referencedPaths = new Set();
  for (const op of operations) {
    if (!op || typeof op !== 'object' || Array.isArray(op)) {
      add('GATE_D_SCHEMA', 'operation 必须是非空对象');
      continue;
    }
    if (!nonEmpty(op.actionId)) {
      add('GATE_D_SCHEMA', 'operation 缺 actionId');
      continue;
    }
    const actionId = op.actionId;
    if (opsById.has(actionId)) add('GATE_D_DUPLICATE_ACTION_ID', `actionId 重复：${actionId}`, { actionId });
    opsById.set(actionId, op);
    if (!isTableRef(op.tableRef)) {
      add(
        'GATE_D_SCHEMA',
        `operation.tableRef 非法：${JSON.stringify(op.tableRef)}（需四字段引用；owner 无值写 null）。` +
          '旧 v2 的 sourceId/objectId/table 身份字段不再接受，须重跑 merge 产出 v3 operations。',
        { actionId },
      );
      continue;
    }
    if (Object.prototype.hasOwnProperty.call(op, 'objectId')) {
      add('GATE_D_SCHEMA', `operation 仍含 objectId（已退役）：${actionId}；恢复：改用 tableRef`, { actionId });
    }
    const parsedActionId = gateParseActionIdV3(actionId);
    if (!parsedActionId) {
      add(
        'GATE_D_SCHEMA',
        `actionId 不符合 v3 形态 sql3:<phase>:<refKey>:<kind>:<ordinal>：${actionId}`,
        { actionId },
      );
    } else {
      if (op.phase !== undefined && parsedActionId.phase !== String(op.phase)) {
        add('GATE_D_ACTION_ID_MISMATCH', `actionId phase 段与 operation.phase 不一致：${actionId}`, { actionId });
      }
      if (op.kind !== undefined && parsedActionId.kind !== String(op.kind)) {
        add('GATE_D_ACTION_ID_MISMATCH', `actionId kind 段与 operation.kind 不一致：${actionId}`, { actionId });
      }
      if (parsedActionId.refKey !== refKeyOf(op.tableRef)) {
        add(
          'GATE_D_ACTION_ID_REF_MISMATCH',
          `actionId 的 refKey 段与 operation.tableRef 不一致：${actionId}（引用被改或 actionId 伪造）`,
          { actionId },
        );
      }
    }
    if (op.generatedBy !== 'script' && op.generatedBy !== 'agent') {
      add('GATE_D_GENERATED_BY_MISSING', `operation 必须持久化 generatedBy=script|agent：${actionId}`, { actionId });
    }
    if (op.generatedBy === 'agent' && !nonEmpty(op.evidenceRef)) {
      add('GATE_D_AGENT_OP_WITHOUT_EVIDENCE', `agent operation 缺 evidenceRef：${actionId}`, { actionId });
    }
    if (!GATE_D_KINDS.has(String(op.kind || ''))) {
      add('GATE_D_KIND_INVALID', `operation.kind 非法：${JSON.stringify(op.kind)}`, { actionId });
    } else if (!(GATE_D_PHASES_BY_KIND[op.kind] || []).includes(op.phase)) {
      add('GATE_D_PHASE_INVALID', `operation.phase=${JSON.stringify(op.phase)} 不允许 kind=${op.kind}`, { actionId });
    }
    if (!op.sql || typeof op.sql !== 'object' || typeof op.sql.path !== 'string') {
      add('GATE_D_MISSING_ARTIFACT', `operation 缺 sql.path：${actionId}`, { actionId });
      continue;
    }
    const badPath = gateSafeSqlPath(op.sql.path, String(op.tableRef.sourceId || ''));
    if (badPath) {
      add('GATE_D_MISSING_ARTIFACT', `sql.path 不安全：${badPath}`, { actionId });
      continue;
    }
    if (referencedPaths.has(op.sql.path)) {
      add('GATE_D_MISSING_ARTIFACT', `sql.path 被重复引用：${op.sql.path}`, { actionId });
      continue;
    }
    referencedPaths.add(op.sql.path);
    const absolute = resolve(options.migrationDir, ...op.sql.path.split('/'));
    if (!existsSync(absolute)) {
      add('GATE_D_MISSING_ARTIFACT', `SQL 文件缺失：${op.sql.path}`, { actionId });
      continue;
    }
    const text = readFileSync(absolute, 'utf-8');
    if (gateSha256(text) !== op.sql.digest) {
      add('GATE_D_SQL_DIGEST_MISMATCH', `SQL 文件 digest 漂移：${op.sql.path}`, { actionId });
    }
    if (op.sql.statements !== 1) {
      add('GATE_D_SCHEMA', `sql.statements 必须为 1：${op.sql.path}`, { actionId });
    }
    const statements = splitSqlStatements(text);
    if (statements.length !== 1) {
      add('GATE_D_MULTI_STATEMENT', `SQL 文件必须恰一条语句（得 ${statements.length}）：${op.sql.path}`, {
        actionId,
      });
    }
    const statement = statements[0] || '';
    const stripped = gateStripLiteralsAndComments(statement);
    if (/\b(?:DROP|TRUNCATE)\b/i.test(stripped)) {
      add('GATE_D_FORBIDDEN_STATEMENT', `禁 DROP/TRUNCATE：${op.sql.path}`, { actionId });
    }
    if (/\bALTER\s+TABLE\b[\s\S]*\b(?:MODIFY|CHANGE|RENAME)\b/i.test(stripped)) {
      add('GATE_D_FORBIDDEN_STATEMENT', `禁 MODIFY/CHANGE/RENAME：${op.sql.path}`, { actionId });
    }
    if (op.kind === 'create-table') {
      if (!/^\s*CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\b/i.test(stripped)) {
        add('GATE_D_CREATE_TABLE_NOT_IF_NOT_EXISTS', `create-table 必须 CREATE TABLE IF NOT EXISTS：${op.sql.path}`, {
          actionId,
        });
      }
      const createdTarget = gateSqlTargetParts(gateStripComments(text));
      if (!createdTarget || !createdTarget.name) {
        add('GATE_D_CREATE_TABLE_NOT_IF_NOT_EXISTS', `无法解析 create-table 表名：${op.sql.path}`, { actionId });
      } else {
        const createdKey = refKeyOf(op.tableRef);
        opTableByActionId.set(actionId, createdKey);
        if (!gateRefMatchesSqlTarget(op.tableRef, createdTarget)) {
          add(
            'GATE_D_SQL_TARGET_MISMATCH',
            `create-table 目标表 ${createdTarget.owner ? `${createdTarget.owner}.` : ''}${createdTarget.name} ` +
              `与 operation.tableRef=${formatRef(op.tableRef)} 不一致`,
            { actionId },
          );
        }
        if (!allowedCreateTableKeys.has(createdKey)) {
          add(
            'GATE_D_CODE_ONLY_DECISION',
            `create-table ${formatRef(op.tableRef)} 不在合法 create 集合（只允许：inventory codeOnly decision=create 或设计新增表（片段 class=create））`,
            { actionId },
          );
        }
        if (baselineRefKeys.has(createdKey)) {
          add('GATE_D_CREATE_TABLE_EXISTING', `存量表不得走 create-table：${formatRef(op.tableRef)}`, { actionId });
        }
      }
    }
    if (op.kind === 'add-column') {
      if (!/^\s*ALTER\s+TABLE\b[\s\S]*\bADD\s+(?:COLUMN\s+)?[^\s;]/i.test(stripped)) {
        add('GATE_D_SQL_SHAPE', `add-column SQL 形态必须是 ALTER TABLE ... ADD [COLUMN] ...：${op.sql.path}`, {
          actionId,
        });
      }
    } else if (op.kind === 'add-index' || op.kind === 'add-unique') {
      const alterAdd = /^\s*ALTER\s+TABLE\b[\s\S]*\bADD\b/i.test(stripped);
      const createIndex = op.kind === 'add-index' && /^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\b/i.test(stripped);
      if (!alterAdd && !createIndex) {
        add('GATE_D_SQL_SHAPE', `operation SQL 形态不符 kind=${op.kind}：${op.sql.path}`, { actionId });
      }
    } else if (op.kind === 'add-comment') {
      if (!/^\s*(?:ALTER\s+TABLE|COMMENT\s+ON)\b/i.test(stripped)) {
        add('GATE_D_SQL_SHAPE', `add-comment SQL 形态不符：${op.sql.path}`, { actionId });
      }
    }
    const dialect = sourceDialectById.get(String(op.tableRef.sourceId || ''));
    if (dialect && !['mysql', 'mariadb', 'postgresql', 'postgres', 'pg'].includes(dialect.toLowerCase())) {
      add('GATE_D_DIALECT_UNSUPPORTED', `source ${op.tableRef.sourceId} 方言 ${dialect} 无执行通道却产了 delta`, {
        actionId,
      });
    }
  }

  // ── operations.unsupported[]（v2 无 designDigest/before）──────────────────────
  const unsupportedByKey = new Map();
  for (const entry of unsupported) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      add('GATE_D_SCHEMA', 'operations.unsupported[] 含非对象条目');
      continue;
    }
    if (!isTableRef(entry.tableRef)) {
      add(
        'GATE_D_SCHEMA',
        `operations.unsupported[].tableRef 非法：${JSON.stringify(entry.tableRef)}（需四字段引用）`,
      );
      continue;
    }
    if (Object.prototype.hasOwnProperty.call(entry, 'objectId')) {
      add('GATE_D_SCHEMA', 'operations.unsupported[] 仍含 objectId（已退役）：改用 tableRef');
    }
    const recomputedKey = gateBuildUnsupportedKeyV3(entry);
    if (nonEmpty(entry.unsupportedKey) && recomputedKey && entry.unsupportedKey !== recomputedKey) {
      add('GATE_D_UNSUPPORTED_KEY_MISMATCH', `unsupportedKey 与 v3 重算不一致：声明 ${entry.unsupportedKey}，重算 ${recomputedKey}`, {
        unsupportedKey: entry.unsupportedKey,
      });
    }
    const key = nonEmpty(entry.unsupportedKey) ? entry.unsupportedKey : recomputedKey;
    if (!key) {
      addProducer(
        GATE_D_PRODUCER_MERGE,
        'GATE_D_UNSUPPORTED_KEY_MISSING',
        'operations.unsupported[] 缺稳定 unsupportedKey（且 tableRef/changeKind 不足，无法机械重算）',
      );
    } else {
      if (unsupportedByKey.has(key)) {
        add('GATE_D_DUPLICATE_UNSUPPORTED_KEY', `operations.unsupported unsupportedKey 重复：${key}`, {
          unsupportedKey: key,
        });
      }
      unsupportedByKey.set(key, entry);
    }
    const missing = [];
    if (!nonEmpty(entry.changeKind)) missing.push('changeKind');
    if (!nonEmpty(entry.requested)) missing.push('requested');
    if (!nonEmpty(entry.state)) missing.push('state');
    if (missing.length > 0) {
      addProducer(
        GATE_D_PRODUCER_MERGE,
        'GATE_D_UNSUPPORTED_INCOMPLETE',
        `operations.unsupported[] 缺必填字段 ${missing.join('/')}：${key || '<无键>'}`,
        key ? { unsupportedKey: key } : {},
      );
    }
    if (nonEmpty(entry.changeKind) && !GATE_D_UNSUPPORTED_KINDS.has(String(entry.changeKind))) {
      add('GATE_D_UNSUPPORTED_KIND', `unsupported.changeKind 非法：${JSON.stringify(entry.changeKind)}`, {
        unsupportedKey: key,
      });
    }
    if (nonEmpty(entry.state)) {
      if (!GATE_D_UNSUPPORTED_STATES.has(String(entry.state))) {
        add('GATE_D_UNSUPPORTED_STATE', `unsupported.state 非法：${JSON.stringify(entry.state)}`, {
          unsupportedKey: key,
        });
      } else if (entry.state === 'withdrawn') {
        add('GATE_D_UNSUPPORTED_STATE', `unsupported 已被撤回但仍留在产物中：${key}`, { unsupportedKey: key });
      } else if (entry.state === 'accepted-manual' && !nonEmpty(entry.manualMigration)) {
        add('GATE_D_UNSUPPORTED_STATE', `accepted-manual 缺 manualMigration：${key}`, { unsupportedKey: key });
      }
    }
  }

  // ── audit items v2：按 classification 校验 + actionId/unsupportedKey 对账 ──────
  const auditByActionId = new Map();
  const auditUnsupportedByKey = new Map();
  const auditCreateDeferTables = new Set();
  const seenAuditActionIds = new Set();
  const seenAuditUnsupportedKeys = new Set();
  const seenDiffKeys = new Set();

  for (const [index, item] of auditItems.entries()) {
    const tag = `delta-audit.items[${index}]`;
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      add('GATE_D_SCHEMA', `${tag} 必须是非空对象`);
      continue;
    }
    const classification = String(item.classification || '');
    if (!GATE_D_CLASSIFICATIONS.has(classification)) {
      add(
        'GATE_D_AUDIT_CLASSIFICATION',
        `${tag}.classification 必须为 operation/unsupported/skip（已删除 gap），得 ${JSON.stringify(item.classification)}`,
      );
      continue;
    }
    const gapClass = String(item.gapClass || '');
    if (!GATE_D_GAP_CLASSES.has(gapClass)) {
      add('GATE_D_AUDIT_GAP_CLASS', `${tag}.gapClass 必须为 G0–G9，得 ${JSON.stringify(item.gapClass)}`);
    } else {
      const expectedGapClasses =
        classification === 'operation'
          ? ['G0']
          : classification === 'unsupported'
            ? ['G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8']
            : ['G9'];
      if (!expectedGapClasses.includes(gapClass)) {
        add(
          'GATE_D_AUDIT_GAP_CLASS',
          `${tag}.gapClass=${gapClass} 不允许 classification=${classification}（G9 仅 skip；operation=G0；unsupported=G1..G8）`,
        );
      }
    }
    if (nonEmpty(item.diffKey)) {
      if (seenDiffKeys.has(item.diffKey)) {
        add('GATE_D_DUPLICATE_DIFF_KEY', `delta-audit diffKey 重复：${item.diffKey}`, { diffKey: item.diffKey });
      }
      seenDiffKeys.add(item.diffKey);
    }

    if (classification === 'operation') {
      // 新表 create defer：允许无 actionId，但必须 tableRef + changeKind + deferredTo。
      if (item.changeKind === 'create-table' && item.deferredTo === 'post-delta') {
        if (!isTableRef(item.tableRef)) {
          add('GATE_D_AUDIT_ITEM', `${tag} create defer 缺合法 tableRef（需四字段引用）`);
        } else auditCreateDeferTables.add(refKeyOf(item.tableRef));
        if (nonEmpty(item.actionId) && !opsById.has(item.actionId)) {
          add(
            'GATE_D_AUDIT_UNKNOWN_ACTION_ID',
            `${tag}.actionId 不在 operations[].actionId：${item.actionId}`,
            { actionId: item.actionId },
          );
        }
        continue;
      }
      if (item.deferredTo === 'post-delta') {
        add('GATE_D_AUDIT_ITEM', `${tag} deferredTo:"post-delta" 仅允许 changeKind:"create-table"`);
      }
      if (!nonEmpty(item.actionId)) {
        add('GATE_D_AUDIT_ITEM', `${tag} 普通 operation item 必须带 actionId（create defer 除外）`);
      } else {
        if (seenAuditActionIds.has(item.actionId)) {
          add('GATE_D_DUPLICATE_ACTION_ID', `delta-audit actionId 重复：${item.actionId}`, {
            actionId: item.actionId,
          });
        }
        seenAuditActionIds.add(item.actionId);
        if (!opsById.has(item.actionId)) {
          add(
            'GATE_D_AUDIT_UNKNOWN_ACTION_ID',
            `${tag}.actionId 不在 operations[].actionId：${item.actionId}`,
            { actionId: item.actionId },
          );
        } else {
          auditByActionId.set(item.actionId, item);
        }
      }
      const missing = [];
      if (!isTableRef(item.tableRef)) missing.push('tableRef(四字段引用)');
      if (typeof item.column !== 'string') missing.push('column');
      if (!GATE_D_KINDS.has(String(item.changeKind || ''))) missing.push('changeKind(6 种 closed kind)');
      if (missing.length > 0) {
        add('GATE_D_AUDIT_ITEM', `${tag} operation item 缺必填/非法：${missing.join('/')}`);
      }
      if (Object.prototype.hasOwnProperty.call(item, 'objectId')) {
        add('GATE_D_AUDIT_ITEM', `${tag} 仍含 objectId（已退役）：改用 tableRef`);
      }
      continue;
    }

    if (classification === 'unsupported') {
      const key = nonEmpty(item.unsupportedKey) ? item.unsupportedKey : null;
      if (!key) {
        add('GATE_D_AUDIT_ITEM', `${tag} unsupported item 必须带 unsupportedKey`);
      } else {
        if (seenAuditUnsupportedKeys.has(key)) {
          add('GATE_D_DUPLICATE_UNSUPPORTED_KEY', `delta-audit unsupportedKey 重复：${key}`, {
            unsupportedKey: key,
          });
        }
        seenAuditUnsupportedKeys.add(key);
        if (!unsupportedByKey.has(key)) {
          add(
            'GATE_D_AUDIT_UNKNOWN_UNSUPPORTED_KEY',
            `${tag}.unsupportedKey 不在 operations.unsupported[]：${key}`,
            { unsupportedKey: key },
          );
        } else {
          auditUnsupportedByKey.set(key, item);
        }
      }
      const missing = [];
      if (!isTableRef(item.tableRef)) missing.push('tableRef(四字段引用)');
      if (typeof item.column !== 'string') missing.push('column');
      if (!GATE_D_UNSUPPORTED_KINDS.has(String(item.changeKind || ''))) missing.push('changeKind');
      if (!nonEmpty(item.requested)) missing.push('requested');
      if (!GATE_D_UNSUPPORTED_STATES.has(String(item.state || ''))) missing.push('state');
      if (!Array.isArray(item.decisionRefs)) missing.push('decisionRefs');
      if (missing.length > 0) {
        add('GATE_D_AUDIT_ITEM', `${tag} unsupported item 缺必填/非法：${missing.join('/')}`);
      }
      continue;
    }

    // skip：G9 + skipReason；skip 不代表语义审核通过。
    if (!GATE_D_SKIP_REASONS.has(String(item.skipReason || ''))) {
      add(
        'GATE_D_AUDIT_SKIP_REASON',
        `${tag} skip 必须带 skipReason ∈ baseline-only/no-operation-sql-produced/retained-unchanged，得 ${JSON.stringify(item.skipReason)}`,
      );
    }
    if (!isTableRef(item.tableRef)) {
      add('GATE_D_AUDIT_ITEM', `${tag} skip 缺合法 tableRef（需四字段引用，baseline-only 也不例外）`);
    }
    if (Object.prototype.hasOwnProperty.call(item, 'objectId')) {
      add('GATE_D_AUDIT_ITEM', `${tag} 仍含 objectId（已退役）：改用 tableRef`);
    }
  }

  // ── 对账：普通 operation 必须有 operation item；unsupported 必须有 unsupported item ──
  for (const op of operations) {
    if (!op || !nonEmpty(op.actionId)) continue;
    if (opsById.get(op.actionId) !== op) continue;
    const createDeferCovered =
      op.kind === 'create-table' &&
      opTableByActionId.has(op.actionId) &&
      auditCreateDeferTables.has(opTableByActionId.get(op.actionId));
    if (!auditByActionId.has(op.actionId) && !createDeferCovered) {
      addProducer(
        GATE_D_PRODUCER_AUDIT,
        'GATE_D_ORPHAN_OPERATION',
        `普通 operation 缺 operation audit item：${op.actionId}`,
        { actionId: op.actionId },
      );
    }
  }
  for (const key of unsupportedByKey.keys()) {
    if (!auditUnsupportedByKey.has(key)) {
      addProducer(
        GATE_D_PRODUCER_AUDIT,
        'GATE_D_ORPHAN_UNSUPPORTED',
        `operations.unsupported 缺 unsupported audit item：${key}`,
        { unsupportedKey: key },
      );
    }
  }

  // ── codeOnly decision=create：必须有 create 语义 audit item（不再要求 operations 有 create-table）──
  for (const tableKey of inventoryCreateTableKeys) {
    if (!auditCreateDeferTables.has(tableKey)) {
      add(
        'GATE_D_CODE_ONLY_CREATE_MISSING',
        `codeOnly decision=create 的表缺 create 语义 audit item（classification=operation、changeKind=create-table、deferredTo=post-delta）：${tableKey}`,
        { table: tableKey, producer: GATE_D_PRODUCER_AUDIT },
      );
    }
  }
  for (const tableKey of auditCreateDeferTables) {
    if (!allowedCreateTableKeys.has(tableKey)) {
      add(
        'GATE_D_CODE_ONLY_DECISION',
        `create defer 表 ${baselineRefByKey.get(tableKey) ? formatRef(baselineRefByKey.get(tableKey)) : tableKey} 不在合法 create 集合` +
          '（只允许：inventory codeOnly decision=create 或设计新增表（片段 class=create））',
        { tableRef: baselineRefByKey.get(tableKey), producer: GATE_D_PRODUCER_AUDIT },
      );
    }
    if (baselineRefKeys.has(tableKey)) {
      add(
        'GATE_D_CREATE_TABLE_EXISTING',
        `存量表不得走 create-table：${baselineRefByKey.get(tableKey) ? formatRef(baselineRefByKey.get(tableKey)) : tableKey}`,
        { tableRef: baselineRefByKey.get(tableKey), producer: GATE_D_PRODUCER_AUDIT },
      );
    }
  }

  // ── 片段结构校验（片段已在合法 create 集合处读取，避免二次解析）──────────────────
  const fragmentReferencedPaths = new Set();
  for (const record of fragmentRecords) {
    const { fragment, slug, file } = record;
    if (fragment.schemaVersion !== GATE_D_SCHEMA_VERSION) {
      addProducer(
        GATE_D_PRODUCER_TABLE,
        'GATE_D_FRAGMENT_SCHEMA',
        `片段 schemaVersion 必须为 ${GATE_D_SCHEMA_VERSION}（v2 片段不投影，须重跑单表 agent），得 ${JSON.stringify(fragment.schemaVersion)}`,
        { slug },
      );
    }
    if (!isTableRef(fragment.tableRef)) {
      addProducer(
        GATE_D_PRODUCER_TABLE,
        'GATE_D_FRAGMENT_SCHEMA',
        `片段缺合法 tableRef（需 {sourceId,owner,kind:'table',name}；旧 table/sourceId/objectId 不再接受）`,
        { slug },
      );
      continue;
    }
    const tableRef = fragment.tableRef;
    const tableKey = refKeyOf(tableRef);
    const fragmentStatements = Array.isArray(fragment.statements) ? fragment.statements : [];
    for (const statement of fragmentStatements) {
      if (statement && typeof statement.sqlPath === 'string' && statement.sqlPath) {
        fragmentReferencedPaths.add(statement.sqlPath.replace(/\\/g, '/'));
      }
    }
    if ((fragment.class === 'create' || fragment.class === 'alter') && fragmentStatements.length === 0) {
      addProducer(
        GATE_D_PRODUCER_TABLE,
        'GATE_D_FRAGMENT_MISSING_SQL',
        `片段 class=${fragment.class} 但无 statements/SQL：${file}（tableRef=${formatRef(tableRef)}）`,
        { tableRef, slug },
      );
    }
    for (const [index, statement] of fragmentStatements.entries()) {
      if (!statement || typeof statement !== 'object' || Array.isArray(statement)) {
        addProducer(GATE_D_PRODUCER_TABLE, 'GATE_D_FRAGMENT_STATEMENT_KIND', `片段 ${file} statements[${index}] 非对象`, {
          tableRef,
          slug,
        });
        continue;
      }
      if (!GATE_D_KINDS.has(String(statement.kind || ''))) {
        addProducer(
          GATE_D_PRODUCER_TABLE,
          'GATE_D_FRAGMENT_STATEMENT_KIND',
          `片段 ${file} statements[${index}].kind 不在 6 种 closed kind：${JSON.stringify(statement.kind)}`,
          { tableRef, slug },
        );
      }
      if (fragment.class === 'create' || fragment.class === 'alter') {
        let sqlText = typeof statement.sql === 'string' ? statement.sql : '';
        if ((!sqlText || !sqlText.trim()) && typeof statement.sqlPath === 'string' && statement.sqlPath) {
          const absolute = resolve(options.migrationDir, ...statement.sqlPath.split('/'));
          if (existsSync(absolute)) {
            try {
              sqlText = readFileSync(absolute, 'utf-8');
            } catch {
              sqlText = '';
            }
          }
        }
        if (!sqlText || !sqlText.trim()) {
          addProducer(
            GATE_D_PRODUCER_TABLE,
            'GATE_D_FRAGMENT_MISSING_SQL',
            `片段 ${file} statements[${index}] 缺 SQL（sql/sqlPath 均不可用）`,
            { tableRef, slug },
          );
          continue;
        }
        if (statement.kind === 'create-table') {
          const stripped = gateStripLiteralsAndComments(sqlText);
          if (!/^\s*CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\b/i.test(stripped)) {
            addProducer(
              GATE_D_PRODUCER_TABLE,
              'GATE_D_CREATE_TABLE_NOT_IF_NOT_EXISTS',
              `片段 ${file} 的 create-table 必须 CREATE TABLE IF NOT EXISTS`,
              { tableRef, slug },
            );
          }
          const createdTarget = gateSqlTargetParts(gateStripComments(sqlText));
          if (!createdTarget || !createdTarget.name) {
            addProducer(
              GATE_D_PRODUCER_TABLE,
              'GATE_D_CREATE_TABLE_NOT_IF_NOT_EXISTS',
              `片段 ${file} 无法解析 create-table 表名`,
              { tableRef, slug },
            );
          } else {
            const createdKey = tableKey;
            if (!gateRefMatchesSqlTarget(tableRef, createdTarget)) {
              addProducer(
                GATE_D_PRODUCER_TABLE,
                'GATE_D_FRAGMENT_MISSING_SQL',
                `片段 ${file} create-table 目标表 ${createdTarget.owner ? `${createdTarget.owner}.` : ''}${createdTarget.name} ` +
                  `与片段 tableRef=${formatRef(tableRef)} 不一致`,
                { tableRef, slug },
              );
            }
            if (!allowedCreateTableKeys.has(createdKey)) {
              add(
                'GATE_D_CODE_ONLY_DECISION',
                `create-table ${formatRef(tableRef)} 不在合法 create 集合（只允许：inventory codeOnly decision=create 或设计新增表（片段 class=create））`,
                { tableRef, producer: GATE_D_PRODUCER_TABLE },
              );
            }
            if (baselineRefKeys.has(createdKey)) {
              add('GATE_D_CREATE_TABLE_EXISTING', `存量表不得走 create-table：${formatRef(tableRef)}`, {
                tableRef,
                producer: GATE_D_PRODUCER_TABLE,
              });
            }
          }
        }
      }
    }
    if (fragment.class === 'unsupported') {
      const entries = Array.isArray(fragment.unsupported) ? fragment.unsupported : [];
      if (entries.length === 0) {
        addProducer(
          GATE_D_PRODUCER_TABLE,
          'GATE_D_FRAGMENT_UNSUPPORTED_UNMERGED',
          `片段 class=unsupported 但 unsupported[] 为空：${file}（tableRef=${formatRef(tableRef)}）`,
          { tableRef, slug },
        );
      }
      for (const [index, entry] of entries.entries()) {
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
          addProducer(
            GATE_D_PRODUCER_TABLE,
            'GATE_D_FRAGMENT_UNSUPPORTED_INCOMPLETE',
            `片段 ${file} unsupported[${index}] 非对象`,
            { tableRef, slug },
          );
          continue;
        }
        const missing = [];
        if (!nonEmpty(entry.changeKind)) missing.push('changeKind');
        if (!nonEmpty(entry.requested)) missing.push('requested');
        if (!nonEmpty(entry.state)) missing.push('state');
        if (missing.length > 0) {
          addProducer(
            GATE_D_PRODUCER_TABLE,
            'GATE_D_FRAGMENT_UNSUPPORTED_INCOMPLETE',
            `片段 ${file} unsupported[${index}] 缺 ${missing.join('/')}（结构异常回单表 agent，不得用 skip 掩盖）`,
            { tableRef, slug },
          );
        }
        if (Object.prototype.hasOwnProperty.call(entry, 'objectId')) {
          addProducer(
            GATE_D_PRODUCER_TABLE,
            'GATE_D_FRAGMENT_UNSUPPORTED_INCOMPLETE',
            `片段 ${file} unsupported[${index}] 仍含 objectId（已退役）：改用 tableRef`,
            { tableRef, slug },
          );
        }
        const entryRef = isTableRef(entry.tableRef) ? entry.tableRef : tableRef;
        const mergedKey = nonEmpty(entry.unsupportedKey)
          ? entry.unsupportedKey
          : gateBuildUnsupportedKeyV3({
              tableRef: entryRef,
              column: entry.column,
              target: entry.target,
              changeKind: entry.changeKind,
            });
        if (!mergedKey) {
          addProducer(
            GATE_D_PRODUCER_MERGE,
            'GATE_D_FRAGMENT_UNSUPPORTED_UNMERGED',
            `片段 ${file} unsupported[${index}] 无法机械重算 unsupportedKey（身份不足）`,
            { tableRef, slug },
          );
        } else if (!unsupportedByKey.has(mergedKey)) {
          addProducer(
            GATE_D_PRODUCER_MERGE,
            'GATE_D_FRAGMENT_UNSUPPORTED_UNMERGED',
            `片段 unsupported 未进入 operations.unsupported[]：${mergedKey}（merge 必须按 unsupportedKey 逐条合并）`,
            { tableRef, slug, unsupportedKey: mergedKey },
          );
        }
      }
    }
  }

  // ── post-delta 表分类与片段/operations 一致（post-delta 已在 create-table 集合处读取）──
  if (postDelta) {
    const classes = postDelta && typeof postDelta === 'object' ? postDelta.classes : null;
    if (!classes || typeof classes !== 'object' || Array.isArray(classes)) {
      addProducer(GATE_D_PRODUCER_MERGE, 'GATE_D_POST_DELTA_MISMATCH', 'post-delta.classes 必须是对象');
    } else {
      const expectedClasses = {
        newTableCreate: new Set(),
        existingDeltaAlter: new Set(),
        designRetainedUnsupported: new Set(),
      };
      for (const record of fragmentRecords) {
        if (!isTableRef(record.fragment.tableRef)) continue;
        const key = refKeyOf(record.fragment.tableRef);
        if (record.fragment.class === 'create') expectedClasses.newTableCreate.add(key);
        else if (record.fragment.class === 'alter') expectedClasses.existingDeltaAlter.add(key);
        else if (record.fragment.class === 'unsupported') expectedClasses.designRetainedUnsupported.add(key);
      }
      const operationAlterTables = new Set();
      for (const op of operations) {
        if (!op || typeof op !== 'object' || op.phase !== 'existing-delta') continue;
        if (isTableRef(op.tableRef)) operationAlterTables.add(refKeyOf(op.tableRef));
      }
      const unsupportedOperationTables = new Set();
      for (const entry of unsupportedByKey.values()) {
        if (entry && isTableRef(entry.tableRef)) unsupportedOperationTables.add(refKeyOf(entry.tableRef));
      }
      const actual = {};
      for (const key of ['newTableCreate', 'existingDeltaAlter', 'designRetainedUnsupported']) {
        const value = Array.isArray(classes[key]) ? classes[key] : null;
        if (!value) {
          addProducer(
            GATE_D_PRODUCER_MERGE,
            'GATE_D_POST_DELTA_MISMATCH',
            `post-delta.classes.${key} 必须是 tableRef 数组`,
          );
          actual[key] = null;
          continue;
        }
        actual[key] = new Set();
        for (const item of value) {
          if (!isTableRef(item)) {
            addProducer(
              GATE_D_PRODUCER_MERGE,
              'GATE_D_POST_DELTA_MISMATCH',
              `post-delta.classes.${key} 含非 v3 tableRef：${JSON.stringify(item)}（旧裸表名须重跑 rebuild）`,
            );
            continue;
          }
          actual[key].add(refKeyOf(item));
        }
      }
      const compareBucket = (key, expected, extra) => {
        if (!actual[key]) return;
        const onlyPost = [...actual[key]].filter((item) => !expected.has(item));
        const expectedWithExtra = new Set([...expected, ...(extra || [])]);
        const onlyExpected = [...expectedWithExtra].filter((item) => !actual[key].has(item));
        if (onlyPost.length > 0 || onlyExpected.length > 0) {
          addProducer(
            GATE_D_PRODUCER_MERGE,
            'GATE_D_POST_DELTA_MISMATCH',
            `post-delta ${key} 与片段/operations 不一致：post-delta 多出 [${onlyPost.join(', ')}]，应有 [${onlyExpected.join(', ')}]`,
          );
        }
      };
      compareBucket('newTableCreate', expectedClasses.newTableCreate);
      compareBucket('existingDeltaAlter', expectedClasses.existingDeltaAlter, operationAlterTables);
      compareBucket(
        'designRetainedUnsupported',
        expectedClasses.designRetainedUnsupported,
        unsupportedOperationTables,
      );
    }
  }

  // 孤儿 SQL：migration 下未被 operation 或片段引用的 .sql（新表 create SQL 由片段引用）。
  const collectSqlFiles = (dir, prefix = '') => {
    const out = [];
    if (!existsSync(dir)) return out;
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const rel = prefix ? prefix + '/' + entry.name : entry.name;
      if (entry.isDirectory()) out.push(...collectSqlFiles(resolve(dir, entry.name), rel));
      else if (entry.name.endsWith('.sql')) out.push(rel);
    }
    return out;
  };
  for (const sqlFile of collectSqlFiles(options.migrationDir)) {
    if (!referencedPaths.has(sqlFile) && !fragmentReferencedPaths.has(sqlFile)) {
      add('GATE_D_ORPHAN_SQL_FILE', `孤儿 SQL 文件（无 operation/片段引用）：${sqlFile}`);
    }
  }

  // scope 参数保留兼容；Gate D 是终态，不再有 Agent D 的可见失败过滤。
  return {
    ok: failures.length === 0,
    mode: 'gate-d',
    scope: options.scope,
    operations: operations.length,
    unsupported: unsupported.length,
    auditItems: auditItems.length,
    failures,
  };
}

// ── 核心检查 ────────────────────────────────────────────────────────────────
// 主键门 #9 方言感知（plan 2026-09-21 §D2）：真值从 entity 路径向上解析 tech-stack.json database；
// 缺席=MySQL 存量形态（回归锁）。存量表照搬分支不走 #9（豁免），方言分叉只作用于新建表全套。
// 在场但不可解析=结构化红禁假绿（dual-review 2026-09-21 P2：证据不可解析禁 skip 兜底）；
// 归一命中但字典缺行=放行留痕（2026-09-22 拍板）；未知类型=D7 矩阵降级留痕（warnings/notes 透出，禁静默丢证据）。
/**
 * v3 版本守卫：**不提供 v1/v2 回退**。旧产物附集中迁移恢复入口。
 */
function classifyCodeSchema(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return { status: 'malformed', reason: 'code-schema 顶层不是对象' };
  }
  if (Object.prototype.hasOwnProperty.call(raw, 'tables')) {
    return {
      status: 'mixed-shape',
      reason: 'v3 不允许顶层 tables（禁止按 tables 猜 sources）；恢复：用 extract-code-schema.mjs 重采 v3（sources[]）',
    };
  }
  if (raw.schemaVersion !== CODE_SCHEMA_VERSION) {
    const legacy =
      raw.schemaVersion === 1 || raw.schemaVersion === 2 || raw.schemaVersion === undefined;
    return {
      status: legacy ? 'legacy' : 'unknown-version',
      reason:
        `schemaVersion=${JSON.stringify(raw.schemaVersion)}：只接受 ${CODE_SCHEMA_VERSION}。` +
        '旧产物恢复入口：用 extract-code-schema.mjs 重采 v3（对象只带 owner/kind/name，不再写 objectId），' +
        '或在集中迁移边界跑 v2→v3 迁移脚本；禁止手工改版本号冒充 v3。',
    };
  }
  if (!Array.isArray(raw.sources)) {
    return { status: 'malformed', reason: 'v3 缺 sources 数组' };
  }
  return { status: 'current' };
}

/**
 * 实体头部可选的 source 声明（增量 micro 消歧）：
 *   `sourceId：src1.xxx` / `数据源：ds01`（或 `dataSourceName：ds01`）。
 * `objectId` 已退役：出现即由调用方判红（此处只负责读出以便报错）。只在头部 4000 字符内读。
 */
function readIdentityHints(content) {
  const head = content.slice(0, 4000);
  const read = (patterns) => {
    for (const pattern of patterns) {
      const m = head.match(pattern);
      if (m) return m[1].trim();
    }
    return undefined;
  };
  return {
    sourceId: read([/(?:^|\n)\s*sourceId\s*[：:]\s*`?([^\s`"']+)/i]),
    objectId: read([/(?:^|\n)\s*objectId\s*[：:]\s*`?([^\s`"']+)/i]),
    dataSourceName: read([
      /(?:^|\n)\s*dataSourceName\s*[：:]\s*`?([^\s`"']+)/i,
      /(?:^|\n)\s*数据源\s*[：:]\s*`?([^\s`"']+)/i,
    ]),
  };
}

/**
 * v3 对象索引：`refKey → {ref,source,object}` 与 `sourceId+精确名 → entry[]`。
 * **禁全小写、禁去 schema 前缀、禁 `split('.')`**：裸名只做逐字精确的唯一命中。
 */
function buildObjectIndex(codeSchema) {
  const byRefKey = new Map();
  const bySourceName = new Map();
  for (const source of codeSchema.sources) {
    if (!source || typeof source !== 'object') continue;
    for (const object of source.objects || []) {
      if (!object || object.kind !== 'table' || typeof object.name !== 'string' || !object.name) continue;
      const ref = {
        sourceId: source.sourceId,
        owner: object.owner === undefined ? null : object.owner,
        kind: 'table',
        name: object.name,
      };
      if (!isSchemaObjectRef(ref)) continue;
      const entry = { ref, source, object };
      const key = refKeyOf(ref);
      if (!byRefKey.has(key)) byRefKey.set(key, entry);
      const nameKey = `${source.sourceId}\u0000${object.name}`;
      if (!bySourceName.has(nameKey)) bySourceName.set(nameKey, []);
      bySourceName.get(nameKey).push(entry);
    }
  }
  return { byRefKey, bySourceName };
}

function sourceLabelOf(source) {
  return `${source.sourceId}${source.binding && source.binding.dataSourceName ? `（${source.binding.dataSourceName}）` : ''}`;
}

/** 按四字段引用精确解析基线对象（refKey 逐字匹配；不跨 source/owner）。 */
function resolveBaselineObjectByRef(tableRef, index) {
  if (!isSchemaObjectRef(tableRef)) {
    return {
      status: 'failure',
      message: `tableRef 非法：${JSON.stringify(tableRef)}（需 {sourceId,owner,kind:'table',name}，owner 无值写 null）`,
    };
  }
  const entry = index.byRefKey.get(refKeyOf(tableRef));
  return entry ? { status: 'existing', entry } : { status: 'new' };
}

/** 无 tableRefs 元数据时：按 source 作用域 + 精确名唯一解析；同名多引用 ⇒ failure（不合并）。 */
function resolveBaselineObjectByName({ owner, name }, sourceId, index) {
  if (!name) return { status: 'failure', message: '未从 entity DDL 抽出 CREATE TABLE 表名' };
  if (!sourceId) return { status: 'failure', message: `表 ${name} 无法确定所属 source` };
  const candidates = (index.bySourceName.get(`${sourceId}\u0000${name}`) || []).filter(
    (entry) => owner == null || entry.ref.owner === owner,
  );
  if (candidates.length === 1) return { status: 'existing', entry: candidates[0] };
  if (candidates.length === 0) return { status: 'new' };
  return {
    status: 'failure',
    message:
      `表 ${owner == null ? '' : `${owner}.`}${name} 在 sourceId=${sourceId} 命中 ${candidates.length} 个基线对象` +
      `（${candidates.map((entry) => formatRef(entry.ref)).join(' / ')}）：` +
      '禁止按裸表名合并；请在实体头部写 sourceId 或 `## tableRefs` 元数据显式绑定四字段引用。',
  };
}

/**
 * 从头部 hints 收敛 source 作用域：sourceId 精确命中，或数据源 binding 唯一命中。
 * 返回 { sourceId } / { failure } / {}（未声明且单 source 时由调用方兜底）。
 */
function resolveSourceScope(hints, codeSchema) {
  if (hints.sourceId) {
    const source = codeSchema.sources.find((item) => item && item.sourceId === hints.sourceId);
    if (!source) return { failure: `实体头部 sourceId=${hints.sourceId} 不在 code-schema v3 sources 中` };
    return { sourceId: source.sourceId };
  }
  if (hints.dataSourceName) {
    const sources = codeSchema.sources.filter(
      (item) => item && item.binding && item.binding.dataSourceName === hints.dataSourceName,
    );
    if (sources.length === 0) return { failure: `实体头部数据源 ${hints.dataSourceName} 不在 code-schema v3 sources 中` };
    if (sources.length > 1) {
      return {
        failure: `数据源 ${hints.dataSourceName} 对应多份基线（${sources.map(sourceLabelOf).join(' / ')}），请改用 sourceId`,
      };
    }
    return { sourceId: sources[0].sourceId };
  }
  return {};
}

function checkIncrementalEntity(content, codeSchema, entityPath) {
  const failures = [];
  // 主键门降级留痕通道（D7 矩阵：未知类型让步=warnings / 无族指纹结构过=notes；禁静默丢证据）
  const idGateWarnings = [];
  const idGateNotes = [];
  const collectIdGate = (content, idDialect) => {
    const r = checkIdMandate(content, idDialect);
    failures.push(...r.failures);
    idGateWarnings.push(...(r.warnings ?? []));
    idGateNotes.push(...(r.notes ?? []));
  };

  // 结构检查 #1-#7（全表，scenario 无关，单一真理源 helper）
  failures.push(...checkEntityStructure(content).failures);

  const dialect = resolveDialectFromEntityPath(entityPath);
  if (dialect.parseError) {
    failures.push(
      `tech-stack.json 存在但不可解析（${dialect.parseError}）——方言真值不可判，禁按默认形态判绿（证据不可解析禁 skip 兜底）`,
    );
  }
  const idDialect = dialect.key ?? (dialect.raw ? `未知类型(${dialect.raw})` : 'MySQL');

  // v3 版本守卫：历史/未知形状一律拒绝，**不回退 v1/v2**。
  const verdict = classifyCodeSchema(codeSchema);
  if (verdict.status !== 'current') {
    failures.push(`code-schema 不可用于增量分类（${verdict.status}）：${verdict.reason}`);
    return { ok: false, failures, warnings: idGateWarnings, notes: idGateNotes };
  }
  if (codeSchema.sources.length === 0) {
    failures.push('code-schema v3 sources 为空：无基线不能分类存量/新表（不是空库）');
    return { ok: false, failures, warnings: idGateWarnings, notes: idGateNotes };
  }

  const hints = readIdentityHints(content);
  if (hints.objectId) {
    failures.push(
      `实体头部仍声明 objectId=${hints.objectId}：objectId 已退役。` +
        '恢复：删除 objectId，改为 sourceId/数据源 + `## tableRefs` 元数据（四字段引用）绑定。',
    );
  }
  const metadata = parseTableRefsMetadata(content);
  if (metadata.present && metadata.error) failures.push(metadata.error);
  const scope = resolveSourceScope(hints, codeSchema);
  if (scope.failure) failures.push(scope.failure);

  const index = buildObjectIndex(codeSchema);
  const segments = extractCreateTableSegments(content);
  if (segments.length === 0) {
    // 无 CREATE TABLE：#1 结构已报，跳过分类检查
    return { ok: failures.length === 0, failures, warnings: idGateWarnings, notes: idGateNotes };
  }

  // 逐段绑定引用（R18：多表文档禁「首表代表全部」）。
  const bindings = [];
  if (metadata.present && !metadata.error) {
    const byOrdinal = new Map();
    for (const item of metadata.bindings) {
      if (byOrdinal.has(item.segment)) failures.push(`tableRefs 元数据段号 ${item.segment} 重复绑定`);
      else byOrdinal.set(item.segment, item.tableRef);
    }
    for (const segment of segments) {
      const tableRef = byOrdinal.get(segment.ordinal);
      if (!tableRef) {
        failures.push(
          `第 ${segment.ordinal} 个 CREATE TABLE（${segment.tableName}）在 tableRefs 元数据中无绑定：` +
            '多表文档必须逐段绑定四字段引用，禁止让首表代表全部',
        );
        continue;
      }
      bindings.push({ segment, tableRef });
    }
    for (const segmentOrdinal of byOrdinal.keys()) {
      if (segmentOrdinal > segments.length) {
        failures.push(`tableRefs 元数据段号 ${segmentOrdinal} 超出文档 CREATE TABLE 数 ${segments.length}`);
      }
    }
  } else {
    let scopedSourceId = scope.sourceId || null;
    if (!scopedSourceId && codeSchema.sources.length === 1) scopedSourceId = codeSchema.sources[0].sourceId;
    for (const segment of segments) {
      if (!scopedSourceId) {
        failures.push(
          `表 ${segment.owner == null ? segment.tableName : `${segment.owner}.${segment.tableName}`} 无法确定所属 source` +
            `（基线有 ${codeSchema.sources.length} 份）：请在实体头部写 sourceId 或数据源，或用 \`## tableRefs\` 绑定四字段引用。`,
        );
        continue;
      }
      const resolved = resolveBaselineObjectByName(
        { owner: segment.owner, name: segment.tableName },
        scopedSourceId,
        index,
      );
      if (resolved.status === 'failure') {
        failures.push(resolved.message);
        continue;
      }
      bindings.push({ segment, tableRef: resolved.status === 'existing' ? resolved.entry.ref : null });
    }
  }

  let hasNewTable = false;
  for (const { segment, tableRef } of bindings) {
    const resolved = tableRef ? resolveBaselineObjectByRef(tableRef, index) : { status: 'new' };
    if (resolved.status === 'failure') {
      failures.push(resolved.message);
      continue;
    }
    if (resolved.status === 'existing') {
      // 存量表：豁免 #8/#9，跑该段基线对照 + 新增列可空
      failures.push(...checkBaselineColumns(segment.text, resolved.entry, segment.tableName));
    } else {
      hasNewTable = true;
    }
  }
  if (hasNewTable) {
    // 新建表：greenfield 全套 #8/#9（结构判据按整篇文档跑，与既有行为一致）
    failures.push(...checkReservedIdentifiers(content).failures);
    collectIdGate(content, idDialect);
  }

  return { ok: failures.length === 0, failures, warnings: idGateWarnings, notes: idGateNotes };
}

// ── helpers ─────────────────────────────────────────────────────────────────
/**
 * 解析 entity DDL 列定义：返回 [{ name, line }]（跳过约束行 PRIMARY KEY/KEY/INDEX/CONSTRAINT/FOREIGN KEY）。
 * 按括号深度切列定义（支持单行/多行两种排版；`decimal(10,2)` 内逗号不切）。
 */
function extractEntityColumns(ddlText) {
  const text = String(ddlText || '');
  const fenced = text.match(/```sql\s*\n([\s\S]*?)```/);
  const ddl = fenced ? fenced[1] : text;
  const openParen = ddl.indexOf('(');
  if (openParen === -1) return [];
  const definitions = [];
  let depth = 0;
  let quote = null;
  let current = '';
  for (let i = openParen; i < ddl.length; i++) {
    const ch = ddl[i];
    if (quote) {
      current += ch;
      if (ch === quote) {
        if (ddl[i + 1] === quote) {
          current += ddl[i + 1];
          i++;
        } else quote = null;
      }
      continue;
    }
    if (ch === "'" || ch === '"' || ch === '`') {
      quote = ch;
      current += ch;
      continue;
    }
    if (ch === '(') {
      depth++;
      if (depth === 1) continue;
    } else if (ch === ')') {
      depth--;
      if (depth === 0) {
        if (current.trim()) definitions.push(current.trim());
        break;
      }
    } else if (ch === ',' && depth === 1) {
      if (current.trim()) definitions.push(current.trim());
      current = '';
      continue;
    }
    current += ch;
  }
  const cols = [];
  const constraintRe = /^(PRIMARY\s+KEY|UNIQUE\s+KEY|UNIQUE\s+INDEX|KEY|INDEX|FULLTEXT|SPATIAL|CONSTRAINT|FOREIGN\s+KEY)\b/i;
  for (const line of definitions) {
    if (constraintRe.test(line)) continue;
    const m = line.match(/^`?([a-z_][\w]*)`?\s+\w+/i);
    if (m) cols.push({ name: m[1].toLowerCase(), line });
  }
  return cols;
}

function checkBaselineColumns(content, baselineEntry, tableName) {
  const failures = [];
  const t = baselineEntry.object;
  const rawDialect = String(
    (baselineEntry.source && baselineEntry.source.dialect) ||
      (baselineEntry.source && baselineEntry.source.binding && baselineEntry.source.binding.dialect) ||
      'mysql',
  ).toLowerCase();
  const dialect =
    rawDialect === 'mariadb'
      ? 'mysql'
      : rawDialect === 'postgres' || rawDialect === 'pg'
        ? 'postgresql'
        : rawDialect === 'dm'
          ? 'dameng'
          : rawDialect;
  const mysqlLike = dialect === 'mysql';
  const postgresLike = dialect === 'postgresql';
  const oracleLike = dialect === 'oracle' || dialect === 'dameng';
  if (!t || !Array.isArray(t.columns)) {
    // 基线对象缺列信息：判坏形状（v2 的对象必须带 columns；不静默跳过）
    return [`基线对象 ${tableName}（${baselineEntry.sourceId}）缺 columns 数组：code-schema v2 形状不完整，拒绝按空基线继续`];
  }
  const entityCols = extractEntityColumns(content);
  const entityColNames = new Set(entityCols.map((c) => c.name));

  // 基线对照：entity 列集 ⊇ code-schema 列集（存量列不得漏保/改名）
  for (const col of t.columns) {
    if (!col || !col.name) continue;
    if (!entityColNames.has(col.name.toLowerCase())) {
      failures.push(`存量列「${tableName}.${col.name}」在 entity DDL 中缺失，违反保存量基线（须逐列照搬 code-schema DDL 原文，不得删/改名/重排；漏保兜底，改名属迁移交 diff backstop）`);
    }
  }

  // 新增列可空 / 方言规则：entity 有、code-schema 无的新列。
  // MySQL 存量表：ddl 不得含 NOT NULL（历史行会违约）。
  // PostgreSQL/Oracle/Dameng：NOT NULL 仅在带 DEFAULT 或 IDENTITY 时允许；禁止 MySQL AUTO_INCREMENT。
  const codeColNames = new Set(t.columns.map((c) => (c.name || '').toLowerCase()));
  for (const ec of entityCols) {
    if (codeColNames.has(ec.name)) continue;
    const hasNotNull = /\bNOT\s+NULL\b/i.test(ec.line);
    const hasDefault = /\bDEFAULT\b/i.test(ec.line);
    const hasIdentity = /\bGENERATED\s+(?:ALWAYS|BY\s+DEFAULT)\s+AS\s+IDENTITY\b|\b(?:BIGSERIAL|SERIAL)\b/i.test(
      ec.line,
    );
    if (mysqlLike) {
      if (hasNotNull) {
        failures.push(`存量表「${tableName}」新增列「${ec.name}」含 NOT NULL（历史行会违约），须允许为空（ddl 不得含 NOT NULL，不论是否有 DEFAULT；业务层后续按需回填后再视情况加约束）`);
      }
      if (hasIdentity) {
        failures.push(`存量表「${tableName}」新增列「${ec.name}」使用 IDENTITY 语法，但基线方言是 MySQL；请改用 AUTO_INCREMENT 或移除`);
      }
      continue;
    }
    const dialectLabel = postgresLike ? 'PostgreSQL' : oracleLike ? 'Oracle/Dameng' : dialect;
    if (hasNotNull && !hasDefault && !hasIdentity) {
      failures.push(
        `存量表「${tableName}」新增列「${ec.name}」在 ${dialectLabel} 下为 NOT NULL 且无 DEFAULT/IDENTITY（历史行会违约），须允许为空或补默认值`,
      );
    }
    if (/\bAUTO_INCREMENT\b/i.test(ec.line) && !mysqlLike) {
      failures.push(
        `存量表「${tableName}」新增列「${ec.name}」使用 MySQL AUTO_INCREMENT，但基线方言是 ${dialectLabel}；请改用 GENERATED ... AS IDENTITY 或序列`,
      );
    }
  }
  return failures;
}

// ── self-test 实现 ──────────────────────────────────────────────────────────
function makeEntity({ module: mod, entity, ddl, header = '' }) {
  return `业务领域：x（${mod}）
${header}${header ? '\n' : ''}
## ${mod}-实体-${entity}

## 字段表

| 字段名 | 类型 | 必填 | 取值范围 | 说明 |
|--------|------|------|----------|------|
| col1 | BIGINT | 是 | 正整数 | 主键 |

## 领域内关系

（无）

## DDL

\`\`\`sql
${ddl}
\`\`\`
`;
}

function selfTest() {
  const failures = [];
  const ok = (name, cond) => { if (!cond) failures.push(`  ${name}: 期望 true 实 false`); };
  const has = (name, arr, substr) => { if (!arr.some((s) => s.includes(substr))) failures.push(`  ${name}: 期望含「${substr}」，实际 ${JSON.stringify(arr)}`); };
  const nothas = (name, arr, substr) => { if (arr.some((s) => s.includes(substr))) failures.push(`  ${name}: 期望不含「${substr}」，实际 ${JSON.stringify(arr)}`); };

  const SRC1 = 'src1.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
  const SRC2 = 'src1.bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb';

  const makeObject = ({ name = 'sys_user', owner = null, columns = [] }) => ({
    owner,
    name,
    quoted: { name: false, owner: false },
    kind: 'table',
    rawDdl: '',
    columns: columns.map((column, ordinal) => ({
      name: column.name,
      ddl: column.ddl ?? 'x',
      source: 'db',
      ordinal,
      hidden: false,
      virtual: false,
    })),
    indexes: [],
    constraints: [],
    foreignKeys: [],
    comments: { table: null, columns: {} },
    tableOptions: null,
    parseIssues: [],
    diffable: true,
  });

  const makeSource = ({ sourceId = SRC1, dataSourceName = 'ds01', objects = [] }) => ({
    sourceId,
    binding: { dataSourceName, entryRef: `datasources.json#${dataSourceName}` },
    databaseType: 'mysql',
    dialect: 'mysql',
    serverVersion: '8.0.36',
    capabilities: ['information_schema'],
    scope: { database: 'demo', owners: [], objectFilter: null },
    channel: 'mcp',
    collectedAt: '2026-10-31T00:00:00.000Z',
    completeness: {
      status: 'complete',
      catalogExpected: objects.length,
      catalogReturned: objects.length,
      objectsParsed: objects.length,
      truncated: false,
      missingPermissions: [],
      evidenceRefs: [],
    },
    objects,
  });

  const makeSchema = (sources) => ({
    schemaVersion: 3,
    generatedAt: '2026-10-31T00:00:00.000Z',
    sources,
  });

  const baselineColumns = [
    { name: 'user_id' },
    { name: 'user_name' },
    { name: 'password' },
    { name: 'create_by' },
    { name: 'create_time' },
  ];
  const codeSchema = makeSchema([
    makeSource({ objects: [makeObject({ columns: baselineColumns })] }),
  ]);

  // 1. 存量表照搬全列 + 新列可空（nick_name DEFAULT NULL）→ ok:true（#8 password/#9 user_id 豁免、无漏保、新列可空）
  {
    const e = makeEntity({ module: '认证', entity: '用户', ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`user_name\` varchar(30) NOT NULL,
  \`password\` varchar(100) DEFAULT NULL,
  \`create_by\` varchar(64) DEFAULT NULL,
  \`create_time\` datetime DEFAULT NULL,
  \`nick_name\` varchar(30) DEFAULT NULL,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, codeSchema);
    ok('1-存量照搬+新列可空 ok', r.ok);
    nothas('1-存量 password 不报 #8', r.failures, 'password」是 SQL 保留字');
    nothas('1-存量 user_id 不报 #9', r.failures, 'id BIGINT NOT NULL AUTO_INCREMENT');
  }

  // 2. 存量表漏保 create_by → 基线对照命中
  {
    const e = makeEntity({ module: '认证', entity: '用户', ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`user_name\` varchar(30) NOT NULL,
  \`password\` varchar(100) DEFAULT NULL,
  \`create_time\` datetime DEFAULT NULL,
  \`nick_name\` varchar(30) DEFAULT NULL,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, codeSchema);
    has('2-漏保 create_by 命中', r.failures, 'create_by');
    has('2-漏保报保存量基线', r.failures, '保存量基线');
  }

  // 3. 存量表新列 NOT NULL → 可空校验命中
  {
    const e = makeEntity({ module: '认证', entity: '用户', ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`user_name\` varchar(30) NOT NULL,
  \`password\` varchar(100) DEFAULT NULL,
  \`create_by\` varchar(64) DEFAULT NULL,
  \`create_time\` datetime DEFAULT NULL,
  \`nick_name\` varchar(30) NOT NULL,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, codeSchema);
    has('3-新列 nick_name NOT NULL 命中', r.failures, 'nick_name');
    has('3-新列报 NOT NULL 违约', r.failures, '历史行会违约');
  }

  // 4. 新建表缺 id → #9 强制命中（新建表全套 #8/#9）
  {
    const e = makeEntity({ module: '线索', entity: '商机', ddl:
`CREATE TABLE crm_lead (
  lead_no varchar(30) NOT NULL,
  PRIMARY KEY (lead_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, codeSchema);
    has('4-新建缺 id 报 #9', r.failures, 'id BIGINT NOT NULL AUTO_INCREMENT');
  }

  // 5. 新建表 password 列 → #8 保留字命中（新建表不豁免 #8）
  {
    const e = makeEntity({ module: '安全', entity: '凭据', ddl:
`CREATE TABLE crm_auth (
  \`password\` varchar(100) NOT NULL,
  id BIGINT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, codeSchema);
    has('5-新建 password 报 #8', r.failures, 'password」是 SQL 保留字');
  }

  // 6. 未知版本 → 拒绝（不回退 v1 tables、不猜 sources）
  {
    const e = makeEntity({ module: '线索', entity: '商机', ddl:
`CREATE TABLE crm_lead (
  lead_no varchar(30) NOT NULL,
  PRIMARY KEY (lead_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, { schemaVersion: 4, sources: [] });
    has('6-未知版本拒绝', r.failures, '只接受 3');
    const legacy = checkIncrementalEntity(e, { schemaVersion: 2, sources: [] });
    has('6-v2 拒绝并给迁移入口', legacy.failures, '重采 v3');
  }

  // 7. 同名表跨两个 source 且实体无 source 声明 → 拒绝（不按裸表名合并，也不静默取第一个）
  {
    const e = makeEntity({ module: '认证', entity: '用户', ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const splitSchema = makeSchema([
      makeSource({ sourceId: SRC1, dataSourceName: 'ds01', objects: [makeObject({ columns: baselineColumns })] }),
      makeSource({ sourceId: SRC2, dataSourceName: 'ds02', objects: [makeObject({ columns: [{ name: 'user_id' }] })] }),
    ]);
    const r = checkIncrementalEntity(e, splitSchema);
    has('7-无 source 声明拒绝', r.failures, '无法确定所属 source');
    nothas('7-不静默取第一个 source', r.failures, '保存量基线');
  }

  // 7b. 同 source 内同名但 owner 不同 → 引用不唯一，拒绝按裸表名合并
  {
    const e = makeEntity({ module: '认证', entity: '用户', header: `sourceId：${SRC1}`, ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const dupSchema = makeSchema([
      makeSource({
        sourceId: SRC1,
        objects: [
          makeObject({ owner: null, columns: baselineColumns }),
          makeObject({ owner: 'dbo', columns: [{ name: 'user_id' }] }),
        ],
      }),
    ]);
    const r = checkIncrementalEntity(e, dupSchema);
    has('7b-同源同名多 owner 拒绝合并', r.failures, '禁止按裸表名合并');
  }

  // 8. 同名跨源 + sourceId 声明 → 按声明命中第二份基线，不合并
  {
    const e = makeEntity({ module: '认证', entity: '用户', header: `sourceId：${SRC2}`, ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`nick_name\` varchar(30) DEFAULT NULL,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const splitSchema = makeSchema([
      makeSource({ sourceId: SRC1, dataSourceName: 'ds01', objects: [makeObject({ columns: baselineColumns })] }),
      makeSource({ sourceId: SRC2, dataSourceName: 'ds02', objects: [makeObject({ columns: [{ name: 'user_id' }] })] }),
    ]);
    const r = checkIncrementalEntity(e, splitSchema);
    ok('8-sourceId 消歧后 ok', r.ok);
    nothas('8-不走另源基线漏保', r.failures, 'create_by');
  }

  // 9. v1 / 顶层 tables → 拒绝（无 v1 回退）
  {
    const e = makeEntity({ module: '认证', entity: '用户', ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;` });
    const r = checkIncrementalEntity(e, { tables: { sys_user: { columns: [{ name: 'user_id' }] } } });
    has('9-顶层 tables 拒绝', r.failures, '不允许顶层 tables');
    has('9-提示重采 v3', r.failures, '重采 v3');
  }

  // 10. 多表文档 + tableRefs 元数据（R18）：逐段绑定，第二张表的漏保独立命中
  {
    const refOf = (name, owner = null) => ({ sourceId: SRC1, owner, kind: 'table', name });
    const e = `${makeEntity({ module: '认证', entity: '用户与角色', ddl:
`CREATE TABLE \`sys_user\` (
  \`user_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  \`user_name\` varchar(30) NOT NULL,
  PRIMARY KEY (\`user_id\`)
);
CREATE TABLE \`sys_role\` (
  \`role_id\` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (\`role_id\`)
);` })}
## tableRefs

\`\`\`json
{"schemaVersion":1,"tableRefs":[${JSON.stringify(refOf('sys_user'))},${JSON.stringify(refOf('sys_role'))}]}
\`\`\`
`;
    const multiSchema = makeSchema([
      makeSource({
        sourceId: SRC1,
        objects: [
          makeObject({ name: 'sys_user', columns: [{ name: 'user_id' }, { name: 'user_name' }] }),
          makeObject({ name: 'sys_role', columns: [{ name: 'role_id' }, { name: 'role_name' }] }),
        ],
      }),
    ]);
    const r = checkIncrementalEntity(e, multiSchema);
    has('10-第二张表漏保命中', r.failures, 'role_name');
    nothas('10-第一张表不误报漏保', r.failures, 'user_name」在 entity DDL 中缺失');
  }

  // 11. 多表文档无 tableRefs 元数据 → 单 source 内按精确名逐段唯一解析
  {
    const e = makeEntity({ module: '认证', entity: '用户与角色', ddl:
`CREATE TABLE \`sys_user\` (\`user_id\` bigint(20) NOT NULL, PRIMARY KEY (\`user_id\`));
CREATE TABLE \`sys_role\` (\`role_id\` bigint(20) NOT NULL, PRIMARY KEY (\`role_id\`));` });
    const singleSchema = makeSchema([
      makeSource({
        sourceId: SRC1,
        objects: [
          makeObject({ name: 'sys_user', columns: [{ name: 'user_id' }] }),
          makeObject({ name: 'sys_role', columns: [{ name: 'role_id' }] }),
        ],
      }),
    ]);
    const r = checkIncrementalEntity(e, singleSchema);
    ok('11-无元数据多表逐段唯一解析通过', r.ok);
  }

  // 12. objectId 身份声明 → 拒绝并给恢复入口
  {
    const e = makeEntity({ module: '认证', entity: '用户', header: 'objectId：obj1.abcdef', ddl:
`CREATE TABLE \`sys_user\` (\`user_id\` bigint(20) NOT NULL, PRIMARY KEY (\`user_id\`));` });
    const r = checkIncrementalEntity(e, codeSchema);
    has('12-objectId 拒绝', r.failures, 'objectId 已退役');
  }

  return failures;
}
