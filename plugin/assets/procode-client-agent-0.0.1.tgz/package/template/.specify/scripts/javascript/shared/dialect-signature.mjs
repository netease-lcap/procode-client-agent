/**
 * 方言签数字典的 mjs 侧读取器（plan 2026-09-21/pg-selection-fidelity §D7：判据结构与参数分离）。
 *
 * 单一真理源：本目录的 dialect-signatures.json——template mjs 门（本文件消费方）同目录读；
 * 服务端 TS（config/shared/dialect-gate.ts）import 同一文件。双端判据永不写裂。
 *
 * 本文件只做读取与键控查找，判断逻辑（四原语）在 TS 引擎；mjs 侧消费点（sql-exec 路由 /
 * check-backend-startup yml 分叉 / extract-code-schema PG 显式红）只用归一与前缀查找。
 * 禁在本文件或消费方再写字面事实（url 前缀/驱动类/坐标）——加类型=字典加行（须过 plan 评审）。
 */

import { readFileSync } from 'fs';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

/** 字典行集（(栈,库) 二维键控；行 schema 见 dialect-signatures.json 顶部注释）。 */
export const dialectSignatures = JSON.parse(
  readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'dialect-signatures.json'), 'utf-8'),
).signatures;

/**
 * databaseType/家族名 → 方言族键的单一归一点（与 TS 引擎 normalizeDatabaseKey 同口径同表：
 * 小写化 + 剥首 token 版本后缀 + 别名表；未知=返回 null 交消费方降级处置，禁静默猜）。
 */
const DATABASE_KEY_ALIASES = {
  mysql: 'MySQL',
  postgresql: 'PostgreSQL',
  postgres: 'PostgreSQL',
  pg: 'PostgreSQL',
  oracle: 'Oracle',
  sqlserver: 'SQLServer',
  mssql: 'SQLServer',
};

export function normalizeDatabaseKey(raw) {
  if (typeof raw !== 'string' || !raw.trim()) return null;
  const firstToken = raw.trim().toLowerCase().split(/\s+/)[0];
  const stem = firstToken.replace(
    /^(postgresql|postgres|mysql|sqlserver|mssql|oracle|pg)(\d+(?:\.\d+)*)?$/,
    '$1',
  );
  return DATABASE_KEY_ALIASES[stem] ?? null;
}

/** (栈, 方言族键) → 字典行；miss=undefined（消费方按判据矩阵处置：字典缺行=放行留痕（2026-09-22 拍板）/ 降级留痕）。 */
export function findDialectSignature(stack, databaseKey) {
  return dialectSignatures.find((row) => row.stack === stack && row.db === databaseKey);
}

/** jdbc url → java-spring 字典行（url 前缀正指纹命中；无命中=null——yml 自报家门的方言判定）。 */
export function dialectByJdbcUrl(url) {
  if (typeof url !== 'string') return null;
  return (
    dialectSignatures.find((row) => row.stack === 'java-spring' && url.includes(row.urlPrefix)) || null
  );
}

/** driver-class-name → java-spring 字典行（驱动类包含匹配；无命中=null）。 */
export function dialectByDriverClass(driverClass) {
  if (typeof driverClass !== 'string') return null;
  return (
    dialectSignatures.find((row) => row.stack === 'java-spring' && driverClass.includes(row.driverClass)) || null
  );
}
