import { readFileSync } from '../../shared/index.mjs';

import { combine } from './tools.mjs';

export const checkerForLineReference = {
  callback:
    (rootDir) =>
    (bundle = {}) => {
      const { absoluteFilePath } = bundle;

      const simpleReg = /\[L[0-9]+[^\n\[\]]+\]/g;
      const source = readFileSync(absoluteFilePath);
      const matched = source.match(simpleReg) || [];

      const array = matched.filter((item = '') => {
        const strictReg = /^\[L[0-9]+,[0-9]+\]$/g;
        const useful = strictReg.test(item);

        return !useful;
      });

      if (!array.length) {
        return;
      }

      const messages = ['### 以下关联段落的行号格式不正确', ''];

      array.forEach((item = '') => {
        const reg = /[0-9]+/g;
        const numbers = item.match(reg) || [];
        const [start, end = start] = numbers;

        messages.push(`- 正确内容：\`[L${start},${end}]\` 当前内容：\`${item}\``);
      });

      return combine(...messages);
    },
};

export default checkerForLineReference;
