#!/usr/bin/env node

import { readFileSync, writeFileSync, existsSync, readdirSync, statSync } from 'fs';
import { resolve, basename, dirname, join } from 'path';
import { fileURLToPath } from 'url';
import { normalizeDatabaseKey } from './shared/dialect-signature.mjs';

// ── checker 边界纪律（plan 2026-11-03/pre-delta-gate-scope-and-checker-boundary §2.4）────
// 本脚本的 `cross-domain-relations` 等门属于 **detect 阶段自检门**：findings 由 detect 的
// `plansCrossDomainDetect.checker`（checkerFeedback: true）定向回灌 agent 返修。纪律：
//   1. 可修性：只报 detect/apply 任务（或其 checkerFeedback 环）**当前有能力修**的 finding；
//   2. 归属：修不了的判据不得塞进本门——前移到拥有修复能力的阶段，或降为 warning/留痕；
//      ScriptPhase 的 `throw` 是终态，只允许放环境缺失/安全红线/schema 坏这类不可修硬失败；
//   3. 证据可判才判：基线缺席时跳过，不得把「还没轮到」当红（fresh/free 无 code-schema）；
//   4. 文案即修法：新增 failure 必须自带修复指令，避免 checker↔prompt 口径漂移式死循环。
// FK 目标主键校验（promote-fk-* 的 targetField）与 mark-snapshot 展示列校验
// （plan 2026-11-03/pre-delta-gate-scope-and-checker-boundary §2.1 / §10）即按此纪律前移到本门；
// 2026-11-03 严格分离（T2）起改为 **opt-in**：仅七阶段 micro-incremental-v1 的 detect checker
// 传 `--require-fk-pk` / `--require-display-column` 时启用；默认调用逐字保持改动前行为
// （fresh/free/monolith/legacy micro 不查）。

// ⚠️ 不在此静态 import `./shared/cross-domain-decl.mjs`（当前契约）：
// 该 shared 文件被 `template/.gitignore` 的 `.specify/*` 忽略（靠 force-add 入库存活），部署面可能缺席。
// 静态 import 会把 `ERR_MODULE_NOT_FOUND` 提前到**模块加载期**，一次性炸掉本脚本全部 mode
// （data-model / cross-domain-fk / cross-domain-decl…），连「缺失」这个明确原因都拿不到。
// 因此只由 `cross-domain-decl` 分支（唯一消费方）在运行时 `await import()`，缺席时输出
// 结构化信封并以 exit 1 收口（见 main() 该分支）。其余 mode 的加载路径与行为逐字不变。

// 顶层可执行派发（allowedModes / cross-domain-fk / content 读取 / architecture / user-stories /
// coverage-gaps / cross-domain-relations / data-model fall-through）移至文件末 main()，
// 经 _isMainEntry guard 仅在直接执行时跑；本处起为纯函数声明，供 check-incremental-entity.mjs
// import { checkEntityStructure, checkReservedIdentifiers, checkIdMandate } 复用。

// ── scenario 取值与判据文案的双支纪律（plan 2026-09-23/plans-free-mode-third-scenario-and-
//    stack-agnostic-clarify D5；dual-review 2026-09-24 P1 补做）────────────────────────────
// 判据的**理由文字**按场景分叉：fresh/incremental 引「build 阶段 Java Entity 的 @Id Long id /
// getById(Long)…」这条本仓真实链路；free 引「外部实现者按本交付面自行编码」——D6 明定自由模式
// **不接 build、无骨架**，原文理由在 free 下是**结构性假陈述**，会把 checkerFeedback 返修环里的
// agent 按一条不存在的链路指路。**byte-exact 双分支，禁同一文案内三元**（D5 分叉纪律）。
//
// 取值优先级（单一来源；禁按产物形态反推场景——那是「派生规则当判据」复发型）：
//   ① `--scenario <fresh|incremental|free>` 显式实参（调用方已知场景；非法值 fail-loud 红）；
//   ② `APP_TECH_STACK_INFO` 环境变量的 `sddModel === 'CLOUD_CLIENT'` 环境门（**D1 的识别机制本体**：
//      scenario **未落盘**，被派发的子进程只能靠环境继承拿到与 `config/shared/profile.ts`
//      `determineScenario` 同源的判据）；
//   ③ 缺省 `fresh`（未传实参且无 env 门 ⇒ 存量调用逐字节回归锁）。
//
// ⚠️ 2026-10-16（plan 2026-10-16/app-tech-stack-info-env-migration D4）：② 的来源由人工开关 env
// （人工置 1 即 free 的那枚，已退役）换成平台注入的 `APP_TECH_STACK_INFO.sddModel`（与 TS 侧
// `plans/shared/env.ts` 的 `isPlansFreeModeEnabled` 同源同判据：**只认字面 `CLOUD_CLIENT`**）。
// **JSON 解析内联在本文件内、不 import 任何 shared 模块**：测试 harness 只拷脚本、不拷其静态 import，
// 新增依赖会制造 ERR_MODULE_NOT_FOUND 死红与「断言存在≠断言执行」的假证据（KG：
// harness-copies-script-not-its-static-imports）。
// **解析失败不红停**（与 TS 侧口径 A/B 的「全兜底」一致，避免两门不对称）：本支只决定**理由文案**，
// 判据本身（保留字门/id 强制门）场景无关、同输入同红同绿 ⇒ 退回缺省 fresh 支 + 一行 warn 即可。
//
// ⚠️ 留痕面口径（与 TS 单点解析器 `config/shared/app-tech-stack-info.ts` 对齐，2026-10-16 dual-review P2）：
// warn **只在真解析异常时**打——`JSON.parse` 抛错 / 顶层不是普通对象（null、数组、原始值）。
// 顶层是普通对象时 `typeof obj.sddModel === 'string' ? obj.sddModel : ''`：**缺 `sddModel` 键 /
// 非 string 一律归空串，不打 warn**——`{"constructionModel":"UPLOAD_SOURCE"}` 这类「只带已知键、
// 不带 sddModel」的形态是**平台正常输出**（TS 侧注释：「把缺字段判成 malformed 会把平台正常形态误报
// 成异常」），若在此 warn，子进程每跑一次吐一条假解析异常，而 TS 父进程是干净命中 ⇒ 两门留痕面失真。
const SCENARIO_VALUES = ['fresh', 'incremental', 'free'];
const APP_TECH_STACK_INFO_ENV = 'APP_TECH_STACK_INFO';
const CLOUD_CLIENT_SDD_MODEL = 'CLOUD_CLIENT';

/**
 * 读 env 里的 `sddModel`：
 *   - 顶层是普通对象 ⇒ `typeof sddModel === 'string' ? sddModel : ''`（缺键/非 string 归空串，
 *     **不留痕**——平台正常形态）；
 *   - `null` 仅表示**真解析异常**（未设/空串 / JSON 坏 / 顶层非对象），调用方据此决定是否 warn。
 * 两种返回都按非 free 处理（free 只认字面 `CLOUD_CLIENT`）。
 */
function readSddModelFromEnv(env = process.env) {
  const raw = env[APP_TECH_STACK_INFO_ENV];
  if (raw === undefined || String(raw).trim() === '') return null;
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    return typeof parsed.sddModel === 'string' ? parsed.sddModel : '';
  } catch {
    // 坏 JSON 不红停（见上方口径注）；留痕交给调用方决定是否 warn。
    return null;
  }
}

function readScenarioArg(argv = process.argv) {
  const idx = argv.indexOf('--scenario');
  if (idx === -1) {
    const sddModel = readSddModelFromEnv();
    // 仅**真解析异常**（JSON 坏 / 顶层非对象）留一行 warn；缺键/非 string 归空串、不打 warn
    //（**不红停**：本支只影响理由文案，不影响判据红绿）。
    if (sddModel === null && String(process.env[APP_TECH_STACK_INFO_ENV] ?? '').trim() !== '') {
      console.warn(
        `[check-backend-design] ${APP_TECH_STACK_INFO_ENV} 在场但解析失败（JSON 坏 / 顶层非对象）——` +
          `scenario 理由文案退回缺省 fresh 支；判据本身（保留字门/id 强制门）场景无关，同输入同红同绿。`,
      );
    }
    return { scenario: sddModel === CLOUD_CLIENT_SDD_MODEL ? 'free' : 'fresh' };
  }
  const value = String(argv[idx + 1] || '').trim();
  if (!SCENARIO_VALUES.includes(value)) {
    return {
      scenario: 'fresh',
      error: `--scenario 取值非法：${JSON.stringify(value)}（应为 fresh|incremental|free；缺省为 fresh）`,
    };
  }
  return { scenario: value };
}

/**
 * 取当前场景的文案支：free 平行体 ‖ fresh/incremental **原文**（后者逐字节不变）。
 * 值的形态可以是定串，也可以是 `(插值) => 串` 的生产者（文案含表名/类型名这类插值时）。
 */
const forScenario = (pair, scenario) => (scenario === 'free' ? pair.free : pair.fresh);

// 保留字门的理由（含表名插值 ⇒ 生产者形态）：free 支去掉 Java/MyBatis 专指载体（自由模式不限语言），
// 换为语言无关的下游载体 + 交付契约口径。
const REASON_RESERVED_TABLE = {
  fresh: (name) =>
    `表名「${name}」是 SQL 保留字，须重命名为非保留字（如 ${name}_info / 业务语义名），禁止用反引号转义保留字——反引号只在 DDL 入口生效，Java Entity 字段名 / MyBatis XML / 字段表 / 跨域关系小节等下游仍裸写该名，跨方言会出错`,
  free: (name) =>
    `表名「${name}」是 SQL 保留字，须重命名为非保留字（如 ${name}_info / 业务语义名），禁止用反引号转义保留字——反引号只在 DDL 入口生效，本交付面的下游载体（实体定义 / 数据访问层语句 / 字段表 / 跨域关系小节）仍裸写该名，跨方言会出错；**外部实现者按本交付面自行编码，此命名约定是交付契约的一部分**`,
};

// id 强制门的理由（定串形态）：free 支把「build 阶段 Java Entity 签名链」换成「外部实现者的
// 持久层按 id 读写/删除依赖此约定」——后者在 free 下才是真陈述（D9 自闭环判据）。
const REASON_ID_PG_MISSING = {
  fresh:
    '每表必须有 `id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY` 代理主键列（PG 方言：禁 AUTO_INCREMENT——PG 无此语法，DDL 直接报错；业务主键可作额外 UNIQUE 约束保留业务唯一性，但不替代 id 主键）——build 阶段 Java Entity 的 @Id Long id / getById(Long) / deleteById(Long) / null id 判空全套签名依赖此约定；PG 下 insert 回读依赖 IDENTITY 生成值（INSERT ... RETURNING），无代理主键则回读链断',
  free:
    '每表必须有 `id BIGINT GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY` 代理主键列（PG 方言：禁 AUTO_INCREMENT——PG 无此语法，DDL 直接报错；业务主键可作额外 UNIQUE 约束保留业务唯一性，但不替代 id 主键）——**本交付面交给外部实现者自行编码**：其持久层实体与按 id 的读写/删除约定一律以此为准；PG 下 insert 回读依赖 IDENTITY 生成值（INSERT ... RETURNING），无代理主键则回读链断',
};

const REASON_ID_MYSQL_MISSING = {
  fresh:
    '每表必须有 `id BIGINT NOT NULL AUTO_INCREMENT` 代理主键列（业务主键如 project_id/work_order_no 可作额外 UNIQUE KEY 保留业务唯一性，但不替代 id 主键）——build 阶段 Java Entity 的 @Id Long id / getById(Long) / deleteById(Long) / null id 判空全套签名依赖此约定',
  free:
    '每表必须有 `id BIGINT NOT NULL AUTO_INCREMENT` 代理主键列（业务主键如 project_id/work_order_no 可作额外 UNIQUE KEY 保留业务唯一性，但不替代 id 主键）——**本交付面交给外部实现者自行编码**：其持久层实体与按 id 的读写/删除约定一律以此为准',
};

const REASON_ID_AUTO_PK_NOT_ID = {
  fresh:
    '有 id AUTO_INCREMENT 列但 PRIMARY KEY 未指向 (id)，须为 `PRIMARY KEY (id)`（结构性校验：build 阶段 Java Entity 的 @Id Long id / getById(Long) / deleteById(Long) 全套签名依赖，方言无关）',
  free:
    '有 id AUTO_INCREMENT 列但 PRIMARY KEY 未指向 (id)，须为 `PRIMARY KEY (id)`（结构性校验：**外部实现者的持久层按 id 读写/删除依赖 id 主键，与方言无关**）',
};

const REASON_ID_IDENTITY_PK_NOT_ID = {
  fresh:
    '有 id GENERATED BY DEFAULT AS IDENTITY 列但 PRIMARY KEY 未指向 id，须为 `PRIMARY KEY (id)`（结构性校验：build 阶段 Java Entity 签名依赖，方言无关）',
  free:
    '有 id GENERATED BY DEFAULT AS IDENTITY 列但 PRIMARY KEY 未指向 id，须为 `PRIMARY KEY (id)`（结构性校验：**外部实现者的持久层按 id 读写/删除依赖 id 主键，与方言无关**）',
};

const REASON_ID_STRUCTURAL_MISSING = {
  fresh:
    '每表必须有代理主键 id 列（BIGINT + PRIMARY KEY 指向 id）——未知类型下无方言形态判据，按方言无关结构校验；build 阶段 Java Entity 的 @Id Long id / getById(Long) / deleteById(Long) / null id 判空全套签名依赖此约定',
  free:
    '每表必须有代理主键 id 列（BIGINT + PRIMARY KEY 指向 id）——未知类型下无方言形态判据，按方言无关结构校验；**外部实现者按本交付面自行编码，其持久层实体与按 id 的读写/删除约定依赖 id 代理主键（与方言无关）**',
};


// ── data-model 三 helper：#1-#7 结构 / #8 保留字 / #9 id 强制 ──────────────────
// scenario 无关的结构检查单一真理源：fresh data-model 全套调用；
// check-incremental-entity.mjs import 后按存量/新建分类选择性调用（存量豁免 #8/#9）。
// 详见 docs/hicode-spec/plan/2026-08-20/split-incremental-entity-checker-from-greenfield-data-model.md
export function checkEntityStructure(content) {
  const failures = [];

  // 1. 必须有 DDL 代码块
  if (!/```sql\s/.test(content)) {
    failures.push('缺少 SQL DDL 代码块 (```sql ... ```)');
  } else {
    // 检查 DDL 代码块内是否有 CREATE TABLE（反引号容忍，对齐 #8/#9 的 CREATE TABLE 正则）
    const sqlMatch = content.match(/```sql\s*\n([\s\S]*?)```/);
    if (!sqlMatch || !/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?(\w+)`?/i.test(sqlMatch[1])) {
      failures.push('DDL 代码块中未找到 CREATE TABLE 语句');
    }
  }

  // 2. 必须有字段表
  if (!/## 字段表/.test(content)) {
    failures.push('缺少「## 字段表」章节');
  } else {
    // 检查字段表是否包含必要列
    const fieldTableSection = content.split('## 字段表')[1]?.split('## ')[0] || '';
    if (!/\|.*字段名.*\|.*类型.*\|.*必填.*\|.*取值范围.*\|.*说明.*\|/.test(fieldTableSection)) {
      failures.push('字段表缺少必要列（字段名|类型|必填|取值范围|说明）');
    }
    // 检查字段表至少有一行数据
    const rows = fieldTableSection.match(/^\|.*\|$/gm) || [];
    if (rows.length < 2) {
      failures.push('字段表至少需要有表头行和一条数据行');
    }
    // 检查每行的"取值范围"列不为空
    const dataRows = rows.slice(2); // skip header and separator
    for (let i = 0; i < dataRows.length; i++) {
      const cols = dataRows[i].split('|').map(c => c.trim());
      if (cols.length >= 5 && !cols[4]) {
        failures.push(`字段表第${i + 1}行「取值范围」列为空`);
      }
    }
  }

  // 3. 必须有「领域内关系」章节
  if (!/## 领域内关系/.test(content)) {
    failures.push('缺少「## 领域内关系」章节');
  }

  // 4. 检查 DDL 中不含枚举引用
  if (/ENUM\s*\(/i.test(content)) {
    failures.push('DDL 中不应包含 ENUM 类型（应使用 TINYINT/VARCHAR + COMMENT 说明取值）');
  }

  // 5. 检查 DDL 中不含 FLOAT
  if (/\bFLOAT\b/i.test(content)) {
    failures.push('DDL 中不应使用 FLOAT 类型（应使用 DECIMAL）');
  }

  // 6. 标题固定格式：## {模块中文名}-实体-{实体中文名}（单行二级标题，为文件首个 ## 标题）
  // 6a. 禁止一级 # 标题：实体中文名已体现在固定二级标题内，不得另起 # 顶层标题（实测模型会在部分实体多套一层 # 中文名）。
  if (/^# [^\n]+\s*$/m.test(content)) {
    const h1 = content.match(/^# ([^\n]+)\s*$/m);
    failures.push(`禁止一级 # 标题（实体名已含于「## {模块中文名}-实体-{实体中文名}」二级标题），实为「# ${h1 ? h1[1].trim() : ''}」——直接删除该 # 整行，不要改写成 ## 标题（否则产生重复固定标题）`);
  }
  {
    // 枚举所有 ## 二级标题行，做收敛性校验：
    //   - 首个 ## 必须是固定格式「{模块中文名}-实体-{实体中文名}」；
    //   - 固定格式的 ## 标题全文件有且仅有一个（防模型把多余的 # 改写成 ## 后产生重复固定标题静默通过）。
    // 收敛性：任一失败都指向"删除多余标题行"，修复终点唯一（仅保留一个固定 ## 标题），不会在多态间振荡。
    const h2Titles = [...content.matchAll(/^## ([^\n]+)\s*$/gm)].map((m) => m[1].trim());
    // 模块中文名允许含连字符（domain.json 的 nameZh 如「客户经营-公海池」「系统管理-用户与登录认证」均含连字符），
    // 实体中文名不含连字符；以「-实体-」为固定分隔，模块名贪婪匹配到最后一个「-实体-」。
    const fixedRe = /^.+-实体-[^-]+$/;
    const fixedTitles = h2Titles.filter((t) => fixedRe.test(t));
    if (h2Titles.length === 0) {
      failures.push('缺少固定标题「## {模块中文名}-实体-{实体中文名}」');
    } else {
      const firstH2 = h2Titles[0];
      if (!fixedRe.test(firstH2)) {
        // 首个 ## 不是固定格式 → 要么是多余的实体名标题，要么缺固定标题
        if (fixedTitles.length > 0) {
          failures.push(`首个 ## 标题不是固定格式（实为「## ${firstH2}」），但文件下方存在固定标题「## ${fixedTitles[0]}」——删除首个多余的「## ${firstH2}」整行，保留下方固定标题`);
        } else {
          failures.push(`标题格式不符：应为「## {模块中文名}-实体-{实体中文名}」，实为「## ${firstH2}」`);
        }
      } else if (fixedTitles.length > 1) {
        // 首个是固定格式但有重复 → 删多余的
        failures.push(`固定标题「## ${fixedTitles[0]}」出现 ${fixedTitles.length} 次，应仅保留一个——删除多余的重复固定标题整行`);
      } else {
        // 标题模块中文名须与头部领域标注一致
        const domainZhMatch = content.match(/业务领域：[^\n]*?[（(]([^）)]+)[）)]/);
        const domainNameZh = domainZhMatch ? domainZhMatch[1] : null;
        // 模块中文名 = 标题去掉「-实体-{实体中文名}」后缀（nameZh 可含连字符，不能再用 split('-')[0] 取首段）
        const moduleNameZh = firstH2.replace(/-实体-[^-]+$/, '');
        if (domainNameZh && moduleNameZh !== domainNameZh) {
          failures.push(`标题模块中文名与领域标注不一致：标题模块「${moduleNameZh}」≠ 领域标注「${domainNameZh}」`);
        }
      }
    }
  }

  // 7. 建表语句标题固定为 ## DDL
  if (!/^## DDL\s*$/m.test(content)) {
    failures.push('缺少建表语句标题「## DDL」（SQL 代码块前应单独一行 ## DDL，禁止用表名/实体名/CREATE TABLE 充当）');
  }

  return { ok: failures.length === 0, failures };
}

// ── DDL 语法门（C1，plan 2026-10-21/design-gate-mechanism-repairs）──────────────
// data-model / cross-domain-fk 共用：最小、方言无关的 DDL 语法判定，不引入 SQL 解析器。
// 只**追加** failures，不短路既有结构/命名/方言判据。真实缺陷两形态：
//   ① `KEY idx_x (x)` / `UNIQUE KEY uk (a, b)` 后缺逗号，下一段直接另起一行；
//   ② `PRIMARY KEY (id),` 尾逗号后直接 `)`。
// 另判：括号/单引号配平、段首形态（列定义或 PRIMARY KEY/UNIQUE KEY/KEY/CONSTRAINT）、
// 表名/ENGINE=/结尾分号。ENGINE= 是 MySQL 系表选项：非 MySQL 真值方言不要求，
// 否则会把 PG/Oracle 原生 DDL 误判红（方言判据仍归 checkIdMandate，本条不改方言规则）。
const DDL_STMT_KEYWORDS = /^(?:PRIMARY\s+KEY|UNIQUE\s+KEY|KEY|CONSTRAINT)\b/i;

// 漏逗号检测：段内续行若以「<列名> <类型>」开头即视为第二个声明起点。
// 只认类型白名单，避免把 `NOT NULL` / `GENERATED ALWAYS` / `DEFAULT CURRENT_TIMESTAMP`
// 等列定义续行误判成漏逗号。
const DDL_TYPE_TOKENS = new Set([
  'BIGINT', 'BIGSERIAL', 'BINARY', 'BIT', 'BLOB', 'BOOL', 'BOOLEAN', 'BYTEA',
  'CHAR', 'CHARACTER', 'CLOB', 'DATE', 'DATETIME', 'DECIMAL', 'DOUBLE', 'ENUM',
  'FLOAT', 'GEOGRAPHY', 'GEOMETRY', 'IDENTITY', 'IMAGE', 'INT', 'INTEGER',
  'INTERVAL', 'JSON', 'JSONB', 'LONGBLOB', 'LONGTEXT', 'MEDIUMBLOB', 'MEDIUMINT',
  'MEDIUMTEXT', 'MONEY', 'NCHAR', 'NCLOB', 'NTEXT', 'NUMBER', 'NUMERIC', 'NVARCHAR',
  'POINT', 'RAW', 'REAL', 'ROWID', 'SERIAL', 'SET', 'SMALLINT', 'SMALLMONEY',
  'SMALLSERIAL', 'TEXT', 'TIME', 'TIMESTAMP', 'TIMESTAMPTZ', 'TINYBLOB', 'TINYINT',
  'TINYTEXT', 'UNIQUEIDENTIFIER', 'UUID', 'VARBINARY', 'VARCHAR', 'VARCHAR2', 'XML',
  'YEAR',
]);

// 列定义续行可能以「CHARACTER SET」/「COLLATE ...」等子句开头，其第二个词恰是类型名
// （如 SET）也不得据此判漏逗号。仅用于漏逗号检测的类型分支。
const DDL_CONTINUATION_LEAD = new Set([
  'CHARACTER', 'CHARSET', 'COLLATE', 'NOT', 'NULL', 'DEFAULT', 'COMMENT',
  'GENERATED', 'ON', 'REFERENCES', 'CHECK', 'USING', 'VISIBLE', 'INVISIBLE',
  'AUTO_INCREMENT', 'UNSIGNED', 'ZEROFILL',
]);

// 段首若命中这些词，说明不是列定义（如 INDEX/FOREIGN KEY/CHECK/FULLTEXT）。
// PRIMARY / UNIQUE / KEY / CONSTRAINT 由 DDL_STMT_KEYWORDS 单独放行，不在此列。
const DDL_NON_COLUMN_LEAD = new Set([
  'INDEX', 'FOREIGN', 'CHECK', 'FULLTEXT', 'SPATIAL', 'EXCLUDE', 'PARTITION', 'LIKE',
  'ENGINE', 'DEFAULT', 'NOT', 'NULL', 'COMMENT', 'COLLATE', 'AUTO_INCREMENT',
  'GENERATED', 'REFERENCES', 'USING', 'WITH', 'TABLESPACE', 'STORAGE', 'CLUSTER',
  'DISTRIBUTE', 'DISTKEY', 'SORTKEY', 'INHERITS', 'OF', 'AS', 'ON', 'AND', 'OR',
  'TRIGGER', 'STORED', 'VIRTUAL', 'CHARSET',
]);

/** 回执展示用：压平空白后截到 80 字符（超长以 ... 结尾）。 */
function ddlSeg80(text) {
  const t = String(text ?? '').replace(/\s+/g, ' ').trim();
  return t.length > 80 ? `${t.slice(0, 77)}...` : t;
}

/** 取位置所在行作为「段」展示；空行退化为起点附近文本。 */
function ddlLineAt(text, pos) {
  const src = String(text ?? '');
  const safePos = Math.max(0, Math.min(pos, Math.max(0, src.length - 1)));
  const lineStart = src.lastIndexOf('\n', safePos - 1) + 1;
  const lineEnd = src.indexOf('\n', safePos);
  const line = src.slice(lineStart, lineEnd === -1 ? src.length : lineEnd);
  const t = line.trim();
  if (t) return ddlSeg80(t);
  const snippet = src.slice(Math.max(0, safePos - 40), safePos + 40);
  return ddlSeg80(snippet) || ddlSeg80(src.slice(0, 80));
}

/**
 * 掩码字符串字面量与注释（保留换行、掩码区宽度不变），供括号/逗号计数：
 *   - 单引号字符串：`''` 转义 + 反斜杠转义；不把字符串内的括号/逗号当语法符号；
 *   - `--` 行注释、块注释同理。
 * 返回未闭合位置，由调用方结构化判红（禁静默吞掉）。
 */
function maskDdlLiteralsAndComments(ddl) {
  const out = ddl.split('');
  let i = 0;
  let unclosedQuotePos = -1;
  let unclosedBlockCommentPos = -1;
  while (i < ddl.length) {
    if (ddl[i] === "'") {
      const start = i;
      out[i] = ' ';
      i += 1;
      let closed = false;
      while (i < ddl.length) {
        if (ddl[i] === '\\' && i + 1 < ddl.length) {
          out[i] = ' ';
          out[i + 1] = ' ';
          i += 2;
          continue;
        }
        if (ddl[i] === "'") {
          if (ddl[i + 1] === "'") {
            out[i] = ' ';
            out[i + 1] = ' ';
            i += 2;
            continue;
          }
          out[i] = ' ';
          i += 1;
          closed = true;
          break;
        }
        if (ddl[i] !== '\n') out[i] = ' ';
        i += 1;
      }
      if (!closed) unclosedQuotePos = start;
      continue;
    }
    if (ddl[i] === '-' && ddl[i + 1] === '-') {
      while (i < ddl.length && ddl[i] !== '\n') {
        out[i] = ' ';
        i += 1;
      }
      continue;
    }
    if (ddl[i] === '/' && ddl[i + 1] === '*') {
      const start = i;
      out[i] = ' ';
      out[i + 1] = ' ';
      i += 2;
      let closed = false;
      while (i < ddl.length) {
        if (ddl[i] === '*' && ddl[i + 1] === '/') {
          out[i] = ' ';
          out[i + 1] = ' ';
          i += 2;
          closed = true;
          break;
        }
        if (ddl[i] !== '\n') out[i] = ' ';
        i += 1;
      }
      if (!closed) unclosedBlockCommentPos = start;
      continue;
    }
    i += 1;
  }
  return { masked: out.join(''), unclosedQuotePos, unclosedBlockCommentPos };
}

/**
 * 最小 DDL 语法门（方言无关）。fileLabel 必须是实体文件名（回执点名落点）。
 * options.requireEngine：MySQL 系（含 tech-stack 缺席的存量形态）要求 `) ENGINE=`；
 * PG/Oracle 等原生 DDL 无此表选项，传 false 以免误判。
 */
export function checkDdlSyntax(content, fileLabel = '', options = {}) {
  const { requireEngine = true } = options;
  const failures = [];
  const sqlMatch = content.match(/```sql\s*\n([\s\S]*?)```/);
  if (!sqlMatch) return { ok: true, failures };
  const ddl = sqlMatch[1];
  if (!ddl.trim()) return { ok: true, failures };

  const fail = (segment, expectation) => {
    failures.push(`${fileLabel}：DDL 语法错误——段「${ddlSeg80(segment)}」${expectation}`);
  };

  const { masked, unclosedQuotePos, unclosedBlockCommentPos } = maskDdlLiteralsAndComments(ddl);
  if (unclosedQuotePos >= 0) {
    fail(ddlLineAt(ddl, unclosedQuotePos), "单引号未成对闭合——SQL 字符串内的单引号须写成 '' 转义，且字符串须有配对结束引号");
    return { ok: false, failures };
  }
  if (unclosedBlockCommentPos >= 0) {
    fail(ddlLineAt(ddl, unclosedBlockCommentPos), '块注释 /* 未闭合——须补 */');
    return { ok: false, failures };
  }

  // 1) 括号配平（字符串/注释内的括号已被掩码，不参与计数）。
  const openStack = [];
  let firstUnmatchedClose = -1;
  for (let i = 0; i < masked.length; i += 1) {
    if (masked[i] === '(') openStack.push(i);
    else if (masked[i] === ')') {
      if (openStack.length === 0) {
        firstUnmatchedClose = i;
        break;
      }
      openStack.pop();
    }
  }
  if (firstUnmatchedClose >= 0) {
    fail(ddlLineAt(ddl, firstUnmatchedClose), '括号不配平（出现多余的 )）——建表块内 ( 与 ) 须成对');
    return { ok: false, failures };
  }
  if (openStack.length > 0) {
    fail(
      ddlLineAt(ddl, openStack[openStack.length - 1]),
      `括号不配平（缺少 ${openStack.length} 个 )）——建表块内 ( 与 ) 须成对`,
    );
    return { ok: false, failures };
  }

  const createMatch = masked.match(/CREATE\s+TABLE\b/i);
  if (!createMatch) return { ok: true, failures }; // 缺 CREATE TABLE 由结构门负责（本门只判已存在的语句）
  const createIdx = createMatch.index;
  let cursor = createIdx + createMatch[0].length;
  const ifNotExists = masked.slice(cursor).match(/^\s+IF\s+NOT\s+EXISTS\b/i);
  if (ifNotExists) cursor += ifNotExists[0].length;

  // 4) 表名
  const nameMatch = masked
    .slice(cursor)
    .match(/^\s+((?:`[^`\n]+`|"[^"\n]+"|[A-Za-z_][\w$]*)(?:\s*\.\s*(?:`[^`\n]+`|"[^"\n]+"|[A-Za-z_][\w$]*))?)/);
  if (nameMatch) {
    cursor += nameMatch[0].length;
  } else {
    fail(ddlLineAt(ddl, createIdx), '缺少表名——应为 CREATE TABLE <表名> ( ... );');
  }

  const openIdx = masked.indexOf('(', cursor);
  if (openIdx < 0) {
    fail(ddlLineAt(ddl, createIdx), '缺少建表块括号——应为 CREATE TABLE <表名> ( <列定义/键定义> ) ENGINE=...;');
    return { ok: false, failures };
  }
  let depth = 0;
  let closeIdx = -1;
  for (let i = openIdx; i < masked.length; i += 1) {
    if (masked[i] === '(') depth += 1;
    else if (masked[i] === ')') {
      depth -= 1;
      if (depth === 0) {
        closeIdx = i;
        break;
      }
    }
  }
  if (closeIdx < 0) {
    fail(ddlLineAt(ddl, openIdx), '建表块缺少配对的 )——CREATE TABLE ( ... ) 须闭合');
    return { ok: false, failures };
  }

  const bodyRaw = ddl.slice(openIdx + 1, closeIdx);
  const bodyMasked = masked.slice(openIdx + 1, closeIdx);
  if (!bodyMasked.trim()) {
    fail(ddlLineAt(ddl, openIdx), '建表块为空——CREATE TABLE ( ... ) 内须至少有一条列定义或键定义');
    return { ok: false, failures };
  }

  // 2) 以掩码文本在顶层深度切段：嵌套括号内的逗号（如 UNIQUE KEY uk (a, b)）不是段分隔符。
  const segments = [];
  let segDepth = 0;
  let segStart = 0;
  for (let i = 0; i < bodyMasked.length; i += 1) {
    if (bodyMasked[i] === '(') segDepth += 1;
    else if (bodyMasked[i] === ')') segDepth -= 1;
    else if (bodyMasked[i] === ',' && segDepth === 0) {
      segments.push({ start: segStart, end: i });
      segStart = i + 1;
    }
  }
  segments.push({ start: segStart, end: bodyMasked.length });

  const lastSeg = segments[segments.length - 1];
  const lastSegText = bodyMasked.slice(lastSeg.start, lastSeg.end);
  if (segments.length > 1 && !lastSegText.trim()) {
    const prevSeg = segments[segments.length - 2];
    fail(`${bodyRaw.slice(prevSeg.start, prevSeg.end).trim()},`, '最后一段不得以逗号结尾（尾逗号）——应删除该段末尾的 ,，让 ) 紧随最后一条声明');
  }

  for (let s = 0; s < segments.length; s += 1) {
    const seg = segments[s];
    const rawSeg = bodyRaw.slice(seg.start, seg.end);
    const maskedSeg = bodyMasked.slice(seg.start, seg.end);
    const isLast = s === segments.length - 1;
    if (!maskedSeg.trim()) {
      if (!isLast) fail(rawSeg, '段为空——相邻两段之间出现了多余逗号，或缺少列/键声明');
      continue; // 尾逗号已单独报
    }

    // 3) 段首形态：列定义 <ident> <type>… 或 PRIMARY KEY / UNIQUE KEY / KEY / CONSTRAINT。
    const normalized = maskedSeg.trim().replace(/`/g, '').replace(/"/g, '');
    const firstWordMatch = normalized.match(/^([A-Za-z_][\w$]*)/);
    const firstWord = firstWordMatch ? firstWordMatch[1].toUpperCase() : '';
    let startOk = DDL_STMT_KEYWORDS.test(normalized);
    if (!startOk && firstWord && !DDL_NON_COLUMN_LEAD.has(firstWord)) {
      const colDef = normalized.match(/^[A-Za-z_][\w$]*\s+([A-Za-z_][\w$]*)/);
      startOk = !!colDef && !DDL_NON_COLUMN_LEAD.has(colDef[1].toUpperCase());
    }
    if (!startOk) {
      fail(rawSeg, '不是合法声明——每段须以列定义「<列名> <类型> …」或 PRIMARY KEY / UNIQUE KEY / KEY / CONSTRAINT 开头');
    }

    // 2) 除最后一段外每段须以逗号结尾：漏逗号会把两段声明并进同一段。
    //    以首个非空行为段首，其后任一非空行再次出现声明起点即点名该段（含最后一段）。
    let seenFirst = false;
    for (const line of maskedSeg.split('\n')) {
      const t = line.trim();
      if (!t) continue;
      if (!seenFirst) {
        seenFirst = true;
        continue;
      }
      const normLine = t.replace(/`/g, '').replace(/"/g, '');
      let nextDecl = DDL_STMT_KEYWORDS.test(normLine);
      if (!nextDecl) {
        const mm = normLine.match(/^([A-Za-z_][\w$]*)\s+([A-Za-z_][\w$]*)/);
        nextDecl = !!mm
          && !DDL_CONTINUATION_LEAD.has(mm[1].toUpperCase())
          && DDL_TYPE_TOKENS.has(mm[2].toUpperCase());
      }
      if (nextDecl) {
        fail(rawSeg, `缺少分隔逗号——本段内出现第二个声明起点「${ddlSeg80(t)}」，除最后一段外每段末尾必须写 ,`);
        break;
      }
    }
  }

  // 4) 语句尾部：ENGINE=（MySQL 系）与结尾分号。
  const tailMasked = masked.slice(closeIdx + 1);
  const semiIdx = tailMasked.indexOf(';');
  const stmtTailMasked = semiIdx >= 0 ? tailMasked.slice(0, semiIdx) : tailMasked;
  const stmtTailRaw = ddl.slice(closeIdx + 1, semiIdx >= 0 ? closeIdx + 1 + semiIdx : ddl.length);
  if (requireEngine && !/\bENGINE\s*=/i.test(stmtTailMasked)) {
    fail(stmtTailRaw.trim() || ')', '缺少 ENGINE= 表选项——MySQL 系建表语句须写成 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ...;');
  }
  if (semiIdx < 0) {
    fail(stmtTailRaw.trim() || ddlLineAt(ddl, ddl.trim().length - 1), '缺少语句结束分号 ;——每条 CREATE TABLE 语句须以 ; 结尾');
  }

  return { ok: failures.length === 0, failures };
}

export function checkReservedIdentifiers(content, scenario = 'fresh') {
  const failures = [];
  // 8. 标识符不得为 SQL 保留字（重命名，禁反引号转义）
  // 多方言 reserved 并集（MySQL 8.0 ∪ PostgreSQL ∪ SQL Server ∪ Oracle reserved）。
  // 命中须重命名——反引号只在 DDL 入口转义，Java Entity 字段名/MyBatis XML/字段表/
  // 跨域关系小节等下游仍裸写该名，跨方言会出错。宁纳入不漏（被报的重命名即可消除）。
  const sqlMatch = content.match(/```sql\s*\n([\s\S]*?)```/);
  if (sqlMatch) {
    const ddl = sqlMatch[1];
    const RESERVED = new Set([
      // MySQL 8.0 reserved
      'accessible','add','all','alter','analyze','and','as','asc','asensitive',
      'before','between','bigint','binary','blob','both','by','call','cascade',
      'case','change','char','character','check','collate','column','condition',
      'constraint','continue','convert','create','cross','cube','cume_dist',
      'current_date','current_time','current_timestamp','current_user','cursor',
      'database','databases','day_hour','day_microsecond','day_minute','day_second',
      'dec','decimal','declare','default','delayed','delete','dense_rank','desc',
      'describe','deterministic','distinct','distinctrow','div','double','drop',
      'dual','each','else','empty','enclosed','escaped','except','exists','exit',
      'explain','false','fetch','first_value','float','for','force','foreign',
      'from','fulltext','function','generated','get','grant','group','grouping',
      'groups','having','high_priority','hour_microsecond','hour_minute','hour_second',
      'if','ignore','in','index','infile','inner','inout','insensitive','insert',
      'int','integer','interval','into','io_after_gtids','io_before_gtids','is',
      'iterate','join','json_table','key','kill','lag','last_value','lateral','lead',
      'leading','leave','left','like','limit','linear','lines','load','localtime',
      'localtimestamp','lock','long','longblob','longtext','loop','low_priority',
      'master_bind','master_heartbeat_period','master_ssl_verify_server_cert','match',
      'mediumblob','mediumint','mediumtext','middleint','minute_microsecond',
      'minute_second','mod','modifies','natural','not','no_write_to_binlog',
      'nth_value','ntile','null','numeric','of','on','optimize','optimizer_costs',
      'option','optionally','or','order','out','outer','outfile','over','partition',
      'percent_rank','precision','primary','procedure','range','rank','read',
      'read_only','read_write','reads','real','recursive','references','regexp',
      'release','rename','repeat','replace','require','resignal','restrict','return',
      'revoke','right','rlike','row','rows','row_number','schema','schemas',
      'second_microsecond','select','sensitive','separator','set','show','signal',
      'smallint','spatial','specific','sql','sqlexception','sqlstate','sqlwarning',
      'sql_big_result','sql_calc_found_rows','sql_small_result','ssl','starting',
      'stored','straight_join','system','table','terminated','then','tinyblob',
      'tinyint','tinytext','to','trailing','trigger','true','undo','union','unique',
      'unlock','unsigned','update','usage','use','user','using','utc_date','utc_time',
      'utc_timestamp','values','varbinary','varchar','varcharacter','varying','virtual',
      'when','where','while','window','with','write','xor','year_month','zerofill',
      // PostgreSQL reserved（补充 MySQL 未含）
      'analysis','array','async','at','authorization','backward','cache','catalog',
      'class','cluster','collation','comment','concurrently','confidence',
      'configuration','connection','copy','cost','csv','data','day','do','document',
      'domain','ddl','detach','dict','dictionary','disable','discard','dump','enable',
      'encoding','encryption','enum','escape','event','exclude','excluding',
      'exclusive','extension','external','family','filter','first','following',
      'forward','freeze','global','granted','handler','header','hold','identity',
      'ilike','immediate','immutable','implicit','include','including','increment',
      'indexes','inherit','inherits','inline','input','invoker','keys','label',
      'language','large','last','leader','level','listener','location','locked','log',
      'logging','mapped','mapping','matched','materialized','maxvalue','method','mode',
      'month','move','name','names','national','nchar','new','next','no','nothing',
      'notify','nowait','nullif','object','off','offset','oids','old','operator',
      'options','overriding','owned','owner','parallel','parser','partial','passing',
      'password','percent','persist','placing','plans','policy','preceding','prepare',
      'prepared','preserve','prior','private','privileges','program','publication',
      'quote','read','reassign','recheck','ref','referencing','refresh','reindex',
      'relative','release','repeatable','replica','reset','restart','restore','returning',
      'role','rollback','rollup','routine','rule','savepoint','scroll','search','second',
      'security','sequence','sequences','serializable','server','session','share',
      'simple','skip','snapshot','some','stable','standalone','standby','start',
      'statement','statistics','stdin','stdout','storage','strict','strip',
      'subscription','symmetric','sysid','tables','tablespace','temp','template',
      'temporary','text','transform','truncate','try','type','types','unbounded',
      'uncommitted','unencrypted','unlisten','unlogged','until','vacuum','valid',
      'validate','validator','value','variable','variadic','verbose','version','views',
      'volatile','whitespace','work','wrapper','xml','xmlroot','yes',
      // SQL Server reserved（补充未含）
      'compute','disk','merge','nvarchar','ntext','plan','rowguidcol','session_user',
      'textsize','tsequal',
      // Oracle reserved（补充未含）
      'audit','compress','exclusive','file','maxextents','noaudit','nowait','number',
      'offline','online','pctfree','pctincrease','pctused','raw','rowid','rownum',
      'share','size','success','synonym','uid','varchar2','verify',
    ]);
    // 表名（CREATE TABLE 后，可能带反引号——反引号不消除保留字判定，须重命名）
    const tblM = ddl.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([a-z_][\w]*)`?/i);
    if (tblM && RESERVED.has(tblM[1].toLowerCase())) {
      failures.push(forScenario(REASON_RESERVED_TABLE, scenario)(tblM[1]));
    }
    // 列名（跳过约束行 PRIMARY KEY / UNIQUE KEY / KEY / INDEX / CONSTRAINT / FOREIGN KEY）
    // 同名列只报一次（DDL 内可能被多行引用）
    const seenCols = new Set();
    for (const line of ddl.split('\n')) {
      if (/^\s*(PRIMARY\s+KEY|UNIQUE\s+KEY|UNIQUE\s+INDEX|KEY|INDEX|FULLTEXT|SPATIAL|CONSTRAINT|FOREIGN\s+KEY)\b/i.test(line)) continue;
      const m = line.match(/^\s*`?([a-z_][\w]*)`?\s+(VARCHAR|BIGINT|INT|INTEGER|SMALLINT|TINYINT|DATETIME|DATE|TIME|TIMESTAMP|TEXT|DECIMAL|NUMERIC|FLOAT|DOUBLE|CHAR|BLOB|BOOLEAN|BOOL|JSON|ENUM)\b/i);
      if (m && !seenCols.has(m[1].toLowerCase()) && RESERVED.has(m[1].toLowerCase())) {
        seenCols.add(m[1].toLowerCase());
        failures.push(`列名「${m[1]}」是 SQL 保留字，须重命名为非保留字（如 ${m[1]}_name / ${m[1]}_code / 业务语义名），禁止用反引号转义保留字`);
      }
    }
  }
  return { ok: failures.length === 0, failures };
}

// ── 方言真值解析（plan 2026-09-21/pg-selection-fidelity §D2）─────────────────
// 主键门方言感知的单一取值点：从 entity 文件路径逐级向上找 plans/tech-stack.json 的
// database.type，经 normalizeDatabaseKey 归一为方言族键。entity 落在
// <docs>/<轮>/plans/backend/_meta/per-domain/<域>/ 下，向上 4 级即 plans/ 层（tech-stack.json 所在），
// 上限 8 级防御冗余。返回 { key, raw, parseError }：
//   key=null 且 raw 非空 = 未知类型（归一不命中）；
//   三者皆 falsy = tech-stack 缺席（调用方按 MySQL 存量形态处理——回归锁：存量 round
//   无 tech-stack 时行为逐字节不变，对齐 B5 rev2「databaseType 缺席按存量 MySQL 形态」拍板）；
//   parseError 非空 = 文件在场但不可解析——调用方必须结构化红，禁回落 MySQL 假绿
//   （dual-review 2026-09-21 P2 修复：证据不可解析禁 skip 兜底，已知坑 #3）。
export function resolveDialectFromEntityPath(filePath) {
  try {
    let dir = dirname(resolve(filePath));
    for (let i = 0; i < 8 && dir; i++) {
      const tsPath = join(dir, 'tech-stack.json');
      if (existsSync(tsPath)) {
        try {
          const json = JSON.parse(readFileSync(tsPath, 'utf-8')) || {};
          const raw = typeof json?.database?.type === 'string' ? json.database.type.trim() : '';
          if (!raw) return { key: null, raw: null, parseError: null };
          return { key: normalizeDatabaseKey(raw), raw, parseError: null };
        } catch (e) {
          return { key: null, raw: null, parseError: e.message };
        }
      }
      const parent = dirname(dir);
      if (parent === dir) break;
      dir = parent;
    }
  } catch {
    /* fallthrough：目录遍历异常按缺席处理 */
  }
  return { key: null, raw: null, parseError: null };
}

export function checkIdMandate(content, dialectKey = 'MySQL', scenario = 'fresh') {
  const failures = [];
  // 降级留痕通道（对齐 check-dialect-consistency 返回形态 {ok, failures, warnings, notes}）：
  // warnings=已知族指纹让步（兼容模式）、notes=无方言信号的结构过——禁静默放行（已知坑：证据不可判必须留痕）。
  const warnings = [];
  const notes = [];
  // 9. 每表必须有代理主键 id（方言感知，plan 2026-09-21/pg-selection-fidelity §D2）
  // build 阶段 Java Entity 的 @Id Long id / getById(Long) / deleteById(Long) /
  // null id 判空全套签名依赖此约定；业务主键作额外唯一键保留但不替代 id 主键。
  // 方言分叉：MySQL=AUTO_INCREMENT 形态（缺 tech-stack 的存量 round 回归锁同此）；
  // PG=GENERATED BY DEFAULT AS IDENTITY 形态。判据矩阵（plan 2026-09-22/dialect-dictionary-miss-full-pass）：
  // 归一命中但字典缺行（如 oracle）=放行留痕（2026-09-22 拍板：判据只作用于字典有行的方言，
  // 缺行族信任生成侧，终局实建+启动仲裁）；未知类型（归一 null）
  // =矩阵降级：跨族混杂→自洽红 / 单族命中→按该族校验 PK 一致性（结构性，非方言判据）
  // +警告留痕让步（「DM MySQL 兼容模式合法用 AUTO_INCREMENT，硬红会误杀」，终局实建+启动仲裁）/
  // 无族指纹→方言无关结构校验。与 check-dialect-consistency.mjs 同矩阵同口径。
  const sqlMatch = content.match(/```sql\s*\n([\s\S]*?)```/);
  if (sqlMatch) {
    const ddl = sqlMatch[1];
    if (dialectKey === 'PostgreSQL') {
      const hasIdIdentity = /^\s*`?id`?\s+BIGINT\b[^\n,]*GENERATED\s+BY\s+DEFAULT\s+AS\s+IDENTITY/im.test(ddl);
      const hasPkIdInline = /^\s*`?id`?\s+BIGINT\b[^\n,]*PRIMARY\s+KEY/im.test(ddl);
      const hasPkIdLine = /PRIMARY\s+KEY\s*\(\s*`?id`?\s*\)/i.test(ddl);
      if (!hasIdIdentity) {
        failures.push(forScenario(REASON_ID_PG_MISSING, scenario));
      } else if (!hasPkIdInline && !hasPkIdLine) {
        failures.push('有 id GENERATED BY DEFAULT AS IDENTITY 列但 PRIMARY KEY 未指向 id，须为 `PRIMARY KEY (id)`（或 id 列定义行内联 PRIMARY KEY）');
      }
    } else if (dialectKey === 'MySQL') {
      const hasIdAuto = /^\s*`?id`?\s+BIGINT\b[^\n,]*AUTO_INCREMENT/im.test(ddl);
      const hasPkId = /PRIMARY\s+KEY\s*\(\s*`?id`?\s*\)/i.test(ddl);
      if (!hasIdAuto) {
        failures.push(forScenario(REASON_ID_MYSQL_MISSING, scenario));
      } else if (!hasPkId) {
        failures.push('有 id AUTO_INCREMENT 列但 PRIMARY KEY 未指向 (id)，须为 `PRIMARY KEY (id)`');
      }
    } else if (dialectKey.startsWith('未知类型(')) {
      // 未知类型（归一 null）——D7 判据矩阵降级路径（plan 2026-09-21 §D7 判据矩阵 DDL 行
      // 未知类型列：自洽失败→硬红；已知族指纹→警告留痕让步，终局实建+启动仲裁）。
      // 与 check-dialect-consistency.mjs 同矩阵同口径；下方 else（已知族缺行）=放行留痕（2026-09-22 拍板）。
      // 形态识别正则复用上方 MySQL/PG 分支定义（禁新造逐字判据——已知坑 framework-rowkey 死锁形态）。
      const raw = dialectKey.slice('未知类型('.length, -1);
      const hasIdAuto = /^\s*`?id`?\s+BIGINT\b[^\n,]*AUTO_INCREMENT/im.test(ddl);
      const hasIdIdentity = /^\s*`?id`?\s+BIGINT\b[^\n,]*GENERATED\s+BY\s+DEFAULT\s+AS\s+IDENTITY/im.test(ddl);
      if (hasIdAuto && hasIdIdentity) {
        failures.push(`方言自洽失败：未知类型「${raw}」下主键列形态跨族混杂（AUTO_INCREMENT 与 GENERATED BY DEFAULT AS IDENTITY 并存）——须统一为选型方言形态（D7 判据矩阵：自洽失败硬红）`);
      } else if (hasIdAuto) {
        const hasPkId = /PRIMARY\s+KEY\s*\(\s*`?id`?\s*\)/i.test(ddl);
        if (!hasPkId) {
          failures.push(forScenario(REASON_ID_AUTO_PK_NOT_ID, scenario));
        } else {
          warnings.push(`未知类型「${raw}」主键列呈 MySQL 族形态（AUTO_INCREMENT）——兼容模式让步，本门放过，终局由实建+启动仲裁（D7 判据矩阵降级路径）`);
        }
      } else if (hasIdIdentity) {
        const hasPkIdInline = /^\s*`?id`?\s+BIGINT\b[^\n,]*PRIMARY\s+KEY/im.test(ddl);
        const hasPkIdLine = /PRIMARY\s+KEY\s*\(\s*`?id`?\s*\)/i.test(ddl);
        if (!hasPkIdInline && !hasPkIdLine) {
          failures.push(forScenario(REASON_ID_IDENTITY_PK_NOT_ID, scenario));
        } else {
          warnings.push(`未知类型「${raw}」主键列呈 PostgreSQL 族形态（GENERATED BY DEFAULT AS IDENTITY）——兼容模式让步，本门放过，终局由实建+启动仲裁（D7 判据矩阵降级路径）`);
        }
      } else {
        // 无已知族指纹：方言无关结构校验（id 代理主键在场→notes 留痕放行；缺席→结构红）。
        const hasStructuralIdPk =
          /^\s*`?id`?\s+BIGINT\b[^\n,]*PRIMARY\s+KEY/im.test(ddl) ||
          /PRIMARY\s+KEY\s*\(\s*`?id`?\s*\)/i.test(ddl);
        if (hasStructuralIdPk) {
          notes.push(`未知类型「${raw}」主键列无已知族方言指纹，按方言无关结构校验过（id 代理主键在场）——终局由实建+启动仲裁（D7 判据矩阵降级路径）`);
        } else {
          failures.push(forScenario(REASON_ID_STRUCTURAL_MISSING, scenario));
        }
      }
    } else {
      // 字典缺行族（归一命中但 dialect-signatures.json 无该 (stack, db) 行，如 oracle/sqlserver）。
      // 2026-09-22 拍板：判据只作用于字典有行的方言，缺行族主键门不走任何方言判据，
      // 放行留痕（notes 不拦截）；误写由终局实建+启动仲裁兜底。
      notes.push(`字典缺行族（databaseType=${dialectKey}）无方言判据：主键门方言判据跳过放行（2026-09-22 拍板），终局实建+启动仲裁`);
    }
  }
  return { ok: failures.length === 0, failures, warnings, notes };
}

// data-model fall-through 派发移至文件末 main()（_isMainEntry guard）。

// ── 跨域 FK 自洽检查 ───────────────────────────────────────────────────────
// 取代已删的 checkRelations dead code（relations.md 已被 2026-08-06/remove-relations-md.md 主动废弃）。
// 不依赖 relations.md，查 entity DDL 内部的跨域 FK 自洽：
//   1. 跨域 FK 列存在性：字段表「说明」列含 FK 信号词但 DDL 对应列是 VARCHAR 而非 *_id BIGINT → failure（降级）。
//   2. 跨域 FK COMMENT 指表：DDL 列名 *_id 且 COMMENT 含「FK 引用」但目标写概念而非 <table>.id → failure。
//   3. 跨域关系小节存在：有 *_id 跨域 FK 列的 entity 必须有「## 跨域关系」小节声明该 FK → failure（build 自推导的信息源缺失）。
// 输入 filePath 为任一 entity-*.md 绝对路径（与 data-model 模式同口径），从其所在目录扫描全部 entity-*.md。
function parseEntityFkColumns(entityText) {
  // 解析单 entity DDL 的潜在 FK 列：列名 *_id 且类型 BIGINT（不论领域内还是跨域——检查 2 再验 COMMENT 是否指表）。
  const fkCols = [];
  const sqlMatch = entityText.match(/```sql\s*\n([\s\S]*?)```/);
  if (!sqlMatch) return { tableName: null, fkCols };
  const ddl = sqlMatch[1];
  // 提取 CREATE TABLE 块内的列定义行
  const createMatch = ddl.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?(\w+)`?[\s\S]*?\)/i);
  const tableName = createMatch ? createMatch[1].toLowerCase() : null;
  const colRe = /^\s*`?(\w+)`?\s+(BIGINT|VARCHAR|INT|TEXT|DECIMAL|DATETIME|TINYINT)[^,]*(?:,\s*(?:--[^\n]*|\/\*[\s\S]*?\*\/))?/gim;
  let m;
  while ((m = colRe.exec(ddl)) !== null) {
    const colName = m[1].toLowerCase();
    const colType = m[2].toUpperCase();
    const lineRest = m[0];
    // 潜在 FK 列：列名 *_id 且类型 BIGINT（领域内 FK 如 team_id 也在内，检查 2 区分指表 vs 概念占位）
    if (/_id$/.test(colName) && colType === 'BIGINT') {
      // 提取 COMMENT 里的目标引用
      const commentMatch = lineRest.match(/COMMENT\s*'([^']*)'/i);
      const comment = commentMatch ? commentMatch[1] : '';
      fkCols.push({ colName, colType, comment });
    }
  }
  return { tableName, fkCols };
}

// 零实体合法出口判定（供 cross-domain-fk 目录模式复用）：目录下无 entity-*.md 时，
// 仅当权威声明 ENTITY-CANONICAL-NONE.md 存在，且 _meta/cross-domain-relations.json 显式声明
// zeroEntity=true 且 relations/unresolved 皆空时，视为合法零实体。
// ⚠️ 口径注记（dual-review F10，2026-09-25）：checkCrossDomainRelations 的零实体放行分支自 P0 起
// 额外要求能力矩阵投影可判 + requirement-coverage 无未处置 conflict，**本出口有意不同步**这两项
// 前提（fk 门为结构收口二遍把关，矩阵接线随 P2 轴扩容统一落，届时同步）——本注释即实况，禁再写
// 「同口径」。顺延登记：axis-registry plan §12.3。
function isLegalZeroEntityDir(entityDir) {
  try {
    if (!existsSync(resolve(entityDir, 'ENTITY-CANONICAL-NONE.md'))) return false;
    const relPath = resolve(entityDir, '_meta', 'cross-domain-relations.json');
    if (!existsSync(relPath)) return false;
    const data = JSON.parse(readFileSync(relPath, 'utf-8'));
    return data.zeroEntity === true
      && Array.isArray(data.relations) && data.relations.length === 0
      && Array.isArray(data.unresolved) && data.unresolved.length === 0;
  } catch {
    return false;
  }
}

function checkCrossDomainFk(filePath) {
  const failures = [];

  // 目录/文件分流：传文件→只查该文件（单 agent 自检口径，对齐 harden-stage2 改动1"传单文件禁目录"嘱托，
  // cross-domain-fk 检查1/2/3 全 per-entity 局部无跨实体查表，单文件 scope 不丢能力）；传目录→扫全（终检口径）。
  let entityDir;
  let entityFiles = [];
  try {
    const st = statSync(filePath);
    if (st.isDirectory()) {
      entityDir = filePath;
      for (const entry of readdirSync(entityDir)) {
        if (!/^entity-.*\.md$/.test(entry)) continue;
        let text;
        try {
          text = readFileSync(resolve(entityDir, entry), 'utf-8');
        } catch {
          continue;
        }
        entityFiles.push({ file: entry, text });
      }
    } else {
      entityDir = resolve(filePath, '..');
      entityFiles = [{ file: basename(filePath), text: readFileSync(filePath, 'utf-8') }];
    }
  } catch (e) {
    return { ok: false, failures: [`无法读取 entity 路径：${filePath}（${e.message}）`] };
  }
  // 域标注真值（D2）：域清单位置只依赖被检路径，目录模式只读一次并复用（cache）。
  // 不适用（domain.json 缺席 / domains 空）⇒ 无 failure；不可判（文件坏）⇒ 每个被检文件各记一条。
  const domainCatalogCache = new Map();
  const domainCatalog = resolveDomainCatalog(filePath, domainCatalogCache);
  const domainContext = createDomainLabelContext();

  if (entityFiles.length === 0) {
    // 零实体合法出口：本系统无业务表、无 entity-*.md 时为合法场景（见 checkCrossDomainRelations 注释）。
    // 目录下存在权威零实体声明 ENTITY-CANONICAL-NONE.md 且 _meta/cross-domain-relations.json#zeroEntity=true 时放行；
    // 否则维持原失败（真漏产出仍报错）。
    if (isLegalZeroEntityDir(entityDir)) {
      return { ok: true, failures: [] };
    }
    return { ok: false, failures: [`未在 ${entityDir} 找到 entity-*.md 文件`] };
  }

  // FK 信号词（出现在字段表「说明」列 → 疑似跨域 FK 引用）
  const FK_SIGNAL_RE = /关联\s*\S*\s*表|手动选择|来源\s*\S*\s*人员|来源组织架构|选择器|下拉选择|引用\s*\S*\s*(?:人员|概念|标识)/;
  // 快照标注（B 类合规快照字段豁免）：COMMENT/说明含这些标注 → 已合规 B 类，不报"降级 VARCHAR"失败
  // 0818 实体实证标注用语：general_manager "快照，非本系统 FK，来源一单制"、current_process_code "编码快照，来源维修执行域...非本系统 FK"、
  // project_id/ship_name_cn "快照，来源单船信息"、equipment_type "来源设备唯一码"。
  // 职责：对未标注的 VARCHAR FK 信号列报失败；已标注的视为 B 类合规（是否应升 A 类由波2 收口任务 prompt 判定，检查只兜"漏标"）。
  const SNAPSHOT_MARK_RE = /快照|非本系统\s*FK|冗余自|来源一单制|来源外部|来源单船信息|来源设备唯一码|来源维修执行域|编码快照/;
  // manual-review 标记豁免：COMMENT/说明含此标记 → ④ 已判挂起待人工（双指向/多态等歧义项），不要求 agent 立即升 *_id/标快照，跳过。
  const MANUAL_REVIEW_RE = /待人工确认跨域关系|待人工确认跨域/;

  // 解析每个 entity 的 FK 列集合 + 字段表「说明」列 FK 信号
  for (const { file, text } of entityFiles) {
    // C1：语法门与 data-model 同口径——只追加失败，不短路下方 FK 判据。
    const dialect = resolveDialectFromEntityPath(resolve(entityDir, file));
    const requireEngine = dialect.key === 'MySQL' || (dialect.key == null && !dialect.raw && !dialect.parseError);
    failures.push(...checkDdlSyntax(text, file, { requireEngine }).failures);

    const { tableName, fkCols } = parseEntityFkColumns(text);

    // 检查 2：跨域 FK COMMENT 指表（概念占位检测）
    // 规则：*_id BIGINT 列若 COMMENT 含「概念」「人员概念」等概念占位词而未指明具体表名 → failure。
    // 正确指表的 COMMENT 含明确表名（`<table>.id` / `<table> 的 id` / `引用班组表 team`）。
    const CONCEPT_PLACEHOLDER_RE = /概念/;
    const TABLE_REF_RE = /\b(\w+)\.id\b|\b(\w+)\s+的\s+id\b|引用\s+(?:班组|人员|表\s*)?([a-z_][a-z0-9_]*)\b/i;
    for (const fk of fkCols) {
      if (!fk.comment) continue;
      const isConceptPlaceholder = CONCEPT_PLACEHOLDER_RE.test(fk.comment);
      const hasTableRef = TABLE_REF_RE.test(fk.comment);
      if (isConceptPlaceholder && !hasTableRef) {
        failures.push(`${file}（表 ${tableName || '?'}）：跨域 FK 列「${fk.colName}」COMMENT 写的是概念占位（「${fk.comment}」）而非具体表名，应为「FK 引用 <目标表>.id」——跨域关系收口任务须填具体表名，让 build 能自推导跨实体 FK`);
      }
    }

    // 检查 3：跨域关系小节存在（COMMENT 写「概念」占位的 *_id 跨域 FK 列须有「## 跨域关系」小节声明）
    // 领域内 FK（如 team_id → team.id，COMMENT 指明具体表）由「## 领域内关系」承载，不要求「## 跨域关系」；
    // 跨域 FK 在波1 无法指表名时写「概念」占位（如 member_id COMMENT「引用...人员概念」）→ 须有「## 跨域关系」小节声明该 FK，作为 build 自推导信息源。
    const conceptFkCols = fkCols.filter((fk) => fk.comment && CONCEPT_PLACEHOLDER_RE.test(fk.comment) && !TABLE_REF_RE.test(fk.comment));
    if (conceptFkCols.length > 0) {
      const hasCrossDomainSection = /## 跨域关系/.test(text);
      if (!hasCrossDomainSection) {
        failures.push(`${file}（表 ${tableName || '?'}）：有 ${conceptFkCols.length} 个跨域 FK 列写概念占位（${conceptFkCols.map((c) => c.colName).join(', ')}）但缺「## 跨域关系」小节声明——build agent 自推导跨实体 FK 的唯一信息源缺失，须补「## 跨域关系」小节写明每条 {本实体}.{col}_id → {target实体}.{id}（N:1 / 1:1 / M:N 经映射表）`);
      }
    }

    // 检查 1：跨域 FK 列存在性（字段表「说明」列含 FK 信号词但 DDL 对应列是 VARCHAR 而非 *_id BIGINT）
    // B 类豁免：说明/COMMENT 含快照标注（SNAPSHOT_MARK_RE）→ 已合规 B 类快照，跳过失败。
    //   A 类（源实体在系统内）应升 *_id + 保留 VARCHAR 名称列为冗余展示快照，由波2 收口任务 prompt 强制；检查只兜"漏标"——未标快照又无 *_id 的 FK 信号列报失败。
    const fieldTableSection = text.split('## 字段表')[1]?.split('## ')[0] || '';
    const fieldRows = [...fieldTableSection.matchAll(/^\|.*\|$/gm)].map((m) => m[0]);
    const fkColNames = new Set(fkCols.map((c) => c.colName));
    // 预解析 DDL 各列 COMMENT（字段表说明可能省略标注，DDL COMMENT 是快照标注的权威落点）
    const ddlColComments = new Map();
    {
      const sqlM = text.match(/```sql\s*\n([\s\S]*?)```/);
      if (sqlM) {
        const colCmtRe = /^\s*`?(\w+)`?\s+\w+[^,]*?COMMENT\s*'([^']*)'/gim;
        let cm;
        while ((cm = colCmtRe.exec(sqlM[1])) !== null) {
          ddlColComments.set(cm[1].toLowerCase(), cm[2]);
        }
      }
    }
    for (let i = 0; i < fieldRows.length; i++) {
      const row = fieldRows[i];
      if (i < 2) continue; // skip header + separator
      const cells = row.split('|').map((c) => c.trim());
      if (cells.length < 6) continue;
      const fieldName = cells[1].toLowerCase();
      const fieldType = cells[2].toUpperCase();
      const fieldDesc = cells[5] || '';
      if (FK_SIGNAL_RE.test(fieldDesc) && !/_id$/.test(fieldName) && !fkColNames.has(fieldName) && fieldType.includes('VARCHAR')) {
        // B 类快照豁免：字段表说明或 DDL COMMENT 命中快照标注 → 合规 B 类，跳过
        const ddlComment = ddlColComments.get(fieldName) || '';
        if (SNAPSHOT_MARK_RE.test(fieldDesc) || SNAPSHOT_MARK_RE.test(ddlComment)) continue;
        // manual-review 豁免：④ 已落「待人工确认跨域关系」标记的歧义项（双指向/多态）跳过，不要求 agent 立即升 *_id/标快照
        if (MANUAL_REVIEW_RE.test(fieldDesc) || MANUAL_REVIEW_RE.test(ddlComment)) continue;
        // 说明列含 FK 信号词，但该列名无 _id 后缀、不在已解析 FK 列集合、未标快照/待人工确认 → 疑似降级 VARCHAR。
        // BIGINT 审计列（created_by/updated_by 等）由 fieldType.includes('VARCHAR') 门排除，归波2 ④ promote-fk-existing-id，不在本检查范围。
        failures.push(`${file}（表 ${tableName || '?'}）：字段表列「${cells[1]}」说明含 FK 信号词（「${fieldDesc.slice(0, 40)}」）但 DDL 列名为「${fieldName}」（${fieldType}）而非 *_id BIGINT——疑似跨域 FK 降级为名称串，须升 *_id（A 类：源实体在系统内，升 *_id 并保留原 VARCHAR 名称列为冗余展示快照）或 COMMENT 标快照来源（B 类：源在系统外，DDL COMMENT 标「快照，非本系统 FK，来源<系统>」）或 COMMENT 标「待人工确认跨域关系」（manual-review：双指向/多态等歧义项，由 ④ 判定后挂起待人工）`);
      }
    }

    // D2：域标注真值（只追加，不改上方任何判据；domain.json 缺席/空 ⇒ 无 failure）。
    failures.push(
      ...checkDomainLabel(text, {
        filePath: resolve(entityDir, file),
        fileLabel: file,
        catalog: domainCatalog,
        context: domainContext,
      }).failures,
    );
  }

  return failures.length === 0 ? { ok: true, failures: [] } : { ok: false, failures };
}

// ── 跨域关系成文判据（cross-domain-decl）──────────────────────────────────────
// plan 2026-10-24/stage5-repair-chain-convergence D2/D3/D5/D6；
// plan 2026-10-30/cross-domain-decl-unpassable-red-feedback-loop D1/D2/D4：
//   成文义务（才可进阻断层）= hasDeclObligation：action 非 merge-into 且 targetTable 为非空串。
//     targetTable 为空的条目（manual-review 多态待人工 / 未建模快照）没有可机械比对的目标表名，
//     判据给不出 agent 能满足的期望值 ⇒ 不进阻断层（与 cross-domain-fk:895 的 manual-review 豁免同口径）。
//   阻断层（failures）判据 = 实体文档「## 跨域关系」小节内**同时**出现目标表名与 carrier 字段 token；
//     bullet / 表格 / prose 任何形态均通过——判据格式无关，禁做格式校验。
//   质量层（advisories，不进 failures、不影响 exit code）= 归一四元组
//     (carrier, field, targetTable, targetField) 命中规范前缀行。期望值单源 = 清单的 relationDecl，
//     脚本**不按 action 重推字段名**（keep-varchar 的 newField / mark-snapshot 的原 field 已由 detect 编好）。
//   relationDecl 解不出四元组 ⇒ 只进 advisory（证据不可解析 ≠ 产物缺失）：旧口径把「判据取不到材」当成
//     「产物缺行」送进 apply 修复环，agent 无权改清单判定字段 ⇒ 恒红（2026-10-30 沙箱 4 轮 stale-abort）。
//   section 缺失 / 抽出 0 条 ⇒ 红（D6：禁止空集 ok:true）。
// 作用域：只读 --carrier 指定 carrier 的实体文件（文件解析复用 shared/cross-domain-decl.mjs 的三级同源
// 逻辑；除定位所需的扫描兜底外不评测其它实体文件）。
// 红文案稳定可粘贴：只列缺失元组 + 该 relation 的 relationDecl 原行，不回显文档原文；排序键固定
// (carrier, field, targetTable)，重复 check 输出逐字相同（stale-abort 依赖同输出判无效修复）。
//
// 依赖注入：归一/抽取/文件解析/成文义务谓词全部来自 shared/cross-domain-decl.mjs（单源，禁第二份），
// 由 main() 按需动态 import 后经 `decl` 传入——本函数不在模块作用域持有该 import（见文件头说明）。
// 其中 hasDeclObligation 与 TS 侧 checkers/cross-domain.ts 的同口径谓词逐值镜像（两运行时禁互相 import），
// 改 blocking 口径须两侧同改。
// `onMissing` 仅供 `--fix` 收集「判缺」条目：判据与补写走同一条代码路径，禁另写一份缺失判定。
function evaluateCrossDomainDecl({ relationsPath, entityDir, carriers, decl, onMissing = null }) {
  const {
    extractCrossDomainSection,
    hasDeclObligation,
    normalizeDeclText,
    parseRelationDecl,
    resolveEntityFileNameByCarrier,
  } = decl;
  const failureEntries = [];
  const advisoryEntries = [];
  const fail = (tuple, message) => failureEntries.push({ ...tuple, message });
  const advise = (tuple, message) => advisoryEntries.push({ ...tuple, message });
  const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
  const byTuple = (a, b) =>
    cmp(a.carrier, b.carrier) || cmp(a.field, b.field) || cmp(a.targetTable, b.targetTable) || cmp(a.message, b.message);
  const finish = () => {
    const collect = (entries) => {
      const seen = new Set();
      const messages = [];
      for (const e of entries.slice().sort(byTuple)) {
        if (seen.has(e.message)) continue;
        seen.add(e.message);
        messages.push(e.message);
      }
      return messages;
    };
    const failures = collect(failureEntries);
    return { ok: failures.length === 0, failures, advisories: collect(advisoryEntries) };
  };

  let raw;
  try {
    raw = readFileSync(relationsPath, 'utf-8');
  } catch (e) {
    return {
      ok: false,
      failures: [`无法读取 cross-domain-relations.json：${relationsPath}（${e.message}）——成文判据不可判 ⇒ 红，禁静默`],
      advisories: [],
    };
  }
  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    return { ok: false, failures: ['cross-domain-relations.json 未找到 JSON 对象——成文判据不可判 ⇒ 红，禁静默'], advisories: [] };
  }
  let data;
  try {
    data = JSON.parse(jsonMatch[0]);
  } catch (e) {
    return { ok: false, failures: [`cross-domain-relations.json 不可解析（${e.message}）——成文判据不可判 ⇒ 红，禁静默`], advisories: [] };
  }
  if (!Array.isArray(data?.relations)) {
    return { ok: false, failures: ['cross-domain-relations.json 缺少 relations 数组——成文判据不可判 ⇒ 红'], advisories: [] };
  }

  const relations = data.relations.filter((r) => r && typeof r === 'object');
  const unresolved = Array.isArray(data.unresolved) ? data.unresolved.filter((u) => u && typeof u === 'object') : [];
  const declLine = (r) =>
    `- \`${typeof r.relationDecl === 'string' && r.relationDecl ? r.relationDecl : '（relationDecl 缺失）'}\``;

  for (const carrier of [...new Set(carriers)].sort(cmp)) {
    const carrierRelations = relations.filter((r) => r.carrier === carrier);
    const carrierUnresolved = unresolved.filter((u) => u.carrier === carrier);
    if (carrierRelations.length === 0 && carrierUnresolved.length === 0) {
      // D6：抽不到必须红。carrier 在清单里无任何条目 = 调用方/清单不可判，禁空集放行。
      fail(
        { carrier, field: '', targetTable: '' },
        `${carrier}：清单 relations/unresolved 中均无该 carrier 条目（抽出 0 条）——禁止空集放行；核对 --carrier 与 cross-domain-relations.json 的 carrier 是否一致`,
      );
      continue;
    }
    // 阻断层只收「有可机械取值的期望值」的 relation（D1）：merge-into 本就不并入成文判据（D8，交付门兜底），
    // targetTable 为空的条目（manual-review 多态待人工 / 未建模快照）同样没有可比对的目标表名。
    // blocking 为空 ⇒ 该 carrier 无成文义务，直接跳过、不要求小节存在（语义不变）。
    const blocking = carrierRelations.filter((r) => hasDeclObligation(r));
    if (blocking.length === 0) continue;

    const file = resolveEntityFileNameByCarrier(entityDir, carrier, data);
    let text;
    try {
      text = readFileSync(join(entityDir, file), 'utf-8');
    } catch {
      fail(
        { carrier, field: '', targetTable: '' },
        `${file}：读不到 carrier=${carrier} 的实体文档——须补实体文档，或修正/补 cross-domain-relations.json 本 carrier 条目的 file 对账字段后重试；禁目录全扫`,
      );
      continue;
    }

    const section = extractCrossDomainSection(text);
    const pasteList = blocking.map(declLine).join('；');
    if (!section.present) {
      fail(
        { carrier, field: '', targetTable: '' },
        `${file}：缺「## 跨域关系」小节——须补写该小节，为每个跨域 relation 写一行（模板：- \`{carrier}.{field}\` → \`{target}.{field}\`（N:1）：<描述>）。可粘贴 relationDecl 原行（${blocking.length} 条）：${pasteList}`,
      );
      // --fix：小节整体缺失时，本 carrier 的全部阻断 relation 都是候选补写行（writer 只取可解四元组的）。
      if (onMissing) onMissing({ carrier, file, section, relations: blocking });
      continue;
    }
    if (section.entries.length === 0) {
      fail(
        { carrier, field: '', targetTable: '' },
        `${file}：「## 跨域关系」小节为空（抽出 0 条）——禁止空集放行，须补写以下行：${pasteList}`,
      );
      if (onMissing) onMissing({ carrier, file, section, relations: blocking });
      continue;
    }

    // 阻断层：token 存在性。格式无关——整段归一后做包含判断，bullet / 表格 / prose 同权。
    // 期望值优先级（D4）：**结构化字段（newField / field / targetTable）> relationDecl prose**——
    // 判据本身不依赖 relationDecl 可解析性；prose 只在结构化字段缺失时兜底。
    // 质量层：四元组以规范 key 出现在归一正文中才算命中（缺失时只出 advisory，不改 exit code）。
    const normBody = normalizeDeclText(section.entries.join('\n'));
    const str = (value) => (typeof value === 'string' ? value.trim() : '');
    for (const r of blocking) {
      const tuple = parseRelationDecl(r.relationDecl);
      const expectedTarget = str(r.targetTable) || tuple?.targetTable || '';
      const expectedField = str(r.newField) || str(r.field) || tuple?.field || '';
      if (!expectedTarget || !expectedField) {
        // 结构化字段也凑不出期望值（清单条目本身缺字段）⇒ 只提示不判红：无可判事实 ≠ 产物缺失。
        advise(
          { carrier, field: str(r.field), targetTable: str(r.targetTable) },
          `${file}：carrier=${carrier} 的 relation 缺可判期望值（targetTable/field 为空，relationDecl 也解不出四元组，原行：${typeof r.relationDecl === 'string' && r.relationDecl ? r.relationDecl : '（缺）'}）——仅提示，不判红；该条清单字段需由 ③ detect 补全，apply 层无权改判定字段`,
        );
        continue;
      }
      if (!tuple) {
        // relationDecl 不可解析只作质量提示，不阻断：token 判据仍按结构化字段执行（见上）。
        advise(
          { carrier, field: expectedField, targetTable: expectedTarget },
          `${file}：carrier=${carrier} 的 relationDecl 无法解析出四元组（原行：${typeof r.relationDecl === 'string' && r.relationDecl ? r.relationDecl : '（缺）'}）——仅提示，不阻断；本条按清单结构化字段判 token 在场：实体文档须写出 \`${carrier}.${expectedField}\` → \`${expectedTarget}.<目标字段>\``,
        );
      }
      const missing = [];
      if (!normBody.includes(normalizeDeclText(expectedTarget))) missing.push(`目标表名「${expectedTarget}」`);
      if (!normBody.includes(normalizeDeclText(expectedField))) missing.push(`carrier 字段 token「${expectedField}」`);
      if (missing.length > 0) {
        fail(
          { carrier, field: expectedField, targetTable: expectedTarget },
          `${file}：「## 跨域关系」小节缺 ${missing.join('、')}（carrier=${carrier}, field=${expectedField}, targetTable=${expectedTarget}）——须在该小节内写出这条跨域关系（bullet/表格/prose 任选）。${tuple ? `可粘贴 relationDecl 原行：${declLine(r)}` : '该条 relationDecl 不可解析，按上述结构化字段书写即可，勿改清单判定字段。'}`,
        );
        // --fix：仅收集本条（relationDecl 已解出四元组 ⇒ 补写行可被判据复核；解不出则 writer 跳过＝不编造）。
        if (onMissing) onMissing({ carrier, file, section, relations: [r] });
        continue;
      }
      const expectedKey = tuple
        ? `${tuple.carrier}.${tuple.field}->${tuple.targetTable}.${tuple.targetField}`
        : '';
      if (expectedKey && !normBody.includes(expectedKey)) {
        advise(
          { carrier, field: expectedField, targetTable: expectedTarget },
          `${file}：质量提示——「## 跨域关系」小节未出现规范四元组行 (carrier=${tuple.carrier}, field=${tuple.field}, targetTable=${tuple.targetTable}, targetField=${tuple.targetField})；规范模板：- \`{carrier}.{field}\` → \`{target}.{field}\`（N:1）：<描述>。可粘贴 relationDecl 原行：${declLine(r)}`,
        );
      }
    }
  }

  return finish();
}

// ── 缺行确定性 writer（--fix，plan 2026-10-24/stage5-repair-chain-convergence D7）──────────────
// 当前契约：`--fix` 只对**阻断层判缺**的 relation，把其 relationDecl 原行以一行 bullet
// `- <relationDecl 原行>` **追加**到该 carrier 实体文档「## 跨域关系」小节末尾；小节不存在则在
// 文件末尾新建。为何这样：修复通道需要确定出口——让模型按措辞凑格式会把「真缺一行」烧成多轮
// agent 重试；机械追加把可变部分收敛为一条可复核的判据输入。
//
// 硬约束（判据会复核，越界即红）：
//   - **只追加**：按字节偏移插入，不覆盖、不重排任何既有内容（含小节后的其它标题与正文）；
//   - **幂等**：归一后小节内已有等价行 ⇒ 跳过（归一函数只用 shared/cross-domain-decl.mjs 那一份）；
//   - **不编造**：relationDecl 缺失/解不出四元组、实体文件不存在 ⇒ 不写；该条不再是 blocker
//     （证据不可解析 ≠ 产物缺失，只进 advisory，见 hasDeclObligation 的注释）；
//   - 追加后由调用方在同一进程内**重新判一次**（允许重试不收敛），输出 `fixed` 为本次实际追加项。
// bullet 行构造（writer 与幂等判定共用，禁两处各写一份）。
const toDeclBulletLine = (relationDecl) => `- ${String(relationDecl).trim()}`;

/**
 * 把 bullet 行追加到「## 跨域关系」小节末尾（按字节偏移插入，既有内容逐字保留）。
 * 行定位与 shared 的 extractCrossDomainSection 同边界口径：到下一个一级/二级标题为止，`###` 属小节内。
 */
function appendLinesToDeclSection(text, bulletLines) {
  const eol = text.includes('\r\n') ? '\r\n' : '\n';
  const block = bulletLines.map((line) => `${line}${eol}`).join('');
  // 带偏移的行切分：只用来定位插入点，不从行数组重组全文（重组会改写行尾/空白，违反只追加）。
  const spans = [];
  let start = 0;
  while (start < text.length) {
    const nl = text.indexOf('\n', start);
    const end = nl === -1 ? text.length : nl + 1;
    spans.push({ start, end, line: text.slice(start, nl === -1 ? text.length : nl) });
    start = end;
  }
  const headingIdx = spans.findIndex((s) => /^##\s*跨域关系/.test(s.line.trim()));
  if (headingIdx === -1) {
    // 小节缺失：文件末尾新建（与既有正文之间留一空行；空文件不留前导空行）。
    const sep = text.length === 0 ? '' : text.endsWith('\n') ? eol : `${eol}${eol}`;
    return `${text}${sep}## 跨域关系${eol}${block}`;
  }
  // 小节存在：插入点 = 小节内最后一条非空行之后；其后的空行/下级内容原样保留。
  let insertAt = spans[headingIdx].end;
  for (let i = headingIdx + 1; i < spans.length; i += 1) {
    const trimmed = spans[i].line.trim();
    if (/^#{1,2}\s/.test(trimmed)) break;
    if (trimmed) insertAt = spans[i].end;
  }
  const lead = insertAt > 0 && !text.slice(0, insertAt).endsWith('\n') ? eol : '';
  return `${text.slice(0, insertAt)}${lead}${block}${text.slice(insertAt)}`;
}

/**
 * 收集并执行补写：复用 evaluateCrossDomainDecl 的 onMissing 回调（判缺与补写同源，禁第二份判据）。
 * 返回 { fixed, writeFailures }：writeFailures 进最终 failures（写入失败不得伪装成修复成功）。
 */
function collectCrossDomainDeclFixes({ relationsPath, entityDir, carriers, decl }) {
  const { normalizeDeclText, parseRelationDecl } = decl;
  // 归一后等价键：剥掉行首 bullet 标记后与 relationDecl 归一值比（`-`/`*`/`+`/`>` 是展示形态）。
  const lineKey = (line) => normalizeDeclText(line).replace(/^[-+>]+/, '');
  const buckets = new Map(); // 绝对文件路径 → { lines, keys, fixed }
  evaluateCrossDomainDecl({
    relationsPath,
    entityDir,
    carriers,
    decl,
    onMissing: ({ carrier, file, section, relations }) => {
      const absFile = join(entityDir, file);
      let bucket = buckets.get(absFile);
      if (!bucket) {
        bucket = { lines: [], keys: new Set((section?.entries ?? []).map(lineKey)), fixed: [] };
        buckets.set(absFile, bucket);
      }
      for (const r of relations) {
        const declText = typeof r?.relationDecl === 'string' ? r.relationDecl.trim() : '';
        // relationDecl 缺失/解不出四元组 ⇒ 不编造（该条只进 advisory，不再是 blocker）。
        if (!declText || !parseRelationDecl(declText)) continue;
        const key = lineKey(declText);
        if (bucket.keys.has(key)) continue; // 归一后已有等价行 ⇒ 跳过（幂等）
        bucket.keys.add(key);
        bucket.lines.push(toDeclBulletLine(declText));
        bucket.fixed.push({ carrier, relationDecl: declText });
      }
    },
  });

  const fixed = [];
  const writeFailures = [];
  for (const [absFile, bucket] of buckets) {
    if (bucket.lines.length === 0) continue;
    try {
      // 写前重读：collect 阶段读的是旧快照，此处以磁盘现状为追加基线（不丢期间写入）。
      const current = readFileSync(absFile, 'utf-8');
      writeFileSync(absFile, appendLinesToDeclSection(current, bucket.lines), 'utf-8');
      fixed.push(...bucket.fixed);
    } catch (e) {
      writeFailures.push(
        `${absFile}：确定性 writer 追加失败（${e?.message ?? e}）——本节条目仍按缺失判红，须人工补齐或检查文件可写性；禁按「已修复」放行`,
      );
    }
  }
  return { fixed, writeFailures };
}

/**
 * cross-domain-decl 入口。
 *   - 无 `--fix`：只读判据，返回形状与既有逐字一致（{ok, failures, advisories}，无 fixed 键）；
 *   - `--fix`：先按同一判据收集缺行并确定性追加，再在同一进程内重判一次（读刚写盘的文档），
 *     输出 `{ok, failures, advisories, fixed}`；`fixed` 只列本次实际追加的条目。
 */
function checkCrossDomainDecl({ relationsPath, entityDir, carriers, decl, fix = false }) {
  if (!fix) return evaluateCrossDomainDecl({ relationsPath, entityDir, carriers, decl });
  const { fixed, writeFailures } = collectCrossDomainDeclFixes({ relationsPath, entityDir, carriers, decl });
  const rechecked = evaluateCrossDomainDecl({ relationsPath, entityDir, carriers, decl });
  return { ...rechecked, failures: [...rechecked.failures, ...writeFailures], fixed };
}

/**
 * 读 domain.json 的业务域 id（`domains[].id`）。best-effort：不可读/不可解析回 error，
 * 调用方按既有口径只打提示或静默降级，不阻塞其它判据。
 */
export function readDomainIds(domainJsonPath) {
  try {
    const domainData = JSON.parse(readFileSync(domainJsonPath, 'utf-8'));
    const ids = (domainData.domains || [])
      .map((d) => d && d.id)
      .filter((d) => typeof d === 'string' && d);
    return { ids, error: null };
  } catch (e) {
    return { ids: [], error: e?.message ?? String(e) };
  }
}

/**
 * 占位符扫描前遮罩已知业务域 id。
 *
 * 为什么需要：域 id 由阶段一 agent 自由命名，可含 `todo`/`tbd` 等词根；`todo-task-center` 这类
 * 连字符形态在 `\b` 下必然命中结构性占位符判据，而同一门又要求正文逐字引用每个域 id ⇒ 两条判据
 * 对合法产物互斥（2026-10-30 沙箱实证：agent 无解后弹问）。域 id 是正文必备引用、不是占位符，
 * 扫描前按明文剔除（split/join，域 id 非正则无需转义），只影响占位符判据，其余判据与文案不变。
 */
export function maskDomainIdsForPlaceholderScan(text, domainIds) {
  let masked = text;
  for (const domainId of domainIds) {
    masked = masked.split(domainId).join(' ');
  }
  return masked;
}

// ── 域标注真值（plan 2026-11-05/entity-domain-label-truth-and-repairable-projection D2）──
// data-model / cross-domain-fk 两个模式共用的「实体头部域标注 == plans/domain.json」校验。
//
// 判据边界（不可判 ≠ 不适用）：
//   - domain.json 缺席，或 domains 为空数组 ⇒ **不适用**（free/legacy round 无域清单时不误伤）；
//   - domain.json 在场但 JSON 不可解析 / 顶层非对象 / domains 非数组 / 元素缺 id ⇒ **红**
//     （域 id 白名单不可判，禁按不适用静默放行）；
//   - 头部缺失 / 括号未闭合 / 缺中文名括号 / id 不在白名单 / nameZh 与 domain.json 不一致 ⇒ **红**。
//
// 格式容忍：`>` 引用前缀、ASCII/全角冒号、冒号与括号前后空白、括号后可跟任意尾注（只取第一段
// 非空括号作 nameZh，其余不判）。**括号段对产物是必需的**（判据「无括号 ⇒ failure」），解析层
// 仍容忍其缺席，以便给出定向文案而不是笼统的「格式不符」。
// 若 domain.json 的该域未提供 nameZh（只有 id），只判格式与 id，不判中文名（证据不可判不判）。
//
// 域清单定位：从被检实体文件（或其所在目录）向上找名为 `plans` 的祖先目录，读 `<plans>/domain.json`；
// 与 resolveDialectFromEntityPath 的 plans/ 定位同款，上限 8 级防御冗余。目录模式下调用方传入
// cache 即可只读一次并复用（见 checkCrossDomainFk）。
const DOMAIN_LABEL_LINE_RE = /^[ \t]*>?[ \t]*业务领域[ \t]*[:：][ \t]*(.*?)[ \t]*$/m;
const DOMAIN_LABEL_BRACKET_RE = /[（(]([^（()）]*)[）)]/;
const DOMAIN_CANDIDATE_LIMIT = 10;

/** 解析实体头部的 `业务领域：<id>（<nameZh>）`。context/`>`/空白容忍，只取第一段括号。 */
export function parseDomainLabel(content) {
  const m = String(content ?? '').match(DOMAIN_LABEL_LINE_RE);
  if (!m) {
    return { present: false, raw: null, id: null, nameZh: null, hasBracket: false, bracketUnclosed: false };
  }
  const raw = m[1].trim();
  const bracket = raw.match(DOMAIN_LABEL_BRACKET_RE);
  if (bracket) {
    const id = raw.slice(0, raw.indexOf(bracket[0])).trim().replace(/^`+|`+$/g, '').trim();
    return {
      present: true,
      raw,
      id: id || null,
      nameZh: bracket[1].trim() || null,
      hasBracket: true,
      bracketUnclosed: false,
    };
  }
  const openIdx = raw.search(/[（(]/);
  return {
    present: true,
    raw,
    id: (openIdx >= 0 ? raw.slice(0, openIdx) : raw).trim().replace(/^`+|`+$/g, '').trim() || null,
    nameZh: null,
    hasBracket: false,
    bracketUnclosed: openIdx >= 0,
  };
}

function readDomainCatalogFile(domainJsonPath, plansDir) {
  const invalid = (reason) => ({ state: 'invalid', reason, plansDir, domainJsonPath });
  let data;
  try {
    data = JSON.parse(readFileSync(domainJsonPath, 'utf-8'));
  } catch (e) {
    return invalid(`JSON 不可解析（${e?.message ?? e}）`);
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) return invalid('顶层不是对象');
  if (!Array.isArray(data.domains)) return invalid('domains 不是数组');
  if (data.domains.length === 0) {
    return { state: 'not-applicable', reason: 'empty-domains', plansDir, domainJsonPath };
  }
  const domains = [];
  for (let i = 0; i < data.domains.length; i++) {
    const entry = data.domains[i];
    const id = typeof entry?.id === 'string' ? entry.id.trim() : '';
    if (!id) return invalid(`domains[${i}] 缺 id`);
    const nameZh = typeof entry?.nameZh === 'string' ? entry.nameZh.trim() : '';
    domains.push({ id, nameZh });
  }
  return { state: 'ok', domains, plansDir, domainJsonPath };
}

/**
 * 从实体文件（或实体目录）向上定位 `plans/` 并读取 `domain.json`。
 * 返回 state：`ok` | `not-applicable`（缺席 / domains 为空） | `invalid`（在场但不可判）。
 * cache（Map）按 domain.json 绝对路径缓存结果，供目录模式只读一次复用。
 */
export function resolveDomainCatalog(startPath, cache = null) {
  if (!startPath) return { state: 'not-applicable', reason: 'no-path', plansDir: null, domainJsonPath: null };
  let dir = resolve(startPath);
  try {
    if (!statSync(dir).isDirectory()) dir = dirname(dir);
  } catch {
    dir = dirname(dir);
  }
  for (let i = 0; i < 8 && dir; i++) {
    if (basename(dir) === 'plans') {
      const domainJsonPath = join(dir, 'domain.json');
      if (!existsSync(domainJsonPath)) {
        return { state: 'not-applicable', reason: 'missing-domain-json', plansDir: dir, domainJsonPath };
      }
      if (cache && cache.has(domainJsonPath)) return cache.get(domainJsonPath);
      const result = readDomainCatalogFile(domainJsonPath, dir);
      if (cache) cache.set(domainJsonPath, result);
      return result;
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return { state: 'not-applicable', reason: 'no-plans-dir', plansDir: null, domainJsonPath: null };
}

/** 供目录模式复用的建议上下文（实体头索引 / 映射表关系懒加载缓存）。 */
export function createDomainLabelContext() {
  return {};
}

function describeDomain(domain) {
  return domain?.nameZh ? `${domain.id}（${domain.nameZh}）` : domain?.id ?? '';
}

function formatDomainCandidates(domains) {
  const ids = domains.map((d) => d.id);
  const shown = ids.slice(0, DOMAIN_CANDIDATE_LIMIT).join('、');
  return ids.length > DOMAIN_CANDIDATE_LIMIT ? `${shown}、…` : shown;
}

function lazyContextValue(context, key, build) {
  if (!context) return build();
  if (!Object.prototype.hasOwnProperty.call(context, key)) context[key] = build();
  return context[key];
}

/** `<plans>/backend` 下全部 entity-*.md 的 slug/表名 → 头部标注索引（建议文案用，懒加载）。 */
function buildEntityHeaderIndex(backendDir) {
  const bySlug = new Map();
  const byTable = new Map();
  const walk = (dir, depth) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      const p = join(dir, entry.name);
      if (entry.isDirectory()) {
        if (depth < 4) walk(p, depth + 1);
        continue;
      }
      if (!/^entity-.*\.md$/i.test(entry.name)) continue;
      let text;
      try {
        text = readFileSync(p, 'utf-8');
      } catch {
        continue;
      }
      const slug = entry.name.replace(/^entity-/i, '').replace(/\.md$/i, '');
      const tableToken = (text.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([A-Za-z_][\w]*)`?/i) || [])[1] || null;
      const record = {
        filePath: p,
        slug,
        table: tableToken ? tableToken.toLowerCase() : null,
        label: parseDomainLabel(text),
      };
      bySlug.set(slug.toLowerCase(), record);
      if (record.table) byTable.set(record.table, record);
    }
  };
  walk(backendDir, 0);
  return { bySlug, byTable };
}

function readCrossDomainRelations(backendDir) {
  try {
    const data = JSON.parse(readFileSync(join(backendDir, '_meta', 'cross-domain-relations.json'), 'utf-8'));
    return Array.isArray(data?.relations) ? data.relations : null;
  } catch {
    return null;
  }
}

/**
 * 反查建议域（只用于失败文案，不作为判据）：
 *   ① 文件落在 `_meta/per-domain/<域>/` 镜像目录 ⇒ 目录名即域（D4 修复 agent 的同一真值源）；
 *   ② 标注里写了中文名但没写 id ⇒ 按 nameZh 在 domain.json 里命中；
 *   ③ 映射表文件（create-mapping-table 的 newField 对应本文件）⇒ carrier / targetTable 指向的
 *      实体文件头部域（plan D2「newField → carrier → carrier 实体的域」；carrier 为 `__mapping__`
 *      时退回条目里的 table/targetTable 端）。
 */
function findDomainSuggestion({ filePath, catalog, label, context }) {
  const byId = new Map(catalog.domains.map((d) => [d.id, d]));
  const normalizedPath = String(filePath || '').replace(/\\/g, '/');
  const mirror = normalizedPath.match(/\/per-domain\/([^/]+)\//);
  if (mirror && byId.has(mirror[1])) {
    return `建议域「${describeDomain(byId.get(mirror[1]))}」（取自 per-domain 镜像目录名）`;
  }
  const rawName = (label?.nameZh || label?.raw || '').trim();
  if (rawName) {
    const byName = catalog.domains.find((d) => d.nameZh && d.nameZh === rawName);
    if (byName) return `建议域「${describeDomain(byName)}」（标注中文名与 domain.json 的 nameZh 一致）`;
  }
  if (!catalog.plansDir || !filePath) return null;

  const backendDir = join(catalog.plansDir, 'backend');
  const index = lazyContextValue(context, 'entityHeaderIndex', () => buildEntityHeaderIndex(backendDir));
  const relations = lazyContextValue(context, 'relations', () => readCrossDomainRelations(backendDir));
  if (!relations) return null;

  const fileName = basename(filePath);
  const fileSlug = fileName.replace(/^entity-/i, '').replace(/\.md$/i, '');
  const own = index.bySlug.get(fileSlug.toLowerCase()) || null;
  const ownTable = own?.table || fileSlug;
  const isMappingEntry = (entry) => {
    if (!entry || entry.action !== 'create-mapping-table') return false;
    const names = [entry.newField, entry.table, entry.targetTable, entry.file ? basename(String(entry.file)) : null]
      .filter((v) => typeof v === 'string' && v);
    return names.some((v) => {
      const s = v.toLowerCase();
      return s === String(ownTable).toLowerCase()
        || s === fileSlug.toLowerCase()
        || s === fileName.toLowerCase()
        || s === `entity-${fileSlug}`.toLowerCase();
    });
  };
  for (const entry of relations) {
    if (!isMappingEntry(entry)) continue;
    const carrierTokens = [entry.carrier, entry.table, entry.targetTable]
      .filter((v) => typeof v === 'string' && v && v !== '__mapping__');
    for (const token of carrierTokens) {
      const key = token.toLowerCase();
      if (key === String(ownTable).toLowerCase() || key === fileSlug.toLowerCase()) continue;
      const carrier = index.bySlug.get(key) || index.byTable.get(key) || null;
      const carrierLabel = carrier?.label;
      if (!carrier || !carrierLabel?.hasBracket || !carrierLabel.id || !byId.has(carrierLabel.id)) continue;
      return `建议域「${describeDomain(byId.get(carrierLabel.id))}」（映射表 ${entry.newField || fileSlug} 的 carrier 实体 ${carrier.slug} 标注）`;
    }
  }
  return null;
}

/**
 * 校验单个实体文件的域标注真值（data-model / cross-domain-fk 共用）。
 * 只**追加** failures，不改变任何既有判据；`domain.json` 缺席 / domains 空 ⇒ 无 failure。
 *
 * options:
 *   - filePath：实体文件绝对路径（域清单定位与建议反查都基于它）；
 *   - fileLabel：文案里的文件标识（缺省 basename）；
 *   - catalog：已解析的域清单（目录模式传入复用；缺省按 filePath 现解析）；
 *   - cache：resolveDomainCatalog 的 Map 缓存（目录模式只读一次）；
 *   - context：createDomainLabelContext() 的懒加载缓存。
 */
export function checkDomainLabel(content, options = {}) {
  const { filePath = '', fileLabel = null, catalog = null, cache = null, context = null } = options;
  const labelText = fileLabel || (filePath ? basename(filePath) : '实体文件');
  const cat = catalog || resolveDomainCatalog(filePath, cache);
  if (cat.state === 'not-applicable') return { ok: true, failures: [] };
  if (cat.state === 'invalid') {
    return {
      ok: false,
      failures: [
        `${labelText}：业务领域标注真值不可判——${cat.domainJsonPath || 'plans/domain.json'} 存在但不可用（${cat.reason}）；不可判 ≠ 不适用，须先修好域清单（domains 为 [{ id, nameZh }] 非空数组，元素必带 id）后重跑，禁用删除/清空 domain.json 绕过`,
      ],
    };
  }

  const label = parseDomainLabel(content);
  const domains = cat.domains;
  const byId = new Map(domains.map((d) => [d.id, d]));
  const exampleDomain = domains[0];
  const example = `业务领域：${describeDomain(exampleDomain)}`;
  const suggestion = findDomainSuggestion({ filePath, catalog: cat, label, context });
  const suffix = [
    `候选域 id：${formatDomainCandidates(domains)}`,
    suggestion ? `反查${suggestion}` : null,
    `期望格式「业务领域：<域 id>（<域中文名>）」，例如「${example}」`,
  ].filter(Boolean).join('；');

  if (!label.present) {
    return {
      ok: false,
      failures: [`${labelText}：缺少业务领域标注（当前：无）——须在文件首部补「> ${example}」；${suffix}`],
    };
  }
  if (label.bracketUnclosed) {
    return {
      ok: false,
      failures: [`${labelText}：业务领域标注的括号未闭合（当前「业务领域：${label.raw}」）——须补全中文名括号；${suffix}`],
    };
  }
  if (!label.id || !byId.has(label.id)) {
    return {
      ok: false,
      failures: [
        `${labelText}：业务领域标注的域 id「${label.id || ''}」不在 plans/domain.json 的 domains[].id 中（当前「业务领域：${label.raw}」）——须改为白名单中的域 id；${suffix}`,
      ],
    };
  }

  const domain = byId.get(label.id);
  if (!label.hasBracket) {
    return {
      ok: false,
      failures: [
        `${labelText}：业务领域标注缺少中文名括号（当前「业务领域：${label.raw}」）——须写成「业务领域：${domain.id}（${domain.nameZh || '<域中文名>'}）」；${suffix}`,
      ],
    };
  }
  if (domain.nameZh && label.nameZh !== domain.nameZh) {
    return {
      ok: false,
      failures: [
        `${labelText}：业务领域标注的中文名与 plans/domain.json 不一致（当前「业务领域：${label.raw}」中的「${label.nameZh || ''}」≠ domain.json「${domain.id}」的 nameZh「${domain.nameZh}」）——须改为「业务领域：${domain.id}（${domain.nameZh}）」；${suffix}`,
      ],
    };
  }
  return { ok: true, failures: [] };
}

function checkUserStories(text, filePath) {
  const failures = [];

  // 1. 文档必须有标题与用途说明
  if (!/^#\s+.*用户故事|^#\s+User Stories|^#\s+后端建模用户故事/m.test(text)) {
    failures.push('缺少文档主标题（应含「用户故事」/User Stories）');
  }

  // 2. 每条用户故事必须包含完整要素
  const stories = text.split(/^### /m).slice(1);
  const requiredKeys = [
    { k: '角色', label: '角色' },
    { k: '前置状态', label: '前置状态' },
    { k: '用户目标', label: '用户目标' },
    { k: '操作路径', label: '操作路径' },
    { k: '涉及业务对象', label: '涉及业务对象' },
    { k: '后端建模指引', label: '后端建模指引' },
  ];
  if (stories.length === 0) {
    failures.push('未找到任何以「### 」标识的用户故事');
  }
  for (let i = 0; i < stories.length; i++) {
    const s = stories[i];
    if (!s.trim()) { failures.push(`故事 ${i + 1}: 标题或内容为空`); continue; }
    // 结构化提取本故事所有列表项键名：- **<key>**[:：]（容忍冒号有无/全半角/尾空格），
    // 替代字面 `includes('- **角色** ')`（带尾随空格，全角冒号即假阳，同 writesTo 后缀病）。
    const presentKeys = new Set(
      [...s.matchAll(/^- \*\*(.+?)\*\*\s*[:：]?/gm)].map((m) => m[1].trim())
    );
    for (const { k } of requiredKeys) {
      if (!presentKeys.has(k)) {
        failures.push(`故事 ${i + 1}「${s.split('\n')[0].trim()}」缺少「${k}」要素`);
      }
    }
  }

  // 3. 用户故事须覆盖 domain.json 声明的每个业务域（至少一个用户故事引用该域 id）
  //    通用结构性覆盖校验：从项目自己的 domain.json 读取域清单，禁硬编码具体业务术语。
  //    domain.json 缺失或为空时 best-effort 跳过，不阻塞（与 checkRelations 读 domain.json 口径一致）。
  const { ids: domainIds, error: domainError } = readDomainIds(resolve(filePath, '..', '..', '..', 'domain.json'));
  if (domainError) {
    console.error(`[check-backend-design] 提示：无法读取 domain.json 做域覆盖校验：${domainError}`);
  } else if (domainIds.length === 0) {
    console.error('[check-backend-design] 提示：domain.json 的 domains[] 为空，跳过用户故事域覆盖校验');
  } else {
    for (const domainId of domainIds) {
      if (!text.includes(domainId)) {
        failures.push(`用户故事未覆盖业务域「${domainId}」（domain.json 声明但 user-stories.md 未引用该域 id）`);
      }
    }
  }

  // 4. 禁止空标题 / 占位 / PENDING / 绝对路径
  // 注：不把字面「占位符/待补充/待补」当违例——它们是合法正文术语；只拦截结构性 TODO 标记。
  const placeholders = maskDomainIdsForPlaceholderScan(text, domainIds).match(/\*\*\*|\[[xX]+\]|<!PENDING>|\bTODO\b|\bTBD\b/gi) || [];
  if (placeholders.length > 0) {
    failures.push(`文档包含占位符/待补充标记：${[...new Set(placeholders)].slice(0, 5).join(', ')}`);
  }
  // 真实绝对路径 = 路径段首字母为字母（/Users/jack、/home/jack、/root/.x），排除路由 glob（/home/**、/root/**）。
  if (/\/Users\/[A-Za-z]|\/home\/[A-Za-z]|\/root\/[A-Za-z.]/.test(text)) {
    failures.push('文档包含真实绝对路径（应使用占位符或相对引用）');
  }
  if (/\n## [^\n]*(?=\n## )/m.test(text) || /\n### [^\n]*(?=\n###)/m.test(text)) {
    failures.push('存在空标题（标题后直接跟另一标题，无内容）');
  }

  return failures.length === 0 ? { ok: true, failures: [] } : { ok: false, failures };
}

function checkCoverageGaps(content) {
  const failures = [];
  let data;
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    failures.push('未找到 JSON 对象，coverage-gaps 文件应包含 { "gaps": [...], "resolved": [...] }');
    return { ok: false, failures };
  }
  try {
    data = JSON.parse(jsonMatch[0]);
  } catch (e) {
    failures.push('JSON 解析失败：' + e.message);
    return { ok: false, failures };
  }
  if (!Array.isArray(data.gaps)) {
    failures.push('缺少或非数组字段：gaps（应为 JSON 数组）');
  } else {
    for (let i = 0; i < data.gaps.length; i++) {
      const g = data.gaps[i];
      if (!g || typeof g !== 'object') { failures.push(`gaps[${i}] 应为对象`); continue; }
      if (!g.storyId) failures.push(`gaps[${i}] 缺少 storyId`);
      if (!g.storyTitle) failures.push(`gaps[${i}] 缺少 storyTitle`);
      if (!g.missingObject) failures.push(`gaps[${i}] 缺少 missingObject`);
      if (!g.sourceNodeId) failures.push(`gaps[${i}] 缺少 sourceNodeId`);
      if (!['missing-entity', 'missing-field', 'missing-relation'].includes(g.gapType)) {
        failures.push(`gaps[${i}] gapType 非法：${g.gapType}（应为 missing-entity|missing-field|missing-relation）`);
      }
      if (!g.expectedCarrier) failures.push(`gaps[${i}] 缺少 expectedCarrier`);
      if (!g.evidence) failures.push(`gaps[${i}] 缺少 evidence`);
    }
  }
  if (!Array.isArray(data.resolved)) {
    failures.push('缺少或非数组字段：resolved（应为 JSON 数组）');
  } else {
    for (let i = 0; i < data.resolved.length; i++) {
      const r = data.resolved[i];
      if (!r || typeof r !== 'object') { failures.push(`resolved[${i}] 应为对象`); continue; }
      if (!r.storyId) failures.push(`resolved[${i}] 缺少 storyId`);
      if (!r.gapType) failures.push(`resolved[${i}] 缺少 gapType`);
      if (!r.reason) failures.push(`resolved[${i}] 缺少 reason`);
    }
  }
  return { ok: failures.length === 0, failures };
}

// ── requirement-coverage 门（plan 2026-09-03/requirement-coverage-judge-unified-entity-channel.md C5）──
// 信封 schema + gapType 枚举 + anchors 非空 + conflict 必带 userAnswer（已弹问）或 needsHumanReview=true（残余）。
// checker 只保清单可被机器消费，不判覆盖语义。
// **锚点真实性校验已取消**（2026-09-03 用户拍板：防臆造的收益不抵 checker↔prompt 格式契约脆性——
//   台账 id 连字符 vs prompt 示例冒号、多级编号点转义等任一侧漂移即误报红 → 重试死循环，得不偿失；
//   anchors 降为证据留痕：detect 仍须写条款级锚点供 fill 回读与人审追溯，但机械门不验真伪）。
const RC_LEGAL_GAP_TYPES = ['missing-entity', 'conflict', 'no-entity-expected'];
const RC_LEGAL_EXITS = ['fill-entity', 'needsHumanReview'];

function checkRequirementCoverage(content) {
  const failures = [];
  let data;
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    failures.push('未找到 JSON 对象，requirement-coverage 文件应包含 { "schemaVersion": 1, "gaps": [...], "resolved": [...] }');
    return { ok: false, failures };
  }
  try {
    data = JSON.parse(jsonMatch[0]);
  } catch (e) {
    failures.push('JSON 解析失败：' + e.message);
    return { ok: false, failures };
  }

  if (data.schemaVersion !== 1) failures.push(`schemaVersion 应为 1，实为 ${JSON.stringify(data.schemaVersion)}`);
  if (!data.generatedBy) failures.push('缺少 generatedBy');
  if (!['fresh', 'incremental'].includes(data.scenario)) {
    failures.push(`scenario 非法/缺：${JSON.stringify(data.scenario)}（应为 fresh|incremental）`);
  }

  if (!Array.isArray(data.gaps)) {
    failures.push('缺少或非数组字段：gaps（应为 JSON 数组，可为空数组）');
  } else {
    for (let i = 0; i < data.gaps.length; i++) {
      const g = data.gaps[i];
      if (!g || typeof g !== 'object') { failures.push(`gaps[${i}] 应为对象`); continue; }
      const label = `gaps[${i}]`;
      if (!g.gapId) failures.push(`${label} 缺少 gapId`);
      if (!RC_LEGAL_GAP_TYPES.includes(g.gapType)) {
        failures.push(`${label} gapType 非法：${g.gapType}（应为 ${RC_LEGAL_GAP_TYPES.join('|')}）`);
      }
      if (!g.subject) failures.push(`${label} 缺少 subject`);
      if (!g.reason) failures.push(`${label} 缺少 reason`);
      if (!Array.isArray(g.anchors) || g.anchors.length === 0 || g.anchors.every((a) => !String(a || '').trim())) {
        failures.push(`${label} 缺少 anchors 或全空（每条 gap 至少 1 个条款级锚点作证据留痕，供 fill 回读与人审追溯）`);
      }
      if (g.suggestedExit && !RC_LEGAL_EXITS.includes(g.suggestedExit)) {
        failures.push(`${label} suggestedExit 非法：${g.suggestedExit}（应为 ${RC_LEGAL_EXITS.join('|')}）`);
      }
      if (g.gapType === 'conflict') {
        const answered = typeof g.userAnswer === 'string' && g.userAnswer.trim().length > 0;
        const deferred = g.needsHumanReview === true;
        if (!answered && !deferred) {
          failures.push(`${label} gapType=conflict 必带 userAnswer（已 AskUserQuestion 拍板）或 needsHumanReview=true（残余通道），二者居其一——不允许未处置的 conflict`);
        }
      }
    }
  }
  if (!Array.isArray(data.resolved)) {
    failures.push('缺少或非数组字段：resolved（应为 JSON 数组，可为空数组）');
  } else {
    for (let i = 0; i < data.resolved.length; i++) {
      const r = data.resolved[i];
      if (!r || typeof r !== 'object') { failures.push(`resolved[${i}] 应为对象`); continue; }
      if (!r.gapId) failures.push(`resolved[${i}] 缺少 gapId`);
      if (!r.reason) failures.push(`resolved[${i}] 缺少 reason`);
    }
  }
  return { ok: failures.length === 0, failures };
}

// ── 能力矩阵通道（plan 2026-09-24/axis-registry-capability-matrix-dynamic-assembly §4 P0 item 4，
//    裁决点 D①：单一 JSON 数据文件）──
// 数据真源 = 本脚本同目录 shared/capability-matrix.json（与 src 侧 capability-matrix.ts 消费同一份，
// capability-matrix-sync.test.ts 字节锁死双副本）。判据逻辑分叉仍在 mjs 内、由矩阵数据驱动（I6）。
// fail-loud：矩阵文件缺失/不可解析/schema 不符/无覆盖 cell ⇒ 结构化红，禁静默落回默认判据（I4）。
function loadCapabilityMatrix() {
  const p = resolve(dirname(fileURLToPath(import.meta.url)), 'shared', 'capability-matrix.json');
  if (!existsSync(p)) return { ok: false, reason: `能力矩阵文件缺失：${p}（部署须携带 shared/capability-matrix.json）` };
  let data;
  try {
    data = JSON.parse(readFileSync(p, 'utf-8'));
  } catch (e) {
    return { ok: false, reason: `能力矩阵不可解析：${e.message}` };
  }
  if (data?._schema !== 'capability-matrix/v1') return { ok: false, reason: `能力矩阵 _schema 非法：${JSON.stringify(data?._schema)}（应为 capability-matrix/v1）` };
  if (!Array.isArray(data.cells) || data.cells.length === 0) return { ok: false, reason: '能力矩阵 cells 为空/非数组（I4 缺配显式爆）' };
  return { ok: true, value: data };
}

// persistence 轴读取（与 src 侧 tech-stack-truth.ts#backendPersistenceOf 三态语义逐值镜像——
// mjs 与 TS 是两个运行时、禁互相 import，语义漂移由双方各自的 fixture 锁兜底）：
// 从 cross-domain-relations.json 路径向上找 tech-stack.json（同 resolveDialectFromEntityPath 的
// 逐级上溯走法）。none / declared / absent；文件缺失或不可解析 ⇒ absent（走 legacy，禁第三种红）。
function persistenceAxisFromEntityPath(filePath) {
  let dir = dirname(resolve(filePath));
  for (let i = 0; i < 8 && dir; i++) {
    const tsPath = join(dir, 'tech-stack.json');
    if (existsSync(tsPath)) {
      try {
        const json = JSON.parse(readFileSync(tsPath, 'utf-8')) || {};
        const backend = json && typeof json === 'object' && !Array.isArray(json) ? json.backend : undefined;
        const raw = backend && typeof backend === 'object' && !Array.isArray(backend) && typeof backend.persistence === 'string' ? backend.persistence.trim() : '';
        if (!raw) return 'absent';
        const value = raw.toLowerCase();
        return value === 'none' || value === '不需要持久化' ? 'none' : 'declared';
      } catch {
        return 'absent';
      }
    }
    const parent = dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return 'absent';
}

// 矩阵 data-model 投影解析（P0 首个 mjs 消费方，消费点 = checkCrossDomainRelations 的零实体放行分支）：
// 无覆盖 cell / 投影缺配 ⇒ 结构化红（I4）。轴态仅含 persistence（serverSurface/appForm 的 cell 随
// P2/P3 落，届时本处轴态同步扩容——禁提前造不可达轴的匹配逻辑）。
function dataModelProjection(filePath) {
  const m = loadCapabilityMatrix();
  if (!m.ok) return m;
  const axes = { persistence: persistenceAxisFromEntityPath(filePath) };
  const hit = m.value.cells.find((c) => c && typeof c.match === 'object' && !Array.isArray(c.match)
    && Object.entries(c.match).every(([k, v]) => axes[k] === v));
  if (!hit) return { ok: false, reason: `无 cell 覆盖当前轴态 ${JSON.stringify(axes)}（I4：缺配必须显式爆，禁静默落回默认判据）` };
  const projection = hit.assert && hit.assert['data-model'];
  if (!projection) return { ok: false, reason: `cell ${JSON.stringify(hit.match)} 未声明 data-model 投影（I4/I5：判据挂载禁靠省略表达）` };
  return { ok: true, value: projection };
}

// R6② 前提判据（plan 2026-09-24/free-d9-… §13.4 N3 ②，axis-registry plan §11.3 合并实施；
// 时序修正见 axis-registry plan §12.4 dual-review F1——本模式唯一挂载点在 ③（波 checker +
// 任务内自检），requirement-coverage.json 由 ⑥ 产出、时点**晚于** ③，故本侧只判「在场则无
// 未处置 conflict」，**缺失⇒跳过**（缺席=时点合法，I3 缺席走 legacy，禁把「还没轮到 ⑥」当红——
// 否则 ③ agent 无合法修复通道，软停止+硬产物 checker 同链=逼 agent 编造）。
// 「文件必须存在」的存在性前提由 ⑥ 之后的挂载面消费：TS 侧 ⑩ 终态门
// （delivery-surface-gate.ts#judgeZeroPersistenceEntityForm，dual-review F1 修正）。
// 在场但不可解析 ⇒ 红（verification-gate-unparseable-evidence-must-red-not-skip：在场即可判的
// 证据不可判禁静默；本判据只在 zeroEntityDeclared 分支消费，零实体之外不新增红）。
function checkRequirementCoverageConflictFree(relationsPath) {
  const rcPath = resolve(dirname(resolve(relationsPath)), 'requirement-coverage.json');
  if (!existsSync(rcPath)) {
    return { ok: true, failures: [] };
  }
  let data;
  try {
    const raw = readFileSync(rcPath, 'utf-8');
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) return { ok: false, failures: ['requirement-coverage.json 未找到 JSON 对象——零实体声明前提判据不可判 ⇒ 红，禁静默'] };
    data = JSON.parse(m[0]);
  } catch (e) {
    return { ok: false, failures: [`requirement-coverage.json 不可解析（${e.message}）——零实体声明前提判据不可判 ⇒ 红，禁静默`] };
  }
  const failures = [];
  if (Array.isArray(data.gaps)) {
    for (let i = 0; i < data.gaps.length; i++) {
      const g = data.gaps[i];
      if (!g || typeof g !== 'object') continue;
      // 豁免谓词与 checkRequirementCoverage ⑥ 门逐字同口径（dual-review F9：禁漂移——truthy
      // userAnswer 会放行纯空白拍板，与 ⑥ 门对同一字段得出相反结论）。
      if (g.gapType === 'conflict' && !(typeof g.userAnswer === 'string' && g.userAnswer.trim().length > 0) && g.needsHumanReview !== true) {
        failures.push(`requirement-coverage.json gaps[${i}]（gapId=${g.gapId ?? '未填'}）存在未处置 conflict（无 userAnswer 且 needsHumanReview≠true）——零实体声明与未决冲突并存自相矛盾；先走 conflict 通道（弹问拍板或 needsHumanReview=true）再声明零实体`);
      }
    }
  }
  return { ok: failures.length === 0, failures };
}

// ── cross-domain-relations：promote-fk-* 的 targetField = 目标表真实主键（detect 阶段可修）──
// plan 2026-11-03/pre-delta-gate-scope-and-checker-boundary §2.1/§2.3/§8：
//   - 数据源 = 由 relations 清单路径推导的同目录 `code-schema.json`（清单在 <backend>/_meta/ 下）；
//     文件缺席 / 不可解析 / 版本不是 v2 / 无 sources[] ⇒ **跳过**（fresh/free 无基线，不得因此红）；
//   - 只对 promote-fk-keep-varchar / promote-fk-existing-id 校验 targetField；
//     mark-snapshot（展示列）/ manual-review / create-mapping-table（§8 拍板跳过 PK）/ merge-into
//     一律不参与 PK 校验；
//   - 表名/列名按 lib/sql-identifier.mjs 归一（反引号/双引号、大小写、schema 前缀）；
//   - 复合主键 / 多源同名 / 缺主键 ⇒ failure（文案点名 composite / multi-source / missing-pk
//     并带修复指令）；目标表不在基线（新表）⇒ 跳过；
//   - 新 failure 追加在既有结构校验之后，不改写既有文案的顺序/格式。
const RELATION_FK_ACTIONS = new Set(['promote-fk-keep-varchar', 'promote-fk-existing-id']);
const RELATION_TARGET_FIELD_FIX_HINT = '若无法确认真实主键，改 action=manual-review 进 unresolved（禁猜 id/主键）';

/**
 * 读取 relations 清单同目录的 code-schema.json。
 *
 * 正常路径只认 v3（引用 = sourceId/owner/kind/name，无 objectId）；缺席 / 非 v3 / 无 sources[]
 * 一律 absent（跳过）。v2 是 objectId 时代产物，必须经集中迁移器升级，本门不就地兼容。
 */
function loadRelationPkBaseline(relationsPath) {
  const codeSchemaPath = resolve(dirname(resolve(relationsPath)), 'code-schema.json');
  if (!existsSync(codeSchemaPath)) return { status: 'absent' };
  let schema;
  try {
    schema = JSON.parse(readFileSync(codeSchemaPath, 'utf-8'));
  } catch {
    // 与「缺席/fresh」同口径跳过：本门不把基线可解析性当判据（版本守卫在增量建档门）。
    return { status: 'absent' };
  }
  if (!schema || typeof schema !== 'object' || Array.isArray(schema)) return { status: 'absent' };
  if (schema.schemaVersion !== 3 || !Array.isArray(schema.sources)) return { status: 'absent' };
  return { status: 'ok', schema };
}

/**
 * 对 promote-fk-* 的 targetField 做真实主键校验；失败追加进 failures。
 * 依赖 lib/ 在运行时按需加载（同文件头 shared/cross-domain-decl.mjs 纪律：静态 import 会把
 * 部署面缺文件的 ERR_MODULE_NOT_FOUND 提前到模块加载期，一次炸掉全部 mode）。
 */
async function checkRelationTargetFieldPrimaryKeys(data, relationsPath, failures) {
  const baseline = loadRelationPkBaseline(relationsPath);
  if (baseline.status !== 'ok') return;
  // 无 promote-fk-*（带 targetTable）条目时不加载 lib，也不因部署面缺 lib 而红。
  const hasFkTarget = Array.isArray(data.relations)
    && data.relations.some((r) => r && RELATION_FK_ACTIONS.has(r.action) && r.targetTable);
  if (!hasFkTarget) return;

  let resolvePrimaryKeysV3;
  let normalizeSqlIdentifier;
  let normalizeTableName;
  let findTableEntries;
  try {
    const [pkResolver, sqlIdentifier] = await Promise.all([
      import('./lib/entity-pk-resolver.mjs'),
      import('./lib/sql-identifier.mjs'),
    ]);
    ({
      resolvePrimaryKeysV3,
    } = pkResolver);
    ({
      normalizeSqlIdentifier,
      normalizeTableName,
      findTableEntries,
    } = sqlIdentifier);
  } catch (e) {
    failures.push(
      `FK 目标主键判据不可用：部署面缺 lib/entity-pk-resolver.mjs 或 lib/sql-identifier.mjs（${e?.message ?? e}）——须随部署面携带 lib/ 后重试`,
    );
    return;
  }

  // v3：身份 = tableRef 四字段；歧义/缺主键条目只带 tableRef，按归一化裸表名筛选（仅用于
  // 文本查表，不据此合并对象）。同名跨源在 byTableName 中仍是多条，会走「命中多个对象」红停。
  const resolved = resolvePrimaryKeysV3(baseline.schema);
  const ambiguities = (resolved && resolved.ambiguities) || [];
  const missingPkList = (resolved && resolved.missingPk) || [];
  for (let i = 0; i < data.relations.length; i++) {
    const r = data.relations[i];
    if (!r || typeof r !== 'object') continue;
    if (!RELATION_FK_ACTIONS.has(r.action)) continue;
    // targetTable 缺失由既有结构校验报（A 类必须写 targetTable）；此处不重复。
    if (!r.targetTable) continue;

    const tableLabel = normalizeTableName(r.targetTable) || String(r.targetTable);
    const entries = findTableEntries(resolved, r.targetTable);
    const ambiguity =
      ambiguities.find((item) => normalizeTableName(item?.tableRef?.name) === tableLabel) || null;
    const missingPk = missingPkList.filter(
      (item) => normalizeTableName(item?.tableRef?.name) === tableLabel,
    );
    // 目标表不在基线（新表）⇒ 跳过：本门拿不到它的真实主键，交 build/后续阶段。
    if (entries.length === 0 && !ambiguity && missingPk.length === 0) continue;

    if (ambiguity) {
      failures.push(
        `relations[${i}] action=${r.action} 目标表「${tableLabel}」${ambiguity.kind}：同名表在基线中不唯一，真实主键不可判定——按 tableRef（sourceId/owner/kind/name）四字段消歧；${RELATION_TARGET_FIELD_FIX_HINT}`,
      );
      continue;
    }
    if (entries.length === 0 && missingPk.length > 0) {
      failures.push(
        `relations[${i}] action=${r.action} 目标表「${tableLabel}」缺主键（missing-pk）：无法校验 targetField 为真实主键——补基线主键声明；${RELATION_TARGET_FIELD_FIX_HINT}`,
      );
      continue;
    }
    if (entries.length !== 1) {
      failures.push(
        `relations[${i}] action=${r.action} 目标表「${tableLabel}」在基线中命中 ${entries.length} 个对象（multi-source/同名不唯一）：真实主键不可判定——按 tableRef（sourceId/owner/kind/name）四字段消歧；${RELATION_TARGET_FIELD_FIX_HINT}`,
      );
      continue;
    }

    const primaryKey = entries[0].primaryKey;
    if (!primaryKey || !Array.isArray(primaryKey.columns) || primaryKey.columns.length === 0) {
      failures.push(
        `relations[${i}] action=${r.action} 目标表「${tableLabel}」缺主键（missing-pk）：无法校验 targetField 为真实主键——补基线主键声明；${RELATION_TARGET_FIELD_FIX_HINT}`,
      );
      continue;
    }
    if (primaryKey.composite || primaryKey.columns.length > 1) {
      const cols = primaryKey.columns.map((column) => column.name).join(', ');
      failures.push(
        `relations[${i}] action=${r.action} 目标表「${tableLabel}」是复合主键（composite：${cols}）：promote-fk-* 的 targetField 必须是单列真实主键——复合主键表改走 manual-review 进 unresolved（禁猜单列主键）`,
      );
      continue;
    }

    const realPrimaryKey = primaryKey.columns[0].name;
    const rawTargetField = typeof r.targetField === 'string' ? r.targetField : '';
    if (!rawTargetField.trim()) {
      failures.push(
        `relations[${i}] action=${r.action} 缺 targetField（应为目标表「${tableLabel}」的真实主键列「${realPrimaryKey}」）——补 targetField=${realPrimaryKey}；${RELATION_TARGET_FIELD_FIX_HINT}`,
      );
      continue;
    }
    if (normalizeSqlIdentifier(rawTargetField) !== normalizeSqlIdentifier(realPrimaryKey)) {
      failures.push(
        `relations[${i}] action=${r.action} targetField=${JSON.stringify(r.targetField)} 不是目标表「${tableLabel}」的真实主键列「${realPrimaryKey}」——把 targetField 改为「${realPrimaryKey}」；${RELATION_TARGET_FIELD_FIX_HINT}`,
      );
    }
  }
}

// ── cross-domain-relations：mark-snapshot 的 targetField = 目标表真实展示列（detect 阶段可修）──
// plan 2026-11-03/pre-delta-gate-scope-and-checker-boundary §10（T6/T6.1）：
//   - 数据源同 promote-fk-* PK 判据：relations 同目录 code-schema.json；缺席/不可解析/非 v2 ⇒ absent；
//   - 只判 action=mark-snapshot 且 targetTable 非空（系统外 targetTable:null 跳过）；
//   - 目标表不在基线（本轮新表）⇒ 跳过：新表列由 entity DDL 保证，本门无基线列集合；
//   - db-only identity-only 对象（basis='db-only' / diffable=false / columns=[]）不产生列集合：
//     同名对象**只有**这类 ⇒ absent（列集合不可判，跳过而不误红）；同表同时有完整 code table
//     ⇒ 用 code table 的列集合（identity-only 对象不贡献列）；
//   - 启用方式与 --require-fk-pk 同 opt-in：--require-display-column（默认关闭，默认调用逐字不变）；
//   - 位置追加在 checkRelationTargetFieldPrimaryKeys 之后，不改既有 failure 顺序/格式。
const RELATION_MARK_SNAPSHOT_ACTION = 'mark-snapshot';
const RELATION_MARK_SNAPSHOT_FIX_HINT =
  '请从 code-schema.json 选择该表真实展示列（sys_user 如 account_name/user_name，sys_dept 如 dept_name），禁猜 name；无法确定唯一展示列改 action=manual-review 进 unresolved';

/** code-schema 对象是否 identity-only（DB-only 表）：这类对象不提供可判的列集合。 */
function isIdentityOnlySchemaObject(object) {
  if (!object || typeof object !== 'object') return true;
  if (object.basis === 'db-only') return true;
  if (object.diffable === false) return true;
  return !Array.isArray(object.columns) || object.columns.length === 0;
}

/** 按归一化裸表名索引 code-schema 表对象（不做 PK 语义合并；同表多对象由列集合取并）。 */
function buildSchemaTableIndex(schema, normalizeTableName) {
  const byTableName = new Map();
  for (const source of (schema && schema.sources) || []) {
    for (const object of (source && source.objects) || []) {
      if (!object || !object.name) continue;
      if (object.kind && object.kind !== 'table') continue;
      const table = normalizeTableName(object.name);
      if (!table) continue;
      const list = byTableName.get(table) || [];
      list.push(object);
      byTableName.set(table, list);
    }
  }
  return byTableName;
}

/**
 * 目标表的基线列集合（列名归一化）。
 * 只取完整 code table；identity-only 对象不贡献列。
 * 只有 identity-only 对象 ⇒ null（列集合不可判，调用方跳过，**不得当作空 Set 误红**）。
 */
function baselineColumnSetOf(objects, normalizeSqlIdentifier) {
  const completeObjects = (objects || []).filter((object) => !isIdentityOnlySchemaObject(object));
  if (completeObjects.length === 0) return null;
  const columns = new Set();
  for (const object of completeObjects) {
    for (const column of object.columns || []) {
      const rawName = typeof column === 'string' ? column : column && column.name;
      const name = normalizeSqlIdentifier(rawName);
      if (name) columns.add(name);
    }
  }
  return columns.size === 0 ? null : columns;
}

/**
 * 对 mark-snapshot 的 targetField 做目标表真实展示列校验；失败追加进 failures。
 * 与 PK 判据同纪律：lib 运行时按需加载；基线缺席/新表/列集合不可判一律跳过。
 */
async function checkRelationMarkSnapshotDisplayColumns(data, relationsPath, failures) {
  const baseline = loadRelationPkBaseline(relationsPath);
  if (baseline.status !== 'ok') return;
  const hasSnapshotTarget = Array.isArray(data.relations)
    && data.relations.some((r) => r && r.action === RELATION_MARK_SNAPSHOT_ACTION && r.targetTable);
  if (!hasSnapshotTarget) return;

  let normalizeSqlIdentifier;
  let normalizeTableName;
  try {
    ({ normalizeSqlIdentifier, normalizeTableName } = await import('./lib/sql-identifier.mjs'));
  } catch (e) {
    failures.push(
      `mark-snapshot 展示列判据不可用：部署面缺 lib/sql-identifier.mjs（${e?.message ?? e}）——须随部署面携带 lib/ 后重试`,
    );
    return;
  }

  const tableIndex = buildSchemaTableIndex(baseline.schema, normalizeTableName);
  for (let i = 0; i < data.relations.length; i++) {
    const r = data.relations[i];
    if (!r || typeof r !== 'object') continue;
    if (r.action !== RELATION_MARK_SNAPSHOT_ACTION) continue;
    // 系统外展示目标（targetTable:null）不做本判据；targetTable 缺失的结构问题由既有校验报。
    if (!r.targetTable) continue;

    const objects = tableIndex.get(normalizeTableName(r.targetTable)) || [];
    // 目标表不在基线（本轮新建表）⇒ 跳过：新表列由 entity DDL 保证。
    if (objects.length === 0) continue;
    const columns = baselineColumnSetOf(objects, normalizeSqlIdentifier);
    // 只有 db-only identity-only 对象 ⇒ 列集合不可判（absent），跳过而不误红。
    if (!columns) continue;

    const tableLabel = normalizeTableName(r.targetTable) || String(r.targetTable);
    const rawTargetField = typeof r.targetField === 'string' ? r.targetField : '';
    const targetFieldLabel = rawTargetField.trim() || '（缺失）';
    if (!rawTargetField.trim() || !columns.has(normalizeSqlIdentifier(rawTargetField))) {
      failures.push(
        `relations[${i}] action=mark-snapshot targetField=\`${targetFieldLabel}\` 不在目标表「${tableLabel}」的基线列集合；${RELATION_MARK_SNAPSHOT_FIX_HINT}`,
      );
    }
  }
}

/**
 * @param {{requireFkPk?: boolean, requireDisplayColumn?: boolean}} [options]
 *   `requireFkPk` 默认 **false**（plan 2026-11-03/strict-separation-micro-incremental-vs-legacy-workflows T2）：
 *   无 `--require-fk-pk` 时行为与 F4 之前逐字一致（不做 FK 目标主键校验）；
 *   只有七阶段 micro-incremental-v1 的 detect 包装显式传该 flag 才启用 PK 判据。
 *   `requireDisplayColumn` 默认 **false**（plan 2026-11-03/pre-delta-gate-scope-and-checker-boundary §10）：
 *   无 `--require-display-column` 时不校验 mark-snapshot 展示列，默认调用逐字保持改动前行为。
 */
async function checkCrossDomainRelations(content, filePath, options = {}) {
  const failures = [];
  let data;
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    failures.push('未找到 JSON 对象，cross-domain-relations 文件应包含 { "tableUniverse": [...], "relations": [...], "unresolved": [...] }');
    return { ok: false, failures };
  }
  try {
    data = JSON.parse(jsonMatch[0]);
  } catch (e) {
    failures.push('JSON 解析失败：' + e.message);
    return { ok: false, failures };
  }
  // 实体级同语义重复（field=__entity_dup__）无损收口门（plan 2026-09-07/entity-dup-mandatory-merge-by-reference-count C2）：
  // 重复必合并（禁止 manual-review 挂起——挂起无人消费=静默出厂，沙箱实证双账号表）+ fieldMapping 必须覆盖
  // 被合并方 DDL 全部列（属性零丢失，detect 自检时刻两文件俱在可机械对照）。
  // 文件定位按 CREATE TABLE 表名扫描（carrier=DDL 表名≠文件 slug 是本仓已知实况，见
  // docs/hicode-spec/plan/2026-08-26/apply-carrier-tablename-vs-slug-and-mergeinto-dispatch），
  // 列解析用宽松列行形状（首 token 标识符 + 任意类型词），类型枚举不设白名单（TIMESTAMP/ENUM 等一律覆盖）。
  const findEntityColumns = (entityDir, table) => {
    let files = [];
    try {
      files = readdirSync(entityDir).filter((f) => /^entity-.*\.md$/.test(f));
    } catch {
      return null;
    }
    const esc = table.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const tableRe = new RegExp('CREATE\\s+TABLE\\s+(?:IF\\s+NOT\\s+EXISTS\\s+)?`?' + esc + '`?\\s*\\(', 'i');
    for (const f of files) {
      const ddl = readFileSync(resolve(entityDir, f), 'utf-8');
      if (!tableRe.test(ddl)) continue;
      const cols = [];
      let inTable = false;
      for (const line of ddl.split('\n')) {
        if (/CREATE\s+TABLE/i.test(line)) { inTable = true; continue; }
        if (inTable && /^\s*\)\s*(ENGINE|;)?/i.test(line)) break;
        if (inTable) {
          const m = line.match(/^\s+`?([a-zA-Z_][a-zA-Z0-9_]*)`?\s+[A-Za-z]/);
          if (m && !/^(PRIMARY|UNIQUE|KEY|INDEX|CONSTRAINT|FOREIGN|CHECK)$/i.test(m[1])) cols.push(m[1]);
        }
      }
      return cols;
    }
    return null;
  };
  const validActions = ['promote-fk-keep-varchar', 'promote-fk-existing-id', 'mark-snapshot', 'manual-review', 'create-mapping-table', 'merge-into'];
  const validSignals = ['A-hard', 'A-soft', 'B-hard', 'B-soft'];

  // 零实体退化出口（plans/backend/ENTITY-CANONICAL-NONE.md）：本系统无业务表、无 entity-*.md 时为合法场景，
  // 实读载体 = cross-domain-relations.json#zeroEntity（且 relations/unresolved 皆空）。此时 tableUniverse
  // 为空是正确结论，非漏产出；仅当 zeroEntity=true 且 relations/unresolved 皆空时放行空集（有跨域关系
  // 却声明零实体=自相矛盾，仍报错）。
  //   R6②（plan 2026-09-24/free-d9-… §13.4 N3 + axis-registry plan §11.3 合并实施，2026-09-25；
  //   时序修正见 axis-registry plan §12.4 F1）：zeroEntity 声明还须过「requirement-coverage 无未处置
  //   conflict」前提——requirement-coverage.json（⑥ 覆盖判定产出）是冲突处置的权威载体。⚠️ 时点实况：
  //   本模式唯一挂载点在 ③，⑥ 晚于 ③ ⇒ 本侧只判「在场则无未处置 conflict」，缺失⇒跳过（时点合法）；
  //   存在性前提由 ⑥ 之后的 TS ⑩ 终态门消费（delivery-surface-gate.ts#judgeZeroPersistenceEntityForm）。
  const zeroEntityDeclared = data.zeroEntity === true
    && Array.isArray(data.relations) && data.relations.length === 0
    && Array.isArray(data.unresolved) && data.unresolved.length === 0;

  if (!Array.isArray(data.tableUniverse)) {
    failures.push('缺少或非数组字段：tableUniverse（应为 JSON 数组，全部 entity DDL 表名全集）');
  } else if (data.tableUniverse.length === 0) {
    if (!zeroEntityDeclared) {
      failures.push('tableUniverse 为空（应含全部 entity DDL 表名；仅声明 zeroEntity=true 且无 relations/unresolved 的零实体场景可为空）');
    } else {
      // P0 item 4 矩阵接线（axis-registry plan §4）：zeroEntity 放行前先过能力矩阵的 data-model
      // 投影——矩阵不可判/无覆盖 cell ⇒ 结构化红（I4 fail-loud，通道由此成为装配义务：部署必须
      // 携带 shared/capability-matrix.json）。P0 阶段投影值**不改变**既有 zeroEntityDeclared 语义
      // （回归锁：三态行为与本改动前逐字节一致，矩阵在此是接线而非行为开关——投影分叉行为随 P2 落）。
      const proj = dataModelProjection(filePath);
      if (!proj.ok) failures.push(`[capability-matrix] ${proj.reason}`);
      // R6② 前提判据：零实体声明 × requirement-coverage 的冲突处置态。文件缺失/不可解析当红
      // （verification-gate-unparseable-evidence-must-red-not-skip：证据不可判禁静默跳过）；
      // 仅在 zeroEntityDeclared 分支消费（缺席场景的存量轮不新增红——I3 缺席走 legacy）。
      const rcCheck = checkRequirementCoverageConflictFree(filePath);
      if (!rcCheck.ok) failures.push(...rcCheck.failures);
    }
  } else {
    for (let i = 0; i < data.tableUniverse.length; i++) {
      if (typeof data.tableUniverse[i] !== 'string' || !data.tableUniverse[i]) {
        failures.push(`tableUniverse[${i}] 应为非空字符串`);
      }
    }
  }

  if (!Array.isArray(data.relations)) {
    failures.push('缺少或非数组字段：relations（应为 JSON 数组）');
  } else {
    for (let i = 0; i < data.relations.length; i++) {
      const r = data.relations[i];
      if (!r || typeof r !== 'object') { failures.push(`relations[${i}] 应为对象`); continue; }
      if (!r.carrier) failures.push(`relations[${i}] 缺少 carrier（持键方实体表名）`);
      if (r.action !== 'merge-into' && !r.field) failures.push(`relations[${i}] 缺少 field`);
      if (!r.action) {
        failures.push(`relations[${i}] 缺少 action`);
      } else if (!validActions.includes(r.action)) {
        failures.push(`relations[${i}] action 非法：${r.action}（应为 ${validActions.join('|')}）`);
      }
      // A 类必须有 targetTable
      const isAClass = r.action === 'promote-fk-keep-varchar' || r.action === 'promote-fk-existing-id' || r.action === 'create-mapping-table';
      if (isAClass && !r.targetTable) {
        failures.push(`relations[${i}] action=${r.action}（A 类）必须写 targetTable（目标表名）`);
      }
      // promote-fk-keep-varchar 必须有 newField
      if (r.action === 'promote-fk-keep-varchar' && !r.newField) {
        failures.push(`relations[${i}] action=promote-fk-keep-varchar 必须写 newField（升 FK 后的新列名 *_id）`);
      }
      // mark-snapshot 必须有 snapshotMark
      if (r.action === 'mark-snapshot' && !r.snapshotMark) {
        failures.push(`relations[${i}] action=mark-snapshot 必须写 snapshotMark（快照标注文案）`);
      }
      // create-mapping-table 必须有 mapping 表名（用 newField 或 targetTable 承载）
      if (r.action === 'create-mapping-table' && !r.newField && !r.targetTable) {
        failures.push(`relations[${i}] action=create-mapping-table 必须写 newField 或 targetTable（映射表名）`);
      }
      // merge-into 是实体级同语义合并（非字段级 FK）：carrier=被合并方、targetTable=保留方、reason=归属依据、fieldMapping=独有字段映射对象（无独有字段时为空对象）
      if (r.action === 'merge-into') {
        if (!r.targetTable) failures.push(`relations[${i}] action=merge-into 必须写 targetTable（保留方表名）`);
        if (!r.reason) failures.push(`relations[${i}] action=merge-into 必须写 reason（同语义重复+主语义归属判定依据）`);
        if (r.fieldMapping === undefined || r.fieldMapping === null || typeof r.fieldMapping !== 'object' || Array.isArray(r.fieldMapping)) {
          failures.push(`relations[${i}] action=merge-into 必须写 fieldMapping（对象：被合并方字段名→保留方字段名，无独有字段时为空对象 {}）`);
        }
        // 结构不变量（非语义）：被合并方 carrier 与保留方 targetTable 不可同一表——
        // 自合并必非法，检出 carrier/targetTable 填反（如 material_master 自合并）。
        // 见 docs/hicode-spec/plan/2026-08-20/fix-mapping-carrier-checker-enoent-and-detect-merge-step5.md。
        if (r.carrier && r.targetTable && r.carrier === r.targetTable) {
          failures.push(`relations[${i}] action=merge-into carrier==targetTable（${r.carrier}），被合并方与保留方不可同一表——检查 carrier/targetTable 是否填反`);
        }
      }
      // 实体级同语义重复（field=__entity_dup__）：必合并（merge-into）、禁 manual-review/禁进 unresolved；
      // fieldMapping 必须无损覆盖被合并方 DDL 全部列（plan 2026-09-07/entity-dup-mandatory-merge-by-reference-count C2）。
      if (r.field === '__entity_dup__' && r.action && r.action !== 'merge-into') {
        failures.push(`relations[${i}] 实体级同语义重复（field=__entity_dup__）必须落 action=merge-into（重复必合并，禁止 ${r.action} 挂起——挂起无人消费=静默出厂）`);
      }
      if (r.action === 'merge-into' && r.field === '__entity_dup__' && filePath) {
        const entityDir = resolve(filePath, '..', '..');
        const carrierCols = findEntityColumns(entityDir, r.carrier);
        if (carrierCols === null) {
          failures.push(`relations[${i}] field=__entity_dup__：读不到承载表 ${r.carrier} 的实体文件（按 CREATE TABLE 表名扫描 ${resolve(entityDir)}/entity-*.md，detect 自检时刻两文件俱在，缺失=上游异常）`);
        } else {
          const mapped = new Set(Object.keys(r.fieldMapping || {}));
          const missing = carrierCols.filter((c) => !mapped.has(c));
          if (missing.length > 0) {
            failures.push(`relations[${i}] field=__entity_dup__：fieldMapping 未覆盖被合并方 ${r.carrier} 全部列（属性零丢失）——缺失：${missing.join(', ')}（同名同语义映射同名，保留方缺→加列，同名不同语义→重命名映射）`);
          }
        }
      }
      if (r.action !== 'merge-into' && !r.relationDecl) failures.push(`relations[${i}] 缺少 relationDecl（跨域关系声明文案）`);
      if (r.signal && !validSignals.includes(r.signal)) {
        failures.push(`relations[${i}] signal 非法：${r.signal}（应为 ${validSignals.join('|')}，可省略）`);
      }
    }
    // 既有结构校验之后追加：promote-fk-* 的 targetField 必须是目标表真实主键（基线缺席则跳过）。
    // 仅在显式 `--require-fk-pk` 时启用——默认调用（base detect / 旧消费者）逐字保持改动前行为。
    if (options.requireFkPk === true) {
      await checkRelationTargetFieldPrimaryKeys(data, filePath, failures);
    }
    // mark-snapshot 的 targetField 必须是目标表真实展示列；同样 opt-in 且追加在 PK 判据之后，
    // 不改既有 failure 顺序/格式（plan 2026-11-03/pre-delta-gate-scope-and-checker-boundary §10）。
    if (options.requireDisplayColumn === true) {
      await checkRelationMarkSnapshotDisplayColumns(data, filePath, failures);
    }
  }

  if (!Array.isArray(data.unresolved)) {
    failures.push('缺少或非数组字段：unresolved（应为 JSON 数组，manual-review 条目归此）');
  } else {
    for (let i = 0; i < data.unresolved.length; i++) {
      const r = data.unresolved[i];
      if (!r || typeof r !== 'object') { failures.push(`unresolved[${i}] 应为对象`); continue; }
      if (!r.carrier) failures.push(`unresolved[${i}] 缺少 carrier`);
      if (!r.field) failures.push(`unresolved[${i}] 缺少 field`);
      if (!r.reason) failures.push(`unresolved[${i}] 缺少 reason（待确认原因）`);
      // 实体级同语义重复不得挂 unresolved（重复必合并，plan 2026-09-07/entity-dup-mandatory-merge-by-reference-count C2）
      if (r.field === '__entity_dup__') {
        failures.push(`unresolved[${i}] 实体级同语义重复（field=__entity_dup__）禁止挂起——必须落 relations 的 action=merge-into（保留方=被引用多者）`);
      }
    }
  }

  return { ok: failures.length === 0, failures };
}

// ── skeleton-conventions.json 结构门（plan 2026-09-09/root-package-contract-consumers-stack-neutral-roles §3.4）──
// 北极星内（schema 形状）：只验「顶层信封 + 角色在场 + 记录自洽」，单文件零格式契约、零盘面/跨文件依赖。
// 栈中立：角色名是抽象角色，判据无任何 Java/Maven 字面量——换栈零改动（值的栈味在 prompt 判据文字
// 与 <stack>-impl 知识文档层）。新增角色 = 本常量 + backend-design prompt 判据 + role-lock 测试三处同步。
// 失败 LLM 可修：归位者是本文件唯一 writer，checkerFeedback 定向回流（3 轮 stale-abort 兜底）；
// 失败消息自带同款示例（红的消息即修法，防 checker↔prompt 口径漂移式死循环）。
// 缺角色 key ≠ 显式 absent：缺 key 会被 build 消费方当 absent 静默降级（如 layerPackages 缺失则
// 实体子包不预建、段 A 并发 mkdir 竞争防护失效），故缺 key 即红、absent 须显式。
export const CONVENTIONS_ROLES = [
  'responseEnvelope',
  'errorCode',
  'pageVo',
  'mapperStyle',
  'testAnnotations',
  'testDataSource',
  'failureStyle',
  'bootModule',
  'layerPackages',
  'commonPackageMapping',
];

const CONVENTIONS_TOP_KEYS = ['rootPackage', 'module', 'conventions'];

const listShapeExamples = {
  layerPackages: '示例 layers:["entity","dto","vo","repository","service"]（JPA 形态，照盘面真实子包名）',
  commonPackageMapping: '示例 mapping:{"home_auth":"common.auth"}（key=域标识，value=根包下相对包路径）',
};

export function checkSkeletonConventionsStructure(json) {
  const failures = [];
  // 1) 顶层信封：schema 外自由文本字段禁写（strictBoundaries/notes 等散文数组史有复发）
  for (const k of Object.keys(json)) {
    if (!CONVENTIONS_TOP_KEYS.includes(k)) {
      failures.push(`顶层 schema 外 key："${k}"（只允许 ${CONVENTIONS_TOP_KEYS.join('/')}；逐角色结论一律进 conventions[role]，禁顶层散文）`);
    }
  }
  // 2) rootPackage：build 侧根包解析的 SOT，缺失即 build 红停——design 期先拦
  if (typeof json.rootPackage !== 'string' || !json.rootPackage.trim()) {
    failures.push('rootPackage 缺失或非非空 string（根包契约 SOT，示例 rootPackage:"com.company.<appName>"；从骨架包树派生，禁臆造）');
  }
  // 3) 角色在场 + 记录自洽
  const convs = json.conventions;
  if (!convs || typeof convs !== 'object' || Array.isArray(convs)) {
    failures.push('conventions 缺失或非 object（key=角色名，value=角色记录）');
    return failures;
  }
  for (const role of CONVENTIONS_ROLES) {
    if (!(role in convs)) {
      failures.push(
        `conventions 缺角色 "${role}"（共 ${CONVENTIONS_ROLES.length} 角色；骨架无该角色须显式 {"${role}":{"role":"${role}","absent":true}}——缺 key 会被 build 侧当 absent 静默降级，不作数）`
      );
      continue;
    }
    const rec = convs[role];
    if (!rec || typeof rec !== 'object' || Array.isArray(rec)) {
      failures.push(`conventions["${role}"] 应为角色记录 object`);
      continue;
    }
    const samplePaths = rec.evidence && Array.isArray(rec.evidence.samplePaths) ? rec.evidence.samplePaths : null;
    if (rec.absent === true) {
      const leaked = ['fqn', 'className', 'layers', 'mapping'].filter((k) => k in rec && rec[k] != null);
      if (leaked.length > 0) {
        failures.push(`conventions["${role}"].absent:true ⇒ 不得带 ${leaked.join('/')}（显式缺席不造类不臆测）`);
      }
      if (samplePaths && samplePaths.length > 0) {
        failures.push(`conventions["${role}"].absent:true ⇒ 不得带 evidence.samplePaths（显式缺席无采样）`);
      }
      continue;
    }
    if (!samplePaths || samplePaths.length === 0) {
      failures.push(`conventions["${role}"] 非 absent ⇒ 须带 evidence.samplePaths 非空（判据=骨架实际在用，采样可溯）；示例 evidence:{samplePaths:["<骨架内真实路径>"]}`);
    }
    if (role === 'layerPackages') {
      if (!Array.isArray(rec.layers) || rec.layers.length === 0 || !rec.layers.every((s) => typeof s === 'string' && s.trim())) {
        failures.push(`conventions["layerPackages"] 非 absent ⇒ 须带 layers 非空 string[]（消费方照清单逐字 mkdir）；${listShapeExamples.layerPackages}`);
      }
    } else if (role === 'commonPackageMapping') {
      const mapping = rec.mapping;
      const mappingOk =
        mapping && typeof mapping === 'object' && !Array.isArray(mapping) &&
        Object.keys(mapping).length > 0 &&
        Object.values(mapping).every((v) => typeof v === 'string' && v.trim());
      if (!mappingOk) {
        failures.push(`conventions["commonPackageMapping"] 非 absent ⇒ 须带 mapping 非空 object<string,string>；${listShapeExamples.commonPackageMapping}`);
      }
    } else if (rec.fqn == null && rec.className == null) {
      failures.push(`conventions["${role}"] 非 absent ⇒ 必带 fqn 或 className（真名+FQN，禁臆测字面名）`);
    }
  }
  return failures;
}

/**
 * 设计期判据：读 README 同级的 `_meta/engineering-plan.json` 最小自描述。
 *
 * 为什么这里不 import `backend-common.mjs`：本文件被测试 harness 单独拷贝执行，
 * 新增静态 import 会制造 ERR_MODULE_NOT_FOUND 假红（见文件头 scenario 解析同款纪律）。
 * 只回答「fresh micro 是否已进入新交付路径」：方案不在场 ⇒ absent（legacy 判据逐字不变）；
 * 在场但版本/形态不符 ⇒ invalid（调用方必须报红，不能当 legacy）。
 */
function readFreshMicroPlanStateNear(filePath) {
  const planPath = resolve(filePath, '..', '_meta', 'engineering-plan.json');
  if (!existsSync(planPath)) return { kind: 'absent', planPath };
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(planPath, 'utf-8'));
  } catch {
    return { kind: 'invalid', planPath, reason: '工程方案不是合法 JSON' };
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { kind: 'invalid', planPath, reason: '工程方案顶层必须是 JSON 对象' };
  }
  if (parsed.schemaVersion !== '1') {
    return {
      kind: 'invalid',
      planPath,
      reason: `工程方案版本不符（期望 schemaVersion="1"，实际 ${JSON.stringify(parsed.schemaVersion)}）`,
    };
  }
  if (parsed.scenario !== 'fresh' || parsed.form !== 'micro') {
    return {
      kind: 'invalid',
      planPath,
      reason: `工程方案形态不符（scenario=${JSON.stringify(parsed.scenario)}、form=${JSON.stringify(parsed.form)}）`,
    };
  }
  return { kind: 'fresh-micro', planPath };
}

/**
 * architecture 门（9 章骨架 / §9 领域表 / 返回风格 / 禁占位与绝对路径）。
 *
 * scenario（plan 2026-09-23/plans-free-mode-third-scenario-and-stack-agnostic-clarify 条目 6 / D5 桶 C）：
 * `'free'` = 自由模式——不跑 ASSEMBLE、**无后端骨架**，故下面两条「骨架派生」判据整支摘除：
 *   ① `_meta/skeleton-conventions.json` 须存在且可解析；
 *   ② `checkSkeletonConventionsStructure` 的 10 角色结构门（rootPackage 非空 / 逐角色自洽 / 采样路径非空）。
 * 摘除是**显式场景分支**，不是「文件不存在就跳过」——后者会把「忘了产出」也判绿
 * （对齐 verification-gate-unparseable-evidence-must-red-not-skip：证据不可判必红，禁 skip 兜底）。
 * 缺失 `--scenario` 即按 fresh 判据（默认段），漏传在 free 下红，属 fail-loud。
 * 其余判据（章标题集合 / §9 领域表表头列序 / 返回风格 / 占位与绝对路径禁令）**两链同判据**，
 * 自由模式正文已逐字保留这些结构（D9 交付面结构门对两链同构）。
 */
function checkArchitecture(text, filePath, scenario = 'fresh') {
  const failures = [];

  // 1. 9 章骨架必须齐全，标题分别命中各章关键语义
  const requiredChapters = [
    { key: '技术栈', name: '项目技术栈（后端）' },
    { key: '架构风格', name: '架构风格' },
    { key: '模块映射', name: '业务领域 → 模块映射' },
    { key: '接口契约', name: '接口契约' },
    { key: '集成', name: '集成' },
    { key: '安全', name: '安全考量' },
    { key: 'APM', name: 'APM/可运维性' },
    { key: '命名规范', name: '命名规范' },
    { key: '契约与包结构', name: '契约与包结构' },
  ];
  for (const { key, name } of requiredChapters) {
    const re = new RegExp(`#+.*${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`);
    if (!re.test(text)) {
      failures.push(`缺少章节：${name}`);
    }
  }
  // 标题层级容错：章标题可为 H1 或 H2（与 requiredChapters 的 `#+` 容忍一致），
  // 避免把 H1 章标题误判为缺失；层级规范由 prompt 侧显式契约约束，此处不硬编层级。
  if (!/#{1,2}\s*第 1 章|#{1,2}\s*一\b|^#{1,2}\s+[^\n]*项目技术栈|^#{1,2}\s+[^\n]*技术栈.*后端/m.test(text)) {
    failures.push('第 1 章「项目技术栈（后端）」标题缺失（须出现「第 1 章」或「项目技术栈」章标题）');
  }
  if (!/#{1,2}\s*第 9 章|#{1,2}\s*九\b|^#{1,2}\s*[^\n]*契约与包结构/m.test(text)) {
    failures.push('第 9 章「契约与包结构」标题缺失（须出现「第 9 章」或「契约与包结构」章标题）');
  }

  // 2. 第 9 章必须包含「领域→归并模块→modulePackage」表（表头须含 领域标识、归并模块、modulePackage）
  //    只认 markdown 表格行（以 `|` 开头）作表头判定，避免正文段落同时含「领域标识」+「modulePackage」
  //    关键词被误判为表头、提前 break 致「缺归并模块列」假阳。
  let sawDomainModuleTable = false;
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i].trim();
    if (l.startsWith('|') && /领域标识/.test(l) && /modulePackage/i.test(l)) {
      sawDomainModuleTable = true;
      const cells = l.split('|').map((c) => c.trim()).filter(Boolean);
      if (!/归并模块/.test(l)) {
        failures.push('第 9 章领域→模块表缺「归并模块」列');
      }
      const di = cells.findIndex((c) => /领域标识/.test(c));
      const pi = cells.findIndex((c) => /modulePackage/i.test(c));
      if (di < 0 || pi < 0 || pi < di) {
        failures.push('第 9 章领域→模块表列顺序非法（领域标识须在 modulePackage 之前）');
      }
      break;
    }
  }
  if (!sawDomainModuleTable) {
    failures.push('第 9 章缺失「领域→归并模块→modulePackage」表（表头须含 领域标识、归并模块、modulePackage）');
  }
  // §9 表行 modulePackage 格式/有效数据行计数已撤回（内容；归位者按 domain.json 填 §9.2 + 领域覆盖审计 + review 兜底）。

  // §9.2 领域标识↔domain.json 一致性已撤回（内容·跨文件语义；归位者按 domain.json 填 §9.2 + 领域覆盖审计 + review 兜底）。

  // 根包名校验已撤回（Java `com.` 假设；根包名由 tech-stack 继承、归位者写、build 编译门自校验）。

  // 4. §9 返回风格小节标题在即可（结构）；skeleton-conventions.json 须存在+可解析+结构门（见上方
  //    checkSkeletonConventionsStructure：顶层信封/10 角色在场/记录自洽——全部 schema 形状、单文件机械判据）。
  //    角色内容语义（真名是否在用/fqn 盘面存在）仍撤回——内容归归位者自检+review，
  //    fqn 与 moduleDir 的源码存在性下沉 build 编译门/启动测试 checker（确定性门）。
  if (!/返回风格/.test(text)) {
    failures.push('第 9 章缺失返回风格契约段（应有「返回风格」小节写明信封工厂方法）');
  }
  // 桶 C（scenario='free'）：无后端骨架 ⇒ 下列两条骨架派生判据整支摘除（显式分支，非「文件不存在就跳过」）。
  if (scenario !== 'free') {
    const planState = readFreshMicroPlanStateNear(filePath);
    if (planState.kind === 'invalid') {
      // 工程方案在场但自描述不符：不能静默按 legacy 解释（否则会把版本/形态问题伪装成「缺 conventions」）。
      failures.push(
        `工程方案自描述非法：${planState.reason}（${planState.planPath}）——设计完整性检查须修正；旧读取器不得当作 legacy 产物`,
      );
    } else {
      const skeletonConventionsPath = resolve(filePath, '..', '_meta', 'skeleton-conventions.json');
      let conventionsJson = null;
      try {
        conventionsJson = JSON.parse(readFileSync(skeletonConventionsPath, 'utf-8'));
      } catch {
        // fresh micro：实测 conventions 在 build 实现后生成（plan §5/§6.2 第 6 点）——设计期只做交付面
        // 结构检查时不得要求该文件；实现后若再次执行本门（文件在场），下面仍照结构门逐条判。
        // 其余场景：保留原 fail-loud 判据，逐字不变。
        if (planState.kind !== 'fresh-micro') {
          failures.push(`缺失或无法解析骨架约定发现产物：${skeletonConventionsPath}（设计阶段须先读骨架按角色判据产出此 json，§9.3/§9.4 引用其真名+FQN）`);
        }
      }
      if (conventionsJson && typeof conventionsJson === 'object' && !Array.isArray(conventionsJson)) {
        failures.push(...checkSkeletonConventionsStructure(conventionsJson));
      }
    }
  }

  // 包结构子包 / 命名规范字面词 / 业务映射表 校验已撤回（内容·Java 假设，§9/§8 标题已保留作结构门）。

  // 6. 集成 / 安全 / APM 三章须有真实内容，允许明确"原始需求未提及"
  if (!/^#{1,2}\s+[^\n]*集成/m.test(text)) {
    failures.push('第 5 章「集成」缺失（须出现含「集成」的章标题）');
  }
  if (!/^#{1,2}\s+[^\n]*安全/m.test(text)) {
    failures.push('第 6 章「安全考量」缺失（须出现含「安全」的章标题）');
  }
  if (!/^#{1,2}\s+[^\n]*(APM|可运维|可观测)/m.test(text)) {
    failures.push('第 7 章「APM/可运维性」缺失（须出现含「APM」/「可运维」/「可观测」的章标题）');
  }

  // 7. 禁止占位 / PENDING / 绝对路径
  // 注：不再把字面「占位符/待补充」当违例——「Base Path 用占位符」是合法设计术语；
  // 只拦截结构性 TODO 标记（[***] / <!PENDING> / TBD / TODO / [xxx] / [关联段落]）。
  // 域 id 是正文必备引用（可能含 todo/tbd 词根），扫描前按 domain.json 遮罩（见 helper 注释）。
  const { ids: placeholderDomainIds } = readDomainIds(resolve(filePath, '..', '..', 'domain.json'));
  const placeholders =
    maskDomainIdsForPlaceholderScan(text, placeholderDomainIds).match(
      /\[\*\*\*\]|<!PENDING>|\bTBD\b|\bTODO\b|\[xxx\]|\[关联段落\]/gi,
    ) || [];
  if (placeholders.length > 0) {
    failures.push(`文档包含占位/待补充标记：${[...new Set(placeholders)].slice(0, 5).join(', ')}`);
  }
  // 真实绝对路径 = 路径段首字母为字母（/Users/jack、/home/jack、/root/.x），排除路由 glob（/home/**、/root/**）。
  if (/\/Users\/[A-Za-z]|\/home\/[A-Za-z]|\/root\/[A-Za-z.]/.test(text)) {
    failures.push('文档包含真实绝对路径（应使用占位符或相对引用）');
  }

  // 8. 禁止写运行时机制章节（模块容错/service-manager/browser-server/共享进程 属 shared prompt，后续实现）
  const forbiddenHeaders = [
    /^#+\s*.*模块级容错.*/im,
    /^#+\s*.*service.?manager.*/im,
    /^#+\s*.*BrowserServer.*/im,
    /^#+\s*.*共享进程生命周期.*/im,
    /^#+\s*.*E2E Runtime.*/im,
    /^#+\s*.*模块容错注册.*/im,
  ];
  for (const p of forbiddenHeaders) {
    const m = text.match(p);
    if (m) failures.push(`禁止写入运行时机制章节：${m[0].trim()}`);
  }

  // 9. 空标题 / 相邻标题
  if (/\n## [^\n]*\n## /g.test(text)) {
    failures.push('存在相邻章节标题（标题间无内容）');
  }
  if (/^## [^\n]*$(?=\n## )/m.test(text)) {
    failures.push('存在空标题（标题后无内容）');
  }

  return failures.length === 0 ? { ok: true, failures: [] } : { ok: false, failures };
}

// ── 合法枚举（单真理源；expert-self-check 前置用）─────────────────────────────────
// domainCoverage[].status ∈ designed|clarified|defaulted|n-a（clarified 合法：领域点已澄清但依赖邻居建模）
// （原 seamRoles[].claim / role 的 LEGAL_OWNER_CLAIM / LEGAL_ROLE 随 seam 退役一并删除——
//  接缝角色段已不存在，归属改由 decision 级的 domain↔声明 owner 校验承接，见 checkDecisionAccounting。）
const LEGAL_DOMAIN_STATUS = new Set(['designed', 'clarified', 'defaulted', 'n-a']);
// 清单外发现提案（coverage `proposals`）类别闭集——**引擎默认三值**（引擎不背业务语义，只背「类别枚举合法」）。
// 业务侧可在声明物加 `proposalKinds` 覆盖；有效集由 TS 侧声明算出、经 `--proposal-kinds` 传入本脚本
// （**禁在本文件二次硬编码业务类别**——同 E8 的单一真理源铁律）。
const DEFAULT_PROPOSAL_KINDS = ['new-domain', 'boundary-gap', 'roster-drift'];

// ── clarify-idempotence：澄清幂等门 ────────────────────────────────────────────
// 读决策台账（+可选上一轮 prev）断言：结构完整 / 字段合法 / 全局决策归位 / 登录决策配对。
// `reqStamp` 已退出决策契约（plan 2026-10-25/requirement-snapshot-root-fix D1/W3）：七字段形状，
// 字段不再必填也不再比较；旧台账多带的 `reqStamp` 按未知字段忽略。
function checkClarifyIdempotence(ledgerPath, prevPath) {
  const failures = [];
  let ledger;
  try {
    ledger = JSON.parse(readFileSync(ledgerPath, 'utf-8'));
  } catch (e) {
    return { ok: false, failures: [`无法读取/解析台账: ${ledgerPath}（${e.message}）`] };
  }

  // 顶层 `requirementSnapshot` 是历史字段（快照降级为提示后 ensure 不再初始化台账）：
  // 存在则要求是字符串，缺席合法——不再作为凭据判据。
  if (ledger.requirementSnapshot !== undefined && typeof ledger.requirementSnapshot !== 'string') {
    failures.push('台账 requirementSnapshot 若存在必须为字符串（历史字段，不再要求非空）');
  }
  if (!Array.isArray(ledger.decisions)) {
    failures.push('台账缺少或非数组字段：decisions');
    return { ok: failures.length === 0, failures };
  }

  const validScope = new Set(['domain', 'global']);
  // source 值枚举已撤回：source 是决策来源的语义分类（user/default/derived_from_requirement/
  // user_confirmed…），由专家按口径自由标注——枚举过窄必误杀（实证 20/20 decision 全被判红），
  // 非结构；非空校验（见上 8 字段循环）保留。scope∈{domain,global} 是结构性双值（横切归位路由依据），保留。
  for (let i = 0; i < ledger.decisions.length; i++) {
    const d = ledger.decisions[i];
    if (!d || typeof d !== 'object') { failures.push(`decisions[${i}] 应为对象`); continue; }
    for (const k of ['id', 'domain', 'scope', 'question', 'answer', 'source', 'decisionRef']) {
      const missing = d[k] === undefined || d[k] === null || d[k] === '';
      if (missing) failures.push(`decisions[${i}] 缺少字段：${k}`);
    }
    if (d.scope !== undefined && !validScope.has(d.scope)) failures.push(`decisions[${i}] scope 非法：${d.scope}（应为 domain|global）`);
    // 陈旧决策判定（reqStamp 与当前/权威快照相等）已随凭据链撤回：快照只给 agent 看，不做判据。
    // 全局归位一致性（scope=global decisionRef 含「全局技术约束」）已撤回（内容·查字符串含特定中文短语=判归位内容；归位者自检 prompt 已要求 scope:global 归位横切专区 + review 兜底）。
  }

  // FREEZE 逐字断言已撤回（语义·冗余；陈旧决策判定已随凭据链一并撤回，逐字断言对 delta 轮必误杀）。
  // --prev 仍接（备用，预留后续结构校验），当前不消费。

  // ── 登录决策配对校验（plan 2026-09-04/clarify-conditional-questions-sequential-rounds）──────
  // 条件依赖的伴生闭环，只覆盖字面钉死的两个 id（④认证机制/账号多登决策 id 未钉死，其孤儿态由
  // 分轮/自主定案规则 + prompt 禁落条款兜底，不进机械门——按问题文本猜 id 属语义判断）：
  //   login-required=不需要登录 → login-scheme 禁止存在（孤儿=同轮冲突产物，分轮/定案后不该发生）；
  //   login-required=需要登录   → login-scheme 必落（缺失 → build 回退账密现行为并告警，设计期 fail loud）。
  // 台账无 login-required（登录决策未落）不在本门内判——「登录决策全部落台账」条款 + coverage decisionIds 校验兜底。
  // ⚠️ 2026-10-30 起 micro 链登录决策改**自主定案**（无冲突禁弹、冲突才问一次），不再有「四支分轮」；
  // monolith / incremental 仍走基线四支弹问门。判据（本条配对校验）不变，仅同步红文案口径。
  const loginRequiredDecision = ledger.decisions.find((d) => d && d.id === 'login-required');
  if (loginRequiredDecision && typeof loginRequiredDecision.answer === 'string') {
    const schemeDecision = ledger.decisions.find((d) => d && d.id === 'login-scheme');
    if (loginRequiredDecision.answer.startsWith('不需要')) {
      if (schemeDecision) {
        failures.push(
          `登录决策配对冲突：login-required="${loginRequiredDecision.answer}" 但台账存在 login-scheme（answer="${schemeDecision.answer}"）。` +
            `期望: 不需要登录时不落 login-scheme（登录方案是「是否需要登录」的条件依赖决策——micro 链自主定案/冲突才问时按定案结果只落需要的条目；monolith 链四支弹问门已分轮，第一轮「是否需要登录」答案回传后才决定是否发第二轮；同屏两问的矛盾产物不合法）。` +
            `修法: 删除台账中 id=login-scheme 的 decision；如确需登录则修正 login-required 答案并重新澄清。`,
        );
      }
    } else if (loginRequiredDecision.answer.startsWith('需要')) {
      if (!schemeDecision) {
        failures.push(
          `登录决策配对缺失：login-required="${loginRequiredDecision.answer}" 但台账无 login-scheme 伴生决策。` +
            `期望: 需要登录时 login-scheme 必落（answer 字面值：账号密码|SSO 单点登录|邮箱/手机号验证码；缺失 → build 期回退账密现行为并告警）。` +
            `修法: micro 链按登录自主定案补落 login-scheme（无冲突直接定案；仅来源冲突时向用户澄清一次）；monolith / incremental 链按四支弹问门第二轮澄清后 APPEND login-scheme。`,
        );
      }
    }
    // answer 非「需要/不需要」字面前缀不在此判——build 侧按 startsWith 归类为 absent 回退现行为，与台账口径一致。
  }

  return { ok: failures.length === 0, failures };
}

// ── 决策交代门（不变量 E8；plan 2026-09-24/clarify-standard-process-engine D5）─────────────
// 断言：**每条声明 decision id 都有交代**——台账里有该 id 的 entry，**或**其 owner 的 coverage
// 在 `decisionAccounting` 里给了 `{id, status:'skipped', reason}`。
// 为什么要它：声明化后「专家压根没提这条决策」与「专家提了并落了台账」在台账上长得一样（都只是
// 「没有这条 id」），没有本门就只能靠人读材料发现漏项；有了它，「静默漏一条决策」变确定性失败。
//
// 数据源 = 声明导出的 JSON（`shared/clarify-declarations.json`，由 TS 侧
// serializeClarifyDeclarations 生成、clarify-declarations-export-sync.test.ts 锁同步）。
// **禁在本文件二次硬编码 id 清单**——那样声明改了本门不改 = 门假绿（单一真理源铁律）。
//
// 证据不可判 = 红（已知坑：JSON.parse catch 禁 null 兜底）：声明 JSON 缺失/不可解析/版本不认，
// 一律 fail，绝不当「无声明 = 无断言」静默放行。
const CLARIFY_DECLARATIONS_RELATIVE = ['shared', 'clarify-declarations.json'];
const SUPPORTED_DECLARATIONS_EXPORT_VERSION = 1;

function readClarifyDeclarations(declarationsPath) {
  const path_ = declarationsPath || resolve(dirname(fileURLToPath(import.meta.url)), ...CLARIFY_DECLARATIONS_RELATIVE);
  let raw;
  try {
    raw = JSON.parse(readFileSync(path_, 'utf-8'));
  } catch (e) {
    throw new Error(`声明导出 JSON 不可读/不可解析：${path_}（${e.message}）——证据不可判禁放行`);
  }
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.experts)) {
    throw new Error(`声明导出 JSON 形状非法（缺 experts 数组）：${path_}`);
  }
  if (raw.version !== SUPPORTED_DECLARATIONS_EXPORT_VERSION) {
    throw new Error(
      `声明导出 JSON 版本不认：${raw.version}（本门支持 ${SUPPORTED_DECLARATIONS_EXPORT_VERSION}）——${path_}；` +
        `版本升级须同步本门判据，禁按旧形状猜读`,
    );
  }
  return { path: path_, experts: raw.experts };
}

const LEGAL_ACCOUNTING_STATUS = new Set(['decided', 'skipped']);

function checkDecisionAccounting({ coverageDir, ledger, declarationsPath }) {
  const failures = [];
  let declared;
  try {
    declared = readClarifyDeclarations(declarationsPath);
  } catch (e) {
    return { failures: [`整体门决策交代（E8）无法判：${e.message}`] };
  }

  // 台账侧：已落的 decision id → 其 domain（归属校验用；台账不可读在上游已记红，此处按空集处理会使
  // 全部声明判缺交代，故显式再记一条，避免把「读不到台账」误报成「十条决策都没交代」）。
  const decided = new Map(); // decision id -> domain
  if (ledger && Array.isArray(ledger.decisions)) {
    for (const d of ledger.decisions) {
      if (d && typeof d === 'object' && typeof d.id === 'string') {
        decided.set(d.id, typeof d.domain === 'string' ? d.domain : null);
      }
    }
  } else {
    failures.push('整体门决策交代（E8）：台账不可读/decisions 非数组 → 证据不可判（禁当无证据放行）');
  }

  // coverage 侧：各专家交代表。按 coverage 文件聚合（碎片已由归位者合并，此处读的是最终 coverage）。
  const accountingById = new Map(); // decision id -> { expert, status, reason }
  let entries = [];
  try {
    entries = readdirSync(coverageDir).filter((f) => f.endsWith('.json'));
  } catch (e) {
    failures.push(`整体门决策交代（E8）无法读取 coverage 目录：${coverageDir}（${e.message}）`);
    return { failures };
  }
  for (const f of entries) {
    let cov;
    try {
      cov = JSON.parse(readFileSync(resolve(coverageDir, f), 'utf-8'));
    } catch {
      continue; // 解析失败已在上游文件集段记红，此处不重复
    }
    if (!cov || typeof cov !== 'object') continue;
    const expert = cov.expert || f.replace(/\.json$/, '');
    if (cov.decisionAccounting === undefined) continue; // 缺字段 = 未交代，由下方逐 id 断言兜底报红
    if (!Array.isArray(cov.decisionAccounting)) {
      failures.push(`expert=${expert} coverage.decisionAccounting 非数组（应为决策交代条目数组，无声明条目也须写 []）`);
      continue;
    }
    for (const item of cov.decisionAccounting) {
      if (!item || typeof item !== 'object' || typeof item.id !== 'string' || !item.id) {
        failures.push(`expert=${expert} coverage.decisionAccounting 含无 id 条目：${JSON.stringify(item)}`);
        continue;
      }
      if (!LEGAL_ACCOUNTING_STATUS.has(item.status)) {
        failures.push(
          `expert=${expert} coverage.decisionAccounting['${item.id}'].status 非法：${JSON.stringify(item.status)}（须 decided|skipped）`,
        );
        continue;
      }
      if (item.status === 'skipped' && !(typeof item.reason === 'string' && item.reason.trim())) {
        failures.push(
          `expert=${expert} coverage.decisionAccounting['${item.id}'] 标了 skipped 但没给 reason——` +
            `skip 必须说明为何本域本轮不产出该决策（无理由的 skip = 静默漏项换了个写法）`,
        );
        continue;
      }
      const owner = accountingById.get(item.id);
      if (owner) {
        failures.push(
          `决策交代撞车：'${item.id}' 由 expert=${owner.expert} 与 expert=${expert} 双份交代（每 id 恰一 owner）`,
        );
        continue;
      }
      accountingById.set(item.id, { expert, status: item.status, reason: item.reason });
    }
  }

  // 逐条断言：台账有 entry 或 coverage 有交代，二者皆无 = 红。消息给全量缺项（一次修完，不挤牙膏）。
  //
  // 归属校验（plan 2026-09-24 拍板合并 9c + 提案 plan D4③）——**seam 排他面的承接**：
  // 原 seam 门（SEAM_REGISTRY + checkSeamReconcile）判的是"你是不是该 seam 的合法 owner"（错归属/冒认
  // owner = red，见 git 史 mjs:1237/1244）；seam 退役后该面在此以 **id 粒度**复现：声明的边界 decision
  // 若落进台账，其 `domain` 必须 === 声明的 owner —— 否则 = 别的专家代笔/冒认该决策，红。
  //
  // ⚠️ 口径边界（2026-09-24 用户拍板 A）：这里**不是**「禁自造决策域」的强形态。真·禁自造（台账出现
  // 完全未声明的 id → 红）要求 decision id 是**可枚举闭集**，而现状 id 是按需求现造的（台账 schema
  // 对 id 无白名单，见 checkClarifyIdempotence 的必填字段集）；仓内已有同型先例与结论——`source` 枚举
  // 因「枚举过窄必误杀（实证 20/20 decision 全被判红）」被撤回。故强形态**明示推迟**到「决策域判定表」
  // plan（设计文档 §十二.1 已列其为独立后续 plan），今日由 prompt 层职责（花名册硬边界条款）+ 提案通道
  // 出口承担，**明写不进机械门**——不假装可判。
  const missing = [];
  for (const exp of declared.experts) {
    for (const d of exp.decisions || []) {
      if (decided.has(d.id)) {
        const ledgerDomain = decided.get(d.id);
        if (ledgerDomain !== null && ledgerDomain !== exp.id) {
          failures.push(
            `决策归属不符：'${d.id}' 声明 owner=${exp.id}，但台账条目的 domain=${ledgerDomain}` +
              `（边界 decision 归其声明 owner 独有——代笔/冒认即红；若确认该决策应换 owner，改声明物里的 owner，不要改台账）`,
          );
        }
        continue;
      }
      // 走到这里 ⇒ 台账**没有**该 id 的 entry（上面的 `decided.has` 分支已 continue）。故本分支只认
      // `skipped`+理由这一条出口：`decided` 的语义 = 「该决策已落台账」，台账无条目还自报 decided
      // = 拿一句自报把漏项抹平——正是本门存在的理由（D5：台账 entry **或** skip+理由，二者皆无 = 红）。
      const acct = accountingById.get(d.id);
      if (acct) {
        if (acct.expert !== exp.id) {
          failures.push(
            `决策交代归属不符：'${d.id}' 声明 owner=${exp.id}，实际由 expert=${acct.expert} 交代（owner 错位）`,
          );
        } else if (acct.status === 'decided') {
          failures.push(
            `决策交代无效：'${d.id}'（owner=${exp.id}）在 coverage.decisionAccounting 标了 status=decided，` +
              `但台账 \`backend/_meta/clarify-decisions.json\` 里没有该 id 的 entry。` +
              `decided 的判据 = 该决策**已落台账**（decisionRef 指得出去），不是一句话自报。修法二选一：` +
              `① 真做了 → 按本专家 ledgerMode 把该决策落进台账（碎片或直接写），本条随之自然绿；` +
              `② 本轮确实不产出 → 改写 {"id":"${d.id}","status":"skipped","reason":"<为何本域本轮不产出该决策>"}`,
          );
        }
        continue;
      }
      missing.push(`${exp.id}:${d.id}`);
    }
  }
  if (missing.length) {
    failures.push(
      `决策未交代（${missing.length} 条）：${missing.join('、')}\n` +
        `     期望: 每条声明 decision 要么落台账 \`backend/_meta/clarify-decisions.json\` 的 decisions，` +
        `要么在其 owner 的 \`coverage/<id>.json\` 的 decisionAccounting 里给 {"id":"<id>","status":"skipped","reason":"<为何不产出>"}` +
        `（无声明条目的专家也要写 decisionAccounting: []）\n` +
        `     通过示例（本轮不产出该决策时）: {"decisionAccounting":[{"id":"${missing[0].split(':')[1]}","status":"skipped","reason":"<为何本域本轮不产出该决策>"}]}\n` +
        `     ⚠️ 别改写成 status:"decided" 糊过去——decided 的判据是「该 id 已在台账里」，` +
        `台账无条目时写 decided 会另判一条「决策交代无效」`,
    );
  }
  return { failures };
}

// ── backend-design-integrity：后端技术设计整体门 ─────────────────────────────────
// 聚合台账幂等（checkClarifyIdempotence）+ 跨瓣一致性（文件集 / 归位↔writesTo / 台账无重复 id）
// + 决策交代门（checkDecisionAccounting，不变量 E8 含归属校验）。dispatch-fidelity 已废（派发由 wave
// 串行 children 结构性保证）；seam-reconcile 已退役（2026-09-24 引擎 plan 刀3——接缝角色段与
// SEAM_REGISTRY 一并删除，横向归属改由 decision 级 ownership 承接，见 checkDecisionAccounting）。
function checkBackendDesignIntegrity({ coverageDir, ledgerPath, prevPath, readmePath, rosterIds, declarationsPath }) {
  const failures = [];
  const rosterSet = new Set(rosterIds);

  // 1) 台账幂等（复用）——延后到 coverage 解析后，需聚合 mode 判 deltaRound（见下）

  let ledger = null;
  try { ledger = JSON.parse(readFileSync(ledgerPath, 'utf-8')); }
  catch (e) { failures.push(`整体门无法读取台账: ${ledgerPath}（${e.message}）`); }
  let readme = '';
  try { readme = readFileSync(readmePath, 'utf-8'); }
  catch (e) { failures.push(`整体门无法读取 README: ${readmePath}（${e.message}）`); }

  // 3) 文件集：roster 每个 id 有 coverage/<id>.json + clarify/<id>.md；coverage expert ∈ roster；无多余
  const clarifyDir = resolve(coverageDir, '..', '..', 'clarify'); // _meta/coverage → backend/clarify
  let entries = [];
  try { entries = readdirSync(coverageDir).filter((f) => f.endsWith('.json')); }
  catch (e) { failures.push(`整体门无法读取 coverage 目录: ${coverageDir}（${e.message}）`); }
  const coverages = [];
  for (const f of entries) {
    let data;
    try { data = JSON.parse(readFileSync(resolve(coverageDir, f), 'utf-8')); }
    catch (e) { failures.push(`${f} JSON 解析失败：${e.message}`); continue; }
    coverages.push(data);
    if (data.expert && !rosterSet.has(data.expert)) {
      failures.push(`coverage/${f} expert=${data.expert} 不在 roster ${[...rosterSet].join('|')}（多余/未知专家）`);
    }
  }
  // 2) 台账幂等（复用）：schema 形状 + 字段完整性（七字段，无 reqStamp）。
  failures.push(...checkClarifyIdempotence(ledgerPath, prevPath).failures);

  for (const id of rosterIds) {
    if (!entries.includes(`${id}.json`)) failures.push(`文件集缺 coverage/${id}.json`);
    if (!existsSync(resolve(clarifyDir, `${id}.md`))) failures.push(`文件集缺 clarify/${id}.md`);
  }

  // 4) 归位一致（结构）：每份 coverage.writesTo 非占位/合法形态（以 § 或 README# 开头）。
  //    逐字锚点标题子串断言已撤回——与 expert-self-check 段号软匹配（见 checkExpertSelfCheck）自相矛盾且脆：
  //    专家 writesTo 带冗余「（§X.X …）」后缀时 readme.includes 残留后缀必假阳
  //    （实证 2026-08-28 zhy828 阶段二 10 轮死循环；同文件段号软匹配注释明说「硬匹配会因两边格式不一致死循环」）。
  //    归位一致性改由 writesTo 非占位形态 + expert-self-check 段号==期望段号 + README 文件存在 +
  //    归位者唯 writer + architecture 章级门 + review 兜底，对齐本文件「内容·语义→撤回结构」既定方向。
  for (const cov of coverages) {
    if (!cov || !cov.expert) continue;
    const w = cov.writesTo;
    if (!w || typeof w !== 'string' || (!w.startsWith('§') && !w.startsWith('README#'))) {
      failures.push(`expert=${cov.expert} coverage.writesTo 非法/缺：${w}`);
    }
  }

  // 5) 台账无重复 id（per-expert 重试幂等 APPEND 兜底；per-expert 自检已查本专家，此处查全量）
  if (ledger && Array.isArray(ledger.decisions)) {
    const seen = new Set();
    for (let i = 0; i < ledger.decisions.length; i++) {
      const d = ledger.decisions[i];
      if (!d || typeof d !== 'object' || !d.id) continue;
      if (seen.has(d.id)) failures.push(`台账 decisions id=${d.id} 重复（index ${i}，per-expert 重试未幂等 APPEND）`);
      seen.add(d.id);
    }
  }

  // 6) 决策交代（E8）：每条声明 decision id 有台账 entry 或 coverage skip+理由；证据不可判=红
  failures.push(...checkDecisionAccounting({ coverageDir, ledger, declarationsPath }).failures);

  return { ok: failures.length === 0, failures };
}

// ── expert-self-check：per-expert 自检门 ──────────────────────────────────────
// 单专家 coverage schema + writesTo（闭包期望值）+ decisionIds 在台账存在且无重复。
// `reqStamp` 已退出决策契约（plan 2026-10-25/requirement-snapshot-root-fix W3）：本门只看形状/归属/存在性。
// 挂在专家函数型 child 返回的 phase checker 上 → processPhase L518 runWithChecker → 单专家 fail 只重跑本 phase。
//
// 碎片模式（可选第 5 参 fragmentPath）：并发四专家（security/integration/middleware/observability）把决策
// 落盘到独占碎片 backend/_meta/clarify-fragments/<expertId>.json（尚未由确定性汇编 phase 合并进台账），
// 此时传 fragmentPath 启用碎片校验：expert 归属 + decisions 数组 + decisionIds 须命中碎片
// + 碎片内 id 去重，并跳过台账「决策印章」断言（碎片未汇编，台账里没有是正常的）。
// FREEZE 轮专家不产碎片（采用台账 prev decisions）→ 传了 fragmentPath 但文件不存在 → 回退现有台账断言。
// authz 仍直写台账 → 不传 fragmentPath，行为与碎片模式引入前逐字一致。
//
// middleware 组化判据（可选第 6 参 clarifyFilePath，plan 2026-09-10/middleware-expert-contract-form-group-node）：
// middleware 专家改为组节点（①选型 → ②基座表单闭包 → ③收尾落全），澄清三件套在组内收尾步之后才齐——
// 传 clarifyFilePath 时断言澄清决策材料存在且含「连接配置」段锚点（防半文档过闸：选型落了、连接值没落）。
// 锚点常量与 TS 侧 middleware-contract.tasks.ts 的 MIDDLEWARE_CONNECTION_SECTION_ANCHOR 同串——双副本
// 一致性由 backend-design-middleware-group.test.ts 钉死（修改必须双改）。
//
// **scenario 分叉（plan 2026-10-29/free-frontend-design-dispatch-without-ends §C.1.2b）**：
// 「连接配置」段只在非 free 存在（build 消费 middlewares.json）；free 只记录中间件类型、不收集连接值，
// 其收尾步不写该段 ⇒ 锚点断言改为 `scenario !== 'free'` 才要求。scenario 取同文件既有的
// `readScenarioArg(process.argv)`（`--scenario` → `APP_TECH_STACK_INFO` → 缺省 fresh），**不新增 CLI 参数**
// （TS 调用约定零变更；缺省调用逐字不变）。这是逻辑分支，不是文案三元（不违反 D5 byte-exact 纪律）。
const MIDDLEWARE_CLARIFY_SECTION_ANCHOR = '## 连接配置';
function checkExpertSelfCheck({ coverageFile, expertId, ledgerPath, expectedWritesTo, fragmentPath, clarifyFilePath, proposalKinds, scenario = 'fresh' }) {
  const failures = [];
  // 有效提案类别闭集：声明侧覆盖优先，缺省引擎三值。三条语义各不相同，**故一律不用 `||` 合并**：
  //   ① 未传（undefined）= 取引擎默认三值；
  //   ② 传空串 = **声明侧显式零类别**（`--proposal-kinds ""` → `['']` → 闭集为空 → 任何 kind 都非法）
  //      ——这是声明物 `proposalKinds: []` 的到达形态，即「本线不受理提案」的合法关闸口子；
  //   ③ 传非空串 = 声明侧覆盖闭集。
  // ⚠️ 别把 ② 顺手归并进 ①（`pkRaw === ''` 当未传）：那会静默拆掉声明侧唯一的关闸口子。
  // 回归锁：tests/scripts/check-backend-design-proposal-channel.test.mjs「传空串 ≠ 未传」。
  const legalProposalKinds = new Set(
    Array.isArray(proposalKinds) ? proposalKinds : DEFAULT_PROPOSAL_KINDS,
  );
  let cov;
  try { cov = JSON.parse(readFileSync(coverageFile, 'utf-8')); }
  catch (e) {
    return { ok: false, failures: [`无法读取/解析 coverage: ${coverageFile}（${e.message}）`] };
  }

  if (cov.expert !== expertId) failures.push(`coverage.expert=${cov.expert} != 期望 ${expertId}`);
  if (!cov.mode || !['FREEZE', 'RECLARIFY'].includes(cov.mode)) {
    failures.push(`coverage.mode 非法/缺：${cov.mode}（应为 FREEZE|RECLARIFY）`);
  }
  // domainCoverage 形状判据两态**互斥**（与下方 proposals evidence 三态同纪律）：类型错不得伪装成「为空」，
  // 否则 agent 会把「写成对象」理解成「内容没补」、反复补内容而不改形状（plan 2026-11-03 实测两轮空转）。
  if (!Array.isArray(cov.domainCoverage)) {
    const dcType = cov.domainCoverage === null ? 'null' : typeof cov.domainCoverage;
    failures.push(
      `coverage.domainCoverage 不是数组（应为 [{ "point": "...", "status": "designed|clarified|defaulted|n-a", "note": "..." }]，当前类型 ${dcType}）`,
    );
  } else if (cov.domainCoverage.length === 0) {
    failures.push(
      `coverage.domainCoverage 为空（至少要一条 { "point", "status" }；本专家若确实无领域点，也要写覆盖点本身，例如根包前缀）`,
    );
  } else {
    // status 值合法性前置（单 coverage 内可判，不必等 merge——与 claim 同构）：
    // status ∈ designed|clarified|defaulted|n-a（clarified 合法）。专家写非法值（如把 mode 的 RECLARIFY
    // 透传进 status）当场在自己 phase 红、hint 注入合法集、重跑自己改——merge 前闭环。
    for (const dc of cov.domainCoverage) {
      if (!dc || typeof dc !== 'object') { failures.push(`${expertId} domainCoverage 含非对象项`); continue; }
      if (!dc.point || !dc.status) { failures.push(`${expertId} domainCoverage 项缺 point/status`); continue; }
      if (!LEGAL_DOMAIN_STATUS.has(dc.status)) {
        failures.push(`${expertId} domainCoverage point="${dc.point}" status 非法：${dc.status}（应为 ${[...LEGAL_DOMAIN_STATUS].join('|')}；RECLARIFY 是 mode 不是 status，勿透传）`);
      }
    }
  }
  // 清单外发现提案（plan 2026-09-24/clarify-proposal-channel-boundary-growth D2/D4①②）。
  // 原 `referrals`（表外接缝上报）在此**原地替换**为 `proposals`——seam 退役后"清单外问题"仍需一个
  // 合规出口；referral 的门早已撤回（旧注释 1173-1176/1275-1276），故此处不是删门而是**建门**。
  // ① 形状：数组 + 每条 kind/title 齐 + evidence **非空字符串**（evidence 是"禁全量重审"的机械抓手）；
  //    evidence 判据三态：缺字段/null ⇒ 缺 evidence；字符串但 trim 空 ⇒ 为空；
  //    非字符串（数组/对象/数字）⇒ **类型错**（「必须是字符串」），不得报成「为空」——把类型错说成
  //    「为空」会让 agent 以为内容没写、去查 checker 源码（plan 2026-10-29/feedback-repair-precision D1）。
  // ② 值域：kind ∈ 闭集；status 只许 pending（**专家只提案不裁决**——对齐 crystallize 铁律 2）
  // ③ 反洪水：单专家单轮 ≤3（对齐 crystallize 净增预算）
  // ④ 语义「该不该采纳」**不进机械门**，归人工裁决（明示口径，不假装可判）。
  if (!Array.isArray(cov.proposals)) {
    failures.push(`coverage.proposals 缺或非数组（清单外发现上报；无发现也须写空数组 []）`);
  } else {
    if (cov.proposals.length > 3) {
      failures.push(
        `${expertId} coverage.proposals 条数 ${cov.proposals.length} 超上限 3（单轮净增预算）——` +
          `请只上报本轮需求实际暴露的最关键几条，其余留到下轮`,
      );
    }
    for (const p of cov.proposals) {
      if (!p || typeof p !== 'object') { failures.push(`${expertId} proposals 含非对象项`); continue; }
      if (!p.kind || !p.title) {
        failures.push(`${expertId} proposals 项缺 kind/title/evidence（evidence 必非空：写清本轮什么需求线索暴露了它）`);
        continue;
      }
      // evidence 三态（缺/null / 空串 / 非字符串）：类型错不得伪装成「为空」。
      if (p.evidence === undefined || p.evidence === null) {
        failures.push(
          `${expertId} proposals['${p.title}'].evidence 缺——evidence 必填非空字符串（多条线索用「；」连接，禁数组），` +
            `写清本轮什么需求线索暴露了它`,
        );
        continue;
      }
      if (typeof p.evidence !== 'string') {
        const evidenceType = Array.isArray(p.evidence) ? 'array' : typeof p.evidence;
        failures.push(
          `${expertId} proposals['${p.title}'].evidence 必须是字符串，当前是 ${evidenceType}；` +
            `多条线索用「；」连接成一条字符串（如 "specs/checklist-03.md：需求要求两地三中心；tech-stack.json#/backend：Node 栈"），` +
            `禁数组 / 对象 / 数字`,
        );
        continue;
      }
      if (!p.evidence.trim()) {
        failures.push(`${expertId} proposals['${p.title}'].evidence 为空——无证据的提案 = 凭空发明决策域，拒收`);
        continue;
      }
      if (!legalProposalKinds.has(p.kind)) {
        failures.push(
          `${expertId} proposals['${p.title}'].kind 非法：${p.kind}（应为 ${[...legalProposalKinds].join('|')}）`,
        );
      }
      if (p.status !== undefined && p.status !== 'pending') {
        failures.push(
          `${expertId} proposals['${p.title}'].status=${p.status}——**专家只提案不裁决**，status 只许 pending（缺省即 pending）；` +
            `采纳/驳回由人裁决，不是你写`,
        );
      }
    }
  }
  // writesTo 段号软匹配（格式无关：roster body 用 README#<n>.<标题>、TS roster 用 §<n> <标题>，
  // 提取段号比较即可；硬匹配会因两边格式不一致死循环）。缺 writesTo 或非上述格式 → fail。
  const secNumOf = (s) => { const m = String(s || '').match(/^(?:§|README#)\s*(\d+)/); return m ? m[1] : null; };
  const expectedSec = secNumOf(expectedWritesTo);
  const actualSec = secNumOf(cov.writesTo);
  if (!actualSec) {
    failures.push(`coverage.writesTo 非法/缺段号：${cov.writesTo}（应为 §<编号> <标题> 或 README#<编号>.<标题>）`);
  } else if (expectedSec && actualSec !== expectedSec) {
    failures.push(`coverage.writesTo="${cov.writesTo}" 段号 ${actualSec} != 期望段号 ${expectedSec}（${expectedWritesTo}）`);
  }

  let ledger;
  try { ledger = JSON.parse(readFileSync(ledgerPath, 'utf-8')); }
  catch (e) {
    failures.push(`无法读取/解析台账: ${ledgerPath}（${e.message}）`);
    return { ok: failures.length === 0, failures };
  }

  // 决策印章：coverage.decisionIds 列出的决策须在台账/碎片存在 + 无重复 id（防与产物脱节的孤儿 decisionIds）。
  // 需求戳已退出契约（plan 2026-10-25/requirement-snapshot-root-fix W3），碎片/台账都不再要求该字段。
  // 碎片模式：传了 fragmentPath 且文件存在 → 改校验碎片（expert 归属/decisions 数组/id 命中碎片/碎片内去重），
  // 并跳过台账决策印章断言——碎片未汇编，台账里没有是正常的。文件不存在（FREEZE 轮回退）或未传（authz）→ 走台账断言。
  let fragmentInUse = typeof fragmentPath === 'string' && fragmentPath.trim() !== '' && existsSync(fragmentPath);
  let fragment = null;
  if (fragmentInUse) {
    try { fragment = JSON.parse(readFileSync(fragmentPath, 'utf-8')); }
    catch (e) {
      failures.push(`${expertId} 无法读取/解析碎片: ${fragmentPath}（${e.message}）；请整体覆盖重写碎片文件（合法 JSON）`);
      fragmentInUse = false;
    }
  }
  if (fragmentInUse) {
    if (fragment.expert !== expertId) {
      failures.push(`${expertId} 碎片 expert=${fragment.expert} != 期望 ${expertId}（碎片文件须独占归属：backend/_meta/clarify-fragments/${expertId}.json 内 expert 字段写本专家 id，勿写他人碎片/勿共用文件）`);
    }
    if (!Array.isArray(fragment.decisions)) {
      failures.push(`${expertId} 碎片 decisions 缺或非数组（${fragmentPath}；应为 {expert,mode,decisions:[{id,domain,scope,question,answer,source,decisionRef}]}）`);
    } else {
      const fragById = {};
      const fragDup = {};
      for (const d of fragment.decisions) {
        if (d && d.id) {
          if (fragById[d.id]) fragDup[d.id] = true;
          fragById[d.id] = d;
        }
      }
      // 台账中该专家 decisionIds 的重复检查 → 平移到碎片内重复（碎片是单写者独占文件，重复=重试未去重整体覆盖）
      if (Array.isArray(cov.decisionIds)) {
        for (const did of cov.decisionIds) {
          const fd = fragById[did];
          if (!fd) {
            failures.push(`${expertId} coverage.decisionIds 含 ${did} 但碎片中不存在（未落盘碎片）`);
          }
        }
      }
      for (const id of Object.keys(fragDup)) {
        failures.push(`碎片中 ${id} 出现多次（须整文件覆盖重写去重，勿追加重复决策）`);
      }
    }
  } else if (Array.isArray(cov.decisionIds)) {
    const ledgerById = {};
    if (Array.isArray(ledger.decisions)) {
      for (const d of ledger.decisions) { if (d && d.id) ledgerById[d.id] = d; }
    }
    for (const did of cov.decisionIds) {
      if (!ledgerById[did]) {
        failures.push(`${expertId} coverage.decisionIds 含 ${did} 但台账无此 id（未 APPEND）`);
      }
    }
    // 台账中该专家 decisionIds 的重复（幂等 APPEND 兜底）
    if (Array.isArray(ledger.decisions)) {
      const counts = {};
      for (const d of ledger.decisions) {
        if (d && cov.decisionIds.includes(d.id)) counts[d.id] = (counts[d.id] || 0) + 1;
      }
      for (const id of Object.keys(counts)) {
        if (counts[id] > 1) failures.push(`台账中 ${id} 出现 ${counts[id]} 次（per-expert 重试未幂等 APPEND，须按 id 去重）`);
      }
    }
  }

  // middleware 组化判据：澄清决策材料存在且含「连接配置」段锚点（防半文档过闸）。
  // free 只记录中间件类型、不收集连接值 ⇒ 该段不要求（scenario 分叉见函数头注）。
  if (typeof clarifyFilePath === 'string' && clarifyFilePath.trim() !== '') {
    let clarifyContent = null;
    try {
      clarifyContent = readFileSync(clarifyFilePath, 'utf-8');
    } catch {
      failures.push(`${expertId} 澄清决策材料缺失：${clarifyFilePath}（组内收尾步未落盘——选型/连接配置须落全，禁半文档过闸）`);
    }
    if (
      scenario !== 'free' &&
      clarifyContent !== null &&
      !clarifyContent.includes(MIDDLEWARE_CLARIFY_SECTION_ANCHOR)
    ) {
      failures.push(
        `${expertId} 澄清决策材料缺「${MIDDLEWARE_CLARIFY_SECTION_ANCHOR}」段（${clarifyFilePath}）——中间件连接配置（真实连接值/建通道结果）须按收尾步契约落全`,
      );
    }
  }

  return { ok: failures.length === 0, failures };
}

// ── 顶层可执行派发（仅在直接执行时跑，被 import 时不执行）──────────────────────
// async 的唯一原因是 cross-domain-decl 分支要按需 `await import()` shared 单源模块（见文件头）；
// 其余分支同步执行、照旧以 process.exit 收口，正常输出与退出码逐字不变。
async function main() {
  const allowedModes = ['data-model', 'cross-domain-fk', 'cross-domain-relations', 'cross-domain-decl', 'user-stories', 'architecture', 'coverage-gaps', 'requirement-coverage', 'clarify-idempotence', 'backend-design-integrity', 'expert-self-check'];
  const [,, mode, filePath] = process.argv;

  // cross-domain-decl 用命名参数（--relations/--entity-dir/--carrier，carrier 可重复），不走 <abs-path> 必填校验；
  // 必须在校验之前分支，否则缺位置参数会被 Usage 拦下。输出恒为一行机器可读 JSON，退出码 ok?0:1。
  if (mode === 'cross-domain-decl') {
    const values = { '--relations': [], '--entity-dir': [], '--carrier': [] };
    const argErrors = [];
    let fix = false;
    const argvTail = process.argv.slice(3);
    for (let i = 0; i < argvTail.length; i++) {
      const token = argvTail[i];
      // `--fix` 是无值开关（D7 writer）：须在「flag 取值」逻辑之前单独分流，
      // 否则会被当成待取值 flag —— 要么吃掉下一个参数，要么误报「缺值」。
      if (token === '--fix') {
        fix = true;
        continue;
      }
      if (!Object.prototype.hasOwnProperty.call(values, token)) {
        argErrors.push(`未知参数：${token}`);
        continue;
      }
      const next = argvTail[i + 1];
      if (next === undefined || next.startsWith('--')) {
        // 缺值 flag 禁静默退化为「不传」（同 --proposal-kinds 口径）：否则会以空 carrier 集判绿。
        argErrors.push(`${token} 缺值`);
        continue;
      }
      values[token].push(next);
      i++;
    }
    const relationsPath = values['--relations'][0];
    const entityDir = values['--entity-dir'][0];
    if (argErrors.length === 0 && (!relationsPath || !entityDir || values['--carrier'].length === 0)) {
      argErrors.push('缺参数：须 --relations <cross-domain-relations.json> --entity-dir <实体文档目录> --carrier <id>（可重复）');
    }
    if (argErrors.length > 0) {
      const r = { ok: false, failures: [`cross-domain-decl 参数非法：${[...new Set(argErrors)].join('；')}`], advisories: [] };
      console.log(JSON.stringify(fix ? { ...r, fixed: [] } : r));
      process.exit(1);
    }
    // 按需加载 shared 单源（语义见文件头）：缺席 ⇒ 结构化信封 + exit 1，不让未捕获异常冒出去。
    // 文案点名文件与原因，上层据此区分「判据不可用」与「产物确实缺行」，禁按其它路径放行。
    let decl;
    try {
      decl = await import('./shared/cross-domain-decl.mjs');
    } catch (e) {
      const r = {
        ok: false,
        failures: [
          `部署面缺 shared/cross-domain-decl.mjs（cross-domain-decl 判据不可用）：${e?.message ?? e}——该文件被 template/.gitignore 的 \`.specify/*\` 忽略，须随部署面显式携带（force-add 或 gitignore 放行）；判据不可判 ⇒ 红，禁静默放行`,
        ],
        advisories: [],
      };
      console.log(JSON.stringify(fix ? { ...r, fixed: [] } : r));
      process.exit(1);
    }
    const r = checkCrossDomainDecl({ relationsPath, entityDir, carriers: values['--carrier'], decl, fix });
    console.log(JSON.stringify(r));
    process.exit(r.ok ? 0 : 1);
  }

  // backend-design-integrity / expert-self-check 用命名参数（--coverage-dir/--ledger/...），不走 <abs-path> 必填校验。
  if (mode === 'backend-design-integrity') {
    const arg = (k) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : null; };
    const coverageDir = arg('--coverage-dir');
    const ledgerPath = arg('--ledger');
    const prevPath = arg('--prev');
    const readmePath = arg('--readme');
    const rosterRaw = arg('--roster');
    if (!coverageDir || !ledgerPath || !readmePath || !rosterRaw) {
      console.log(JSON.stringify({ ok: false, failures: ['backend-design-integrity 缺参数：须 --coverage-dir/--ledger/--readme/--roster（可选 --prev）'] }));
      process.exit(0);
    }
    const rosterIds = rosterRaw.split(',').map((s) => s.trim()).filter(Boolean);
    // --declarations 可选：声明导出 JSON 路径（缺省 = 脚本同目录 shared/clarify-declarations.json）。
    // 单测用它注入「声明漂移」的合成证据；生成工程里不需要传（随 template 拷贝同目录就位）。
    const r = checkBackendDesignIntegrity({
      coverageDir,
      ledgerPath,
      prevPath,
      readmePath,
      rosterIds,
      declarationsPath: arg('--declarations'),
    });
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }

  if (mode === 'expert-self-check') {
    // expert-self-check <coverageFile> <expertId> <ledgerPath> <expectedWritesTo> [fragmentPath] [clarifyFilePath]
    // 第 5 参 <fragmentPath> 可选：并发四专家写独占碎片（backend/_meta/clarify-fragments/<expertId>.json）时传，
    // FREEZE 轮（专家不产碎片、采用台账 prev decisions）与 authz（直写台账）不传——不传则行为与旧版逐字一致。
    // 第 6 参 <clarifyFilePath> 可选：middleware 组化判据——传澄清决策材料路径时断言存在且含「连接配置」段
    // 锚点（防半文档过闸）；其它专家不传，行为不变。
    // --proposal-kinds 是**命名参数**，须先从位置参数序列里摘掉再解构——否则未传第 5/6 参时
    // 该 flag 的两个 token 会被当成 fragmentPath/clarifyFilePath（NaN 式错位，症状是"脚本执行异常"）。
    const argvTail = process.argv.slice(3);
    const pkFlagIdx = argvTail.indexOf('--proposal-kinds');
    // 无值 flag（`--proposal-kinds` 是最后一个 token）= 调用方 bug，**禁静默退化为引擎默认集**：
    // 那会把「声明侧覆盖没生效」伪装成「按默认判」——闭集被悄悄换掉而无人知晓（证据不可判当红，
    // 同「JSON.parse catch 禁 null 兜底」铁律）。注意与「值为空串」严格区分：空串是声明物
    // `proposalKinds: []` 的到达形态（显式零类别、合法关闸），只有「后面根本没有 token」才判红。
    if (pkFlagIdx > -1 && pkFlagIdx + 1 >= argvTail.length) {
      console.log(JSON.stringify({ ok: false, failures: ['--proposal-kinds 缺值：该 flag 须后跟 `<a|b|c>`（声明侧覆盖的提案类别闭集）。值为空串 ≠ 不传——空串表示显式零类别（关闭提案通道），不传表示取引擎默认三值'] }));
      process.exit(0);
    }
    const pkRaw = pkFlagIdx > -1 ? argvTail[pkFlagIdx + 1] : null;
    const flagTokenIdx = new Set();
    if (pkFlagIdx > -1) { flagTokenIdx.add(pkFlagIdx); flagTokenIdx.add(pkFlagIdx + 1); }
    const positional = argvTail.filter((_, i) => !flagTokenIdx.has(i));
    const [coverageFile, expertId, ledgerPath, expectedWritesTo, fragmentPath, clarifyFilePath] = positional;
    if (!coverageFile || !expertId || !ledgerPath || !expectedWritesTo) {
      console.log(JSON.stringify({ ok: false, failures: ['expert-self-check 缺参数：须 <coverageFile> <expertId> <ledgerPath> <expectedWritesTo>（第 5 参 <fragmentPath> 可选：传碎片文件路径启用碎片校验，FREEZE 轮/authz 不传走台账断言；第 6 参 <clarifyFilePath> 可选：middleware 组化澄清落全判据；--proposal-kinds <a|b|c> 可选：声明侧覆盖的提案类别闭集）'] }));
      process.exit(0);
    }
    // --proposal-kinds 可选：声明侧覆盖的提案类别闭集（`|` 分隔）。不传 = 引擎默认三值。
    const proposalKinds = pkRaw === null ? undefined : pkRaw.split('|').map((x) => x.trim());
    // scenario 取同文件既有的 readScenarioArg（architecture/data-model 分支同款；缺省 fresh ⇒
    // 存量调用逐字不变）。**不新增 CLI 参数**：free 判据经 APP_TECH_STACK_INFO 环境继承到达子进程。
    const { scenario, error: scenarioError } = readScenarioArg();
    if (scenarioError) {
      console.log(JSON.stringify({ ok: false, failures: [scenarioError] }));
      process.exit(0);
    }
    const r = checkExpertSelfCheck({ coverageFile, expertId, ledgerPath, expectedWritesTo, fragmentPath, clarifyFilePath, proposalKinds, scenario });
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }

  if (!allowedModes.includes(mode) || !filePath) {
    console.error(`Usage: node check-backend-design.mjs <${allowedModes.join('|')}> <abs-path>`);
    process.exit(1);
  }

  if (mode === 'cross-domain-fk') {
    // cross-domain-fk 不读传入文件内容，而是扫描其所在目录全部 entity-*.md，故不走下面的 content 读取。
    const r = checkCrossDomainFk(filePath);
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }

  if (mode === 'clarify-idempotence') {
    // 幂等门：filePath = 台账 clarify-decisions.json；可选 --prev <上一轮台账>（预留，当前不消费）。
    // 自读 ledger（+prev），不走下面的通用 content 读取。快照已降级为提示：不再接受 --snapshot 权威。
    const prevFlag = process.argv.indexOf('--prev');
    const prevPath = prevFlag > -1 ? process.argv[prevFlag + 1] : null;
    const r = checkClarifyIdempotence(filePath, prevPath);
    const failures = r.failures ?? [];
    console.log(JSON.stringify({ ok: failures.length === 0, failures }, null, 2));
    process.exit(0);
  }

  let content;
  try {
    content = readFileSync(filePath, 'utf-8');
  } catch (e) {
    console.log(JSON.stringify({ ok: false, failures: [`无法读取文件: ${filePath}`] }));
    process.exit(0);
  }

  if (mode === 'architecture') {
    // --scenario（plan 2026-09-23/plans-free-mode-… 条目 6 / D5 桶 C）：'free' 摘掉骨架约定产物的
    // 「须存在 + 结构门」两条判据。**缺省 = fresh**（旧调用方/未传参调用行为逐字节不变）；
    // 非 fresh|incremental|free 的取值直接红，不静默按 fresh 走（防拼错场景名静默放行）。
    // 取值解析统一走 readScenarioArg（data-model 模式共用同一条，禁两处各写一遍）。
    const { scenario, error: scenarioError } = readScenarioArg();
    if (scenarioError) {
      console.log(JSON.stringify({ ok: false, failures: [scenarioError] }));
      process.exit(0);
    }
    const r = checkArchitecture(content, filePath, scenario);
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }
  if (mode === 'user-stories') {
    const r = checkUserStories(content, filePath);
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }
  if (mode === 'coverage-gaps') {
    const r = checkCoverageGaps(content);
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }
  if (mode === 'requirement-coverage') {
    // requirement-coverage 门：filePath = _meta/requirement-coverage.json，仅校验 manifest 内容本身
    // （信封/gapType/anchors 非空留痕/conflict 处置态）。锚点真实性校验已取消（2026-09-03 拍板，见函数头注）。
    const r = checkRequirementCoverage(content);
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }
  if (mode === 'cross-domain-relations') {
    // `--require-fk-pk` / `--require-display-column` 是 opt-in 开关（默认关闭）：
    //   · 默认 = F4 之前行为（不做 promote-fk-* 的 targetField 主键校验、不做 mark-snapshot 展示列校验）；
    //   · 只有七阶段 micro-incremental-v1 的 detect 包装通过 checker 追加这两个 flag。
    const argvTail = process.argv.slice(3);
    const requireFkPk = argvTail.includes('--require-fk-pk');
    const requireDisplayColumn = argvTail.includes('--require-display-column');
    const r = await checkCrossDomainRelations(content, filePath, { requireFkPk, requireDisplayColumn });
    console.log(JSON.stringify(r, null, 2));
    process.exit(0);
  }

  // data-model 模式（fall-through）：fresh greenfield 全套（结构 + 保留字 + id），逐字节等价改造前。
  // 增量场景不自检 data-model，改用 check-incremental-entity.mjs 按存量/新建分类调用这些 helper。
  // 主键门 #9 方言感知（plan 2026-09-21 §D2）：真值从 entity 路径向上解析 tech-stack.json database；
  // 缺席=MySQL 存量形态（回归锁）；在场但不可解析=结构化红禁假绿（dual-review 2026-09-21 P2）；
  // 归一命中但字典缺行=放行留痕（2026-09-22 拍板）；未知类型=D7 矩阵降级留痕（见 checkIdMandate）。
  // scenario（dual-review 2026-09-24 P1 补做）：只影响**判据理由文案**的支（D5 byte-exact 双分支），
  // 不影响判据本身。取值同 architecture 分支（readScenarioArg）；缺省 fresh ⇒ 存量调用逐字节不变。
  // ⚠️ 命令 token 在 TS 侧是**模块级多场景常量**（`ENTITY_CHECK_CMD_FRESH_PREFIX` 等），场景无法经
  // 实参透传 ⇒ 被派发子进程只能靠 `APP_TECH_STACK_INFO` 环境继承拿到同源判据（见文件头 readScenarioArg）。
  const { scenario, error: scenarioError } = readScenarioArg();
  if (scenarioError) {
    console.log(JSON.stringify({ ok: false, failures: [scenarioError], warnings: [], notes: [] }, null, 2));
    process.exit(0);
  }
  const dialect = resolveDialectFromEntityPath(filePath);
  const idCheck = dialect.parseError
    ? {
        ok: false,
        failures: [
          `tech-stack.json 存在但不可解析（${dialect.parseError}）——方言真值不可判，禁按默认形态判绿（证据不可解析禁 skip 兜底）`,
        ],
        warnings: [],
        notes: [],
      }
    : checkIdMandate(content, dialect.key ?? (dialect.raw ? `未知类型(${dialect.raw})` : 'MySQL'), scenario);
  // C1 语法门先跑，但只追加 failures，不短路既有结构/保留字/方言判据。
  // ENGINE= 要求只落在 MySQL 系（含 tech-stack 缺席的存量形态）：PG/Oracle 原生 DDL 无该表选项，
  // 硬要求会把方言门既有绿色夹具误判红，且与 §C1「不改现有方言规则」冲突。
  const requireEngine = dialect.key === 'MySQL' || (dialect.key == null && !dialect.raw && !dialect.parseError);
  // D2 域标注真值（plan 2026-11-05/… D2）：只追加 failures；domain.json 缺席/domains 空 ⇒ 不适用。
  // 单文件模式同样从 filePath 向上定位 plans/，域清单每次进程只读一次（本分支只检一个文件）。
  const domainLabel = checkDomainLabel(content, { filePath });
  const failures = [
    ...checkDdlSyntax(content, basename(filePath), { requireEngine }).failures,
    ...checkEntityStructure(content).failures,
    ...checkReservedIdentifiers(content, scenario).failures,
    ...idCheck.failures,
    ...domainLabel.failures,
  ];
  console.log(
    JSON.stringify({ ok: failures.length === 0, failures, warnings: idCheck.warnings, notes: idCheck.notes }, null, 2),
  );
  process.exit(0);
}

// 仅当作为主入口直接执行时才跑 main（被 check-incremental-entity.mjs import 拿 helper 时不自动执行）。
const _isMainEntry = process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]);
if (_isMainEntry) {
  // main 为 async（仅因 cross-domain-decl 的按需 import）：rejection 显式转非零退出，
  // 避免 unhandled rejection 的静默/版本相关行为；各分支的正常输出仍由 process.exit 收口。
  main().catch((e) => {
    console.error(`[check-backend-design] 未捕获异常：${e?.stack ?? e}`);
    process.exit(1);
  });
}
