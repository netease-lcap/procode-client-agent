import path from 'node:path';
import { auto, getActiveSpecDir, readFileSync } from './shared/index.mjs';

const requiredFields = ['name', 'serviceTitle', 'description', 'serviceType'];
const fields = [...requiredFields, 'endpointType', 'registered'];

/** 先检查清单结构，再逐项检查；前置规则失败后不继续访问内部字段。 */
const listRules = [
  {
    check: (entries) => Array.isArray(entries),
    message: '必须是工程数组。',
  },
  {
    check: (entries) => entries.length > 0,
    message: '必须是非空工程数组；不拆分时保留一个应用工程，不写空数组。',
  },
];

const entryRules = [
  {
    check: (entry) => entry !== null && typeof entry === 'object' && !Array.isArray(entry),
    message: '必须是工程对象。',
  },
  {
    check: (entry) => Object.keys(entry).every((key) => fields.includes(key)) && requiredFields.every((key) => Object.hasOwn(entry, key)),
    message: `必须包含 ${requiredFields.join('、')}，仅允许额外声明 endpointType、registered。`,
  },
  {
    check: (entry) => !Object.hasOwn(entry, 'registered') || typeof entry.registered === 'boolean',
    message: 'registered 必须为布尔值，由服务注册成功后回写，不得手动设为 true 绕过注册。',
  },
  ...requiredFields.map((key) => ({
    check: (entry) => typeof entry[key] === 'string' && entry[key].trim().length > 0,
    message: `${key} 必须是非空字符串。`,
  })),
  {
    check: (entry) => /^[a-z0-9][a-z0-9_-]*$/.test(entry.name),
    message: 'name 只允许小写字母、数字、连字符或下划线，以字母或数字开头。',
  },
  {
    check: (entry) => /^\p{Script=Han}+$/u.test(entry.serviceTitle),
    message: 'serviceTitle 必须使用中文。',
  },
  {
    check: (entry) => entry.serviceType === 'frontend',
    message: '本清单只允许正式前端工程，serviceType 必须为 frontend，不允许 backend、prototype 或其他服务类型。',
  },
  {
    check: (entry) => ['pc', 'h5'].includes(entry.endpointType),
    message: '前端工程必须填写 endpointType，且值为 pc 或 h5。',
  },
  {
    check: (entry, { names }) => !names.has(entry.name),
    message: 'name 重复，不能让下游服务匹配产生歧义。',
  },
  {
    check: (entry, { titles }) => !titles.has(entry.serviceTitle),
    message: 'serviceTitle 重复，不能让下游服务匹配产生歧义。',
  },
];

/** 只校验当前迭代的工程清单，不注册服务、不修改文件。 */
export const checkEnds = (rootDir = process.cwd()) => {
  rootDir = path.resolve(rootDir || process.cwd());
  let file = '';
  try {
    const activeSpecDir = getActiveSpecDir(rootDir);
    if (!activeSpecDir) return { ok: false, output: `未定位当前规范目录（工作目录：${rootDir}），无法确定 ends.json 的绝对路径。` };
    file = path.resolve(rootDir, activeSpecDir, 'ends.json');
    const source = readFileSync(file);
    if (source === undefined) return { ok: false, output: `${file} 不存在，请先生成工程清单。` };
    const entries = JSON.parse(source);
    for (const rule of listRules) {
      if (!rule.check(entries)) return { ok: false, output: `${file} ${rule.message}` };
    }
    const names = new Set();
    const titles = new Set();
    for (const [index, entry] of entries.entries()) {
      for (const rule of entryRules) {
        if (!rule.check(entry, { names, titles })) {
          return { ok: false, output: `${file} 第 ${index + 1} 项：${rule.message}` };
        }
      }
      names.add(entry.name);
      titles.add(entry.serviceTitle);
    }
    return { ok: true, output: `${file} 工程清单结构校验通过，共 ${entries.length} 项。` };
  } catch (error) {
    return { ok: false, output: file
      ? `${file} 读取或 JSON 解析失败：${error.message}`
      : `无法定位 ends.json（工作目录：${rootDir}）：${error.message}` };
  }
};

/** 与现有检查脚本保持一致：成功单行，失败多行，供公共 hook handle 消费。 */
export const toRaw = (rootDir = process.cwd()) => {
  const result = checkEnds(rootDir);
  return result.ok ? result.output : [
    `工程清单校验失败：${result.output}`,
    '请依据上述绝对路径定位并修复工程清单后重新执行校验；若尚未定位文件，先确认当前规范目录。不修改其他迭代或放宽校验规则。',
  ].join('\n');
};

auto(import.meta)(() => {
  const output = toRaw();
  // 保留命令行失败退出码；导入和 hook 检查不修改进程状态。
  process.exitCode = output.split('\n').filter(Boolean).length > 1 ? 1 : 0;
  return output;
});

export default toRaw;
