#!/usr/bin/env node
/**
 * 门 B：交接物完整性（§5.4；不做独立 DB 审计）。
 *
 * 输入（全部只读）：
 *   plans/backend/_meta/code-table-inventory.json     Agent A 输出（门 A 已放行）
 *   plans/backend/_meta/db-table-list.json            runner catalog preflight 输出
 *   plans/backend/_meta/table-structure.raw.json      runner 输出（唯一写者）
 *   plans/backend/_meta/table-structure.evidence.json Agent B 输出（唯一写者）
 *
 * 九条规则：
 *   1. 覆盖：每张 codeTable 有且仅有一条 evidence；多余 evidence = 红；
 *   2. DB-only identity：dbOnly 必须在 db-table-list.json 中存在；
 *   3. 原始证据：raw 非空、未截断、parseIssues 为空；evidence.rawRef 命中对应 raw 记录；
 *   4. 归一自洽：evidence 的列/索引/约束与 raw 对账（名称/数量）；不调用旧 MySQL parser；
 *   5. 非空结构：code table 的 columns 为空 = 红；
 *   6. 方言声明：evidence.dialect 非空即可（不设白名单）；给了 `--binding` 时再加真值判据
 *      `EVIDENCE_DIALECT`（evidence.dialect 必须等于 binding.databaseType；忽略大小写，
 *      但不做别名折叠——`mysql8` ≠ `mysql`）；
 *   7. 归一来源：evidence.normalization === "agent"；
 *   8. 目标库真值：给了 `--manifest` 时，evidence 选中源的 database 必须等于
 *      `.manifest/datasources.json#<dataSourceName>.config.database`（`EVIDENCE_DATABASE`；
 *      仅 trim 后字面相等）；
 *   9. 失败分类：输出 `failureClass.kind` = repairable / blocked / external，供外层决定
 *      checker feedback / 阶段终态 blocked / error。
 *
 * 通道收口（Wave 1 · plan 2026-11-09 §5.4 / S3）：
 *   · 新批次结构证据只允许 `channel: "mcp"`（raw 顶层或逐源 sources[]）；
 *   · 旧 `channel: "local"` 是**确定性红停**：保留旧文件供追溯，但返回 P4 重新采集入口，
 *     不得静默跳过、不得当空集、不得改写标签冒充 MCP；
 *   · 通道缺失 / 非法 / 不可解析 / 条目截断同样红停（不得当作「无证据跳过」）。
 *
 * 输出：stdout 一行结构化 JSON（ok / failures / classification / failureClass / summary / recovery），
 * exit 0|1。缺文件、坏 JSON、形状非法都算红，绝不静默跳过。
 *
 * CLI：
 *   node check-table-structure-evidence.mjs [check] [--root <dir>]
 *     [--inventory <path>] [--db-table-list <path>] [--raw <path>] [--evidence <path>]
 *     [--binding <path>] [--manifest <path>] [--data-source-name <name>]
 *
 * 模块导出 validateTableStructureEvidence(...) 供单测直接使用。
 */

import { createHash } from 'crypto';
import { existsSync, readFileSync } from 'fs';
import { basename, resolve } from 'path';
import { fileURLToPath } from 'url';

import {
  assertSingleOwner,
  canonicalDialect,
  foldIdentifierForDialect,
} from './shared/schema/dialect-rules.mjs';

export const GATE_VERSION = 1;
export const EVIDENCE_SCHEMA_VERSION = 1;

/**
 * 旧 local 证据的确定性恢复入口（plan 2026-11-09 §5.4 / exec S3）。
 * 只产采集证据，不产执行回执；重新采集失败时保留旧文件供追溯。
 */
export const RECOLLECT_RECOVERY = Object.freeze({
  action: 'rerun-stage-four-collection',
  stage: '阶段四',
  step: 'P4',
  entry: '重跑阶段四：门 A preflight → 逐表结构采集 → 基线补全 → 证据归一 → 基线装配',
  message: '通道已退役，请重跑阶段四重新采集',
});

export const INVENTORY_REL = 'plans/backend/_meta/code-table-inventory.json';
export const DB_TABLE_LIST_REL = 'plans/backend/_meta/db-table-list.json';
export const RAW_REL = 'plans/backend/_meta/table-structure.raw.json';
export const EVIDENCE_REL = 'plans/backend/_meta/table-structure.evidence.json';

export const FAILURE_CODES = Object.freeze({
  SCHEMA: 'TABLE_STRUCTURE_SCHEMA',
  INVENTORY: 'TABLE_STRUCTURE_INVENTORY',
  DB_LIST: 'TABLE_STRUCTURE_DB_LIST',
  DATASOURCE: 'TABLE_STRUCTURE_DATASOURCE',
  DB_ONLY_MISSING: 'TABLE_STRUCTURE_DB_ONLY_MISSING',
  RAW_MISSING: 'TABLE_STRUCTURE_RAW_MISSING',
  RAW_SCHEMA: 'TABLE_STRUCTURE_RAW_SCHEMA',
  RAW_EMPTY: 'TABLE_STRUCTURE_RAW_EMPTY',
  RAW_TRUNCATED: 'TABLE_STRUCTURE_RAW_TRUNCATED',
  RAW_PARSE_ISSUES: 'TABLE_STRUCTURE_RAW_PARSE_ISSUES',
  CHANNEL_RETIRED_LOCAL: 'TABLE_STRUCTURE_CHANNEL_RETIRED_LOCAL',
  CHANNEL_MISSING: 'TABLE_STRUCTURE_CHANNEL_MISSING',
  CHANNEL_INVALID: 'TABLE_STRUCTURE_CHANNEL_INVALID',
  EVIDENCE_MISSING: 'TABLE_STRUCTURE_EVIDENCE_MISSING',
  COVERAGE_MISSING: 'TABLE_STRUCTURE_COVERAGE_MISSING',
  COVERAGE_DUPLICATE: 'TABLE_STRUCTURE_COVERAGE_DUPLICATE',
  EVIDENCE_UNEXPECTED: 'TABLE_STRUCTURE_EVIDENCE_UNEXPECTED',
  RAWREF_MISSING: 'TABLE_STRUCTURE_RAWREF_MISSING',
  RAWREF_INVALID: 'TABLE_STRUCTURE_RAWREF_INVALID',
  RAWREF_UNMATCHED: 'TABLE_STRUCTURE_RAWREF_UNMATCHED',
  RAWREF_AMBIGUOUS: 'TABLE_STRUCTURE_RAWREF_AMBIGUOUS',
  RAWREF_SQL_MISMATCH: 'TABLE_STRUCTURE_RAWREF_SQL_MISMATCH',
  RAWREF_RESULT_MISMATCH: 'TABLE_STRUCTURE_RAWREF_RESULT_MISMATCH',
  RECONCILE_FAILED: 'TABLE_STRUCTURE_RECONCILE_FAILED',
  RECONCILE_COLUMNS: 'TABLE_STRUCTURE_RECONCILE_COLUMNS',
  RECONCILE_INDEXES: 'TABLE_STRUCTURE_RECONCILE_INDEXES',
  RECONCILE_CONSTRAINTS: 'TABLE_STRUCTURE_RECONCILE_CONSTRAINTS',
  RECONCILE_FOREIGN_KEYS: 'TABLE_STRUCTURE_RECONCILE_FOREIGN_KEYS',
  COLUMNS_EMPTY: 'TABLE_STRUCTURE_COLUMNS_EMPTY',
  DIALECT: 'TABLE_STRUCTURE_DIALECT',
  EVIDENCE_DIALECT: 'TABLE_STRUCTURE_EVIDENCE_DIALECT',
  EVIDENCE_DATABASE: 'TABLE_STRUCTURE_EVIDENCE_DATABASE',
  NORMALIZATION: 'TABLE_STRUCTURE_NORMALIZATION',
  MULTI_OWNER: 'TABLE_STRUCTURE_MULTI_OWNER',
  OWNER: 'TABLE_STRUCTURE_OWNER',
  TABLE_NAME: 'TABLE_STRUCTURE_TABLE_NAME',
  USAGE: 'TABLE_STRUCTURE_USAGE',
});

const isPlainObject = (value) =>
  value != null && typeof value === 'object' && !Array.isArray(value);

const isNonEmptyString = (value) => typeof value === 'string' && value.trim() !== '';

/** 记录/来源条目的 dataSourceName（空字符串表示未标注）。 */
const sourceTagOf = (value) =>
  isPlainObject(value) && isNonEmptyString(value.dataSourceName) ? value.dataSourceName.trim() : '';

/**
 * 库表数（只计数，不判断对错）：按 dataSourceName 选当前裁决源；无 sources 时用顶层 tableNames。
 * 缺失/歧义返回 null（调用方不得据此判 blocked）。
 */
const dbTableCountOf = (dbTableList, dataSourceName = '') => {
  const sources = isPlainObject(dbTableList) && Array.isArray(dbTableList.sources)
    ? dbTableList.sources.filter(isPlainObject)
    : [];
  if (sources.length === 0) {
    return isPlainObject(dbTableList) && Array.isArray(dbTableList.tableNames)
      ? dbTableList.tableNames.length
      : null;
  }
  const entry = isNonEmptyString(dataSourceName)
    ? sources.find((item) => sourceTagOf(item) === dataSourceName)
    : sources[0];
  if (!entry) return null;
  return Array.isArray(entry.tableNames) ? entry.tableNames.length : null;
};

const failure = (code, path, message, extra = {}) => ({ code, path, message, ...extra });

// ─── 通道收口（Wave 1 · B §5.4 / S3）─────────────────────────────────────────
// 通道真值可出现在 raw（顶层 / 逐源）、db-table-list（顶层 / 逐源）与 evidence（顶层 / source / 逐源）。
// 任何一处声明 local 即确定性红停；raw 是新批次的唯一通道来源，缺失/非法同样红停。

/** 收集一份文档上的显式通道声明（null/undefined 视为未声明）。 */
const channelDeclarationsOf = (document) => {
  const list = [];
  if (!isPlainObject(document)) return list;
  const add = (path, value) => {
    if (value === undefined || value === null) return;
    list.push({ path, value });
  };
  add('channel', document.channel);
  if (isPlainObject(document.source)) add('source.channel', document.source.channel);
  for (const [index, source] of (Array.isArray(document.sources) ? document.sources : []).entries()) {
    if (isPlainObject(source)) add(`sources[${index}].channel`, source.channel);
  }
  return list;
};

const channelFailure = (code, path, message, channel) =>
  failure(code, path, message, {
    kind: 'blocked',
    channel: channel ?? null,
    recovery: { ...RECOLLECT_RECOVERY },
  });

/**
 * 通道校验：local → CHANNEL_RETIRED_LOCAL（P4 重采入口）；缺失/非法 → CHANNEL_MISSING/INVALID。
 * 返回的 failures 带 `kind:"blocked"`，让外层按「重采/重写 evidence 不会改变结论」处理（红停，不空转）。
 */
const validateEvidenceChannel = ({ raw, dbTableList, evidence }) => {
  const failures = [];

  // raw 是新批次通道的唯一事实来源：必须有可判的声明，不能靠「没写」蒙混。
  if (isPlainObject(raw)) {
    const rawChannels = channelDeclarationsOf(raw);
    if (rawChannels.length === 0) {
      failures.push(
        channelFailure(
          FAILURE_CODES.CHANNEL_MISSING,
          '$raw.channel',
          'raw.channel 缺失：新批次结构证据必须由 MCP runner 产出并声明 channel:"mcp"；' +
            '旧 local 证据不得作为本轮基线。通道已退役，请重跑阶段四重新采集（P4）。',
          null,
        ),
      );
    }
  }

  const documents = [
    ['$raw', raw],
    ['$dbTableList', dbTableList],
    ['$evidence', evidence],
  ];
  for (const [prefix, document] of documents) {
    for (const { path, value } of channelDeclarationsOf(document)) {
      const channel = typeof value === 'string' ? value.trim() : '';
      if (channel === 'mcp') continue;
      if (channel === 'local') {
        failures.push(
          channelFailure(
            FAILURE_CODES.CHANNEL_RETIRED_LOCAL,
            `${prefix}.${path}`,
            `${prefix}.${path}="local"：本地直连通道已退役，旧 local 成功产物只能作为历史展示，` +
              '不得当作本轮 MCP 成功证据或改写标签冒充 MCP。通道已退役，请重跑阶段四重新采集（P4）。',
            'local',
          ),
        );
        continue;
      }
      failures.push(
        channelFailure(
          FAILURE_CODES.CHANNEL_INVALID,
          `${prefix}.${path}`,
          `${prefix}.${path}=${JSON.stringify(value)} 非法：结构证据通道只允许 "mcp"（local 已退役，` +
            '缺失/非字符串视为结构不符）。请重跑阶段四重新采集（P4）。',
          channel || null,
        ),
      );
    }
  }

  return failures;
};


/** datasource-binding envelope → 选中源条目（单源缺名时取唯一一条；多源歧义返回 null）。 */
const selectBindingEntry = (binding, name) => {
  if (!isPlainObject(binding)) return null;
  const list = Array.isArray(binding.bindings)
    ? binding.bindings.filter(isPlainObject)
    : isNonEmptyString(binding.dataSourceName)
      ? [binding]
      : [];
  if (list.length === 0) return null;
  if (isNonEmptyString(name)) return list.find((entry) => sourceTagOf(entry) === name) || null;
  return list.length === 1 ? list[0] : null;
};

/** `.manifest/datasources.json` → 选中源条目（单源缺名时取唯一一条；多源歧义返回 null）。 */
const selectManifestEntry = (manifest, name) => {
  if (!isPlainObject(manifest)) return null;
  const list = Array.isArray(manifest.dataSources)
    ? manifest.dataSources.filter(isPlainObject)
    : isNonEmptyString(manifest.dataSourceName)
      ? [manifest]
      : [];
  if (list.length === 0) return null;
  if (isNonEmptyString(name)) return list.find((entry) => sourceTagOf(entry) === name) || null;
  return list.length === 1 ? list[0] : null;
};

/**
 * 失败分类（D0）：只读 raw 里的错误字段，避免把列名/表名里的普通单词误判成外部故障。
 */
const EXTERNAL_ERROR_RE =
  /(?:ECONNREFUSED|ECONNRESET|ENOTFOUND|ETIMEDOUT|EHOSTUNREACH|EAI_AGAIN|socket hang up)|(?:\b401\b|\b403\b)|access denied|unauthori[sz]ed|forbidden|鉴权[^\n]{0,20}(?:失败|不可用|拒绝)|认证[^\n]{0,20}(?:失败|不可用|拒绝)|权限不足|缺少权限|缺权限|(?:MCP|mcp)[^\n]{0,60}(?:会话|session)[^\n]{0,30}(?:打不开|无法打开|不可用|失败|超时|断开)|(?:网络|平台接口)[^\n]{0,30}(?:不可达|不通|无法访问|超时|失败)/i;

const rawErrorTextOf = (raw) => {
  if (!isPlainObject(raw)) return '';
  const parts = [];
  const push = (value) => {
    if (isNonEmptyString(value)) parts.push(value);
    else if (isPlainObject(value) || Array.isArray(value)) {
      try {
        parts.push(JSON.stringify(value));
      } catch {
        // 循环引用/坏值不影响分类。
      }
    }
  };
  push(raw.error);
  push(raw.failure);
  push(raw.execution);
  for (const source of Array.isArray(raw.sources) ? raw.sources : []) {
    push(source?.error);
    push(source?.execution);
  }
  for (const record of Array.isArray(raw.tables) ? raw.tables : []) {
    push(record?.error);
    push(record?.executionError);
    push(record?.parseIssues);
  }
  return parts.join('\n');
};

/**
 * 失败分类：repairable（feedback 重写/重采）| blocked（外部数据前置不成立）| external（外部不可用）。
 *
 * 只做归因，不决定是否红停；外层按 kind 选择 feedback / stage-terminal / gate。
 */
const classifyFailure = (failures, context = {}) => {
  if (!Array.isArray(failures) || failures.length === 0) return null;
  const explicit = failures.find((item) => item.kind === 'blocked' || item.kind === 'external');
  if (explicit) return { kind: explicit.kind, reason: explicit.message };

  if (EXTERNAL_ERROR_RE.test(context.errorText || '')) {
    return {
      kind: 'external',
      reason: '外部依赖不可用（MCP 会话/鉴权/网络/平台接口）：唯一红停，不进入修复环',
    };
  }

  const summary = isPlainObject(context.summary) ? context.summary : {};
  const codeTableCount = Number(summary.codeTables || 0) + Number(summary.codeOnly || 0);
  const dbTableCount =
    Number.isFinite(context.dbTableCount)
      ? Number(context.dbTableCount)
      : Number(summary.codeTables || 0) + Number(summary.dbOnly || 0);
  if (dbTableCount === 0 && codeTableCount > 0) {
    return {
      kind: 'blocked',
      reason:
        `外部数据前置不成立：库 ${dbTableCount} 张表 / 代码 ${codeTableCount} 张表` +
        '（库中确实没有代码要求的表，重采/重写 evidence 不会变）',
    };
  }
  return { kind: 'repairable', reason: '证据可重采/可重写：agent 修复后重试' };
};

/** 稳定 JSON（recursively sorted keys），用于 rawResultDigest。 */
function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(',')}]`;
  const keys = Object.keys(value).sort();
  return `{${keys.map((key) => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function sha256(value) {
  return createHash('sha256').update(String(value), 'utf8').digest('hex');
}

/** 表身份键：去引号后按方言折叠（quoted 不保留大小写，仅用于列匹配）。 */
function tableKey(dialect, name) {
  return foldIdentifierForDialect(dialect, name, { quoted: false });
}

function columnKey(dialect, column) {
  if (typeof column === 'string') return foldIdentifierForDialect(dialect, column, { quoted: false });
  return foldIdentifierForDialect(dialect, column?.name, { quoted: column?.quoted === true });
}

function sameNameSet(left, right) {
  const a = [...left].sort();
  const b = [...right].sort();
  return a.length === b.length && a.every((value, index) => value === b[index]);
}

function countBy(list) {
  const map = new Map();
  for (const item of list) map.set(item, (map.get(item) || 0) + 1);
  return map;
}

// ─── DDL 机械扫描（独立于旧 parseShowCreateTable，只做对账） ────────────────

function findCreateTableBody(ddl) {
  const text = String(ddl ?? '');
  const match = /create\s+(?:or\s+replace\s+)?table\s+(?:if\s+not\s+exists\s+)?/i.exec(text);
  if (!match) return null;
  let index = match.index + match[0].length;
  while (index < text.length && text[index] !== '(') {
    if (text[index] === ';') return null;
    index += 1;
  }
  if (index >= text.length) return null;
  const start = index + 1;
  let depth = 1;
  let quote = null;
  for (index += 1; index < text.length; index += 1) {
    const char = text[index];
    if (quote) {
      if (char === quote) {
        if (text[index + 1] === quote) {
          index += 1;
        } else {
          quote = null;
        }
      }
      continue;
    }
    if (char === "'" || char === '"' || char === '`') {
      quote = char;
      continue;
    }
    if (char === '[') {
      quote = ']';
      continue;
    }
    if (char === '(') depth += 1;
    else if (char === ')') {
      depth -= 1;
      if (depth === 0) return text.slice(start, index);
    }
  }
  return null;
}

function splitTopLevel(body) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quote = null;
  for (let index = 0; index < body.length; index += 1) {
    const char = body[index];
    if (quote) {
      if (char === quote) {
        if (body[index + 1] === quote) index += 1;
        else quote = null;
      }
      continue;
    }
    if (char === "'" || char === '"' || char === '`') {
      quote = char;
      continue;
    }
    if (char === '[') {
      quote = ']';
      continue;
    }
    if (char === '(') depth += 1;
    else if (char === ')') depth = Math.max(0, depth - 1);
    else if (char === ',' && depth === 0) {
      parts.push(body.slice(start, index));
      start = index + 1;
    }
  }
  parts.push(body.slice(start));
  return parts.map((part) => part.trim()).filter(Boolean);
}

function firstToken(text) {
  const source = String(text ?? '');
  let index = 0;
  while (index < source.length && /\s/.test(source[index])) index += 1;
  if (index >= source.length) return null;
  const quote = source[index];
  if (quote === '"' || quote === '`' || quote === "'") {
    let value = '';
    index += 1;
    for (; index < source.length; index += 1) {
      if (source[index] === quote) {
        if (source[index + 1] === quote) {
          value += quote;
          index += 1;
          continue;
        }
        index += 1;
        break;
      }
      value += source[index];
    }
    return { name: value, quoted: true, rest: source.slice(index) };
  }
  if (quote === '[') {
    let value = '';
    index += 1;
    for (; index < source.length; index += 1) {
      if (source[index] === ']') {
        if (source[index + 1] === ']') {
          value += ']';
          index += 1;
          continue;
        }
        index += 1;
        break;
      }
      value += source[index];
    }
    return { name: value, quoted: true, rest: source.slice(index) };
  }
  const match = /^[^\s(]+/.exec(source.slice(index));
  if (!match) return null;
  return { name: match[0], quoted: false, rest: source.slice(index + match[0].length) };
}

const TABLE_DEFINITION_RE =
  /^(constraint|primary\s+key|unique(?:\s+(?:key|index))?|foreign\s+key|check|key|index|fulltext|spatial|partition|exclude|period|like)\b/i;

function tableDefinitionName(text, kind) {
  if (kind === 'index' && /^primary\s+key\b/i.test(text)) return null;
  const constraint = /^constraint\s+/i.exec(text);
  if (constraint) return firstToken(text.slice(constraint[0].length))?.name ?? null;
  if (/^foreign\s+key\b/i.test(text)) {
    const rest = text.replace(/^foreign\s+key\s*/i, '');
    const token = /^\(/.test(rest) ? null : firstToken(rest)?.name ?? null;
    return token;
  }
  if (/^(key|index|fulltext|spatial)\b/i.test(text)) {
    const rest = text.replace(/^(key|index|fulltext|spatial)\s*/i, '');
    if (/^\(/.test(rest)) return null;
    return firstToken(rest)?.name ?? null;
  }
  if (/^unique(?:\s+(?:key|index))?\b/i.test(text)) {
    const rest = text.replace(/^unique(?:\s+(?:key|index))?\s*/i, '');
    if (/^\(/.test(rest)) return null;
    return firstToken(rest)?.name ?? null;
  }
  return null;
}

/**
 * 从 DDL 文本机械抽取列名与表级定义计数。
 * 返回 null 表示无法解析出 CREATE TABLE 主体（调用方 fail-loud）。
 */
export function scanDdlStructure(ddl) {
  const body = findCreateTableBody(ddl);
  if (body == null) return null;
  const columns = [];
  const indexes = { count: 0, names: [] };
  const constraints = { count: 0, names: [] };
  const foreignKeys = { count: 0, names: [] };

  const add = (bucket, name) => {
    bucket.count += 1;
    bucket.names.push(name || null);
  };

  for (const item of splitTopLevel(body)) {
    const token = firstToken(item);
    if (!token) continue;
    const trimmed = item.trim();
    if (!token.quoted && TABLE_DEFINITION_RE.test(trimmed)) {
      let kind = null;
      if (/^constraint\s+/i.test(trimmed)) {
        if (/\bforeign\s+key\b/i.test(trimmed)) kind = 'foreignKeys';
        else if (/\bcheck\b/i.test(trimmed)) kind = 'constraints';
        else if (/\bunique\b/i.test(trimmed) || /\bprimary\s+key\b/i.test(trimmed)) kind = 'indexes';
        else kind = 'constraints';
      } else if (/^foreign\s+key\b/i.test(trimmed)) kind = 'foreignKeys';
      else if (/^check\b/i.test(trimmed)) kind = 'constraints';
      else if (/^(primary\s+key|unique|key|index|fulltext|spatial)\b/i.test(trimmed)) kind = 'indexes';
      if (kind) {
        const bucket = kind === 'indexes' ? indexes : kind === 'constraints' ? constraints : foreignKeys;
        add(bucket, tableDefinitionName(trimmed, kind));
      }
      continue;
    }

    columns.push({ name: token.name, quoted: token.quoted, ddl: trimmed });

    // 列内联约束（agent 必须以同样口径写入 evidence 的 indexes/constraints/foreignKeys）。
    const rest = token.rest;
    if (/\bprimary\s+key\b/i.test(rest)) add(indexes, null);
    else if (/\bunique\b(?!identifier)\b/i.test(rest)) add(indexes, null);
    if (/\bcheck\b/i.test(rest)) add(constraints, null);
    if (/\breferences\b/i.test(rest)) add(foreignKeys, null);
  }

  return { columns, indexes, constraints, foreignKeys };
}

// ─── rows / text table 机械抽取 ──────────────────────────────────────────────

function parseTextTable(text) {
  const lines = String(text ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => !/^[|+\-\s:]+$/.test(line));
  if (lines.length < 2) return [];
  let split;
  if (lines[0].includes('|')) {
    split = (line) => line.replace(/^\||\|$/g, '').split('|').map((cell) => cell.trim());
  } else if (lines[0].includes('\t')) {
    split = (line) => line.split('\t').map((cell) => cell.trim());
  } else if (lines[0].includes(',')) {
    split = (line) => line.split(',').map((cell) => cell.trim().replace(/^"|"$/g, ''));
  } else {
    return [];
  }
  const header = split(lines[0]);
  if (header.length === 0 || header.every((cell) => !cell)) return [];
  return lines.slice(1).map((line) => {
    const values = split(line);
    const row = {};
    header.forEach((key, index) => {
      row[key] = values[index] ?? '';
    });
    return row;
  });
}

function rowsOf(value) {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') return parseTextTable(value);
  if (isPlainObject(value)) {
    if (Object.prototype.hasOwnProperty.call(value, 'result')) {
      const nested = rowsOf(value.result);
      if (nested.length > 0) return nested;
    }
    for (const key of ['rows', 'data', 'records']) {
      if (Array.isArray(value[key])) return value[key];
    }
    return [value];
  }
  return [];
}

function nameColumnOf(rows) {
  if (rows.length === 0) return null;
  if (rows.every((row) => typeof row === 'string' || typeof row === 'number')) {
    return { column: null };
  }
  if (!rows.every(isPlainObject)) return null;
  const keys = [...new Set(rows.flatMap((row) => Object.keys(row)))];
  const usable = (key) =>
    rows.every((row) => {
      if (!Object.prototype.hasOwnProperty.call(row, key)) return false;
      const value = row[key];
      return (typeof value === 'string' && value.trim() !== '') || typeof value === 'number';
    });
  const column =
    keys.find((key) => /^(column_?name|col_?name|field_?name|field|name|attname)$/i.test(key) && usable(key)) ||
    keys.find((key) => /name/i.test(key) && usable(key)) ||
    (keys.length === 1 && usable(keys[0]) ? keys[0] : null);
  return column ? { column } : null;
}

function columnNamesFromRows(rows, dialect) {
  const resolved = nameColumnOf(rows);
  if (!resolved) return null;
  const names = rows.map((row) =>
    resolved.column == null ? String(row).trim() : String(row[resolved.column]).trim(),
  );
  if (names.some((name) => name === '')) return null;
  return names.map((name) => foldIdentifierForDialect(dialect, name, { quoted: false }));
}

// ─── evidence / raw 形状归一 ─────────────────────────────────────────────────

function evidenceColumns(entry) {
  const columns = Array.isArray(entry.columns) ? entry.columns : [];
  return columns
    .map((column) => {
      if (typeof column === 'string') return { name: column, quoted: false, ddl: null };
      if (!isPlainObject(column)) return null;
      return {
        name: String(column.name ?? '').trim(),
        quoted: column.quoted === true,
        ddl: isNonEmptyString(column.ddl) ? column.ddl : null,
      };
    })
    .filter(Boolean);
}

function evidenceDefinitions(entry, key) {
  const list = Array.isArray(entry[key]) ? entry[key] : [];
  return list.map((item) => {
    if (typeof item === 'string') return { ddl: item, name: null };
    if (!isPlainObject(item)) return { ddl: null, name: null };
    return {
      ddl: isNonEmptyString(item.ddl) ? item.ddl : null,
      name: isNonEmptyString(item.name)
        ? item.name
        : isNonEmptyString(item.constraintName)
          ? item.constraintName
          : isNonEmptyString(item.indexName)
            ? item.indexName
            : null,
    };
  });
}

function definitionName(dialect, item) {
  if (item.name) return foldIdentifierForDialect(dialect, item.name, { quoted: false });
  if (!item.ddl) return null;
  const token = firstToken(item.ddl);
  return token ? foldIdentifierForDialect(dialect, token.name, { quoted: token.quoted }) : null;
}

function reconcileCategory(dialect, rawBucket, evidenceItems, label, code) {
  const rawCount = rawBucket.count;
  const evidenceCount = evidenceItems.length;
  if (rawCount === 0 && evidenceCount === 0) {
    return { ok: true, basis: 'empty', rawCount, evidenceCount };
  }
  if (rawCount !== evidenceCount) {
    return {
      ok: false,
      code,
      details: { rawCount, evidenceCount },
      message: `${label} 数量不一致：raw=${rawCount}，evidence=${evidenceCount}`,
    };
  }
  const rawNames = rawBucket.names.map((name) =>
    name == null ? null : foldIdentifierForDialect(dialect, name, { quoted: false }),
  );
  const evidenceNames = evidenceItems.map((item) => definitionName(dialect, item));
  const namesComparable =
    rawNames.every((name) => name != null) && evidenceNames.every((name) => name != null);
  if (namesComparable) {
    const left = countBy(rawNames);
    const right = countBy(evidenceNames);
    const leftKeys = [...left.keys()].sort();
    const rightKeys = [...right.keys()].sort();
    const same =
      leftKeys.length === rightKeys.length &&
      leftKeys.every((key) => right.has(key) && left.get(key) === right.get(key));
    if (!same) {
      return {
        ok: false,
        code,
        details: { rawNames: leftKeys, evidenceNames: rightKeys },
        message: `${label} 名称不一致：raw=[${leftKeys.join(', ')}]，evidence=[${rightKeys.join(', ')}]`,
      };
    }
    return { ok: true, basis: 'name+count', rawCount, evidenceCount };
  }
  return { ok: true, basis: 'count', rawCount, evidenceCount };
}

function reconcileEntry(dialect, rawRecord, entry, failures, path) {
  const table = entry.table;
  const shape = rawRecord.expectedShape;
  let rawColumnKeys = [];
  let basis;
  const categoryBases = { indexes: [], constraints: [], foreignKeys: [] };

  if (shape === 'ddl') {
    const texts = [];
    if (typeof rawRecord.rawResult === 'string') texts.push(rawRecord.rawResult);
    else if (Array.isArray(rawRecord.rawResult)) {
      for (const value of rawRecord.rawResult) {
        if (typeof value === 'string') texts.push(value);
        else if (isPlainObject(value)) texts.push(...Object.values(value).filter((item) => typeof item === 'string'));
      }
    } else if (isPlainObject(rawRecord.rawResult)) {
      texts.push(...Object.values(rawRecord.rawResult).filter((item) => typeof item === 'string'));
    }
    texts.push(...(Array.isArray(rawRecord.rawRows) ? rawRecord.rawRows : []).filter((item) => typeof item === 'string'));
    const scanned = texts.map((text) => scanDdlStructure(text)).find((value) => value && value.columns.length > 0);
    if (!scanned) {
      failures.push(
        failure(
          FAILURE_CODES.RECONCILE_FAILED,
          path,
          `表 ${table} 的 raw DDL 无法机械解析出列定义（不得静默跳过）`,
          { table },
        ),
      );
      return { columns: 0, basis: 'ddl-unparseable' };
    }
    rawColumnKeys = scanned.columns.map((column) =>
      foldIdentifierForDialect(dialect, column.name, { quoted: column.quoted }),
    );
    basis = 'ddl';
    const categories = [
      ['indexes', scanned.indexes, 'indexes', FAILURE_CODES.RECONCILE_INDEXES, '索引'],
      ['constraints', scanned.constraints, 'constraints', FAILURE_CODES.RECONCILE_CONSTRAINTS, '约束'],
      ['foreignKeys', scanned.foreignKeys, 'foreignKeys', FAILURE_CODES.RECONCILE_FOREIGN_KEYS, '外键'],
    ];
    for (const [evidenceKey, bucket, label, code, cn] of categories) {
      const verdict = reconcileCategory(
        dialect,
        bucket,
        evidenceDefinitions(entry, evidenceKey),
        cn,
        code,
      );
      categoryBases[evidenceKey].push(verdict.basis);
      if (!verdict.ok) {
        failures.push(
          failure(verdict.code, path, `表 ${table} ${verdict.message}`, {
            table,
            details: verdict.details,
          }),
        );
      }
    }
  } else if (shape === 'columns') {
    const rows = Array.isArray(rawRecord.rawRows) && rawRecord.rawRows.length > 0
      ? rawRecord.rawRows
      : rowsOf(rawRecord.rawResult);
    const names = columnNamesFromRows(rows, dialect);
    if (!names) {
      failures.push(
        failure(
          FAILURE_CODES.RECONCILE_FAILED,
          path,
          `表 ${table} 的 raw 列结果无法机械确定列名列（需返回 column_name 或单列行集）`,
          { table },
        ),
      );
      return { columns: 0, basis: 'columns-unparseable', categoryBases };
    }
    rawColumnKeys = names;
    basis = 'columns';
  } else {
    failures.push(
      failure(FAILURE_CODES.RAW_SCHEMA, path, `表 ${table} 的 expectedShape 非法："${shape}"`, { table }),
    );
    return { columns: 0, basis: 'invalid', categoryBases };
  }

  const evidenceNames = evidenceColumns(entry).map((column) => columnKey(dialect, column));
  const left = countBy(rawColumnKeys);
  const right = countBy(evidenceNames);
  const leftKeys = [...left.keys()].sort();
  const rightKeys = [...right.keys()].sort();
  const same =
    leftKeys.length === rightKeys.length &&
    leftKeys.every((key) => right.has(key) && left.get(key) === right.get(key));
  if (!same) {
    failures.push(
      failure(
        FAILURE_CODES.RECONCILE_COLUMNS,
        path,
        `表 ${table} 列与 raw 不一致：raw=[${leftKeys.join(', ')}]，evidence=[${rightKeys.join(', ')}]`,
        {
          table,
          basis,
          rawColumns: leftKeys,
          evidenceColumns: rightKeys,
        },
      ),
    );
  }
  return { columns: rawColumnKeys.length, basis, categoryBases };
}

// ─── 主校验 ─────────────────────────────────────────────────────────────────

/**
 * @param {object} input
 * @param {object} input.inventory
 * @param {object} input.dbTableList
 * @param {object} input.raw
 * @param {object} input.evidence
 * @param {string} [input.rootDir] 用于校验 rawRef.file
 * @param {string} [input.rawPath] 实际 raw 文件路径
 * @returns {{ok:boolean, failures:object[], summary:object|null, classification:object|null, version:number}}
 */
export function validateTableStructureEvidence(input = {}) {
  const { inventory, dbTableList, raw, evidence } = input;
  const rootDir = input.rootDir ? resolve(input.rootDir) : null;
  const failures = [];
  const summary = {
    dialect: '',
    codeTables: 0,
    codeOnly: 0,
    dbOnly: 0,
    evidenceTables: 0,
    rawTables: 0,
    reconciled: { columns: 0, bases: [], indexes: [], constraints: [], foreignKeys: [] },
  };

  // ── 形状：inventory / db-table-list / raw / evidence ─────────────────────
  if (!isPlainObject(inventory)) {
    failures.push(failure(FAILURE_CODES.INVENTORY, '$inventory', 'code-table-inventory.json 不可读或不是对象'));
  } else {
    if (inventory.schemaVersion !== 2) {
      failures.push(
        failure(
          FAILURE_CODES.INVENTORY,
          '$inventory.schemaVersion',
          `schemaVersion 必须为 2（inventory v2；v1 已退役，需重跑 Agent A 产出 tables[].scope + dynamicPatterns[]；实际 ${JSON.stringify(inventory.schemaVersion)}）`,
        ),
      );
    }
    if (!Array.isArray(inventory.tables)) {
      failures.push(failure(FAILURE_CODES.INVENTORY, '$inventory.tables', 'tables 必须是数组'));
    }
  }

  const dbSources = Array.isArray(dbTableList?.sources) ? dbTableList.sources.filter(isPlainObject) : [];
  if (!isPlainObject(dbTableList)) {
    failures.push(failure(FAILURE_CODES.DB_LIST, '$dbTableList', 'db-table-list.json 不可读或不是对象'));
  } else {
    if (dbTableList.kind !== 'db-table-list') {
      failures.push(failure(FAILURE_CODES.DB_LIST, '$dbTableList.kind', 'kind 必须是 "db-table-list"'));
    }
    if (dbSources.length === 0 && !Array.isArray(dbTableList.tableNames)) {
      failures.push(failure(FAILURE_CODES.DB_LIST, '$dbTableList.tableNames', 'tableNames 必须是数组'));
    }
    if (dbSources.length === 0 && dbTableList.truncated === true) {
      failures.push(
        failure(FAILURE_CODES.DB_LIST, '$dbTableList.truncated', '表清单被截断，分类不可信'),
      );
    }
    if (
      dbSources.length === 0 &&
      Array.isArray(dbTableList.tableNames) &&
      dbTableList.tableNames.length > 0 &&
      !isNonEmptyString(dbTableList.tableNameColumn)
    ) {
      failures.push(
        failure(FAILURE_CODES.DB_LIST, '$dbTableList.tableNameColumn', '非空表清单缺 tableNameColumn'),
      );
    }
  }

  if (!isPlainObject(raw)) {
    failures.push(failure(FAILURE_CODES.RAW_MISSING, '$raw', 'table-structure.raw.json 不可读或不是对象'));
  } else {
    if (raw.kind !== 'table-structure.raw') {
      failures.push(
        failure(FAILURE_CODES.RAW_SCHEMA, '$raw.kind', `kind 必须是 "table-structure.raw"（实际 ${JSON.stringify(raw.kind)}）`),
      );
    }
    if (raw.schemaVersion !== 1) {
      failures.push(
        failure(
          FAILURE_CODES.RAW_SCHEMA,
          '$raw.schemaVersion',
          `schemaVersion 必须为 1（实际 ${JSON.stringify(raw.schemaVersion)}）`,
        ),
      );
    }
    if (!isNonEmptyString(raw.dialect)) {
      failures.push(failure(FAILURE_CODES.RAW_SCHEMA, '$raw.dialect', 'raw.dialect 必须非空'));
    }
    if (!Array.isArray(raw.tables)) {
      failures.push(failure(FAILURE_CODES.RAW_SCHEMA, '$raw.tables', 'raw.tables 必须是数组'));
    }
  }

  // ── 通道收口（Wave 1 · B §5.4 / S3）：先于任何「缺证据跳过」分支裁决 ──────────
  // 旧 local 批次即使 evidence 缺失，也要返回确定性重采入口，不能被 EVIDENCE_MISSING 盖住。
  const channelFailures = validateEvidenceChannel({ raw, dbTableList, evidence });
  failures.push(...channelFailures);
  const recovery = channelFailures.length > 0 ? { ...RECOLLECT_RECOVERY } : null;

  if (!isPlainObject(evidence)) {
    failures.push(
      failure(FAILURE_CODES.EVIDENCE_MISSING, '$evidence', 'table-structure.evidence.json 不可读或不是对象'),
    );
    return {
      ok: false,
      failures,
      summary,
      classification: null,
      failureClass: classifyFailure(failures, { summary, errorText: rawErrorTextOf(raw) }),
      recovery,
      version: GATE_VERSION,
    };
  }

  if (evidence.schemaVersion !== EVIDENCE_SCHEMA_VERSION) {
    failures.push(
      failure(
        FAILURE_CODES.SCHEMA,
        '$evidence.schemaVersion',
        `schemaVersion 必须为 ${EVIDENCE_SCHEMA_VERSION}（实际 ${JSON.stringify(evidence.schemaVersion)}）`,
      ),
    );
  }
  if (evidence.kind !== 'table-structure.evidence') {
    failures.push(
      failure(
        FAILURE_CODES.SCHEMA,
        '$evidence.kind',
        `kind 必须是 "table-structure.evidence"（实际 ${JSON.stringify(evidence.kind)}）`,
      ),
    );
  }
  if (evidence.normalization !== 'agent') {
    failures.push(
      failure(
        FAILURE_CODES.NORMALIZATION,
        '$evidence.normalization',
        `normalization 必须是 "agent"（实际 ${JSON.stringify(evidence.normalization)}）；旧 MySQL parser 不得写入生产 evidence`,
      ),
    );
  }
  const dialect = isNonEmptyString(evidence.dialect) ? canonicalDialect(evidence.dialect) : '';
  summary.dialect = dialect;
  if (!dialect) {
    failures.push(
      failure(
        FAILURE_CODES.DIALECT,
        '$evidence.dialect',
        'dialect 必须是非空字符串（不设白名单，但不得缺失）',
      ),
    );
  }
  // 方言折叠用：evidence 缺失时退回 raw / inventory catalog，只为让其它规则不被连带静默跳过。
  const foldDialect =
    dialect ||
    (isPlainObject(raw) && isNonEmptyString(raw.dialect) ? canonicalDialect(raw.dialect) : '') ||
    (isPlainObject(inventory) && isPlainObject(inventory.catalog) && isNonEmptyString(inventory.catalog.dialect)
      ? canonicalDialect(inventory.catalog.dialect)
      : '');

  if (!Array.isArray(evidence.tables)) {
    failures.push(failure(FAILURE_CODES.SCHEMA, '$evidence.tables', 'tables 必须是数组'));
    return {
      ok: false,
      failures,
      summary,
      classification: null,
      failureClass: classifyFailure(failures, { summary, errorText: rawErrorTextOf(raw) }),
      recovery,
      version: GATE_VERSION,
    };
  }

  // ── 多数据源作用域：门 B 一次只裁决一个 dataSourceName ─────────────────────
  // 身份 = (dataSourceName, 折叠表名)；跨源同名表必须各自成对，禁止合并去重。
  const bindingName = isNonEmptyString(input.dataSourceName) ? input.dataSourceName.trim() : '';
  const inventoryTablesAll = Array.isArray(inventory?.tables) ? inventory.tables : [];
  const rawTablesAll = Array.isArray(raw?.tables) ? raw.tables : [];
  const evidenceTablesAll = evidence.tables;
  const recordTags = new Set(
    [...inventoryTablesAll, ...rawTablesAll, ...evidenceTablesAll]
      .map(sourceTagOf)
      .filter(Boolean),
  );
  const multiSource = dbSources.length > 1 || recordTags.size > 1;
  if (multiSource && !bindingName) {
    failures.push(
      failure(
        FAILURE_CODES.DATASOURCE,
        '$evidence',
        '多数据源聚合产物必须用 --data-source-name 逐源校验（不得跨源合并判等）',
      ),
    );
    return {
      ok: false,
      failures,
      summary,
      classification: null,
      failureClass: classifyFailure(failures, { summary, errorText: rawErrorTextOf(raw) }),
      recovery,
      version: GATE_VERSION,
    };
  }
  const dbSourceEntry = dbSources.length > 0
    ? bindingName
      ? dbSources.find((entry) => sourceTagOf(entry) === bindingName)
      : dbSources[0]
    : null;
  if (dbSources.length > 0 && bindingName && !dbSourceEntry) {
    failures.push(
      failure(
        FAILURE_CODES.DATASOURCE,
        '$dbTableList.sources',
        `db-table-list 缺少 dataSourceName=${bindingName} 的来源（逐源 preflight 必须齐全）`,
      ),
    );
  }
  if (dbSourceEntry && dbSourceEntry.catalogComplete !== true) {
    failures.push(
      failure(
        FAILURE_CODES.DB_LIST,
        '$dbTableList.sources.catalogComplete',
        `数据源 ${bindingName || sourceTagOf(dbSourceEntry) || '<unknown>'} 目录不完整（catalogComplete!==true）：不得把首屏当完整目录`,
      ),
    );
  }
  if (dbSourceEntry && dbSourceEntry.truncated === true) {
    failures.push(
      failure(FAILURE_CODES.DB_LIST, '$dbTableList.sources.truncated', '逐源表清单被截断，分类不可信'),
    );
  }

  const belongsToScope = (item) => {
    const tag = sourceTagOf(item);
    if (!tag) return true;
    return !bindingName || tag === bindingName;
  };
  const scopedInventoryTables = inventoryTablesAll.filter((entry) => {
    // inventory v2：external 是「具体表、无绑定连接」，不属于任何已确认绑定，
    // 不参与门 B 的逐源判等/覆盖（它永不进 delta，也不需要结构证据）。
    if (isPlainObject(entry) && entry.scope === 'external') return false;
    if (!belongsToScope(entry)) return false;
    if (multiSource && isPlainObject(entry) && !sourceTagOf(entry)) {
      failures.push(
        failure(
          FAILURE_CODES.DATASOURCE,
          '$inventory.tables',
          'inventory 条目缺 dataSourceName：多数据源下不得无归属判等',
        ),
      );
    }
    return true;
  });

  // raw 过滤时保留「原索引 -> 作用域索引」映射，供 evidence.rawRef.index 重定位。
  const rawTables = [];
  const originalToScoped = new Map();
  rawTablesAll.forEach((record, index) => {
    if (!belongsToScope(record)) return;
    if (multiSource && isPlainObject(record) && !sourceTagOf(record)) {
      failures.push(
        failure(
          FAILURE_CODES.DATASOURCE,
          `$raw.tables[${index}]`,
          'raw 记录缺 dataSourceName：多数据源下不得无归属判等',
        ),
      );
    }
    originalToScoped.set(index, rawTables.length);
    rawTables.push(record);
  });
  const evidenceTables = [];
  for (const entry of evidenceTablesAll) {
    if (!belongsToScope(entry)) continue;
    if (multiSource && isPlainObject(entry) && !sourceTagOf(entry)) {
      failures.push(
        failure(
          FAILURE_CODES.DATASOURCE,
          '$evidence.tables',
          'evidence 条目缺 dataSourceName：多数据源下不得无归属判等',
        ),
      );
    }
    let copy = entry;
    if (isPlainObject(entry) && isPlainObject(entry.rawRef) && entry.rawRef.index !== undefined && entry.rawRef.index !== null) {
      const mapped = originalToScoped.get(Number(entry.rawRef.index));
      if (mapped !== undefined) copy = { ...entry, rawRef: { ...entry.rawRef, index: mapped } };
    }
    evidenceTables.push(copy);
  }
  const evidenceSource = Array.isArray(evidence.sources) && evidence.sources.length > 0
    ? (bindingName
      ? evidence.sources.find((entry) => sourceTagOf(entry) === bindingName)
      : evidence.sources[0])
    : evidence.source;

  // ── 真值判据（D4）：只在外层传入 binding/manifest 时启用，不破坏既有单测/调用方 ──
  // 禁止用 canonicalDialect 折叠后再比：`mysql8` 会折成 `mysql`，照抄示例值就漏判。
  const bindingNameForTruth =
    bindingName || sourceTagOf(evidenceSource) || (Array.isArray(evidence.sources) && evidence.sources.length === 1
      ? sourceTagOf(evidence.sources[0])
      : '');
  const bindingEntry = selectBindingEntry(input.binding, bindingNameForTruth);
  if (bindingEntry && isNonEmptyString(bindingEntry.databaseType) && isNonEmptyString(evidence.dialect)) {
    const expectedDialect = bindingEntry.databaseType.trim();
    const actualDialect = evidence.dialect.trim();
    if (actualDialect.toLowerCase() !== expectedDialect.toLowerCase()) {
      failures.push(
        failure(
          FAILURE_CODES.EVIDENCE_DIALECT,
          '$evidence.dialect',
          `evidence.dialect="${actualDialect}" 与 datasource-binding databaseType="${expectedDialect}" 不一致` +
            '（真值判据；禁止照抄示例值 mysql）',
          { expected: expectedDialect, actual: actualDialect },
        ),
      );
    }
  }

  const manifestEntry = selectManifestEntry(input.manifest, bindingNameForTruth);
  if (isPlainObject(input.manifest)) {
    if (!manifestEntry && bindingNameForTruth) {
      failures.push(
        failure(
          FAILURE_CODES.EVIDENCE_DATABASE,
          '$evidence.source.database',
          `.manifest/datasources.json 缺少 dataSourceName=${bindingNameForTruth} 的契约条目（平台数据源条目缺失）`,
          { kind: 'blocked', dataSourceName: bindingNameForTruth },
        ),
      );
    } else if (manifestEntry) {
      const config = isPlainObject(manifestEntry.config) ? manifestEntry.config : {};
      const expectedDatabase = isNonEmptyString(config.database) ? config.database.trim() : '';
      // Oracle/达梦用 connectionTarget，没有 config.database 时不做目标库真值判据。
      if (expectedDatabase) {
        const actualDatabase = isNonEmptyString(evidenceSource?.database)
          ? evidenceSource.database.trim()
          : '';
        if (actualDatabase !== expectedDatabase) {
          failures.push(
            failure(
              FAILURE_CODES.EVIDENCE_DATABASE,
              '$evidence.source.database',
              `evidence.source.database=${JSON.stringify(actualDatabase || null)} 与 ` +
                `.manifest/datasources.json#${bindingNameForTruth || '<source>'}.config.database="${expectedDatabase}" 不一致` +
                '（真值判据；禁止照抄示例值 app_db）',
              { expected: expectedDatabase, actual: actualDatabase || null },
            ),
          );
        }
      }
    }
  }

  // ── 分类：codeTables / codeOnly / dbOnly ─────────────────────────────────
  const candidates = [];
  for (const [index, entry] of scopedInventoryTables.entries()) {
    if (!isPlainObject(entry) || !isNonEmptyString(entry.table)) {
      failures.push(
        failure(FAILURE_CODES.INVENTORY, `$inventory.tables[${index}]`, '表条目缺非空 table'),
      );
      continue;
    }
    candidates.push({ table: entry.table.trim(), entry });
  }
  const dbNames = Array.isArray(dbSourceEntry?.tableNames)
    ? dbSourceEntry.tableNames.filter(isNonEmptyString).map((name) => name.trim())
    : Array.isArray(dbTableList?.tableNames)
      ? dbTableList.tableNames.filter(isNonEmptyString).map((name) => name.trim())
      : [];
  const catalogComplete = dbSourceEntry
    ? dbSourceEntry.catalogComplete === true
    : dbTableList?.catalogComplete !== false;
  const catalogTruncated = dbSourceEntry ? dbSourceEntry.truncated === true : dbTableList?.truncated === true;
  const dbKeys = new Set(dbNames.map((name) => tableKey(foldDialect, name)));
  const candidateKeys = new Set(candidates.map((candidate) => tableKey(foldDialect, candidate.table)));
  const codeTables = candidates.filter((candidate) => dbKeys.has(tableKey(foldDialect, candidate.table)));
  const codeOnly = candidates.filter((candidate) => !dbKeys.has(tableKey(foldDialect, candidate.table)));
  const dbOnly = dbNames.filter((name) => !candidateKeys.has(tableKey(foldDialect, name)));
  const classification = {
    codeTables: codeTables.map((candidate) => candidate.table),
    codeOnly: codeOnly.map((candidate) => ({
      table: candidate.table,
      decision: candidate.entry.decision ?? null,
      reason: candidate.entry.reason ?? null,
      dataSourceName: candidate.entry.dataSourceName ?? null,
    })),
    dbOnly,
  };
  summary.codeTables = classification.codeTables.length;
  summary.codeOnly = classification.codeOnly.length;
  summary.dbOnly = classification.dbOnly.length;
  // 零存量结构：该源确认没有 code table 且目录完整/未截断时，空 inventory/raw 合法。
  const zeroStock = codeTables.length === 0 && catalogComplete && !catalogTruncated;
  if (scopedInventoryTables.length === 0 && !zeroStock) {
    failures.push(
      failure(FAILURE_CODES.INVENTORY, '$inventory.tables', 'tables 为空（门 A 不得以空集放行）'),
    );
  }

  // 规则 2：dbOnly 必须在 db-table-list 中存在（inventory 若已带 dbOnly 摘要则逐条核对）。
  const declaredDbOnly = Array.isArray(inventory?.dbOnly)
    ? inventory.dbOnly
    : Array.isArray(inventory?.completeness?.dbOnly)
      ? inventory.completeness.dbOnly
      : [];
  for (const item of declaredDbOnly) {
    const name = typeof item === 'string' ? item : item?.table;
    if (!isNonEmptyString(name)) continue;
    if (!dbKeys.has(tableKey(foldDialect, name))) {
      failures.push(
        failure(
          FAILURE_CODES.DB_ONLY_MISSING,
          '$inventory.dbOnly',
          `dbOnly 表 "${name}" 不在 db-table-list.json 中`,
          { table: name },
        ),
      );
    }
  }

  // raw 索引：folded table -> [{record,index}]
  summary.rawTables = rawTables.length;
  if (rawTables.length === 0 && !zeroStock) {
    failures.push(failure(FAILURE_CODES.RAW_EMPTY, '$raw.tables', 'raw.tables 为空（不得作为证据）'));
  }
  const rawIndex = new Map();
  for (const [index, record] of rawTables.entries()) {
    if (!isPlainObject(record) || !isNonEmptyString(record.table)) {
      failures.push(failure(FAILURE_CODES.RAW_SCHEMA, `$raw.tables[${index}]`, 'raw 表条目缺非空 table'));
      continue;
    }
    const key = tableKey(foldDialect, record.table);
    if (!rawIndex.has(key)) rawIndex.set(key, []);
    rawIndex.get(key).push({ record, index });
  }
  for (const [key, records] of rawIndex.entries()) {
    if (records.length > 1) {
      failures.push(
        failure(
          FAILURE_CODES.RAWREF_AMBIGUOUS,
          '$raw.tables',
          `raw 中同一张表出现 ${records.length} 次（folded="${key}"），rawRef 无法唯一命中`,
          { table: records[0].record.table, indexes: records.map((item) => item.index) },
        ),
      );
    }
  }

  // ── 规则 1 / 3 / 4 / 5 / 7：逐条 evidence ────────────────────────────────
  if (evidenceTables.some((entry) => !isPlainObject(entry))) {
    failures.push(failure(FAILURE_CODES.SCHEMA, '$evidence.tables', 'tables 中存在非对象条目'));
  }
  summary.evidenceTables = evidenceTables.length;

  const evidenceIndex = new Map();
  for (const [index, entry] of evidenceTables.entries()) {
    if (!isPlainObject(entry)) continue;
    if (!isNonEmptyString(entry.table)) {
      failures.push(
        failure(FAILURE_CODES.TABLE_NAME, `$evidence.tables[${index}].table`, '表条目缺非空 table'),
      );
      continue;
    }
    const rawName = entry.table.trim();
    if (/[."]/.test(rawName) && !/[`[]/.test(rawName)) {
      failures.push(
        failure(
          FAILURE_CODES.TABLE_NAME,
          `$evidence.tables[${index}].table`,
          `表名 "${rawName}" 不得包含 schema/owner 前缀；请用 owner 字段（§5.7）`,
          { table: rawName },
        ),
      );
    }
    const key = tableKey(foldDialect, rawName);
    if (!evidenceIndex.has(key)) evidenceIndex.set(key, []);
    evidenceIndex.get(key).push({ entry, index });
  }

  for (const [key, entries] of evidenceIndex.entries()) {
    if (entries.length > 1) {
      failures.push(
        failure(
          FAILURE_CODES.COVERAGE_DUPLICATE,
          '$evidence.tables',
          `codeTable "${entries[0].entry.table}" 有 ${entries.length} 条 evidence（有且仅有一条）`,
          { table: entries[0].entry.table, indexes: entries.map((item) => item.index) },
        ),
      );
    }
  }

  const codeTableKeys = new Set(classification.codeTables.map((name) => tableKey(foldDialect, name)));
  const codeOnlyKeys = new Set(classification.codeOnly.map((item) => tableKey(foldDialect, item.table)));

  for (const [key, entries] of evidenceIndex.entries()) {
    const entry = entries[0].entry;
    const path = `$evidence.tables["${entry.table}"]`;
    if (!codeTableKeys.has(key)) {
      if (codeOnlyKeys.has(key)) {
        failures.push(
          failure(
            FAILURE_CODES.EVIDENCE_UNEXPECTED,
            path,
            `表 "${entry.table}" 是 codeOnly（库中不存在，decision=${entry.decision ?? '未声明'}），不应采集结构`,
            { table: entry.table },
          ),
        );
      } else {
        failures.push(
          failure(
            FAILURE_CODES.EVIDENCE_UNEXPECTED,
            path,
            `表 "${entry.table}" 不是 codeTable（不在 inventory ∩ db-table-list 中）`,
            { table: entry.table },
          ),
        );
      }
    }

    // 规则 5：code table columns 非空（形状首先必须合法）。
    const columns = Array.isArray(entry.columns) ? entry.columns : null;
    if (columns == null) {
      failures.push(failure(FAILURE_CODES.SCHEMA, `${path}.columns`, 'columns 必须是数组'));
    } else if (columns.length === 0) {
      failures.push(
        failure(FAILURE_CODES.COLUMNS_EMPTY, `${path}.columns`, `表 "${entry.table}" columns 为空（不得以空结构放行）`, {
          table: entry.table,
        }),
      );
    }

    // 规则 7：逐表 normalization（根级已校验；逐表若声明必须同样是 agent）。
    if (entry.normalization !== undefined && entry.normalization !== 'agent') {
      failures.push(
        failure(
          FAILURE_CODES.NORMALIZATION,
          `${path}.normalization`,
          `逐表 normalization 必须是 "agent"（实际 ${JSON.stringify(entry.normalization)}）`,
          { table: entry.table },
        ),
      );
    }

    // 规则 3：rawRef 必填且命中。
    const rawRef = entry.rawRef;
    if (!isPlainObject(rawRef)) {
      failures.push(
        failure(FAILURE_CODES.RAWREF_MISSING, `${path}.rawRef`, `表 "${entry.table}" 缺 rawRef provenance`, {
          table: entry.table,
        }),
      );
      continue;
    }
    if (!isNonEmptyString(rawRef.file)) {
      failures.push(
        failure(FAILURE_CODES.RAWREF_INVALID, `${path}.rawRef.file`, 'rawRef.file 必须非空', { table: entry.table }),
      );
    } else if (rootDir) {
      const expected = input.rawPath ? resolve(input.rawPath) : resolve(rootDir, RAW_REL);
      const declared = rawRef.file.startsWith('/') ? resolve(rawRef.file) : resolve(rootDir, rawRef.file);
      if (declared !== expected && basename(rawRef.file) !== basename(expected)) {
        failures.push(
          failure(
            FAILURE_CODES.RAWREF_INVALID,
            `${path}.rawRef.file`,
            `rawRef.file 未指向 runner 的 table-structure.raw.json（声明 ${rawRef.file}）`,
            { table: entry.table },
          ),
        );
      }
    }
    if (!isNonEmptyString(rawRef.table)) {
      failures.push(
        failure(FAILURE_CODES.RAWREF_INVALID, `${path}.rawRef.table`, 'rawRef.table 必须非空', {
          table: entry.table,
        }),
      );
    }
    const refKey = isNonEmptyString(rawRef.table) ? tableKey(foldDialect, rawRef.table) : key;
    const hits = rawIndex.get(refKey) || [];
    let hit = null;
    if (rawRef.index !== undefined && rawRef.index !== null) {
      const index = Number(rawRef.index);
      if (!Number.isInteger(index) || index < 0) {
        failures.push(
          failure(FAILURE_CODES.RAWREF_INVALID, `${path}.rawRef.index`, 'rawRef.index 必须是非负整数', {
            table: entry.table,
          }),
        );
      } else {
        hit = hits.find((candidate) => candidate.index === index) || null;
        if (!hit) {
          failures.push(
            failure(
              FAILURE_CODES.RAWREF_UNMATCHED,
              `${path}.rawRef.index`,
              `rawRef.index=${index} 未命中 raw 记录（表 "${rawRef.table}"）`,
              { table: entry.table },
            ),
          );
        }
      }
    } else if (hits.length === 1) {
      hit = hits[0];
    } else if (hits.length === 0) {
      failures.push(
        failure(
          FAILURE_CODES.RAWREF_UNMATCHED,
          `${path}.rawRef.table`,
          `rawRef 表 "${rawRef.table}" 未命中 raw 记录`,
          { table: entry.table },
        ),
      );
    } else {
      failures.push(
        failure(
          FAILURE_CODES.RAWREF_AMBIGUOUS,
          `${path}.rawRef`,
          `rawRef 表 "${rawRef.table}" 命中 ${hits.length} 条 raw 记录；需用 index 消歧`,
          { table: entry.table, indexes: hits.map((item) => item.index) },
        ),
      );
    }

    if (!hit) continue;
    const record = hit.record;
    const rawPath = `$raw.tables[${hit.index}]`;

    if (!isNonEmptyString(record.usedSql)) {
      failures.push(failure(FAILURE_CODES.RAW_SCHEMA, `${rawPath}.usedSql`, 'raw 记录缺 usedSql', { table: entry.table }));
    } else if (isNonEmptyString(rawRef.usedSqlSha256)) {
      const actual = sha256(record.usedSql);
      if (actual !== String(rawRef.usedSqlSha256).toLowerCase()) {
        failures.push(
          failure(
            FAILURE_CODES.RAWREF_SQL_MISMATCH,
            `${path}.rawRef.usedSqlSha256`,
            `usedSqlSha256 与 raw 记录不一致（raw=${actual}）`,
            { table: entry.table },
          ),
        );
      }
    }
    const declaredDigest = rawRef.rawResultDigest ?? rawRef.rawResultSha256;
    if (isNonEmptyString(declaredDigest)) {
      const actual = sha256(stableStringify(record.rawResult));
      if (actual !== String(declaredDigest).toLowerCase()) {
        failures.push(
          failure(
            FAILURE_CODES.RAWREF_RESULT_MISMATCH,
            `${path}.rawRef.rawResultDigest`,
            `rawResultDigest 与 raw 记录不一致（raw=${actual}）`,
            { table: entry.table },
          ),
        );
      }
    }

    const rawRows = Array.isArray(record.rawRows) ? record.rawRows : null;
    const hasRows = rawRows != null && rawRows.length > 0;
    const rawResultEmpty =
      !hasRows &&
      (record.rawResult == null ||
        (typeof record.rawResult === 'string' && record.rawResult.trim() === '') ||
        (Array.isArray(record.rawResult) && record.rawResult.length === 0) ||
        (isPlainObject(record.rawResult) && Object.keys(record.rawResult).length === 0));
    if (rawResultEmpty) {
      failures.push(
        failure(FAILURE_CODES.RAW_EMPTY, rawPath, `表 "${entry.table}" raw result 为空（不得作为证据）`, {
          table: entry.table,
        }),
      );
    }
    if (record.truncated === true) {
      failures.push(
        failure(FAILURE_CODES.RAW_TRUNCATED, rawPath, `表 "${entry.table}" raw result 被截断`, {
          table: entry.table,
          truncatedFields: record.truncatedFields ?? [],
        }),
      );
    }
    if (Array.isArray(record.parseIssues) && record.parseIssues.length > 0) {
      failures.push(
        failure(
          FAILURE_CODES.RAW_PARSE_ISSUES,
          `${rawPath}.parseIssues`,
          `表 "${entry.table}" raw parseIssues 非空：${record.parseIssues.join('; ')}`,
          { table: entry.table },
        ),
      );
    }
    if (Array.isArray(entry.parseIssues) && entry.parseIssues.length > 0) {
      failures.push(
        failure(
          FAILURE_CODES.RAW_PARSE_ISSUES,
          `${path}.parseIssues`,
          `表 "${entry.table}" evidence parseIssues 非空：${entry.parseIssues.join('; ')}`,
          { table: entry.table },
        ),
      );
    }

    // 规则 4：与 raw 对账。
    if (!rawResultEmpty && record.truncated !== true) {
      const outcome = reconcileEntry(foldDialect, record, entry, failures, path);
      summary.reconciled.columns += outcome.columns;
      if (!summary.reconciled.bases.includes(outcome.basis)) summary.reconciled.bases.push(outcome.basis);
      for (const key of ['indexes', 'constraints', 'foreignKeys']) {
        for (const basisValue of outcome.categoryBases?.[key] || []) {
          if (!summary.reconciled[key].includes(basisValue)) summary.reconciled[key].push(basisValue);
        }
      }
    }
  }

  // 规则 1：codeTable 覆盖（缺失 = 红）。
  for (const table of classification.codeTables) {
    const key = tableKey(foldDialect, table);
    if (!evidenceIndex.has(key)) {
      failures.push(
        failure(FAILURE_CODES.COVERAGE_MISSING, '$evidence.tables', `codeTable "${table}" 没有 evidence`, {
          table,
        }),
      );
    }
  }

  // owner/schema：D7 多值 fail-loud；逐表必须与声明 owner 一致。
  const declaredOwners = [];
  if (isPlainObject(evidenceSource)) {
    if (Array.isArray(evidenceSource.owners)) declaredOwners.push(...evidenceSource.owners);
    if (isNonEmptyString(evidenceSource.owner)) declaredOwners.push(evidenceSource.owner);
    if (isNonEmptyString(evidenceSource.schema)) declaredOwners.push(evidenceSource.schema);
  }
  for (const entries of evidenceIndex.values()) {
    const entry = entries[0].entry;
    if (isNonEmptyString(entry.owner)) declaredOwners.push(entry.owner);
    if (isNonEmptyString(entry.schema)) declaredOwners.push(entry.schema);
  }
  const ownerVerdict = assertSingleOwner(foldDialect, declaredOwners);
  if (!ownerVerdict.ok) {
    failures.push(
      failure(FAILURE_CODES.MULTI_OWNER, '$evidence', ownerVerdict.reason, {
        owners: ownerVerdict.owners,
      }),
    );
  } else if (ownerVerdict.owner != null) {
    const expected = foldIdentifierForDialect(foldDialect, ownerVerdict.owner);
    for (const entries of evidenceIndex.values()) {
      const entry = entries[0].entry;
      const actual = isNonEmptyString(entry.owner) ? entry.owner : entry.schema;
      if (isNonEmptyString(actual) && foldIdentifierForDialect(foldDialect, actual) !== expected) {
        failures.push(
          failure(
            FAILURE_CODES.OWNER,
            `$evidence.tables["${entry.table}"].owner`,
            `表 "${entry.table}" owner="${actual}" 与声明 owner="${ownerVerdict.owner}" 不一致`,
            { table: entry.table },
          ),
        );
      }
    }
  }

  // summary 去重（bases 按出现顺序）。
  summary.reconciled.bases = [...new Set(summary.reconciled.bases)];

  // 库真空判据只认「当前裁决源」的真实表数：summary 只能推出 codeTables+dbOnly，
  // 库清单为空时会把 codeTables 误当成库表数（库 0 张表必须判 0）。
  const scopedDbTableCount = dbTableCountOf(dbTableList, bindingName);

  return {
    ok: failures.length === 0,
    failures,
    summary,
    classification,
    failureClass: classifyFailure(failures, {
      summary,
      errorText: rawErrorTextOf(raw),
      dbTableCount: scopedDbTableCount,
    }),
    recovery,
    version: GATE_VERSION,
  };
}

// ─── CLI ────────────────────────────────────────────────────────────────────

function parseArgv(argv) {
  const args = {
    root: null,
    inventory: null,
    dbTableList: null,
    raw: null,
    evidence: null,
    binding: null,
    manifest: null,
    help: false,
  };
  const start = argv[2] === 'check' ? 3 : 2;
  for (let index = start; index < argv.length; index += 1) {
    const arg = argv[index];
    const next = () => argv[++index];
    if (arg === '--help' || arg === '-h') args.help = true;
    else if (arg === '--root') args.root = next();
    else if (arg === '--inventory') args.inventory = next();
    else if (arg === '--db-table-list') args.dbTableList = next();
    else if (arg === '--raw') args.raw = next();
    else if (arg === '--evidence') args.evidence = next();
    else if (arg === '--binding') args.binding = next();
    else if (arg === '--manifest') args.manifest = next();
    else if (arg === '--data-source-name') args.dataSourceName = next();
    else throw new Error(`未知参数：${arg}`);
  }
  return args;
}

function usage() {
  return [
    '用法: node check-table-structure-evidence.mjs [check] [--root <dir>]',
    '  [--inventory <path>] [--db-table-list <path>] [--raw <path>] [--evidence <path>]',
    '  [--binding <path>] [--manifest <path>] [--data-source-name <name>]',
    '  （--binding/--manifest 启用 evidence.dialect/database 真值判据；多数据源必须逐源校验）',
    '路径缺省为 <root>/plans/backend/_meta/{code-table-inventory,db-table-list,',
    'table-structure.raw,table-structure.evidence}.json',
  ].join('\n');
}

function readJsonOptional(filePath) {
  if (!existsSync(filePath)) return { ok: false, error: `文件不存在：${filePath}` };
  try {
    return { ok: true, value: JSON.parse(readFileSync(filePath, 'utf-8')) };
  } catch (error) {
    return { ok: false, error: `JSON 解析失败：${(error && error.message) || error}` };
  }
}

export function runCli(argv = process.argv) {
  const args = parseArgv(argv);
  if (args.help) {
    process.stdout.write(`${usage()}\n`);
    return 0;
  }
  const root = args.root ? resolve(args.root) : process.cwd();
  const inventoryPath = args.inventory ? resolve(args.inventory) : resolve(root, INVENTORY_REL);
  const dbTableListPath = args.dbTableList ? resolve(args.dbTableList) : resolve(root, DB_TABLE_LIST_REL);
  const rawPath = args.raw ? resolve(args.raw) : resolve(root, RAW_REL);
  const evidencePath = args.evidence ? resolve(args.evidence) : resolve(root, EVIDENCE_REL);

  const loaded = {
    inventory: readJsonOptional(inventoryPath),
    dbTableList: readJsonOptional(dbTableListPath),
    raw: readJsonOptional(rawPath),
    evidence: readJsonOptional(evidencePath),
  };
  // binding/manifest 是可选真值输入：只在外层显式给出时启用，缺文件不另判红。
  const binding = args.binding
    ? readJsonOptional(resolve(args.binding))
    : { ok: false, skipped: true };
  const manifest = args.manifest
    ? readJsonOptional(resolve(args.manifest))
    : { ok: false, skipped: true };
  if (!loaded.evidence.ok) {
    // 证据文件缺失也要先裁决通道：旧 local 批次必须拿到 P4 重采入口，不能被 EVIDENCE_MISSING 盖住。
    const channelFailures = validateEvidenceChannel({
      raw: loaded.raw.ok ? loaded.raw.value : undefined,
      dbTableList: loaded.dbTableList.ok ? loaded.dbTableList.value : undefined,
      evidence: undefined,
    });
    const failures = [
      ...channelFailures,
      failure(FAILURE_CODES.EVIDENCE_MISSING, '$evidence', loaded.evidence.error),
    ];
    const payload = {
      ok: false,
      failures,
      classification: null,
      failureClass: classifyFailure(failures, {}),
      recovery: channelFailures.length > 0 ? { ...RECOLLECT_RECOVERY } : null,
      summary: null,
      version: GATE_VERSION,
    };
    process.stdout.write(`${JSON.stringify(payload)}\n`);
    return 1;
  }

  const verdict = validateTableStructureEvidence({
    inventory: loaded.inventory.ok ? loaded.inventory.value : undefined,
    dbTableList: loaded.dbTableList.ok ? loaded.dbTableList.value : undefined,
    raw: loaded.raw.ok ? loaded.raw.value : undefined,
    evidence: loaded.evidence.value,
    binding: binding.ok ? binding.value : undefined,
    manifest: manifest.ok ? manifest.value : undefined,
    rootDir: root,
    rawPath,
    dataSourceName: args.dataSourceName || '',
  });
  const payload = { ...verdict };
  if (!loaded.inventory.ok) {
    payload.failures.unshift(failure(FAILURE_CODES.INVENTORY, '$inventory', loaded.inventory.error));
  }
  if (!loaded.dbTableList.ok) {
    payload.failures.unshift(failure(FAILURE_CODES.DB_LIST, '$dbTableList', loaded.dbTableList.error));
  }
  if (!loaded.raw.ok) {
    payload.failures.unshift(failure(FAILURE_CODES.RAW_MISSING, '$raw', loaded.raw.error));
  }
  payload.ok = payload.failures.length === 0;
  // 文件读取失败是 unshift 进来的，failureClass 必须按最终 failures 重算。
  payload.failureClass = classifyFailure(payload.failures, {
    summary: payload.summary,
    errorText: rawErrorTextOf(loaded.raw.ok ? loaded.raw.value : undefined),
    dbTableCount: dbTableCountOf(
      loaded.dbTableList.ok ? loaded.dbTableList.value : undefined,
      args.dataSourceName || '',
    ),
  });
  process.stdout.write(`${JSON.stringify(payload)}\n`);
  return payload.ok ? 0 : 1;
}

const isMain = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    process.exit(runCli());
  } catch (error) {
    process.stdout.write(
      `${JSON.stringify({
        ok: false,
        failures: [failure(FAILURE_CODES.USAGE, '$', (error && error.message) || String(error))],
        classification: null,
        summary: null,
        recovery: null,
        version: GATE_VERSION,
      })}\n`,
    );
    process.exit(1);
  }
}
