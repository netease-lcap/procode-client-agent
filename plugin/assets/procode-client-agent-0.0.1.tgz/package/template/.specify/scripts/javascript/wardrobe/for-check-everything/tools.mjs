import {
  readStatusSync,
  getStartsByCores,
  readWarehouseFileSync,
} from '../../shared/index.mjs';

import phases from '../../output/phases.json' with { type: 'json' };

export const combine = (...list) => list.join('\n');

export const isPathOrQuote = (source = '') => {
  source = source.trim();

  const root = '(?:inputs|[^/]+/docs/[^/]+)';
  const regForPath = new RegExp(`^[\\/a-zA-Z0-9\\-]*${root}[^\\[\\]\\(\\)]+\\.md$`);
  const regForQuote = new RegExp(`^\\[[^\\[\\]\\(\\)]+\\]\\(${root}[^\\[\\]\\(\\)]+\\.md\\)$`);

  const matchedForPath = regForPath.test(source);
  const matchedForQuote = regForQuote.test(source);

  return matchedForPath || matchedForQuote;
};

export const startsByCores = ((rootDir) => {
  rootDir = rootDir || process.cwd();

  return getStartsByCores(rootDir);
})();

export const filterForPhase =
  (rootDir) =>
  (item = '') => {
    const status = readStatusSync(rootDir) || {};
    const keys = Object.keys(status);

    const filter = (key) => status?.[key]?.status !== 'done';
    const filtered = keys.filter(filter);

    const final = filtered.length ? filtered : keys;
    const set = new Set(final);

    const folders = phases.filter((item) => set.has(item.command)).map((item) => item.folder || item.command);

    return folders.some((folder) => item.startsWith(`${folder}/`));
  };

export const filter = (item) => {
  const isFile = item?.endsWith?.('.md');
  const isPlans = item?.includes?.('plans/');
  const isTemp = item?.includes?.('/temp-');
  const isTerms = item?.includes?.('terms-');
  const isStandard = item?.includes?.('specs/');
  const isChecklist = item?.includes?.('specs/checklist-');
  const isRequirementMenus = item?.endsWith?.('specs/menus.md');

  const isUIDesign = item?.includes?.('ui-design.md');

  const isWarehouse = readWarehouseFileSync(item);
  const isChangelogs = item?.includes?.('.changelogs');

  if (!isFile) {
    return;
  }

  if (isChangelogs) {
    return;
  }

  if (isTemp || isWarehouse) {
    return;
  }

  if (!filterForPhase()(item)) {
    return;
  }

  if (isUIDesign) {
    return;
  }

  return isPlans || isStandard || isTerms || isChecklist || isRequirementMenus;
};
