import { handle } from './tools.mjs';

import check from '../check-everything.mjs';

handle(check);
