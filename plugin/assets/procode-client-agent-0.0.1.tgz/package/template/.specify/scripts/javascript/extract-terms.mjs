import fs from 'fs';
import path from 'path';

import {
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  parse,
  parseToTable,
  writeToFileSync,
  formatWritedFiles,
  auto,
} from './shared/index.mjs';

export const filterTermsModule = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/terms-module-');

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const activeSpecDir = getActiveSpecDir();
  const termsAbsoluteFilePath = `${activeSpecDir}/specs/terms.md`;

  const options = { rootDir };
  const parseTable = parseToTable(options);
  const termsModuleBundles = filterUnderSpecs(rootDir)(filterTermsModule);

  const map = (bundle = {}) => {
    const { absoluteFilePath } = bundle;

    const content = readFileSync(absoluteFilePath);
    const parsed = parseTable(content);

    return parsed;
  };

  const array = termsModuleBundles.map(map).flat();

  const body = (() => {
    const store = {};

    array.forEach((item = []) => {
      const [cn = '', en = '', descritpion = ''] = item;

      const key = `${cn}@${en}`;
      const got = [store[key], descritpion];

      store[key] = store[key] || '';
      store[key] = got.filter(Boolean).join(' ');
    });

    const entries = Object.entries(store);
    const got = entries.map((entry) => {
      const [key = '', value = ''] = entry;

      const splitted = key.split('@') || [];

      return [...splitted, value];
    });

    return got.map((item) => item.join(' | ')).map((item) => `| ${item} |`);
  })();

  const table = ['| 中文名称 | 英文名称 | 解释说明 |', '|---------|---------|---------|', ...body];

  const parts = [
    '# 术语表',
    '',
    '## 业务术语表',
    '',
    table.join('\n'),
  ];

  const result = writeToFileSync('术语表', termsAbsoluteFilePath)(parts);

  return `创建${result}成功`;
};

auto(import.meta)(toRaw);

export default toRaw;
