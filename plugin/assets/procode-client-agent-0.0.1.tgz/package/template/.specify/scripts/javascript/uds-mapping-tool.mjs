globalThis.__SPECKIT_BAKED_MAPPING_REFS__ = [{"file":"datasources.json","list":"$.dataSources","host":"$.config.host","port":"$.config.port"},{"file":"middlewares.json","extractor":"middleware-endpoints"}];
/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/cli.mts
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/commands.ts
import path3 from "node:path";
import { createLogger } from "./shared/logger.mjs";

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/aggregate.ts
import fs2 from "node:fs";
import path2 from "node:path";

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/mappings-io.ts
import fs from "node:fs";
import path from "node:path";
var MANIFEST_DIR = ".manifest";
var MAPPINGS_FILE_NAME = "uds-mappings.json";
var MappingsFileError = class extends Error {
  /** §6.3：校验失败 */
  exitCode = 3;
  constructor(message) {
    super(message);
    this.name = "MappingsFileError";
  }
};
var MappingsWriteError = class extends Error {
  /** §6.3：原子写失败 */
  exitCode = 5;
  constructor(message) {
    super(message);
    this.name = "MappingsWriteError";
  }
};
function mappingsFilePath(cwd) {
  return path.join(cwd, MANIFEST_DIR, MAPPINGS_FILE_NAME);
}
function emptyMappings() {
  return { schemaVersion: 1, mappings: [] };
}
function readMappingsFile(cwd) {
  const file = mappingsFilePath(cwd);
  if (!fs.existsSync(file)) return null;
  let raw;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch (err) {
    throw new MappingsFileError(`${MAPPINGS_FILE_NAME} \u8BFB\u53D6\u5931\u8D25\uFF1A${errMessage(err)}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new MappingsFileError(`${MAPPINGS_FILE_NAME} \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage(err)}`);
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new MappingsFileError(
      `${MAPPINGS_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08\u9700 { schemaVersion, mappings } \u5F62\u6001\u7684 JSON \u5BF9\u8C61\uFF09`
    );
  }
  const file_ = parsed;
  if (!Array.isArray(file_.mappings)) {
    throw new MappingsFileError(`${MAPPINGS_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08mappings \u5FC5\u987B\u4E3A\u6570\u7EC4\uFF09`);
  }
  if (file_.schemaVersion !== 1) {
    throw new MappingsFileError(
      `${MAPPINGS_FILE_NAME} \u7684 schemaVersion \u672A\u77E5\uFF08= ${JSON.stringify(file_.schemaVersion)}\uFF09\uFF0C\u4EC5\u652F\u6301 1\uFF0C\u62D2\u7EDD\u8BFB\u5199`
    );
  }
  if (file_.mappings.some((item) => typeof item !== "object" || item === null || Array.isArray(item))) {
    throw new MappingsFileError(
      `${MAPPINGS_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08mappings \u6761\u76EE\u5FC5\u987B\u4E3A\u5BF9\u8C61\uFF0C\u5B58\u5728 null/\u975E\u5BF9\u8C61\u6761\u76EE\uFF09`
    );
  }
  return file_;
}
function atomicWriteMappings(cwd, data) {
  const file = mappingsFilePath(cwd);
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(tmp, `${JSON.stringify(data, null, 2)}
`, { mode: 384 });
    fs.renameSync(tmp, file);
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {
    }
    throw new MappingsWriteError(`\u539F\u5B50\u5199\u5931\u8D25\uFF1A${errMessage(err)}`);
  }
}
function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/aggregate.ts
var DEFAULT_PORTS = {
  redis: 6379,
  sentinel: 26379,
  cluster: 6379,
  http: 80,
  https: 443,
  kafka: 9092,
  rabbitmq: 5672
};
function resolveDefaultPort(input) {
  const table = DEFAULT_PORTS;
  switch (input.kind) {
    case "host-port":
    case "generic": {
      if (typeof input.middleware !== "string") return void 0;
      if (!Object.prototype.hasOwnProperty.call(table, input.middleware)) return void 0;
      return table[input.middleware];
    }
    case "node-list":
      if (input.role === "sentinel") return DEFAULT_PORTS.sentinel;
      if (input.role === "cluster") return DEFAULT_PORTS.cluster;
      return void 0;
    case "url":
      if (input.urlScheme === "http") return DEFAULT_PORTS.http;
      if (input.urlScheme === "https") return DEFAULT_PORTS.https;
      return void 0;
    default:
      return void 0;
  }
}
var BUILTIN_EXTRACTORS = {
  "middleware-endpoints": expandMiddlewareEndpoints
};
var REGISTRY_MIDDLEWARE_TOKENS = ["nacos", "consul", "eureka", "zookeeper", "config-server"];
var REGISTRY_COMPANION_OFFSETS = { nacos: 1e3 };
function registryCompanionOffset(middleware) {
  const name = typeof middleware === "string" ? middleware.toLowerCase() : "";
  if (!REGISTRY_MIDDLEWARE_TOKENS.some((t) => name.includes(t))) return void 0;
  for (const [token, offset] of Object.entries(REGISTRY_COMPANION_OFFSETS)) {
    if (name.includes(token)) return offset;
  }
  return void 0;
}
function expandMiddlewareEndpoints(data) {
  const entry = data;
  const list = entry?.list;
  if (!Array.isArray(list)) {
    throw new Error("\u4E2D\u95F4\u4EF6\u914D\u7F6E\u7684\u7ED3\u6784\u4E0D\u7B26\uFF08\u7F3A list \u6570\u7EC4\uFF09\u2014\u2014\u5F15\u7528\u96C6\u65E0\u4ECE\u679A\u4E3E");
  }
  const refs = [];
  const addRef = (host, port, defaultPort, middleware) => {
    if (typeof host !== "string" || host === "") return;
    const p = typeof port === "number" ? port : defaultPort;
    if (typeof p !== "number" || !Number.isFinite(p)) return;
    refs.push(`${host}:${p}`);
    const offset = registryCompanionOffset(middleware);
    if (offset !== void 0) refs.push(`${host}:${p + offset}`);
  };
  for (const item of list) {
    const entryObj = isPlainObject(item) ? item : null;
    const ep = entryObj?.endpoint;
    if (!isPlainObject(ep)) continue;
    if (ep.kind === "host-port") {
      addRef(ep.host, ep.port, resolveDefaultPort({ middleware: entryObj.middleware, kind: ep.kind }), entryObj.middleware);
    } else if (ep.kind === "node-list") {
      const dft = resolveDefaultPort({ kind: ep.kind, role: ep.role });
      if (Array.isArray(ep.nodes)) {
        for (const n of ep.nodes) {
          const node = isPlainObject(n) ? n : null;
          addRef(node?.host, node?.port, dft, entryObj.middleware);
        }
      }
    } else if (ep.kind === "generic") {
      const dft = resolveDefaultPort({ middleware: entryObj.middleware, kind: ep.kind });
      if (Array.isArray(ep.targets)) {
        for (const t of ep.targets) {
          const target = isPlainObject(t) ? t : null;
          addRef(target?.host, target?.port, dft, entryObj.middleware);
        }
      }
    } else if (ep.kind === "url") {
      if (ep.mapped !== true) continue;
      const u = parseUrl(ep.endPoint);
      if (u === null) continue;
      const port = u.port !== "" ? Number(u.port) : resolveDefaultPort({ kind: ep.kind, urlScheme: u.protocol.replace(/:$/, "") });
      addRef(u.hostname, port, void 0, void 0);
    }
  }
  return refs;
}
function parseUrl(endPoint) {
  if (typeof endPoint !== "string" || endPoint === "") return null;
  try {
    return new URL(endPoint);
  } catch {
    return null;
  }
}
function readJsonPath(data, jsonPath) {
  if (typeof jsonPath !== "string" || !jsonPath.startsWith("$.")) {
    throw new Error(`JSON \u8DEF\u5F84\u5FC5\u987B\u4EE5 '$.' \u8D77\u624B\uFF1A${JSON.stringify(jsonPath)}`);
  }
  if (jsonPath.includes("[") || jsonPath.includes("*")) {
    throw new Error(
      `JSON \u8DEF\u5F84\u53EA\u652F\u6301 $.a.b \u70B9\u5206\u5F62\u5F0F\uFF0C\u4E0D\u5F97\u542B '[' \u6216 '*'\uFF1A${JSON.stringify(jsonPath)}`
    );
  }
  let cursor = data;
  for (const segment of jsonPath.slice(2).split(".")) {
    if (segment === "") throw new Error(`JSON \u8DEF\u5F84\u542B\u7A7A\u6BB5\uFF1A${JSON.stringify(jsonPath)}`);
    if (!isPlainObject(cursor)) {
      throw new Error(`JSON \u8DEF\u5F84\u53D6\u4E0D\u5230\u503C\uFF08\u5728 '${segment}' \u5904\u65AD\u5F00\uFF09\uFF1A${JSON.stringify(jsonPath)}`);
    }
    if (!Object.prototype.hasOwnProperty.call(cursor, segment)) {
      throw new Error(`JSON \u8DEF\u5F84\u53D6\u4E0D\u5230\u503C\uFF08\u7F3A '${segment}'\uFF09\uFF1A${JSON.stringify(jsonPath)}`);
    }
    cursor = cursor[segment];
  }
  return cursor;
}
var BAKED_KEY = "__SPECKIT_BAKED_MAPPING_REFS__";
function readBakedRules() {
  const baked = globalThis[BAKED_KEY];
  if (!Array.isArray(baked)) return [];
  return baked.map(normalizeBakedRule).filter((rule) => rule !== null);
}
function normalizeBakedRule(raw) {
  if (!isPlainObject(raw)) return null;
  const file = raw.file;
  if (typeof file !== "string" || file === "") return null;
  if (raw.extractor !== void 0) {
    return typeof raw.extractor === "string" && raw.extractor !== "" ? { file, extractor: raw.extractor } : null;
  }
  const { list, host, port } = raw;
  if (typeof list === "string" && list !== "" && typeof host === "string" && host !== "" && typeof port === "string" && port !== "") {
    return { file, list, host, port };
  }
  return null;
}
function resolveRules() {
  return readBakedRules();
}
function collectRefsOrThrow(cwd, rules) {
  const refs = /* @__PURE__ */ new Set();
  for (const rule of rules) {
    const file = path2.join(cwd, MANIFEST_DIR, rule.file);
    if (!fs2.existsSync(file)) continue;
    const data = readRefDataChecked(file);
    for (const endpoint of extractRefs(data, rule)) refs.add(endpoint);
  }
  return refs;
}
function extractRefs(data, rule) {
  if ("extractor" in rule) {
    const extractor = BUILTIN_EXTRACTORS[rule.extractor];
    if (extractor === void 0) {
      throw new Error(`\u672A\u77E5\u7684\u5185\u7F6E\u63D0\u53D6\u5668 id\uFF1A${JSON.stringify(rule.extractor)}\uFF08${rule.file}\uFF09`);
    }
    return extractor(data);
  }
  return extractByJsonPaths(data, rule);
}
function extractByJsonPaths(data, rule) {
  const entries = readJsonPath(data, rule.list);
  if (!Array.isArray(entries)) {
    throw new Error(`list \u8DEF\u5F84\u672A\u6307\u5411\u6570\u7EC4\uFF08${rule.list}\uFF0C${rule.file}\uFF09\u2014\u2014\u5F15\u7528\u96C6\u65E0\u4ECE\u679A\u4E3E`);
  }
  const refs = [];
  for (const entry of entries) {
    if (!isPlainObject(entry)) continue;
    let host;
    let port;
    try {
      host = readJsonPath(entry, rule.host);
      port = readJsonPath(entry, rule.port);
    } catch {
      continue;
    }
    if (typeof host !== "string" || host === "") continue;
    const portNumber = readPortNumber(port);
    if (portNumber === null) continue;
    refs.push(`${host}:${portNumber}`);
  }
  return refs;
}
function readPortNumber(port) {
  if (typeof port === "number") return Number.isFinite(port) ? port : null;
  if (typeof port === "string" && /^\d+$/.test(port)) return Number(port);
  return null;
}
function readRefDataChecked(file) {
  let raw;
  try {
    raw = fs2.readFileSync(file, "utf8");
  } catch (err) {
    throw new Error(`\u5F15\u7528\u6E90\u6570\u636E\u6587\u4EF6\u8BFB\u53D6\u5931\u8D25\uFF08${file}\uFF09\uFF1A${errMessage2(err)}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new Error(`\u5F15\u7528\u6E90\u6570\u636E\u6587\u4EF6\u4E0D\u662F\u5408\u6CD5 JSON\uFF08${file}\uFF09\uFF1A${errMessage2(err)}`);
  }
  if (!isPlainObject(parsed)) {
    throw new Error(`\u5F15\u7528\u6E90\u6570\u636E\u6587\u4EF6\u9876\u5C42\u5FC5\u987B\u4E3A JSON \u5BF9\u8C61\uFF08${file}\uFF09`);
  }
  if (parsed.schemaVersion !== 1) {
    throw new Error(
      `\u5F15\u7528\u6E90\u6570\u636E\u6587\u4EF6\u7684 schemaVersion \u672A\u77E5\uFF08= ${JSON.stringify(parsed.schemaVersion)}\uFF09\uFF0C\u4EC5\u652F\u6301 1\uFF08${file}\uFF09`
    );
  }
  return parsed;
}
function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function errMessage2(err) {
  return err instanceof Error ? err.message : String(err);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/sbx-outbound.ts
import { execFileSync } from "node:child_process";
var MAX_ATTEMPTS = 3;
var RETRY_INTERVAL_MS = 2e3;
var RETRYABLE_EXIT = /* @__PURE__ */ new Set([9]);
var SBOX_OUTBOUND_BIN_ENV = "SBOX_OUTBOUND_BIN";
var DEFAULT_SBOX_OUTBOUND_BIN = "sbx-outbound";
var NO_EXIT_CODE = -1;
function resolveSbxOutboundBin() {
  const override = process.env[SBOX_OUTBOUND_BIN_ENV];
  return override !== void 0 && override !== "" ? override : DEFAULT_SBOX_OUTBOUND_BIN;
}
function describeSbxArgs(args) {
  const parts = [];
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    parts.push(arg);
    if (i + 1 >= args.length || !arg.startsWith("-")) continue;
    const value = args[++i];
    parts.push(arg === "-m" ? `<${countPayloadItems(value)} \u6761\u8F7D\u8377>` : value);
  }
  return `sbx-outbound ${parts.join(" ")}`;
}
function countPayloadItems(payload) {
  try {
    const parsed = JSON.parse(payload);
    return Array.isArray(parsed) ? String(parsed.length) : "?";
  } catch {
    return "?";
  }
}
function runSbxOutbound(args, log2) {
  const bin = resolveSbxOutboundBin();
  const startedAt = Date.now();
  let result;
  try {
    const stdout = execFileSync(bin, args, { encoding: "utf-8", stdio: ["ignore", "pipe", "pipe"] });
    result = { status: 0, stdout, stderr: "" };
  } catch (err) {
    const e = err;
    result = {
      // status = 子进程自退出的退出码；被信号杀死 / spawn 失败（如 ENOENT）时非数字 → 归一 null
      status: typeof e.status === "number" ? e.status : null,
      stdout: toStringOrEmpty(e.stdout),
      stderr: toStringOrEmpty(e.stderr),
      spawnError: err
    };
  }
  log2?.tool(describeSbxArgs(args), {
    exit: result.status ?? NO_EXIT_CODE,
    ms: Date.now() - startedAt
  });
  return result;
}
function runSbxOutboundWithRetry(args, log2) {
  let result = runSbxOutbound(args, log2);
  let attempts = 1;
  while (attempts < MAX_ATTEMPTS && result.status !== null && RETRYABLE_EXIT.has(result.status)) {
    sleepSync(RETRY_INTERVAL_MS);
    result = runSbxOutbound(args, log2);
    attempts++;
  }
  return { ...result, attempts };
}
function exitWithOutboundFailure(result, attempts, action, log2) {
  if (result.status !== null) {
    process.stderr.write(`${result.status}
${result.stderr}${result.stdout ? `
${result.stdout}` : ""}
`);
    if (attempts > 1) process.stderr.write(`\u5C1D\u8BD5 ${attempts} \u6B21\u5747\u5931\u8D25
`);
    log2?.error(
      `${action} sbx-outbound \u8C03\u7528\u5931\u8D25\uFF08\u9000\u51FA\u7801 ${result.status}${attempts > 1 ? `\uFF0C\u5C1D\u8BD5 ${attempts} \u6B21\u5747\u5931\u8D25` : ""}\uFF09`
    );
  } else {
    const detail = result.spawnError instanceof Error ? result.spawnError.message : String(result.spawnError ?? "sbx-outbound \u8C03\u7528\u5931\u8D25");
    process.stderr.write(`sbx-outbound \u8C03\u7528\u5931\u8D25\uFF08\u65E0\u9000\u51FA\u7801\uFF09\uFF1A${detail}
`);
    log2?.error(`${action} sbx-outbound \u8C03\u7528\u5931\u8D25\uFF08\u65E0\u9000\u51FA\u7801\uFF09\uFF1A${detail}`);
  }
  process.exit(1);
}
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}
function toStringOrEmpty(v) {
  return v === void 0 || v === null ? "" : String(v);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/commands.ts
var EXIT = {
  OK: 0,
  FAILURE: 1,
  USAGE: 2,
  INVALID: 3,
  NOT_FOUND: 4
};
var log = createLogger("uds-mapping");
function workspaceRoot() {
  const home = process.env.HOME?.trim();
  if (!home) {
    process.stderr.write("HOME is unset; cannot resolve $HOME/resources\n");
    process.exit(2);
  }
  return path3.join(home, "resources");
}
var FLAG_KEYS = {
  "--mapping": "mapping",
  "--real-endpoint": "realEndpoint"
};
var SUBCOMMAND_SPECS = {
  validate: {
    flags: [],
    usage: "validate",
    summary: "\u6821\u9A8C\u6620\u5C04\u8868\u7ED3\u6784\uFF08\u4E0D\u843D\u76D8\uFF1B\u6587\u4EF6\u7F3A\u5931\u6309\u7A7A\u8868\u653E\u884C\uFF09"
  },
  upsert: {
    flags: ["--mapping"],
    usage: "upsert --mapping <json>",
    summary: "\u6309 realEndpoint \u63D2\u5165\u6216\u6574\u6761\u76EE\u66FF\u6362"
  },
  get: {
    flags: ["--real-endpoint"],
    usage: "get [--real-endpoint <r>]",
    summary: "\u65E0\u53C2 = \u6574\u8868\uFF1B\u5E26\u53C2 = \u5355\u6761\uFF08\u672A\u547D\u4E2D exit 4\uFF09"
  },
  "map-ensure": {
    flags: ["--real-endpoint"],
    usage: "map-ensure --real-endpoint <r>",
    summary: "\u5E42\u7B49\u5EFA\u6620\u5C04\uFF1A\u5148\u67E5\u5E73\u53F0\uFF08\u547D\u4E2D\u5373\u56DE\u5199\u672C\u5730\uFF09\uFF0C\u672A\u5EFA\u5219\u7533\u8BF7\uFF08\u4EC5 exit 9 \u53EF\u91CD\u8BD5\uFF09"
  },
  "map-verify": {
    flags: [],
    usage: "map-verify",
    summary: '\u53EA\u8BFB\u5F15\u7528\u5B8C\u6574\u6027\u6821\u9A8C\uFF08\u5B64\u513F\u68C0\u6D4B\uFF09\uFF1Bstdout = {"ok":bool,"orphans":[\u2026]}'
  },
  "map-rebuild": {
    flags: [],
    usage: "map-rebuild",
    summary: "\u5168\u91CF\u91CD\u5EFA\uFF1A\u805A\u5408 \u2192 \u5B64\u513F\u6E05\u7406 \u2192 set -m \u2192 \u6F02\u79FB\u66F4\u65B0 / stale \u6807\u8BB0"
  }
};
function usage(reason) {
  const lines = Object.entries(SUBCOMMAND_SPECS).map(
    ([, spec]) => `  ${spec.usage.padEnd(36)}${spec.summary}`
  );
  process.stderr.write(
    `usage: uds-mapping-tool <${Object.keys(SUBCOMMANDS).join("|")}> [flags]
${lines.join("\n")}
\u53C2\u6570\u975E\u6CD5\uFF1A${reason}
`
  );
  log.error(`\u53C2\u6570\u975E\u6CD5\uFF1A${reason}`);
  process.exit(EXIT.USAGE);
}
function parseFlags(rest, subcommand) {
  const allowed = SUBCOMMAND_SPECS[subcommand].flags;
  const out = {};
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    if (!allowed.includes(arg)) usage(`\u672A\u77E5\u6216\u8D8A\u6743 flag\uFF1A${arg}\uFF08${subcommand} \u7684\u5141\u8BB8\u96C6\uFF1A${allowed.join(" ") || "(\u65E0)"}\uFF09`);
    if (i + 1 >= rest.length) usage(`flag \u7F3A\u503C\uFF1A${arg}`);
    out[FLAG_KEYS[arg]] = rest[++i];
  }
  return out;
}
function exitWith(code, message) {
  if (message) {
    process.stderr.write(`${message}
`);
    if (code !== EXIT.NOT_FOUND) log.error(message);
  }
  process.exit(code);
}
var isNonEmptyString = (v) => typeof v === "string" && v.length > 0;
var isValidPort = (v) => typeof v === "number" && Number.isInteger(v) && v > 0 && v <= 65535;
function validateMappingEntry(entry, at = "") {
  const field = (name) => at === "" ? name : `${at}.${name}`;
  if (typeof entry !== "object" || entry === null || Array.isArray(entry)) {
    return [{ target: at === "" ? "mapping" : at, message: "\u6620\u5C04\u6761\u76EE\u5FC5\u987B\u4E3A\u5BF9\u8C61" }];
  }
  const e = entry;
  const errors = [];
  if (!isNonEmptyString(e.realEndpoint)) {
    errors.push({ target: field("realEndpoint"), message: "realEndpoint \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32\uFF08\u5E73\u53F0\u4FA7 host:port\uFF09" });
  }
  if (!isValidPort(e.loopbackPort)) {
    errors.push({
      target: field("loopbackPort"),
      message: `loopbackPort \u5FC5\u987B\u4E3A\u6B63\u6574\u6570\u4E14 \u2264 65535\uFF08\u5F53\u524D ${JSON.stringify(e.loopbackPort)}\uFF09`
    });
  }
  if (e.direct !== void 0 && typeof e.direct !== "boolean") {
    errors.push({ target: field("direct"), message: "direct \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A boolean" });
  }
  if (e.stale !== void 0 && typeof e.stale !== "boolean") {
    errors.push({ target: field("stale"), message: "stale \u82E5\u5B58\u5728\u5FC5\u987B\u4E3A boolean" });
  }
  return errors;
}
function validateMappingsFile(file) {
  const errors = [];
  const warnings = [];
  if (file.schemaVersion !== 1) {
    errors.push({
      target: "schemaVersion",
      message: `\u672A\u77E5 schemaVersion\uFF08= ${JSON.stringify(file.schemaVersion)}\uFF09\uFF0C\u4EC5\u652F\u6301 1`
    });
  }
  const seen = /* @__PURE__ */ new Set();
  file.mappings.forEach((entry, i) => {
    errors.push(...validateMappingEntry(entry, `mappings[${i}]`));
    if (typeof entry === "object" && entry !== null && isNonEmptyString(entry.realEndpoint)) {
      const key = entry.realEndpoint;
      if (seen.has(key)) {
        errors.push({ target: `mappings[${i}].realEndpoint`, message: `realEndpoint \u91CD\u590D\uFF1A${key}` });
      } else {
        seen.add(key);
      }
    }
  });
  return { errors, warnings };
}
function reportValidation({ errors, warnings }) {
  if (errors.length > 0) {
    process.stdout.write(`${JSON.stringify({ ok: false, errors })}
`);
    const summary = `\u6821\u9A8C\u5931\u8D25\uFF1A${errors.length} \u5904\u9519\u8BEF\uFF08\u9996\u5904\uFF1A${errors[0].target} ${errors[0].message}\uFF09`;
    process.stderr.write(`${summary}
`);
    log.error(summary);
    process.exit(EXIT.INVALID);
  }
  process.stdout.write(`${JSON.stringify({ ok: true, warnings })}
`);
}
function persist(cwd, file, action) {
  const startedAt = Date.now();
  try {
    atomicWriteMappings(cwd, file);
  } catch (err) {
    log.error(`${action} \u843D\u76D8\u5931\u8D25\uFF1A${errMessage3(err)}`);
    throw err;
  }
  log.tool(`${action} \u2192 \u843D\u76D8 ${file.mappings.length} \u6761\u6620\u5C04`, {
    exit: EXIT.OK,
    ms: Date.now() - startedAt
  });
}
function readOrEmpty(cwd) {
  return readMappingsFile(cwd) ?? emptyMappings();
}
function cmdValidate(argv) {
  parseFlags(argv, "validate");
  reportValidation(validateMappingsFile(readOrEmpty(workspaceRoot())));
  return EXIT.OK;
}
function cmdUpsert(argv) {
  const args = parseFlags(argv, "upsert");
  if (args.mapping === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --mapping");
  let parsed;
  try {
    parsed = JSON.parse(args.mapping);
  } catch (err) {
    exitWith(EXIT.USAGE, `--mapping \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage3(err)}`);
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    exitWith(EXIT.USAGE, "--mapping \u5FC5\u987B\u4E3A\u5355\u4E2A\u6620\u5C04\u6761\u76EE\u5BF9\u8C61 JSON");
  }
  const entry = parsed;
  const errors = validateMappingEntry(entry);
  if (errors.length > 0) reportValidation({ errors, warnings: [] });
  const cwd = workspaceRoot();
  const file = readOrEmpty(cwd);
  file.mappings = file.mappings.filter((x) => x.realEndpoint !== entry.realEndpoint).concat([entry]);
  persist(cwd, file, `upsert realEndpoint=${entry.realEndpoint}`);
  process.stdout.write('{"ok":true}\n');
  return EXIT.OK;
}
function cmdGet(argv) {
  const args = parseFlags(argv, "get");
  const existing = readMappingsFile(workspaceRoot());
  const file = existing ?? emptyMappings();
  if (args.realEndpoint === void 0) {
    process.stdout.write(`${JSON.stringify(file)}
`);
    return EXIT.OK;
  }
  const entry = file.mappings.find((x) => x.realEndpoint === args.realEndpoint);
  if (entry === void 0) {
    exitWith(
      EXIT.NOT_FOUND,
      existing === null ? `\u6620\u5C04\u6587\u4EF6\u7F3A\u5931\uFF08.manifest/${MAPPINGS_FILE_NAME}\uFF09\uFF0C\u672A\u627E\u5230\uFF1A${args.realEndpoint}` : `\u672A\u627E\u5230\u6620\u5C04\u6761\u76EE\uFF1A${args.realEndpoint}`
    );
  }
  process.stdout.write(`${JSON.stringify(entry)}
`);
  return EXIT.OK;
}
function parseSbxMappingOutput(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    exitWith(EXIT.INVALID, `sbx-outbound \u8F93\u51FA\u4E0D\u662F\u5408\u6CD5 JSON\uFF08${errMessage3(err)}\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`);
  }
  if (!isPlainObject2(parsed)) {
    exitWith(EXIT.INVALID, `sbx-outbound \u8F93\u51FA\u7ED3\u6784\u4E0D\u7B26\uFF08\u9700 { loopbackPort } \u5BF9\u8C61\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`);
  }
  const port = parsed.loopbackPort;
  if (!isValidPort(port)) {
    exitWith(
      EXIT.INVALID,
      `sbx-outbound \u8F93\u51FA\u7684 loopbackPort \u975E\u6CD5\uFF08= ${JSON.stringify(port)}\uFF0C\u987B\u4E3A\u6B63\u6574\u6570\u4E14 \u2264 65535\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`
    );
  }
  const direct = parsed.direct;
  return typeof direct === "boolean" ? { loopbackPort: port, direct } : { loopbackPort: port };
}
function withMapping(file, realEndpoint, loopbackPort, direct) {
  const entry = { realEndpoint, loopbackPort };
  if (direct !== void 0) entry.direct = direct;
  return {
    schemaVersion: 1,
    mappings: file.mappings.filter((x) => x.realEndpoint !== realEndpoint).concat([entry])
  };
}
function cmdMapEnsure(argv) {
  const args = parseFlags(argv, "map-ensure");
  if (args.realEndpoint === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --real-endpoint");
  const realEndpoint = args.realEndpoint;
  const cwd = workspaceRoot();
  const got = runSbxOutbound(["get", "-r", realEndpoint], log);
  if (got.status === EXIT.OK) {
    const out2 = parseSbxMappingOutput(got.stdout);
    persist(
      cwd,
      withMapping(readOrEmpty(cwd), realEndpoint, out2.loopbackPort, out2.direct),
      `map-ensure(hit) realEndpoint=${realEndpoint}`
    );
    process.stdout.write(`${JSON.stringify({ ok: true, realEndpoint, loopbackPort: out2.loopbackPort })}
`);
    return EXIT.OK;
  }
  if (got.status !== EXIT.NOT_FOUND) exitWithOutboundFailure(got, 1, "map-ensure", log);
  const added = runSbxOutboundWithRetry(["add", "-r", realEndpoint], log);
  if (added.status !== EXIT.OK) exitWithOutboundFailure(added, added.attempts, "map-ensure", log);
  const out = parseSbxMappingOutput(added.stdout);
  persist(
    cwd,
    withMapping(readOrEmpty(cwd), realEndpoint, out.loopbackPort, out.direct),
    `map-ensure(add) realEndpoint=${realEndpoint}`
  );
  process.stdout.write(`${JSON.stringify({ ok: true, realEndpoint, loopbackPort: out.loopbackPort })}
`);
  return EXIT.OK;
}
function aggregateRefsDetailed(cwd) {
  const rules = resolveRules();
  if (rules.length === 0) return { status: "failed", reason: "\u5F15\u7528\u6E90\u89C4\u5219\u8868\u4E3A\u7A7A\u2014\u2014\u65E0\u4ECE\u679A\u4E3E\u5F15\u7528\u96C6" };
  try {
    return { status: "ok", refs: collectRefsOrThrow(cwd, rules) };
  } catch (err) {
    return { status: "failed", reason: errMessage3(err) };
  }
}
function cmdMapVerify(argv) {
  parseFlags(argv, "map-verify");
  const cwd = workspaceRoot();
  const file = readOrEmpty(cwd);
  const aggregation = aggregateRefsDetailed(cwd);
  if (aggregation.status === "failed") {
    exitWith(EXIT.INVALID, `\u5F15\u7528\u96C6\u805A\u5408\u5931\u8D25\uFF08${aggregation.reason}\uFF09\u2014\u2014\u65E0\u4ECE\u5224\u5B9A\u5B64\u513F\uFF0C\u4E0D\u62A5\u300C\u65E0\u5B64\u513F\u300D`);
  }
  const orphans = file.mappings.filter((x) => !aggregation.refs.has(x.realEndpoint)).map((x) => x.realEndpoint);
  process.stdout.write(`${JSON.stringify({ ok: orphans.length === 0, orphans })}
`);
  if (orphans.length === 0) return EXIT.OK;
  const summary = `\u5F15\u7528\u5B8C\u6574\u6027\u6821\u9A8C\u5931\u8D25\uFF1A${orphans.length} \u6761\u5B64\u513F\u6620\u5C04\uFF08\u4E0D\u5728\u5F15\u7528\u96C6\u5185\uFF09\uFF1A${orphans.slice(0, 5).join(", ")}${orphans.length > 5 ? " \u2026" : ""}`;
  process.stderr.write(`${summary}
`);
  log.error(summary);
  process.exit(EXIT.INVALID);
}
function parseSetFallbackArray(stdout) {
  let parsed;
  try {
    parsed = JSON.parse(stdout);
  } catch {
    return null;
  }
  if (!Array.isArray(parsed)) return null;
  const shapeOk = parsed.every(
    (x) => isPlainObject2(x) && isNonEmptyString(x.realEndpoint) && typeof x.actualLoopbackPort === "number"
  );
  return shapeOk ? parsed : null;
}
function cmdMapRebuild(argv) {
  parseFlags(argv, "map-rebuild");
  const cwd = workspaceRoot();
  const file = readMappingsFile(cwd);
  if (file === null) return EXIT.OK;
  const aggregation = aggregateRefsDetailed(cwd);
  if (aggregation.status === "failed") {
    for (const x of file.mappings) x.stale = true;
    persist(cwd, file, "map-rebuild(aggregate-failed)");
    process.stderr.write(
      `\u5F15\u7528\u96C6\u805A\u5408\u5931\u8D25\uFF08${aggregation.reason}\uFF09\uFF1A${file.mappings.length} \u6761\u6620\u5C04\u4FDD\u7559\u65E7\u503C\u5E76\u6807\u8BB0 stale=true\uFF0C\u8DF3\u8FC7\u5B64\u513F\u6E05\u7406\uFF0C\u5F85\u4E0B\u8F6E\u91CD\u5EFA\u91CD\u8BD5
`
    );
    log.error(`map-rebuild \u5F15\u7528\u96C6\u805A\u5408\u5931\u8D25\uFF1A${aggregation.reason}`);
    process.exit(EXIT.FAILURE);
  }
  file.mappings = file.mappings.filter((x) => aggregation.refs.has(x.realEndpoint));
  if (file.mappings.length === 0) {
    persist(cwd, file, "map-rebuild(empty)");
    return EXIT.OK;
  }
  const payload = file.mappings.map((x) => ({
    realEndpoint: x.realEndpoint,
    expectLoopbackPort: x.loopbackPort
  }));
  const result = runSbxOutbound(["set", "-m", JSON.stringify(payload)], log);
  if (result.status === EXIT.OK) {
    for (const x of file.mappings) delete x.stale;
    persist(cwd, file, "map-rebuild");
    return EXIT.OK;
  }
  if (result.status === 1) {
    const fallback = parseSetFallbackArray(result.stdout);
    if (fallback !== null) {
      const drifts = [];
      for (const x of file.mappings) {
        const hit = fallback.find((y) => y.realEndpoint === x.realEndpoint);
        if (hit !== void 0) {
          drifts.push(`${x.realEndpoint} \u671F\u671B ${x.loopbackPort} \u2192 \u5B9E\u9645 ${hit.actualLoopbackPort}`);
          x.loopbackPort = hit.actualLoopbackPort;
        }
        delete x.stale;
      }
      persist(cwd, file, "map-rebuild(drift)");
      process.stderr.write(
        `\u7AEF\u53E3\u6F02\u79FB\uFF08set \u6709\u56DE\u9000\uFF0C\u5DF2\u6309 actualLoopbackPort \u66F4\u65B0\uFF1B\u6D88\u8D39\u65B9\u8BFB\u5F53\u524D\u503C\u515C\u5E95\uFF0CI-3\uFF09\uFF1A
${drifts.map((l) => `  ${l}`).join("\n")}
`
      );
      return EXIT.OK;
    }
  }
  for (const x of file.mappings) x.stale = true;
  persist(cwd, file, "map-rebuild(failed)");
  if (result.status !== null) {
    process.stderr.write(
      `set \u6279\u91CF\u91CD\u5EFA\u5168\u91CF\u5931\u8D25\uFF08sbx-outbound \u9000\u51FA\u7801 ${result.status}\uFF09\uFF1A\u5168\u90E8\u6620\u5C04\u4FDD\u7559\u65E7\u503C\u6807\u8BB0 stale=true\uFF0C\u5F85\u4E0B\u8F6E\u91CD\u5EFA\u91CD\u8BD5
${result.stderr}${result.stdout ? `
${result.stdout}` : ""}
`
    );
    log.error(`map-rebuild set \u6279\u91CF\u91CD\u5EFA\u5168\u91CF\u5931\u8D25\uFF08sbx-outbound \u9000\u51FA\u7801 ${result.status}\uFF09\uFF1A${file.mappings.length} \u6761\u6620\u5C04\u6807\u8BB0 stale`);
  } else {
    process.stderr.write(
      "set \u6279\u91CF\u91CD\u5EFA\u5168\u91CF\u5931\u8D25\uFF08sbx-outbound \u8C03\u7528\u5F02\u5E38\uFF09\uFF1A\u5168\u90E8\u6620\u5C04\u4FDD\u7559\u65E7\u503C\u6807\u8BB0 stale=true\uFF0C\u5F85\u4E0B\u8F6E\u91CD\u5EFA\u91CD\u8BD5\n"
    );
    log.error(`map-rebuild set \u6279\u91CF\u91CD\u5EFA\u5168\u91CF\u5931\u8D25\uFF08\u65E0\u9000\u51FA\u7801\uFF09\uFF1A${file.mappings.length} \u6761\u6620\u5C04\u6807\u8BB0 stale`);
  }
  process.exit(EXIT.FAILURE);
}
function guarded(fn) {
  return (argv) => {
    try {
      return fn(argv);
    } catch (err) {
      if (err instanceof MappingsFileError || err instanceof MappingsWriteError) {
        exitWith(err.exitCode, err.message);
      }
      throw err;
    }
  };
}
var SUBCOMMANDS = {
  validate: guarded(cmdValidate),
  upsert: guarded(cmdUpsert),
  get: guarded(cmdGet),
  "map-ensure": guarded(cmdMapEnsure),
  "map-verify": guarded(cmdMapVerify),
  "map-rebuild": guarded(cmdMapRebuild)
};
function isPlainObject2(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function errMessage3(err) {
  return err instanceof Error ? err.message : String(err);
}
function truncate(raw) {
  return raw.length <= 200 ? raw : `${raw.slice(0, 200)}\u2026(\u5171 ${raw.length} \u5B57\u7B26)`;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/uds-mapping/cli.mts
function main() {
  const [sub, ...rest] = process.argv.slice(2);
  const handler = sub !== void 0 && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, sub) ? SUBCOMMANDS[sub] : void 0;
  if (handler === void 0) {
    console.error(`\u672A\u77E5\u5B50\u547D\u4EE4\uFF1A${sub ?? "(\u65E0)"}\uFF1B\u53EF\u7528\uFF1A${Object.keys(SUBCOMMANDS).join(", ")}`);
    process.exit(2);
  }
  process.exit(handler(rest));
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  main();
}
export {
  SUBCOMMANDS
};
