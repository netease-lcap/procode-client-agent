globalThis.__SPECKIT_BAKED_MAPPING_REFS__ = [{"file":"datasources.json","list":"$.dataSources","host":"$.config.host","port":"$.config.port"},{"file":"middlewares.json","extractor":"middleware-endpoints"}];
/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/cli.mts
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/commands.ts
import path4 from "node:path";
import { createLogger } from "./shared/logger.mjs";

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/ask.ts
var DATA_SOURCE_ASK_TIMEOUT_MS = 10 * 60 * 1e3;
var FALLBACK_ANSWER = "{}";
function buildDataSourceAskInput(databaseName, sources) {
  if (typeof databaseName !== "string" || databaseName === "") {
    throw new Error("buildDataSourceAskInput\uFF1AdatabaseName \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32\uFF08\u6570\u636E\u5E93\u7C7B\u578B\u6807\u8BC6\uFF0C\u5982 mysql8\uFF09");
  }
  if (!Array.isArray(sources) || sources.length === 0) {
    throw new Error(
      "buildDataSourceAskInput\uFF1Asources \u5FC5\u987B\u4E3A\u975E\u7A7A\u6570\u7EC4\uFF08dataSourceSelect \u7684\u5FC5\u586B\u5B57\u6BB5\uFF0C\u672C\u95EE\u7684\u69FD\u4F4D\u8868\uFF09"
    );
  }
  const seen = /* @__PURE__ */ new Set();
  const options = [];
  for (const source of sources) {
    if (typeof source !== "object" || source === null || Array.isArray(source)) {
      throw new Error("buildDataSourceAskInput\uFF1Asources \u7684\u5143\u7D20\u5FC5\u987B\u4E3A\u5BF9\u8C61\uFF08{ title, description? }\uFF09");
    }
    if (typeof source.title !== "string" || source.title === "") {
      throw new Error("buildDataSourceAskInput\uFF1Asources[].title \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32");
    }
    if (seen.has(source.title)) {
      throw new Error(
        `buildDataSourceAskInput\uFF1Asources[].title \u5728\u540C\u4E00\u4E2A question \u5185\u5FC5\u987B\u552F\u4E00\uFF0C\u91CD\u590D\uFF1A${source.title}`
      );
    }
    seen.add(source.title);
    options.push(
      source.description === void 0 ? { title: source.title } : { title: source.title, description: source.description }
    );
  }
  return {
    questions: [
      {
        header: `\u6570\u636E\u6E90\uFF08${databaseName}\uFF09`,
        question: `\u8BF7\u9009\u62E9\u8981\u63A5\u5165\u7684 ${databaseName} \u6570\u636E\u6E90`,
        // options 恒 []——`dataSourceSelect` 的槽位表在 input.sources 里，不在 options 里
        options: [],
        input: { kind: "dataSourceSelect", databaseName, sources: options }
      }
    ],
    fallbackAnswer: FALLBACK_ANSWER,
    timeoutMs: DATA_SOURCE_ASK_TIMEOUT_MS
  };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/datasources-io.ts
import fs from "node:fs";
import path from "node:path";
var MANIFEST_DIR = ".manifest";
var DATASOURCES_FILE_NAME = "datasources.json";
var DataSourcesFileError = class extends Error {
  /** §6.3：校验失败 */
  exitCode = 3;
  constructor(message) {
    super(message);
    this.name = "DataSourcesFileError";
  }
};
var DataSourcesWriteError = class extends Error {
  /** §6.3：原子写失败 */
  exitCode = 5;
  constructor(message) {
    super(message);
    this.name = "DataSourcesWriteError";
  }
};
function dataSourcesFilePath(cwd) {
  return path.join(cwd, MANIFEST_DIR, DATASOURCES_FILE_NAME);
}
function emptyDataSources() {
  return { schemaVersion: 1, dataSources: [] };
}
function readDataSourcesFile(cwd) {
  const file = dataSourcesFilePath(cwd);
  if (!fs.existsSync(file)) return null;
  let raw;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch (err) {
    throw new DataSourcesFileError(`${DATASOURCES_FILE_NAME} \u8BFB\u53D6\u5931\u8D25\uFF1A${errMessage(err)}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new DataSourcesFileError(`${DATASOURCES_FILE_NAME} \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage(err)}`);
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    throw new DataSourcesFileError(
      `${DATASOURCES_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08\u9700 { schemaVersion, dataSources } \u5F62\u6001\u7684 JSON \u5BF9\u8C61\uFF09`
    );
  }
  const file_ = parsed;
  if (!Array.isArray(file_.dataSources)) {
    throw new DataSourcesFileError(`${DATASOURCES_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08dataSources \u5FC5\u987B\u4E3A\u6570\u7EC4\uFF09`);
  }
  if (file_.schemaVersion !== 1) {
    throw new DataSourcesFileError(
      `${DATASOURCES_FILE_NAME} \u7684 schemaVersion \u672A\u77E5\uFF08= ${JSON.stringify(file_.schemaVersion)}\uFF09\uFF0C\u4EC5\u652F\u6301 1\uFF0C\u62D2\u7EDD\u8BFB\u5199`
    );
  }
  if (file_.dataSources.some((item) => typeof item !== "object" || item === null || Array.isArray(item))) {
    throw new DataSourcesFileError(
      `${DATASOURCES_FILE_NAME} \u7ED3\u6784\u4E0D\u7B26\uFF08dataSources \u6761\u76EE\u5FC5\u987B\u4E3A\u5BF9\u8C61\uFF0C\u5B58\u5728 null/\u975E\u5BF9\u8C61\u6761\u76EE\uFF09`
    );
  }
  return file_;
}
function atomicWriteDataSources(cwd, data) {
  const file = dataSourcesFilePath(cwd);
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(tmp, `${JSON.stringify(data, null, 2)}
`, { mode: 384 });
    fs.renameSync(tmp, file);
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {
    }
    throw new DataSourcesWriteError(`\u539F\u5B50\u5199\u5931\u8D25\uFF1A${errMessage(err)}`);
  }
}
function errMessage(err) {
  return err instanceof Error ? err.message : String(err);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/platform-tool-client.ts
import { execFileSync } from "node:child_process";
import path2 from "node:path";
var PLATFORM_TOOL_BIN_ENV = "PLATFORM_TOOL_BIN";
var DEFAULT_PLATFORM_TOOL_REL = path2.join(
  ".specify",
  "scripts",
  "javascript",
  "platform-tool.mjs"
);
var PLATFORM_TOOL_TIMEOUT_MS = 9e4;
function resolvePlatformToolPath(cwd) {
  const override = process.env[PLATFORM_TOOL_BIN_ENV];
  return override !== void 0 && override !== "" ? override : path2.join(cwd, DEFAULT_PLATFORM_TOOL_REL);
}
function runPlatformTool(cwd, args, log2) {
  const tool = resolvePlatformToolPath(cwd);
  const startedAt = Date.now();
  let result;
  try {
    const stdout = execFileSync(process.execPath, [tool, ...args], {
      cwd,
      encoding: "utf-8",
      stdio: ["ignore", "pipe", "pipe"],
      timeout: PLATFORM_TOOL_TIMEOUT_MS
    });
    result = { status: 0, stdout, stderr: "", tool };
  } catch (err) {
    const e = err;
    result = {
      // status = 子进程自退出的退出码；被信号杀死 / 超时 / spawn 失败（如 ENOENT）时非数字 → 归一 null
      status: typeof e.status === "number" ? e.status : null,
      stdout: e.stdout === void 0 || e.stdout === null ? "" : String(e.stdout),
      stderr: e.stderr === void 0 || e.stderr === null ? "" : String(e.stderr),
      tool,
      spawnError: err
    };
  }
  log2?.tool(`node <platform-tool.mjs> ${args.join(" ")}`, {
    exit: result.status ?? NO_EXIT_CODE,
    ms: Date.now() - startedAt
  });
  return result;
}
var NO_EXIT_CODE = -1;

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/uds-mapping-client.ts
import { execFileSync as execFileSync2 } from "node:child_process";
import path3 from "node:path";
var UDS_MAPPING_TOOL_BIN_ENV = "UDS_MAPPING_TOOL_BIN";
var DEFAULT_UDS_MAPPING_TOOL_REL = path3.join(
  ".specify",
  "scripts",
  "javascript",
  "uds-mapping-tool.mjs"
);
var SIBLING_TIMEOUT_MS = 3e4;
var MAP_ENSURE_TIMEOUT_MS = 6e4;
function resolveUdsMappingToolPath(cwd) {
  const override = process.env[UDS_MAPPING_TOOL_BIN_ENV];
  return override !== void 0 && override !== "" ? override : path3.join(cwd, DEFAULT_UDS_MAPPING_TOOL_REL);
}
function describeSiblingArgs(realEndpoint) {
  return `node <uds-mapping-tool.mjs> get --real-endpoint ${realEndpoint}`;
}
function execUdsMappingTool(cwd, args, describe2, timeoutMs, log2) {
  const tool = resolveUdsMappingToolPath(cwd);
  const startedAt = Date.now();
  let result;
  try {
    const stdout = execFileSync2(process.execPath, [tool, ...args], {
      cwd,
      encoding: "utf-8",
      stdio: ["ignore", "pipe", "pipe"],
      timeout: timeoutMs
    });
    result = { status: 0, stdout, stderr: "", tool };
  } catch (err) {
    const e = err;
    result = {
      // status = 子进程自退出的退出码；被信号杀死 / 超时 / spawn 失败（如 ENOENT）时非数字 → 归一 null
      status: typeof e.status === "number" ? e.status : null,
      stdout: toStringOrEmpty(e.stdout),
      stderr: toStringOrEmpty(e.stderr),
      tool,
      spawnError: err
    };
  }
  log2?.tool(describe2, {
    exit: result.status ?? NO_EXIT_CODE2,
    ms: Date.now() - startedAt
  });
  return result;
}
function runUdsMappingTool(cwd, realEndpoint, log2) {
  return execUdsMappingTool(
    cwd,
    ["get", "--real-endpoint", realEndpoint],
    describeSiblingArgs(realEndpoint),
    SIBLING_TIMEOUT_MS,
    log2
  );
}
function runUdsMappingMapEnsure(cwd, realEndpoint, log2) {
  return execUdsMappingTool(
    cwd,
    ["map-ensure", "--real-endpoint", realEndpoint],
    `node <uds-mapping-tool.mjs> map-ensure --real-endpoint ${realEndpoint}`,
    MAP_ENSURE_TIMEOUT_MS,
    log2
  );
}
var NO_EXIT_CODE2 = -1;
function toStringOrEmpty(v) {
  return v === void 0 || v === null ? "" : String(v);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/commands.ts
var EXIT = {
  OK: 0,
  FAILURE: 1,
  USAGE: 2,
  INVALID: 3,
  NOT_FOUND: 4
};
var log = createLogger("datasource");
function workspaceRoot() {
  const home = process.env.HOME?.trim();
  if (!home) {
    process.stderr.write("HOME is unset; cannot resolve $HOME/resources\n");
    process.exit(2);
  }
  return path4.join(home, "resources");
}
var SUBCOMMAND_SPECS = {
  validate: {
    values: { "--entry": "entry" },
    switches: { "--require-filled": "requireFilled" },
    usage: "validate [--entry <json>] [--require-filled]",
    summary: "\u6821\u9A8C\u6574\u6587\u4EF6\u6216\u5355\u6761\u76EE\uFF08\u5224\u522B\u5F0F\u8054\u5408 + \u5B57\u6BB5\u7C7B\u578B + \u552F\u4E00\u6027\uFF09\uFF1B--require-filled \u8FFD\u52A0\u5FC5\u586B\u503C\u975E\u7A7A"
  },
  upsert: {
    values: { "--entry": "entry" },
    switches: {},
    usage: "upsert --entry <json>",
    summary: "\u6309 dataSourceName \u63D2\u5165\u6216\u6574\u6761\u76EE\u66FF\u6362"
  },
  get: {
    values: { "--name": "name" },
    switches: {},
    usage: "get [--name <n>]",
    summary: "\u65E0\u53C2 = \u6574\u8868\uFF1B\u5E26\u53C2 = \u5355\u6761\u76EE\uFF08\u672A\u547D\u4E2D exit 4\uFF09"
  },
  delete: {
    values: { "--name": "name" },
    switches: {},
    usage: "delete --name <n>",
    summary: "\u6309\u540D\u5220\u9664\u6761\u76EE\uFF08\u672A\u547D\u4E2D exit 4\uFF09\uFF1B**\u4E0D**\u6E05\u7406\u56DE\u73AF\u6620\u5C04\uFF08\u7406\u7531\u89C1 README \xA77.1\uFF09"
  },
  resolve: {
    values: { "--name": "name" },
    switches: {},
    usage: "resolve --name <n>",
    summary: "join \u56DE\u73AF\u6620\u5C04\uFF1A\u6761\u76EE databaseType + config + loopbackHost / loopbackPort\uFF08\u672A\u547D\u4E2D\u6216\u6620\u5C04\u7F3A\u5931\u5747 exit 4\uFF09"
  },
  "register-prepare": {
    values: { "--type": "type", "--slots": "slots" },
    switches: {},
    usage: "register-prepare --type <t> --slots <slots json>",
    summary: "\u7F16\u6392\u524D\u7F6E\uFF1A\u24EA \u5E73\u53F0\u7C7B\u578B\u95E8\uFF08\u4E0D\u652F\u6301 = exit 0 + UNSUPPORTED_TYPE\uFF09+ \u7EC4\u88C5 dataSourceSelect \u7684 ask \u8F7D\u8377\uFF08\u88F8 input\uFF09"
  },
  "register-commit": {
    values: {
      "--app": "app",
      "--name": "name",
      "--answer": "answer",
      "--type": "type"
    },
    switches: {},
    usage: "register-commit --app <a> (--name <n> | --answer <answer json>) --type <t>",
    summary: "\u7F16\u6392\u63D0\u4EA4\uFF1A\u89E3\u6790\u7B54\u6848\uFF08--name \u663E\u5F0F\u4F18\u5148\uFF09\u2192 \u5E73\u53F0\u53D6\u914D\u7F6E \u2192 \u6761\u76EE\u7EC4\u88C5 \u2192 map-ensure \u2192 \u5199\u6761\u76EE \u2192 \u590D\u9A8C"
  }
};
function usage(reason) {
  const lines = Object.entries(SUBCOMMAND_SPECS).map(
    ([, spec]) => `  ${spec.usage.padEnd(48)}${spec.summary}`
  );
  process.stderr.write(
    `usage: datasource-tool <${Object.keys(SUBCOMMANDS).join("|")}> [flags]
${lines.join("\n")}
\u53C2\u6570\u975E\u6CD5\uFF1A${reason}
`
  );
  log.error(`\u53C2\u6570\u975E\u6CD5\uFF1A${reason}`);
  process.exit(EXIT.USAGE);
}
function parseFlags(rest, subcommand) {
  const spec = SUBCOMMAND_SPECS[subcommand];
  const values = {};
  const switches = {};
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    const valueKey = Object.prototype.hasOwnProperty.call(spec.values, arg) ? spec.values[arg] : void 0;
    const switchKey = Object.prototype.hasOwnProperty.call(spec.switches, arg) ? spec.switches[arg] : void 0;
    if (valueKey === void 0 && switchKey === void 0) {
      const allowed = [...Object.keys(spec.values), ...Object.keys(spec.switches)];
      usage(`\u672A\u77E5\u6216\u8D8A\u6743 flag\uFF1A${arg}\uFF08${subcommand} \u7684\u5141\u8BB8\u96C6\uFF1A${allowed.join(" ") || "(\u65E0)"}\uFF09`);
    }
    if (switchKey !== void 0) {
      switches[switchKey] = true;
      continue;
    }
    if (i + 1 >= rest.length) usage(`flag \u7F3A\u503C\uFF1A${arg}`);
    values[valueKey] = rest[++i];
  }
  return { values, switches };
}
function exitWith(code, message, opts = {}) {
  if (message) {
    process.stderr.write(`${message}
`);
    const shouldLog = opts.logError ?? code !== EXIT.NOT_FOUND;
    if (shouldLog) log.error(message);
  }
  process.exit(code);
}
var DATABASE_TYPES = ["mysql8", "oracle", "postgresql", "sqlserver"];
var DATABASE_MODES = ["Platform_Generation", "Manual_Configuration"];
var CONNECTED_MODES = ["sid", "serviceName"];
var ENTRY_KEYS = ["dataSourceName", "databaseType", "databaseMode", "config"];
var COMMON_KEYS = ["host", "port", "username", "password", "customSetting"];
var CONFIG_KEYS = {
  mysql8: [...COMMON_KEYS, "database"],
  oracle: [...COMMON_KEYS, "connectedMode", "connectionTarget"],
  postgresql: [...COMMON_KEYS, "database", "schemaName"],
  sqlserver: [...COMMON_KEYS, "database", "schemaName"]
};
var TARGET_KEY = {
  mysql8: "database",
  oracle: "connectionTarget",
  postgresql: "database",
  sqlserver: "database"
};
var EXTRA_KEYS = {
  mysql8: [],
  oracle: ["connectedMode"],
  postgresql: ["schemaName"],
  sqlserver: ["schemaName"]
};
var UNKNOWN_TYPE_PROBE_KEYS = [...new Set(Object.values(TARGET_KEY))];
var isPlainObject = (v) => typeof v === "object" && v !== null && !Array.isArray(v);
var isNonEmptyString = (v) => typeof v === "string" && v.length > 0;
function isValidPortText(v) {
  if (typeof v !== "string" || !/^\d+$/.test(v)) return false;
  const n = Number(v);
  return n >= 1 && n <= 65535;
}
function validateEntry(entry, at = "", opts = { requireFilled: false }) {
  const field = (name) => at === "" ? name : `${at}.${name}`;
  const errors = [];
  const warnings = [];
  if (!isPlainObject(entry)) {
    return { errors: [{ target: at === "" ? "entry" : at, message: "\u6570\u636E\u6E90\u6761\u76EE\u5FC5\u987B\u4E3A\u5BF9\u8C61" }], warnings };
  }
  for (const key of Object.keys(entry)) {
    if (!ENTRY_KEYS.includes(key)) {
      errors.push({
        target: field(key),
        message: `\u6761\u76EE\u542B\u672A\u77E5\u5B57\u6BB5 ${key}\u2014\u2014\u6761\u76EE\u7EA7\u5141\u8BB8\u952E\u4EC5 ${ENTRY_KEYS.join(" / ")}\uFF08\u7981\u591A\u4F59\u5B57\u6BB5\uFF09`
      });
    }
  }
  if (!isNonEmptyString(entry.dataSourceName)) {
    errors.push({
      target: field("dataSourceName"),
      message: "dataSourceName \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32\uFF08\u6761\u76EE\u952E\uFF0C\u7531 IDE \u4FA7\u6D41\u7A0B\u4EA7\u51FA\uFF09"
    });
  }
  const type = entry.databaseType;
  if (!isNonEmptyString(type)) {
    errors.push({
      target: field("databaseType"),
      message: `databaseType \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32\u2014\u2014\u6570\u636E\u5E93\u7C7B\u578B\u6807\u8BC6\uFF08\u5951\u7EA6\u5DF2\u77E5\u5F62\u6001\uFF1A${DATABASE_TYPES.join(" / ")}\uFF1B\u5F53\u524D ${JSON.stringify(type)}\uFF09`
    });
  }
  const knownType = isNonEmptyString(type) && DATABASE_TYPES.includes(type);
  const dbType = knownType ? type : void 0;
  if (!isNonEmptyString(entry.databaseMode) || !DATABASE_MODES.includes(entry.databaseMode)) {
    errors.push({
      target: field("databaseMode"),
      message: `databaseMode \u5FC5\u987B\u4E3A ${DATABASE_MODES.join(" / ")} \u4E4B\u4E00\uFF08\u5F53\u524D ${JSON.stringify(entry.databaseMode)}\uFF09`
    });
  }
  if (!isPlainObject(entry.config)) {
    errors.push({ target: field("config"), message: "config \u5FC5\u987B\u4E3A\u5BF9\u8C61" });
    return { errors, warnings };
  }
  const config = entry.config;
  if (dbType !== void 0) {
    const allowed = CONFIG_KEYS[dbType];
    for (const key of Object.keys(config)) {
      if (!allowed.includes(key)) {
        errors.push({
          target: field(`config.${key}`),
          message: `databaseType=${dbType} \u7684 config \u4E0D\u5141\u8BB8\u5B57\u6BB5 ${key}\uFF08\u7981\u591A\u4F59\u5B57\u6BB5\uFF1B\u5141\u8BB8\uFF1A${allowed.join(" / ")}\uFF09\u2014\u2014\u8BE5\u5B57\u6BB5\u5C5E\u5176\u5B83\u6570\u636E\u5E93\u7C7B\u578B\uFF0C\u5E26\u4E0A\u5B83\u4F1A\u8BA9\u6D88\u8D39\u65B9\u6309\u9519\u8BEF\u7684 URL \u6A21\u677F\u62FC\u4E32`
        });
      }
    }
  }
  const requireString = (key, opts2 = {}) => {
    const v = config[key];
    if (v === void 0) {
      errors.push({ target: field(`config.${key}`), message: `config.${key} \u4E3A\u5FC5\u586B\u5B57\u6BB5\uFF08\u7F3A\u5931\uFF09` });
      return;
    }
    if (typeof v !== "string") {
      errors.push({
        target: field(`config.${key}`),
        message: `config.${key} \u5FC5\u987B\u4E3A\u5B57\u7B26\u4E32\uFF08\u5F53\u524D ${describe(v)}\uFF09`
      });
      return;
    }
    if (opts2.requireFilled && v === "") {
      errors.push({
        target: field(`config.${key}`),
        message: `config.${key} \u4E0D\u5F97\u4E3A\u7A7A\uFF08--require-filled\uFF1A\u8BE5\u5B57\u6BB5\u4E3A\u7A7A\u5373\u65E0\u6CD5\u5EFA\u7ACB\u8FDE\u63A5\uFF09`
      });
    }
  };
  requireString("host", { requireFilled: opts.requireFilled });
  requireString("username", { requireFilled: opts.requireFilled });
  if (config.port === void 0) {
    errors.push({ target: field("config.port"), message: "config.port \u4E3A\u5FC5\u586B\u5B57\u6BB5\uFF08\u7F3A\u5931\uFF09" });
  } else if (typeof config.port !== "string") {
    errors.push({
      target: field("config.port"),
      message: `config.port \u5FC5\u987B\u4E3A**\u5B57\u7B26\u4E32**\uFF08\u5F53\u524D ${describe(config.port)}\uFF09\u2014\u2014\u7AEF\u53E3\u6309\u6587\u672C\u627F\u8F7D\uFF08\u73AF\u5883\u53D8\u91CF\u6CE8\u5165\u7684\u7AEF\u53E3\u672C\u5C31\u662F\u5B57\u7B26\u4E32\uFF09`
    });
  } else if (!isValidPortText(config.port)) {
    errors.push({
      target: field("config.port"),
      message: `config.port \u5FC5\u987B\u4E3A 1\u201365535 \u7684\u5341\u8FDB\u5236\u6574\u6570\u6587\u672C\uFF08\u5F53\u524D ${JSON.stringify(config.port)}\uFF09`
    });
  }
  if (config.password !== void 0 && typeof config.password !== "string") {
    errors.push({
      target: field("config.password"),
      message: `config.password \u5FC5\u987B\u4E3A\u5B57\u7B26\u4E32\uFF08\u5F53\u524D ${describe(config.password)}\uFF09\uFF1B\u65E0\u5BC6\u7801\u7528\u7A7A\u4E32`
    });
  }
  if (config.password === void 0) {
    errors.push({ target: field("config.password"), message: "config.password \u4E3A\u5FC5\u586B\u5B57\u6BB5\uFF08\u7F3A\u5931\uFF1B\u65E0\u5BC6\u7801\u7528\u7A7A\u4E32\uFF09" });
  }
  if (config.customSetting !== void 0) {
    if (typeof config.customSetting !== "string") {
      errors.push({
        target: field("config.customSetting"),
        message: `config.customSetting \u5FC5\u987B\u4E3A\u5B57\u7B26\u4E32\uFF08\u5F53\u524D ${describe(config.customSetting)}\uFF09`
      });
    } else if (config.customSetting.startsWith("&")) {
      warnings.push({
        target: field("config.customSetting"),
        message: `config.customSetting \u4E0D\u5E26\u524D\u5BFC "&"\uFF08\u5F53\u524D\u4EE5 "&" \u5F00\u5934\uFF0C\u6D88\u8D39\u65B9\u62FC\u63A5\u65F6\u4F1A\u5F97\u5230 "&&"\uFF09\u2014\u2014\u5F62\u5982 "sslmode=require&targetServerType=master"`
      });
    }
  }
  if (dbType !== void 0) {
    requireString(TARGET_KEY[dbType], { requireFilled: opts.requireFilled });
    for (const key of EXTRA_KEYS[dbType]) {
      if (key === "connectedMode") {
        const v = config.connectedMode;
        if (v === void 0) {
          errors.push({ target: field("config.connectedMode"), message: "config.connectedMode \u4E3A\u5FC5\u586B\u5B57\u6BB5\uFF08\u7F3A\u5931\uFF09" });
        } else if (typeof v !== "string" || !CONNECTED_MODES.includes(v)) {
          errors.push({
            target: field("config.connectedMode"),
            message: `config.connectedMode \u5FC5\u987B\u4E3A ${CONNECTED_MODES.join(" / ")} \u4E4B\u4E00\uFF08\u5F53\u524D ${JSON.stringify(v)}\uFF09`
          });
        }
      } else {
        requireString(key);
      }
    }
  } else {
    const hit = UNKNOWN_TYPE_PROBE_KEYS.some((key) => isNonEmptyString(config[key]));
    if (!hit) {
      errors.push({
        target: field(`config.${UNKNOWN_TYPE_PROBE_KEYS[0]}`),
        message: `databaseType=${JSON.stringify(type)} \u4E0D\u5728\u5951\u7EA6\u5DF2\u77E5\u5F62\u6001\uFF08${DATABASE_TYPES.join(" / ")}\uFF09\u5185\uFF0C\u65E0\u6CD5\u5224\u5B9A\u5176 config \u952E\u96C6\uFF1B\u4F46\u8FDE\u63A5\u76EE\u6807\u5B57\u6BB5\u5FC5\u586B\uFF08\u63A2\u6D4B\u952E\u96C6\uFF1A${UNKNOWN_TYPE_PROBE_KEYS.join(" / ")}\uFF0C\u987B\u4E3A**\u975E\u7A7A\u5B57\u7B26\u4E32**\uFF0C\u5F53\u524D\u5747\u672A\u547D\u4E2D\uFF09\u2014\u2014\u7F3A\u5B83\u65E0\u6CD5\u5EFA\u7ACB\u8FDE\u63A5`
      });
    }
  }
  if (typeof config.host === "string" && config.host.includes(":")) {
    warnings.push({
      target: field("config.host"),
      message: "config.host \u542B\u5192\u53F7\uFF08\u7591\u4F3C host:port \u5F62\u6001\uFF09\u2014\u2014\u7AEF\u53E3\u8BF7\u586B config.port\uFF1BIPv6 \u5B57\u9762\u91CF\u4EA6\u4F1A\u547D\u4E2D\u672C\u544A\u8B66"
    });
  }
  return { errors, warnings };
}
function validateDataSourcesFile(file, opts) {
  const errors = [];
  const warnings = [];
  if (file.schemaVersion !== 1) {
    errors.push({
      target: "schemaVersion",
      message: `\u672A\u77E5 schemaVersion\uFF08= ${JSON.stringify(file.schemaVersion)}\uFF09\uFF0C\u4EC5\u652F\u6301 1`
    });
  }
  const seen = /* @__PURE__ */ new Set();
  file.dataSources.forEach((entry, i) => {
    const report = validateEntry(entry, `dataSources[${i}]`, opts);
    errors.push(...report.errors);
    warnings.push(...report.warnings);
    if (isPlainObject(entry) && isNonEmptyString(entry.dataSourceName)) {
      if (seen.has(entry.dataSourceName)) {
        errors.push({
          target: `dataSources[${i}].dataSourceName`,
          message: `dataSourceName \u91CD\u590D\uFF1A${entry.dataSourceName}\uFF08\u6761\u76EE\u952E\u987B\u5168\u8868\u552F\u4E00\uFF09`
        });
      } else {
        seen.add(entry.dataSourceName);
      }
    }
  });
  return { errors, warnings };
}
function reportValidation({ errors, warnings }) {
  if (errors.length > 0) {
    process.stdout.write(`${JSON.stringify({ ok: false, errors })}
`);
    const summary = `\u6821\u9A8C\u5931\u8D25\uFF1A${errors.length} \u5904\u9519\u8BEF\uFF08\u9996\u5904\uFF1A${errors[0].target} ${errors[0].message}\uFF09`;
    process.stderr.write(`${summary}
`);
    log.error(summary);
    process.exit(EXIT.INVALID);
  }
  process.stdout.write(`${JSON.stringify({ ok: true, warnings })}
`);
}
function persist(cwd, file, action) {
  const startedAt = Date.now();
  try {
    atomicWriteDataSources(cwd, file);
  } catch (err) {
    log.error(`${action} \u843D\u76D8\u5931\u8D25\uFF1A${errMessage2(err)}`);
    throw err;
  }
  log.tool(`${action} \u2192 \u843D\u76D8 ${file.dataSources.length} \u6761\u6570\u636E\u6E90`, {
    exit: EXIT.OK,
    ms: Date.now() - startedAt
  });
}
function readOrEmpty(cwd) {
  return readDataSourcesFile(cwd) ?? emptyDataSources();
}
function cmdValidate(argv) {
  const { values, switches } = parseFlags(argv, "validate");
  const requireFilled = switches.requireFilled === true;
  if (values.entry !== void 0) {
    let parsed;
    try {
      parsed = JSON.parse(values.entry);
    } catch (err) {
      exitWith(EXIT.USAGE, `--entry \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage2(err)}`);
    }
    reportValidation(validateEntry(parsed, "", { requireFilled }));
    return EXIT.OK;
  }
  reportValidation(validateDataSourcesFile(readOrEmpty(workspaceRoot()), { requireFilled }));
  return EXIT.OK;
}
function cmdUpsert(argv) {
  const { values } = parseFlags(argv, "upsert");
  if (values.entry === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --entry");
  let parsed;
  try {
    parsed = JSON.parse(values.entry);
  } catch (err) {
    exitWith(EXIT.USAGE, `--entry \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage2(err)}`);
  }
  if (!isPlainObject(parsed)) {
    exitWith(EXIT.USAGE, "--entry \u5FC5\u987B\u4E3A\u5355\u4E2A\u6570\u636E\u6E90\u6761\u76EE\u5BF9\u8C61 JSON");
  }
  const entry = parsed;
  const errors = validateEntry(entry, "", { requireFilled: false }).errors;
  if (errors.length > 0) reportValidation({ errors, warnings: [] });
  const cwd = workspaceRoot();
  const file = readOrEmpty(cwd);
  file.dataSources = file.dataSources.filter((x) => x.dataSourceName !== entry.dataSourceName).concat([entry]);
  persist(cwd, file, `upsert dataSourceName=${entry.dataSourceName}`);
  process.stdout.write('{"ok":true}\n');
  return EXIT.OK;
}
function cmdGet(argv) {
  const { values } = parseFlags(argv, "get");
  const existing = readDataSourcesFile(workspaceRoot());
  const file = existing ?? emptyDataSources();
  if (values.name === void 0) {
    process.stdout.write(`${JSON.stringify(file)}
`);
    return EXIT.OK;
  }
  const entry = file.dataSources.find((x) => x.dataSourceName === values.name);
  if (entry === void 0) {
    exitWith(
      EXIT.NOT_FOUND,
      existing === null ? `\u6570\u636E\u6E90\u6587\u4EF6\u7F3A\u5931\uFF08.manifest/${DATASOURCES_FILE_NAME}\uFF09\uFF0C\u672A\u627E\u5230\uFF1A${values.name}` : `\u672A\u627E\u5230\u6570\u636E\u6E90\u6761\u76EE\uFF1A${values.name}`
    );
  }
  process.stdout.write(`${JSON.stringify(entry)}
`);
  return EXIT.OK;
}
function cmdDelete(argv) {
  const { values } = parseFlags(argv, "delete");
  if (values.name === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --name");
  const cwd = workspaceRoot();
  const existing = readDataSourcesFile(cwd);
  if (existing === null) {
    exitWith(EXIT.NOT_FOUND, `\u6570\u636E\u6E90\u6587\u4EF6\u7F3A\u5931\uFF08.manifest/${DATASOURCES_FILE_NAME}\uFF09\uFF0C\u65E0\u53EF\u5220\u9664\u6761\u76EE\uFF1A${values.name}`);
  }
  const file = existing;
  const hit = file.dataSources.some((x) => x.dataSourceName === values.name);
  if (!hit) exitWith(EXIT.NOT_FOUND, `\u672A\u627E\u5230\u6570\u636E\u6E90\u6761\u76EE\uFF1A${values.name}`);
  file.dataSources = file.dataSources.filter((x) => x.dataSourceName !== values.name);
  persist(cwd, file, `delete dataSourceName=${values.name}`);
  process.stdout.write('{"ok":true}\n');
  return EXIT.OK;
}
function cmdResolve(argv) {
  const { values } = parseFlags(argv, "resolve");
  if (values.name === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --name");
  const cwd = workspaceRoot();
  const existing = readDataSourcesFile(cwd);
  const file = existing ?? emptyDataSources();
  const entry = file.dataSources.find((x) => x.dataSourceName === values.name);
  if (entry === void 0) {
    exitWith(
      EXIT.NOT_FOUND,
      existing === null ? `\u6570\u636E\u6E90\u6587\u4EF6\u7F3A\u5931\uFF08.manifest/${DATASOURCES_FILE_NAME}\uFF09\uFF0C\u672A\u627E\u5230\uFF1A${values.name}` : `\u672A\u627E\u5230\u6570\u636E\u6E90\u6761\u76EE\uFF1A${values.name}`
    );
  }
  const config = entry.config;
  const realEndpoint = `${config.host}:${config.port}`;
  const got = runUdsMappingTool(cwd, realEndpoint, log);
  if (got.status === EXIT.NOT_FOUND) {
    exitWith(
      EXIT.NOT_FOUND,
      `\u6620\u5C04\u7F3A\u5931\uFF1A${realEndpoint} \u5728\u56DE\u73AF\u6620\u5C04\u8868\uFF08owner\uFF1Auds-mapping \u5951\u7EA6\uFF09\u4E2D\u65E0\u5BF9\u5E94\u6761\u76EE\uFF08\u6570\u636E\u6E90\u6761\u76EE ${values.name} \u5B58\u5728\uFF09\u2014\u2014\u5148\u5EFA\u6620\u5C04\uFF08map-ensure --real-endpoint\uFF09\u518D resolve`,
      { logError: true }
    );
  }
  if (got.status !== EXIT.OK) {
    exitWith(
      EXIT.FAILURE,
      `\u5144\u5F1F\u5DE5\u5177 uds-mapping-tool.mjs \u8C03\u7528\u5931\u8D25\uFF08resolve ${values.name}\uFF1B\u8DEF\u5F84 ${got.tool}\uFF09\uFF1A${renderToolFailure(got)}\u2014\u2014\u6620\u5C04\u8BFB\u53D6\u53EA\u80FD\u7ECF\u8BE5\u5DE5\u5177\uFF08\u4E0D\u5F97\u76F4\u8BFB uds-mappings.json\uFF09`
    );
  }
  const port = parseLoopbackPort(got.stdout);
  const resolved = {
    ...config,
    // ⛔ `databaseType` 是**条目级**字段（不在 `entry.config` 里），必须显式带上——只 spread
    // config 会把它丢掉，而准入放宽后消费方**必须**知道类型才能选 URL 模板 / driver
    // （loopbackHost / loopbackPort 只解决「连哪里」，不解决「怎么拼」）。设计 §3.5。
    //
    // 位置在 spread **之后**：条目级字段是权威，未知类型不检「禁多余字段」，config 里若
    // 混进同名键也不得覆盖它。
    databaseType: entry.databaseType,
    loopbackHost: "127.0.0.1",
    loopbackPort: port
  };
  process.stdout.write(`${JSON.stringify(resolved)}
`);
  return EXIT.OK;
}
function parseLoopbackPort(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    exitWith(EXIT.INVALID, `\u5144\u5F1F\u5DE5\u5177\u8F93\u51FA\u4E0D\u662F\u5408\u6CD5 JSON\uFF08${errMessage2(err)}\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`);
  }
  if (!isPlainObject(parsed)) {
    exitWith(EXIT.INVALID, `\u5144\u5F1F\u5DE5\u5177\u8F93\u51FA\u7ED3\u6784\u4E0D\u7B26\uFF08\u9700\u6620\u5C04\u6761\u76EE\u5BF9\u8C61\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`);
  }
  const port = parsed.loopbackPort;
  if (typeof port !== "number" || !Number.isInteger(port) || port <= 0 || port > 65535) {
    exitWith(
      EXIT.INVALID,
      `\u5144\u5F1F\u5DE5\u5177\u8F93\u51FA\u7684 loopbackPort \u975E\u6CD5\uFF08= ${JSON.stringify(port)}\uFF0C\u987B\u4E3A\u6B63\u6574\u6570\u4E14 \u2264 65535\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`
    );
  }
  return port;
}
function cmdRegisterPrepare(argv) {
  const { values } = parseFlags(argv, "register-prepare");
  if (values.type === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --type");
  if (values.slots === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --slots");
  const type = values.type;
  let slots;
  try {
    slots = JSON.parse(values.slots);
  } catch (err) {
    exitWith(EXIT.USAGE, `--slots \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage2(err)}`);
  }
  let ask;
  try {
    ask = buildDataSourceAskInput(type, slots).questions[0].input;
  } catch (err) {
    exitWith(EXIT.USAGE, `\u53C2\u6570\u975E\u6CD5\uFF08--type / --slots \u5F62\u6001\uFF09\uFF1A${errMessage2(err)}`);
  }
  const got = runPlatformTool(workspaceRoot(), ["is-database-type-supported", "--type", type], log);
  if (got.status !== EXIT.OK) {
    exitWith(
      EXIT.FAILURE,
      `\u5E73\u53F0\u5DE5\u5177 platform-tool.mjs \u8C03\u7528\u5931\u8D25\uFF08register-prepare \u24EA is-database-type-supported --type ${type}\uFF1B\u8DEF\u5F84 ${got.tool}\uFF09\uFF1A${renderToolFailure(got)}`
    );
  }
  const supported = parseSupportedFlag(got.stdout);
  if (!supported) {
    process.stdout.write(`${JSON.stringify({ ok: false, reason: "UNSUPPORTED_TYPE", type })}
`);
    return EXIT.OK;
  }
  process.stdout.write(`${JSON.stringify({ ok: true, ask })}
`);
  return EXIT.OK;
}
function cmdRegisterCommit(argv) {
  const { values } = parseFlags(argv, "register-commit");
  if (values.app === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --app");
  if (values.type === void 0) usage("\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --type");
  if (values.app === "") usage("--app \u4E0D\u5F97\u4E3A\u7A7A");
  if (values.type === "") usage("--type \u4E0D\u5F97\u4E3A\u7A7A");
  const app = values.app;
  const type = values.type;
  const cwd = workspaceRoot();
  let names;
  if (values.name !== void 0) {
    if (values.name === "") usage("--name \u4E0D\u5F97\u4E3A\u7A7A");
    names = [values.name];
  } else if (values.answer !== void 0) {
    names = parseAnswerDataSourceNames(values.answer);
  } else {
    usage(
      "\u7F3A\u5C11\u5FC5\u586B\u53C2\u6570 --name \u6216 --answer\uFF08\u4E8C\u9009\u4E00\uFF1A--answer \u4F20 dataSourceSelect \u7684\u7B54\u6848\u539F\u6587\uFF0C--name \u663E\u5F0F\u6307\u5B9A\u5355\u540D\uFF09"
    );
  }
  const entries = [];
  for (const name of names) {
    const fetched = fetchPlatformEntry(app, name);
    entries.push({
      dataSourceName: name,
      databaseType: type,
      databaseMode: fetched.databaseMode,
      config: fetched.config
    });
  }
  for (const entry of entries) {
    const errors = validateEntry(entry, "", { requireFilled: false }).errors;
    if (errors.length > 0) reportValidation({ errors, warnings: [] });
  }
  for (const entry of entries) {
    const config = entry.config;
    const realEndpoint = `${config.host}:${config.port}`;
    const got = runUdsMappingMapEnsure(cwd, realEndpoint, log);
    if (got.status !== EXIT.OK) {
      exitWith(
        EXIT.FAILURE,
        `\u5144\u5F1F\u5DE5\u5177 uds-mapping-tool.mjs \u8C03\u7528\u5931\u8D25\uFF08register-commit \u2466 map-ensure --real-endpoint ${realEndpoint}\uFF1B\u8DEF\u5F84 ${got.tool}\uFF09\uFF1A${renderToolFailure(got)}\u2014\u2014\u5148\u6620\u5C04\u540E\u5199\uFF1A\u6620\u5C04\u5931\u8D25\u5373\u4E2D\u65AD\uFF0C\u6761\u76EE\u4E0D\u843D\u76D8`
      );
    }
  }
  const file = readOrEmpty(cwd);
  const registered = new Set(names);
  file.dataSources = file.dataSources.filter((x) => !registered.has(x.dataSourceName)).concat(entries);
  persist(cwd, file, `register-commit ${entries.length} \u6761\uFF08${names.join("\u3001")}\uFF09`);
  const recheck = validateDataSourcesFile(file, { requireFilled: false });
  if (recheck.errors.length > 0) reportValidation(recheck);
  process.stdout.write(`${JSON.stringify({ ok: true, registered: names })}
`);
  return EXIT.OK;
}
function parseAnswerDataSourceNames(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    exitWith(EXIT.USAGE, `--answer \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errMessage2(err)}`);
  }
  if (isPlainObject(parsed) && Object.keys(parsed).length === 0) {
    exitWith(
      EXIT.INVALID,
      "--answer \u662F\u7A7A\u5BF9\u8C61\uFF08{}\uFF09\u2014\u2014\u8FD9\u662F ask \u53D6\u6D88/\u8D85\u65F6\u7684\u515C\u5E95\u7B54\u6848\u5F62\u6001\uFF08FALLBACK_ANSWER\uFF09\uFF0C\u4E0D\u4EE3\u8868\u7528\u6237\u7684\u9009\u62E9\uFF1B\u8C03\u7528\u65B9\u5E94\u5148\u8BC6\u522B\u53D6\u6D88\u5E76\u7EC8\u6B62\u6D41\u7A0B\uFF0C\u4E0D\u8981\u5BF9\u53D6\u6D88\u7B54\u6848\u63D0\u4EA4"
    );
  }
  if (!isPlainObject(parsed) || !Array.isArray(parsed.sources)) {
    exitWith(
      EXIT.INVALID,
      `--answer \u5F62\u6001\u8FDD\u7EA6\uFF1A\u987B\u4E3A dataSourceSelect \u7684\u7B54\u6848\u5BF9\u8C61 { sources: [{ title, dataSourceName }] }\uFF08\u539F\u6587\uFF1A${truncate(raw)}\uFF09`
    );
  }
  const sources = parsed.sources;
  if (sources.length === 0) {
    exitWith(EXIT.INVALID, "--answer.sources \u4E3A\u7A7A\u6570\u7EC4\u2014\u2014\u81F3\u5C11\u8981\u6709\u4E00\u4E2A\u69FD\u4F4D\u7684\u7B54\u6848");
  }
  const names = [];
  const seenTitles = /* @__PURE__ */ new Set();
  const seenNames = /* @__PURE__ */ new Set();
  sources.forEach((source, i) => {
    if (!isPlainObject(source)) {
      exitWith(EXIT.INVALID, `--answer.sources[${i}] \u5FC5\u987B\u4E3A\u5BF9\u8C61\uFF08{ title, dataSourceName }\uFF09`);
    }
    if (!isNonEmptyString(source.title)) {
      exitWith(
        EXIT.INVALID,
        `--answer.sources[${i}].title \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32\uFF08\u7B54\u6848\u6309\u69FD\u4F4D\u6807\u9898\u5BF9\u9F50\u7684\u952E\uFF09`
      );
    }
    if (seenTitles.has(source.title)) {
      exitWith(
        EXIT.INVALID,
        `--answer.sources[${i}].title \u91CD\u590D\uFF1A${source.title}\uFF08\u69FD\u4F4D\u6807\u9898\u5728\u540C\u4E00\u4E2A ask \u5185\u552F\u4E00\uFF0C\u7B54\u6848\u6309\u5B83\u5BF9\u9F50\uFF09`
      );
    }
    seenTitles.add(source.title);
    if (!isNonEmptyString(source.dataSourceName)) {
      exitWith(
        EXIT.INVALID,
        `--answer.sources[${i}].dataSourceName \u5FC5\u987B\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32\uFF08\u69FD\u4F4D\u300C${source.title}\u300D\u7684\u9009\u62E9\u7ED3\u679C\u7F3A\u5931\uFF09`
      );
    }
    if (!seenNames.has(source.dataSourceName)) {
      seenNames.add(source.dataSourceName);
      names.push(source.dataSourceName);
    }
  });
  return names;
}
function fetchPlatformEntry(app, name) {
  const got = runPlatformTool(
    workspaceRoot(),
    ["get-data-source-config", "--app", app, "--name", name],
    log
  );
  if (got.status === EXIT.NOT_FOUND) {
    exitWith(
      EXIT.NOT_FOUND,
      `\u5E73\u53F0\u672A\u547D\u4E2D\u6570\u636E\u6E90\u914D\u7F6E\uFF1A${name}\uFF08appId ${app}\uFF0C\u7ECF platform-tool get-data-source-config \u67E5\u8BE2\uFF09\u2014\u2014ask \u7B54\u6848\u6307\u5411\u5E73\u53F0\u4E0D\u5B58\u5728\u7684\u914D\u7F6E\uFF0C\u9700\u4EBA\u5DE5/\u7F16\u6392\u4ECB\u5165`,
      { logError: true }
    );
  }
  if (got.status !== EXIT.OK) {
    exitWith(
      EXIT.FAILURE,
      `\u5E73\u53F0\u5DE5\u5177 platform-tool.mjs \u8C03\u7528\u5931\u8D25\uFF08register-commit \u2463 get-data-source-config --app ${app} --name ${name}\uFF1B\u8DEF\u5F84 ${got.tool}\uFF09\uFF1A${renderToolFailure(got)}`
    );
  }
  let parsed;
  try {
    parsed = JSON.parse(got.stdout);
  } catch (err) {
    exitWith(EXIT.INVALID, `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u4E0D\u662F\u5408\u6CD5 JSON\uFF08${errMessage2(err)}\uFF1B\u539F\u6587\uFF1A${truncate(got.stdout)}\uFF09`);
  }
  if (!isPlainObject(parsed)) {
    exitWith(
      EXIT.INVALID,
      `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u7ED3\u6784\u4E0D\u7B26\uFF08\u9700 { config, databaseType, databaseMode } \u5BF9\u8C61\uFF1B\u539F\u6587\uFF1A${truncate(got.stdout)}\uFF09`
    );
  }
  const config = parsed.config;
  if (!isPlainObject(config)) {
    exitWith(
      EXIT.INVALID,
      `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u7684 config \u975E\u5BF9\u8C61\uFF08\u5F53\u524D ${describe(config)}\uFF1B\u539F\u6587\uFF1A${truncate(got.stdout)}\uFF09`
    );
  }
  const mode = parsed.databaseMode;
  if (!isNonEmptyString(mode) || !DATABASE_MODES.includes(mode)) {
    exitWith(
      EXIT.INVALID,
      `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u7684 databaseMode \u975E\u6CD5\uFF08= ${JSON.stringify(mode)}\uFF0C\u987B\u4E3A ${DATABASE_MODES.join(" / ")} \u4E4B\u4E00\uFF1Bnull = \u5E73\u53F0\u54CD\u5E94\u672A\u643A\u5E26\u8BE5\u5B57\u6BB5\uFF09\u2014\u2014${name}\uFF08appId ${app}\uFF09\u7684\u6761\u76EE\u65E0\u6CD5\u7EC4\u88C5`
    );
  }
  return { config, databaseMode: mode };
}
function parseSupportedFlag(raw) {
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    exitWith(EXIT.INVALID, `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u4E0D\u662F\u5408\u6CD5 JSON\uFF08${errMessage2(err)}\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`);
  }
  if (!isPlainObject(parsed)) {
    exitWith(EXIT.INVALID, `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u7ED3\u6784\u4E0D\u7B26\uFF08\u9700 { supported } \u5BF9\u8C61\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`);
  }
  const supported = parsed.supported;
  if (typeof supported !== "boolean") {
    exitWith(
      EXIT.INVALID,
      `\u5E73\u53F0\u5DE5\u5177\u8F93\u51FA\u7684 supported \u975E\u6CD5\uFF08= ${JSON.stringify(supported)}\uFF0C\u987B\u4E3A boolean\uFF1B\u539F\u6587\uFF1A${truncate(raw)}\uFF09`
    );
  }
  return supported;
}
function guarded(fn) {
  return (argv) => {
    try {
      return fn(argv);
    } catch (err) {
      if (err instanceof DataSourcesFileError || err instanceof DataSourcesWriteError) {
        exitWith(err.exitCode, err.message);
      }
      throw err;
    }
  };
}
var SUBCOMMANDS = {
  validate: guarded(cmdValidate),
  upsert: guarded(cmdUpsert),
  get: guarded(cmdGet),
  delete: guarded(cmdDelete),
  resolve: guarded(cmdResolve),
  "register-prepare": guarded(cmdRegisterPrepare),
  "register-commit": guarded(cmdRegisterCommit)
};
function describe(v) {
  if (Array.isArray(v)) return "array";
  if (v === null) return "null";
  return `${typeof v}\uFF08${JSON.stringify(v)}\uFF09`;
}
function renderToolFailure(got) {
  return got.status === null ? got.spawnError instanceof Error ? got.spawnError.message : String(got.spawnError ?? "\u65E0\u9000\u51FA\u7801\uFF08spawn \u5931\u8D25\u6216\u8D85\u65F6\uFF09") : `\u9000\u51FA\u7801 ${got.status}${firstLine(got.stderr) === "" ? "" : `\uFF1A${firstLine(got.stderr)}`}`;
}
function errMessage2(err) {
  return err instanceof Error ? err.message : String(err);
}
function firstLine(text) {
  const line = (text ?? "").split("\n").find((l) => l.trim() !== "");
  return line === void 0 ? "" : line.trim();
}
function truncate(raw) {
  return raw.length <= 200 ? raw : `${raw.slice(0, 200)}\u2026(\u5171 ${raw.length} \u5B57\u7B26)`;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/datasource/cli.mts
function main() {
  const [sub, ...rest] = process.argv.slice(2);
  const handler = sub !== void 0 && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, sub) ? SUBCOMMANDS[sub] : void 0;
  if (handler === void 0) {
    console.error(`\u672A\u77E5\u5B50\u547D\u4EE4\uFF1A${sub ?? "(\u65E0)"}\uFF1B\u53EF\u7528\uFF1A${Object.keys(SUBCOMMANDS).join(", ")}`);
    process.exit(2);
  }
  process.exit(handler(rest));
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  main();
}
export {
  SUBCOMMANDS
};
