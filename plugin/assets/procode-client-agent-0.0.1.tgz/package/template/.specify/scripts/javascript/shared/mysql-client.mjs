/**
 * 数据源解析的共享模块（无顶层副作用，供 sql-exec.mjs / extract-code-schema.mjs /
 * check-code-table-inventory.mjs import）。
 *
 * 口径（plan 2026-11-09 incremental-database-mcp-only-and-local-debug D1–D3、§5.1）：
 * 数据库访问统一经平台 MCP。本模块只把**已确认数据源契约条目**翻译成 MCP 请求上下文
 * （`dataSourceName` / `databaseType` / 目标库 / `appId`），**不**产出 host/port/username/password，
 * 不调用 `datasource-tool.mjs resolve`，不要求 `uds-mappings.json` 存在。
 * 本地调试由显式启动入口（SPECKIT_LOCAL_MOCK=1）启动本地 MCP 并注入 endpoint，
 * 不在这里创建第二条数据库连接通道。
 *
 * 约定：所有函数显式接收 ds，不依赖模块级可变状态 / process.argv。
 *
 * 变更史（plan 2026-09-21 §B5 rev2）：原 `resolveDatasource`（读 application.yml 判方言+解析
 * 连接）已删除——唯一消费方 check-backend-startup.mjs 的 SQL 冒烟层迁出。
 *
 * 变更史（plan 2026-11-04 local-MySQL-channel-retirement）：删除 MySQL 本地直连驱动函数。
 *
 * 变更史（plan 2026-11-09 incremental-database-mcp-only-and-local-debug）：删除
 * `datasource-tool.mjs resolve` 回环映射与账号/密码要求；两个 resolver 复用同一
 * 契约条目 → MCP 请求上下文实现；`channel` 只允许 mcp，local 确定性拒绝。
 */

import { existsSync, readFileSync } from 'fs';
import { resolve } from 'path';

/**
 * 已确认数据源契约文件：`$HOME/resources/.manifest/datasources.json`。
 * 条目身份 = `dataSourceName`（契约 `DataSource` 无第二 id 字段）。
 */
const DATASOURCES_CONTRACT_REL = ['resources', '.manifest', 'datasources.json'];

function pickText(value) {
  return typeof value === 'string' ? value.trim() : value == null ? '' : String(value).trim();
}

/**
 * 读 `$HOME/resources/.manifest/datasources.json`（只读，不写）。
 * 返回 {state:'missing'|'invalid'|'present', path, entries?, error?}。
 */
function readConfirmedDatasourcesContract(home = process.env.HOME) {
  const homeDir = pickText(home);
  const file = homeDir
    ? resolve(homeDir, ...DATASOURCES_CONTRACT_REL)
    : resolve(...DATASOURCES_CONTRACT_REL); // HOME 缺失时给出相对定位，仅用于错误信息
  if (!homeDir) return { state: 'invalid', path: file, error: 'HOME 未设置，无法定位 $HOME/resources/.manifest/datasources.json' };
  if (!existsSync(file)) return { state: 'missing', path: file };
  let doc;
  try {
    doc = JSON.parse(readFileSync(file, 'utf-8'));
  } catch (e) {
    return { state: 'invalid', path: file, error: `不是合法 JSON：${e && e.message ? e.message : String(e)}` };
  }
  if (doc == null || typeof doc !== 'object' || Array.isArray(doc)) {
    return { state: 'invalid', path: file, error: '结构不符（需 { schemaVersion, dataSources } 对象）' };
  }
  if (!Array.isArray(doc.dataSources)) {
    return { state: 'invalid', path: file, error: '结构不符（dataSources 必须为数组）' };
  }
  if (doc.schemaVersion !== 1) {
    return { state: 'invalid', path: file, error: `schemaVersion 未知（=${JSON.stringify(doc.schemaVersion)}），仅支持 1` };
  }
  if (doc.dataSources.some((item) => item == null || typeof item !== 'object' || Array.isArray(item))) {
    return { state: 'invalid', path: file, error: '结构不符（dataSources 条目必须为对象）' };
  }
  return { state: 'present', path: file, entries: doc.dataSources };
}

/** 契约条目的连接目标字段：Oracle 用 connectionTarget，其余类型用 database（与 datasource-tool TARGET_KEY 同构）。 */
function contractTargetKey(databaseType) {
  const t = pickText(databaseType).toLowerCase();
  if (t.includes('oracle') || t === 'ora') return 'connectionTarget';
  return 'database';
}

/** appId 只取显式参数与沙箱平台环境来源，无默认值回退。 */
function resolveAppId(explicit) {
  return (
    pickText(explicit) ||
    pickText(process.env.APP_ID) ||
    pickText(process.env.LCAP_APP_ID) ||
    pickText(process.env.NASL_STORAGE_APP_ID)
  );
}

/**
 * 通道校验：只允许 mcp。`local` 已退役（确定性文案）；其他值 fail-loud，不静默改写。
 * 未传 channel 视为 mcp（兼容旧调用方）。
 */
function checkChannel(channel) {
  const value = pickText(channel);
  if (!value || value === 'mcp') return { ok: true };
  if (value === 'local') return { ok: false, reason: 'local 通道已退役，请经 MCP 重新采集' };
  return { ok: false, reason: `未知通道 "${value}"：只允许 mcp（local 通道已退役）` };
}

// ─────────────────────────────────────────────────────────────────────────────
// 唯一解析：契约条目 → MCP 请求上下文。
//
// 采集（resolveIncrementalDatasource）与执行（resolveExecDatasource）复用本实现，
// 不新增第二套连接目标推断。请求上下文**不含**用户名、密码与回环地址。
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @param {string} name 已确认 dataSourceName（契约条目名）
 * @param {string} [appIdExplicit] 显式 appId（缺省走平台 env 来源）
 * @returns {{ok:true, ds:{dataSourceName:string,databaseType:string,db:string,appId:string}}
 *   | {ok:false, reason:string}}
 */
function resolveContractDatasource(name, appIdExplicit) {
  if (!name) {
    return { ok: false, reason: '缺已确认 dataSourceName（绑定 envelope/显式参数）——禁止以默认实例采集' };
  }
  const contract = readConfirmedDatasourcesContract();
  if (contract.state === 'missing') {
    return { ok: false, reason: `缺数据源契约 ${contract.path}（坐标只认已确认条目，禁回退默认连接值）` };
  }
  if (contract.state === 'invalid') {
    return { ok: false, reason: `数据源契约不可用（${contract.path}）：${contract.error}` };
  }
  const entry = contract.entries.find((item) => item.dataSourceName === name) || null;
  if (!entry) {
    return { ok: false, reason: `未找到已确认数据源条目 dataSourceName="${name}"（${contract.path}）` };
  }

  const databaseType = pickText(entry.databaseType);
  const config =
    entry.config != null && typeof entry.config === 'object' && !Array.isArray(entry.config) ? entry.config : {};
  const targetKey = contractTargetKey(databaseType);
  const db = pickText(config[targetKey]);
  const appId = resolveAppId(appIdExplicit);

  const issues = [];
  if (!databaseType) issues.push(`契约条目 dataSourceName="${name}" 缺 databaseType`);
  if (!db) issues.push(`契约条目 dataSourceName="${name}" 缺连接目标库（config.${targetKey}）`);
  if (!appId) issues.push('mcp 通道缺 appId（无法定位远端应用）');
  if (issues.length > 0) return { ok: false, reason: issues.join('；') };

  return { ok: true, ds: { dataSourceName: name, databaseType, db, appId } };
}

/**
 * 增量微服务（platform micro incremental）严格数据源解析。
 *
 * 背景（FZ-08 / A §3.3-§3.4 / F3 G-08、G-17、A03）：micro 写侧按 P3 改裁不再写
 * `plans/db-config.json`（该产物已随 plan 2026-11-04 退役），坐标只住契约条目；
 * envelope 只留 `entryRef` 指针。因此：
 *   - **不读**已退役的 db-config 产物、**不读** `SQL_EXEC_DB_*` 环境覆盖；
 *   - 不使用 root/127.0.0.1 等硬默认地址，也不做 mcp→local 静默回退；
 *   - 缺已确认 dataSourceName / 契约缺失 / 条目字段不全 ⇒ 显式失败，不回退默认连接值。
 *
 * `channel` 保留接收以兼容调用方，但只允许 mcp；`local` 返回确定性退役文案。
 *
 * @param {string} _workdir 保留旧调用签名；本函数不从工程目录探测 db-config
 * @param {{dataSourceName?: string, channel?: 'mcp'|'local', appId?: string}} opts
 * @returns {{ok:true, ds:object} | {ok:false, reason:string}}
 */
export function resolveIncrementalDatasource(_workdir, opts = {}) {
  const channel = checkChannel(opts.channel);
  if (!channel.ok) return { ok: false, reason: channel.reason };

  const dataSourceName = pickText(opts.dataSourceName);
  const resolved = resolveContractDatasource(dataSourceName, opts.appId);
  if (!resolved.ok) {
    return {
      ok: false,
      reason: `增量 micro 数据源收口拒绝：${resolved.reason}。SQL_EXEC_DB_* 环境变量不改变目标；不得回退默认连接值。`,
    };
  }
  return { ok: true, ds: resolved.ds };
}

/**
 * sql-exec 执行数据源 resolver（plan 2026-11-04/retire-db-config-json-artifact §3）。
 *
 * 与 {@link resolveIncrementalDatasource} 复用同一契约条目 → MCP 请求上下文实现。
 *   - `dataSourceName` 必须显式传入；缺失即失败，不回退默认。
 *   - db = 契约条目连接目标字段（`config.database` 或 Oracle `config.connectionTarget`）。
 *   - appId = 显式参数 / 沙箱平台环境来源（MCP 通道必填）。
 *
 * fail-loud：任一必需字段缺失（dataSourceName / 契约条目 / databaseType / 目标库 / appId）
 * 时返回带 `error` 的对象——**不读** `SQL_EXEC_DB_*`、**不读** `plans/db-config.json`、
 * **不注入** root/root、127.0.0.1:3306 等默认值。
 *
 * @param {string} _workdir 保留旧调用签名；契约坐标不再从工程目录探测
 * @param {string|undefined} dataSourceName
 * @returns {{dataSourceName:string,databaseType:string,db:string,appId:string,error?:string}}
 */
export function resolveExecDatasource(_workdir, dataSourceName) {
  const name = pickText(dataSourceName);
  const appId = resolveAppId();
  if (!name) {
    return {
      dataSourceName: '',
      databaseType: '',
      db: '',
      appId,
      error:
        '缺显式 dataSourceName（契约条目名）——不回退 db-config/默认库，调用方须从 binding/契约/问询结果传入',
    };
  }
  const resolved = resolveContractDatasource(name, appId);
  if (!resolved.ok) {
    return { dataSourceName: name, databaseType: '', db: '', appId, error: resolved.reason };
  }
  return resolved.ds;
}
