import fs from 'fs';
import path from 'path';

import {
  PENDING,
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  readRawSpecContentSync,
  getRawSpecRelativeFilePath,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  writeToFileSync,
  writeQuoteToContent,
  formatWritedFiles,
  parseQuote,
  parseToList,
  parseToTable,
  parseEn,
  parseStemFromPath,
  auto,
} from './shared/index.mjs';

export const findHidden = (item) => item.endsWith('pieces/hidden.md');
export const findQuotes = (item) => item.endsWith('pieces/quotes.md');
export const filterPoints = (item) => item.includes('pieces/point-');
export const filterIgnored = (item) => item.includes('pieces/ignored-');

export const getIgnoredParts = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const options = { rootDir };
  const parseList = parseToList(options);

  const quotesBundle = findUnderSpecs(rootDir)(findQuotes);

  if (!quotesBundle?.absoluteFilePath) {
    const activeSpecDir = getActiveSpecDir(rootDir);
    throw new Error(`缺少原始引用文档：${activeSpecDir}/pieces/quotes.md`);
  }

  const specContent = readRawSpecContentSync(rootDir);
  const quotesContent = readFileSync(quotesBundle.absoluteFilePath);

  const parsedQuotes = parseList(quotesContent) || [];

  const strings = specContent.split('\n');
  const ignoreParts = strings.map((content) => ({ content }));

  const quotes = parsedQuotes.reduce((result = [], item = {}) => {
    const { children = [] } = item;

    return children.reduce((merged = [], current = {}) => {
      const { content = '' } = current;

      const parsed = parseQuote(content) || [];

      return [...merged, ...parsed];
    }, result);
  }, []);

  quotes.forEach((item = {}) => {
    const { range = [] } = item;
    const [start = 0, end = 0] = range;

    const sliced = ignoreParts.slice(start - 1, end);

    sliced.forEach((current) => (current.matched = true));
  });

  return ignoreParts;
};

export const toIgnore = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const activeSpecDir = getActiveSpecDir(rootDir);

  const specContent = readRawSpecContentSync(rootDir);
  const rawSpecRelativeFilePath = getRawSpecRelativeFilePath(rootDir);

  const ranges = [];
  const strings = specContent.split('\n');
  const ignoreParts = getIgnoredParts(rootDir);

  ignoreParts.forEach((item = {}, index) => {
    const { matched } = item;

    const line = index + 1;
    const prev = ignoreParts[index - 1];
    const next = ignoreParts[line];

    if (matched) {
      return;
    }

    if (!prev || prev?.matched) {
      ranges.push([line, line]);
    } else {
      const { length } = ranges;
      const last = ranges[length - 1];

      last[1] = line;
    }
  });

  const messages = ['- **忽略内容**：'];

  ranges.forEach((item = []) => {
    const [start, end] = item;

    const single = start === end;
    const line = strings[start - 1] || '';
    const valuable = line.replace(/\s/g, '');
    const useless = single && !valuable;

    if (useless) {
      return;
    }

    const rangeString = `L${start},${end}`;
    const string = `  - **[${rangeString}](${rawSpecRelativeFilePath}#${rangeString})**`;

    messages.push(string);
  });

  const ignoredQuotesRelativeFilePath = 'pieces/ignored-quotes.md';
  const ignoredQuotesAbsoluteFilePath = path.resolve(activeSpecDir, ignoredQuotesRelativeFilePath);

  const ignoredContentRelativeFilePath = 'pieces/ignored-content.md';
  const ignoredContentAbsoluteFilePath = path.resolve(activeSpecDir, ignoredContentRelativeFilePath);

  const ignoredQuotesFile = writeToFileSync('忽略内容-原始引用', ignoredQuotesAbsoluteFilePath, '\n')(messages);
  const ignoredContentFile = writeQuoteToContent(rootDir, '忽略内容-原始内容')(
    ignoredQuotesAbsoluteFilePath,
    ignoredContentAbsoluteFilePath
  );

  return [ignoredQuotesFile, ignoredContentFile];
};

export const getDescriptionFromHidden = (rootDir) => {
  const { absoluteDir: hiddenAbsoluteDir, absoluteFilePath: hiddenAbsoluteFilePath } =
    findUnderSpecs(rootDir)(findHidden) || {};

  const store = {};
  const source = readFileSync(hiddenAbsoluteFilePath);
  const matched = source?.match?.(/\n\-[^\n]+/g) || [];

  matched.forEach((item = '') => {
    const getText = getTextInBetween(item);
    const got = getText('**', '**：') || getText('-', '：');
    const key = got.replace(/\s/g, '');
    const [, descritpion] = item.split('：');

    if (!key || !descritpion) {
      return;
    }

    store[key] = descritpion;
  });

  return (key = '') => {
    const [last = ''] = key.match(/(?<=\-)[^\-]+$/g) || [];
    const got = store[key] || store[last];

    if (got) {
      return got;
    }

    const find = (item) => item?.includes?.(key);
    const keys = Object.keys(store);
    const found = keys.find(find);

    return found?.descritpion;
  };
};

export const toConverage = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const options = { rootDir };
  const parseList = parseToList(options);
  const getDescription = getDescriptionFromHidden(rootDir);

  const activeSpecDir = getActiveSpecDir(rootDir);
  const pointBundles = filterUnderSpecs(rootDir)(filterPoints);

  return pointBundles.map((bundle = {}) => {
    const { absoluteFilePath } = bundle;

    const content = readFileSync(absoluteFilePath);
    const parsed = parseList(content) || [];
    const name = parseStemFromPath(absoluteFilePath);

    const messages = ['# 关联主题'];

    parsed.forEach((item = {}) => {
      const { title = '', content = '' } = item;

      const got = getDescription(title) || '';
      const descritpion = (() => {
        if (title === '视觉规范、页面组件') {
          return '<!-- **特别注意/Important**：视觉规范、页面组件 只允许匹配整体视觉规范、通用页面布局、通用页面结构、通用页面组件、通用交互样式、跨页面可复用的展示规范。同时，凡是原始需求、补充材料、页面规范中已经明确出现的主流设计稿地址（如 MasterGo、Figma 等），也必须提取到这里，并视为设计规范的一部分。禁止把某个底层功能节点、某个功能模块明细、某个单独业务页面的局部逻辑、某个业务流程步骤、某个具体功能操作说明、某个具体功能的（样式、布局、组件、展示、交互规范），当成 视觉规范、页面组件 的关联段落。禁止包含任何流程图、软件工程、系统架构 等相关内容。 -->';
        }

        return (
          got &&
          `<!-- ${title} 包含以下子功能：${got}。必须重点找到每个子功能对应的关联段落，禁止遗漏任何子功能对应的关联段落。 -->`
        );
      })();

      const more = '  - [根据 忽略内容-原始内容 内容匹配补充关联段落]';
      const parts = [descritpion, content, more];
      const merged = parts.join('\n');

      messages.push(merged);
    });

    const targetRelativeFilePath = `pieces/ignored-point-${name}.md`;
    const targetAbsoluteFilePath = path.resolve(activeSpecDir, targetRelativeFilePath);

    const suffix = name === 'design' ? '' : PENDING;

    return writeToFileSync(`忽略内容-业务引用-${name}`, targetAbsoluteFilePath)(messages, suffix);
  });
};

export const polyfillForQuotes = (rootDir) => {
  const found = findUnderSpecs(rootDir)(findQuotes);

  if (found) {
    return;
  }

  const pointBundles = filterUnderSpecs(rootDir)(filterPoints);
  const map = (item) => readFileSync(item.absoluteFilePath);
  const source = pointBundles.map(map).join('\n\n');
  const replaced = source.replace(/(^|\n)\#[^\n]+/g, '');

  const activeSpecDir = getActiveSpecDir(rootDir);
  const relativeFilePath = 'pieces/quotes.md';
  const absoluteFilePath = path.resolve(activeSpecDir, relativeFilePath);

  writeToFileSync('xxx', absoluteFilePath)('# 原始引用', replaced);
};

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  polyfillForQuotes(rootDir);
  removeUnderSpecs(rootDir)(filterIgnored);

  const parts = getIgnoredParts(rootDir) || [];
  const everyForMatch = (item) => item.matched;
  const everyForContent = (item) => !item.content.trim();
  const every = (item) => everyForMatch(item) || everyForContent(item);
  const full = parts.every(every);

  if (full) {
    return '原始需求文档已完全覆盖，不需要再执行后续流程，直接执行后置操作';
  }

  const ignore = toIgnore(rootDir);
  const converage = toConverage(rootDir);
  const source = [ignore, converage];
  const files = source.flat().filter(Boolean);

  return formatWritedFiles('覆盖率文档列表')(files);
};

auto(import.meta)(toRaw);
export default toRaw;
