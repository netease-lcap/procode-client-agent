/**
 * 需求快照（requirement snapshot）唯一实现。
 *
 * 职责：按阶段声明输入清单、计算确定性指纹、幂等落盘阶段上下文。
 * 快照**只做提示**——给 agent 一个判据「本轮是同一轮重试，还是输入已经换了」：
 *   - 不读、不写澄清台账（clarify-decisions.json）；不轮转 `.prev`、不置 `pendingReview`；
 *   - context 缺失/损坏/算法版本不符/作用域不符 ⇒ 视为需要重写，绝不 throw；
 *   - 唯一硬失败是写盘失败（`SnapshotError('write-failed')`）；参数非法抛 `bad-args`。
 *     快照不是门：调用方拿到失败只应记录，不得据此断链。
 *
 * 关键口径：
 *   - 输入按 id 升序；`path` 是相对 specDir 的 POSIX 路径；软输入缺席也登记
 *     （present:false + 空内容），因此「缺席 → 出现」会改变指纹。
 *   - 必需输入（inputs/spec.txt）缺席同样只登记 present:false——缺需求不是失败。
 *   - 目录库存每轮重新枚举（新增/删除 checklist 通过 id 变化参与 hash）；
 *     库存不可读按空库存处理（同上：不把读失败升级成门）。
 *   - hash = sha256(`algorithmVersion\0stage\0scenario\0` +
 *     每个输入 `id\0present\0content\0`)，内容一律按 UTF-8。
 *   - 落盘使用临时文件 + rename 原子替换；同 spec+stage 用 `<contextPath>.lock` 独占串行（无重试）。
 *   - 不读执行时间、日志、运行状态、本轮下游产物；不泛化删除所有时间字段。
 *
 * 阶段输入（D3：只投影需求侧；设计产物与后续波会合法回写的字段一律不进指纹，
 * 否则正常产出会改变自己的指纹、制造假变化）：
 *   两侧共同：input:spec、spec:checklist:<basename>、spec:terms、
 *             piece:tech、piece:ui-design。
 *   outline 另收：spec:application-manual（可选）、
 *                 knowledge:pre-clarify-stack（存在且非空且无缺席标记才算有效）。
 *   backend-design 另收：incremental 时 plan:inventory-baseline（原文）。
 *   明确不读：plans/domain.json、plans/tech-stack.json、
 *             plans/backend/_meta/architecture.json（设计产物）、
 *             clarify-decisions.json、coverage/、fragments/、README、
 *             dispatch-wave-state.json 及任何 _meta 执行时间。
 *
 * 派发态（plans/backend/_meta/dispatch-wave-state.json）只做最小维护：
 * 缺失 ⇒ 写最小映射；可读 ⇒ 只更新 requirementSnapshot（其余键逐字保留）；
 * 不可读 ⇒ 保留现场并以 `note` 上报，不覆盖。
 */

import { createHash } from 'crypto';
import fs from 'fs';
import path from 'path';

export const ALGORITHM_VERSION = 'requirement-snapshot/v1';
export const SNAPSHOT_STAGES = ['outline', 'backend-design'];
export const SNAPSHOT_SCENARIOS = ['fresh', 'incremental', 'free'];
export const SNAPSHOT_CONTEXT_REL = {
  outline: 'plans/_meta/tech-clarify-context.json',
  'backend-design': 'plans/backend/_meta/requirement-snapshot.json',
};

const PRE_CLARIFY_KNOWLEDGE_REL = 'knowledge/external/pre-clarify-stack.md';
const PRE_CLARIFY_ABSENT_MARKER = '外部知识缺席';
const STATE_REL = 'plans/backend/_meta/dispatch-wave-state.json';
const DEFAULT_BASELINE_REL = 'plans/backend/_meta/inventory-baseline.json';
const SNAPSHOT_HEX_RE = /^[0-9a-f]{64}$/;

/** 结构化失败：CLI 依据 code 生成 `{ ok:false, error:{ code, message, detail? } }`。 */
export class SnapshotError extends Error {
  constructor(code, message, detail) {
    super(message);
    this.name = 'SnapshotError';
    this.code = code;
    this.detail = detail;
  }
}

const sha256 = (content) => createHash('sha256').update(content, 'utf8').digest('hex');
const byId = (a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);

function assertStage(stage) {
  if (!SNAPSHOT_STAGES.includes(stage)) {
    throw new SnapshotError('bad-args', `unknown stage "${stage}" (expected one of: ${SNAPSHOT_STAGES.join(', ')})`);
  }
}

function assertScenario(scenario) {
  if (!SNAPSHOT_SCENARIOS.includes(scenario)) {
    throw new SnapshotError('bad-args', `unknown scenario "${scenario}" (expected one of: ${SNAPSHOT_SCENARIOS.join(', ')})`);
  }
}

function assertScope(stage, scenario) {
  assertStage(stage);
  assertScenario(scenario);
}

function assertSpecDir(specDir) {
  if (typeof specDir !== 'string' || specDir.trim() === '' || !path.isAbsolute(specDir)) {
    throw new SnapshotError('bad-args', 'specDir must be an absolute path');
  }
}

function contextPathFor(specDir, stage) {
  return path.join(specDir, ...SNAPSHOT_CONTEXT_REL[stage].split('/'));
}

function relativeAbs(specDir, rel) {
  return path.join(specDir, ...rel.split('/'));
}

function listChecklistFiles(specDir) {
  const specsDir = path.join(specDir, 'specs');
  let entries;
  try {
    entries = fs.readdirSync(specsDir, { withFileTypes: true });
  } catch {
    // 库存不可读 = 本轮无 checklist 输入；快照只做提示，不把读失败升级成门。
    return [];
  }
  return entries
    .filter((entry) => (entry.isFile() || entry.isSymbolicLink()) && entry.name.startsWith('checklist-') && entry.name.endsWith('.md'))
    .map((entry) => entry.name)
    .sort();
}

/**
 * 读取一个普通文件输入。缺席或不可读一律登记 present:false + 空内容：
 * 快照只用于提示，读不到文件（含必需输入）不构成失败。
 */
function readPlainInput(specDir, id, rel) {
  const abs = relativeAbs(specDir, rel);
  let present = false;
  let content = '';

  try {
    content = fs.readFileSync(abs, 'utf8');
    present = true;
  } catch {
    present = false;
    content = '';
  }

  return { id, path: rel, present, sha256: sha256(content), content };
}

/**
 * outline 的 pre-clarify 外部知识输入：只有「存在 + trim 后非空 + 不含缺席标记」才是有效输入；
 * 其余情况仍登记 present:false + 空内容，确保知识到达会改变指纹。
 */
function readPreClarifyKnowledgeInput(specDir) {
  const abs = relativeAbs(specDir, PRE_CLARIFY_KNOWLEDGE_REL);
  let present = false;
  let content = '';

  let raw = null;
  try {
    raw = fs.readFileSync(abs, 'utf8');
  } catch {
    raw = null;
  }
  if (typeof raw === 'string' && raw.trim() !== '' && !raw.includes(PRE_CLARIFY_ABSENT_MARKER)) {
    present = true;
    content = raw;
  }

  return {
    id: 'knowledge:pre-clarify-stack',
    path: PRE_CLARIFY_KNOWLEDGE_REL,
    present,
    sha256: sha256(content),
    content,
  };
}

/**
 * 按阶段收集输入清单。
 *
 * @returns {{ inputs: Array<{id:string,path:string,present:boolean,sha256:string,content:string}> }}
 *   inputs 按 id 升序；content 仅内部 hash 使用，落盘/输出时用 publicInputs 去掉。
 *   缺席输入同样登记（present:false），故「缺席 → 出现」会改变指纹。
 */
export function collectStageInputs({ specDir, stage, scenario }) {
  assertScope(stage, scenario);
  assertSpecDir(specDir);

  const inputs = [];

  inputs.push(readPlainInput(specDir, 'input:spec', 'inputs/spec.txt'));

  for (const name of listChecklistFiles(specDir)) {
    inputs.push(readPlainInput(specDir, `spec:checklist:${name}`, `specs/${name}`));
  }

  inputs.push(readPlainInput(specDir, 'spec:terms', 'specs/terms.md'));

  if (stage === 'outline') {
    inputs.push(readPlainInput(specDir, 'spec:application-manual', 'specs/application-manual.md'));
  }

  inputs.push(readPlainInput(specDir, 'piece:tech', 'pieces/tech.md'));
  inputs.push(readPlainInput(specDir, 'piece:ui-design', 'pieces/ui-design.md'));

  if (stage === 'outline') {
    inputs.push(readPreClarifyKnowledgeInput(specDir));
  } else if (scenario === 'incremental') {
    inputs.push(readPlainInput(specDir, 'plan:inventory-baseline', 'plans/backend/_meta/inventory-baseline.json'));
  }

  inputs.sort(byId);
  return { inputs };
}

function hashInputs({ stage, scenario, inputs }) {
  const hash = createHash('sha256');
  hash.update(`${ALGORITHM_VERSION}\0${stage}\0${scenario}\0`, 'utf8');
  for (const input of [...inputs].sort(byId)) {
    hash.update(`${input.id}\0${input.present}\0${input.content}\0`, 'utf8');
  }
  return hash.digest('hex');
}

/** 计算当前输入的确定性指纹与输入清单（ensure 复用同一实现，禁第二份算法）。 */
export function computeSnapshotDetails({ specDir, stage, scenario }) {
  const collected = collectStageInputs({ specDir, stage, scenario });
  return {
    requirementSnapshot: hashInputs({ stage, scenario, inputs: collected.inputs }),
    inputs: collected.inputs,
  };
}

/** 落盘/输出用输入清单：去掉仅供 hash 的 content。 */
export function publicInputs(inputs) {
  return inputs.map(({ id, path: relPath, present, sha256: digest }) => ({ id, path: relPath, present, sha256: digest }));
}

function isValidSnapshotContext(value) {
  return Boolean(
    value &&
      typeof value === 'object' &&
      !Array.isArray(value) &&
      typeof value.algorithmVersion === 'string' &&
      typeof value.stage === 'string' &&
      typeof value.scenario === 'string' &&
      typeof value.requirementSnapshot === 'string' &&
      SNAPSHOT_HEX_RE.test(value.requirementSnapshot),
  );
}

/** 阶段上下文的绝对路径。 */
export function snapshotContextPath({ specDir, stage }) {
  assertStage(stage);
  assertSpecDir(specDir);
  return contextPathFor(specDir, stage);
}

/**
 * 读取阶段上下文（宽容）：文件不存在、不可解析或形状非法一律返回 null。
 * 调用方据此判断「本轮标识不可用」；快照已不是门，读不到不等于失败。
 */
export function readSnapshotContext({ specDir, stage }) {
  const contextPath = snapshotContextPath({ specDir, stage });
  let context;
  try {
    context = JSON.parse(fs.readFileSync(contextPath, 'utf8'));
  } catch {
    return null;
  }
  return isValidSnapshotContext(context) ? context : null;
}

function atomicWrite(target, data) {
  try {
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const tmp = `${target}.tmp-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    try {
      fs.writeFileSync(tmp, data);
      fs.renameSync(tmp, target);
    } catch (err) {
      try {
        fs.unlinkSync(tmp);
      } catch {
        /* 清理失败不掩盖写失败 */
      }
      throw err;
    }
  } catch (err) {
    if (err instanceof SnapshotError) throw err;
    throw new SnapshotError('write-failed', `failed to write ${target}: ${err.message}`, { path: target });
  }
}

function writeJson(target, value) {
  atomicWrite(target, `${JSON.stringify(value, null, 2)}\n`);
}

function acquireLock(lockPath, meta) {
  try {
    fs.writeFileSync(lockPath, `${JSON.stringify({ pid: process.pid, startedAt: new Date().toISOString(), ...meta })}\n`, { flag: 'wx' });
  } catch (err) {
    if (err && err.code === 'EEXIST') {
      throw new SnapshotError(
        'write-failed',
        `requirement snapshot write lock already exists: ${lockPath}. Another writer may still be active; a stale lock must be removed manually.`,
        { lockPath },
      );
    }
    throw new SnapshotError('write-failed', `cannot create requirement snapshot write lock ${lockPath}: ${err.message}`, { lockPath });
  }
}

function releaseLock(lockPath) {
  try {
    fs.unlinkSync(lockPath);
  } catch (err) {
    if (err && err.code !== 'ENOENT') {
      process.stderr.write(`prepare-requirement-snapshot: failed to release lock ${lockPath}: ${err.message}\n`);
    }
  }
}

function readState(statePath) {
  if (!fs.existsSync(statePath)) return { state: 'missing' };
  try {
    const parsed = JSON.parse(fs.readFileSync(statePath, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return { state: 'corrupt' };
    return { state: 'valid', parsed };
  } catch {
    return { state: 'corrupt' };
  }
}

function summarizeBaseline({ baselinePath, roster }) {
  if (!baselinePath || !fs.existsSync(baselinePath)) return null;
  try {
    const parsed = JSON.parse(fs.readFileSync(baselinePath, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    const counts = {};
    for (const expertId of roster) {
      counts[expertId] = Array.isArray(parsed.domains?.[expertId]) ? parsed.domains[expertId].length : 0;
    }
    counts.dataSources = Array.isArray(parsed.dataSources) ? parsed.dataSources.length : 0;
    return { path: baselinePath, degraded: parsed.degraded === true, counts };
  } catch {
    // 基线损坏不阻断凭据生成（专家侧已有降级文案兜底）。
    return null;
  }
}

/**
 * 派发态的最小维护（D2：与台账解耦后唯一还需要的联动）。
 *   - 缺失 ⇒ 写澄清引擎的运行时透传体（mode/globalConstraints/baseline 取默认值）；
 *   - 可读对象 ⇒ 只替换 requirementSnapshot，其余键逐字保留；
 *   - 不可读 ⇒ 不覆盖（保留现场），以 note 上报。
 */
function syncDispatchWaveState({ specDir, requirementSnapshot, roster, baselinePath }) {
  const statePath = relativeAbs(specDir, STATE_REL);
  const state = readState(statePath);

  if (state.state === 'corrupt') {
    return { note: `dispatch wave state is unreadable and was left untouched: ${statePath}` };
  }

  if (state.state === 'missing') {
    writeJson(statePath, {
      mode: 'RECLARIFY',
      requirementSnapshot,
      globalConstraints: '',
      baseline: summarizeBaseline({
        baselinePath: baselinePath || relativeAbs(specDir, DEFAULT_BASELINE_REL),
        roster,
      }),
    });
    return {};
  }

  writeJson(statePath, { ...state.parsed, requirementSnapshot });
  return {};
}

/**
 * ensure：计算当前指纹并落盘阶段上下文；同输入零写盘。
 *
 * 只在「当前指纹/作用域/算法版本」与既有上下文不一致时重写，且重写不影响台账：
 * 既不轮转 `.prev`，也不清空/改写 `clarify-decisions.json`，不写 `pendingReview`。
 *
 * @returns {{ok:true, action:'created'|'unchanged'|'changed', stage, scenario,
 *            requirementSnapshot, contextPath, algorithmVersion, inputs, updatedAt, note?}}
 */
export function ensureSnapshot({ specDir, stage, scenario, roster, baselinePath }) {
  assertScope(stage, scenario);
  assertSpecDir(specDir);

  const contextPath = snapshotContextPath({ specDir, stage });
  const lockPath = `${contextPath}.lock`;
  const expertIds = Array.isArray(roster) ? [...new Set(roster.map((id) => String(id).trim()).filter(Boolean))] : [];

  try {
    fs.mkdirSync(path.dirname(contextPath), { recursive: true });
  } catch (err) {
    throw new SnapshotError('write-failed', `cannot create snapshot context directory for ${contextPath}: ${err.message}`, { path: contextPath });
  }

  acquireLock(lockPath, { stage, scenario });
  try {
    const current = computeSnapshotDetails({ specDir, stage, scenario });
    const existing = readSnapshotContext({ specDir, stage });

    const sameScope =
      existing &&
      existing.stage === stage &&
      existing.scenario === scenario &&
      existing.algorithmVersion === ALGORITHM_VERSION;

    const buildResult = (action, updatedAt) => ({
      ok: true,
      action,
      stage,
      scenario,
      requirementSnapshot: current.requirementSnapshot,
      // 上一轮记录的指纹（同作用域才可信）：调用方据此判定「本轮是不是同一轮的重试」。
      // 缺失/跨作用域 ⇒ 不提供，调用方按 RECLARIFY 处理。
      ...(sameScope && existing ? { previousRequirementSnapshot: existing.requirementSnapshot } : {}),
      contextPath,
      algorithmVersion: ALGORITHM_VERSION,
      inputs: publicInputs(current.inputs),
      updatedAt,
    });

    if (sameScope && existing.requirementSnapshot === current.requirementSnapshot) {
      // 同输入：零写盘（含派发态），返回既有 updatedAt。
      return buildResult('unchanged', existing.updatedAt ?? null);
    }

    // 先维护派发态（缺失/可读），再写上下文作为完成标记。
    let note;
    if (stage === 'backend-design') {
      const stateResult = syncDispatchWaveState({
        specDir,
        requirementSnapshot: current.requirementSnapshot,
        roster: expertIds,
        baselinePath,
      });
      note = stateResult.note;
    }

    const updatedAt = new Date().toISOString();
    writeJson(contextPath, {
      schemaVersion: 1,
      algorithmVersion: ALGORITHM_VERSION,
      stage,
      scenario,
      requirementSnapshot: current.requirementSnapshot,
      updatedAt,
      inputs: publicInputs(current.inputs),
    });

    return { ...buildResult(sameScope ? 'changed' : 'created', updatedAt), ...(note ? { note } : {}) };
  } finally {
    releaseLock(lockPath);
  }
}
