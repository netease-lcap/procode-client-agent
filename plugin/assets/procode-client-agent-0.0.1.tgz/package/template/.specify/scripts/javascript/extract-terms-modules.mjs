import fs from 'fs';
import path from 'path';

import {
  PENDING,
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  parse,
  writeToFileSync,
  formatWritedFiles,
  parseMenus,
  auto,
} from './shared/index.mjs';

export const findEnums = (item) => item.endsWith('specs/enums.md');
export const findTerms = (item) => item.endsWith('specs/terms.md');
export const findMenus = (item) => item.endsWith('specs/menus.md');
export const filterTermsModule = (item) => item.includes('pieces/terms-module-');

export const tableToSet = (menus = []) => {
  const set = new Set(['项目背景', '整体业务']);

  // 处理 null 或 undefined 的情况
  if (!menus) {
    return set;
  }

  menus.forEach((item = {}) => {
    if (!item || typeof item !== 'object') {
      return;
    }

    const key = item.combined;

    key && set.add(key);
  });

  return set;
};

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  removeUnderSpecs(rootDir)(findTerms);
  removeUnderSpecs(rootDir)(findEnums);
  removeUnderSpecs(rootDir)(filterTermsModule);

  const activeSpecDir = getActiveSpecDir(rootDir);

  const { absoluteFilePath: menusAbsoluteFilePath } = findUnderSpecs(rootDir)(findMenus) || {};
  const piecesAbsoluteDir = path.resolve(activeSpecDir, 'pieces');

  if (!menusAbsoluteFilePath) {
    throw new Error(`缺少功能模块目录：${activeSpecDir}/specs/menus.md`);
  }

  const parsed = parseMenus(menusAbsoluteFilePath);
  const set = tableToSet(parsed?.menus);

  const map = (key) => {
    const segments = [`# ${key}`];
    const name = `terms-module-${key}.md`;
    const absoluteFilePath = path.resolve(piecesAbsoluteDir, name);

    segments.push(
      `<!-- 必须阅读并充分理解指定文档：${activeSpecDir}/pieces/content-${key}.md。必须严格逐个分析每个功能模块的业务描述，禁止遗漏任何功能模块以及任何功能模块的业务描述细节。 -->`
    );

    return writeToFileSync(name, absoluteFilePath)(segments, PENDING);
  };

  const files = Array.from(set).map(map);

  return formatWritedFiles('业务术语表文档列表')(files);
};

auto(import.meta, true)(toRaw);

export default toRaw;
