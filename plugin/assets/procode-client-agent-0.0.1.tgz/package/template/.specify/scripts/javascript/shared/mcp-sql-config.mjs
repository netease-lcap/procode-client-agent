// MCP 部署级常量（tracked 静态配置，不写死在 client 代码里）。
// 改 endpoint 改本文件即可。SQL_EXEC_MCP_ENDPOINT 环境变量覆盖此默认值。
// timeoutMs=60s：executeSqlDirect 是同步执行（直返 FINISHED/FAILED），重型 DDL 耗时远超
// 旧异步 executeSql 的"提交即返"30s 余量；sql-exec.mjs 逐条执行，单条 60s 够。
export default {
  defaultEndpoint: 'http://lcap.low-code:22988/internal/v3/sse/mcp',
  defaultTimeoutMs: 60000,
};
