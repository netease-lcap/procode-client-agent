/**
 * /speckit.merge 后置总结脚本（cwd = 沙箱工作区根）。
 * 读取 docs/.merge/current.json 指针 + runDir/state.json + merge-result.json +
 * merge-plan.md（逐文件合并决策明细，内联展示），stdout 输出即用户可见的合并结果摘要。
 * 任何异常都 exit 0（降级输出，不产生 error block）。
 * 状态/决策明细不可读时如实降级，禁编造「零冲突/全部融合」类无据事实（ledger ×2 坑）。
 */
import fs from 'node:fs';
import path from 'node:path';

const say = (lines) => console.log(lines.filter(Boolean).join('\n'));

const MERGE_STATE_FILE = 'state.json';
const MERGE_RESULT_FILE = 'merge-result.json';
const MERGE_PLAN_FILE = 'merge-plan.md';

/** 逐文件决策条目展示上限与决策原因截断（防摘要撑爆消息） */
const MAX_ENTRIES = 15;
const REASON_MAX_LENGTH = 80;

/** 合并方式封闭枚举（与 merge/shared/constants.ts MERGE_DECISION_ENUM 同源词表） */
const DECISION_ENUM = ['取我方', '取对方', '融合', '需人工裁决'];

function resolveAppDir(rootDir) {
  const appName = (process.env.APP_NAME || process.env.APP_ID || '').trim();
  if (appName && !appName.includes('/') && appName !== '.' && appName !== '..') {
    const candidate = path.join(rootDir, appName);
    if (fs.existsSync(candidate)) return candidate;
  }
  return rootDir;
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return null;
  }
}

function readText(filePath) {
  try {
    return fs.readFileSync(filePath, 'utf-8');
  } catch {
    return null;
  }
}

/** run 目录可用判据：state.json / merge-result.json 任一可读即算在场（存在性守卫）。 */
function canReadRunDir(runDir) {
  return Boolean(
    runDir &&
      (fs.existsSync(path.join(runDir, MERGE_STATE_FILE)) ||
        fs.existsSync(path.join(runDir, MERGE_RESULT_FILE))),
  );
}

/**
 * 解析本轮 run 目录。
 *
 * 指针 `runDir` 是**带工作区 ID 的绝对路径**，工作区重建/克隆换 ID 后必 ENOENT——与服务端
 * `readRunState`（config/merge/shared/merge-ops.ts，D5 修复）同语义：按指针里稳定存在的
 * `runTs` 回落 appDir 相对路径；命中即告警留痕（stderr，不污染 stdout 摘要，不静默）。
 * 两处都不可读 → 返回 null（调用方按「状态不可读」如实降级，禁编造「未推送」负面断言）。
 */
function resolveRunDir(appDir, pointer) {
  if (canReadRunDir(pointer.runDir)) return pointer.runDir;
  if (pointer.runTs) {
    const relocated = path.join(appDir, 'docs', '.merge', pointer.runTs);
    if (canReadRunDir(relocated)) {
      console.warn(
        `[merge-summary] 指针 runDir 已失效（${pointer.runDir || '空'}），按 runTs=${pointer.runTs} 重定位到 ${relocated}（工作区重建/克隆换 ID）。`,
      );
      return relocated;
    }
  }
  return null;
}

/**
 * 解析 merge-plan.md 条目（展示提取，非校验判定）。
 *
 * 正则与 TS 侧 merge/shared/merge-plan.ts 的 validateMergePlan **逐字同构**
 * （MERGE_PLAN_ENTRY_RE 条目标题行 + 字段行匹配）；此处只提取展示字段，不做必填/
 * 枚举校验。改条目/字段格式必须同批改两处（双端判据禁写裂）。
 */
function parseMergePlanEntries(planText) {
  const lines = String(planText || '').split('\n');
  const starts = [];
  lines.forEach((line, index) => {
    const match = line.match(/^###\s+(c-\d+)\s+(\S+)/);
    if (match) {
      starts.push({ index, id: match[1], filePath: match[2], review: line.includes('⚠需人工裁决') });
    }
  });
  return starts.map((start, i) => {
    const end = i + 1 < starts.length ? starts[i + 1].index : lines.length;
    const body = lines.slice(start.index + 1, end);
    const field = (name) => {
      const line = body.find((l) => l.trim().startsWith(`- ${name}:`) || l.trim().startsWith(`- ${name}：`));
      return line ? line.trim().replace(/^-\s*/, '').replace(new RegExp(`^${name}[：:]\\s*`), '') : undefined;
    };
    return {
      id: start.id,
      filePath: start.filePath,
      review: start.review,
      decision: (field('合并方式') || '').trim(),
      reason: (field('决策原因') || '').trim(),
      confidence: (field('置信度') || '').trim(),
    };
  });
}

function truncate(text, maxLength) {
  return text.length <= maxLength ? text : `${text.slice(0, maxLength)}…`;
}

/** 单条决策摘要行：`<文件路径>：合并方式（置信度）——决策原因截断` */
function renderEntryLine(entry) {
  const decisionWord = DECISION_ENUM.find((v) => entry.decision.startsWith(v))
    || entry.decision.slice(0, 20) || '未知';
  const label = entry.review ? `⚠${decisionWord}` : decisionWord;
  const confidence = entry.confidence ? `（${entry.confidence}）` : '';
  return entry.reason
    ? `  - ${entry.filePath}：${label}${confidence}——${truncate(entry.reason, REASON_MAX_LENGTH)}`
    : `  - ${entry.filePath}：${label}${confidence}`;
}

try {
  const rootDir = process.cwd();
  const appDir = resolveAppDir(rootDir);
  const pointerPath = path.join(appDir, 'docs', '.merge', 'current.json');

  if (!fs.existsSync(pointerPath)) {
    say(['### 代码合并', '', '当前没有合并运行记录。']);
    process.exit(0);
  }

  const pointer = JSON.parse(fs.readFileSync(pointerPath, 'utf-8'));
  const runDir = resolveRunDir(appDir, pointer);
  const state = runDir ? readJson(path.join(runDir, MERGE_STATE_FILE)) : null;
  const result = runDir ? readJson(path.join(runDir, MERGE_RESULT_FILE)) : null;

  const status = result?.status || state?.commitId || state?.pushedRef ? 'merged/pushed' : '未知';
  const lines = ['### 代码合并', '', `- 模式：${pointer.mode || state?.mode || '未知'}`];

  if ((pointer.mode || state?.mode) === 'push') {
    // 负面断言只在可读证据确实不含 pushedRef 时出现（dual-review P2）：存在性守卫是
    // state.json / merge-result.json 任一在场，runDir 解析成功不蕴含 state 可读——
    // state 缺失但 merge-result 在场时回退 result，否则会在已推送边界下误报「未推送」。
    lines.push(
      runDir
        ? `- 推送：${state?.pushedRef || result?.pushedRef || '未推送'}`
        : '- 推送：状态不可读（运行状态 runDir/runTs 均无法定位）',
    );
    if (state?.isNewRemoteBranch) lines.push('- 已新建远端目标分支');
  } else if (!runDir) {
    // pull/merge 模式同族约束（dual-review P1）：状态不可读时禁编造
    // 「合并提交：未提交」「冲突文件：0 个」等无据负面事实。
    lines.push('- 运行状态：状态不可读（运行状态 runDir/runTs 均无法定位）');
  } else if (!state) {
    // runDir 在场（至少 merge-result.json 可读）但 state.json 缺失：冲突数/决策明细
    // 均以 state 为源，缺失时如实说，禁回落 0 编造「零冲突」。
    lines.push('- 源分支：未知（state.json 不可读）');
    lines.push('- 决策明细：state.json 不可读（冲突清单无法定位）');
  } else {
    lines.push(`- 源分支：${state.theirsRef || state.theirs || '未知'}`);
    const conflictCount = state.conflictFiles?.length ?? 0;
    if (conflictCount === 0) {
      lines.push('- 冲突文件：0 个（零文本冲突，无决策条目）');
    } else {
      lines.push(`- 冲突文件：${conflictCount} 个`);
      const planText = readText(path.join(runDir, MERGE_PLAN_FILE));
      if (planText === null) {
        lines.push('  - 决策明细：merge-plan 不可读');
      } else {
        const entries = parseMergePlanEntries(planText);
        if (entries.length === 0) {
          lines.push('  - 决策明细：merge-plan 无条目（未按模板撰写或状态异常）');
        } else {
          entries.slice(0, MAX_ENTRIES).forEach((entry) => lines.push(renderEntryLine(entry)));
          if (entries.length > MAX_ENTRIES) {
            lines.push(`  - …其余 ${entries.length - MAX_ENTRIES} 个冲突文件略`);
          }
        }
      }
    }
    lines.push(`- 合并提交：${state.commitId || '未提交'}`);
    if (state.alreadyUpToDate) lines.push('- 远端改动已全部在本地（no-op 收口）');
    if (state.autoMergedFiles?.length) {
      lines.push(`- 另有 ${state.autoMergedFiles.length} 个 auto-merged 文件（双方改动，无文本冲突）`);
    }
  }

  if (result?.status === 'failed') {
    lines.push(`- 终态：**failed(${result.reason})**`);
    if (result.resumeHint) lines.push(`- 续做指引：${result.resumeHint}`);
  } else if (!runDir) {
    lines.push('- 终态：未知（运行状态不可读）');
  } else {
    lines.push(`- 终态：${status === '未知' ? '未知' : '✅ 完成'}`);
  }

  say(lines);
} catch (error) {
  say([`### 代码合并`, '', `合并摘要生成失败：${(error && error.message) || error}`]);
}
process.exit(0);
