/**
 * 段 B｜后端工程定位与根包解析的纯函数集（除字典懒读+记忆化外无顶层副作用）。
 *
 * findBackendDir 为「后端产物根定位」的唯一实现（多候选 + APP_NAME 未设置时向下扫描多应用子目录），
 * 供 sql-exec / extract-code-schema / check-backend-* / generate-type-registry / precreate-package-dirs /
 * run-backend-domain-tests 等脚本共用，杜绝各脚本复制粘贴的探测逻辑漂移。
 * resolveRootPackage / parseDomainModuleMap 仅供 run-backend-domain-tests.mjs（单域单测批量自检，
 * 需 domain→modulePackage 映射定位域包）。约定：所有函数显式接收参数，不依赖模块级可变状态 / process.argv。
 */

import { existsSync, readdirSync, readFileSync, statSync } from 'fs';
import { resolve, basename, dirname, relative, isAbsolute, sep } from 'path';

/** 应用名（与 project.ts / 各 check 脚本同源：APP_NAME / APP_ID，缺省 project）。 */
export function appNameOf(env = process.env) {
  return String(env.APP_NAME || env.APP_ID || 'project').trim() || 'project';
}

/** 后端根构建锚点字典（唯一真理源=本目录 backend-root-anchors.json；TS 侧镜像见
 *  src/utils/customWaveAgent/speckit/config/shared/，字节相等由同步门锁死）。
 *  判据=任一锚点存在即视为后端工程根；扩语言=字典加一条锚点，本文件零改动。懒读 + 记忆化，无顶层副作用。 */
let backendRootAnchorsCache = null;
export function backendRootAnchors() {
  backendRootAnchorsCache ??= JSON.parse(
    readFileSync(new URL('./backend-root-anchors.json', import.meta.url), 'utf8'),
  ).anchors;
  return backendRootAnchorsCache;
}

/** 后端构建根判定：任一锚点命中即真根（多技术栈扩展点=dialect 同款字典加行）。 */
export function isBackendRoot(d) {
  return backendRootAnchors().some((anchor) => existsSync(resolve(d, anchor)));
}

/** 服务清单（`${appName}-services.json`）声明的后端产物根 —— 与 TS 侧
 *  `resolveServiceArtifactDirSync` ① **同一解析序**：取第一条 `serviceType === 'backend'`
 *  （跳过原型）的 `sourceDir ?? projectName ?? serviceName`，**声明即采纳**。
 *
 *  脚本侧不得改用目录名推导：端定义派生的产物根不一定是 `${appName}-backend` 形态
 *  （默认端定义就不是），按名字猜必然落空，机械脚本于是误报「未找到后端工程目录」并 red stop。
 *  「声明即采纳」也照抄 TS：窗口期目录与构建锚点可能都还没落，按名字推导同样落空；
 *  清单声明给的是稳定路径，存在性由调用方按自己的报错处理。
 *
 *  **取声明路径首段**（本函数语义 = 后端产物根，不是模块目录）：`pathBase` 的契约是
 *  「相对项目产物根且首段即后端根目录名」（见 sql-exec.mjs 归档判据 `moduleArchiveDir`），
 *  所以 fresh micro 的 `backend/<service>` 归约为聚合根 `backend/`——编译/启动/单测/sql-exec
 *  归档都以聚合根为基准；单段声明（如默认端定义的目录名）原样返回。 */
function declaredBackendRoot(appDir, appName) {
  const servicesFile = resolve(appDir, `${appName}-services.json`);
  if (!existsSync(servicesFile)) return null;
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(servicesFile, 'utf-8'));
  } catch {
    return null; // 清单损坏：回落既有候选，不在此处充当门禁
  }
  if (!Array.isArray(parsed)) return null;
  for (const entry of parsed) {
    if (!entry || typeof entry !== 'object') continue;
    // 写盘口径是 serviceType（ServiceDefinition 无 type 字段）；type 只兜底历史手工清单。
    const kind = entry.serviceType ?? entry.type;
    if (kind !== 'backend') continue;
    // 原型由同端 frontend 派生，不得顶掉正式后端根。
    if (entry.businessType === 'prototype') continue;
    const name = String(entry.sourceDir ?? entry.projectName ?? entry.serviceName ?? '').trim();
    if (!name) continue;
    const [rootSegment] = name.split(/[\\/]/).filter(Boolean);
    if (rootSegment) return resolve(appDir, rootSegment);
  }
  return null;
}

/** 在当前 cwd 下定位后端工程目录（**legacy 后端产物根兜底定位**）。
 *  统一口径（与 TS 侧 resolveServiceArtifactDirSync 同序）：
 *  ① 服务清单声明**最优先**，但必须存在且命中构建锚点才采纳（stale 声明继续 fallback）；
 *  ② `<appName>/backend`（fresh micro 工程方案 rootDir 口径）；
 *  ③ 端定义派生的 `${appName}-backend-<end>`；
 *  ④ 旧名 `${appName}-backend` 仅作单端/存量回退；
 *  ⑤ 平铺 `backend` → cwd；APP_NAME 未设置时向下扫描多应用子目录。
 *  候选构造只在本函数，禁调用方各写探测。 */
export function findBackendDir(cwd = process.cwd()) {
  const appName = appNameOf();

  // ① 服务清单声明（TS 侧 `resolveServiceArtifactDirSync` ① 同序）。
  //    cwd 可能是资源根（清单在 <cwd>/<appName>/），也可能已是应用目录（平铺）。
  //    声明必须落盘且命中锚点：stale/占位声明不得遮蔽真实候选（plan §3 D5 兜底硬化）。
  for (const appDir of [resolve(cwd, appName), cwd]) {
    const declared = declaredBackendRoot(appDir, appName);
    if (declared && existsSync(declared) && isBackendRoot(declared)) return declared;
  }

  const multiEndCandidates = [];

  // ② 多端派生根：`${appName}-backend-*`（端定义派生名 = 统一口径）
  for (const base of [resolve(cwd, appName), cwd]) {
    let entries;
    try {
      entries = readdirSync(base, { withFileTypes: true });
    } catch {
      continue; // 目录不存在/不可读
    }
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (!entry.name.startsWith(`${appName}-backend-`)) continue;
      multiEndCandidates.push(resolve(base, entry.name));
    }
  }

  // ③ APP_NAME/APP_ID 未设置时，扫描 cwd 下多应用子目录里的 `*-backend` / `*-backend-*`
  //   （适配多应用目录结构，自 check-backend-startup.mjs 移植）。
  if (!process.env.APP_NAME && !process.env.APP_ID) {
    try {
      for (const entry of readdirSync(cwd)) {
        const appDir = resolve(cwd, entry);
        try { if (!statSync(appDir).isDirectory()) continue; } catch { continue; }
        try {
          for (const sub of readdirSync(appDir)) {
            if (sub.endsWith('-backend') || sub.includes('-backend-')) multiEndCandidates.push(resolve(appDir, sub));
          }
        } catch { /* 目录不可读 */ }
      }
    } catch { /* cwd 不可读 */ }
  }

  // 顺序（plan §3 D5）：<appName>/backend → ${appName}-backend-* → ${appName}-backend → backend → cwd。
  const candidates = [...new Set([
    // fresh micro 的代码根是 `<app>/backend/`（工程方案 buildUnits[].rootDir 口径）。
    resolve(cwd, appName, 'backend'),
    ...multiEndCandidates,
    resolve(cwd, appName, `${appName}-backend`),
    resolve(cwd, `${appName}-backend`),
    resolve(cwd, 'backend'),
    cwd,
  ])];
  return candidates.find(isBackendRoot);
}

/** 定位当前应用 docs 下全部「含 plans/backend」的日期目录，按 mtime 升序（最新在末尾）。
 *  docsRoot 多候选（平铺/嵌套布局都覆盖）：优先 resolve(cwd,'docs')（平铺：cwd/docs），
 *  回退 resolve(cwd,appName,'docs')（嵌套：cwd/{appName}/docs）。与 findBackendDir 的多候选策略一致。 */
export function planBackendDirs(cwd = process.cwd()) {
  const appName = appNameOf();
  const docsCandidates = [resolve(cwd, 'docs'), resolve(cwd, appName, 'docs')];
  const docsRoot = docsCandidates.find((d) => existsSync(d));
  if (!docsRoot) return [];
  let dirs;
  try {
    dirs = readdirSync(docsRoot).filter((n) => !n.startsWith('.') && existsSync(resolve(docsRoot, n, 'plans', 'backend')));
  } catch {
    return [];
  }
  if (dirs.length === 0) return [];
  dirs.sort((a, b) => statSync(resolve(docsRoot, a)).mtimeMs - statSync(resolve(docsRoot, b)).mtimeMs || a.localeCompare(b, 'en'));
  return dirs.map((n) => resolve(docsRoot, n, 'plans', 'backend'));
}

/** 最新日期目录的 plans/backend（设计 README 与 _meta 所在）。 */
export function resolvePlanBackendDir(cwd = process.cwd()) {
  const dirs = planBackendDirs(cwd);
  return dirs.length ? dirs[dirs.length - 1] : null;
}

/**
 * 项目产物根：从 cwd 逐级向上（含 cwd，最多 8 层祖先），返回第一个
 * `planBackendDirs(dir).length > 0` 的祖先目录。
 *
 * 为什么不直接 `resolvePlanBackendDir(cwd)`：agent 常从 `<project>/backend/<svc>` 等
 * 子目录执行脚本，cwd 本身不含 docs/<ts>/plans/backend；归档/写盘归属必须锚定项目根，
 * 而不是随 cwd 漂移（plan 2026-11-04 §3 D1）。
 * 显式收 cwd，禁读 process.cwd()（调用方负责传对基准）。
 */
export function resolveProjectRoot(cwd = process.cwd()) {
  let dir = resolve(cwd);
  for (let depth = 0; depth <= 8; depth += 1) {
    try {
      if (planBackendDirs(dir).length > 0) return dir;
    } catch {
      // 目录不可读 ⇒ 当作没找到，继续上溯。
    }
    const parent = resolve(dir, '..');
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

/** 最新一轮的 plans/backend 目录（mtime 升序末尾）；定位不到返回 null。
 *  唯一实现：resolveProjectRoot 上溯 + planBackendDirs 取最新轮。
 *  不把裸 `<root>/plans/backend` 当候选（全仓无生产者，且 stray 目录会遮蔽真实轮）。 */
export function findPlanBackendDir(cwd = process.cwd()) {
  const projectRoot = resolveProjectRoot(cwd);
  if (!projectRoot) return null;
  const dirs = planBackendDirs(projectRoot);
  return dirs.length ? dirs[dirs.length - 1] : null;
}

/** 工程方案最小自描述版本（与 TS 侧 `ENGINEERING_PLAN_SCHEMA_VERSION` 同值）。
 *  脚本不复制契约全量校验（那是 S01/入口的职责），只回答「这份文件能不能作为 fresh micro 真值」。
 *
 *  注意：工程方案版本是**字符串** `"1"/"2"`，与 operations/执行回执的数字版本 `1/2` 是不同契约，
 *  不得互相比较或复用常量。V2 增量方案由窄读面（sql-exec 的归档投影）按 `schemaVersion:"2"` ∧
 *  `scenario:"incremental"` 读取；fresh 专用读面（readFreshMicroEngineeringPlan）保持只看 V1。 */
export const ENGINEERING_PLAN_SCHEMA_VERSION = '1';
export const ENGINEERING_PLAN_V2_SCHEMA_VERSION = '2';

const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);
const asString = (value) => (typeof value === 'string' ? value.trim() : '');
/**
 * 语言值 → 小写基础 token（`Java 21` → `java`）。
 * 与 TS 侧 `toolchain-capability.ts#normalizeLanguageToken` 同口径：`backend.language` 常带版本号，
 * 只 `toLowerCase()` 会得到 `java 21`，与 `'java'` 严格比较会把 Java 栈误判成非 Java。
 */
const normalizeLanguageToken = (value) => {
  const text = asString(value);
  if (!text) return '';
  return text.split(/\s+/)[0].toLowerCase();
};
const readJsonSafe = (abs) => {
  try {
    return JSON.parse(readFileSync(abs, 'utf-8'));
  } catch {
    return null;
  }
};

// ── 代码根列表解析（只给 legacy 扫代码路径；plans 目录定位见 findPlanBackendDir）──────────
// 代码根权威来源（plan 2026-11-04 §3 D5，按优先级）：
//   ① 显式参数 explicitRoots；
//   ② plans/backend/_meta/engineering-plan.json#buildUnits[].rootDir（fresh micro）；
//   ③ plans/_meta/iteration-context.json#materials[kind=source-code].workCopyPath
//      + plans/_meta/entry-form-observation.json#codeRoots[kind=backend].path；
//   ④ ${appName}-services.json#sourceDir（存量微服务声明）；
//   ⑤ 共享启发式 findBackendDir（仅 legacy 兜底，source='heuristic' 可辨识）。
// 脚本职责 = 只消费 + 校验（存在 / 不逃逸工作区 / 命中构建锚点），不重新决策。
//
// 多基准解析：不同产物的路径基准不同——
//   · engineering-plan.buildUnits[].rootDir 是**应用根相对**（如 `backend`）；
//   · iteration-context.materials[].workCopyPath 是**工作区根相对**（如 `hangzhouyun/backend`）；
//   · entry-form-observation.codeRoots[].path 新旧产物两种都可能；
//   · 调用方 rootDir 可能是工作区根，也可能是应用根（resolveProjectRoot 两种都会返回）。
// 因此对每个相对候选按 [appRoot, workspaceRoot, rootDir] 去重后依次 try-first-exists，
// 避免 `hangzhouyun/backend` 在应用根下被解析成 `<app>/hangzhouyun/backend`。

/** 由 activeSpecDir（形如 `<app>/docs/<ts>`）推导应用根/工作区根（best-effort）。 */
function deriveBackendRootBases({ activeSpecDir, rootDir, appName }) {
  const bases = [];
  // 只认 `<...>/docs/<ts>` 形态；其它形态不猜基准，退回调用方 rootDir。
  if (activeSpecDir && basename(dirname(activeSpecDir)) === 'docs') {
    const appRoot = dirname(dirname(activeSpecDir));
    // 平铺布局（`<ws>/docs/<ts>`）下 appRoot 即工作区根，两者相同；
    // 嵌套布局（`<ws>/<app>/docs/<ts>`）才上取一级。
    const workspaceRoot = basename(appRoot) === appName ? dirname(appRoot) : appRoot;
    bases.push(appRoot, workspaceRoot);
  }
  bases.push(rootDir);
  return [...new Set(bases.map((base) => resolve(base)))];
}

const isPathWithin = (base, abs) => {
  const rel = relative(base, abs);
  return rel === '' || (rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel));
};

/** 相对候选 → 第一个 existsSync 命中的基准；都不命中时返回主基准（appRoot/rootDir）下的路径供诊断。 */
function resolveCandidateAgainstBases(bases, candidate) {
  if (isAbsolute(candidate)) return resolve(candidate);
  for (const base of bases) {
    const abs = resolve(base, candidate);
    if (existsSync(abs)) return abs;
  }
  return resolve(bases[0], candidate);
}

/** 单个候选根校验：多基准解析 → 必须在 appRoot/workspaceRoot/rootDir 任一之内 → 必须存在且命中锚点。 */
function validateBackendRootCandidate(bases, candidate) {
  const abs = resolveCandidateAgainstBases(bases, candidate);
  const withinAnyBase = bases.some((base) => isPathWithin(base, abs));
  if (!withinAnyBase || !existsSync(abs) || !isBackendRoot(abs)) return { ok: false, path: abs };
  return { ok: true, path: abs };
}

/** 校验一组声明候选：合法者去重入 roots，不合法者入 ambiguous（供调用方报缺口）。 */
function collectValidatedBackendRoots(bases, candidates) {
  const roots = [];
  const ambiguous = [];
  const seen = new Set();
  for (const candidate of candidates) {
    const text = asString(candidate);
    if (!text) continue;
    const validated = validateBackendRootCandidate(bases, text);
    if (seen.has(validated.path)) continue;
    seen.add(validated.path);
    if (validated.ok) roots.push(validated.path);
    else ambiguous.push(validated.path);
  }
  return { roots, ambiguous };
}

/** 工程方案代码根：`<activeSpecDir>/plans/backend/_meta/engineering-plan.json#buildUnits[].rootDir`。 */
function engineeringPlanBackendRootCandidates(activeSpecDir) {
  if (!activeSpecDir) return [];
  const plan = readJsonSafe(resolve(activeSpecDir, 'plans', 'backend', '_meta', 'engineering-plan.json'));
  if (!isRecord(plan) || !Array.isArray(plan.buildUnits)) return [];
  return plan.buildUnits.filter(isRecord).map((unit) => asString(unit.rootDir)).filter(Boolean);
}

/** 观测/迭代上下文代码根：iteration-context materials + entry-form-observation codeRoots。 */
function iterationContextBackendRootCandidates(activeSpecDir) {
  if (!activeSpecDir) return [];
  const candidates = [];
  const context = readJsonSafe(resolve(activeSpecDir, 'plans', '_meta', 'iteration-context.json'));
  if (isRecord(context) && Array.isArray(context.materials)) {
    for (const material of context.materials) {
      if (!isRecord(material) || material.kind !== 'source-code') continue;
      const workCopyPath = asString(material.workCopyPath);
      if (workCopyPath) candidates.push(workCopyPath);
    }
  }
  const observation = readJsonSafe(resolve(activeSpecDir, 'plans', '_meta', 'entry-form-observation.json'));
  if (isRecord(observation) && Array.isArray(observation.codeRoots)) {
    for (const root of observation.codeRoots) {
      if (!isRecord(root) || root.kind !== 'backend') continue;
      const rootPath = asString(root.path);
      if (rootPath) candidates.push(rootPath);
    }
  }
  return candidates;
}

/** 服务清单代码根：`${appName}-services.json#sourceDir`（相对清单所在 appDir）。 */
function servicesBackendRootCandidates(rootDir, appName) {
  for (const appDir of [resolve(rootDir, appName), rootDir]) {
    const servicesFile = resolve(appDir, `${appName}-services.json`);
    if (!existsSync(servicesFile)) continue;
    const parsed = readJsonSafe(servicesFile);
    if (!Array.isArray(parsed)) continue;
    const candidates = [];
    for (const entry of parsed) {
      if (!isRecord(entry)) continue;
      // 写盘口径是 serviceType（ServiceDefinition 无 type 字段）；type 只兜底历史手工清单。
      const kind = entry.serviceType ?? entry.type;
      if (kind !== 'backend') continue;
      if (entry.businessType === 'prototype') continue;
      const declared = asString(entry.sourceDir ?? entry.projectName ?? entry.serviceName);
      if (declared) candidates.push(isAbsolute(declared) ? declared : resolve(appDir, declared));
    }
    if (candidates.length > 0) return candidates;
  }
  return [];
}

/**
 * 解析 legacy 扫代码路径的**代码根列表**（只消费声明 + 校验，不猜）。
 *
 * 返回 `{ roots, source, ambiguous }`：
 *   · roots：通过「多基准解析 + 不逃逸 appRoot/workspaceRoot/rootDir + 存在 + isBackendRoot」校验的绝对路径列表；
 *   · source：'explicit' | 'engineering-plan' | 'iteration-context' | 'services' | 'heuristic'；
 *   · ambiguous：该来源声明了但校验不通过的候选绝对路径（不存在 / 逃逸 / 非后端根）。
 *
 * 某来源一旦给出声明候选即不再降级到下一来源（含全部校验失败的空 roots），
 * 由调用方按「缺失/歧义 ⇒ checker feedback」处理；只有完全无声明时才落到启发式。
 */
export function resolveDeclaredBackendRoots(input = {}) {
  const rootDir = resolve(input.rootDir || process.cwd());
  const appName = appNameOf();
  // activeSpecDir 允许相对 rootDir（调用方通常传绝对路径）。
  const activeSpecDir = input.activeSpecDir
    ? isAbsolute(input.activeSpecDir) ? resolve(input.activeSpecDir) : resolve(rootDir, input.activeSpecDir)
    : null;
  const bases = deriveBackendRootBases({ activeSpecDir, rootDir, appName });
  const explicitCandidates = (Array.isArray(input.explicitRoots) ? input.explicitRoots : [])
    .map((root) => (typeof root === 'string' ? root.trim() : ''))
    .filter(Boolean);
  if (explicitCandidates.length > 0) {
    return { ...collectValidatedBackendRoots(bases, explicitCandidates), source: 'explicit' };
  }
  const engineeringCandidates = engineeringPlanBackendRootCandidates(activeSpecDir);
  if (engineeringCandidates.length > 0) {
    return { ...collectValidatedBackendRoots(bases, engineeringCandidates), source: 'engineering-plan' };
  }
  const iterationCandidates = iterationContextBackendRootCandidates(activeSpecDir);
  if (iterationCandidates.length > 0) {
    return { ...collectValidatedBackendRoots(bases, iterationCandidates), source: 'iteration-context' };
  }
  const serviceCandidates = servicesBackendRootCandidates(rootDir, appName);
  if (serviceCandidates.length > 0) {
    return { ...collectValidatedBackendRoots(bases, serviceCandidates), source: 'services' };
  }
  const heuristic = findBackendDir(rootDir);
  return { roots: heuristic ? [heuristic] : [], source: 'heuristic', ambiguous: [] };
}

/**
 * 读工程方案的最小自描述（scripts 侧 fresh micro 判据）。
 *
 * 判据只认「方案在场且自描述匹配」（plan §5.1：scenario='fresh' ∧ form='micro'）；
 * **方案不在场 ⇒ legacy**（fresh monolith / incremental / free 没有该产物，旧行为逐字不变）；
 * 在场但版本/形态不符 ⇒ invalid，调用方必须 fail loud，不能静默回落旧 conventions。
 *
 * 为什么不另造环境变量或第二份形态判定：工程方案本身就是唯一自描述载体；另设 env 会与
 * TS 侧 profile 判定漂移，且脚本被单独执行时拿不到 profile。
 *
 * 本读面保持 v1-only（`sql-exec` 依赖它的 invalid 分支走自己的窄读面，归档语义零变化）；
 * 机械消费方（generate-type-registry / precreate-package-dirs / loadSkeletonConventions）
 * 一律走 `readMicroEngineeringPlan`。
 */
export function readFreshMicroEngineeringPlan(planDir) {
  const planPath = planDir ? resolve(planDir, '_meta', 'engineering-plan.json') : '';
  if (!planDir || !existsSync(planPath)) return { kind: 'legacy', planPath };
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(planPath, 'utf-8'));
  } catch {
    return { kind: 'invalid', planPath, reason: `工程方案不是合法 JSON：${planPath}` };
  }
  if (!isRecord(parsed)) {
    return { kind: 'invalid', planPath, reason: `工程方案顶层必须是 JSON 对象：${planPath}` };
  }
  if (parsed.schemaVersion !== ENGINEERING_PLAN_SCHEMA_VERSION) {
    return {
      kind: 'invalid',
      planPath,
      reason:
        `工程方案版本不符：期望 schemaVersion=${JSON.stringify(ENGINEERING_PLAN_SCHEMA_VERSION)}，` +
        `实际 ${JSON.stringify(parsed.schemaVersion)}（旧读取器不得把新格式当旧 conventions 解释）`,
    };
  }
  if (parsed.scenario !== 'fresh' || parsed.form !== 'micro') {
    return {
      kind: 'invalid',
      planPath,
      reason:
        `工程方案形态不符：scenario=${JSON.stringify(parsed.scenario)}、form=${JSON.stringify(parsed.form)}，` +
        "本读面只服务 scenario='fresh' ∧ form='micro'",
    };
  }
  return { kind: 'fresh-micro', planPath, plan: parsed };
}

/**
 * 读工程方案的共享读面（机械消费方：generate-type-registry / precreate-package-dirs /
 * loadSkeletonConventions），同时放行两种自描述形态：
 *   · `schemaVersion:"1" ∧ scenario:"fresh" ∧ form:"micro"` ⇒ kind='fresh-micro'；
 *   · `schemaVersion:"2" ∧ scenario:"incremental" ∧ form:"micro"` ⇒ kind='incremental-micro'。
 *
 * 设计依据：v2 增量方案由 `sharedPlanFields` 派生，与 v1 共用
 * `codeModules / buildUnits / dependencies / runtime` 这组同构字段；机械消费方只读
 * `codeModules[].{moduleId,pathBase,packageName,sourceDirs}` 与 `runtime[].serviceRef`，
 * 不依赖 v1 独有的 `executionActions`（v2 没有该字段）。因此这里放行两版组合，
 * 其余（未知版本、版本与场景错配、form 非 micro）仍 fail loud——不得把新格式当旧
 * conventions 解释，也不静默回落到聚合根或目录猜测。
 *
 * 与 `readFreshMicroEngineeringPlan` 的分工：后者保持 v1-only，`sql-exec` 依赖它的
 * invalid 分支再走自己的窄读面（归档语义零变化）；机械消费方一律走本函数。
 */
export function readMicroEngineeringPlan(planDir) {
  const planPath = planDir ? resolve(planDir, '_meta', 'engineering-plan.json') : '';
  if (!planDir || !existsSync(planPath)) return { kind: 'legacy', planPath };
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(planPath, 'utf-8'));
  } catch {
    return { kind: 'invalid', planPath, reason: `工程方案不是合法 JSON：${planPath}` };
  }
  if (!isRecord(parsed)) {
    return { kind: 'invalid', planPath, reason: `工程方案顶层必须是 JSON 对象：${planPath}` };
  }
  const isFreshV1 = parsed.schemaVersion === ENGINEERING_PLAN_SCHEMA_VERSION && parsed.scenario === 'fresh';
  const isIncrementalV2 =
    parsed.schemaVersion === ENGINEERING_PLAN_V2_SCHEMA_VERSION && parsed.scenario === 'incremental';
  if ((isFreshV1 || isIncrementalV2) && parsed.form === 'micro') {
    return { kind: isFreshV1 ? 'fresh-micro' : 'incremental-micro', planPath, plan: parsed };
  }
  return {
    kind: 'invalid',
    planPath,
    reason:
      '工程方案版本/形态不符：期望 (schemaVersion="1" ∧ scenario="fresh") 或 ' +
      '(schemaVersion="2" ∧ scenario="incremental") 且 form="micro"；' +
      `实际 schemaVersion=${JSON.stringify(parsed.schemaVersion)}，` +
      `scenario=${JSON.stringify(parsed.scenario)}，` +
      `form=${JSON.stringify(parsed.form)}（不得把新格式当旧 conventions 解释）`,
  };
}

const JAVA_PACKAGE_SEGMENT = /^[A-Za-z_][A-Za-z0-9_]*$/;
const isValidJavaPackage = (value) =>
  Boolean(value) && value.split('.').every((segment) => JAVA_PACKAGE_SEGMENT.test(segment));

/** 点分公共前缀；不足一段时返回空串。 */
function commonDotPrefix(packages) {
  if (packages.length === 0) return '';
  const split = packages.map((pkg) => pkg.split('.'));
  const prefix = [];
  for (let index = 0; ; index += 1) {
    const segment = split[0][index];
    if (!segment || split.some((segments) => segments[index] !== segment)) break;
    prefix.push(segment);
  }
  return prefix.join('.');
}

/**
 * fresh micro 根包 = 工程方案 Java 代码模块 `packageName` 的点分公共前缀。
 *
 * 与 TS 侧 `resolveFreshMicroRootPackage` 同口径：
 *   · 非 Java 栈（所有显式语言都不是 java）⇒ 不推导，不返回 `com.company` 默认值；
 *   · 明确声明 java 却缺 `packageName` ⇒ 设计缺口；语言未知的模块不参与 Java 根包；
 *   · 公共前缀不足两段 ⇒ 不能当根包。
 * 不读 skeleton-conventions.json 的旧 rootPackage（实测产物不是本轮根包真值）。
 */
export function resolveRootPackageFromEngineeringPlan(plan) {
  const modules = Array.isArray(plan?.codeModules) ? plan.codeModules.filter(isRecord) : [];
  if (modules.length === 0) return { ok: false, reason: '工程方案 `codeModules[]` 为空（无模块可推根包）' };
  const languages = new Set();
  for (const module of modules) {
    const language = isRecord(module.stack) ? normalizeLanguageToken(module.stack.language) : '';
    if (language) languages.add(language);
  }
  if (languages.size > 0 && !languages.has('java')) {
    return {
      ok: false,
      reason: `非 Java 栈（${[...languages].join('/')}）：不推导 Java 根包，也不虚构 com.company 默认值`,
    };
  }
  const packages = [];
  const missing = [];
  for (const module of modules) {
    const moduleId = asString(module.moduleId) || '(未命名)';
    const language = isRecord(module.stack) ? normalizeLanguageToken(module.stack.language) : '';
    const packageName = asString(module.packageName);
    // 显式非 Java 模块（如 Node/TS）的 packageName/namespace 不是 Java 包，不参与公共前缀。
    if (language && language !== 'java') continue;
    if (packageName) {
      if (!isValidJavaPackage(packageName)) {
        return { ok: false, reason: `codeModules[${moduleId}].packageName 不是合法 Java 包名：${packageName}` };
      }
      packages.push(packageName);
      continue;
    }
    if (language === 'java') missing.push(moduleId);
  }
  if (missing.length > 0) {
    return {
      ok: false,
      reason: `Java 代码模块缺 packageName：${missing.join('、')}（工程方案缺口，禁按目录名推包名）`,
    };
  }
  if (packages.length === 0) {
    return {
      ok: false,
      reason: '工程方案没有任何 `codeModules[].packageName`，且未声明 Java 栈——根包不可判定',
    };
  }
  const rootPackage = commonDotPrefix(packages);
  if (rootPackage.split('.').filter(Boolean).length < 2) {
    return {
      ok: false,
      reason: `codeModules[].packageName 的公共前缀不足两段（${rootPackage || '(空)'}），不能当根包`,
    };
  }
  return { ok: true, rootPackage, modulePackages: [...new Set(packages)].sort() };
}

/** `pathBase` → 后端产物目录内的 moduleDir（只剥离开头的 `backend/`，与 TS 侧同口径）。 */
function moduleDirOfPathBase(pathBase) {
  const normalized = asString(pathBase).replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
  return normalized.startsWith('backend/') ? normalized.slice('backend/'.length) : normalized;
}

/** 服务身份后缀：`demo-backend-org` → `org`、`mdm-org` → `org`（与既有口径一致）。 */
function serviceSuffix(serviceId) {
  return serviceId.includes('-backend-')
    ? serviceId.replace(/^.*-backend-/, '')
    : serviceId.replace(/^[a-z0-9]+-/, '');
}

const uniqueBy = (items, keyOf) => {
  const seen = new Set();
  const out = [];
  for (const item of items) {
    const key = keyOf(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
};

/**
 * fresh micro 读面上下文：代码模块全集 + 代码根 + 既有归属真值。
 *
 * `codeRoot` = 项目产物根（projectArtifactDir）。工程方案 `pathBase` 的基准是它，不是
 * `docs/<ts>/plans/backend` 设计目录；由 `plans/backend` 上溯四级得到（docs/<ts>/plans/backend）。
 * 这样多 `buildUnits[].rootDir` / `codeModules[].pathBase` 工程不再假设单一后端根。
 */
export function freshMicroContextOfPlan(planDir, state) {
  const plan = state.plan;
  const codeRoot = resolve(planDir, '..', '..', '..', '..');
  const modules = (Array.isArray(plan.codeModules) ? plan.codeModules : [])
    .filter(isRecord)
    .map((module) => ({
      moduleId: asString(module.moduleId),
      pathBase: asString(module.pathBase),
      moduleDir: moduleDirOfPathBase(module.pathBase),
      modulePackage: asString(module.packageName) || null,
      buildUnitId: asString(module.buildUnitId),
      sourceDirs: Array.isArray(module.sourceDirs) ? module.sourceDirs.filter((dir) => typeof dir === 'string' && dir.trim()) : [],
      testDirs: Array.isArray(module.testDirs) ? module.testDirs.filter((dir) => typeof dir === 'string' && dir.trim()) : [],
      language: isRecord(module.stack) ? normalizeLanguageToken(module.stack.language) : '',
    }))
    .filter((module) => module.moduleId);

  const serviceRefsByModule = new Map();
  for (const binding of Array.isArray(plan.runtime) ? plan.runtime : []) {
    if (!isRecord(binding)) continue;
    const moduleId = asString(binding.moduleId);
    const serviceRef = asString(binding.serviceRef);
    if (!moduleId || !serviceRef) continue;
    serviceRefsByModule.set(moduleId, [...(serviceRefsByModule.get(moduleId) ?? []), serviceRef]);
  }
  const serviceBinding = readJsonSafe(resolve(planDir, '_meta', 'service-binding.json'));
  const entityBinding = readJsonSafe(resolve(planDir, '_meta', 'entity-module-binding.json'));
  return { plan, codeRoot, modules, serviceRefsByModule, serviceBinding, entityBinding };
}

const moduleMatchesService = (module, suffix) => {
  if (!suffix) return false;
  const lastPath = module.moduleDir.split('/').filter(Boolean).pop() ?? '';
  const lastPackage = (module.modulePackage ?? '').split('.').filter(Boolean).pop() ?? '';
  return [module.moduleId, lastPath, lastPackage].some((value) => value === suffix);
};

/**
 * 服务身份 → 代码模块（唯一判据）。
 *
 * 来源 = 工程方案 `runtime[].serviceRef`（显式绑定）∪ 模块 id/目录末段/包末段后缀匹配。
 * 多命中视为归属歧义，返回 candidates 由调用方报缺口，禁止任选其一。
 */
export function resolveFreshMicroServiceModule(ctx, serviceId) {
  const id = asString(serviceId);
  if (!id) return { kind: 'missing', reason: 'service-binding 未给出 serviceId' };
  const suffix = serviceSuffix(id);
  const runtimeHits = [];
  for (const [moduleId, refs] of ctx.serviceRefsByModule.entries()) {
    const hit = refs.some((ref) => ref === id || (suffix && serviceSuffix(ref) === suffix));
    if (!hit) continue;
    const module = ctx.modules.find((candidate) => candidate.moduleId === moduleId);
    if (module) runtimeHits.push(module);
  }
  // `runtime[].serviceRef` 是工程方案的显式运行关联，优先于模块身份后缀匹配；
  // 只有方案没有运行关联（如共享库/未部署模块）时才用 serviceId 后缀兜底。
  const candidates = runtimeHits.length
    ? uniqueBy(runtimeHits, (module) => module.moduleId)
    : uniqueBy(ctx.modules.filter((module) => moduleMatchesService(module, suffix)), (module) => module.moduleId);
  if (candidates.length === 1) return { kind: 'bound', module: candidates[0] };
  if (candidates.length > 1) {
    return { kind: 'ambiguous', candidates, reason: `服务 ${id} 命中多个代码模块（${candidates.map((m) => m.moduleId).join('、')}）` };
  }
  return { kind: 'missing', reason: `服务 ${id} 在工程方案 runtime[] 与 codeModules[] 中都没有唯一归属` };
}

/** 实体 slug：`entity-<slug>.md` → `<slug>`（整串保留 `-`/`.`/`:`，不归一化）。 */
function entitySlugOfFile(entityFilePath) {
  const match = /^entity-(.+)\.md$/.exec(basename(entityFilePath));
  return match ? match[1] : '';
}

const ENTITY_DOMAIN_PATTERN = /业务领域[：:]\s*([A-Za-z0-9_-]+)/;
function entityDomainOfFile(entityFilePath) {
  try {
    const header = readFileSync(entityFilePath, 'utf-8').split('\n').slice(0, 6).join('\n');
    return header.match(ENTITY_DOMAIN_PATTERN)?.[1] ?? '';
  } catch {
    return '';
  }
}

function serviceIdOfDomain(ctx, domainId) {
  const domains = Array.isArray(ctx.serviceBinding?.domains) ? ctx.serviceBinding.domains : [];
  for (const entry of domains) {
    if (isRecord(entry) && asString(entry.domain) === domainId) return asString(entry.serviceId);
  }
  return '';
}

/**
 * fresh micro 实体 → 代码模块落点（与 TS 侧 `resolveFreshMicroEntityPlacement` 同序）：
 *   ① `entity-module-binding.json` 的 entitySlug → moduleId（既有投影绑定）；
 *   ② 实体头「业务领域」→ `service-binding.json` 的 serviceId → 代码模块唯一匹配；
 *   ③ 不可判 ⇒ 显式 unbound/ambiguous/service-without-module，禁回落 README/旧 modules/域名字面。
 */
export function resolveFreshMicroEntityPlacement(ctx, entityFilePath) {
  const slug = entitySlugOfFile(entityFilePath);
  const bindings = Array.isArray(ctx.entityBinding?.bindings) ? ctx.entityBinding.bindings : [];
  if (slug) {
    for (const entry of bindings) {
      if (!isRecord(entry) || asString(entry.entitySlug) !== slug) continue;
      const moduleId = asString(entry.moduleId);
      const module = ctx.modules.find((candidate) => candidate.moduleId === moduleId);
      if (module) return { kind: 'bound', source: 'entity-binding', module };
      if (moduleId) return { kind: 'unbound', reason: `entity-module-binding 引用了不存在的代码模块 ${moduleId}` };
    }
  }
  const domain = entityDomainOfFile(entityFilePath);
  const serviceId = domain ? serviceIdOfDomain(ctx, domain) : '';
  if (!serviceId) {
    return {
      kind: 'unbound',
      reason: domain
        ? `领域 ${domain} 未在 service-binding.json 绑定服务，且 entity-module-binding.json 无该实体投影`
        : '实体文件头未标注业务领域，且 entity-module-binding.json 无该实体投影',
    };
  }
  const matched = resolveFreshMicroServiceModule(ctx, serviceId);
  if (matched.kind === 'bound') {
    return { kind: 'bound', source: 'service-binding', module: matched.module, domain, serviceId };
  }
  if (matched.kind === 'ambiguous') {
    return { kind: 'ambiguous', reason: matched.reason, domain, serviceId };
  }
  return { kind: 'service-without-module', reason: matched.reason, domain, serviceId };
}

/**
 * 读 skeleton-conventions.json（plans/backend/_meta/）——骨架实现约定与根包的契约读面。
 *
 * 返回 `{ rootPackage, conventions, source, measuredPresent }` 或 null（legacy 文件缺失/不可解析）。
 *
 * micro 工程方案在场（fresh v1 / incremental v2 由 readMicroEngineeringPlan 一并放行）：
 *   · `rootPackage` 由工程方案 `codeModules[].packageName` 公共前缀推导（build 实测产物不是根包真值）；
 *   · `conventions` 仍取实测 skeleton-conventions.json 的角色真名（layerPackages / commonPackageMapping 等）；
 *     实测产物在 build 实现后才生成，故此处不因它缺席而返回 null——调用方按场景决定缺口口径；
 *   · 工程方案 invalid ⇒ throw（带版本/形态原因），禁止回落旧 conventions。
 * legacy：逐字保持旧行为（文件缺失/不可解析 ⇒ null；rootPackage 取 json.rootPackage）。
 */
export function loadSkeletonConventions(planDir) {
  if (!planDir) return null;
  const state = readMicroEngineeringPlan(planDir);
  if (state.kind === 'invalid') {
    throw new Error(
      `[backend-common] 工程方案不可用：${state.reason}（${state.planPath}）。` +
        '责任面 = 工程方案生产任务；禁止回落旧 skeleton-conventions/目录猜测。',
    );
  }
  const p = resolve(planDir, '_meta', 'skeleton-conventions.json');
  const measuredPresent = existsSync(p);
  const json = measuredPresent ? readJsonSafe(p) : null;
  const measuredObject = isRecord(json);

  if (state.kind === 'fresh-micro' || state.kind === 'incremental-micro') {
    const root = resolveRootPackageFromEngineeringPlan(state.plan);
    const convs = measuredObject && isRecord(json.conventions) ? json.conventions : {};
    return {
      rootPackage: root.ok ? root.rootPackage : null,
      rootPackageReason: root.ok ? undefined : root.reason,
      conventions: convs,
      source: 'engineering-plan',
      measuredPresent: measuredObject,
      engineeringPlan: state.plan,
    };
  }

  // ── legacy：逐字保持改造前语义 ──
  if (!json || typeof json !== 'object') return null;
  const root = typeof json.rootPackage === 'string' && json.rootPackage.trim() ? json.rootPackage.trim() : null;
  const convs = json.conventions && typeof json.conventions === 'object' && !Array.isArray(json.conventions) ? json.conventions : {};
  return { rootPackage: root, conventions: convs, source: 'skeleton-conventions', measuredPresent: true };
}

// ── 根包动态解析（与 project.ts resolveBackendRootPackage 同源，纯脚本侧）──────────────
// 唯一真理源 = 后端骨架盘上；优先读 README §9.1，缺/不可解析回退扫骨架 src/main/java/。
function walkSingleChildChain(javaRoot) {
  const segments = [];
  let current = javaRoot;
  while (segments.length < 32) {
    let entries;
    try {
      entries = readdirSync(current, { withFileTypes: true });
    } catch {
      break;
    }
    const dirs = entries.filter((e) => e.isDirectory());
    const files = entries.filter((e) => e.isFile() && e.name !== '.gitkeep');
    if (files.length > 0 || dirs.length !== 1) break;
    segments.push(dirs[0].name);
    current = resolve(current, dirs[0].name);
  }
  return segments.length > 0 ? segments : null;
}
function pascalCase(s) {
  return s.split(/[-_]+/).filter(Boolean).map((seg) => seg.charAt(0).toUpperCase() + seg.slice(1)).join('');
}
function scanJavaClass(dir, suffix) {
  let entries;
  try {
    entries = readdirSync(dir, { withFileTypes: true });
  } catch {
    return null;
  }
  for (const e of entries) {
    if (!e.isFile()) continue;
    if (e.name.endsWith(`${suffix}.java`)) return e.name.slice(0, -5);
  }
  return null;
}
function parseReadmeRootPackage(text) {
  const headerM = text.match(/###\s+9\.1\s+根包名[^\n]*/);
  if (!headerM) return null;
  const start = headerM.index + headerM[0].length;
  const after = text.slice(start);
  const nextM = after.match(/\n#{2,3}\s/);
  const section = nextM ? after.slice(0, nextM.index) : after;
  const backM = section.match(/`([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+){2,})`/);
  if (backM) return backM[1];
  const codeBlockM = section.match(/```\s*\n\s*([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+)+)\s*\n\s*```/);
  if (codeBlockM) return codeBlockM[1];
  const bareM = section.match(/(^|[^\w.])([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]+){1,})([^\w.]|$)/);
  return bareM ? bareM[2] : null;
}
/** 解析后端根包 → { dot: 'com.company.<appName>', slash: 'com/company/<appName>' }。
 *
 * fresh micro（工程方案在场且自描述匹配）：根包只取 `codeModules[].packageName` 公共前缀，
 * **禁读 README §9.1、禁扫盘面包树、禁兜底假包名**；方案 invalid/根包不可判定 ⇒ throw（fail loud）。
 * legacy：逐字保持 README §9.1 → 包树扫描 → 占位兜底的原顺序。 */
export function resolveRootPackage(backendDir, cwd = process.cwd()) {
  const planBackendDir = resolvePlanBackendDir(cwd);
  if (planBackendDir) {
    const state = readFreshMicroEngineeringPlan(planBackendDir);
    if (state.kind === 'invalid') {
      throw new Error(
        `[fresh-micro] 根包不可判定：${state.reason}（${state.planPath}）。` +
          '责任面 = 工程方案生产任务；禁止回落 README §9.1 / 包树 walk / com.company 默认值。',
      );
    }
    if (state.kind === 'fresh-micro') {
      const root = resolveRootPackageFromEngineeringPlan(state.plan);
      if (!root.ok) {
        throw new Error(
          `[fresh-micro] 根包不可判定：${root.reason}（${state.planPath}）。` +
            '责任面 = 工程方案生产任务；禁止回落 README §9.1 / 包树 walk / com.company 默认值。',
        );
      }
      return { dot: root.rootPackage, slash: root.rootPackage.replace(/\./g, '/') };
    }
  }
  if (planBackendDir) {
    const readme = resolve(planBackendDir, 'README.md');
    if (existsSync(readme)) {
      const root = parseReadmeRootPackage(readFileSync(readme, 'utf-8'));
      if (root) return { dot: root, slash: root.replace(/\./g, '/') };
    }
  }
  const javaRoot = resolve(backendDir, 'src', 'main', 'java');
  if (existsSync(javaRoot)) {
    const segs = walkSingleChildChain(javaRoot);
    if (segs && segs.length > 1) return { dot: segs.join('.'), slash: segs.join('/') };
  }
  // 兜底占位（正常路径由上方 README/包树扫描得 com.company.<appName>，永不命中）。
  return { dot: 'com.company.app', slash: 'com/company/app' };
}

/**
 * 从 README §9.2 表格解析 domain→modulePackage 映射。
 * 返回 Map<domainId, { modulePkg, type }>。
 *   - modulePkg：L299 四列表的 cells[3]（如 com.company.<appName>.fund）
 *   - type：L56 五列表的 cells[3]（core/support/common），用于公共层判定，
 *     避免靠包名字面 .common. 硬编码（换应用公共层包叫 public/shared 也适用）。
 *   - type 缺失（L56 表不存在或未匹配）时为 undefined，归桶脚本兜底用 modulePkg 字面。
 */
export function parseDomainModuleMap(cwd = process.cwd()) {
  const map = new Map();
  const planBackendDir = resolvePlanBackendDir(cwd);
  if (!planBackendDir) return map;
  const freshState = readFreshMicroEngineeringPlan(planBackendDir);
  if (freshState.kind === 'invalid') {
    throw new Error(
      `[fresh-micro] 域→modulePackage 映射不可判定：${freshState.reason}（${freshState.planPath}）。` +
        '责任面 = 工程方案生产任务；禁止回落 README §9.2 / 旧模块清单。',
    );
  }
  const readme = resolve(planBackendDir, 'README.md');
  const text = existsSync(readme) ? readFileSync(readme, 'utf-8') : '';
  const headerM = text.match(/###\s+9\.2\s+领域/);
  const start = headerM ? headerM.index + headerM[0].length : 0;
  const after = headerM ? text.slice(start) : '';
  const nextM = after.match(/\n#{2,3}\s/);
  const section = nextM ? after.slice(0, nextM.index) : after;
  // 第一遍：解析含「类型」列的五列表（业务领域|领域标识|类型|归并模块|模块目录）拿 domainId→type。
  // 该表在 README 第 3 章（早于 §9.2），故搜整个文件而非 section。
  // 表头含「领域标识」+「类型」，不含「modulePackage」。
  const allLines = text.split('\n');
  const typeMap = new Map();
  let inTypeTable = false;
  for (const line of allLines) {
    if (inTypeTable && line.startsWith('|')) {
      const cells = line.split('|').map((c) => c.trim());
      if (cells.length >= 4) {
        const domainId = cells[2];
        const type = cells[3];
        // 域标识取 canonical 原样（含连字符：`org-master-data`）——域 id 形态收紧见下方第二遍注释。
        if (domainId && type && /^[a-z][a-z0-9_.-]*$/.test(domainId) && /^(core|support|common)$/.test(type)) {
          typeMap.set(domainId, type);
        }
      }
      // 分隔线（|---|---|）后的数据行解析完即停（遇空行或非表格行）
      if (!line.includes('|') || cells.every((c) => !c)) { inTypeTable = false; }
    }
    if (line.startsWith('|') && line.includes('领域标识') && line.includes('类型') && !line.includes('modulePackage')) {
      inTypeTable = true;
      continue;
    }
  }

  // 第二遍：解析 §9.2 四列表（领域标识|归并模块|modulePackage|目录）拿 domainId→modulePkg。
  //
  // 捕获语法 = **canonical 原样**（micro 形态 outset 后拓宽，plan
  // 2026-10-18/micro1009-build-preflight-backend-engineering §1.T5 / §3 约束 3）：
  //   · 域标识：连字符分隔的 canonical id（`org-master-data`）与 `mdm-*` 模块 id 都要被**整段**收下
  //     （旧形态 `[a-z0-9_.]` 会把它们静默丢弃 ⇒ 微服务形态整表解析为空）；
  //   · modulePackage：末段是 T2 包名派生器的**驼峰短名**（`externalPerson` / `permTrace` / `noPerm`），
  //     故**首字母之后**段字符集须含大写（Java 包段允许驼峰），且**不许以分隔符结尾**
  //     （末位锚 `[A-Za-z0-9]` 拒 `-`/`_`/`.` 收尾）。
  // 域标识只许小写（canonical id 全小写）；两处均为**收紧面**——旧宽式（域标识容大写、
  // modulePackage 容尾分隔符）会静默收坏值，顺 `parseDomainModuleMap` 流向 precreate / type-registry 输入面。
  const lines = section.split('\n');
  // 表头含「领域标识」+「modulePackage」。
  let inPkgTable = false;
  for (const line of lines) {
    if (inPkgTable && line.startsWith('|')) {
      const cells = line.split('|').map((c) => c.trim());
      if (cells.length >= 4) {
        const domainId = cells[1];
        const modulePkg = cells[3];
        if (
          domainId &&
          modulePkg &&
          !domainId.match(/^[-:|]+$/) &&
          /^[a-z][a-z0-9_.-]*$/.test(domainId) &&
          /^[a-z][A-Za-z0-9_.-]*[A-Za-z0-9]$/.test(modulePkg)
        ) {
          map.set(domainId, { modulePkg, type: typeMap.get(domainId) });
        }
      }
    }
    if (line.startsWith('|') && line.includes('领域标识') && line.includes('modulePackage')) {
      inPkgTable = true;
      continue;
    }
  }

  // fresh micro 兜底：README §9.2 可能尚未包含全部域，或干脆缺席；此时用
  // 工程方案 `codeModules[]` + `service-binding.json` 的唯一服务归属补齐。
  // **禁读 `skeleton-conventions.module.modules[].serviceName`**：实测产物没有该写者，
  // 按它匹配会把多模块域静默丢空（旧实现已知缺口）。README 已有条目保持优先，不被覆盖。
  if (freshState.kind === 'fresh-micro') {
    const ctx = freshMicroContextOfPlan(planBackendDir, freshState);
    const domains = Array.isArray(ctx.serviceBinding?.domains) ? ctx.serviceBinding.domains : [];
    for (const entry of domains) {
      if (!isRecord(entry)) continue;
      const domainId = asString(entry.domain);
      if (!domainId || map.has(domainId)) continue;
      const resolved = resolveFreshMicroServiceModule(ctx, asString(entry.serviceId));
      if (resolved.kind !== 'bound' || !resolved.module.modulePackage) continue;
      map.set(domainId, { modulePkg: resolved.module.modulePackage, type: typeMap.get(domainId) });
    }
  }
  return map;
}

// ── 多模块 Maven 工程定位（启动模块 + surefire 报告收集）──────────────────────────────
// 多模块 reactor（RuoYi：根 pom packaging=pom 仅聚合，启动类在各子模块、surefire 报告落各子模块 target/），
// 根 target/ 既无启动类也无测试报告。两个纯函数（机械、栈无关、不读 README）供 check-backend-startup/test 共用，
// 消除各脚本本地副本漂移 + 修「根 target/ 唯一」假设致的多模块盲区（C0 退化 stdout 兜底 / B1 失败 .txt 扫不到）。

/**
 * 定位「含 @SpringBootApplication 启动类」的子模块目录（多模块聚合工程）。
 * 扫描 backendDir 一级子目录（须含 pom.xml），递归找 src/main/java 下内容含 @SpringBootApplication 的 .java，
 * 返回该模块目录；未命中（单模块工程，启动类在根）返回 null，调用方退化为在 backendDir 上直接执行。
 * 与 check-backend-startup.mjs 原 L378 本地实现同源——上提共享，两脚本共用。
 */
export function findBootModuleDir(backendDir) {
  let entries;
  try { entries = readdirSync(backendDir); } catch { return null; }
  const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };
  for (const name of entries) {
    const modDir = resolve(backendDir, name);
    if (!isDir(modDir)) continue;
    if (!existsSync(resolve(modDir, 'pom.xml'))) continue;
    const javaRoot = resolve(modDir, 'src', 'main', 'java');
    if (!existsSync(javaRoot)) continue;
    // 递归扫 *.java，匹配 @SpringBootApplication
    const stack = [javaRoot];
    let found = false;
    while (stack.length) {
      const dir = stack.pop();
      let sub;
      try { sub = readdirSync(dir, { withFileTypes: true }); } catch { continue; }
      for (const e of sub) {
        const p = resolve(dir, e.name);
        if (e.isDirectory()) { stack.push(p); continue; }
        if (!e.name.endsWith('.java')) continue;
        let txt;
        try { txt = readFileSync(p, 'utf-8'); } catch { continue; }
        if (txt.includes('@SpringBootApplication')) { found = true; break; }
      }
      if (found) break;
    }
    if (found) return modDir;
  }
  return null;
}

/**
 * 收集 backendDir 下所有 surefire-reports 目录（多模块 reactor：报告落各子模块 target/surefire-reports/）。
 * 递归扫描，匹配「parent=target 且 basename=surefire-reports」的目录；不误入 target/classes、不扫 node_modules/.git。
 * 单模块工程退化为 [根 target/surefire-reports]（向后兼容旧单根读取语义）。
 * 返回数组（可能为空：测试未运行/报告未落盘）——调用方据此区分「真无报告」与「单根写死」。
 */
export function collectSurefireReportDirs(backendDir) {
  const dirs = [];
  const seen = new Set();
  const SKIP = new Set(['node_modules', '.git', '.idea', 'dist', 'build']); // build=Gradle，不扫 Gradle 产出
  const walk = (dir) => {
    let entries;
    try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const e of entries) {
      if (!e.isDirectory()) continue;
      if (SKIP.has(e.name)) continue;
      const p = resolve(dir, e.name);
      if (e.name === 'surefire-reports' && basename(resolve(dir)) === 'target') {
        if (!seen.has(p)) { seen.add(p); dirs.push(p); }
        continue; // surefire-reports 内不再下钻
      }
      walk(p);
    }
  };
  // 先放根 target/surefire-reports（单模块主路径），再递归补子模块
  const rootSf = resolve(backendDir, 'target', 'surefire-reports');
  if (existsSync(rootSf) && statSync(rootSf).isDirectory()) { seen.add(rootSf); dirs.push(rootSf); }
  walk(backendDir);
  return dirs;
}

/**
 * 收集 backendDir 自身 + 全部一级子模块目录（多模块 reactor：每个含 pom.xml 的直接子目录）。
 * 单模块工程退化为 [backendDir]（无子模块）。供「按 FQN 找 .java」跨子模块定位——
 * 多模块下业务/框架类散落各子模块 src/main/java（如 ruoyi-common 的 ApiResponse、ruoyi-admin 的启动类），
 * 只查根 src/main/java 会漏。返回目录数组（含 backendDir）。
 */
export function collectModuleDirs(backendDir) {
  const dirs = [backendDir];
  let entries;
  try { entries = readdirSync(backendDir); } catch { return dirs; }
  for (const name of entries) {
    const modDir = resolve(backendDir, name);
    try { if (!statSync(modDir).isDirectory()) continue; } catch { continue; }
    if (existsSync(resolve(modDir, 'pom.xml')) || existsSync(resolve(modDir, 'build.gradle')) || existsSync(resolve(modDir, 'build.gradle.kts'))) dirs.push(modDir);
  }
  return dirs;
}

/**
 * 按 Java FQN 的相对路径（com/company/x/Y → com/company/x/Y.java）在 backendDir 的根 + 各子模块
 * src/main/java 下查找真实 .java 文件，返回首个命中路径；未命中返回 null。
 * 机械保证 skeleton-conventions 记的 fqn 非臆测类名——跨子模块 reactor 也能定位。
 */
export function findJavaByRel(backendDir, rel) {
  for (const modDir of collectModuleDirs(backendDir)) {
    const p = resolve(modDir, 'src', 'main', 'java', rel);
    if (existsSync(p)) return p;
  }
  return null;
}
