import fs from 'fs';
import path from 'path';

import {
  PENDING,
  FOREIGN,
  IMPORTANT,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  getPathReg,
  readFile,
  readdirSync,
  readFileSync,
  readJSONSync,
  relativeFilePathToBundle,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  omitContentByTitleKeywords,
  getAbsoluteFilePathWhenExisted,
  readFileSyncWithRelativeFilePath,
} from './tools.mjs';

import {
  parseQuote,
  parseTitle,
  parseToList,
  parseMenusToTable,
} from './parse.mjs';

/**
 * 要省略的关键词列表
 *
 * @description 在文件处理时，包含这些关键词的内容会被省略或替换
 * 默认包含：【当前业务功能无关】
 *
 * @type {Array<string>}
 */
export const omitKeywords = [FOREIGN.NONMATCHED];

/**
 * 将绝对路径转换为相对路径
 *
 * @description 移除根目录前缀，将绝对路径转换为相对路径
 * 同时处理特殊的路径格式（如 Markdown 链接中的路径）
 * 并规范化当前应用 docs 日期目录引用
 *
 * @param {string} rootDir - 项目根目录
 *
 * @returns {Function} 返回一个函数，接收源路径参数
 *
 * @example
 * const converter = toRelativeFilePath('/path/to/project');
 * converter('/path/to/project/my-app/docs/{日期}/plans/index.md')
 * // 返回 'my-app/docs/{日期}/plans/index.md'
 */
export const toRelativeFilePath = (rootDir) => (source) => {
  rootDir = rootDir || process.cwd();

  const activeSpecDir = getActiveSpecDir(rootDir) || '';
  const specFolder = activeSpecDir.replace(`${rootDir}/`, '');

  const activeSpecRelative = specFolder.split(path.sep).join('/');
  const dateDirectoryPattern = /[^/]+\/docs\/[^/]+/g;

  return source
    .replace(rootDir, '')
    .replace(/^\//g, '')
    .replace(/\(\//g, '(')
    .replace(/,L(?=[0-9])+/g, ',')
    .replace(dateDirectoryPattern, activeSpecRelative);
};

/**
 * 将文件路径转换为 Markdown 链接字符串
 *
 * @description 根据文件路径读取文件标题，生成 Markdown 格式的链接
 * 支持缓存以提高性能
 *
 * @param {string} rootDir - 项目根目录
 * @param {Object} store - 缓存对象，存储已处理的路径
 * @param {Array<string>} filePaths - 文件路径列表
 *
 * @returns {Function} 返回一个函数，接收源路径参数
 *
 * @example
 * const converter = filePathToString('/path/to/project', {}, []);
 * converter('plans/index.md')
 * // 返回指向当前应用 docs 日期目录的 Markdown 链接
 */
export const filePathToString =
  (rootDir, store = {}, filePaths = []) =>
  (source) => {
    rootDir = rootDir || process.cwd();

    const activeSpecDir = getActiveSpecDir(rootDir);
    const targetRelativePath = toRelativeFilePath(rootDir)(source);

    const activeSpecRelative = path.relative(rootDir, activeSpecDir).split(path.sep).join('/');
    const documentRelativeInput = targetRelativePath.startsWith('inputs/');
    const useful = documentRelativeInput || targetRelativePath.startsWith(`${activeSpecRelative}/`);
    const find = (item) => item?.endsWith(targetRelativePath);
    const bundle = !useful && findUnderSpecs(rootDir)(find);

    let targetAbsolutePath = documentRelativeInput
      ? path.resolve(activeSpecDir, targetRelativePath)
      : path.resolve(rootDir, targetRelativePath);

    if (store[targetAbsolutePath]) {
      return store[targetAbsolutePath];
    }

    if (!fs.existsSync(targetAbsolutePath)) {
      const found = filePaths.find((item) => item.endsWith(targetAbsolutePath));
      targetAbsolutePath = path.resolve(activeSpecDir, targetRelativePath);
    }

    if (!fs.existsSync(targetAbsolutePath)) {
      return targetRelativePath;
    }

    const targetContent = readFileSync(targetAbsolutePath.trim());

    if (targetContent.includes(PENDING)) {
      return targetRelativePath;
    }

    const title = parseTitle(targetContent) || '关联文档';
    const replaced = title.replace(/[\[\]\(\)]+/g, '');

    const quoteFilePath = bundle?.quoteFilePath || targetRelativePath;

    store[targetAbsolutePath] = `[${replaced}](${quoteFilePath})`;
    return store[targetAbsolutePath];
  };

/**
 * 文档文件过滤器
 *
 * @description 判断文件是否应该被处理
 * 排除特定的持久化配置文件和临时文件
 *
 * @param {string} item - 文件路径
 *
 * @returns {boolean} 如果应该处理返回 true
 *
 * @example
 * filterForDocuments('plans/index.md') // 返回 true
 * filterForDocuments('pieces/content.md') // 返回 false
 */
export const filterForDocuments = (item = '') => {
  const keywords = [
    'plans/frontend/routes.md',
    'pieces/content.md',
    'pieces/ignore-section.md',
    'pieces/ignore-content.md',
    'pieces/content-',
    'pieces/design-',
    'pieces/ignored-content-',
  ];

  const some = (keyword) => !item.includes(keyword);
  const useful = keywords.every(some);

  return useful;
};

/**
 * 匹配所有项的过滤器
 *
 * @description 总是返回 true，用于不需要条件过滤的场景
 *
 * @returns {boolean} 总是返回 true
 */
export const matchAll = () => true;

export const designUrlReg =
  /https?:\/\/(?:[a-z0-9-]+\.)*(?:mastergo\.com|figma\.com)(?::\d+)?(?:[/?#][^\s<>()\]]*)?/gi;
export const imageUrlReg =
  /https?:\/\/[^\s<>()\]]+\.(?:png|jpe?g|jeg|jepg|webp)(?:[?#][^\s<>()\]]*)?/gi;

export const extractDesignUrls = (source = '') => {
  if (typeof source !== 'string') {
    return [];
  }

  const matched = source.match(designUrlReg) || [];
  return [...new Set(matched)];
};

export const extractImageUrls = (source = '') => {
  if (typeof source !== 'string') {
    return [];
  }

  const designUrls = new Set(extractDesignUrls(source));
  const matched = source.match(imageUrlReg) || [];
  return [...new Set(matched)].filter((url) => !designUrls.has(url));
};

const writeDesignUrlSection = (source = '', segments = []) => {
  const map = (item) => `- ${item}`;

  const joined = segments.join('\n');

  const designUrls = extractDesignUrls(joined);
  const imageUrls = extractImageUrls(joined);
  const designContent = designUrls.length ? designUrls.map(map).join('\n') : '无设计稿地址';
  const imageContent = imageUrls.length ? imageUrls.map(map).join('\n') : '无图片地址';
  const sections = [
    `### 设计稿地址\n\n${designContent}`,
    `### 图片地址\n\n${imageContent}`,
  ].join('\n\n');
  const reg = /\n*### (?:设计稿地址|图片地址)[^\S\r\n]*\r?\n[\s\S]*$/;
  const cleaned = source.replace(reg, '').replace(/\s*$/g, '');

  return `${cleaned}\n\n${sections}\n`;
};

export const appendDesignUrlSection = (source = '', ...segments) =>
  writeDesignUrlSection(source, [source, ...segments]);

/**
 * 根据 checklist 文件名解析其唯一对应的需求片段文件。
 *
 * checklist-<模块键>.md 只允许匹配：
 * - pieces/design-<模块键>.md
 * - pieces/content-<模块键>.md
 *
 * @param {string} absoluteFilePath - checklist 绝对路径
 * @returns {{ design: string, content: string } | undefined}
 */
export const getChecklistDesignSourcePaths = (absoluteFilePath = '') => {
  const matched = path.basename(absoluteFilePath).match(/^checklist-(.+)\.md$/);
  const moduleKey = matched?.[1];

  if (!moduleKey) {
    return;
  }

  return {
    design: `pieces/design-${moduleKey}.md`,
    content: `pieces/content-${moduleKey}.md`,
  };
};

export const appendChecklistDesignUrlSection = (rootDir) => (source, absoluteFilePath) => {
  const sourcePaths = getChecklistDesignSourcePaths(absoluteFilePath);

  if (!sourcePaths) {
    return source;
  }

  const readRelativeFileSync = readFileSyncWithRelativeFilePath(rootDir);
  const designSource = readRelativeFileSync(sourcePaths.design) || '';
  const contentSource = readRelativeFileSync(sourcePaths.content) || '';

  // checklist 的地址只能来自当前模块严格对应的 design/content 文件，
  // 不从 checklist 自身或名称相似的其他模块继承历史地址。
  return writeDesignUrlSection(source, [designSource, contentSource]);
};

export const appendUiDesignUrlSection = (rootDir) => (source, absoluteFilePath) => {
  // 只读取目标文档同目录的原始来源，避免跨规范目录混入地址。
  const piecesDir = path.dirname(absoluteFilePath);
  const canonicalPath = path.join(piecesDir, 'content-design.md');
  const legacyPath = path.join(piecesDir, 'contend-design.md');
  const sourcePath = fs.existsSync(canonicalPath) ? canonicalPath : legacyPath;

  if (!fs.existsSync(sourcePath)) {
    return source;
  }

  return writeDesignUrlSection(source, [fs.readFileSync(sourcePath, 'utf8')]);
};

/**
 * 文件内容处理器列表
 *
 * @description 定义了一系列文件内容处理规则
 * 每个处理器可以有条件匹配和替换函数
 * 按顺序应用到文件内容
 *
 * @type {Array<Object>}
 * @property {Function} match - 条件匹配函数（可选）
 * @property {Function} replace - 内容替换函数
 *
 * @example
 * // 处理器会按顺序应用：
 * // 1. 移除所有 HTML 注释
 * // 2. 为前端视图文件添加设计链接
 * // 3. 省略无关内容
 * // 4. 修复表格格式
 * // 5. 合并多余的空行
 */
export const handlers = [
  {
    replace: (rootDir) => (source) =>
      source.replace(/<!--[^<>]*-->/g, (string) => {
        return string === PENDING ? string : '';
      }),
  },
  {
    match: (item) => /[/\\]specs[/\\]checklist-[^/\\]+\.md$/.test(item || ''),
    replace: appendChecklistDesignUrlSection,
  },
  {
    match: (item) => /[/\\]pieces[/\\]ui-design\.md$/.test(item || ''),
    replace: appendUiDesignUrlSection,
  },
  {
    replace: (rootDir) => omitContentByTitleKeywords(omitKeywords, '无匹配内容'),
  },
  {
    match: (item) => item?.endsWith?.('specs/terms.md'),
    replace: (rootDir) => (source) => source.replace(/\|[\n\s]+\|/g, '|\n|'),
  },
  {
    replace: (rootDir) => (source) => source.replace(/\n{3,}/g, '\n\n'),
  },
];

/**
 * 初始化占位符文件
 *
 * @description 为规范初始化创建必要的占位符文件
 * 包括变更日志目录、需求文档和预检查文件
 * 如果这些文件不存在，则创建空的占位符文件
 *
 * @param {string} rootDir - 项目根目录
 *
 * @example
 * writeForPlaceholder('/path/to/project');
 * // 创建以下文件（如果不存在）：
 * // - .changelogs/plans/placeholder.md
 * // - .changelogs/specs/placeholder.md
 * // - pieces/precheck.md
 */
export const writeForPlaceholder = (() => {
  const relativeFilePaths = [
    '.changelogs/plans/placeholder.md',
    '.changelogs/specs/placeholder.md',
    'pieces/precheck.md',
  ];

  const writeToRootDir = (rootDir) => (relativeFilePath) => {
    const activeSpecDir = getActiveSpecDir(rootDir);

    if (!activeSpecDir) {
      return;
    }

    const absoulteFilePath = path.resolve(activeSpecDir, relativeFilePath);

    const find = (item) => item.endsWith(relativeFilePath);
    const found = findUnderSpecs(rootDir)(find);

    !found && writeToFileSync('', absoulteFilePath)('');
  };

  return (rootDir) => {
    const write = writeToRootDir(rootDir);

    relativeFilePaths.forEach(write);
  };
})();

/**
 * 处理临时文件
 *
 * @description 查找并重命名所有临时文件（temp- 前缀）
 * 移除 temp- 前缀，使其成为正式文件
 *
 * @param {string} rootDir - 项目根目录
 *
 * @example
 * writeForTemps('/path/to/project');
 * // 将 plans/data-model/temp-User.md 重命名为 plans/data-model/User.md
 */
export const writeForTemps = (rootDir) => {
  const filterForTempFiles = (item = '') => {
    const inDataModel = item.includes('plans/data-model/temp-');
    const inFrontend = item.includes('plans/frontend/temp-');
    const inBackend = item.includes('plans/backend/temp-');

    return inDataModel || inFrontend || inBackend;
  };

  const bundles = filterUnderSpecs(rootDir)(filterForTempFiles) || [];

  bundles.forEach((bundle = {}, index) => {
    const { fileName, absoluteDir, absoluteFilePath } = bundle;

    const newFileName = fileName.replace(/^temp-/, '');
    const newPath = path.join(absoluteDir, newFileName);

    fs.renameSync(absoluteFilePath, newPath);
  });
};

/**
 * 修正文件内容
 *
 * @description 对规范目录下的所有文件应用内容处理器
 * 包括：初始化必要文件、处理临时文件、应用内容转换规则
 *
 * @param {string} rootDir - 项目根目录，默认为 process.cwd()
 * @param {boolean} onlyForPath - 是否仅处理路径，不处理内容
 *
 * @example
 * correctToFile('/path/to/project');
 * // 处理所有文件，应用内容转换规则
 */
export const correctToFile = (rootDir = '', onlyForPath = false) => {
  rootDir = rootDir || process.cwd();

  writeForPlaceholder(rootDir);
  writeForTemps(rootDir);

  const store = {};
  const activeSpecDir = getActiveSpecDir(rootDir);

  const activeSpecList = readdirSync(activeSpecDir);
  const filePaths = activeSpecList
    .filter((item) => !item.startsWith('build'))
    .filter((item) => item.endsWith('.md'))
    .filter(filterForDocuments);

  const toString = filePathToString(rootDir, store, filePaths);

  filePaths.forEach((filePath) => {
    const absoluteFilePath = path.resolve(activeSpecDir, filePath);
    const content = readFileSync(absoluteFilePath);

    const initial = handlers.reduce((result, hanlder = {}) => {
      if (onlyForPath) {
        return result;
      }

      const { replace, match = matchAll } = hanlder;

      const matched = match(absoluteFilePath);
      const handled = matched && replace(rootDir)(result, absoluteFilePath);

      return handled || result;
    }, content);

    const replaced = initial.replace(/[^\n]*\.md[^\n]*/g, (line = '') => {
      const filePathReg = getPathReg();
      const todoReg = /\[\s*\]/g;
      const quoteReg = /[\[(].+[\])]/g;
      const rawQuoteReg = /^\[L[0-9]+/g;
      const usefulQuoteReg = /^\[[^()\[\]\.]+\]\((?:inputs\/|[^/]+\/docs\/[^/]+\/)[^()\[\]]+\.md\)$/g;

      const [filePath = '', ...extra] = line.match(filePathReg) || [];
      const [quote = ''] = line.replace(todoReg, '').match(quoteReg) || [];

      const useful = usefulQuoteReg.test(quote) || rawQuoteReg.test(quote);
      const multi = extra.some((item) => item !== filePath);

      if (multi) {
        return toRelativeFilePath(rootDir)(line);
      }

      if (!filePath) {
        return line;
      }

      const got = toString(filePath);

      return line.replace(quote || filePath, got);
    });

    if (replaced === content) {
      return;
    }

    fs.writeFileSync(absoluteFilePath, replaced);
  });
};

/**
 * 合并多个内容组
 *
 * @description 将多个内容组合并为一个字符串
 * 使用指定的分隔符连接，并移除多余的空行
 *
 * @param {string} spliter - 分隔符，默认为 '\n\n'
 *
 * @returns {Function} 返回一个函数，接收多个内容组参数
 *
 * @example
 * const merger = mergeGroups('\n\n');
 * const result = merger('# 标题', '内容1', '内容2');
 * // 返回 '# 标题\n\n内容1\n\n内容2'
 */
export const mergeGroups =
  (spliter = '\n\n') =>
  (...groups) => {
    const array = groups.flat();

    return array.join(spliter).replace(/\n{3,}/g, '\n\n');
  };

/**
 * 从仓库中同步读取文件
 *
 * @description 从 .specify/warehouse 目录中读取对应的文件
 * 用于获取文件的原始版本或模板
 *
 * @param {string} absoluteFilePath - 文件的绝对路径
 *
 * @returns {string|undefined} 仓库中对应文件的内容
 *
 * @example
 * const content = readWarehouseFileSync('/path/to/my-app/docs/{日期}/plans/index.md');
 * // 返回 .specify/warehouse/plans/index.md 的内容
 */
export const readWarehouseFileSync = (absoluteFilePath = '') => {
  // 添加类型检查，确保 absoluteFilePath 是字符串
  if (typeof absoluteFilePath !== 'string') {
    absoluteFilePath = '';
  }

  const activeSpecDir = getActiveSpecDir(process.cwd());
  const relative = activeSpecDir ? path.relative(activeSpecDir, absoluteFilePath) : absoluteFilePath;
  const matched = relative && !relative.startsWith('..') ? relative : absoluteFilePath;
  const filePath = matched && `.specify/warehouse/${matched}`;

  return filePath && readFileSync(filePath);
};

/**
 * 从仓库中同步读取 src 下的 TypeScript 文件
 *
 * @description 当目标写入路径位于 src 目录且扩展名为 .ts 时，
 * 优先读取同级项目根目录下的 .specify/warehouse/src 对应文件。
 *
 * @param {string} absoluteFilePath - src 下 TypeScript 文件的绝对路径
 *
 * @returns {string|undefined} 仓库中对应文件的内容
 */
export const readWarehouseNaturalFileSync = (absoluteFilePath = '') => {
  if (!absoluteFilePath?.endsWith?.('.ts')) {
    return;
  }

  const fileName = path.basename(absoluteFilePath);
  const filePath = fileName && `.specify/warehouse/src/${fileName}`;

  return filePath && readFileSync(filePath);
};

/**
 * 提取重要标记的内容
 *
 * @description 从文本中提取所有标记为 IMPORTANT 的行
 * 用于保留重要内容
 *
 * @param {string} source - 源文本
 *
 * @returns {string} 所有重要内容的合并字符串
 *
 * @example
 * const text = '<!-- IMPORTANT --> 重要内容\n普通内容\n<!-- IMPORTANT --> 另一个重要内容';
 * extractImportant(text);
 * // 返回 '<!-- IMPORTANT --> 重要内容\n<!-- IMPORTANT --> 另一个重要内容'
 */
export const extractImportant = (source = '') => {
  const reg = new RegExp(`[^\\n\\s]*<!--\\s*${IMPORTANT}[^\\n]+`, 'g');
  const matched = source.match(reg) || [];

  return matched.join('\n');
};

/**
 * 同步写入文件
 *
 * @description 将内容写入文件，支持多种处理模式
 * 对于 entity- 或 logic- 前缀的文件，会添加 temp- 前缀
 * 自动保留重要标记的内容
 * 对于 src 下的 TypeScript 文件，优先直接使用 .specify/warehouse/src 中的内容
 *
 * @param {string} name - 文件名称（用于生成 Markdown 链接）
 * @param {string} absoluteFilePath - 文件的绝对路径
 * @param {string} spliter - 内容分隔符，默认为 '\n\n'
 *
 * @returns {Function} 返回一个函数，接收多个内容组参数
 *
 * @example
 * const writer = writeToFileSync('项目设计', '/path/to/plans/index.md');
 * const link = writer('# 标题', '内容1', '内容2');
 * // 返回 '[项目设计](/path/to/plans/index.md)'
 */
export const writeToFileSync =
  (name = '', absoluteFilePath = '', spliter = '\n\n') =>
  (...groups) => {
    const isMD = absoluteFilePath.endsWith('.md');
    const fileName = path.basename(absoluteFilePath);

    // 检查文件名是否包含 entity- 或 logic- 或 view- 前缀
    const isEntityOrLogicFile = /^(entity-|logic-|view-)/.test(fileName);
    const read = readWarehouseFileSync(absoluteFilePath);

    let result;
    let targetPath = absoluteFilePath;
    const temp = isEntityOrLogicFile && read;

    if (temp) {
      // 如果命中 entity- 或 logic- 或 view- 前缀，添加 temp- 前缀
      const dir = path.dirname(absoluteFilePath);
      const newFileName = `temp-${fileName}`;
      targetPath = path.join(dir, newFileName);

      result = read.replaceAll(PENDING, '');
    } else {
      // 原逻辑处理
      const merge = mergeGroups(spliter);
      const merged = merge(...groups);

      const important = (isMD && extractImportant(merged)) || '';
      const readWithImportand = important ? merge(important, read) : read;

      result = read ? readWithImportand : merged;
    }

    const absoluteDir = path.dirname(targetPath);

    fs.mkdirSync(absoluteDir, { recursive: true });
    fs.writeFileSync(targetPath, result);

    return temp ? '' : `[${name}](${targetPath})`;
  };

/**
 * 提交内容到文件
 *
 * @description 将内容直接写入文件，不进行任何处理
 * 用于最终提交文件
 *
 * @param {string} name - 文件名称（用于生成 Markdown 链接）
 * @param {string} absoluteFilePath - 文件的绝对路径
 * @param {string} spliter - 内容分隔符，默认为 '\n\n'
 *
 * @returns {Function} 返回一个函数，接收多个内容组参数
 *
 * @example
 * const committer = commitToFileSync('最终文件', '/path/to/final.md');
 * const link = committer('# 标题', '内容');
 * // 返回 '[最终文件](/path/to/final.md)'
 */
export const commitToFileSync =
  (name = '', absoluteFilePath = '', spliter = '\n\n') =>
  (...groups) => {
    const natural = readWarehouseNaturalFileSync(absoluteFilePath);
    const merged = natural || groups.flat().join(spliter);
    const absoluteDir = path.dirname(absoluteFilePath);

    fs.mkdirSync(absoluteDir, { recursive: true });
    fs.writeFileSync(absoluteFilePath, merged);

    return `[${name}](${absoluteFilePath})`;
  };

/**
 * 同步写入 JSON 文件
 *
 * @description 将 JavaScript 对象转换为 JSON 并写入文件
 *
 * @param {string} name - 文件名称（用于生成 Markdown 链接）
 * @param {string} absoluteFilePath - JSON 文件的绝对路径
 *
 * @returns {Function} 返回一个函数，接收 JavaScript 对象参数
 *
 * @example
 * const writer = writeToJSONSync('配置文件', '/path/to/config.json');
 * const link = writer({ key: 'value', count: 42 });
 * // 返回 '[配置文件](/path/to/config.json)'
 */
export const writeToJSONSync =
  (name = '', absoluteFilePath = '') =>
  (object) => {
    const json = JSON.stringify(object);

    return writeToFileSync(name, absoluteFilePath)(json);
  };

/**
 * 写入日志文件
 *
 * @description 将日志信息追加到日志文件
 * 自动添加时间戳
 *
 * @type {Function}
 *
 * @example
 * writeToLog('操作名称', '详细信息1', '详细信息2');
 * // 在 .data/_spec.log 中添加：[2024-01-01 12:00:00] 操作名称: 详细信息1 详细信息2
 */
export const writeToLog = (() => {
  const rootDir = process.cwd();
  const absoluteFilePath = `${rootDir}/.data/_spec.log`;
  const MAX_LOG_FILE_SIZE = 5 * 1024 * 1024;
  const LOG_FILE_REG = /^_spec_(\d+)\.log$/;

  const toLogDir = () => path.dirname(absoluteFilePath);
  const toNextLogFilePath = () => {
    const absoluteDir = toLogDir();
    const fileNames = fs.existsSync(absoluteDir) ? fs.readdirSync(absoluteDir) : [];
    const indexes = fileNames
      .map((fileName = '') => Number(fileName.match(LOG_FILE_REG)?.[1] || 0))
      .filter(Boolean);
    const nextIndex = (Math.max(0, ...indexes) || 0) + 1;

    return path.resolve(absoluteDir, `_spec_${nextIndex}.log`);
  };
  const resolveWritableLogFilePath = () => {
    const absoluteDir = toLogDir();
    const fileNames = fs.existsSync(absoluteDir) ? fs.readdirSync(absoluteDir) : [];
    const targetLogFilePaths = [
      absoluteFilePath,
      ...fileNames
        .filter((fileName = '') => LOG_FILE_REG.test(fileName))
        .sort((a = '', b = '') => Number(a.match(LOG_FILE_REG)?.[1] || 0) - Number(b.match(LOG_FILE_REG)?.[1] || 0))
        .map((fileName = '') => path.resolve(absoluteDir, fileName)),
    ];
    const found = targetLogFilePaths.find((filePath = '') => {
      if (!fs.existsSync(filePath)) {
        return true;
      }

      return fs.statSync(filePath).size < MAX_LOG_FILE_SIZE;
    });

    return found || toNextLogFilePath();
  };

  return (source, ...rest) => {
    const date = new Date();
    const dateString = date.toLocaleString('zh');
    const message = rest.join(' ');
    const more = `[${dateString}] ${source}: ${message}`;
    const targetAbsoluteFilePath = resolveWritableLogFilePath();

    const read = readFileSync(targetAbsoluteFilePath);
    const list = [more, read];
    const merged = list.filter(Boolean).join('\n');

    writeToFileSync('log', targetAbsoluteFilePath)(merged);
  };
})();
