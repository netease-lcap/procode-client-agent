import path from 'path';

import {
  getActiveSpecDir,
  readFileSync,
  findUnderSpecs,
  parseMenus,
  writeToFileSync,
  auto,
} from './shared/index.mjs';

import { checkerForMenus } from './wardrobe/for-check-everything/index.mjs';

export const hiddenKeywords = ['删除', '移除', '弹窗', '按钮', '跳转', '导航', '保存', '筛选', '填写'];

export const numberToLevels = [
  '一',
  '二',
  '三',
  '四',
  '五',
  '六',
  '七',
  '八',
  '九',
  '十',
  '十一',
  '十二',
  '十三',
  '十四',
  '十五',
  '十六',
  '十七',
  '十八',
  '十九',
  '二十',
];

export const findMenus = (item) => Boolean(item) && typeof item === 'string' && item.endsWith('specs/menus.md');

export const prependMenusReferences = (messages = [], rootDir = '') => {
  const activeSpecDir = getActiveSpecDir(rootDir);
  const menusAbsoluteFilePath = path.resolve(activeSpecDir, 'specs/menus.md');
  const menusTemplateAbsoluteFilePath = path.resolve(rootDir || process.cwd(), '.specify/templates/specs/menus-template.md');
  const references = [
    `<!-- 功能模块目录地址：${menusAbsoluteFilePath} -->`,
    `<!-- 功能模块目录模板地址：${menusTemplateAbsoluteFilePath} -->`,
    '',
  ];

  return references.concat(messages);
};

export const isHidden = (source = '') => {
  if (typeof source !== 'string') {
    return false;
  }

  return hiddenKeywords.some((item = '') => source.includes(item));
};

/**
 * 将菜单层级格式化为统一的目录文本。
 */
export const formatMenuPath = (levels = []) =>
  (Array.isArray(levels) ? levels : [])
    .filter(Boolean)
    .join(' > ');

/**
 * 统一构造检测错误。
 *
 * 每条错误都包含：
 * 1. message：错误信息
 * 2. menuPath：对应的功能模块目录，允许为空
 */
export const createMenuCheckError = (message = '', levels = []) => ({
  message,
  menuPath: formatMenuPath(levels),
});

/**
 * 将结构化错误渲染成最终文案，统一输出格式。
 */
export const renderMenuCheckErrors = (errors = []) =>
  (Array.isArray(errors) ? errors : []).flatMap((item = {}) => [
    `- ${item?.message || ''}`,
  ]);

/**
 * 检测功能一：功能模块目录中的所有名称都必须是纯中文。
 *
 * 这里按“具体菜单项”逐条报错，方便直接定位到对应目录。
 */
export const detectChineseMenuErrors = (menus = []) => {
  const errors = [];
  const isChineseOnly = (text = '') => Boolean(text) && /^[\u4e00-\u9fa5]+$/g.test(text);

  (Array.isArray(menus) ? menus : []).forEach((item = {}) => {
    const levels = item?.compressed || [];

    levels.forEach((name = '') => {
      if (name && !isChineseOnly(name)) {
        errors.push(createMenuCheckError(`功能名称 \`${name}\` 必须使用全中文`, levels));
      }
    });
  });

  return errors;
};

/**
 * 根据隐藏关键字判断哪些父级功能点必须隐藏所有子项。
 */
export const detectHiddenMenuErrors = (menus = []) => {
  const hiddenStore = (Array.isArray(menus) ? menus : [])
    .filter((item = {}) => item?.category === '页面')
    .reduce((result = {}, item = {}) => {
      const last = item?.last || '';
      const compressed = item?.compressed || [];
      const parentLevels = compressed.slice(0, -1);
      const key = parentLevels.join('-');

      if (!key) {
        return result;
      }

      result[key] = result[key] || {
        levels: parentLevels,
        children: [],
      };

      if (isHidden(last)) {
        result[key].children.push(last);
      }

      return result;
    }, {});

  return Object.values(hiddenStore)
    .filter((item = {}) => item?.children?.length >= 1)
    .map((item = {}) => {
      return item.children.map((child) => {
        return createMenuCheckError(`以下子项必须隐藏：${child}`, item?.levels?.concat?.(child));
      });
    })
    .flat();
};

/**
 * 生成功能：按现有业务逻辑重新拼出 menus.md 与 hidden.md。
 */
export const generateMenusFiles = (menusBundle = {}, parsed = {}, hiddenContent = '', activeSpecDir = '') => {
  const { levels = 0, maxLength = 0, menus = [], extraHead = [] } = parsed;
  const tableSource = menus.map((item = {}) => item.fulfilledRaw);
  const body = tableSource || [];
  const fulfilledLength = body[0]?.length || 0;
  const headLength = fulfilledLength - maxLength + levels;
  const neckLength = fulfilledLength;
  const hiddenAbsoluteFilePath = path.resolve(activeSpecDir, 'pieces', 'hidden.md');

  const head = Array.from({ length: headLength })
    .fill('')
    .map((item, index) => `${numberToLevels[index]}级功能`)
    .concat(...extraHead);
  const neck = Array.from({ length: neckLength }).fill('').map(() => '-------');
  const joined = [head, neck, ...body]
    .map((item = []) => `| ${item.join(' | ')} |`)
    .join('\n');

  writeToFileSync('menus.md', menusBundle.absoluteFilePath)('# 功能模块目录', joined);

  if (hiddenContent) {
    writeToFileSync('hidden.md', hiddenAbsoluteFilePath)('# 隐藏功能', hiddenContent);
  }

  return '验收成功';
};

/**
 * 统一读取当前校验和生成阶段需要的上下文。
 */
export const readMenusContext = (rootDir = '') => {
  const activeSpecDir = getActiveSpecDir(rootDir);
  const menusBundle = findUnderSpecs(rootDir)(findMenus);

  if (!menusBundle?.absoluteFilePath) {
    return {
      activeSpecDir,
      menusBundle,
    };
  }

  const source = readFileSync(menusBundle.absoluteFilePath) || '';
  const hiddenMatched = source.match(/\n\-[^\n]+/g) || [];
  const parsed = parseMenus(menusBundle.absoluteFilePath) || {};
  return {
    activeSpecDir,
    menusBundle,
    source,
    hiddenContent: hiddenMatched.join('\n'),
    parsed,
  };
};

/**
 * 当前文件的主流程：
 * 1. 读取上下文
 * 2. 按顺序执行三类检测
 * 3. 没有错误时再执行生成
 */
export const toRaw = (rootDir = '') => {
  rootDir = rootDir || process.cwd();

  const { activeSpecDir, menusBundle, parsed = {}, hiddenContent = '' } = readMenusContext(rootDir);
  const { menus = [] } = parsed;

  if (!menusBundle?.absoluteFilePath) {
    return prependMenusReferences([
      '<!-- **特别注意/关键规则**：缺少以下文档是非常严重的问题，必须重新执行阶段三生成功能模块目录。 -->',
      '',
      `缺少文档：[功能模块目录](${activeSpecDir}/specs/menus.md)`,
    ], rootDir).join('\n');
  }

  if (!menus.length) {
    return prependMenusReferences([
      '<!-- **特别注意/关键规则**：缺少以下文档是非常严重的问题，必须重新执行阶段三生成功能模块目录。 -->',
      '',
      '缺少关键内容：`功能目录模块` 对应的表格内容',
    ], rootDir).join('\n');
  }

  const chineseErrors = detectChineseMenuErrors(menus);

  if (chineseErrors.length) {
    return prependMenusReferences([
      '# 功能模块目录中只允许使用中文',
      '',
      '<!-- 以下功能模块名称必须使用全中文，请直接进行生成替换对应名称，禁止重新生成整个功能模块目录 -->',
      '',
      ...renderMenuCheckErrors(chineseErrors),
    ], rootDir).join('\n');
  }

  const hiddenErrors = detectHiddenMenuErrors(menus);

  if (hiddenErrors.length) {
    return prependMenusReferences([
      '# 以下功能点必须要隐藏所有子项',
      '',
      '<!-- **特别注意/关键规则**：你有充足的时间与资源，必须严格按照任务要求进行验收改正。禁止出于任何理由，导致没有严格遵守任务要求验收文件内容。 -->',
      '',
      ...renderMenuCheckErrors(hiddenErrors),
    ], rootDir).join('\n');
  }

  // 共用 check-everything 的菜单规则，包括所属迭代 ends.json 的 serviceTitle 一级功能校验。
  // 必须在生成文件前检查，归属不匹配时不改写 menus.md。
  const fallbackErrors = checkerForMenus.callback(rootDir)(menusBundle) || [];

  if (fallbackErrors.length) {
    return prependMenusReferences([
      '',
      fallbackErrors,
    ], rootDir).join('\n');
  }

  return generateMenusFiles(menusBundle, parsed, hiddenContent, activeSpecDir);
};

auto(import.meta)(toRaw);

export default toRaw;
