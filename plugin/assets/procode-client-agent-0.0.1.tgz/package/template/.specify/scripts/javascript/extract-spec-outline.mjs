import fs from 'fs';
import path from 'path';

import {
  PENDING,
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  readRawSpecContentSync,
  parse,
  parseToList,
  writeToFileSync,
  formatWritedFiles,
  parseMenusToTable,
  auto,
} from './shared/index.mjs';

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const options = { rootDir };
  const activeSpecDir = getActiveSpecDir(rootDir);

  const content = readRawSpecContentSync(rootDir);
  const matched = content.match(/\#+\s+[^\n]+/g) || [];

  const relativeFilePath = 'pieces/spec-outline.md';
  const absoulteFilePath = path.resolve(activeSpecDir, relativeFilePath);

  return writeToFileSync('原始需求-大纲', absoulteFilePath)(matched);
};

auto(import.meta)(toRaw);
export default toRaw;
