globalThis.__SPECKIT_BAKED_MAPPING_REFS__ = [{"file":"datasources.json","list":"$.dataSources","host":"$.config.host","port":"$.config.port"},{"file":"middlewares.json","extractor":"middleware-endpoints"}];
/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/cli.mts
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/commands.ts
import { createLogger } from "./shared/logger.mjs";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/deploy-io.ts
import fs from "node:fs";
import path2 from "node:path";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/validation.ts
import path from "node:path";
var SERVICE_NAME_PATTERN = /^[A-Za-z0-9](?:[A-Za-z0-9._-]{0,61}[A-Za-z0-9])?$/;
var TECH_ID_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
var SIMPLE_IDENTIFIER_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_-]*$/;
var PORT_NAME_PATTERN = /^[a-z][a-z0-9-]{0,62}$/;
var ENDPOINT_TYPES = /* @__PURE__ */ new Set(["pc", "h5", "api"]);
var BUSINESS_TYPES = /* @__PURE__ */ new Set(["application", "prototype"]);
var PROTOCOLS = /* @__PURE__ */ new Set(["http", "grpc", "tcp"]);
var SERVICE_TYPES = /* @__PURE__ */ new Set(["frontend", "backend", "bff"]);
var ENDPOINT_EXPOSURES = /* @__PURE__ */ new Set(["public", "internal"]);
var ROOT = path.resolve(path.sep, "__deploy_project__");
var BUILT_IN_PRESET_PORTS = [6002, 6003, 6005];
function isBuiltInPresetPort(port) {
  return BUILT_IN_PRESET_PORTS.some((value) => value === port);
}
function isEligibleBuiltInPresetPort(service, port) {
  const businessType = service.businessType ?? "application";
  const fixedPort = businessType === "prototype" ? service.serviceType === "frontend" ? 6005 : void 0 : service.serviceType === "frontend" ? 6002 : service.serviceType === "backend" ? 6003 : void 0;
  return fixedPort !== void 0 && port.protocol === "http" && port.port === fixedPort && service.runtime?.ports?.filter((entry) => entry.protocol === "http").length === 1;
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function nonEmptyString(value) {
  return typeof value === "string" && value.trim() !== "";
}
function add(issues, field, message) {
  issues.push({ path: field, message });
}
function object(value, target, fields, issues) {
  if (!isRecord(value)) {
    add(issues, target, target + " \u5FC5\u987B\u662F\u5BF9\u8C61");
    return void 0;
  }
  for (const key of Object.keys(value)) {
    if (!fields.includes(key)) {
      const field = target ? target + "." + key : key;
      add(issues, field, "\u672A\u77E5\u5B57\u6BB5\uFF1A" + field);
    }
  }
  return value;
}
function checkPath(value, target, issues, allowedRoot = ROOT) {
  if (!nonEmptyString(value) || value.includes("\0") || value.includes("\\") || /^[a-z]:/i.test(value) || path.isAbsolute(value)) {
    add(issues, target, target + " \u5FC5\u987B\u662F\u9879\u76EE\u6839\u76F8\u5BF9\u8DEF\u5F84");
    return;
  }
  const relative = path.relative(allowedRoot, path.resolve(ROOT, value));
  if (relative === ".." || relative.startsWith("../") || path.isAbsolute(relative)) {
    add(issues, target, target + " \u4E0D\u80FD\u8D8A\u51FA\u58F0\u660E\u76EE\u5F55");
  }
}
function checkContainerPath(value, target, issues) {
  if (!nonEmptyString(value) || !value.startsWith("/") || value === "/" || value.includes("\\") || [...value].some((character) => character.charCodeAt(0) < 32) || value.split("/").slice(1).some((segment) => segment === "" || segment === "." || segment === "..")) {
    add(issues, target, target + " \u5FC5\u987B\u662F\u7EDD\u5BF9 POSIX \u6587\u4EF6\u8DEF\u5F84");
  }
}
function normalizeBasePath(value) {
  const normalized = value.startsWith("/") ? value : "/" + value;
  return normalized === "/" ? "/" : normalized.replace(/\/+$/, "");
}
function checkBasePath(value, target, issues) {
  if (!nonEmptyString(value)) {
    add(issues, target, "basePath \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
    return "";
  }
  const normalized = normalizeBasePath(value);
  if (/[?#\\\s]/.test(value) || [...value].some((character) => character.charCodeAt(0) < 32) || value.split("/").some((s) => s === "." || s === "..") || !/^\/(?:[^/?#\s]+(?:\/[^/?#\s]+)*)?$/.test(normalized)) {
    add(issues, target, "basePath \u5FC5\u987B\u662F\u4E0D\u542B\u53C2\u6570\u3001\u7A7A\u6BB5\u6216\u7A7F\u8D8A\u6BB5\u7684 URL Path");
  }
  return normalized;
}
function checkTechStack(value, target, issues) {
  const stack = object(value, target, [
    "language",
    "languageVersion",
    "framework",
    "frameworkVersion",
    "buildTool",
    "packageManager",
    "packaging"
  ], issues);
  if (!stack) return;
  for (const key of ["language", "framework", "buildTool"]) {
    if (typeof stack[key] !== "string" || !TECH_ID_PATTERN.test(stack[key]))
      add(issues, target + "." + key, key + " \u5FC5\u987B\u662F\u5C0F\u5199\u6280\u672F\u6807\u8BC6");
  }
  for (const key of ["languageVersion", "frameworkVersion", "packageManager", "packaging"]) {
    if (stack[key] !== void 0 && !nonEmptyString(stack[key]))
      add(issues, target + "." + key, key + " \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
  }
}
function checkRuntime(value, target, issues) {
  const runtime = object(value, target, ["startScript", "javaOpts", "configFiles", "ports", "http", "healthCheck", "container"], issues);
  if (!runtime) return { ports: [] };
  if (runtime.startScript !== void 0) checkPath(runtime.startScript, target + ".startScript", issues);
  if (runtime.javaOpts !== void 0) {
    if (!Array.isArray(runtime.javaOpts)) add(issues, target + ".javaOpts", "javaOpts \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6570\u7EC4");
    else
      runtime.javaOpts.forEach((value2, i) => {
        if (!nonEmptyString(value2)) add(issues, target + ".javaOpts[" + i + "]", "javaOpts \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
      });
  }
  if (runtime.configFiles !== void 0) {
    if (!Array.isArray(runtime.configFiles)) add(issues, target + ".configFiles", "configFiles \u5FC5\u987B\u662F\u6570\u7EC4");
    else {
      const configNames = /* @__PURE__ */ new Set();
      runtime.configFiles.forEach((value2, i) => {
        const configField = target + ".configFiles[" + i + "]";
        const config = object(value2, configField, ["name", "templatePath", "path", "containerPath"], issues);
        if (!config) return;
        if (!nonEmptyString(config.name)) add(issues, configField + ".name", "\u914D\u7F6E\u6587\u4EF6 name \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
        else if (configNames.has(config.name)) add(issues, configField + ".name", "\u914D\u7F6E\u6587\u4EF6 name \u91CD\u590D\uFF1A" + config.name);
        else configNames.add(config.name);
        checkPath(config.templatePath, configField + ".templatePath", issues);
        checkPath(config.path, configField + ".path", issues);
        checkContainerPath(config.containerPath, configField + ".containerPath", issues);
      });
    }
  }
  const ports = [];
  const names = /* @__PURE__ */ new Set();
  if (runtime.ports !== void 0) {
    if (!Array.isArray(runtime.ports)) add(issues, target + ".ports", "ports \u5FC5\u987B\u662F\u6570\u7EC4");
    else
      runtime.ports.forEach((input, i) => {
        const field = target + ".ports[" + i + "]";
        const port = object(input, field, ["name", "protocol", "port", "connectPort", "inboundKeyMode"], issues);
        if (!port) return;
        if (!nonEmptyString(port.name) || !PORT_NAME_PATTERN.test(port.name))
          add(issues, field + ".name", "\u7AEF\u53E3\u540D\u5FC5\u987B\u4EE5\u5C0F\u5199\u5B57\u6BCD\u5F00\u5934\uFF0C\u4F7F\u7528\u5C0F\u5199\u5B57\u6BCD\u3001\u6570\u5B57\u548C\u77ED\u6A2A\u7EBF");
        else {
          if (names.has(port.name)) add(issues, field + ".name", "\u7AEF\u53E3\u540D\u91CD\u590D\uFF1A" + port.name);
          names.add(port.name);
        }
        if (typeof port.protocol !== "string" || !PROTOCOLS.has(port.protocol))
          add(issues, field + ".protocol", "protocol \u4EC5\u652F\u6301 http\u3001grpc\u3001tcp");
        if (port.port !== void 0 && (!Number.isInteger(port.port) || Number(port.port) < 1 || Number(port.port) > 65535))
          add(issues, field + ".port", "port \u5FC5\u987B\u662F 1-65535 \u7684\u6574\u6570");
        if (port.connectPort !== void 0 && (!Number.isInteger(port.connectPort) || Number(port.connectPort) < 1 || Number(port.connectPort) > 65535))
          add(issues, field + ".connectPort", "connectPort \u5FC5\u987B\u662F 1-65535 \u7684\u6574\u6570");
        if (port.connectPort !== void 0 && port.port === void 0)
          add(issues, field + ".connectPort", "connectPort \u53EA\u80FD\u56DE\u586B\u5230\u5DF2\u6709\u5E94\u7528\u76D1\u542C\u7AEF\u53E3");
        if (port.inboundKeyMode !== void 0 && port.inboundKeyMode !== "preset-port")
          add(issues, field + ".inboundKeyMode", "inboundKeyMode \u4EC5\u652F\u6301 preset-port");
        ports.push({ ...port });
      });
  }
  let contextPath;
  if (runtime.http !== void 0) {
    const http = object(runtime.http, target + ".http", ["contextPath"], issues);
    if (http) contextPath = checkBasePath(http.contextPath, target + ".http.contextPath", issues);
  }
  if (runtime.healthCheck !== void 0) {
    const check = object(runtime.healthCheck, target + ".healthCheck", ["script"], issues);
    if (check) checkPath(check.script, target + ".healthCheck.script", issues);
  }
  if (runtime.container !== void 0) {
    const container = object(runtime.container, target + ".container", ["name", "baseDir", "port"], issues);
    if (container) {
      if (!nonEmptyString(container.name)) add(issues, target + ".container.name", "\u5BB9\u5668 name \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
      checkPath(container.baseDir, target + ".container.baseDir", issues);
      if (!Number.isInteger(container.port) || Number(container.port) < 1 || Number(container.port) > 65535)
        add(issues, target + ".container.port", "\u5BB9\u5668 port \u5FC5\u987B\u662F 1-65535 \u7684\u6574\u6570");
    }
  }
  return { ports, ...contextPath === void 0 ? {} : { contextPath } };
}
function validateServiceAt(input, target, requireRuntime) {
  const issues = [];
  const service = object(
    input,
    target,
    ["serviceName", "projectName", "deployName", "e2eName", "serviceTitle", "serviceType", "techStack", "businessType", "description", "apiBasePath", "sourceDir", "build", "imageBuild", "runtime", "endpoints", "dependencies"],
    issues
  );
  if (!service) return { ok: false, issues };
  const field = (name) => target ? target + "." + name : name;
  if (!nonEmptyString(service.serviceName) || !SERVICE_NAME_PATTERN.test(service.serviceName))
    add(issues, field("serviceName"), "serviceName \u53EA\u80FD\u5305\u542B\u82F1\u6587\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\u3001\u70B9\u548C\u8FDE\u5B57\u7B26\uFF0C\u9996\u5C3E\u987B\u4E3A\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u6700\u957F 63 \u4F4D");
  for (const name of ["projectName", "deployName", "e2eName"]) {
    const value2 = service[name];
    if (value2 !== void 0 && (typeof value2 !== "string" || !SIMPLE_IDENTIFIER_PATTERN.test(value2)))
      add(issues, field(name), name + " \u5FC5\u987B\u662F\u4EE5\u5B57\u6BCD\u6216\u6570\u5B57\u5F00\u5934\u3001\u4EC5\u542B\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\u548C\u8FDE\u5B57\u7B26\u7684\u975E\u7A7A\u6807\u8BC6\u7B26");
  }
  if (!nonEmptyString(service.serviceTitle))
    add(issues, field("serviceTitle"), "serviceTitle \u5FC5\u987B\u7531\u4E0A\u6E38\u6280\u672F\u8BBE\u8BA1/\u67B6\u6784\u5206\u6790\u63D0\u4F9B\u4E14\u4E3A\u975E\u7A7A\u5B57\u7B26\u4E32");
  if (typeof service.serviceType !== "string" || !SERVICE_TYPES.has(service.serviceType))
    add(issues, field("serviceType"), "serviceType \u4EC5\u652F\u6301 frontend\u3001backend\u3001bff\uFF0C\u4E14\u5FC5\u987B\u663E\u5F0F\u63D0\u4F9B");
  if (service.techStack !== void 0) checkTechStack(service.techStack, field("techStack"), issues);
  const businessType = service.businessType === void 0 ? "application" : service.businessType;
  if (typeof businessType !== "string" || !BUSINESS_TYPES.has(businessType))
    add(issues, field("businessType"), "businessType \u4EC5\u652F\u6301 application\u3001prototype");
  const normalizedBusinessType = typeof businessType === "string" && BUSINESS_TYPES.has(businessType) ? businessType : "application";
  if (service.description !== void 0 && !nonEmptyString(service.description))
    add(issues, field("description"), "description \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
  const apiPath = service.apiBasePath === void 0 ? void 0 : checkBasePath(service.apiBasePath, field("apiBasePath"), issues);
  if (service.sourceDir !== void 0) checkPath(service.sourceDir, field("sourceDir"), issues);
  const runtimeInfo = service.runtime === void 0 ? { ports: [] } : checkRuntime(service.runtime, field("runtime"), issues);
  const ports = runtimeInfo.ports;
  const presetService = {
    serviceType: service.serviceType,
    businessType: normalizedBusinessType,
    runtime: { ports }
  };
  ports.forEach((port, index) => {
    if (port.inboundKeyMode === "preset-port" && !isEligibleBuiltInPresetPort(presetService, port)) {
      add(
        issues,
        field(`runtime.ports[${index}].inboundKeyMode`),
        "preset-port \u4EC5\u9650\u552F\u4E00 HTTP \u7AEF\u53E3\uFF1A\u6B63\u5F0F frontend/6002\u3001backend/6003 \u6216\u539F\u578B frontend/6005"
      );
    }
  });
  if (service.build !== void 0) {
    const build = object(service.build, field("build"), ["script", "outputs"], issues);
    if (build) {
      if (build.script !== void 0) checkPath(build.script, field("build.script"), issues);
      if (build.outputs !== void 0) {
        if (!Array.isArray(build.outputs)) add(issues, field("build.outputs"), "outputs \u5FC5\u987B\u662F\u6570\u7EC4");
        else
          build.outputs.forEach((value2, i) => {
            const outputField = field("build.outputs[" + i + "]");
            const output = object(value2, outputField, ["path", "static", "entryFile"], issues);
            if (!output) return;
            checkPath(output.path, outputField + ".path", issues);
            if (output.static !== void 0 && typeof output.static !== "boolean")
              add(issues, outputField + ".static", "static \u5FC5\u987B\u662F\u5E03\u5C14\u503C");
            if (output.entryFile !== void 0) {
              if (output.static !== true) add(issues, outputField + ".entryFile", "entryFile \u5FC5\u987B\u5C5E\u4E8E\u660E\u786E\u7684\u9759\u6001\u4EA7\u7269");
              checkPath(
                output.entryFile,
                outputField + ".entryFile",
                issues,
                path.resolve(ROOT, nonEmptyString(output.path) ? output.path : ".")
              );
            }
          });
      }
    }
  }
  if (service.imageBuild !== void 0) {
    const image = object(service.imageBuild, field("imageBuild"), ["dockerfile", "contextDir"], issues);
    if (image) {
      checkPath(image.dockerfile, field("imageBuild.dockerfile"), issues);
      if (image.contextDir !== void 0) checkPath(image.contextDir, field("imageBuild.contextDir"), issues);
    }
  }
  const endpoints = [];
  const httpPaths = /* @__PURE__ */ new Set();
  if (service.endpoints !== void 0) {
    if (!Array.isArray(service.endpoints)) add(issues, field("endpoints"), "endpoints \u5FC5\u987B\u662F\u6570\u7EC4");
    else
      service.endpoints.forEach((value2, i) => {
        const endpointField = field("endpoints[" + i + "]");
        const endpoint = object(
          value2,
          endpointField,
          ["type", "businessType", "title", "portName", "basePath", "exposure"],
          issues
        );
        if (!endpoint) return;
        if (typeof endpoint.type !== "string" || !ENDPOINT_TYPES.has(endpoint.type))
          add(issues, endpointField + ".type", "type \u4EC5\u652F\u6301 pc\u3001h5\u3001api");
        const endpointBusinessType = endpoint.businessType === void 0 ? endpoint.type === "api" ? "application" : normalizedBusinessType : endpoint.businessType;
        if (typeof endpointBusinessType !== "string" || !BUSINESS_TYPES.has(endpointBusinessType))
          add(issues, endpointField + ".businessType", "businessType \u4EC5\u652F\u6301 application\u3001prototype");
        if (endpoint.type === "api" && endpointBusinessType !== "application")
          add(issues, endpointField + ".businessType", "API \u5165\u53E3\u7684 businessType \u5FC5\u987B\u662F application");
        if (typeof endpoint.exposure !== "string" || !ENDPOINT_EXPOSURES.has(endpoint.exposure))
          add(issues, endpointField + ".exposure", "exposure \u4EC5\u652F\u6301 public\u3001internal\uFF0C\u4E14\u5FC5\u987B\u663E\u5F0F\u63D0\u4F9B");
        if (!nonEmptyString(endpoint.title)) add(issues, endpointField + ".title", "title \u5FC5\u987B\u662F\u975E\u7A7A\u5B57\u7B26\u4E32");
        const port = ports.find((p) => p.name === endpoint.portName);
        if (!nonEmptyString(endpoint.portName) || !port)
          add(issues, endpointField + ".portName", "\u5165\u53E3\u5FC5\u987B\u5F15\u7528\u672C\u670D\u52A1\u7684\u547D\u540D\u7AEF\u53E3");
        const basePath = checkBasePath(endpoint.basePath, endpointField + ".basePath", issues);
        if (port?.protocol === "http") {
          if (httpPaths.has(basePath))
            add(issues, endpointField + ".basePath", "\u540C\u4E00\u670D\u52A1 HTTP basePath \u91CD\u590D\uFF1A" + basePath);
          httpPaths.add(basePath);
        }
        if (endpoint.type === "api") {
          if (apiPath === void 0)
            add(issues, field("apiBasePath"), "API \u5165\u53E3\u5FC5\u987B\u58F0\u660E\u5408\u6CD5\u7684 apiBasePath");
        }
        if (requireRuntime && port?.port === void 0)
          add(issues, endpointField + ".portName", "\u5165\u53E3\u5F15\u7528\u7684\u547D\u540D\u7AEF\u53E3\u5C1A\u672A\u767B\u8BB0");
        endpoints.push({ ...endpoint, businessType: endpointBusinessType, basePath });
      });
  }
  if (service.dependencies !== void 0) {
    if (!Array.isArray(service.dependencies)) add(issues, field("dependencies"), "dependencies \u5FC5\u987B\u662F\u6570\u7EC4");
    else {
      service.dependencies.forEach((value2, i) => {
        const dependencyField = field("dependencies[" + i + "]");
        const dependency = object(value2, dependencyField, ["serviceName", "portName", "requiredForStartup"], issues);
        if (!dependency) return;
        if (!nonEmptyString(dependency.serviceName) || !SERVICE_NAME_PATTERN.test(dependency.serviceName))
          add(issues, dependencyField + ".serviceName", "\u4F9D\u8D56 serviceName \u53EA\u80FD\u5305\u542B\u82F1\u6587\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\u3001\u70B9\u548C\u8FDE\u5B57\u7B26\uFF0C\u9996\u5C3E\u987B\u4E3A\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u6700\u957F 63 \u4F4D");
        if (!nonEmptyString(dependency.portName) || !PORT_NAME_PATTERN.test(dependency.portName))
          add(issues, dependencyField + ".portName", "\u4F9D\u8D56 portName \u5FC5\u987B\u662F\u547D\u540D\u7AEF\u53E3");
        if (typeof dependency.requiredForStartup !== "boolean")
          add(issues, dependencyField + ".requiredForStartup", "requiredForStartup \u5FC5\u987B\u662F\u5E03\u5C14\u503C");
      });
    }
  }
  if (issues.length) return { ok: false, issues };
  const value = structuredClone(service);
  value.businessType = normalizedBusinessType;
  if (service.runtime !== void 0 && runtimeInfo.contextPath !== void 0) {
    value.runtime = value.runtime ?? {};
    value.runtime.http = { contextPath: runtimeInfo.contextPath };
  }
  if (apiPath !== void 0)
    value.apiBasePath = apiPath === "/" || !String(service.apiBasePath).endsWith("/") ? apiPath : apiPath + "/";
  if (service.endpoints !== void 0) value.endpoints = endpoints;
  return { ok: true, value, issues: [] };
}
function validateDeployService(input, options = {}) {
  return validateServiceAt(input, "", options.requireRuntime === true);
}
function validateDeployManifest(input, options = {}) {
  const issues = [];
  const manifest = object(input, "", ["services"], issues);
  if (!manifest) return { ok: false, issues };
  if (!Array.isArray(manifest.services)) {
    add(issues, "services", "services \u5FC5\u987B\u662F\u6570\u7EC4");
    return { ok: false, issues };
  }
  const services = [];
  const names = /* @__PURE__ */ new Set();
  const assigned = /* @__PURE__ */ new Set();
  const assignedConnect = /* @__PURE__ */ new Set();
  manifest.services.forEach((input2, i) => {
    const target = "services[" + i + "]";
    const report = validateServiceAt(input2, target, options.requireRuntime === true);
    issues.push(...report.issues);
    if (!report.value) return;
    const service = report.value;
    const normalizedName = service.serviceName.toLowerCase();
    if (names.has(normalizedName))
      add(issues, target + ".serviceName", "serviceName \u91CD\u590D\uFF08\u5FFD\u7565\u5927\u5C0F\u5199\uFF09\uFF1A" + service.serviceName);
    names.add(normalizedName);
    service.runtime?.ports?.forEach((port, j) => {
      if (port.port === void 0) return;
      if (assigned.has(port.port)) add(issues, target + ".runtime.ports[" + j + "].port", "port \u91CD\u590D\uFF1A" + port.port);
      assigned.add(port.port);
      if (port.connectPort !== void 0) {
        if (assignedConnect.has(port.connectPort))
          add(issues, target + ".runtime.ports[" + j + "].connectPort", "connectPort \u91CD\u590D\uFF1A" + port.connectPort);
        assignedConnect.add(port.connectPort);
      }
    });
    services.push(service);
  });
  const serviceIndex = new Map(services.map((service) => [service.serviceName, service]));
  services.forEach((service, serviceIndexInManifest) => {
    service.dependencies?.forEach((dependency, dependencyIndex) => {
      const dependencyPath = "services[" + serviceIndexInManifest + "].dependencies[" + dependencyIndex + "]";
      const target = serviceIndex.get(dependency.serviceName);
      if (!target) {
        add(issues, dependencyPath + ".serviceName", "\u4F9D\u8D56\u76EE\u6807\u670D\u52A1\u4E0D\u5B58\u5728\uFF1A" + dependency.serviceName);
        return;
      }
      const targetPort = target.runtime?.ports?.find((port) => port.name === dependency.portName);
      if (!targetPort) add(issues, dependencyPath + ".portName", "\u4F9D\u8D56\u76EE\u6807\u547D\u540D\u7AEF\u53E3\u4E0D\u5B58\u5728\uFF1A" + dependency.portName);
    });
  });
  const dependencyGraph = /* @__PURE__ */ new Map();
  services.forEach((service, serviceIndexInManifest) => {
    const requiredEdges = service.dependencies?.flatMap(
      (dependency, dependencyIndex) => dependency.requiredForStartup ? [{ to: dependency.serviceName, path: "services[" + serviceIndexInManifest + "].dependencies[" + dependencyIndex + "].serviceName" }] : []
    ) ?? [];
    dependencyGraph.set(service.serviceName, requiredEdges);
  });
  const colors = /* @__PURE__ */ new Map();
  const visit = (serviceName) => {
    colors.set(serviceName, "gray");
    for (const edge of dependencyGraph.get(serviceName) ?? []) {
      const color = colors.get(edge.to) ?? "white";
      if (color === "gray") add(issues, edge.path, "requiredForStartup \u4F9D\u8D56\u5B58\u5728\u73AF");
      else if (color === "white") visit(edge.to);
    }
    colors.set(serviceName, "black");
  };
  services.forEach((service) => {
    if ((colors.get(service.serviceName) ?? "white") === "white") visit(service.serviceName);
  });
  return issues.length ? { ok: false, issues } : { ok: true, value: { services }, issues: [] };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/deploy-io.ts
var DEPLOY_MANIFEST_RELATIVE_PATH = path2.join(".manifest", "deploy.json");
var DeployManifestValidationError = class extends Error {
  exitCode = 3;
  constructor(message) {
    super(message);
    this.name = "DeployManifestValidationError";
  }
};
var DeployManifestFileError = class extends DeployManifestValidationError {
  constructor(message) {
    super(message);
    this.name = "DeployManifestFileError";
  }
};
var DeployManifestNotFoundError = class extends Error {
  exitCode = 4;
  constructor(message) {
    super(message);
    this.name = "DeployManifestNotFoundError";
  }
};
var DeployManifestWriteError = class extends Error {
  exitCode = 5;
  constructor(message) {
    super(message);
    this.name = "DeployManifestWriteError";
  }
};
function deployManifestFilePath(cwd) {
  return path2.join(cwd, DEPLOY_MANIFEST_RELATIVE_PATH);
}
function deployManifestExists(cwd) {
  return fs.existsSync(deployManifestFilePath(cwd));
}
function readDeployManifest(cwd) {
  const file = deployManifestFilePath(cwd);
  if (!fs.existsSync(file)) return { services: [] };
  let raw;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch (error) {
    throw new DeployManifestFileError(`deploy.json \u8BFB\u53D6\u5931\u8D25\uFF1A${errorMessage(error)}`);
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (error) {
    throw new DeployManifestFileError(`deploy.json \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errorMessage(error)}`);
  }
  const report = validateDeployManifest(parsed);
  if (!report.ok || !report.value) {
    throw new DeployManifestFileError(formatValidationIssues(report.issues));
  }
  return report.value;
}
function writeDeployManifest(cwd, manifest) {
  const report = validateDeployManifest(manifest);
  if (!report.ok || !report.value) {
    throw new DeployManifestValidationError(formatValidationIssues(report.issues));
  }
  const file = deployManifestFilePath(cwd);
  const next = `${JSON.stringify(report.value, null, 2)}
`;
  try {
    if (fs.existsSync(file) && fs.readFileSync(file, "utf8") === next) return { changed: false };
  } catch (error) {
    throw new DeployManifestWriteError(`deploy.json \u6BD4\u5BF9\u5931\u8D25\uFF1A${errorMessage(error)}`);
  }
  const temporary = `${file}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.mkdirSync(path2.dirname(file), { recursive: true });
    fs.writeFileSync(temporary, next);
    fs.renameSync(temporary, file);
    return { changed: true };
  } catch (error) {
    try {
      fs.unlinkSync(temporary);
    } catch {
    }
    throw new DeployManifestWriteError(`deploy.json \u539F\u5B50\u5199\u5165\u5931\u8D25\uFF1A${errorMessage(error)}`);
  }
}
function upsertDeployService(cwd, service) {
  const serviceReport = validateDeployService(service);
  if (!serviceReport.ok || !serviceReport.value) {
    throw new DeployManifestValidationError(formatValidationIssues(serviceReport.issues));
  }
  const current = readDeployManifest(cwd);
  const index = current.services.findIndex((item) => item.serviceName === serviceReport.value.serviceName);
  const services = [...current.services];
  if (index >= 0) services[index] = preserveAssignedPorts(current.services[index], serviceReport.value);
  else services.push(serviceReport.value);
  const manifest = { services };
  const report = validateDeployManifest(manifest);
  if (!report.ok || !report.value) {
    throw new DeployManifestValidationError(formatValidationIssues(report.issues));
  }
  const result = writeDeployManifest(cwd, report.value);
  return { ...result, manifest: report.value };
}
function preserveAssignedPorts(previous, next) {
  const result = structuredClone(next);
  for (const port of result.runtime?.ports ?? []) {
    const existing = previous.runtime?.ports?.find((item) => item.name === port.name);
    if (existing?.port === void 0) continue;
    if (port.port !== void 0 && port.port !== existing.port) {
      throw new DeployManifestValidationError(`\u7AEF\u53E3\u5DF2\u767B\u8BB0\uFF0C\u4E0D\u5141\u8BB8\u6539\u5199\uFF1A${next.serviceName}/${port.name}`);
    }
    port.port = existing.port;
    if (existing.connectPort !== void 0) port.connectPort = existing.connectPort;
  }
  return result;
}
function deleteDeployService(cwd, serviceName) {
  const current = readDeployManifest(cwd);
  if (!current.services.some((service) => service.serviceName === serviceName)) {
    throw new DeployManifestNotFoundError(`service \u4E0D\u5B58\u5728\uFF1A${serviceName}`);
  }
  const manifest = { services: current.services.filter((service) => service.serviceName !== serviceName) };
  const result = writeDeployManifest(cwd, manifest);
  return { ...result, manifest };
}
function formatValidationIssues(issues) {
  return issues.map((item) => `${item.path}: ${item.message}`).join("; ");
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/mutation-lock.ts
import fs2 from "node:fs/promises";
import path3 from "node:path";
import { randomUUID } from "node:crypto";
var WAIT_INTERVAL_MS = 25;
var DEFAULT_TIMEOUT_MS = 7e4;
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
var DeployLockError = class extends Error {
  exitCode = 1;
  code = "DEPLOY_LOCK_TIMEOUT";
};
function errorCode(error) {
  return error?.code;
}
async function readBootId() {
  if (process.platform !== "linux") return null;
  return fs2.readFile("/proc/sys/kernel/random/boot_id", "utf8").then((value) => value.trim() || null).catch(() => null);
}
async function readStartTicks(pid) {
  if (process.platform !== "linux") return null;
  try {
    const stat = await fs2.readFile(`/proc/${pid}/stat`, "utf8");
    const endOfComm = stat.lastIndexOf(")");
    if (endOfComm < 0) return null;
    return stat.slice(endOfComm + 1).trim().split(/\s+/)[19] || null;
  } catch {
    return null;
  }
}
function parseOwner(raw) {
  try {
    const value = JSON.parse(raw);
    if (!value || !UUID.test(value.token ?? "") || !Number.isSafeInteger(value.pid) || (value.pid ?? 0) <= 0 || !(value.bootId === null || typeof value.bootId === "string") || !(value.startTicks === null || typeof value.startTicks === "string")) return null;
    return value;
  } catch {
    return null;
  }
}
async function ownerIsGone(owner) {
  try {
    process.kill(owner.pid, 0);
  } catch (error) {
    return errorCode(error) === "ESRCH";
  }
  if (!owner.bootId || !owner.startTicks) return false;
  const bootId = await readBootId();
  if (!bootId) return false;
  if (bootId !== owner.bootId) return true;
  const startTicks = await readStartTicks(owner.pid);
  return startTicks !== null && startTicks !== owner.startTicks;
}
async function tryRecoverDeadOwner(lock) {
  const ownerPath = path3.join(lock, "owner");
  const observed = await fs2.readFile(ownerPath, "utf8").catch(() => null);
  const owner = observed === null ? null : parseOwner(observed);
  if (!owner || !await ownerIsGone(owner)) return;
  if (await fs2.readFile(ownerPath, "utf8").catch(() => null) !== observed) return;
  const quarantine = `${lock}.stale.${owner.token}`;
  try {
    await fs2.rename(lock, quarantine);
  } catch (error) {
    if (["ENOENT", "EEXIST", "ENOTEMPTY"].includes(errorCode(error) ?? "")) return;
    throw error;
  }
}
async function withDeployMutation(cwd, work, options = {}) {
  const lock = path3.join(cwd, ".deploy.lock");
  const token = randomUUID();
  const pending = `${lock}.pending.${token}`;
  const owner = {
    token,
    pid: process.pid,
    bootId: await readBootId(),
    startTicks: await readStartTicks(process.pid)
  };
  await fs2.mkdir(pending);
  try {
    await fs2.writeFile(path3.join(pending, "owner"), JSON.stringify(owner), { flag: "wx" });
    const deadline = Date.now() + (options.timeoutMs ?? DEFAULT_TIMEOUT_MS);
    for (; ; ) {
      try {
        await fs2.lstat(lock);
      } catch (error) {
        if (errorCode(error) !== "ENOENT") throw error;
        try {
          await fs2.rename(pending, lock);
          break;
        } catch (publishError) {
          if (!["EEXIST", "ENOTEMPTY"].includes(errorCode(publishError) ?? "")) throw publishError;
        }
      }
      await tryRecoverDeadOwner(lock);
      if (Date.now() >= deadline) {
        throw new DeployLockError("\u90E8\u7F72\u53D8\u66F4\u9501\u7B49\u5F85\u8D85\u65F6\uFF1B\u8BF7\u786E\u8BA4\u73B0\u6709\u4EFB\u52A1/\u9057\u7559\u9501\u5F52\u5C5E\uFF0C\u4E0D\u81EA\u52A8\u62A2\u5360\u672A\u77E5\u9501");
      }
      await new Promise((resolve) => setTimeout(resolve, WAIT_INTERVAL_MS));
    }
    try {
      return await work();
    } finally {
      const ownerPath = path3.join(lock, "owner");
      const current = await fs2.readFile(ownerPath, "utf8").catch(() => null);
      if (current && parseOwner(current)?.token === token) {
        await fs2.unlink(ownerPath);
        await fs2.rmdir(lock).catch((error) => {
          if (!["ENOENT", "ENOTEMPTY"].includes(errorCode(error) ?? "")) throw error;
        });
      }
    }
  } finally {
    await fs2.rm(pending, { recursive: true, force: true });
  }
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/runtime-policy.ts
var NACOS_DISCOVERY_PORT_OPTION = "-Dspring.cloud.nacos.discovery.port=";
function applyDeployServiceRuntimePolicy(input) {
  const service = structuredClone(input);
  if (service.techStack === void 0) return service;
  const applicable = service.serviceType === "backend" && service.techStack.language === "java" && service.techStack.framework === "spring-boot";
  const javaOpts = service.runtime?.javaOpts?.filter((value) => !value.startsWith(NACOS_DISCOVERY_PORT_OPTION)) ?? [];
  if (!applicable) {
    if (service.runtime?.javaOpts) service.runtime.javaOpts = javaOpts;
    return service;
  }
  const httpPorts = service.runtime?.ports?.filter((port) => port.protocol === "http") ?? [];
  if (httpPorts.length !== 1) {
    throw new Error(`service ${service.serviceName} \u751F\u6210 Nacos \u53C2\u6570\u9700\u8981\u6070\u597D\u4E00\u4E2A HTTP \u547D\u540D\u7AEF\u53E3\uFF0C\u5B9E\u9645\u4E3A ${httpPorts.length} \u4E2A`);
  }
  service.runtime ??= {};
  const inboundKey = httpPorts[0].inboundKeyMode === "preset-port" ? String(httpPorts[0].port) : service.serviceName;
  javaOpts.push(`${NACOS_DISCOVERY_PORT_OPTION}"$(sbx-inbound get-connect -k ${inboundKey})"`);
  service.runtime.javaOpts = javaOpts;
  return service;
}
function applyDeployRuntimePolicy(manifest) {
  return { services: manifest.services.map(applyDeployServiceRuntimePolicy) };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/service-facts.ts
function mergeDeployConfigFiles(existing, incoming, removeNames = []) {
  const removals = new Set(removeNames);
  const result = existing.filter((file) => !removals.has(file.name)).map((file) => ({ ...file }));
  const indexes = new Map(result.map((file, index) => [file.name, index]));
  for (const file of incoming) {
    const next = { ...file };
    const index = indexes.get(file.name);
    if (index === void 0) {
      indexes.set(file.name, result.length);
      result.push(next);
    } else {
      result[index] = next;
    }
  }
  return result;
}
function mergeDeployServiceFacts(existing, incoming) {
  assertDeployServiceFacts(incoming);
  const existingFiles = existing.runtime?.configFiles ?? [];
  const incomingFiles = incoming.runtime?.configFiles ?? [];
  const removeNames = incoming.runtime?.removeConfigFileNames ?? [];
  const result = structuredClone(existing);
  if (incoming.techStack !== void 0) result.techStack = structuredClone(incoming.techStack);
  if (incoming.runtime !== void 0) {
    result.runtime = {
      ...existing.runtime ? structuredClone(existing.runtime) : {},
      ...incoming.runtime.configFiles !== void 0 || removeNames.length ? { configFiles: mergeDeployConfigFiles(existingFiles, incomingFiles, removeNames) } : {}
    };
  }
  return result;
}
function assertDeployServiceFacts(value) {
  if (!isRecord2(value)) throw new DeployManifestValidationError("service facts \u5FC5\u987B\u662F\u5BF9\u8C61");
  const topKeys = Object.keys(value);
  if (!topKeys.length || topKeys.some((key) => key !== "runtime" && key !== "techStack")) {
    throw new DeployManifestValidationError("service facts \u53EA\u652F\u6301 techStack\u3001runtime.configFiles \u548C removeConfigFileNames");
  }
  if (value.techStack !== void 0) {
    const report = validateDeployService({
      serviceName: "facts-probe",
      serviceTitle: "facts probe",
      serviceType: "backend",
      techStack: value.techStack
    });
    if (!report.ok) throw new DeployManifestValidationError(report.issues.map((issue) => `${issue.path}: ${issue.message}`).join("; "));
  }
  const runtime = value.runtime;
  if (runtime === void 0) {
    if (value.techStack === void 0) throw new DeployManifestValidationError("service facts \u4E0D\u80FD\u4E3A\u7A7A");
    return;
  }
  if (!isRecord2(runtime)) throw new DeployManifestValidationError("facts.runtime \u5FC5\u987B\u662F\u5BF9\u8C61");
  const runtimeKeys = Object.keys(runtime);
  if (!runtimeKeys.length || runtimeKeys.some((key) => key !== "configFiles" && key !== "removeConfigFileNames")) {
    throw new DeployManifestValidationError("service facts \u53EA\u652F\u6301 runtime.configFiles \u548C removeConfigFileNames");
  }
  if (runtime.configFiles !== void 0 && !Array.isArray(runtime.configFiles)) {
    throw new DeployManifestValidationError("facts.runtime.configFiles \u5FC5\u987B\u662F\u6570\u7EC4");
  }
  if (runtime.removeConfigFileNames !== void 0) {
    if (!Array.isArray(runtime.removeConfigFileNames) || runtime.removeConfigFileNames.some((name) => typeof name !== "string" || !name.trim()) || new Set(runtime.removeConfigFileNames).size !== runtime.removeConfigFileNames.length) {
      throw new DeployManifestValidationError("facts.runtime.removeConfigFileNames \u5FC5\u987B\u662F\u975E\u7A7A\u4E14\u4E0D\u91CD\u590D\u7684\u5B57\u7B26\u4E32\u6570\u7EC4");
    }
    const runtimeFacts = runtime;
    const incomingNames = new Set((runtimeFacts?.configFiles ?? []).map((file) => file.name));
    if ([...incomingNames].some((name) => runtimeFacts?.removeConfigFileNames?.includes(name))) {
      throw new DeployManifestValidationError("\u540C\u4E00 facts \u4E0D\u80FD\u540C\u65F6\u66F4\u65B0\u548C\u5220\u9664\u540C\u540D configFile");
    }
  }
}
function isRecord2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
async function updateDeployServiceFacts(cwd, input) {
  assertDeployServiceFacts(input.facts);
  return withDeployMutation(cwd, async () => {
    const current = readDeployManifest(cwd);
    const index = current.services.findIndex((service) => service.serviceName === input.serviceName);
    if (index < 0) throw new DeployManifestNotFoundError(`service \u4E0D\u5B58\u5728\uFF1A${input.serviceName}`);
    const services = current.services.map((service, serviceIndex) => {
      if (serviceIndex !== index) return service;
      const next = structuredClone(service);
      const merged = mergeDeployServiceFacts(
        {
          techStack: next.techStack,
          runtime: next.runtime ? { configFiles: next.runtime.configFiles } : void 0
        },
        input.facts
      );
      if (merged.techStack !== void 0) next.techStack = merged.techStack;
      if (merged.runtime?.configFiles !== void 0) {
        next.runtime ??= {};
        next.runtime.configFiles = merged.runtime.configFiles;
      }
      return input.facts.techStack === void 0 ? next : applyDeployServiceRuntimePolicy(next);
    });
    const manifest = { services };
    const result = writeDeployManifest(cwd, manifest);
    return { ...result, manifest: readDeployManifest(cwd) };
  });
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/codegen-checker.ts
function validateDeployCodegenManifest(input, options = {}) {
  const report = validateDeployManifest(input, options);
  if (!report.ok || !report.value) return report;
  const manifest = report.value;
  const issues = [];
  if (manifest.services.length === 0) issues.push({ path: "services", message: "\u751F\u7801\u524D\u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u670D\u52A1" });
  manifest.services.forEach((service, index) => {
    const prefix = `services[${index}]`;
    const issue = (field, message) => issues.push({ path: `${prefix}.${field}`, message: `${service.serviceName}: ${message}` });
    if (service.sourceDir === void 0) issue("sourceDir", "\u751F\u7801\u524D\u5FC5\u987B\u786E\u5B9A\u6E90\u7801\u76EE\u5F55");
    const stack = service.techStack;
    if (!stack) {
      issue("techStack", "\u751F\u7801\u524D\u5FC5\u987B\u786E\u5B9A\u670D\u52A1\u6280\u672F\u6808");
      return;
    }
    if (stack.language === "java") {
      if (stack.languageVersion === void 0) issue("techStack.languageVersion", "Java \u751F\u7801\u524D\u5FC5\u987B\u786E\u5B9A\u8BED\u8A00\u7248\u672C");
      if (stack.packaging !== "jar" && stack.packaging !== "war")
        issue("techStack.packaging", "Java packaging \u4EC5\u652F\u6301 jar \u6216 war");
    }
    if (stack.framework !== "none" && stack.frameworkVersion === void 0)
      issue("techStack.frameworkVersion", "\u751F\u7801\u524D\u5FC5\u987B\u786E\u5B9A\u6846\u67B6\u7248\u672C");
    if ((stack.language === "javascript" || stack.language === "typescript") && stack.packageManager === void 0)
      issue("techStack.packageManager", "JavaScript/TypeScript \u751F\u7801\u524D\u5FC5\u987B\u786E\u5B9A\u5305\u7BA1\u7406\u5668");
    if (stack.packaging === "war") {
      const container = service.runtime?.container;
      if (!container) issue("runtime.container", "WAR \u751F\u7801\u524D\u5FC5\u987B\u89C4\u5212\u5916\u90E8\u5BB9\u5668");
      else if (!service.runtime?.ports?.some((port) => port.port === container.port))
        issue("runtime.container.port", "WAR \u5BB9\u5668\u7AEF\u53E3\u5FC5\u987B\u5339\u914D\u672C\u670D\u52A1\u547D\u540D\u76D1\u542C\u7AEF\u53E3");
    }
  });
  return issues.length ? { ok: false, issues } : report;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/registration.ts
import { isDeepStrictEqual } from "node:util";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/ask.ts
var DeployInputError = class extends Error {
  constructor(message, code = "REGISTRATION_INVALID") {
    super(message);
    this.code = code;
    this.name = "DeployInputError";
  }
  exitCode = 3;
};
var object2 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var labels = {
  "entry.exposure": { public: "\u5BF9\u5916\u63D0\u4F9B", internal: "\u4EC5\u5185\u90E8\u4F7F\u7528" },
  "entry.retention": { keep: "\u4FDD\u7559\u5165\u53E3", remove: "\u79FB\u9664\u5165\u53E3" },
  "service.retention": { keep: "\u4FDD\u7559\u670D\u52A1", remove: "\u5220\u9664\u670D\u52A1" }
};
function buildDeployAsk(questions) {
  if (!questions.length) return void 0;
  const ids = /* @__PURE__ */ new Set();
  for (const item of questions) {
    if (!Object.hasOwn(labels, item.key) || ids.has(item.id))
      throw new DeployInputError("\u76EE\u6807\u95EE\u8BE2\u7C7B\u578B\u975E\u6CD5\u6216\u91CD\u590D");
    ids.add(item.id);
  }
  const serviceQuestion = questions.some((item) => item.key === "service.retention");
  return {
    fallbackAnswer: "{}",
    timeoutMs: 6e5,
    questions: [{
      header: serviceQuestion ? "\u4E1A\u52A1\u53D8\u66F4\u786E\u8BA4" : "\u4E1A\u52A1\u5165\u53E3\u786E\u8BA4",
      question: serviceQuestion ? "\u8BF7\u786E\u8BA4\u4EE5\u4E0B\u9879\u76EE\u670D\u52A1\u53D8\u66F4" : "\u8BF7\u786E\u8BA4\u4EE5\u4E0B\u9879\u76EE\u5165\u53E3\u4FE1\u606F",
      options: [],
      input: {
        kind: "form",
        formItems: questions.map((item) => {
          const kind = item.key === "service.retention" ? "" : item.target.type === "api" ? "API" : "\u9875\u9762";
          const name = item.key === "service.retention" ? `\u662F\u5426\u4FDD\u7559\u5DF2\u6709\u670D\u52A1 ${item.target.serviceName}\uFF1F` : item.key === "entry.retention" ? `\u662F\u5426\u4FDD\u7559\u5DF2\u6709${kind}\u5165\u53E3 ${item.target.serviceName}${item.target.basePath}\uFF1F` : `\u662F\u5426\u5BF9\u5916\u63D0\u4F9B${kind}\u5165\u53E3 ${item.target.serviceName}${item.target.basePath}\uFF1F`;
          return {
            key: item.id,
            name,
            inputType: "select",
            required: true,
            lineRegion: "whole",
            value: null,
            selectValues: Object.entries(labels[item.key]).map(([value, label]) => ({ name: label, value }))
          };
        })
      }
    }]
  };
}
function resolveDeployAnswer(prepared, answer) {
  const ask = buildDeployAsk(prepared.questions);
  if (!ask) {
    if (answer !== void 0) throw new DeployInputError("\u65E0\u95EE\u8BE2\u65F6\u4E0D\u63A5\u53D7\u7B54\u6848", "ANSWER_INVALID");
    return {};
  }
  let outer;
  try {
    outer = JSON.parse(answer ?? "");
  } catch {
    throw new DeployInputError("\u95EE\u8BE2\u7B54\u6848\u4E0D\u662F\u5408\u6CD5 JSON", "ANSWER_INVALID");
  }
  if (!object2(outer)) throw new DeployInputError("\u95EE\u8BE2\u7B54\u6848\u5FC5\u987B\u4E3A\u5BF9\u8C61", "ANSWER_INVALID");
  if (!Object.keys(outer).length) return null;
  const question = ask.questions[0].question;
  if (Object.keys(outer).length !== 1 || typeof outer[question] !== "string")
    throw new DeployInputError("\u7B54\u6848\u987B\u6309 question \u56DE\u4F20\u539F\u6587", "ANSWER_INVALID");
  let payload;
  try {
    payload = JSON.parse(outer[question]);
  } catch {
    throw new DeployInputError("\u8868\u5355\u7B54\u6848\u4E0D\u662F\u5408\u6CD5 JSON", "ANSWER_INVALID");
  }
  if (!object2(payload) || Object.keys(payload).length !== 1 || !object2(payload.values))
    throw new DeployInputError("\u8868\u5355\u7B54\u6848\u5B57\u6BB5\u4E0D\u5B8C\u6574", "ANSWER_INVALID");
  const values = payload.values;
  if (Object.keys(values).length !== prepared.questions.length)
    throw new DeployInputError("\u8868\u5355\u7B54\u6848\u5B57\u6BB5\u4E0D\u5B8C\u6574", "ANSWER_INVALID");
  const result = {};
  for (const item of prepared.questions) {
    const value = values[item.id];
    if (typeof value !== "string" || !Object.hasOwn(labels[item.key], value))
      throw new DeployInputError("\u7B54\u6848\u4E0D\u5728\u5DF2\u63D0\u4F9B\u5019\u9009\u4E2D\uFF1A" + item.key, "ANSWER_INVALID");
    result[item.id] = value;
  }
  if (Object.keys(values).some((key) => !Object.hasOwn(result, key)))
    throw new DeployInputError("\u8868\u5355\u7B54\u6848\u5B57\u6BB5\u975E\u6CD5", "ANSWER_INVALID");
  return result;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/target-plan.ts
var object3 = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
function defaultMissingHttpPort(entry) {
  if (!object3(entry)) return entry;
  const runtime = entry.runtime;
  if (runtime !== void 0 && (!object3(runtime) || runtime.ports !== void 0)) return entry;
  return {
    ...entry,
    runtime: { ...object3(runtime) ? runtime : {}, ports: [{ name: "http", protocol: "http" }] }
  };
}
function endpointId(ref) {
  return JSON.stringify([ref.serviceName, ref.type, ref.portName, normalizeBasePath(ref.basePath)]);
}
function questionId(key, target) {
  return key === "service.retention" ? `${key}:${target.serviceName}` : [
    key,
    target.serviceName,
    target.type,
    target.portName,
    normalizeBasePath(target.basePath)
  ].join(":");
}
function normalizeDeployTarget(raw, mode) {
  if (mode !== "known" && mode !== "analyzed") throw new DeployInputError("\u767B\u8BB0\u76EE\u6807\u6A21\u5F0F\u975E\u6CD5");
  if (!object3(raw) || Object.keys(raw).some((key) => !["manifest", "deleteServiceNames", "unresolvedExposures"].includes(key)) || !object3(raw.manifest) || Object.keys(raw.manifest).some((key) => key !== "services") || !Array.isArray(raw.manifest.services)) throw new DeployInputError("\u767B\u8BB0\u76EE\u6807\u5FC5\u987B\u5305\u542B manifest.services");
  const names = /* @__PURE__ */ new Set();
  const services = raw.manifest.services.map((entry, index) => {
    const report = validateDeployService(defaultMissingHttpPort(entry));
    if (!report.ok || !report.value)
      throw new DeployInputError(
        report.issues.map((issue) => `manifest.services[${index}].${issue.path}: ${issue.message}`).join("; "),
        "MANIFEST_INVALID"
      );
    const normalizedName = report.value.serviceName.toLowerCase();
    if (names.has(normalizedName)) throw new DeployInputError("serviceName \u91CD\u590D\uFF08\u5FFD\u7565\u5927\u5C0F\u5199\uFF09\uFF1A" + report.value.serviceName);
    names.add(normalizedName);
    return report.value;
  });
  const deletes = raw.deleteServiceNames === void 0 ? [] : raw.deleteServiceNames;
  if (!Array.isArray(deletes)) throw new DeployInputError("deleteServiceNames \u5FC5\u987B\u662F\u6570\u7EC4");
  const deleted = /* @__PURE__ */ new Set();
  const deletedNormalized = /* @__PURE__ */ new Set();
  for (const name of deletes) {
    if (typeof name !== "string" || !SERVICE_NAME_PATTERN.test(name))
      throw new DeployInputError("\u5220\u9664\u7684 serviceName \u53EA\u80FD\u5305\u542B\u82F1\u6587\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\u3001\u70B9\u548C\u8FDE\u5B57\u7B26\uFF0C\u9996\u5C3E\u987B\u4E3A\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u6700\u957F 63 \u4F4D");
    const normalizedName = name.toLowerCase();
    if (deletedNormalized.has(normalizedName))
      throw new DeployInputError("\u5220\u9664\u7684 serviceName \u91CD\u590D\uFF08\u5FFD\u7565\u5927\u5C0F\u5199\uFF09\uFF1A" + name);
    if (names.has(normalizedName)) throw new DeployInputError("\u540C\u4E00 serviceName \u4E0D\u80FD\u540C\u65F6\u66F4\u65B0\u548C\u5220\u9664\uFF1A" + name);
    deleted.add(name);
    deletedNormalized.add(normalizedName);
  }
  if (raw.unresolvedExposures !== void 0 && mode === "known")
    throw new DeployInputError("\u5DF2\u77E5\u76EE\u6807\u4E0D\u63A5\u53D7\u672A\u786E\u5B9A\u7684\u5165\u53E3\u516C\u5F00\u6027");
  const refs = raw.unresolvedExposures;
  if (refs !== void 0 && !Array.isArray(refs)) throw new DeployInputError("unresolvedExposures \u5FC5\u987B\u662F\u6570\u7EC4");
  const endpoints = new Set(
    services.flatMap(
      (service) => (service.endpoints ?? []).map(
        (entry) => endpointId({ serviceName: service.serviceName, type: entry.type, portName: entry.portName, basePath: entry.basePath })
      )
    )
  );
  const seenRefs = /* @__PURE__ */ new Set();
  const unresolvedExposures = (Array.isArray(refs) ? refs : []).map((ref) => {
    if (!object3(ref) || Object.keys(ref).some((key) => !["serviceName", "type", "portName", "basePath"].includes(key)) || typeof ref.serviceName !== "string" || typeof ref.type !== "string" || typeof ref.portName !== "string" || typeof ref.basePath !== "string") throw new DeployInputError("\u672A\u786E\u5B9A\u5165\u53E3\u6807\u8BC6\u975E\u6CD5");
    const normalized = {
      serviceName: ref.serviceName,
      type: ref.type,
      portName: ref.portName,
      basePath: normalizeBasePath(ref.basePath)
    };
    const id = endpointId(normalized);
    if (!endpoints.has(id)) throw new DeployInputError("\u672A\u786E\u5B9A\u5165\u53E3\u4E0D\u5728\u672C\u6B21\u670D\u52A1\u76EE\u6807\u4E2D");
    if (seenRefs.has(id)) throw new DeployInputError("\u672A\u786E\u5B9A\u5165\u53E3\u91CD\u590D");
    seenRefs.add(id);
    return normalized;
  });
  return {
    manifest: { services },
    deleteServiceNames: [...deleted],
    ...refs === void 0 ? {} : { unresolvedExposures }
  };
}
function planDeployTarget(target, current, mode) {
  const input = normalizeDeployTarget(target, mode);
  if (mode === "known") return [];
  const existing = new Map(current.services.map((service) => [service.serviceName, service]));
  const questions = [];
  for (const serviceName of input.deleteServiceNames ?? []) {
    if (!existing.has(serviceName)) throw new DeployInputError("service \u4E0D\u5B58\u5728\uFF1A" + serviceName, "SERVICE_NOT_FOUND");
    const target2 = { serviceName };
    questions.push({ id: questionId("service.retention", target2), key: "service.retention", target: target2 });
  }
  for (const service of input.manifest.services) {
    const previous = existing.get(service.serviceName);
    if (!previous) continue;
    const currentEntries = new Set(
      (service.endpoints ?? []).map((entry) => endpointId({
        serviceName: service.serviceName,
        type: entry.type,
        portName: entry.portName,
        basePath: entry.basePath
      }))
    );
    for (const entry of previous.endpoints ?? []) {
      const target2 = { serviceName: service.serviceName, type: entry.type, portName: entry.portName, basePath: entry.basePath };
      if (!currentEntries.has(endpointId(target2)))
        questions.push({ id: questionId("entry.retention", target2), key: "entry.retention", target: target2 });
    }
  }
  for (const target2 of input.unresolvedExposures ?? [])
    questions.push({ id: questionId("entry.exposure", target2), key: "entry.exposure", target: target2 });
  return questions;
}
function applyDeployTargetAnswers(target, originals, questions, values) {
  const services = structuredClone(target.manifest.services);
  const deleted = new Set(target.deleteServiceNames ?? []);
  const ids = new Set(questions.map((question) => question.id));
  if (Object.keys(values).length !== ids.size || Object.keys(values).some((id) => !ids.has(id)))
    throw new DeployInputError("\u95EE\u8BE2\u7B54\u6848\u5B57\u6BB5\u4E0D\u5B8C\u6574", "ANSWER_INVALID");
  for (const question of questions) {
    const value = values[question.id];
    if (question.key === "service.retention") {
      if (value !== "keep" && value !== "remove") throw new DeployInputError("\u670D\u52A1\u4FDD\u7559\u7B54\u6848\u975E\u6CD5", "ANSWER_INVALID");
      if (value === "keep") deleted.delete(question.target.serviceName);
      continue;
    }
    const service = services.find((entry2) => entry2.serviceName === question.target.serviceName);
    if (!service) throw new DeployInputError("\u95EE\u8BE2\u76EE\u6807\u670D\u52A1\u4E0D\u5B58\u5728", "ANSWER_INVALID");
    const id = endpointId(question.target);
    if (question.key === "entry.retention") {
      if (value !== "keep" && value !== "remove") throw new DeployInputError("\u5165\u53E3\u4FDD\u7559\u7B54\u6848\u975E\u6CD5", "ANSWER_INVALID");
      if (value === "keep") {
        const original = originals[question.target.serviceName];
        const entry2 = original?.endpoints?.find((candidate) => endpointId({
          serviceName: question.target.serviceName,
          type: candidate.type,
          portName: candidate.portName,
          basePath: candidate.basePath
        }) === id);
        if (!entry2) throw new DeployInputError("\u539F\u6709\u5165\u53E3\u4E0D\u5B58\u5728", "ANSWER_INVALID");
        service.endpoints = [...service.endpoints ?? [], structuredClone(entry2)];
        const port = original?.runtime?.ports?.find((candidate) => candidate.name === entry2.portName);
        if (!port) throw new DeployInputError("\u539F\u6709\u5165\u53E3\u7684\u547D\u540D\u7AEF\u53E3\u4E0D\u5B58\u5728", "ANSWER_INVALID");
        const currentPort = service.runtime?.ports?.find((candidate) => candidate.name === entry2.portName);
        if (currentPort && currentPort.protocol !== port.protocol)
          throw new DeployInputError("\u4FDD\u7559\u5165\u53E3\u4E0E\u540C\u540D\u7AEF\u53E3\u7684\u65B0\u534F\u8BAE\u51B2\u7A81", "ANSWER_INVALID");
        if (!currentPort) {
          service.runtime = { ...service.runtime, ports: [...service.runtime?.ports ?? [], structuredClone(port)] };
        }
      }
      continue;
    }
    if (value !== "public" && value !== "internal") throw new DeployInputError("\u5165\u53E3\u516C\u5F00\u6027\u7B54\u6848\u975E\u6CD5", "ANSWER_INVALID");
    const entry = service.endpoints?.find((candidate) => endpointId({
      serviceName: question.target.serviceName,
      type: candidate.type,
      portName: candidate.portName,
      basePath: candidate.basePath
    }) === id);
    if (!entry) throw new DeployInputError("\u95EE\u8BE2\u76EE\u6807\u5165\u53E3\u4E0D\u5B58\u5728", "ANSWER_INVALID");
    entry.exposure = value;
  }
  return { upserts: services, deleteServiceNames: [...deleted] };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/platform-tool.ts
import { execFile } from "node:child_process";
import path4 from "node:path";
import { promisify } from "node:util";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/domain-result.ts
var record = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var nonEmpty = (value) => typeof value === "string" && value.trim().length > 0;
function parseDeployServiceDomains(value, label = "domains") {
  if (!Array.isArray(value)) throw new Error(`${label} \u5E94\u4E3A\u6570\u7EC4`);
  const names = /* @__PURE__ */ new Set();
  for (const [index, service] of value.entries()) {
    if (!record(service) || !nonEmpty(service.serviceName) || !nonEmpty(service.domain) || !Array.isArray(service.endpoints) || !service.endpoints.length || names.has(service.serviceName)) throw new Error(`${label}[${index}] \u7ED3\u6784\u975E\u6CD5\u6216 serviceName \u91CD\u590D`);
    names.add(service.serviceName);
    let hostname;
    try {
      const host = new URL(`https://${service.domain}`);
      hostname = host.hostname;
      if (host.host !== service.domain || host.port || host.pathname !== "/") throw new Error("domain includes path or port");
    } catch {
      throw new Error(`${label}[${index}].domain \u7ED3\u6784\u975E\u6CD5`);
    }
    for (const [endpointIndex, endpoint] of service.endpoints.entries()) {
      const itemLabel = `${label}[${index}].endpoints[${endpointIndex}]`;
      if (!record(endpoint) || typeof endpoint.type !== "string" || !["pc", "h5", "api"].includes(endpoint.type) || typeof endpoint.businessType !== "string" || !["application", "prototype"].includes(endpoint.businessType) || !nonEmpty(endpoint.title) || !nonEmpty(endpoint.basePath) || !endpoint.basePath.startsWith("/") || !nonEmpty(endpoint.url)) throw new Error(`${itemLabel} \u7ED3\u6784\u975E\u6CD5`);
      try {
        const url = new URL(endpoint.url);
        if (!["http:", "https:"].includes(url.protocol) || url.hostname !== hostname)
          throw new Error("URL host mismatch");
      } catch {
        throw new Error(`${itemLabel}.url \u7ED3\u6784\u975E\u6CD5`);
      }
    }
  }
  return value;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/platform-tool.ts
var execFileAsync = promisify(execFile);
var DEFAULT_PLATFORM_REQUEST_TIMEOUT_MS = 6e4;
var PLATFORM_TOOL_TIMEOUT_MARGIN_MS = 3e4;
function resolvePlatformToolTimeoutMs(env) {
  const configured = Number(env.PLATFORM_DB_API_TIMEOUT_MS);
  const perAttempt = Number.isFinite(configured) && configured > 0 ? configured : DEFAULT_PLATFORM_REQUEST_TIMEOUT_MS;
  return Math.min(2147483647, perAttempt * 4 + PLATFORM_TOOL_TIMEOUT_MARGIN_MS);
}
async function runPlatformTool(cwd, args, env, timeoutMs = resolvePlatformToolTimeoutMs(env)) {
  try {
    const result = await execFileAsync(
      process.execPath,
      [path4.resolve(cwd, ".specify/scripts/javascript/platform-tool.mjs"), ...args],
      { cwd, env, encoding: "utf8", maxBuffer: 1024 * 1024, timeout: timeoutMs, windowsHide: true }
    );
    return { code: 0, stdout: result.stdout, stderr: result.stderr };
  } catch (error) {
    const processError = error && typeof error === "object" ? error : {};
    return {
      code: typeof processError.code === "number" ? processError.code : 1,
      stdout: processError.stdout ?? "",
      stderr: processError.stderr ?? errorMessage2(error)
    };
  }
}
async function submitViaPlatformTool(request, cwd = process.cwd(), env = process.env) {
  const result = await runPlatformTool(cwd, ["register-app-frontends", "--payload", JSON.stringify(request)], env);
  if (result.code !== 0) throw new Error(result.stderr.trim() || result.stdout.trim() || `platform-tool exit ${result.code}`);
  let response;
  try {
    response = JSON.parse(result.stdout);
  } catch (error) {
    throw new Error(`platform-tool \u8FD4\u56DE\u975E JSON\uFF1A${errorMessage2(error)}`);
  }
  if (!response || typeof response !== "object" || Array.isArray(response) || response.ok !== true) throw new Error("platform-tool \u672A\u8FD4\u56DE\u6210\u529F\u7ED3\u679C");
  const payload = response;
  return Object.hasOwn(payload, "domains") ? parseDeployServiceDomains(payload.domains) : void 0;
}
function errorMessage2(error) {
  return error instanceof Error ? error.message : String(error);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/lcap-client.ts
var PreviewSyncValidationError = class extends Error {
  constructor(message, code = "PREVIEW_SYNC_INVALID") {
    super(message);
    this.code = code;
    this.name = "PreviewSyncValidationError";
  }
  exitCode = 3;
};
var LcapPreviewSyncError = class extends Error {
  exitCode = 1;
  code = "LCAP_API_FAILED";
  constructor(message) {
    super(message);
    this.name = "LcapPreviewSyncError";
  }
};
function hasPublicEndpoints(manifest) {
  return manifest.services.some((service) => service.endpoints?.some((endpoint) => endpoint.exposure === "public"));
}
function readDeployPreviewContext(env = process.env) {
  const fields = [
    ["APP_ID", "appId"],
    ["PRD_ID", "collaborationId"],
    ["CURRENT_BRANCH", "branchName"]
  ];
  const context = {};
  for (const [variable, field] of fields) {
    const value = env[variable];
    if (typeof value !== "string" || !value.trim())
      throw new PreviewSyncValidationError("\u73AF\u5883\u53D8\u91CF " + variable + " \u7F3A\u5931", "PREVIEW_CONTEXT_MISSING");
    context[field] = value;
  }
  return context;
}
function checkPreviewSupport(manifest, options = {}) {
  const report = validateDeployManifest(manifest);
  if (!report.ok || !report.value) return report;
  const issues = [];
  let count = 0;
  for (const service of report.value.services) {
    const externalPorts = /* @__PURE__ */ new Set();
    for (const endpoint of (service.endpoints ?? []).filter((entry) => entry.exposure === "public")) {
      count++;
      const port = service.runtime?.ports?.find((p) => p.name === endpoint.portName);
      externalPorts.add(endpoint.portName);
      if (port?.protocol !== "http") {
        issues.push({
          path: service.serviceName + "/endpoints",
          message: "\u5F53\u524D\u5E73\u53F0\u4EC5\u652F\u6301 HTTP \u5916\u90E8\u5165\u53E3\uFF0C\u5C1A\u4E0D\u652F\u6301\u975E HTTP \u5916\u90E8\u5165\u53E3"
        });
      }
    }
    if (externalPorts.size > 1)
      issues.push({ path: service.serviceName + "/endpoints", message: "\u5F53\u524D\u5E73\u53F0\u4E0D\u652F\u6301\u540C\u4E00\u670D\u52A1\u591A\u4E2A\u5916\u90E8\u547D\u540D\u7AEF\u53E3" });
  }
  if (!count && report.value.services.length === 0 && !options.allowEmptyTarget)
    issues.push({ path: "services", message: "\u7A7A\u76EE\u6807\u4EC5\u5141\u8BB8\u7528\u4E8E\u6E05\u7406\u5DF2\u6709\u516C\u5F00\u5165\u53E3" });
  return issues.length ? { ok: false, issues } : report;
}
function buildPreviewSyncRequest(manifest, mappings, context, options = {}) {
  readDeployPreviewContext({
    APP_ID: context?.appId,
    PRD_ID: context?.collaborationId,
    CURRENT_BRANCH: context?.branchName
  });
  const support = checkPreviewSupport(manifest, options);
  if (!support.ok)
    throw new PreviewSyncValidationError(
      support.issues.map((i) => i.path + ": " + i.message).join("; "),
      "PREVIEW_UNSUPPORTED"
    );
  const report = validateDeployManifest(manifest, { requireRuntime: true });
  if (!report.ok || !report.value) throw new PreviewSyncValidationError(report.issues.map((i) => i.message).join("; "));
  const frontends = [];
  const serviceMappings = [];
  for (const service of report.value.services) {
    const endpoints = (service.endpoints ?? []).filter((endpoint) => endpoint.exposure === "public");
    if (!endpoints.length) continue;
    const portName = endpoints[0].portName;
    const port = service.runtime?.ports?.find((p) => p.name === portName)?.port;
    const matches = mappings.filter(
      (m) => m.serviceName === service.serviceName && m.portName === portName && m.port === port
    );
    const mapping = matches[0];
    if (matches.length !== 1 || typeof mapping.inboundBasePath !== "string" || !mapping.inboundBasePath.startsWith("/"))
      throw new PreviewSyncValidationError(
        "\u670D\u52A1 " + service.serviceName + "/" + portName + " \u7F3A\u5C11\u552F\u4E00\u6709\u6548 Sandbox \u5165\u7AD9\u6620\u5C04",
        "RUNTIME_MAPPING_MISSING"
      );
    serviceMappings.push({ serviceName: service.serviceName, inboundBasePath: mapping.inboundBasePath });
    for (const endpoint of endpoints)
      frontends.push({
        serviceName: service.serviceName,
        basePath: endpoint.basePath,
        type: endpoint.type,
        businessType: endpoint.businessType ?? "application",
        title: endpoint.title
      });
  }
  return { ...context, frontends, serviceMappings };
}
async function syncPreviewToLcap(request, submit = submitViaPlatformTool) {
  try {
    return await submit(request);
  } catch (error) {
    throw new LcapPreviewSyncError("LCAP \u4E1A\u52A1\u7AEF\u540C\u6B65\u5931\u8D25\uFF1A" + errorMessage3(error));
  }
}
function errorMessage3(error) {
  return error instanceof Error ? error.message : String(error);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/external-dependencies.ts
import fs5 from "node:fs";
import { createHash } from "node:crypto";
import os from "node:os";
import path6 from "node:path";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/sandbox-inbound.ts
import { execFile as execFile2 } from "node:child_process";
import { promisify as promisify2 } from "node:util";
var execFileAsync2 = promisify2(execFile2);
var DEFAULT_TIMEOUT_MS2 = 15e3;
var SandboxInboundExternalError = class extends Error {
  constructor(message, partialMappings = []) {
    super(message);
    this.partialMappings = partialMappings;
    this.name = "SandboxInboundExternalError";
  }
  exitCode = 1;
  code = "SBX_INBOUND_FAILED";
};
var SandboxInboundValidationError = class extends Error {
  constructor(message, partialMappings = []) {
    super(message);
    this.partialMappings = partialMappings;
    this.name = "SandboxInboundValidationError";
  }
  exitCode = 3;
  code = "SBX_INBOUND_INVALID";
};
async function listSandboxInbound(options = {}) {
  return runSandboxInbound(["list"], options);
}
async function setSandboxInbound(ports, keys, options = {}) {
  if (ports.length === 0 || ports.length !== keys.length || ports.some((port) => !Number.isInteger(port) || port < 1 || port > 65535) || keys.some((key) => typeof key !== "string" || key.trim() === "") || new Set(keys).size !== keys.length) {
    throw new SandboxInboundValidationError("sbx-inbound set \u9700\u8981\u7B49\u957F\u4E14\u552F\u4E00\u7684\u670D\u52A1 key \u4E0E\u6709\u6548\u76D1\u542C\u7AEF\u53E3");
  }
  const completed = [];
  for (let i = 0; i < ports.length; i++) {
    try {
      const returned = await runSandboxInbound(["set", "-p", String(ports[i]), "-k", keys[i]], options);
      if (returned.length !== 1 || returned[0].key !== keys[i]) {
        throw new SandboxInboundValidationError(`sbx-inbound set \u8FD4\u56DE\u6570\u91CF\u6216 key \u4E0E\u670D\u52A1 ${keys[i]} \u4E0D\u4E00\u81F4`);
      }
      completed.push(returned[0]);
    } catch (error) {
      if (error instanceof SandboxInboundValidationError) {
        throw new SandboxInboundValidationError(error.message, [...completed, ...error.partialMappings]);
      }
      if (error instanceof SandboxInboundExternalError) {
        throw new SandboxInboundExternalError(error.message, completed);
      }
      throw error;
    }
  }
  return completed;
}
async function runSandboxInbound(args, options) {
  const binary = options.binary || (options.env ?? process.env).SBOX_INBOUND_BIN || "sbx-inbound";
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS2;
  let stdout;
  try {
    const result = await execFileAsync2(binary, args, {
      encoding: "utf8",
      env: options.env ?? process.env,
      timeout: timeoutMs,
      windowsHide: true
    });
    stdout = result.stdout ?? "";
  } catch (error) {
    const failure = error;
    const detail = failure.killed || failure.signal ? `\u6267\u884C\u8D85\u65F6\uFF08${timeoutMs}ms\uFF09` : (failure.stderr || failure.stdout || failure.message || "\u672A\u77E5\u9519\u8BEF").trim();
    throw new SandboxInboundExternalError(`sbx-inbound ${args[0]} \u5931\u8D25\uFF1A${detail}`);
  }
  return parseSandboxInboundMappings(stdout, args[0]);
}
function parseSandboxInboundMappings(stdout, operation) {
  let parsed;
  try {
    parsed = JSON.parse(stdout);
  } catch (error) {
    throw new SandboxInboundValidationError(`sbx-inbound ${operation} stdout \u4E0D\u662F\u5408\u6CD5 JSON\uFF1A${errorMessage4(error)}`);
  }
  if (!Array.isArray(parsed)) {
    throw new SandboxInboundValidationError(`sbx-inbound ${operation} stdout \u5FC5\u987B\u662F JSON \u6570\u7EC4`);
  }
  const mappings = [];
  const issues = [];
  parsed.forEach((value, index) => {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
      issues.push(`sbx-inbound ${operation} \u7B2C ${index + 1} \u6761\u6620\u5C04\u5FC5\u987B\u662F\u5BF9\u8C61`);
      return;
    }
    const mapping = value;
    const listen = Number(mapping.listen);
    const connect = Number(mapping.connect);
    const validKey = typeof mapping.key === "number" && Number.isFinite(mapping.key) || typeof mapping.key === "string" && mapping.key.trim() !== "";
    if (!Number.isInteger(listen) || listen < 1 || listen > 65535 || !Number.isInteger(connect) || connect < 1 || connect > 65535 || !validKey || typeof mapping.path !== "string" || !mapping.path.startsWith("/")) {
      issues.push(`sbx-inbound ${operation} \u7B2C ${index + 1} \u6761\u6620\u5C04\u7ED3\u6784\u4E0D\u5B8C\u6574`);
      return;
    }
    mappings.push({
      listen,
      connect,
      key: mapping.key,
      path: mapping.path,
      ...typeof mapping.preset === "boolean" ? { preset: mapping.preset } : {}
    });
  });
  if (issues.length) {
    const known = mappings.filter(
      (mapping) => parsed.filter(
        (value) => typeof value === "object" && value !== null && !Array.isArray(value) && Number(value.listen) === mapping.listen
      ).length === 1
    );
    throw new SandboxInboundValidationError(issues.join("; "), known);
  }
  return mappings;
}
function errorMessage4(error) {
  return error instanceof Error ? error.message : String(error);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/local-mock.ts
import fs4 from "node:fs/promises";

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/local-mock-state.ts
import fs3 from "node:fs/promises";
import path5 from "node:path";
import { randomUUID as randomUUID2 } from "node:crypto";
var STATE_FILE = "deploy-local-mock-state.json";
var LOCK_DIR = ".deploy-local-mock.lock";
async function readLocalMockState(stateDir) {
  let content;
  try {
    content = await fs3.readFile(path5.join(stateDir, STATE_FILE), "utf8");
  } catch (error) {
    if (error.code === "ENOENT")
      return { version: 1, mappings: {}, lastTarget: null, submissions: [] };
    throw error;
  }
  let value;
  try {
    value = JSON.parse(content);
  } catch {
    throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u6587\u4EF6\u4E0D\u662F JSON");
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u975E\u6CD5");
  const state = value;
  if (state.version !== 1 || !state.mappings || typeof state.mappings !== "object" || Array.isArray(state.mappings) || !Array.isArray(state.submissions) || !("lastTarget" in state))
    throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u7248\u672C\u6216\u7ED3\u6784\u975E\u6CD5");
  if (Object.entries(state.mappings).some(([key, mapping]) => {
    const item = mapping;
    return !item || typeof item !== "object" || Array.isArray(item) || !Number.isInteger(Number(key)) || String(Number(key)) !== key || item.listen !== Number(key) || !validPort(item.connect) || typeof item.key !== "string" && typeof item.key !== "number" || !nonEmpty2(String(item.key)) || typeof item.path !== "string" || !item.path.startsWith("/");
  }) || state.lastTarget !== null && !validTarget(state.lastTarget) || state.submissions.some((submission) => !submission || typeof submission !== "object" || typeof submission.at !== "string" || !nonEmpty2(submission.at) || !validTarget(submission.target)))
    throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u5185\u5BB9\u635F\u574F");
  return state;
}
function validPort(value) {
  return typeof value === "number" && Number.isInteger(value) && value >= 1 && value <= 65535;
}
function nonEmpty2(value) {
  return typeof value === "string" && value.trim().length > 0;
}
function validTarget(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const target = value;
  return nonEmpty2(target.appId) && nonEmpty2(target.collaborationId) && nonEmpty2(target.branchName) && Array.isArray(target.frontends) && target.frontends.every((item) => item && typeof item === "object" && nonEmpty2(item.serviceName) && nonEmpty2(item.title) && nonEmpty2(item.basePath) && ["pc", "h5", "api"].includes(item.type) && ["application", "prototype"].includes(item.businessType)) && Array.isArray(target.serviceMappings) && target.serviceMappings.every((item) => item && typeof item === "object" && nonEmpty2(item.serviceName) && nonEmpty2(item.inboundBasePath) && item.inboundBasePath.startsWith("/"));
}
function processAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error.code !== "ESRCH";
  }
}
async function recoverAbandonedLock(lock) {
  const owner = path5.join(lock, "owner");
  let data;
  try {
    data = await fs3.readFile(owner, "utf8");
  } catch (error) {
    if (error.code !== "ENOENT") return;
  }
  let pid;
  try {
    pid = data ? JSON.parse(data).pid : void 0;
  } catch {
  }
  if (typeof pid === "number" && Number.isInteger(pid) && pid > 0) {
    if (processAlive(pid)) return;
  } else {
    const age = Date.now() - (await fs3.stat(lock).catch(() => ({ mtimeMs: Date.now() }))).mtimeMs;
    if (age < 3e4) return;
  }
  const claim = path5.join(lock, ".recovery");
  try {
    await fs3.mkdir(claim);
  } catch (error) {
    if (error.code !== "EEXIST") return;
    const age = Date.now() - (await fs3.stat(claim).catch(() => ({ mtimeMs: Date.now() }))).mtimeMs;
    if (age < 3e4) return;
    await fs3.rmdir(claim).catch(() => {
    });
    return;
  }
  try {
    if (await fs3.readFile(owner, "utf8").catch(() => void 0) !== data) return;
    if (data !== void 0) await fs3.unlink(owner).catch(() => {
    });
  } finally {
    await fs3.rmdir(claim).catch(() => {
    });
  }
  await fs3.rmdir(lock).catch(() => {
  });
}
async function updateLocalMockState(stateDir, update) {
  const lock = path5.join(stateDir, LOCK_DIR);
  const owner = path5.join(lock, "owner");
  const token = randomUUID2();
  const deadline = Date.now() + 1e4;
  for (; ; ) {
    try {
      await fs3.mkdir(lock);
      try {
        await fs3.writeFile(owner, JSON.stringify({ pid: process.pid, token }), { flag: "wx" });
      } catch (error) {
        await fs3.rmdir(lock).catch(() => {
        });
        throw error;
      }
      break;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      await recoverAbandonedLock(lock);
      if (Date.now() > deadline) throw new Error("\u672C\u5730 deploy mock \u72B6\u6001\u9501\u7B49\u5F85\u8D85\u65F6");
      await new Promise((resolve) => setTimeout(resolve, 20));
    }
  }
  const temp = path5.join(stateDir, `.${STATE_FILE}.${randomUUID2()}.tmp`);
  try {
    const state = await readLocalMockState(stateDir);
    const result = update(state);
    await fs3.writeFile(temp, JSON.stringify(state, null, 2) + "\n", { flag: "wx" });
    await fs3.rename(temp, path5.join(stateDir, STATE_FILE));
    return result;
  } finally {
    await fs3.unlink(temp).catch(() => {
    });
    if (await fs3.readFile(owner, "utf8").catch(() => "") === JSON.stringify({ pid: process.pid, token })) {
      await fs3.unlink(owner);
      await fs3.rmdir(lock);
    }
  }
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/local-mock.ts
function localMockServiceDomain(serviceName) {
  if (/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/.test(serviceName))
    return `${serviceName.toLowerCase()}.deploy.local.test`;
  const hex = Buffer.from(serviceName, "utf8").toString("hex");
  if (!hex) throw new Error("\u672C\u5730 deploy mock \u670D\u52A1\u540D\u4E0D\u80FD\u4E3A\u7A7A");
  return `encoded.${hex.match(/.{1,60}/g).map((part) => "x" + part).join(".")}.deploy.local.test`;
}
function domainsFromTarget(target) {
  const grouped = /* @__PURE__ */ new Map();
  for (const frontend of target.frontends) {
    let service = grouped.get(frontend.serviceName);
    if (!service) {
      service = { serviceName: frontend.serviceName, domain: localMockServiceDomain(frontend.serviceName), endpoints: [] };
      grouped.set(frontend.serviceName, service);
    }
    service.endpoints.push({
      type: frontend.type,
      businessType: frontend.businessType,
      title: frontend.title,
      basePath: frontend.basePath,
      url: new URL(frontend.basePath, `https://${service.domain}`).toString()
    });
  }
  return parseDeployServiceDomains([...grouped.values()], "local-mock domains");
}
function createLocalMockDependencies(stateDir, domainsFile) {
  return {
    inbound: {
      async list() {
        const state = await readLocalMockState(stateDir);
        return Object.values(state.mappings);
      },
      async set(ports, keys) {
        if (!ports.length || ports.length !== keys.length || ports.some((port) => !Number.isInteger(port) || port < 1 || port > 65535) || keys.some((key) => !key))
          throw new Error("\u672C\u5730 deploy mock \u9700\u8981\u7B49\u957F\u7684\u6709\u6548\u76D1\u542C\u7AEF\u53E3\u548C\u670D\u52A1 key");
        return updateLocalMockState(stateDir, (state) => ports.map((port, index) => {
          const key = String(port);
          const serviceKey = keys[index];
          const existing = state.mappings[key];
          if (existing && existing.key !== serviceKey) throw new Error(`\u76D1\u542C\u7AEF\u53E3 ${port} \u5DF2\u7531\u5176\u4ED6 key \u5360\u7528`);
          if (Object.values(state.mappings).some((mapping) => mapping.key === serviceKey && mapping.listen !== port))
            throw new Error(`\u670D\u52A1 key ${serviceKey} \u5DF2\u7ED1\u5B9A\u5176\u4ED6\u76D1\u542C\u7AEF\u53E3`);
          return state.mappings[key] ??= {
            listen: port,
            connect: port,
            key: serviceKey,
            path: `/__deploy_local_mock__/${port}`
          };
        }));
      }
    },
    submitPreview: async (request) => {
      const domains = domainsFromTarget(request);
      await updateLocalMockState(stateDir, (state) => {
        const target = structuredClone(request);
        state.lastTarget = target;
        state.submissions.push({ target, at: (/* @__PURE__ */ new Date()).toISOString() });
      });
      return domains;
    },
    runPlatformTool: async (_cwd, args) => {
      if (args.length !== 1 || args[0] !== "get-service-domains")
        return { code: 1, stdout: "", stderr: `\u672C\u5730 deploy mock \u4E0D\u652F\u6301 platform-tool ${args.join(" ")}` };
      const state = await readLocalMockState(stateDir);
      let domains = state.lastTarget ? domainsFromTarget(state.lastTarget) : [];
      if (state.lastTarget === null && domainsFile) {
        const value = JSON.parse(await fs4.readFile(domainsFile, "utf8"));
        if (!value || typeof value !== "object" || Array.isArray(value) || !Array.isArray(value.domains))
          throw new Error("DEPLOY_MOCK_DOMAINS_FILE \u5FC5\u987B\u5305\u542B domains \u6570\u7EC4");
        domains = parseDeployServiceDomains(value.domains, "DEPLOY_MOCK_DOMAINS_FILE domains");
      }
      return { code: 0, stdout: JSON.stringify({ domains }), stderr: "" };
    }
  };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/external-dependencies.ts
function readDeployExternalConfig(env, cwd = process.cwd()) {
  const mode = env.DEPLOY_EXTERNAL_MODE ?? "real";
  if (mode === "real") return { mode: "real" };
  if (mode !== "local-mock") throw new Error(`DEPLOY_EXTERNAL_MODE \u65E0\u6548\uFF1A${mode}`);
  const override = env.DEPLOY_MOCK_STATE_DIR;
  if (override !== void 0 && !path6.isAbsolute(override))
    throw new Error("DEPLOY_MOCK_STATE_DIR \u5FC5\u987B\u662F\u5DF2\u5B58\u5728\u7684\u7EDD\u5BF9\u76EE\u5F55");
  const stateDir = override ?? path6.join(
    os.tmpdir(),
    "hicode-deploy-local-mock",
    createHash("sha256").update(fs5.realpathSync(cwd)).digest("hex").slice(0, 20)
  );
  if (override === void 0) fs5.mkdirSync(stateDir, { recursive: true });
  try {
    if (!fs5.statSync(stateDir).isDirectory()) throw new Error("not-directory");
    fs5.accessSync(stateDir, fs5.constants.W_OK);
  } catch {
    throw new Error("DEPLOY_MOCK_STATE_DIR \u4E0D\u5B58\u5728\u6216\u4E0D\u53EF\u5199");
  }
  const domainsFile = env.DEPLOY_MOCK_DOMAINS_FILE;
  if (domainsFile && !path6.isAbsolute(domainsFile))
    throw new Error("DEPLOY_MOCK_DOMAINS_FILE \u5FC5\u987B\u662F\u7EDD\u5BF9\u8DEF\u5F84");
  return domainsFile ? { mode, stateDir, domainsFile } : { mode, stateDir };
}
function readDeployPreviewContextForMode(cwd, env) {
  return readDeployExternalConfig(env, cwd).mode === "local-mock" ? { appId: "local-app", collaborationId: "local-prd", branchName: "local-branch" } : readDeployPreviewContext(env);
}
function createRealDeployDependencies(cwd, env) {
  return {
    inbound: {
      list: () => listSandboxInbound({ env }),
      set: (ports, keys) => setSandboxInbound(ports, keys, { env })
    },
    submitPreview: (request) => submitViaPlatformTool(request, cwd, env),
    runPlatformTool
  };
}
function resolveDeployExternalDependencies(cwd, env) {
  const config = readDeployExternalConfig(env, cwd);
  return config.mode === "local-mock" ? createLocalMockDependencies(config.stateDir, config.domainsFile) : createRealDeployDependencies(cwd, env);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/runtime.ts
var DeployRuntimeError = class extends Error {
  constructor(message, code, uncertain, ports = [], exitCode = 1, details) {
    super(message);
    this.code = code;
    this.uncertain = uncertain;
    this.ports = ports;
    this.exitCode = exitCode;
    this.details = details;
    this.name = "DeployRuntimeError";
  }
};
async function preflightDeployPorts(input, options = {}) {
  const inbound = options.inbound ?? resolveDeployExternalDependencies(options.cwd ?? process.cwd(), options.env ?? process.env).inbound;
  return runDeployPorts(input, "register", { ...options, inbound }, true);
}
async function ensureDeployPorts(input, mode, options = {}) {
  return runDeployPorts(input, mode, options, false);
}
async function runDeployPorts(input, mode, options, preflight) {
  const report = validateDeployManifest(input);
  if (!report.ok || !report.value) {
    throw new DeployRuntimeError(
      report.issues.map((i) => i.path + ": " + i.message).join("; "),
      "MANIFEST_INVALID",
      false,
      [],
      3
    );
  }
  const manifest = report.value;
  for (const service of manifest.services) {
    const namedPorts = service.runtime?.ports ?? [];
    const httpPorts = namedPorts.filter((port) => port.protocol === "http");
    if (httpPorts.length > 1) {
      throw new DeployRuntimeError(
        `service ${service.serviceName} \u6709\u591A\u4E2A HTTP \u547D\u540D\u7AEF\u53E3\uFF0C\u65E0\u6CD5\u4F7F\u7528\u552F\u4E00 serviceName \u767B\u8BB0\u5165\u7AD9\u901A\u9053`,
        "RUNTIME_HTTP_PORT_AMBIGUOUS",
        false,
        [],
        3
      );
    }
    for (const port of namedPorts) if (port.protocol !== "http") delete port.connectPort;
  }
  const entries = manifest.services.flatMap(
    (service) => (service.runtime?.ports ?? []).filter((port) => port.protocol === "http").map((port) => ({ service, serviceName: service.serviceName, port }))
  );
  if (mode === "restore" && entries.some((entry) => entry.port.port === void 0)) {
    throw new DeployRuntimeError("\u6062\u590D\u9700\u8981 HTTP \u547D\u540D\u7AEF\u53E3\u5DF2\u6709\u76D1\u542C\u503C\uFF0C\u8BF7\u5148\u5B8C\u6210\u767B\u8BB0", "RUNTIME_UNASSIGNED", false, [], 3);
  }
  if (!entries.length) return preflight ? { ports: [] } : { manifest, ports: [] };
  const inbound = options.inbound ?? {
    list: () => listSandboxInbound({ env: options.env }),
    set: (ports2, keys) => setSandboxInbound(ports2, keys, { env: options.env })
  };
  let current;
  try {
    current = parseSandboxInboundMappings(JSON.stringify(await inbound.list()), "list");
    if (new Set(current.map((m) => m.listen)).size !== current.length) throw new Error("list \u8FD4\u56DE\u91CD\u590D\u76D1\u542C\u7AEF\u53E3");
    const serviceKeys = current.filter((m) => typeof m.key === "string" && entries.some((e) => e.serviceName === m.key));
    if (new Set(serviceKeys.map((m) => m.key)).size !== serviceKeys.length) throw new Error("list \u8FD4\u56DE\u91CD\u590D\u670D\u52A1 key");
  } catch (error) {
    throw new DeployRuntimeError(error instanceof Error ? error.message : String(error), "RUNTIME_LIST_FAILED", false);
  }
  const ports = [];
  const reserved = /* @__PURE__ */ new Set([
    ...BUILT_IN_PRESET_PORTS,
    ...current.map((m) => m.listen),
    ...manifest.services.flatMap((service) => (service.runtime?.ports ?? []).flatMap((port) => port.port === void 0 ? [] : [port.port]))
  ]);
  const pending = [];
  for (const entry of entries) {
    if (entry.port.inboundKeyMode === void 0 && isEligibleBuiltInPresetPort(entry.service, entry.port) && !current.some((mapping) => mapping.key === entry.serviceName)) {
      const mapping = current.find((item) => item.listen === entry.port.port);
      if (mapping && String(mapping.key) === String(entry.port.port) && mapping.preset === true)
        entry.port.inboundKeyMode = "preset-port";
    }
    if (entry.port.inboundKeyMode === "preset-port") {
      const requested2 = entry.port.port;
      const named = current.find((mapping2) => mapping2.key === entry.serviceName);
      if (named) {
        throw new DeployRuntimeError(
          `service ${entry.serviceName} \u9009\u62E9\u9884\u7F6E\u901A\u9053\uFF0C\u4F46\u540C\u540D key \u5DF2\u7ED1\u5B9A\u76D1\u542C\u7AEF\u53E3 ${named.listen}\uFF1B\u8BF7\u5148\u6838\u5BF9\u6C99\u7BB1\u6620\u5C04\u4E0E Manifest`,
          "RUNTIME_KEY_CONFLICT",
          false,
          ports,
          3,
          {
            reason: "KEY_PORT_MISMATCH",
            serviceName: entry.serviceName,
            portName: entry.port.name,
            requestedPort: requested2,
            occupiedByKey: named.key,
            preset: named.preset
          }
        );
      }
      const mapping = current.find((item) => item.listen === requested2);
      if (!mapping || String(mapping.key) !== String(requested2) || mapping.preset !== true) {
        const occupiedByOtherKey = mapping && String(mapping.key) !== String(requested2);
        throw new DeployRuntimeError(
          occupiedByOtherKey ? `service ${entry.serviceName} \u7684\u9884\u7F6E\u76D1\u542C\u7AEF\u53E3 ${requested2} \u5DF2\u88AB key=${mapping.key} \u5360\u7528\uFF1B\u4E0D\u80FD\u63A5\u7BA1\u8BE5\u901A\u9053` : `service ${entry.serviceName} \u9700\u8981\u6C99\u7BB1\u9884\u7F6E\u901A\u9053 listen=${requested2}, key=${requested2}, preset=true\uFF1B\u5F53\u524D\u6620\u5C04\u7F3A\u5931\u6216\u4E0D\u662F\u9884\u7F6E\u901A\u9053`,
          occupiedByOtherKey ? "RUNTIME_KEY_CONFLICT" : "RUNTIME_PRESET_UNAVAILABLE",
          false,
          ports,
          3,
          {
            reason: occupiedByOtherKey ? "PORT_OCCUPIED" : "PRESET_UNAVAILABLE",
            serviceName: entry.serviceName,
            portName: entry.port.name,
            requestedPort: requested2,
            ...mapping ? { occupiedByKey: mapping.key, preset: mapping.preset } : {}
          }
        );
      }
      entry.port.connectPort = mapping.connect;
      ports.push({
        serviceName: entry.serviceName,
        portName: entry.port.name,
        port: requested2,
        inboundPort: mapping.connect,
        inboundBasePath: mapping.path,
        action: "reused"
      });
      continue;
    }
    const existing = current.find((m) => m.key === entry.serviceName);
    if (existing) {
      if (entry.port.port !== void 0 && entry.port.port !== existing.listen) {
        throw new DeployRuntimeError(
          `service ${entry.serviceName} \u5FC5\u987B\u4F7F\u7528 -k ${entry.serviceName}\uFF0C\u8BE5 key \u5DF2\u7ED1\u5B9A\u76D1\u542C\u7AEF\u53E3 ${existing.listen}\uFF0C\u4E0E Manifest ${entry.port.port} \u4E0D\u4E00\u81F4\uFF1B\u8BF7\u663E\u5F0F\u4FEE\u590D Manifest \u7AEF\u53E3\uFF0C\u4E0D\u8981\u66F4\u6539 key`,
          "RUNTIME_KEY_CONFLICT",
          false,
          ports,
          3,
          {
            reason: "KEY_PORT_MISMATCH",
            serviceName: entry.serviceName,
            portName: entry.port.name,
            requestedPort: entry.port.port,
            occupiedByKey: existing.key,
            preset: existing.preset
          }
        );
      }
      entry.port.port = existing.listen;
      entry.port.connectPort = existing.connect;
      ports.push({
        serviceName: entry.serviceName,
        portName: entry.port.name,
        port: existing.listen,
        inboundPort: existing.connect,
        inboundBasePath: existing.path,
        action: "reused"
      });
      continue;
    }
    let requested = entry.port.port;
    const occupied = requested === void 0 ? void 0 : current.find((m) => m.listen === requested);
    if (requested !== void 0 && isBuiltInPresetPort(requested) && (!occupied || isEligibleBuiltInPresetPort(entry.service, entry.port) && String(occupied.key) === String(requested) && occupied.preset !== true)) {
      throw new DeployRuntimeError(
        `service ${entry.serviceName} \u7684\u5185\u7F6E\u76D1\u542C\u7AEF\u53E3 ${requested} \u6CA1\u6709\u53EF\u6838\u5B9E\u7684\u6C99\u7BB1\u9884\u7F6E\u901A\u9053\uFF1B\u8BF7\u5148\u786E\u8BA4\u6C99\u7BB1\u6620\u5C04\u6216\u66F4\u6362\u7AEF\u53E3`,
        "RUNTIME_PRESET_UNAVAILABLE",
        false,
        ports,
        3,
        {
          reason: "PRESET_UNAVAILABLE",
          serviceName: entry.serviceName,
          portName: entry.port.name,
          requestedPort: requested,
          suggestedPort: nextAvailablePort(reserved)
        }
      );
    }
    if (requested !== void 0 && occupied) {
      throw new DeployRuntimeError(
        `service ${entry.serviceName} \u5FC5\u987B\u4F7F\u7528 -k ${entry.serviceName}\uFF0C\u76D1\u542C\u7AEF\u53E3 ${requested} \u5DF2\u88AB key=${occupied.key} \u5360\u7528\uFF1B\u8BF7${mode === "register" ? "\u7701\u7565 port \u7531\u5951\u7EA6\u5206\u914D\u6216\u66F4\u6362\u53EF\u7528\u7AEF\u53E3" : "\u663E\u5F0F\u4FEE\u590D Manifest \u7AEF\u53E3"}\uFF0C\u4E0D\u8981\u672A\u7ECF\u6838\u9A8C\u590D\u7528\u8BE5\u901A\u9053`,
        "RUNTIME_KEY_CONFLICT",
        false,
        ports,
        3,
        {
          reason: "PORT_OCCUPIED",
          serviceName: entry.serviceName,
          portName: entry.port.name,
          requestedPort: requested,
          occupiedByKey: occupied.key,
          preset: occupied.preset,
          suggestedPort: nextAvailablePort(reserved)
        }
      );
    }
    if (requested === void 0) {
      const next = nextAvailablePort(reserved);
      if (next === void 0) throw new DeployRuntimeError("\u6CA1\u6709\u53EF\u7533\u8BF7\u7684\u76D1\u542C\u7AEF\u53E3", "RUNTIME_EXHAUSTED", false, ports, 3);
      requested = next;
      reserved.add(requested);
    }
    pending.push({ entry, requested, assigned: entry.port.port !== void 0 });
  }
  const reusedValidated = validateDeployManifest(manifest);
  if (!reusedValidated.ok) {
    throw new DeployRuntimeError(reusedValidated.issues.map((i) => i.message).join("; "), "RUNTIME_PORT_CONFLICT", false, ports, 3);
  }
  if (preflight) {
    return { ports: entries.map((entry) => {
      const reused = ports.find((port) => port.serviceName === entry.serviceName);
      const available = pending.find((item) => item.entry === entry);
      return {
        serviceName: entry.serviceName,
        portName: entry.port.name,
        port: reused?.port ?? available.requested,
        action: reused ? "reused" : "available"
      };
    }) };
  }
  if (!pending.length) return { manifest, ports };
  let returned = [];
  try {
    returned = parseSandboxInboundMappings(JSON.stringify(await inbound.set(
      pending.map((p) => p.requested),
      pending.map((p) => p.entry.serviceName)
    )), "set");
    if (returned.length !== pending.length || new Set(returned.map((m) => m.listen)).size !== returned.length) {
      throw new Error("set \u8FD4\u56DE\u6570\u91CF\u4E0D\u4E00\u81F4\u6216\u76D1\u542C\u7AEF\u53E3\u91CD\u590D");
    }
    const completed = new Set(ports.map((p) => p.port));
    for (let i = 0; i < returned.length; i++) {
      const mapping = returned[i], item = pending[i];
      if (mapping.key !== item.entry.serviceName || item.assigned && mapping.listen !== item.requested || completed.has(mapping.listen) || mapping.listen !== item.requested && reserved.has(mapping.listen)) {
        throw new Error("set \u8FD4\u56DE\u7AEF\u53E3\u6F02\u79FB\u6216\u4E0E\u5176\u4ED6\u901A\u9053\u51B2\u7A81");
      }
      completed.add(mapping.listen);
      item.entry.port.port = mapping.listen;
      item.entry.port.connectPort = mapping.connect;
      ports.push({
        serviceName: item.entry.serviceName,
        portName: item.entry.port.name,
        port: mapping.listen,
        inboundPort: mapping.connect,
        inboundBasePath: mapping.path,
        action: "created"
      });
    }
    const validated = validateDeployManifest(manifest);
    if (!validated.ok) throw new Error(validated.issues.map((i) => i.message).join("; "));
    ports.sort(
      (a, b) => entries.findIndex((e) => e.serviceName === a.serviceName && e.port.name === a.portName) - entries.findIndex((e) => e.serviceName === b.serviceName && e.port.name === b.portName)
    );
    return { manifest, ports };
  } catch (error) {
    const known = error instanceof SandboxInboundValidationError || error instanceof SandboxInboundExternalError ? error.partialMappings : returned;
    for (const mapping of known) {
      if (typeof mapping.key !== "string" || known.filter((m) => m.key === mapping.key).length !== 1 || known.filter((m) => m.listen === mapping.listen).length !== 1) continue;
      const item = pending.find((p) => p.entry.serviceName === mapping.key);
      if (item && item.assigned && mapping.listen !== item.requested) continue;
      if (item && !item.assigned && mapping.listen !== item.requested && reserved.has(mapping.listen)) continue;
      if (item && ports.some((p) => p.port === mapping.listen)) continue;
      if (!item || ports.some((p) => p.serviceName === item.entry.serviceName && p.portName === item.entry.port.name))
        continue;
      item.entry.port.port = mapping.listen;
      item.entry.port.connectPort = mapping.connect;
      ports.push({
        serviceName: item.entry.serviceName,
        portName: item.entry.port.name,
        port: mapping.listen,
        inboundPort: mapping.connect,
        inboundBasePath: mapping.path,
        action: "created"
      });
    }
    throw new DeployRuntimeError(
      error instanceof Error ? error.message : String(error),
      "RUNTIME_SET_UNCERTAIN",
      true,
      ports
    );
  }
}
function nextAvailablePort(reserved) {
  let candidate = 6004;
  while (reserved.has(candidate) && candidate <= 65535) candidate++;
  return candidate <= 65535 ? candidate : void 0;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/script-defaults.ts
function applyDeployScriptDefaults(manifest) {
  const result = structuredClone(manifest);
  for (const service of result.services) {
    if (!service || typeof service !== "object" || Array.isArray(service)) continue;
    const record2 = service;
    const name = record2.serviceName;
    if (typeof name !== "string" || !name.trim()) continue;
    const root = `deploy/${name}/scripts`;
    if (record2.build === void 0) record2.build = { script: `${root}/build.sh` };
    else if (record2.build && typeof record2.build === "object" && !Array.isArray(record2.build)) {
      const build = record2.build;
      if (build.script === void 0) build.script = `${root}/build.sh`;
    }
    if (record2.runtime === void 0) {
      record2.runtime = {
        startScript: `${root}/start.sh`,
        healthCheck: { script: `${root}/health-check.sh` }
      };
      continue;
    }
    if (!record2.runtime || typeof record2.runtime !== "object" || Array.isArray(record2.runtime)) continue;
    const runtime = record2.runtime;
    if (runtime.startScript === void 0) runtime.startScript = `${root}/start.sh`;
    if (runtime.healthCheck === void 0) runtime.healthCheck = { script: `${root}/health-check.sh` };
    else if (runtime.healthCheck && typeof runtime.healthCheck === "object" && !Array.isArray(runtime.healthCheck)) {
      const check = runtime.healthCheck;
      if (check.script === void 0) check.script = `${root}/health-check.sh`;
    }
  }
  return result;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/image-build-defaults.ts
function withDefaultImageBuild(service) {
  if (service.imageBuild !== void 0 || typeof service.serviceName !== "string" || !service.serviceName.trim())
    return service;
  return {
    ...service,
    imageBuild: {
      dockerfile: `deploy/${service.deployName ?? service.serviceName}/dockerfile/Dockerfile`
    }
  };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/service-domains.ts
var DeployServiceDomainQueryError = class extends Error {
  exitCode = 1;
  code = "SERVICE_DOMAIN_QUERY_FAILED";
  constructor(message) {
    super(message);
    this.name = "DeployServiceDomainQueryError";
  }
};
async function getDeployServiceDomains(options = {}) {
  const cwd = options.cwd ?? process.cwd();
  const env = options.env ?? process.env;
  if (readDeployExternalConfig(env, cwd).mode === "real") readDeployPreviewContext(env);
  const runner = options.runPlatformTool ?? resolveDeployExternalDependencies(cwd, env).runPlatformTool;
  let result;
  try {
    result = await runner(cwd, ["get-service-domains"], env);
  } catch (error) {
    throw new DeployServiceDomainQueryError(errorMessage5(error));
  }
  if (result.code !== 0) {
    throw new DeployServiceDomainQueryError(result.stderr.trim() || result.stdout.trim() || `platform-tool exit ${result.code}`);
  }
  let payload;
  try {
    payload = JSON.parse(result.stdout);
  } catch (error) {
    throw new DeployServiceDomainQueryError(`platform-tool \u8FD4\u56DE\u975E JSON\uFF1A${errorMessage5(error)}`);
  }
  if (!isRecord3(payload) || !Array.isArray(payload.domains)) {
    throw new DeployServiceDomainQueryError("platform-tool \u8FD4\u56DE\u7ED3\u6784\u975E\u6CD5\uFF1A\u9700\u8981 domains \u6570\u7EC4");
  }
  try {
    return parseDeployServiceDomains(payload.domains);
  } catch (error) {
    throw new DeployServiceDomainQueryError(`platform-tool \u8FD4\u56DE\u670D\u52A1\u57DF\u540D\u6761\u76EE\u975E\u6CD5\uFF1A${errorMessage5(error)}`);
  }
}
function isRecord3(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function errorMessage5(error) {
  return error instanceof Error ? error.message : String(error);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/domain-reconciliation.ts
var endpointKey = (entry) => JSON.stringify([entry.type, entry.businessType, entry.basePath]);
var endpointLabel = (key) => {
  const [type, businessType, basePath] = JSON.parse(key);
  return `${type}/${businessType}:${basePath}`;
};
function expectedServices(manifest) {
  const expected = /* @__PURE__ */ new Map();
  for (const service of manifest.services) {
    for (const endpoint of service.endpoints ?? []) {
      if (endpoint.exposure !== "public") continue;
      const entries = expected.get(service.serviceName) ?? /* @__PURE__ */ new Set();
      entries.add(endpointKey({
        type: endpoint.type,
        businessType: endpoint.businessType ?? "application",
        basePath: endpoint.basePath
      }));
      expected.set(service.serviceName, entries);
    }
  }
  return expected;
}
function compareSnapshot(label, expected, actual) {
  const issues = [];
  const received = new Map(actual.map((service) => [service.serviceName, service]));
  const missingServices = [...expected.keys()].filter((name) => !received.has(name)).sort();
  const extraServices = [...received.keys()].filter((name) => !expected.has(name)).sort();
  if (missingServices.length) issues.push(`${label}\u7F3A\u5C11\u670D\u52A1\uFF1A${missingServices.join("\u3001")}`);
  if (extraServices.length) issues.push(`${label}\u591A\u4F59\u670D\u52A1\uFF1A${extraServices.join("\u3001")}`);
  for (const [serviceName, expectedEndpoints] of expected) {
    const service = received.get(serviceName);
    if (!service) continue;
    const actualEndpoints = service.endpoints.map(endpointKey);
    const actualSet = new Set(actualEndpoints);
    const duplicates = [...actualSet].filter((key) => actualEndpoints.filter((entry) => entry === key).length > 1).sort();
    const missing = [...expectedEndpoints].filter((key) => !actualSet.has(key)).sort();
    const extra = [...actualSet].filter((key) => !expectedEndpoints.has(key)).sort();
    if (missing.length) issues.push(`${label} ${serviceName} \u7F3A\u5C11\u5165\u53E3\uFF1A${missing.map(endpointLabel).join("\u3001")}`);
    if (extra.length) issues.push(`${label} ${serviceName} \u591A\u4F59\u5165\u53E3\uFF1A${extra.map(endpointLabel).join("\u3001")}`);
    if (duplicates.length) issues.push(`${label} ${serviceName} \u91CD\u590D\u5165\u53E3\uFF1A${duplicates.map(endpointLabel).join("\u3001")}`);
  }
  return issues;
}
function reconcileDeployServiceDomains(manifest, submitted, queried) {
  if (submitted === void 0) return { settled: false, detail: "LCAP \u6CE8\u518C\u54CD\u5E94\u7F3A\u5C11 domains \u6570\u7EC4", domains: [] };
  let submittedDomains;
  let queriedDomains;
  try {
    submittedDomains = parseDeployServiceDomains(submitted, "\u6CE8\u518C\u54CD\u5E94 domains");
    queriedDomains = parseDeployServiceDomains(queried, "\u56DE\u8BFB domains");
  } catch (error) {
    return { settled: false, detail: error instanceof Error ? error.message : String(error), domains: [] };
  }
  const expected = expectedServices(manifest);
  const issues = [
    ...compareSnapshot("\u6CE8\u518C\u54CD\u5E94", expected, submittedDomains),
    ...compareSnapshot("\u5E73\u53F0\u56DE\u8BFB", expected, queriedDomains)
  ];
  const readBack = new Map(queriedDomains.map((service) => [service.serviceName, service.domain]));
  for (const service of submittedDomains) {
    const actualDomain = readBack.get(service.serviceName);
    if (actualDomain !== void 0 && actualDomain !== service.domain)
      issues.push(`${service.serviceName} \u57DF\u540D\u4E0D\u4E00\u81F4\uFF1A\u6CE8\u518C\u54CD\u5E94 ${service.domain}\uFF0C\u5E73\u53F0\u56DE\u8BFB ${actualDomain}`);
  }
  return issues.length ? { settled: false, detail: issues.join("\uFF1B"), domains: [] } : { settled: true, detail: `\u5168\u90E8 ${expected.size} \u4E2A public \u670D\u52A1\u7684\u57DF\u540D\u53CA\u5165\u53E3\u5DF2\u843D\u5B9A`, domains: submittedDomains };
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/registration.ts
function prepareDeployRegistration(cwd, raw, baseline, mode = "analyzed") {
  const target = normalizeDeployTarget(raw, mode);
  const report = baseline === void 0 ? void 0 : validateDeployManifest(baseline);
  if (report && (!report.ok || !report.value))
    throw new DeployInputError("\u5206\u6790\u57FA\u7EBF\u4E0D\u662F\u5408\u6CD5 Manifest", "BASELINE_INVALID");
  const current = report?.value ?? readDeployManifest(cwd);
  for (const serviceName of target.deleteServiceNames ?? []) {
    if (!current.services.some((service) => service.serviceName === serviceName))
      throw new DeployInputError(`service \u4E0D\u5B58\u5728\uFF1A${serviceName}`, "SERVICE_NOT_FOUND");
  }
  const names = [...target.manifest.services.map((service) => service.serviceName), ...target.deleteServiceNames ?? []];
  const originals = Object.fromEntries(
    names.map((name) => [name, current.services.find((s) => s.serviceName === name) ?? null])
  );
  const questions = planDeployTarget(target, current, mode);
  const ask = buildDeployAsk(questions);
  return { target, mode, originals, questions, ...ask ? { ask } : {} };
}
function normalizeKnownManifest(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some((key) => !["manifest", "deleteServiceNames"].includes(key)) || !input.manifest || typeof input.manifest !== "object" || Array.isArray(input.manifest) || !Array.isArray(input.manifest.services)) {
    throw new DeployInputError("\u5DF2\u77E5 Manifest \u8F93\u5165\u5FC5\u987B\u5305\u542B services \u6570\u7EC4", "MANIFEST_INVALID");
  }
  const manifest = structuredClone(input.manifest);
  for (const [serviceIndex, service] of manifest.services.entries()) {
    if (!service || typeof service !== "object" || Array.isArray(service))
      throw new DeployInputError("\u670D\u52A1\u63CF\u8FF0\u5FC5\u987B\u662F\u5BF9\u8C61", "MANIFEST_INVALID");
    if (service.businessType !== void 0 && service.businessType !== "application" && service.businessType !== "prototype")
      throw new DeployInputError(
        `services[${serviceIndex}].businessType: businessType \u4EC5\u652F\u6301 application\u3001prototype`,
        "MANIFEST_INVALID"
      );
    const endpoints = Array.isArray(service.endpoints) ? service.endpoints : [];
    for (const [endpointIndex, endpoint] of endpoints.entries()) {
      if (endpoint && typeof endpoint === "object" && !Array.isArray(endpoint) && endpoint.businessType !== void 0 && endpoint.businessType !== "application" && endpoint.businessType !== "prototype")
        throw new DeployInputError(
          `services[${serviceIndex}].endpoints[${endpointIndex}].businessType: businessType \u4EC5\u652F\u6301 application\u3001prototype`,
          "MANIFEST_INVALID"
        );
      if (endpoint && typeof endpoint === "object" && !Array.isArray(endpoint) && endpoint.type === "api" && endpoint.businessType === "prototype")
        throw new DeployInputError(
          `services[${serviceIndex}].endpoints[${endpointIndex}].businessType: API \u5165\u53E3\u7684 businessType \u5FC5\u987B\u662F application`,
          "MANIFEST_INVALID"
        );
    }
    const prototypeOnly = endpoints.length > 0 && endpoints.every(
      (endpoint) => endpoint && typeof endpoint === "object" && !Array.isArray(endpoint) && (endpoint.type === "pc" || endpoint.type === "h5") && (endpoint.businessType ?? service.businessType ?? "application") === "prototype"
    );
    const runtime = service.runtime;
    if (runtime === void 0) continue;
    if (!runtime || typeof runtime !== "object" || Array.isArray(runtime))
      throw new DeployInputError("runtime \u5FC5\u987B\u662F\u5BF9\u8C61", "MANIFEST_INVALID");
    const runtimeRecord = runtime;
    if (!Array.isArray(runtimeRecord.ports)) continue;
    const ports = runtimeRecord.ports;
    const missingProtocol = ports.some(
      (port) => port && typeof port === "object" && !Array.isArray(port) && port.protocol === void 0
    );
    if (missingProtocol && !prototypeOnly)
      throw new DeployInputError("\u975E\u539F\u578B\u670D\u52A1\u7684 runtime.ports \u5FC5\u987B\u663E\u5F0F\u586B\u5199 protocol", "PROTOCOL_REQUIRED");
    if (prototypeOnly) {
      runtimeRecord.ports = ports.map((port) => {
        if (!port || typeof port !== "object" || Array.isArray(port)) return port;
        return { ...port, protocol: port.protocol ?? "http" };
      });
    }
  }
  const withScripts = applyDeployScriptDefaults(manifest);
  return normalizeDeployTarget({ manifest: { services: withScripts.services.map(withDefaultImageBuild) } }, "known").manifest;
}
async function verifyPreviewSettled(cwd, manifest, submitted, options = {}) {
  let domains;
  try {
    domains = options.queryPreviewDomains ? await options.queryPreviewDomains(cwd) : await getDeployServiceDomains({ cwd, env: options.env ?? process.env });
  } catch (error) {
    return {
      settled: false,
      detail: `\u670D\u52A1\u57DF\u540D\u67E5\u8BE2\u5931\u8D25\uFF1A${error instanceof Error ? error.message : String(error)}`,
      queryFailure: { error }
    };
  }
  const { settled, detail } = reconcileDeployServiceDomains(manifest, submitted, domains);
  return { settled, detail };
}
async function syncPreviewWithVerify(cwd, manifest, ports, context, options, allowEmptyTarget) {
  const attempt = async () => {
    const domains = await syncPreviewToLcap(
      buildPreviewSyncRequest(manifest, ports, context, { allowEmptyTarget }),
      options.submitPreview
    );
    return { ...await verifyPreviewSettled(cwd, manifest, domains, options), domains };
  };
  const first = await attempt();
  if (first.settled) return first.domains;
  const second = await attempt();
  if (second.settled) return second.domains;
  if (second.queryFailure) throw second.queryFailure.error;
  throw new Error(`\u9884\u89C8\u6CE8\u518C\u672A\u843D\u5B9A\uFF08\u5DF2\u91CD\u89E6\u53D1 1 \u6B21\uFF09\uFF1A${second.detail}`);
}
function deploymentFailure(error, stage, ports = [], previewStatus = "not-required", uncertain = false, manifestState = "unchanged", manifest) {
  const detail = error;
  return {
    ok: false,
    status: "failed",
    stage,
    ports,
    previewStatus,
    uncertain,
    manifestState,
    ...manifest ? { manifest } : {},
    error: {
      code: detail?.code ?? "DEPLOY_FAILED",
      message: detail?.message ?? String(error),
      ...error instanceof DeployRuntimeError && error.details ? { details: error.details } : {}
    }
  };
}
async function commitDeployRegistrationUsingMutation(cwd, prepared, answer, options = {}, mutate = (work) => withDeployMutation(cwd, work)) {
  let stage = "prepare", ports = [];
  let savedManifest;
  try {
    const mode = prepared?.mode;
    const target = normalizeDeployTarget(prepared?.target, mode);
    if (!prepared.originals || typeof prepared.originals !== "object" || Array.isArray(prepared.originals))
      throw new DeployInputError("\u51C6\u5907\u5FEB\u7167\u7F3A\u5931");
    const names = [...target.manifest.services.map((service) => service.serviceName), ...target.deleteServiceNames ?? []];
    if (Object.keys(prepared.originals).length !== names.length || names.some((n) => !Object.hasOwn(prepared.originals, n)))
      throw new DeployInputError("\u51C6\u5907\u5FEB\u7167\u8303\u56F4\u4E0D\u4E00\u81F4");
    for (const name of names) {
      const original = prepared.originals[name];
      if (original !== null && (!validateDeployService(original).ok || original.serviceName !== name))
        throw new DeployInputError("\u51C6\u5907\u5FEB\u7167\u6761\u76EE\u975E\u6CD5");
    }
    const snapshot = { services: Object.values(prepared.originals).filter((service) => service !== null) };
    const questions = planDeployTarget(target, snapshot, mode);
    if (!isDeepStrictEqual(prepared.questions, questions))
      throw new DeployInputError("\u51C6\u5907\u95EE\u8BE2\u4E0E\u76EE\u6807\u4E0D\u4E00\u81F4");
    const values = resolveDeployAnswer({ questions, ask: prepared.ask }, answer);
    if (values === null)
      return {
        ok: true,
        status: "cancelled",
        stage: "ask",
        ports: [],
        previewStatus: "not-required",
        uncertain: false,
        manifestState: "unchanged"
      };
    const changes = applyDeployTargetAnswers(target, prepared.originals, questions, values);
    const external = resolveDeployExternalDependencies(cwd, options.env ?? process.env);
    const execution = { ...options, inbound: options.inbound ?? external.inbound };
    stage = "lock";
    return await mutate(async () => {
      stage = "preflight";
      const current = readDeployManifest(cwd);
      for (const name of names) {
        if (!isDeepStrictEqual(prepared.originals[name], current.services.find((s) => s.serviceName === name) ?? null)) {
          throw new DeployInputError("\u786E\u8BA4\u671F\u95F4\u670D\u52A1\u5DF2\u53D8\u5316\uFF0C\u8BF7\u91CD\u65B0\u51C6\u5907\uFF1A" + name, "PREPARED_STALE");
        }
      }
      const services = current.services.filter((s) => !changes.deleteServiceNames.includes(s.serviceName));
      for (const supplied of changes.upserts) {
        const entry = withDefaultImageBuild(supplied);
        const index = services.findIndex((s) => s.serviceName === entry.serviceName);
        if (index < 0) services.push(entry);
        else services[index] = preserveAssignedPorts(services[index], entry);
      }
      const report = validateDeployManifest(applyDeployRuntimePolicy(applyDeployScriptDefaults({ services })));
      if (!report.ok || !report.value)
        throw new DeployInputError(report.issues.map((i) => i.path + ": " + i.message).join("; "));
      const requiresPreview = hasPublicEndpoints(report.value);
      const previewSyncRequired = requiresPreview || current.services.length > 0;
      const allowEmptyTarget = !requiresPreview;
      if (previewSyncRequired) {
        const support = checkPreviewSupport(report.value, { allowEmptyTarget });
        if (!support.ok)
          return deploymentFailure(
            new DeployInputError(support.issues.map((i) => i.message).join("; "), "PREVIEW_UNSUPPORTED"),
            stage,
            [],
            "unsupported"
          );
      }
      const context = previewSyncRequired ? readDeployPreviewContextForMode(cwd, options.env ?? process.env) : void 0;
      stage = "ports";
      const registered = await ensureDeployPorts(report.value, "register", execution);
      ports = registered.ports;
      const registeredManifest = applyDeployRuntimePolicy(registered.manifest);
      stage = "save";
      (options.writeManifest ?? writeDeployManifest)(cwd, registeredManifest);
      savedManifest = registeredManifest;
      let domains;
      if (context) {
        stage = "preview";
        domains = await syncPreviewWithVerify(
          cwd,
          registeredManifest,
          ports,
          context,
          { ...execution, submitPreview: options.submitPreview ?? external.submitPreview },
          allowEmptyTarget
        );
      }
      return {
        ok: true,
        status: "registered",
        stage: "complete",
        ports,
        previewStatus: context ? "synced" : "not-required",
        uncertain: false,
        manifestState: "saved",
        manifest: savedManifest,
        ...Array.isArray(domains) ? { domains } : {}
      };
    });
  } catch (error) {
    if (error instanceof DeployRuntimeError)
      return deploymentFailure(error, stage, error.ports, "not-required", error.uncertain);
    const code = stage === "save" ? "WRITE_FAILED" : void 0;
    return deploymentFailure(
      code ? { code, message: error instanceof Error ? error.message : String(error) } : error,
      stage,
      ports,
      stage === "preview" ? "failed" : "not-required",
      stage === "save" || stage === "preview",
      savedManifest ? "saved" : stage === "save" ? "unknown" : "unchanged",
      savedManifest
    );
  }
}
function commitDeployRegistration(cwd, prepared, answer, options = {}) {
  return commitDeployRegistrationUsingMutation(cwd, prepared, answer, options);
}
async function registerKnownManifest(input, options = {}) {
  const cwd = options.cwd ?? process.cwd();
  try {
    const manifest = normalizeKnownManifest(input);
    const current = readDeployManifest(cwd);
    const prepared = prepareDeployRegistration(
      cwd,
      { manifest, deleteServiceNames: input.deleteServiceNames ?? [] },
      current,
      "known"
    );
    return await commitDeployRegistration(cwd, prepared, void 0, options);
  } catch (error) {
    return deploymentFailure(error, "prepare");
  }
}
async function restoreDeployPreviewUsingMutation(cwd, options = {}, mutate = (work) => withDeployMutation(cwd, work)) {
  let stage = "read", ports = [];
  let persistedManifest, manifestState = "unchanged";
  try {
    const initialManifest = readDeployManifest(cwd);
    if (!initialManifest.services.length && !deployManifestExists(cwd))
      return {
        ok: true,
        status: "restored",
        stage: "complete",
        ports: [],
        previewStatus: "not-required",
        uncertain: false,
        manifestState: "unchanged"
      };
    const external = resolveDeployExternalDependencies(cwd, options.env ?? process.env);
    const execution = { ...options, inbound: options.inbound ?? external.inbound };
    stage = "lock";
    return await mutate(async () => {
      stage = "read";
      const manifest = readDeployManifest(cwd);
      persistedManifest = manifest;
      const hasEndpoints = hasPublicEndpoints(manifest);
      let context;
      stage = "preflight";
      const support = checkPreviewSupport(manifest, { allowEmptyTarget: !hasEndpoints });
      if (!support.ok)
        return deploymentFailure(
          new DeployInputError(support.issues.map((i) => i.message).join("; "), "PREVIEW_UNSUPPORTED"),
          stage,
          [],
          "unsupported"
        );
      context = readDeployPreviewContextForMode(cwd, options.env ?? process.env);
      stage = "ports";
      const restored = await ensureDeployPorts(manifest, "restore", execution);
      ports = restored.ports;
      const restoredManifest = applyDeployRuntimePolicy(restored.manifest);
      if (!isDeepStrictEqual(manifest, restoredManifest)) {
        stage = "save";
        (options.writeManifest ?? writeDeployManifest)(cwd, restoredManifest);
        persistedManifest = restoredManifest;
        manifestState = "saved";
      }
      let domains;
      if (context) {
        stage = "preview";
        domains = await syncPreviewWithVerify(
          cwd,
          restoredManifest,
          ports,
          context,
          { ...execution, submitPreview: options.submitPreview ?? external.submitPreview },
          !hasPublicEndpoints(restoredManifest)
        );
      }
      return {
        ok: true,
        status: "restored",
        stage: "complete",
        ports,
        previewStatus: context ? "synced" : "not-required",
        uncertain: false,
        manifestState,
        manifest: restoredManifest,
        ...Array.isArray(domains) ? { domains } : {}
      };
    });
  } catch (error) {
    const currentManifestState = manifestState;
    const failureManifestState = stage === "save" && currentManifestState !== "saved" ? "unknown" : currentManifestState;
    return deploymentFailure(
      error,
      stage,
      error instanceof DeployRuntimeError ? error.ports : ports,
      stage === "preview" ? "failed" : "not-required",
      error instanceof DeployRuntimeError ? error.uncertain : stage === "save" || stage === "preview",
      failureManifestState,
      failureManifestState === "unknown" ? void 0 : persistedManifest
    );
  }
}
function restoreDeployPreview(cwd, options = {}) {
  return restoreDeployPreviewUsingMutation(cwd, options);
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/port-repair.ts
async function repairDeployPort(input, options = {}) {
  if (!input.serviceName?.trim() || !input.portName?.trim() || !validPort2(input.expectedOldPort) || input.targetPort !== void 0 && !validPort2(input.targetPort)) {
    throw new DeployRuntimeError(
      "\u4FEE\u590D\u53C2\u6570\u65E0\u6548\uFF1A\u9700\u8981 serviceName\u3001portName\u3001expectedOldPort \u53CA\u53EF\u9009\u6709\u6548 targetPort",
      "RUNTIME_REPAIR_INVALID",
      false,
      [],
      3
    );
  }
  return withDeployMutation(input.cwd, async () => {
    const manifest = readDeployManifest(input.cwd);
    const service = manifest.services.find((item) => item.serviceName === input.serviceName);
    const port = service?.runtime?.ports?.find((item) => item.name === input.portName);
    if (!port || port.protocol !== "http" || port.port !== input.expectedOldPort) {
      throw new DeployRuntimeError(
        `\u670D\u52A1 ${input.serviceName}/${input.portName} \u7684\u5DF2\u4FDD\u5B58 HTTP \u76D1\u542C\u503C\u4E0E\u9884\u671F\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6 Manifest`,
        "RUNTIME_REPAIR_STALE",
        false,
        [],
        3
      );
    }
    if (port.inboundKeyMode === "preset-port") {
      throw new DeployRuntimeError(
        `\u670D\u52A1 ${input.serviceName}/${input.portName} \u4F7F\u7528\u6C99\u7BB1\u9884\u7F6E\u7AEF\u53E3\uFF1B\u4E0D\u80FD\u76F4\u63A5\u4FEE\u590D\u76D1\u542C\u503C\uFF0C\u8BF7\u901A\u8FC7\u670D\u52A1\u767B\u8BB0\u5165\u53E3\u53D8\u66F4\u7AEF\u53E3\u4E0E\u5165\u7AD9\u6A21\u5F0F`,
        "RUNTIME_REPAIR_PRESET_PORT",
        false,
        [],
        3
      );
    }
    const external = resolveDeployExternalDependencies(input.cwd, options.env ?? process.env);
    const inbound = options.inbound ?? external.inbound;
    let current;
    try {
      current = parseSandboxInboundMappings(JSON.stringify(await inbound.list()), "list");
      if (new Set(current.map((item) => item.listen)).size !== current.length || current.filter((item) => item.key === input.serviceName).length > 1) {
        throw new Error("list \u8FD4\u56DE\u91CD\u590D\u76D1\u542C\u7AEF\u53E3\u6216\u670D\u52A1 key\uFF0C\u65E0\u6CD5\u786E\u5B9A\u901A\u9053\u5F52\u5C5E");
      }
    } catch (error) {
      throw new DeployRuntimeError(error instanceof Error ? error.message : String(error), "RUNTIME_LIST_FAILED", false);
    }
    const oldOwner = current.find((item) => item.listen === input.expectedOldPort);
    if (!oldOwner || oldOwner.key === input.serviceName) {
      throw new DeployRuntimeError(
        `\u76D1\u542C\u7AEF\u53E3 ${input.expectedOldPort} \u672A\u88AB\u5176\u4ED6 key \u5360\u7528\uFF0C\u65E0\u9700\u6267\u884C\u51B2\u7A81\u4FEE\u590D`,
        "RUNTIME_REPAIR_NOT_REQUIRED",
        false,
        [],
        3
      );
    }
    const existing = current.find((item) => item.key === input.serviceName);
    if (existing && existing.listen !== input.targetPort) {
      throw new DeployRuntimeError(
        `\u670D\u52A1 ${input.serviceName} \u7684 key \u5DF2\u7ED1\u5B9A ${existing.listen}\uFF0C\u8BF7\u5148\u6838\u5BF9\u5916\u90E8\u6620\u5C04\uFF1B\u4E0D\u80FD\u53E6\u5EFA\u540C\u540D key`,
        "RUNTIME_KEY_CONFLICT",
        false,
        [],
        3,
        {
          reason: "KEY_PORT_MISMATCH",
          serviceName: input.serviceName,
          portName: input.portName,
          requestedPort: input.expectedOldPort,
          occupiedByKey: input.serviceName,
          preset: existing.preset
        }
      );
    }
    const reserved = /* @__PURE__ */ new Set([
      ...current.map((item) => item.listen),
      ...manifest.services.flatMap((item) => item.runtime?.ports?.flatMap((named) => named.port === void 0 ? [] : [named.port]) ?? [])
    ]);
    const target = input.targetPort ?? existing?.listen ?? firstFreePort(reserved);
    if (target === void 0 || isBuiltInPresetPort(target) && existing?.listen !== target || target === input.expectedOldPort || !existing && reserved.has(target) || manifest.services.some((item) => item.runtime?.ports?.some((named) => named.port === target && !(item.serviceName === input.serviceName && named.name === input.portName)))) {
      throw new DeployRuntimeError(
        `\u76EE\u6807\u76D1\u542C\u7AEF\u53E3 ${target ?? "(\u65E0\u53EF\u7528\u503C)"} \u4E0D\u53EF\u7528\uFF0C\u8BF7\u9009\u62E9\u672A\u5360\u7528\u7AEF\u53E3`,
        "RUNTIME_REPAIR_TARGET_OCCUPIED",
        false,
        [],
        3
      );
    }
    let confirmed = existing;
    if (!confirmed) {
      try {
        const returned = parseSandboxInboundMappings(JSON.stringify(await inbound.set([target], [input.serviceName])), "set");
        if (returned.length !== 1 || returned[0].key !== input.serviceName || returned[0].listen !== target) {
          throw new Error("set \u672A\u786E\u8BA4\u76EE\u6807\u7AEF\u53E3\u4EE5 serviceName \u767B\u8BB0");
        }
        confirmed = returned[0];
      } catch (error) {
        throw new DeployRuntimeError(error instanceof Error ? error.message : String(error), "RUNTIME_SET_UNCERTAIN", true);
      }
    }
    port.port = target;
    port.connectPort = confirmed.connect;
    if (service.runtime?.container?.port === input.expectedOldPort) service.runtime.container.port = target;
    try {
      (options.writeManifest ?? writeDeployManifest)(input.cwd, manifest);
    } catch (error) {
      throw new DeployRuntimeError(
        `\u901A\u9053\u5DF2\u6309 -k ${input.serviceName} \u786E\u8BA4\uFF0C\u4F46 Manifest \u4FDD\u5B58\u5931\u8D25\uFF1A${error instanceof Error ? error.message : String(error)}`,
        "RUNTIME_REPAIR_SAVE_UNCERTAIN",
        true
      );
    }
    return {
      ok: true,
      serviceName: input.serviceName,
      portName: input.portName,
      oldPort: input.expectedOldPort,
      port: target,
      connectPort: confirmed.connect,
      applicationSyncRequired: true
    };
  });
}
function validPort2(value) {
  return Number.isInteger(value) && value >= 1 && value <= 65535;
}
function firstFreePort(reserved) {
  for (let port = 6004; port <= 65535; port++) if (!reserved.has(port) && !isBuiltInPresetPort(port)) return port;
  return void 0;
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/commands.ts
var logger = createLogger("deploy");
var EXIT = { OK: 0, FAILURE: 1, USAGE: 2, INVALID: 3, NOT_FOUND: 4, WRITE_FAILED: 5 };
var InvalidArgumentError = class extends Error {
  exitCode = EXIT.USAGE;
  code = "INVALID_ARGUMENT";
};
var SUBCOMMAND_SPECS = {
  help: { flags: [], usage: "help [manifest|<command>]", detail: "\u67E5\u770B\u603B\u5E2E\u52A9\u6216\u547D\u4EE4\u53C2\u6570\uFF0C\u4E0D\u8BFB\u53D6\u9879\u76EE\u6587\u4EF6\u3002" },
  get: {
    flags: ["--service-name"],
    usage: "get [--service-name <name>]",
    detail: "\u8BFB\u53D6\u5B8C\u6574 Manifest \u6216\u4E00\u4E2A\u670D\u52A1\uFF1B\u6587\u4EF6\u4E0D\u5B58\u5728\u8FD4\u56DE\u7A7A\u670D\u52A1\u96C6\u5408\u3002"
  },
  validate: {
    flags: ["--entry", "--require-runtime", "--for-codegen"],
    usage: "validate [--entry <service-json>] [--require-runtime] [--for-codegen]",
    detail: "\u53EA\u8BFB\u6821\u9A8C\uFF1B--for-codegen \u68C0\u67E5\u5B8C\u6574 Manifest \u7684\u751F\u7801\u524D\u4E8B\u5B9E\uFF0C\u4E0D\u80FD\u4E0E --entry \u540C\u7528\uFF1B--require-runtime \u8981\u6C42\u5165\u53E3\u5F15\u7528\u7684\u547D\u540D\u7AEF\u53E3\u5DF2\u6709\u76D1\u542C\u503C\u3002"
  },
  "check-ports": {
    flags: ["--input"],
    usage: "check-ports [--input <manifest-json>]",
    detail: "\u53EA\u8BFB\u68C0\u67E5\u5019\u9009\u5B8C\u6574 Manifest \u7684 HTTP \u76D1\u542C\u7AEF\u53E3\u4E0E Sandbox key \u5F52\u5C5E\uFF1B\u7701\u7565 input \u65F6\u8BFB\u53D6\u5DF2\u4FDD\u5B58 Manifest\u3002\u8FD4\u56DE\u5F53\u524D\u53EF\u7528\u7AEF\u53E3\u5FEB\u7167\uFF0C\u4E0D\u7533\u8BF7\u3001\u4E0D\u9884\u7559\u3001\u4E0D\u843D\u76D8\uFF1B\u63D0\u4EA4\u65F6\u4ECD\u4F1A\u590D\u6838\u3002"
  },
  "repair-port": {
    flags: ["--service-name", "--port-name", "--expected-old-port", "--target-port"],
    usage: "repair-port --service-name <name> --port-name <name> --expected-old-port <port> [--target-port <port>]",
    detail: "\u4EC5\u7528\u4E8E\u666E\u901A\u6A21\u5F0F\u5DF2\u4FDD\u5B58 HTTP \u7AEF\u53E3\u88AB\u5176\u4ED6 key \u5360\u7528\u7684\u663E\u5F0F\u4FEE\u590D\uFF1B\u9884\u7F6E\u6A21\u5F0F\u987B\u901A\u8FC7\u5B8C\u6574\u670D\u52A1\u767B\u8BB0\u8C03\u6574\u3002\u6210\u529F\u540E\u8C03\u7528\u65B9\u4ECD\u9700\u540C\u6B65\u5E94\u7528\u914D\u7F6E/\u811A\u672C\u5E76\u9A8C\u8BC1\u9884\u89C8\u3002"
  },
  upsert: {
    flags: ["--entry"],
    usage: "upsert --entry <service-json>",
    detail: '\u6309 serviceName \u540C\u540D service \u6574\u6761\u66FF\u6362\uFF1B\u5148 get \u5E76\u5408\u5E76\u9700\u4FDD\u7559\u5B57\u6BB5\u3002\u5DF2\u6709\u540C\u540D\u7AEF\u53E3\u4FDD\u7559\u539F\u6570\u503C\uFF1B\u4E0D\u8C03\u7528 Sandbox/LCAP\u3002\u6210\u529F stdout\uFF1A{"ok":true}'
  },
  "update-service-facts": {
    flags: ["--service-name", "--facts"],
    usage: "update-service-facts --service-name <name> --facts <json-object>",
    detail: '\u6309 serviceName \u53D7\u63A7\u56DE\u586B\u670D\u52A1\u4E8B\u5B9E\uFF1B\u652F\u6301 facts.runtime.configFiles \u589E\u6539\u548C removeConfigFileNames \u5220\u9664\uFF08configFiles \u6BCF\u9879\u5FC5\u586B name/templatePath/path/containerPath\uFF09\u3002\u6210\u529F stdout\uFF1A{"ok":true,"manifest":{...}}\u3002'
  },
  delete: {
    flags: ["--service-name"],
    usage: "delete --service-name <name>",
    detail: "\u53EA\u5220\u9664\u660E\u786E\u6307\u5B9A\u7684\u670D\u52A1\u63CF\u8FF0\uFF0C\u4E0D\u5904\u7406\u5916\u90E8\u8D44\u6E90\u3002\u5165\u53E3\u53D8\u66F4\u5E94\u4F7F\u7528\u767B\u8BB0\u95ED\u73AF\u3002"
  },
  "register-known": {
    flags: ["--input"],
    usage: "register-known --input <target-json>",
    detail: "\u6309\u5B8C\u6574 service \u76EE\u6807\u76F4\u63A5\u767B\u8BB0\uFF1B\u672A\u63D0\u4F9B\u7684 service \u4FDD\u6301\u4E0D\u53D8\uFF0CdeleteServiceNames \u663E\u5F0F\u5220\u9664\u6574\u670D\u52A1\uFF1B\u4E0D\u95EE\u8BE2\u3002"
  },
  "register-prepare": {
    flags: ["--input", "--baseline"],
    usage: "register-prepare --input <target-json> --baseline <get-manifest-json>",
    detail: "\u53EA\u8BFB\u51C6\u5907\u53D7\u5F71\u54CD\u670D\u52A1\u7684\u5B8C\u6574\u76EE\u6807\u3002baseline \u5FC5\u987B\u4E3A\u5206\u6790\u5F00\u59CB\u524D get \u7684\u5B8C\u6574 Manifest \u539F\u8F93\u51FA\uFF0C\u4E0D\u80FD\u5206\u6790\u540E\u91CD\u53D6\uFF1B\u76F8\u5173\u4E8B\u5B9E\u53D8\u5316\u5728 commit \u65F6\u62D2\u7EDD\u3002\u8FD4\u56DE {target,originals,questions,ask?}\uFF1B\u4E0D\u843D\u76D8\u3001\u4E0D\u7533\u8BF7\u7AEF\u53E3\u3002"
  },
  "register-commit": {
    flags: ["--prepared", "--answer"],
    usage: "register-commit --prepared <prepared-json> [--answer <raw-json>]",
    detail: "\u539F\u6837\u56DE\u4F20 prepare \u8F93\u51FA\u548C\u95EE\u8BE2\u7B54\u6848\uFF1B\u6709 ask \u65F6\u7B54\u6848\u6309 question \u2192 JSON\u5B57\u7B26\u4E32 \u2192 values[key]\u3002{} \u53D6\u6D88\uFF0C\u975E\u6CD5\u7B54\u6848\u4E0D\u80FD\u9ED8\u8BA4\u540C\u610F\u3002\u63D0\u4EA4\u9501\u5185\u590D\u9A8C\u2192\u767B\u8BB0\u7AEF\u53E3\u2192\u539F\u5B50\u4FDD\u5B58\u2192\u5B8C\u6574\u9884\u89C8\u540C\u6B65\uFF1B\u7ED3\u679C\u5305\u542B stage/ports/previewStatus/uncertain/manifestState\uFF0Csaved \u65F6\u8FD4\u56DE\u5B9E\u9645 manifest\u3002"
  },
  "runtime-sync": {
    flags: [],
    usage: "runtime-sync",
    detail: "\u751F\u547D\u5468\u671F\u6062\u590D\uFF1A\u6309 serviceName \u6062\u590D\u5404\u670D\u52A1\u552F\u4E00 HTTP \u7AEF\u53E3\u7684\u5165\u7AD9\u6620\u5C04\uFF0C\u56DE\u586B\u5176 connectPort \u5E76\u539F\u5B50\u4FDD\u5B58\uFF1B\u975E HTTP \u7AEF\u53E3\u4E0D\u767B\u8BB0\u3002\u6309\u5B8C\u6574 Manifest \u540C\u6B65 public \u76EE\u6807\u6216\u7A7A\u76EE\u6807\u6E05\u7406\u3002\u4E0D\u5206\u6790\u9879\u76EE\u3001\u4E0D\u95EE\u7528\u6237\u3001\u4E0D\u542F\u52A8\u8FDB\u7A0B\u3001\u4E0D\u9996\u6B21\u5206\u914D\u3002\u65E0 Manifest \u4E3A\u7A7A\u64CD\u4F5C\uFF1B\u5DF2\u5B58\u5728\u7684\u663E\u5F0F\u7A7A Manifest \u4F1A\u540C\u6B65\u7A7A\u76EE\u6807\u3002"
  }
};
var MANIFEST_HELP = `Manifest \u6587\u4EF6\uFF1A.manifest/deploy.json
\u9996\u6B21\u751F\u6210\uFF1Aget \u8FD4\u56DE {"services":[]}\u3002
\u5B8C\u6574\u8BFB\u53D6\uFF1Aget \u4E0D\u5E26 --service-name \u8FD4\u56DE\u5168\u90E8\u670D\u52A1\uFF1BTypeScript \u4ECE index.ts \u8C03 getDeployManifest({cwd})\uFF0C\u7F3A\u5931\u6587\u4EF6\u8FD4\u56DE\u7A7A services\uFF0C\u635F\u574F\u6587\u4EF6\u62A5\u9519\u3002
\u6839\u7ED3\u6784\uFF1Aservices[]\u3002
serviceName\uFF1A\u7A33\u5B9A\u903B\u8F91\u670D\u52A1\u540D\uFF1B\u53EA\u5141\u8BB8\u82F1\u6587\u5B57\u6BCD\uFF08\u53EF\u5927\u5199\uFF09\u3001\u6570\u5B57\u53CA\u4E2D\u95F4\u7684\u4E0B\u5212\u7EBF\u3001\u70B9\u3001\u8FDE\u5B57\u7B26\uFF0C\u9996\u5C3E\u4E3A\u5B57\u6BCD\u6216\u6570\u5B57\uFF0C\u6700\u957F63\u4F4D\uFF0C\u9879\u76EE\u5185\u5FFD\u7565\u5927\u5C0F\u5199\u552F\u4E00\uFF1B\u5BFC\u5165\u6E90\u7801\u65F6\u4FDD\u7559\u76EE\u5F55\u672B\u6BB5\u539F\u540D\u3002serviceTitle\uFF1A\u5FC5\u586B\u3001\u7531\u4E0A\u6E38\u6280\u672F\u8BBE\u8BA1/\u67B6\u6784\u5206\u6790\u63D0\u4F9B\u7684\u670D\u52A1\u8BED\u4E49\u6807\u9898\uFF0C\u4E0D\u4F5C\u4E3A\u4E3B\u952E\uFF0C\u5951\u7EA6\u4E0D\u4ECE serviceName \u63A8\u5BFC\u3002
serviceType\uFF1A\u5FC5\u586B frontend|backend|bff\uFF1B\u4E0D\u4ECE\u811A\u672C\u3001\u76EE\u5F55\u6216\u67B6\u6784\u6587\u4EF6\u63A8\u65AD\u3002
techStack\uFF1A\u6280\u672F\u8BBE\u8BA1\u786E\u8BA4\u7684\u5B8C\u6574\u9009\u578B\u5BF9\u8C61\uFF0C\u542B\u5FC5\u586B language/framework/buildTool\uFF0C\u4EE5\u53CA\u6309\u6280\u672F\u6808\u586B\u5199\u7684 languageVersion/frameworkVersion/packageManager/packaging\uFF1B\u539F\u578B\u767B\u8BB0\u53EF\u6682\u7F3A\uFF0C\u751F\u7801\u524D\u5FC5\u987B\u8865\u9F50\u3002
businessType\uFF1A\u670D\u52A1\u4E1A\u52A1\u7528\u9014 application|prototype\uFF1B\u7701\u7565\u5F52\u4E00\u5316\u4E3A application\uFF0C\u539F\u578B\u670D\u52A1\u663E\u5F0F\u586B\u5199 prototype\uFF0C\u4E0D\u4ECE\u5165\u53E3\u53CD\u63A8\u3002
description\uFF1A\u53EF\u9009\uFF0C\u975E\u7A7A\u670D\u52A1\u804C\u8D23\u63CF\u8FF0\u3002
sourceDir\uFF1A\u9879\u76EE\u6839\u76F8\u5BF9\u8DEF\u5F84\uFF0C. \u4E0E ./ \u5747\u5408\u6CD5\uFF1B\u539F\u578B\u767B\u8BB0\u53EF\u6682\u7F3A\uFF0C\u751F\u7801\u524D\u5FC5\u987B\u8865\u9F50\u3002
apiBasePath\uFF1A\u670D\u52A1 API \u524D\u7F00\uFF0C\u4E0E\u662F\u5426\u5916\u90E8\u5F00\u653E\u72EC\u7ACB\uFF1B\u65B0\u751F\u6210\u9ED8\u8BA4 /api/{serviceName}/\uFF0C\u5BFC\u5165\u6CBF\u7528\u786E\u8BA4\u8DEF\u5F84\uFF0C\u751F\u7801\u4E0E\u8F6C\u53D1\u4FDD\u7559\u5B8C\u6574\u524D\u7F00\u3002
build.script\uFF1A\u9879\u76EE\u6839\u76F8\u5BF9\u7684\u6784\u5EFA\u811A\u672C\uFF1B\u4E1A\u52A1\u767B\u8BB0\u7701\u7565\u65F6\u8865\u4E3A deploy/{serviceName}/scripts/build.sh\uFF1Bbuild.outputs[]\uFF1A{path,static?,entryFile?}\u3002
imageBuild\uFF1A{dockerfile,contextDir?}\uFF0C\u8DEF\u5F84\u5747\u76F8\u5BF9\u9879\u76EE\u6839\uFF1B\u4E1A\u52A1\u767B\u8BB0\u7701\u7565\u65F6\u6309 deployName ?? serviceName \u8865 dockerfile=deploy/{\u76EE\u5F55\u540D}/dockerfile/Dockerfile\uFF1BcontextDir \u7701\u7565\u65F6\u4F7F\u7528\u9879\u76EE\u6839\uFF0C\u663E\u5F0F\u503C\u4FDD\u7559\uFF1B\u72EC\u7ACB\u4E8E build.script\u3002
runtime.startScript\uFF1A\u542F\u52A8\u811A\u672C\uFF0C\u4E1A\u52A1\u767B\u8BB0\u7701\u7565\u65F6\u8865\u4E3A deploy/{serviceName}/scripts/start.sh\uFF1Bruntime.javaOpts\uFF1AJVM \u9009\u9879\u6570\u7EC4\uFF0C\u4EC5 backend + Java + Spring Boot \u8981\u6C42\u552F\u4E00 HTTP \u547D\u540D\u7AEF\u53E3\uFF0C\u5E76\u6309\u5B9E\u9645\u5165\u7AD9 key \u751F\u6210 -Dspring.cloud.nacos.discovery.port="$(sbx-inbound get-connect -k <key>)"\uFF1B\u666E\u901A\u6A21\u5F0F key \u4E3A serviceName\uFF0C\u7ECF Sandbox \u6838\u5B9E\u7684\u9884\u7F6E\u6A21\u5F0F\u4E3A 6003\uFF0C\u4E0D\u4F9D\u8D56 connectPort\uFF0C\u5176\u4ED6\u9009\u9879\u4FDD\u7559\u3002\u5E95\u5C42 upsert \u4E0D\u8865\u505A\u3002runtime.configFiles\uFF1A{name,templatePath,path,containerPath} \u6570\u7EC4\uFF0C\u7531\u9700\u8981\u7EF4\u62A4\u670D\u52A1\u4E8B\u5B9E\u7684\u6D41\u7A0B\u6309 serviceName \u53D7\u63A7\u56DE\u586B\uFF1BtemplatePath/path \u662F\u9879\u76EE\u6839\u76F8\u5BF9\u8DEF\u5F84\uFF0CcontainerPath \u662F\u7EDD\u5BF9 POSIX \u5BB9\u5668\u6587\u4EF6\u8DEF\u5F84\uFF0C\u4E0D\u8868\u793A Dockerfile COPY\u3002
runtime.container\uFF1AWAR \u8FD0\u884C\u65F6\u5BB9\u5668\u58F0\u660E\uFF0C\u542B name\u3001baseDir\u3001port\uFF1Bport \u5FC5\u987B\u5339\u914D\u672C\u670D\u52A1\u67D0\u4E2A\u547D\u540D\u76D1\u542C\u7AEF\u53E3\u7684 port \u503C\u3002
runtime.ports[]\uFF1A{name,protocol:http|grpc|tcp,port?,connectPort?,inboundKeyMode?:preset-port}\uFF1B\u666E\u901A HTTP \u7AEF\u53E3\u4EE5 serviceName \u4E3A key \u767B\u8BB0\u3002\u4EC5\u5339\u914D\u7684\u552F\u4E00 HTTP \u7AEF\u53E3\u53EF\u7528 preset-port\uFF1A\u6B63\u5F0F frontend/6002\u3001backend/6003 \u6216\u539F\u578B frontend/6005\uFF1B\u7701\u7565\u6807\u8BB0\u65F6\u53EA\u5728 Sandbox \u6838\u5B9E listen\u3001\u6570\u5B57 key\u3001preset=true \u540E\u56DE\u586B\u5E76\u590D\u7528\uFF0C\u4E0D\u6267\u884C set\u3002\u975E HTTP \u7AEF\u53E3\u53EA\u4FDD\u7559\u58F0\u660E\uFF0C\u4E0D\u767B\u8BB0\u3001\u4E0D\u4FDD\u7559 connectPort\u3002
check-ports [--input <\u5B8C\u6574manifest-json>]\uFF1A\u53EA\u8BFB\u68C0\u67E5\u7AEF\u53E3\u53CA key \u5F52\u5C5E\uFF0C\u8FD4\u56DE\u503C\u4EC5\u4E3A\u5F53\u524D\u5FEB\u7167\uFF0C\u4E0D\u9884\u7559\u3001\u4E0D\u767B\u8BB0\uFF1B\u666E\u901A\u6A21\u5F0F\u4E0D\u80FD\u590D\u7528\u5176\u4ED6 key\uFF0C\u9884\u7F6E\u6A21\u5F0F\u987B\u6838\u5B9E\u6570\u5B57 key\uFF0C\u63D0\u4EA4\u65F6\u4F1A\u91CD\u65B0\u590D\u6838\u3002
repair-port --service-name <name> --port-name <name> --expected-old-port <port> [--target-port <port>]\uFF1A\u663E\u5F0F\u4FEE\u590D\u666E\u901A\u6A21\u5F0F\u5DF2\u4FDD\u5B58 HTTP \u76D1\u542C\u503C\u88AB\u5176\u4ED6 key \u5360\u7528\uFF1B\u9884\u7F6E\u6A21\u5F0F\u4E0D\u80FD\u4F7F\u7528\uFF0C\u987B\u7ECF\u5B8C\u6574\u670D\u52A1\u767B\u8BB0\u8C03\u6574\u3002
runtime.http.contextPath\uFF1A\u5E94\u7528\u81EA\u8EAB\u7684 HTTP \u4E0A\u4E0B\u6587\u8DEF\u5F84\uFF0C\u4F8B\u5982 /xxl-job-admin\uFF1B\u4E0D\u7B49\u4E8E apiBasePath \u6216 endpoint.basePath\u3002
runtime.healthCheck\uFF1A{script}\uFF0C\u53EA\u8BFB\u6709\u754C\u68C0\u67E5\uFF1B\u4E1A\u52A1\u767B\u8BB0\u540E\u5FC5\u6709\uFF0C\u7701\u7565\u65F6\u6309 serviceName \u8865\u4E3A deploy/{serviceName}/scripts/health-check.sh\uFF1B\u4E0D\u542F\u52A8\u670D\u52A1\u3002
endpoints[]\uFF1A{type:pc|h5|api,businessType?:application|prototype,title,portName,basePath,exposure:public|internal}\uFF1Bpc/h5 \u7701\u7565 businessType \u65F6\u7EE7\u627F\u670D\u52A1\u503C\uFF0C\u663E\u5F0F\u503C\u4F18\u5148\uFF1Bapi \u7701\u7565\u65F6\u56FA\u5B9A\u4E3A application\uFF0C\u4E0D\u5141\u8BB8 prototype\u3002\u53EA\u6709 public \u53C2\u4E0E ingress/LCAP \u9884\u89C8\uFF0Cinternal \u4E0D\u540C\u6B65\uFF1B\u6240\u6709\u5165\u53E3\u5FC5\u987B\u6709 title\uFF0C\u6240\u6709 API endpoint \u7684 basePath \u4E0E apiBasePath \u4E00\u81F4\uFF0C\u5185\u90E8 API \u4E5F\u53EF\u4EE5\u53EA\u58F0\u660E apiBasePath \u800C\u4E0D\u58F0\u660E endpoint\u3002
dependencies[]\uFF1A{serviceName,portName,requiredForStartup}\uFF1Bprotocol \u4ECE\u76EE\u6807\u670D\u52A1 runtime.ports \u6309 portName \u89E3\u6790\uFF0C\u4EC5\u5FC5\u9700\u542F\u52A8\u4F9D\u8D56\u53C2\u4E0E\u73AF\u68C0\u67E5\u3002
HTTP \u76D1\u542C\u503C\u7531\u5951\u7EA6\u9996\u6B21\u767B\u8BB0\u6216\u7ECF\u6838\u5B9E\u7684\u9884\u7F6E\u6A21\u5F0F\u786E\u8BA4\uFF0C\u666E\u901A\u66F4\u65B0\u4E0D\u53EF\u6F02\u79FB\uFF1B\u666E\u901A\u6A21\u5F0F\u53EF\u7528 repair-port \u663E\u5F0F\u4FEE\u590D\u51B2\u7A81\uFF0Cruntime-sync \u6309\u5DF2\u4FDD\u5B58\u6A21\u5F0F\u6216\u7ECF Sandbox \u6838\u5B9E\u7684\u5185\u7F6E\u6A21\u5F0F\u6838\u5BF9 key\uFF0C\u5E76\u66F4\u65B0 connectPort\uFF1B\u975E HTTP \u76D1\u542C\u503C\u7531\u8C03\u7528\u65B9\u786E\u8BA4\uFF0CPORT_HTTP/PORT_HTTP_ADMIN \u6CE8\u5165\u542F\u52A8\u4E0E\u68C0\u67E5\u3002
\u6267\u884C\u4E0A\u4E0B\u6587\u4E0E\u8FD0\u884C\u6001\u8FB9\u754C\uFF1AAPP_ID/PRD_ID/CURRENT_BRANCH \u4EC5\u4ECE\u73AF\u5883\u8BFB\u53D6\uFF0C\u4E0D\u5199\u5165 Manifest\uFF1BSandbox \u5165\u7AD9 path/inboundBasePath \u4E0E LCAP \u8FD4\u56DE\u7684\u670D\u52A1 domain \u53EA\u5C5E\u4E8E\u8FD0\u884C/\u5E73\u53F0\u7ED3\u679C\uFF0C\u4E5F\u4E0D\u5199\u5165 Manifest\uFF1Bruntime-sync \u53EF\u56DE\u586B runtime.ports[].connectPort\uFF0C\u4EE5\u53CA\u7ECF Sandbox \u6838\u5B9E\u7684\u65E7\u5355\u4F53\u9884\u7F6E\u6807\u8BB0\u4E0E\u5BF9\u5E94 Nacos javaOpts\u3002
\u672C\u5730\u8054\u8C03\uFF1A\u8BBE\u7F6E DEPLOY_EXTERNAL_MODE=local-mock\uFF1B\u6309\u5DE5\u4F5C\u7A7A\u95F4\u6839\u81EA\u52A8\u9694\u79BB\u5E76\u4FDD\u5B58\u8DE8\u8FDB\u7A0B\u72B6\u6001\u3002\u53EF\u9009\u7EDD\u5BF9\u53EF\u5199 DEPLOY_MOCK_STATE_DIR \u548C DEPLOY_MOCK_DOMAINS_FILE\uFF1Bmock \u4E0B synced \u53EA\u662F\u6A21\u62DF\u76EE\u6807\u5DF2\u4FDD\u5B58\uFF0C\u4E0D\u4EE3\u8868\u771F\u5B9E LCAP\u3002
\u5B57\u6BB5\u6765\u81EA\u786E\u8BA4\u4E8B\u5B9E\uFF0C\u65E0\u6CD5\u786E\u8BA4\u7684\u53EF\u9009\u5B57\u6BB5\u5E94\u7701\u7565\uFF1B\u5B9E\u8D28\u67B6\u6784\u6B67\u4E49\u63D0\u4F9B\u5019\u9009\uFF0C\u4E0D\u731C\u6D4B\u3002
\u53D7\u63A7\u4E8B\u5B9E\u56DE\u586B\uFF1Aupdate-service-facts --service-name <name> --facts <json-object>\uFF1Bfacts.techStack \u5B8C\u6574\u66FF\u6362\u670D\u52A1\u6280\u672F\u6808\uFF0Cfacts.runtime \u652F\u6301 configFiles \u589E\u6539\u548C removeConfigFileNames \u5220\u9664\uFF0C\u672A\u77E5\u5B57\u6BB5\u548C\u53D7\u4FDD\u62A4\u5B57\u6BB5\u62D2\u7EDD\uFF1B\u540C\u4E00 name \u4E0D\u80FD\u540C\u65F6\u66F4\u65B0\u548C\u5220\u9664\u3002
\u751F\u7801\u524D\u68C0\u67E5\uFF1Avalidate --for-codegen \u68C0\u67E5\u5B8C\u6574 Manifest \u7684\u670D\u52A1\u6280\u672F\u6808\u3001\u6E90\u7801\u76EE\u5F55\u4E0E WAR \u5BB9\u5668\u4E8B\u5B9E\uFF1B\u53EF\u72EC\u7ACB\u7EC4\u5408 --require-runtime\uFF0C\u4E0D\u53EF\u4E0E --entry \u540C\u7528\u3002\u901A\u8FC7\u540E\u518D get \u8BFB\u53D6\u6700\u65B0 Manifest\uFF1B\u5B83\u4E0D\u68C0\u67E5\u811A\u672C\u6587\u4EF6\u662F\u5426\u5DF2\u751F\u6210\uFF0C\u4E5F\u4E0D\u4FDD\u8BC1\u751F\u7801\u5668\u652F\u6301\u9009\u578B\u3002\u751F\u7801\u540E\u53E6\u7528 createDeployReadinessChecker \u68C0\u67E5\u811A\u672C\u6587\u4EF6\u3002
\u5E73\u53F0\u80FD\u529B\u8FB9\u754C\uFF1A\u5F53\u524D LCAP \u4EC5\u652F\u6301\u6BCF\u670D\u52A1\u4E00\u4E2A\u5916\u90E8 HTTP \u547D\u540D\u7AEF\u53E3\uFF1Bpublic \u9875\u9762\u548C API \u90FD\u4F1A\u8FDB\u5165 Portal Ingress/\u9884\u89C8\uFF0Cpublic \u975E HTTP\u3001\u591A\u5916\u90E8\u547D\u540D\u7AEF\u53E3\u5728\u5916\u90E8\u64CD\u4F5C\u524D\u660E\u786E\u62D2\u7EDD\u3002Manifest \u662F\u5B8C\u6574\u76EE\u6807\u72B6\u6001\uFF0C\u5DF2\u6709\u516C\u5F00\u5165\u53E3\u88AB\u79FB\u9664\u65F6\u4F1A\u63D0\u4EA4\u7A7A\u76EE\u6807\u6E05\u7406 Portal \u7AEF\u4FE1\u606F\u548C Ingress\uFF1B\u5DF2\u5B58\u5728\u7684\u663E\u5F0F\u7A7A Manifest \u5728 runtime-sync \u65F6\u4E5F\u4F1A\u540C\u6B65\u7A7A\u76EE\u6807\uFF1Binternal API \u53EF\u4EE5\u4EC5\u4FDD\u7559 apiBasePath\u3002
\u670D\u52A1\u57DF\u540D\u67E5\u8BE2\uFF1A\u4F7F\u7528 deploy facade \u7684 getDeployServiceDomains()\uFF1B\u811A\u672C\u4FA7\u53EF\u4F7F\u7528\u751F\u6210\u7684 platform-tool get-service-domains\u3002\u771F\u5B9E\u6A21\u5F0F\u7F3A\u5C11\u8EAB\u4EFD\u3001\u5E73\u53F0\u5931\u8D25\u6216\u8FD4\u56DE\u7ED3\u6784\u975E\u6CD5\u5747\u62A5\u9519\uFF1B\u672C\u5730 mock \u6CE8\u518C\u540E\u8FD4\u56DE\u6700\u65B0\u5B8C\u6574\u76EE\u6807\u7684\u5206\u7EC4\u57DF\u540D\uFF0C\u67E5\u8BE2\u8BFB\u53D6\u540C\u4E00\u72B6\u6001\uFF0C\u9996\u6B21\u63D0\u4EA4\u524D\u624D\u4F7F\u7528\u53EF\u9009 fixture \u6216 []\uFF1B.test URL \u4E0D\u662F\u771F\u5B9E\u53EF\u8BBF\u95EE\u9884\u89C8\u5730\u5740\u3002
\u5DF2\u77E5\u4E8B\u5B9E\uFF1Aregister-known --input <target-json>\uFF0C\u4E00\u6B21\u5B8C\u6210\u5B8C\u6574\u670D\u52A1\u6CE8\u518C/\u66F4\u65B0\u4E0E\u663E\u5F0F\u6574\u670D\u52A1\u5220\u9664\uFF0C\u4E0D\u95EE\u8BE2\u3002\u5206\u6790\u578B\u95ED\u73AF\uFF1Aget \u2192 register-prepare --input <target-json> --baseline <get\u539F\u6587> \u2192 \u5FC5\u8981 ask \u2192 register-commit\u3002\u76EE\u6807\u683C\u5F0F\u4E3A {"manifest":{"services":[\u5B8C\u6574\u53D7\u5F71\u54CD\u670D\u52A1]},"deleteServiceNames":[\u6574\u670D\u52A1\u540D],"unresolvedExposures":[\u53EF\u9009\u5165\u53E3\u6807\u8BC6]}\uFF1BAgent \u4E0D\u6784\u9020\u5185\u90E8\u95EE\u8BE2\u9009\u9879\u6216\u53D8\u66F4\u8BA1\u5212\u3002
\u6574\u670D\u52A1\u5220\u9664\uFF1A\u5206\u6790\u578B Agent \u5728 deleteServiceNames \u5199\u660E\u670D\u52A1\u540D\uFF0C\u5951\u7EA6\u81EA\u52A8\u751F\u6210 service.retention \u95EE\u8BE2\uFF1B\u5DF2\u77E5\u4E8B\u5B9E\u76F4\u63A5\u6267\u884C\u3002\u5220\u9664\u4E0D\u505C\u6B62\u8FDB\u7A0B\u6216\u91CA\u653E Sandbox \u5165\u7AD9\u6620\u5C04\u3002
\u5BBF\u4E3B TypeScript \u63A5\u6536\u9884\u586B Manifest \u548C\u53EA\u8BFB AI/ask \u901A\u9053\uFF1BAgent \u4F9D\u7EDF\u4E00 Skill \u5206\u6790\u3002CLI \u4E0D\u81EA\u884C\u8FD0\u884C\u6A21\u578B\u3002\u5E73\u53F0\u5199\u5165\u53EA\u80FD\u7531 register-commit \u6216 runtime-sync \u7684\u5185\u90E8\u95ED\u73AF\u89E6\u53D1\u3002
\u7ED3\u679C manifestState\uFF1Aunchanged/saved/unknown\uFF1Bsaved \u63D0\u4F9B\u5B9E\u9645\u4FDD\u5B58 manifest\uFF0Cunknown \u4E0D\u628A\u5206\u6790\u5019\u9009\u5F53\u6210\u5DF2\u4FDD\u5B58\u4E8B\u5B9E\u3002\u6210\u529F\u767B\u8BB0\u4E3A status=registered\u3001manifestState=saved\uFF1B\u76EE\u6807\u5305\u542B public \u6216\u9700\u8981\u6E05\u7406\u5DF2\u6709 Portal \u76EE\u6807\u65F6 previewStatus=synced\uFF1B\u9996\u6B21\u767B\u8BB0\u4E14\u4EC5 internal/no endpoint \u7684\u975E\u7A7A\u670D\u52A1\u4E3A not-required\u3002
\u6280\u672F\u8BBE\u8BA1\u6700\u5C0F\u793A\u4F8B\uFF1A{"services":[{"serviceName":"portal-web","serviceTitle":"\u95E8\u6237\u524D\u7AEF","serviceType":"frontend","description":"\u95E8\u6237\u9875\u9762","runtime":{"ports":[{"name":"http","protocol":"http"}]},"endpoints":[{"type":"pc","title":"\u95E8\u6237","portName":"http","basePath":"/","exposure":"public"}]}]}\u3002
\u57FA\u7840\u7EF4\u62A4\uFF1Aget \u2192 validate --entry \u2192 upsert \u2192 validate \u2192 get\uFF08\u65E0\u5916\u90E8\u8C03\u7528\uFF09\u3002
\u9000\u51FA\u7801\uFF1A0\u6210\u529F\uFF0C1\u5916\u90E8\u5931\u8D25\uFF0C2\u53C2\u6570\u9519\u8BEF\uFF0C3\u6821\u9A8C\u5931\u8D25\uFF0C4\u672A\u627E\u5230\uFF0C5\u539F\u5B50\u5199\u5931\u8D25\u3002
`;
function generalHelp() {
  return "deploy-tool.mjs \u2014 \u90E8\u7F72\u5951\u7EA6\n\u7528\u6CD5\uFF1Adeploy-tool.mjs <\u547D\u4EE4> [\u53C2\u6570]\nhelp manifest / help <\u4E3B\u9898> / --help\n" + Object.values(SUBCOMMAND_SPECS).map((s) => s.usage + "\n  " + s.detail).join("\n") + "\n";
}
async function helpCommand(args) {
  if (args.length > 1) throw new InvalidArgumentError("help \u6700\u591A\u63A5\u53D7\u4E00\u4E2A\u4E3B\u9898");
  const topic = args[0];
  if (!topic) process.stdout.write(generalHelp());
  else if (topic === "manifest") process.stdout.write(MANIFEST_HELP);
  else if (Object.hasOwn(SUBCOMMAND_SPECS, topic)) {
    const spec = SUBCOMMAND_SPECS[topic];
    process.stdout.write(spec.usage + "\n" + spec.detail + "\n");
  } else throw new InvalidArgumentError("\u672A\u77E5\u5E2E\u52A9\u4E3B\u9898\uFF1A" + topic);
  return 0;
}
async function getCommand(args) {
  const flags = parseFlags(args, "get");
  const manifest = readDeployManifest(process.cwd());
  if (!flags.serviceName) return succeed(manifest);
  const service = manifest.services.find((item) => item.serviceName === flags.serviceName);
  if (!service) throw new DeployManifestNotFoundError(`service \u4E0D\u5B58\u5728\uFF1A${flags.serviceName}`);
  return succeed(service);
}
async function validateCommand(args) {
  const flags = parseFlags(args, "validate");
  if (flags.forCodegen && flags.entry !== void 0)
    throw new InvalidArgumentError("--for-codegen \u53EA\u652F\u6301\u5B8C\u6574 Manifest\uFF0C\u4E0D\u80FD\u4E0E --entry \u540C\u7528");
  const report = flags.forCodegen ? validateDeployCodegenManifest(readDeployManifest(process.cwd()), { requireRuntime: flags.requireRuntime }) : flags.entry === void 0 ? validateDeployManifest(readDeployManifest(process.cwd()), { requireRuntime: flags.requireRuntime }) : validateDeployService(parseEntry(flags.entry), { requireRuntime: flags.requireRuntime });
  if (!report.ok) throw new DeployManifestValidationError(formatIssues(report.issues));
  return succeed({ ok: true });
}
async function checkPortsCommand(args) {
  const flags = parseFlags(args, "check-ports");
  const manifest = flags.input === void 0 ? readDeployManifest(process.cwd()) : parseEntry(flags.input);
  const external = resolveDeployExternalDependencies(process.cwd(), process.env);
  return succeed({ ok: true, ...await preflightDeployPorts(manifest, { inbound: external.inbound }) });
}
async function repairPortCommand(args) {
  const flags = parseFlags(args, "repair-port");
  if (!flags.portName || !flags.expectedOldPort)
    throw new InvalidArgumentError("repair-port \u7F3A\u5C11 --port-name \u6216 --expected-old-port");
  return succeed(await repairDeployPort({
    cwd: process.cwd(),
    serviceName: requireServiceName(flags.serviceName),
    portName: flags.portName,
    expectedOldPort: Number(flags.expectedOldPort),
    ...flags.targetPort === void 0 ? {} : { targetPort: Number(flags.targetPort) }
  }));
}
async function upsertCommand(args) {
  const flags = parseFlags(args, "upsert");
  if (flags.entry === void 0) throw new InvalidArgumentError("upsert \u7F3A\u5C11 --entry");
  const entry = parseEntry(flags.entry);
  await withDeployMutation(process.cwd(), async () => upsertDeployService(process.cwd(), entry));
  logger.info("upsert serviceName=" + String(entry?.serviceName));
  return succeed({ ok: true });
}
async function updateServiceFactsCommand(args) {
  const flags = parseFlags(args, "update-service-facts");
  const serviceName = requireServiceName(flags.serviceName);
  if (flags.facts === void 0) throw new InvalidArgumentError("\u7F3A\u5C11 --facts");
  const facts = parseEntry(flags.facts);
  if (!facts || typeof facts !== "object" || Array.isArray(facts)) {
    throw new DeployManifestValidationError("facts \u5FC5\u987B\u662F\u5BF9\u8C61");
  }
  const result = await updateDeployServiceFacts(process.cwd(), {
    serviceName,
    facts
  });
  return succeed({ ok: true, manifest: result.manifest });
}
async function deleteCommand(args) {
  const flags = parseFlags(args, "delete");
  await withDeployMutation(
    process.cwd(),
    async () => deleteDeployService(process.cwd(), requireServiceName(flags.serviceName))
  );
  logger.info("delete serviceName=" + flags.serviceName);
  return succeed({ ok: true });
}
async function registerPrepareCommand(args) {
  const flags = parseFlags(args, "register-prepare");
  if (flags.input === void 0) throw new InvalidArgumentError("\u7F3A\u5C11 --input");
  if (flags.baseline === void 0) throw new InvalidArgumentError("\u7F3A\u5C11 --baseline\uFF08\u5206\u6790\u5F00\u59CB\u524D\u7684 get \u539F\u8F93\u51FA\uFF09");
  return succeed(
    prepareDeployRegistration(
      process.cwd(),
      parseEntry(flags.input),
      parseEntry(flags.baseline)
    )
  );
}
async function registerKnownCommand(args) {
  const flags = parseFlags(args, "register-known");
  if (flags.input === void 0) throw new InvalidArgumentError("\u7F3A\u5C11 --input");
  return emitOperation(await registerKnownManifest(parseEntry(flags.input)));
}
async function registerCommitCommand(args) {
  const flags = parseFlags(args, "register-commit");
  if (flags.prepared === void 0) throw new InvalidArgumentError("\u7F3A\u5C11 --prepared");
  return emitOperation(
    await commitDeployRegistration(
      process.cwd(),
      parseEntry(flags.prepared),
      flags.answer
    )
  );
}
async function runtimeSyncCommand(args) {
  parseFlags(args, "runtime-sync");
  return emitOperation(await restoreDeployPreview(process.cwd()));
}
function emitOperation(result) {
  succeed(result);
  logger.info(
    "operation status=" + result.status + " stage=" + result.stage + " ports=" + JSON.stringify(
      result.ports.map((p) => ({ serviceName: p.serviceName, portName: p.portName, port: p.port, action: p.action }))
    )
  );
  if (result.ok) return 0;
  process.stderr.write("[deploy-tool] " + result.error?.code + " " + result.error?.message + "\n");
  if (result.stage === "save") return 5;
  if (["prepare", "preflight", "read"].includes(result.stage) || ["RUNTIME_UNASSIGNED", "RUNTIME_KEY_CONFLICT", "RUNTIME_PRESET_UNAVAILABLE"].includes(result.error?.code ?? "")) return 3;
  return 1;
}
function wrap(handler) {
  return async (args) => {
    try {
      return await handler(args);
    } catch (error) {
      return fail(error);
    }
  };
}
var SUBCOMMANDS = {
  help: wrap(helpCommand),
  get: wrap(getCommand),
  validate: wrap(validateCommand),
  "check-ports": wrap(checkPortsCommand),
  "repair-port": wrap(repairPortCommand),
  upsert: wrap(upsertCommand),
  "update-service-facts": wrap(updateServiceFactsCommand),
  delete: wrap(deleteCommand),
  "register-known": wrap(registerKnownCommand),
  "register-prepare": wrap(registerPrepareCommand),
  "register-commit": wrap(registerCommitCommand),
  "runtime-sync": wrap(runtimeSyncCommand)
};
function fail(error) {
  const normalized = normalizeError(error);
  succeed({ ok: false, error: {
    code: normalized.code,
    message: normalized.message,
    ...normalized.details ? { details: normalized.details } : {}
  } });
  process.stderr.write("[deploy-tool] " + normalized.code + " " + normalized.message.split("\n")[0] + "\n");
  logger.error(normalized.code + " " + normalized.message.split("\n")[0]);
  return normalized.exitCode;
}
function invalidCommand(command) {
  return fail(new InvalidArgumentError("\u672A\u77E5\u547D\u4EE4\uFF1A" + (command ?? "(\u65E0)")));
}
function normalizeError(error) {
  if (error instanceof InvalidArgumentError) return error;
  if (error instanceof DeployManifestNotFoundError)
    return { exitCode: 4, code: "SERVICE_NOT_FOUND", message: error.message };
  if (error instanceof DeployManifestWriteError) return { exitCode: 5, code: "WRITE_FAILED", message: error.message };
  if (error instanceof DeployManifestFileError || error instanceof DeployManifestValidationError)
    return { exitCode: 3, code: "MANIFEST_INVALID", message: error.message };
  const typed = error;
  return {
    exitCode: typeof typed?.exitCode === "number" ? typed.exitCode : 1,
    code: typeof typed?.code === "string" ? typed.code : "INTERNAL_ERROR",
    message: error instanceof Error ? error.message : String(error),
    ...typed?.details && typeof typed.details === "object" ? { details: typed.details } : {}
  };
}
function parseFlags(args, subcommand) {
  const allowed = SUBCOMMAND_SPECS[subcommand].flags;
  const parsed = { requireRuntime: false, forCodegen: false }, seen = /* @__PURE__ */ new Set();
  const keys = {
    "--entry": "entry",
    "--facts": "facts",
    "--service-name": "serviceName",
    "--port-name": "portName",
    "--expected-old-port": "expectedOldPort",
    "--target-port": "targetPort",
    "--input": "input",
    "--prepared": "prepared",
    "--answer": "answer",
    "--baseline": "baseline"
  };
  for (let i = 0; i < args.length; i++) {
    const flag = args[i];
    if (!allowed.includes(flag) || seen.has(flag)) throw new InvalidArgumentError("\u53C2\u6570\u975E\u6CD5\u6216\u91CD\u590D\uFF1A" + flag);
    seen.add(flag);
    if (flag === "--require-runtime") {
      parsed.requireRuntime = true;
      continue;
    }
    if (flag === "--for-codegen") {
      parsed.forCodegen = true;
      continue;
    }
    const value = args[++i];
    if (value === void 0 || value.startsWith("--")) throw new InvalidArgumentError(flag + " \u7F3A\u5C11\u53C2\u6570\u503C");
    const key = keys[flag];
    parsed[key] = value;
  }
  return parsed;
}
function parseEntry(raw) {
  try {
    return JSON.parse(raw);
  } catch {
    throw new InvalidArgumentError("\u53C2\u6570\u4E0D\u662F\u5408\u6CD5 JSON");
  }
}
function requireServiceName(value) {
  if (!value?.trim()) throw new InvalidArgumentError("\u7F3A\u5C11 --service-name");
  return value;
}
function succeed(payload) {
  process.stdout.write(JSON.stringify(payload) + "\n");
  return 0;
}
function formatIssues(issues) {
  return issues.map((i) => i.path + ": " + i.message).join("; ");
}

// src/utils/customWaveAgent/speckit/config/shared/manifest/deploy/cli.mts
async function main() {
  const [command, ...args] = process.argv.slice(2);
  const normalized = command === "--help" || command === "-h" ? "help" : command;
  const handler = normalized && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, normalized) ? SUBCOMMANDS[normalized] : void 0;
  process.exitCode = handler ? await handler(args) : invalidCommand(command);
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  void main();
}
export {
  SUBCOMMANDS
};
