// Java 版本归一口径单点（plan 2026-09-08/java8-backend-generation-support item 6；
// dual-review 修复 P1「四份 resolveJavaHome 复制体无测试锁定」——抽公共实现供四份 checker import，
// 单测锁 tests/scripts/java-version-normalize.test.mjs）。
// "1.8.0_412"→8、"1.8"→8、"21"→21、"21.0.3"→21：取首个数字段，1.x 取 minor 为主版本号。
export function normalizeJavaMajor(raw) {
  const m = String(raw).match(/(\d+)(?:\.(\d+))?/);
  if (!m) return null;
  if (m[1] === '1' && m[2] !== undefined) return parseInt(m[2], 10);
  return parseInt(m[1], 10);
}

// 从 pom 片段读目标主版本：<java.version>（回退 <maven.compiler.release>），经 normalizeJavaMajor 归一。
export function parsePomJavaMajor(pom) {
  let m = pom.match(/<java\.version>([\d.]+)<\/java\.version>/);
  if (!m) m = pom.match(/<maven\.compiler\.release>([\d.]+)<\/maven\.compiler\.release>/);
  return m ? normalizeJavaMajor(m[1]) : null;
}

// 从 `java -version` 输出解析主版本：`version "1.8.0_412"`→8（两段解析，旧 (\d+) 只取到 "1" 恒失配）。
export function parseJavaVersionOutput(out) {
  const m = String(out).match(/version "([\d.]+)/) || String(out).match(/version ([\d.]+)/);
  return m ? normalizeJavaMajor(m[1]) : null;
}
