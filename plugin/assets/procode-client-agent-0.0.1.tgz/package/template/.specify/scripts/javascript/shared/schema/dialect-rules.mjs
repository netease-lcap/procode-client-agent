/**
 * 方言规则（§5.7）：只做机械归一，不内置任何方言 SQL。
 *
 * 职责：
 *   - 已知别名归一；未知方言**原样透传**（不设白名单，不猜 MySQL）；
 *   - 大小写/引号折叠：未加引号 MySQL/PG 小写、Oracle/达梦大写，未知原样；
 *   - owner/schema 选择：代码前缀 → 契约 schemaName/owner → 当前 schema，多值 fail-loud；
 *   - 连接目标库键：Oracle=connectionTarget，MySQL/PG/达梦=database，未知走候选键探测；
 *   - appId 只认 APP_ID（含平台历史别名）。
 *
 * 本模块被 gate B checker 与 extract 编排器共用；不得引入 DB 驱动或方言 SQL。
 */

/** 方言族：只用于折叠规则，不用于能力承诺。 */
export const DIALECT_FAMILY = Object.freeze({
  mysql: 'mysql',
  mariadb: 'mysql',
  tidb: 'mysql',
  oracle: 'oracle',
  ora: 'oracle',
  postgres: 'postgresql',
  postgresql: 'postgresql',
  pg: 'postgresql',
  pgsql: 'postgresql',
  dm: 'dameng',
  dameng: 'dameng',
  damengdb: 'dameng',
});

/** 已知别名的 canonical 名。 */
const CANONICAL = Object.freeze({
  mariadb: 'mysql',
  tidb: 'mysql',
  ora: 'oracle',
  postgres: 'postgresql',
  pg: 'postgresql',
  pgsql: 'postgresql',
  dm: 'dameng',
  damengdb: 'dameng',
});

const trimText = (value) => (typeof value === 'string' ? value.trim() : '');

/**
 * 已知别名归一；未知原样返回（保留原拼写，不猜 MySQL）。
 * 例：PostgreSQL→postgresql、Oracle→oracle、MySQL8→mysql、CustomDB→CustomDB。
 */
export function canonicalDialect(value) {
  const text = trimText(value);
  if (!text) return '';
  const lower = text.toLowerCase();
  if (lower.includes('postgres') || lower === 'pg' || lower === 'pgsql') return 'postgresql';
  if (lower.includes('oracle') || lower === 'ora') return 'oracle';
  if (lower.includes('mysql') || lower.includes('mariadb') || lower === 'tidb') return 'mysql';
  if (lower === 'dm' || lower === 'dmdb' || lower.includes('dameng')) return 'dameng';
  return CANONICAL[lower] || text;
}

/** 仅折叠规则用的方言族；未知返回 'unknown'。 */
export function dialectFamily(value) {
  const canonical = canonicalDialect(value);
  return DIALECT_FAMILY[canonical] || 'unknown';
}

const QUOTE_PAIRS = [
  ['"', '"'],
  ['`', '`'],
  ["'", "'"],
  ['[', ']'],
];

/** 去掉一层外层标识符引号；不是成对引号则原样返回。 */
export function stripIdentifierQuotes(value) {
  const text = String(value ?? '').trim();
  if (text.length < 2) return text;
  for (const [open, close] of QUOTE_PAIRS) {
    if (text.startsWith(open) && text.endsWith(close)) {
      const inner = text.slice(open.length, text.length - close.length);
      // SQL 的转义写法："" / `` / ]]。
      return inner.split(`${close}${close}`).join(close);
    }
  }
  return text;
}

export function isQuotedIdentifier(value) {
  const text = String(value ?? '').trim();
  for (const [open, close] of QUOTE_PAIRS) {
    if (text.length >= 2 && text.startsWith(open) && text.endsWith(close)) return true;
  }
  return false;
}

/**
 * 标识符折叠（§5.7）。
 *   - 加了引号：保留大小写（只去引号）；
 *   - 未加引号：MySQL/PG 小写；Oracle/达梦大写；未知原样。
 *
 * @param {string} dialect
 * @param {string} name
 * @param {{quoted?: boolean}} [options]
 */
export function foldIdentifierForDialect(dialect, name, options = {}) {
  const text = stripIdentifierQuotes(name);
  if (!text) return '';
  const quoted = options.quoted === true || (options.quoted === undefined && isQuotedIdentifier(name));
  if (quoted) return text;
  const family = dialectFamily(dialect);
  if (family === 'mysql' || family === 'postgresql') return text.toLowerCase();
  if (family === 'oracle' || family === 'dameng') return text.toUpperCase();
  return text;
}

/** owner/schema 与表名使用同一套折叠规则。 */
export function foldOwnerIdentifier(dialect, name, options = {}) {
  return foldIdentifierForDialect(dialect, name, options);
}

/**
 * 连接目标库键（§5.7 / mysql-client 既有口径）。
 * 未知方言返回 null，调用方必须用候选键探测；不得回退猜 MySQL。
 */
export function targetKeyForDialect(dialect) {
  const family = dialectFamily(dialect);
  if (family === 'oracle') return 'connectionTarget';
  if (family === 'mysql' || family === 'postgresql' || family === 'dameng') return 'database';
  return null;
}

/** 未知方言的候选键（有序）；探测仍失败 = fail-loud。 */
export const PROBE_DATABASE_KEYS = Object.freeze([
  'database',
  'connectionTarget',
  'dbName',
  'dbname',
  'databaseName',
  'schema',
  'schemaName',
  'serviceName',
  'sid',
]);

const isPlainObject = (value) =>
  value != null && typeof value === 'object' && !Array.isArray(value);

const pickText = (value) => (typeof value === 'string' ? value.trim() : '');

/**
 * 从契约 config 选择目标库。
 *
 * @param {string} dialect
 * @param {object} config 契约条目 config
 * @param {{ probeKeys?: string[] }} [options] 未知方言额外候选键
 * @returns {{ value:string, key:string }|null}
 */
export function pickDatabaseName(dialect, config, options = {}) {
  if (!isPlainObject(config)) return null;
  const preferred = targetKeyForDialect(dialect);
  const keys = preferred
    ? [preferred, ...(preferred === 'database' ? ['connectionTarget'] : ['database'])]
    : [...(options.probeKeys || []), ...PROBE_DATABASE_KEYS];
  for (const key of keys) {
    const value = pickText(config[key]);
    if (value) return { value, key };
  }
  return null;
}

/**
 * owner/schema 选择（§5.7 优先级 + D7 多值 fail-loud）。
 *
 * @param {object} input
 * @param {Array<string|null|undefined>} [input.codeOwners] 代码 SQL 前缀（可多个）
 * @param {Array<string|null|undefined>} [input.contractOwners] 契约 schemaName/owner
 * @param {string|null|undefined} [input.currentSchema] 当前 schema
 * @param {string} [input.dialect]
 * @returns {{ok:boolean, owner:string|null, source:string|null, owners:string[], reason?:string}}
 */
export function resolveOwner({ codeOwners = [], contractOwners = [], currentSchema = null, dialect = '' } = {}) {
  const groups = [
    { source: 'code', values: codeOwners },
    { source: 'contract', values: contractOwners },
    { source: 'current', values: currentSchema == null ? [] : [currentSchema] },
  ];
  for (const group of groups) {
    const seen = new Map();
    for (const value of group.values) {
      const raw = pickText(value);
      if (!raw) continue;
      const key = foldOwnerIdentifier(dialect, raw);
      if (!seen.has(key)) seen.set(key, raw);
    }
    if (seen.size === 0) continue;
    if (seen.size > 1) {
      return {
        ok: false,
        owner: null,
        source: group.source,
        owners: [...seen.values()],
        reason: `识别到多个 schema/owner（${group.source}）：${[...seen.values()].join(', ')}；按 D7 fail-loud，不猜`,
      };
    }
    return { ok: true, owner: [...seen.values()][0], source: group.source, owners: [...seen.values()] };
  }
  return { ok: true, owner: null, source: null, owners: [] };
}

/**
 * 检查一组已声明 owner 是否唯一（gate B / 装配复用）。
 *
 * @returns {{ok:boolean, owner:string|null, owners:string[], reason?:string}}
 */
export function assertSingleOwner(dialect, owners = []) {
  const seen = new Map();
  for (const value of owners) {
    const raw = pickText(value);
    if (!raw) continue;
    const key = foldOwnerIdentifier(dialect, raw);
    if (!seen.has(key)) seen.set(key, raw);
  }
  if (seen.size > 1) {
    return {
      ok: false,
      owner: null,
      owners: [...seen.values()],
      reason: `多个 schema/owner：${[...seen.values()].join(', ')}（D7 fail-loud）`,
    };
  }
  return { ok: true, owner: seen.size === 1 ? [...seen.values()][0] : null, owners: [...seen.values()] };
}

/**
 * appId：契约/沙箱 env，不接受 SQL_EXEC_DB_*。
 * 只做读取，不校验为空（由通道层 fail-loud）。
 */
export function resolveAppId(env = process.env) {
  return (
    pickText(env.APP_ID) ||
    pickText(env.LCAP_APP_ID) ||
    pickText(env.NASL_STORAGE_APP_ID) ||
    ''
  );
}
