import fs from 'fs';
import path from 'path';

import {
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  parseQuote,
  parseStemFromPath,
  parseEn,
  parse,
  parseToList,
  writeToFileSync,
  formatWritedFiles,
  parseMenus,
  traceRelations,
  toAbsoluteFilePath,
  getRawSpecAbsoluteFilePath,
  readRawSpecContentSync,
  auto,
} from './shared/index.mjs';

export const findMenus = (item) => Boolean(item) && typeof item === 'string' && item.endsWith('specs/menus.md');
export const filterIgnored = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/ignored-');

export const filterPoint = (item) => {
  if (!item || typeof item !== 'string') return false;
  const pointable = item.includes('pieces/point-');
  const designable = item.includes('pieces/point-design-');

  return pointable && !designable;
};

export const filterPointDesign = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/point-design-');

export const getImageLineRanges = (rootDir = '') => {
  const source = readRawSpecContentSync(rootDir) || '';
  const lines = source.split('\n');
  const startKeyword = '<图片内容|start>';
  const endKeyword = '<图片内容|end>';
  const ranges = [];
  let currentStart = 0;

  lines.forEach((line = '', index = 0) => {
    const lineNumber = index + 1;

    if (line.includes(startKeyword)) {
      currentStart = lineNumber;
      return;
    }

    if (line.includes(endKeyword) && currentStart) {
      ranges.push([currentStart, lineNumber]);
      currentStart = 0;
    }
  });

  return ranges;
};

export const isRawSpecQuoteFile = (filePath = '', rootDir = '') => {
  const normalized = path.resolve(String(filePath || ''));
  const rawSpecAbsoluteFilePath = path.resolve(String(getRawSpecAbsoluteFilePath(rootDir) || ''));
  const rawSpecReg = /[/\\]inputs[/\\]spec\.(txt|md)$/;

  return Boolean(normalized)
    && (normalized === rawSpecAbsoluteFilePath || rawSpecReg.test(normalized));
};

export const normalizeRange = (range = []) => {
  const [start = 0, end = start] = Array.isArray(range) ? range : [];
  return [toNumber(start), toNumber(end || start)];
};

export const rangeToPart = (range = []) => {
  const [start = 0, end = start] = normalizeRange(range);
  const single = !Array.isArray(range) || range.length <= 1 || start === end;

  return single ? `L${start}` : `L${start},${end}`;
};

export const expandRangeByImageRanges =
  (imageRanges = []) =>
  (range = []) => {
    const [start = 0, end = start] = normalizeRange(range);
    const matched = (Array.isArray(imageRanges) ? imageRanges : []).filter(([imageStart = 0, imageEnd = 0] = []) => {
      return !(end < imageStart || imageEnd < start);
    });

    if (!matched.length) {
      return [start, end];
    }

    const starts = matched.map(([imageStart = 0] = []) => imageStart);
    const ends = matched.map(([, imageEnd = 0] = []) => imageEnd);

    return [Math.min(...starts), Math.max(...ends)];
  };

export const correctQuoteRangeByImages =
  (rootDir = '') =>
  (quote = {}) => {
    const { filePath = '', range = [] } = quote;

    if (!isRawSpecQuoteFile(filePath, rootDir)) {
      return { ...quote, range: normalizeRange(range) };
    }

    const imageRanges = getImageLineRanges(rootDir);
    const fixedRange = expandRangeByImageRanges(imageRanges)(range);

    return { ...quote, range: fixedRange };
  };

export const escapeRegExp = (source = '') => String(source).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export const correctQuoteSourceByImages =
  (rootDir = '') =>
  (source = '') => {
    const correctQuoteRange = correctQuoteRangeByImages(rootDir);
    const to = toAbsoluteFilePath(rootDir);
    const quotes = parseQuote(source) || [];

    return quotes.reduce((result = '', quote = {}) => {
      const { filePath = '', range = [] } = quote;
      const fixed = correctQuoteRange({ ...quote, filePath: to(filePath) });
      const oldPart = rangeToPart(range);
      const newPart = rangeToPart(fixed.range);

      if (!filePath || oldPart === newPart) {
        return result;
      }

      const escapedPath = escapeRegExp(filePath);
      const escapedPart = escapeRegExp(oldPart);
      const markdownReg = new RegExp(`\\[${escapedPart}\\]\\(${escapedPath}#${escapedPart}\\)`, 'g');
      const quoteReg = new RegExp(`${escapedPath}#${escapedPart}`, 'g');

      return result
        .replace(markdownReg, `[${newPart}](${filePath}#${newPart})`)
        .replace(quoteReg, `${filePath}#${newPart}`);
    }, source);
  };

export const fulfillQuoteRangesFromImages =
  (rootDir = '') =>
  (bundle = {}) => {
    const { fileName = '', absoluteFilePath = '' } = bundle;
    const source = readFileSync(absoluteFilePath) || '';
    const corrected = correctQuoteSourceByImages(rootDir)(source);

    if (!absoluteFilePath || corrected === source) {
      return;
    }

    writeToFileSync(fileName, absoluteFilePath)(corrected);
  };

export const getObjectsFromItem =
  (rootDir) =>
  (item = {}) => {
    // 处理null和undefined情况
    if (!item || typeof item !== 'object') {
      return {};
    }

    const { content = '' } = item;

    const [, itemDescrition] = content.split('：');
    const parsed = parseQuote(content) || [];

    const correctQuoteRange = correctQuoteRangeByImages(rootDir);
    const quotes = parsed.map((item = {}) => {
      const { filePath: itemFilePath } = item;

      const to = toAbsoluteFilePath(rootDir);
      const filePath = to(itemFilePath);

      return correctQuoteRange({ ...item, filePath });
    });

    if (!quotes?.length) {
      return {};
    }

    const relations = [{ quotes }];
    const traced = traceRelations(rootDir)(relations) || [];
    const [first = {}] = traced;
    const { quotes: got = [] } = first;

    return got.reduce((result = {}, item = {}) => {
      const { filePath, range = [], description = '' } = item;

      const [start, end] = range;
      const part = `L${start},${end}`;
      const suffix = description || itemDescrition || '';
      const content = `  - **[${part}](${filePath}#${part})**：${suffix}`;

      result[part] = { content };
      return result;
    }, {});
  };

export const uselessFileNames = [
  'point-design.md',
];

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const activeSpecDir = getActiveSpecDir(rootDir);
  const activeSpecList = readdirSync(activeSpecDir);

  const { absoluteFilePath: menusAbsoluteFilePath } = findUnderSpecs(rootDir)(findMenus) || {};
  const piecesAbsoluteDir = path.resolve(activeSpecDir, 'pieces');

  const options = { rootDir };
  const parseList = parseToList(options);
  const getObjects = getObjectsFromItem(rootDir);
  const menus = parseMenus(menusAbsoluteFilePath)?.menus || [];
  const pointBundles = filterUnderSpecs(rootDir)(filterPoint);
  const pointDesignBundles = filterUnderSpecs(rootDir)(filterPointDesign);

  const sortInformation = (a, b) => (a.index < b.index ? -1 : 1);

  const informationToPart = (item) => item.content.replace(/(^|\n)#[^\n]+/g, '');

  const fulfillPointFromIgnored = (bundle = {}) => {
    const { absoluteDir, relativeFilePath, absoluteFilePath } = bundle;

    const name = parseStemFromPath(relativeFilePath);
    const ignoredAbsoluteFilePath = path.resolve(absoluteDir, `ignored-point-${name}.md`);
    const ignoredSource = readFileSync(ignoredAbsoluteFilePath) || '';
    const ignoredList = parseList(ignoredSource) || [];

    const pointSource = readFileSync(absoluteFilePath) || '';
    const pointList = parseList(pointSource) || [];

    const messages = ['# 关联主题'];

    pointList.forEach((point = {}) => {
      const { title, children: pointChildren = [] } = point;

      const map = (item) => item?.content;
      const find = (item) => item?.title === title;
      const sort = (a, b) => {
        const [aString = ''] = a.match(/[0-9]+/g) || [];
        const [bString = ''] = b.match(/[0-9]+/g) || [];

        const aNumber = toNumber(aString);
        const bNumber = toNumber(bString);

        return aNumber > bNumber ? 1 : -1;
      };

      const found = ignoredList.find(find) || {};
      const { children: foundChildren = [] } = found;

      const objects = foundChildren.map(getObjects);
      const merged = Object.assign({}, ...objects);
      const more = Object.values(merged);
      const list = [point, ...pointChildren, ...more];

      const mapped = list.map(map).filter(Boolean);
      const parts = Array.from(new Set(mapped));
      const message = parts.sort(sort).join('\n');

      messages.push(message);
    });

    writeToFileSync(name, absoluteFilePath)(messages);
  };

  const bundleToInformation = (bundle = {}) => {
    const { fileName, relativeFilePath, absoluteFilePath } = bundle;

    const useless = uselessFileNames.includes(fileName);

    if (useless) {
      return;
    }

    const name = parseStemFromPath(relativeFilePath);
    const findIndex = (item) => item?.combined === name;
    const index = menus.findIndex(findIndex);
    const content = readFileSync(absoluteFilePath);

    return { index, content };
  };

  pointBundles.forEach(fulfillPointFromIgnored);
  pointDesignBundles.forEach(fulfillQuoteRangesFromImages(rootDir));

  const informations = pointBundles
    .map(bundleToInformation)
    .filter(Boolean)
    .sort(sortInformation);

  const parts = informations.map(informationToPart);
  const merged = ['# 原始引用', '', ...parts];

  const quotesAbsolutePath = path.resolve(piecesAbsoluteDir, 'quotes.md');
  const result = writeToFileSync('原始引用', quotesAbsolutePath)(merged);

  return `创建${result}成功`;
};

auto(import.meta)(toRaw);

export default toRaw;
