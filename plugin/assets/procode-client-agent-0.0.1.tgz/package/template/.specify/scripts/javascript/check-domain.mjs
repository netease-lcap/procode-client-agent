#!/usr/bin/env node
import { readFileSync, readdirSync, existsSync } from 'fs';
import path from 'path';

const mode = process.argv[2];
const filePath = process.argv[3];
const domainPath = process.argv[4];

// ─── 输入合法性：build 的合法输入只有 pieces 与 specs ───
const LEGAL_SOURCE_PREFIXES = ['pieces/', 'specs/'];
const SHARED_WHITELIST = ['terms.md']; // 规范需求阶段全局文件白名单，可进 sharedRefs
const ILLEGAL_HINTS = ['plans/', 'entities.md', 'er-diagram.md', 'frontend/index.md'];
const stripAnchor = (f) => (typeof f === 'string' ? f.split('#')[0].trim() : f);
const isLegalSourceFile = (f) => {
  const p = stripAnchor(f);
  return typeof p === 'string' && LEGAL_SOURCE_PREFIXES.some((pre) => p.startsWith(pre));
};
const isLegalSharedFile = (f) => isLegalSourceFile(f) || SHARED_WHITELIST.includes(stripAnchor(f));
const looksIllegal = (f) => typeof f === 'string' && ILLEGAL_HINTS.some((h) => f.includes(h));

if (!mode || !filePath) {
  console.log(JSON.stringify({ ok: false, failures: [{ type: 'usage', location: 'args', reason: 'Usage: node check-domain.mjs <domain> <file-path>', fix: 'Provide valid args' }] }));
  process.exit(1);
}

try {
  if (mode === 'domain') {
    const dom = JSON.parse(readFileSync(filePath, 'utf-8'));
    const failures = [];

    if (!dom.domains || !Array.isArray(dom.domains)) failures.push({ type: 'structure', location: 'domains', reason: 'Missing or invalid domains array', fix: 'Ensure domains is a non-empty array' });
    if (!dom.assumptions || !Array.isArray(dom.assumptions)) failures.push({ type: 'structure', location: 'assumptions', reason: 'Missing or invalid assumptions array', fix: 'Ensure assumptions is an array' });
    if (!dom.openQuestions || !Array.isArray(dom.openQuestions)) failures.push({ type: 'structure', location: 'openQuestions', reason: 'Missing or invalid openQuestions array', fix: 'Ensure openQuestions is an array' });

    if (dom.domains && Array.isArray(dom.domains)) {
      const domainIds = new Set();
      dom.domains.forEach((d, i) => {
        const prefix = `domains[${i}]`;
        if (!d.id || typeof d.id !== 'string') failures.push({ type: 'schema', location: prefix + '.id', reason: 'Missing or invalid id', fix: 'Each domain must have a string id' });
        else {
          if (domainIds.has(d.id)) failures.push({ type: 'schema', location: prefix + '.id', reason: 'Duplicate domain id: ' + d.id, fix: 'Domain ids must be unique' });
          domainIds.add(d.id);
        }
        if (!d.nameZh || typeof d.nameZh !== 'string') failures.push({ type: 'schema', location: prefix + '.nameZh', reason: 'Missing or invalid nameZh', fix: 'Each domain must have a non-empty nameZh' });
        if (!d.type || !['core', 'support', 'common'].includes(d.type)) failures.push({ type: 'schema', location: prefix + '.type', reason: 'Missing or invalid type (must be core/support/common)', fix: 'Set type to core, support, or common' });
        if (!d.description || typeof d.description !== 'string' || d.description.trim() === '') failures.push({ type: 'schema', location: prefix + '.description', reason: 'Missing or empty description', fix: 'Each domain must have a non-empty description' });

        // sourceRefs 结构 + 强制非空 + 路径合法性
        if (!d.sourceRefs || !Array.isArray(d.sourceRefs)) {
          failures.push({ type: 'schema', location: prefix + '.sourceRefs', reason: 'Missing or invalid sourceRefs array', fix: 'Each domain must register a non-empty sourceRefs array (files/segments it was identified from)' });
        } else {
          if (d.sourceRefs.length === 0) failures.push({ type: 'source-refs', location: prefix + '.sourceRefs', reason: 'Empty sourceRefs: a domain is identified by reading originals, so sources cannot be empty', fix: 'Register at least one pieces/specs source ref (the thinnest domain still maps to specs/menus.md)' });
          d.sourceRefs.forEach((r, ri) => {
            const rp = `${prefix}.sourceRefs[${ri}]`;
            if (!r || typeof r.file !== 'string' || r.file.trim() === '') failures.push({ type: 'source-refs', location: rp + '.file', reason: 'Missing or empty file', fix: 'Each sourceRef needs a non-empty file path under pieces/ or specs/' });
            else if (looksIllegal(r.file) || !isLegalSourceFile(r.file)) failures.push({ type: 'illegal-input', location: rp + '.file', reason: 'Illegal source file "' + r.file + '" (must start with pieces/ or specs/; design-stage products entities.md/er-diagram.md/frontend/index.md are forbidden)', fix: 'Reference only pieces/** or specs/** files' });
            if (!r || typeof r.anchor !== 'string' || r.anchor.trim() === '') failures.push({ type: 'source-refs', location: rp + '.anchor', reason: 'Missing or empty anchor', fix: 'Each sourceRef needs a semantic anchor (heading/section/specRange)' });
          });
        }
      });

      // Validate dependsOn after collecting all IDs (two-pass)
      dom.domains.forEach((d, i) => {
        const prefix = `domains[${i}]`;
        if (d.dependsOn && Array.isArray(d.dependsOn)) {
          d.dependsOn.forEach(dep => {
            if (!domainIds.has(dep)) failures.push({ type: 'dependency', location: prefix + '.dependsOn', reason: 'Depends on unknown domain: ' + dep, fix: 'Ensure dependsOn references valid domain ids' });
          });
        }
      });

      // Cycle check
      const domains = {};
      dom.domains.forEach(d => { domains[d.id] = (d.dependsOn || []).filter(dep => dep !== d.id); });
      const visited = new Set();
      const inStack = new Set();
      function hasCycle(node) {
        visited.add(node); inStack.add(node);
        for (const dep of domains[node] || []) {
          if (!visited.has(dep)) { if (hasCycle(dep)) return true; }
          else if (inStack.has(dep)) return true;
        }
        inStack.delete(node);
        return false;
      }
      for (const id of Object.keys(domains)) {
        if (!visited.has(id) && hasCycle(id)) {
          failures.push({ type: 'cycle', location: 'dependsOn', reason: 'Cycle detected starting from ' + id, fix: 'Remove cyclic dependencies by re-analyzing domain boundaries' });
          break;
        }
      }
    }

    // ─── sharedRefs 结构校验（顶层）───
    if (dom.sharedRefs !== undefined && !Array.isArray(dom.sharedRefs)) {
      failures.push({ type: 'structure', location: 'sharedRefs', reason: 'sharedRefs must be an array when present', fix: 'Make sharedRefs a top-level array of { file, scope, reason }' });
    }
    const sharedRefs = Array.isArray(dom.sharedRefs) ? dom.sharedRefs : [];
    sharedRefs.forEach((r, i) => {
      const prefix = 'sharedRefs[' + i + ']';
      if (!r || typeof r.file !== 'string' || r.file.trim() === '') failures.push({ type: 'shared-refs', location: prefix + '.file', reason: 'Missing or empty file', fix: 'Each sharedRef needs a non-empty file (pieces/**, specs/** or terms.md)' });
      else if (looksIllegal(r.file) || !isLegalSharedFile(r.file)) failures.push({ type: 'illegal-input', location: prefix + '.file', reason: 'Illegal shared file "' + r.file + '" (must be pieces/**, specs/** or specs/terms.md; design-stage products forbidden)', fix: 'Reference only legal global files' });
      if (!r || typeof r.reason !== 'string' || r.reason.trim() === '') failures.push({ type: 'shared-refs', location: prefix + '.reason', reason: 'Missing or empty reason', fix: 'Each sharedRef needs a reason' });
      if (!r || !['global', 'multi-domain'].includes(r.scope)) failures.push({ type: 'shared-refs', location: prefix + '.scope', reason: 'scope must be "global" or "multi-domain"', fix: 'Set scope to global or multi-domain' });
    });

    // ─── 逐文件覆盖对账（zero-loss，非前缀级）───
    // 收集所有 sourceRefs + sharedRefs 认领的合法源文件（去锚点、去前缀差异按 basename 对账）
    const claimedFiles = new Set();
    if (dom.domains && Array.isArray(dom.domains)) {
      dom.domains.forEach((d) => (d.sourceRefs || []).forEach((r) => r && typeof r.file === 'string' && isLegalSourceFile(r.file) && claimedFiles.add(path.basename(stripAnchor(r.file)))));
    }
    sharedRefs.forEach((r) => r && typeof r.file === 'string' && isLegalSourceFile(r.file) && claimedFiles.add(path.basename(stripAnchor(r.file))));

    // 定位真实 pieces 与 specs 目录：domain.json 在 activeSpecDir/plans 下，
    // 上溯到 activeSpecDir。找不到目录则跳过逐文件对账（运行时无基线，不误报）。
    const domAbsDir = path.dirname(path.resolve(filePath));
    const specDir = path.dirname(domAbsDir); // plans/ 的父 = activeSpecDir
    const enumerateSources = (sub) => {
      const dir = path.join(specDir, sub);
      if (!existsSync(dir)) return [];
      try {
        return readdirSync(dir).filter((f) => f.endsWith('.md')).map((f) => `${sub}/${f}`);
      } catch {
        return [];
      }
    };
    // 只对账 checklist-*.md：specs 下其余 data-model/design/content/terms/point 等不作为必认领源（plan 只读 checklist）
    const actualSources = enumerateSources('specs').filter((f) => path.basename(f).startsWith('checklist-'));
    // 仅当能枚举到真实源文件时才做逐文件兜底（否则运行时无基线，交 LLM 段落自检）
    if (actualSources.length > 0) {
      actualSources.forEach((f) => {
        if (!claimedFiles.has(path.basename(f))) {
          failures.push({ type: 'coverage', location: f, reason: 'Source file not dispatched: "' + f + '" is claimed by neither any domain sourceRefs nor sharedRefs', fix: 'Assign this source file to a domain sourceRefs (vertical) or register it in sharedRefs (horizontal)' });
        }
      });
    }

    dom.openQuestions && Array.isArray(dom.openQuestions) && dom.openQuestions.forEach((q, i) => {
      const prefix = 'openQuestions[' + i + ']';
      if (!q.priority || !['P0', 'P1'].includes(q.priority)) failures.push({ type: 'schema', location: prefix + '.priority', reason: 'Priority must be P0 or P1', fix: 'Set priority to P0 or P1 per dead rules' });
      if (!q.backtrackSignal || typeof q.backtrackSignal !== 'string' || q.backtrackSignal.trim() === '') failures.push({ type: 'schema', location: prefix + '.backtrackSignal', reason: 'Missing or empty backtrackSignal', fix: 'Provide an observable backtrack signal' });
    });

    dom.assumptions && Array.isArray(dom.assumptions) && dom.assumptions.forEach((a, i) => {
      const prefix = 'assumptions[' + i + ']';
      if (!a.impactIfInvalid || typeof a.impactIfInvalid !== 'string') failures.push({ type: 'schema', location: prefix + '.impactIfInvalid', reason: 'Missing impactIfInvalid', fix: 'Each assumption must have impactIfInvalid' });
    });

    console.log(JSON.stringify({
      ok: failures.length === 0,
      failures
    }));

  } else {
    console.log(JSON.stringify({ ok: false, failures: [{ type: 'usage', location: 'mode', reason: 'Mode must be "domain"', fix: 'Use "domain" as first argument' }] }));
    process.exit(1);
  }
} catch (e) {
  console.log(JSON.stringify({ ok: false, failures: [{ type: 'parse', location: filePath, reason: e.message, fix: 'Ensure file is valid JSON' }] }));
  process.exit(1);
}
