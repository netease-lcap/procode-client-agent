#!/usr/bin/env node

/**
 * 统一 SQL 执行 CLI（DDL + DML + 初始化数据），收口所有 SQL 执行入口。
 *
 * SQL 由调用方按方言生成；一次调用原样提交一次 executeSqlDirect，并产生一份执行证据。
 * 调用方负责提交可独立执行与回放的语句；执行器不解析程序体、不按分号拆分。
 * --type 声明 ddl/dml/probe，--table-name 或动作 tableRef 声明 DML 归档目标。
 * 简单旧调用保留类型/表名推断；无法识别时要求补元数据，不猜为 probe。
 *   - 归档根按归属模块落盘（plan 2026-10-24/stage1-generation-static-and-idempotency-ownership §D6）：
 *       <项目产物根>/<codeModules[].pathBase>/sql/<dataSourceName>/
 *     pathBase 取 plans/backend/_meta/engineering-plan.json，相对**项目产物根**（如 backend/<service> 或
 *     backend/<service>/<module>；与部署侧构建单元同一基准）。多模块工程（codeModules.length > 1）**必须**
 *     带 --module-id；缺参/未命中 ⇒ exit 1（不执行不落盘），**禁**回落聚合根 backend/sql。
 *     单模块工程、或无工程方案（monolith/存量）⇒ 维持 <backendDir>/sql/<ds>/ 旧布局（逐字节兼容）。
 *   - 归档四分路由（scheme/seed 见 plan 2026-09-01、probe 见 plan 2026-09-03）：
 *       单语句 DDL → <归档根>/scheme/；
 *       单语句 DML 且表 ∈ seed-tables.json 清单 → .../seed/；∉ → biz/（只判定，不落盘）；
 *       单语句探测（SELECT/SHOW/DESC/EXPLAIN 等未识别语句）→ probe/（落盘冒烟证据归档）；
 *       `--type` 显式声明归档类别；DML 按目标表的种子清单决定 seed/biz。
 *     仅 scheme|seed|probe 落盘归档；biz 执行照旧但不落盘（业务 DML 不进发布重放，留盘只会
 *     污染已执行清单核对，2026-09-07 收口）。probe 落盘为**冒烟证据归档**（plan 2026-09-21
 *     §B5 rev2 解禁：段 AS SQL 冒烟产物 evidence 交叉核对面，水印带执行结果；只作证据，不进重放）。
 *     清单 = plans/backend/_meta/seed-tables.json（build 波前置种子表识别任务产，本 CLI 机械查表，agent 无判定权）；
 *     仅单语句 DML 时清单是硬依赖（缺失 = fail loud，exit 1，不落盘不执行）——biz 不落盘后清单仍是
 *     seed/biz 判定与漏报探测的权威；DDL/probe 不依赖清单。
 *   - --init-data 降级为「申报」：不影响路由与文件名，仅用于漏报探测——单语句申报种子但被清单路由进 biz
 *     → 输出 claimMismatch（人审补清单，build 期禁手改清单；biz 不落盘）。
 *   - 归档文件名「时间戳-表名.sql」（与 src 平级、不进 jar）；水印带 statements=1 / table=<真名>。
 *   - 执行通道：所有数据库类型（MySQL / PostgreSQL / Oracle / 达梦 / 其他）统一走远端 MCP
 *     executeSqlDirect；本地直连通道（含 PG local）已退役，不向调用方开放 --mode 切换
 *     （plan 2026-11-09/incremental-database-mcp-only-and-local-debug D1/D3/D5）。
 *
 * 用法：
 *   node sql-exec.mjs --sql "<单条 SQL 语句>" [--type ddl|dml|probe] [--table-name <name>] [--init-data] [--data-source-name <p>] [--module-id <id>]
 *   node sql-exec.mjs --file <path.sql | entity-*.md> [...]
 *   归档归属：--module-id（多模块工程必传；决定归档根 = <项目产物根>/<pathBase>/sql/<ds>）
 *   数据源选择：--data-source-name（必填；目标数据源=已确认契约条目名，不回退默认）
 *   执行通道：mcp（所有类型统一远端 executeSqlDirect）；SQL_EXEC_MCP_ENDPOINT / SQL_EXEC_MCP_ENV 可覆盖
 *   任务超时：环境变量 SQL_EXEC_TIMEOUT_MS（缺省 120000，覆盖单条语句执行）
 *   清单定位：环境变量 SEED_TABLES_MANIFEST=<abs path> 显式覆盖（调试用）；缺省从工程产物根向上探测
 *
 * 退出码：数据库明确成功（completed）→ exit 0；一切非成功（列已存在/数据库报错/unknown/
 *   not-executed）→ **统一归档 skipped，不阻断 build，exit 0**；只有门禁/参数/写盘类失败 exit 1。
 *   给了 --action-id 时，每次执行都落 statement/request/response/outcome 四件套到机械派生目录
 *   <归档根>/sql/<dataSourceName>/_evidence/<sanitize(actionId)>/（completed 与 skipped 都写）。
 *   （不做方言错误码签名表：不区分 1060 / 42701 / ORA-01430，非成功一律 skipped。）
 * stdout 输出单行 JSON：{ ok, statements, status, file, msg?, claimMismatch?, receipt?, receiptFile?, receiptSkipped? }
 * （file=null：失败、biz；probe 落盘冒烟证据归档）。
 *
 * ── 增量 SQL 动作 / 执行回执 v3（plan-objectid-retirement §3.2/§5.3）──────────────────
 * `operations.json` 的每个 action 都要能落一份**可持久化**的执行回执（`SqlExecutionReceiptV3`，
 * `shared/database/receipts.ts`）。动作身份与目标**只从 operations v3 读取**，不再由调用方拼对象 id：
 *   --operations <path>                                    operations.json（schemaVersion=3）
 *   --action-id <id> --iteration-id <id>                   动作身份（actionId 原样复制，不重新生成）
 *   --table-ref <json>                                     可选显式目标；给出时必须与 operation.tableRef 逐字相等
 *   --module-id                                            归档/回执模块身份（与 operations[].moduleId 同时存在时必须相等）
 *   --receipt <path>                                       回执落盘路径（原子写：tmp + rename）
 *   --require-module-binding                               强制 --module-id + --data-source-name（禁聚合根/默认库回退）
 *
 * **--source-id / --object-id 已退役**：objectId 退役后目标只认 `operation.tableRef`
 * （sourceId+owner+kind+name）。旧参数传入即 **exit 1**（`RETIRED_ACTION_IDENTITY`），
 * 不静默忽略、不回退到按 actionId 反解表名；缺 --operations/--action-id/--iteration-id 同样拒绝执行。
 *
 * 回执 v3 只保留身份、binding、实际 target、`tableRef`、SQL digest、执行时间、通道、最终状态、
 * 任务引用、错误与归档引用；可选 postcheck 缺席表示未做，不等同通过。执行状态：
 *   · completed      数据库明确成功（MCP 任务 FINISHED）；
 *   · failed         数据库明确失败（MCP 任务 FAILED）；
 *   · unknown        已提交但最终结果未知（响应超时/断连/任务状态非终态）；保留任务引用，**不自动重发**；
 *   · not-executed   提交前失败（连接不上、参数/通道不可用）；attemptedAt 为 null。
 * 传输成功/任务 ID/exit 0 都不能改写为 completed。
 *
 * 纪律（不伪造证据）：
 *   · 身份参数齐全才进入动作模式；缺参 ⇒ **exit 1 且不执行**。完全没传动作参数（非增量动作调用）⇒
 *     保持旧执行行为，输出里带 `receipt:null` 与原因。
 *   · 旧版结构状态参数（--precheck/--postcheck/--expected-before/--expected-after 等）不再受支持，
 *     传入即 **exit 1 并列出参数名**，不静默忽略。
 *   · 执行失败/未知也照写回执——失败证据不能丢；只有 completed 才 exit 0。
 *   · 回执 `sqlDigest` = 对本次提交 SQL 文本 UTF-8 字节取 `sha256:<hex>`，与 C04 `computeSqlDigest` 同口径。
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync, readdirSync, renameSync } from 'fs';
import { createHash } from 'crypto';
import { resolve, join, basename, dirname, sep } from 'path';
import { sanitizeSql } from './shared/sql-text.mjs';
import { resolveExecDatasource } from './shared/mysql-client.mjs';
import { normalizeDatabaseKey } from './shared/dialect-signature.mjs';
import { executeSqlViaMcp, callMcpTool } from './shared/mcp-sql-client.mjs';
import {
  findBackendDir,
  resolveDeclaredBackendRoots,
  resolvePlanBackendDir,
  resolveProjectRoot,
  readFreshMicroEngineeringPlan,
  ENGINEERING_PLAN_V2_SCHEMA_VERSION,
} from './shared/backend-common.mjs';
// D13 判据**单源**住 extract-code-schema.mjs（该脚本有 main 守卫，import 不触发执行）；
// 本脚本只消费，不另写第二份「per-module 显式解析 / 禁回退」逻辑。
import { resolveDesignTimeDatasource } from './extract-code-schema.mjs';

function die(msg) {
  console.error(`[sql-exec] 失败：${msg}`);
  process.exit(1);
}

// ── 帮助 ─────────────────────────────────────────────────────────────────────
function printHelp() {
  console.log(`sql-exec.mjs — 统一 SQL 执行 CLI（DDL/DML/初始化数据）

用法（SQL 执行模式）：
  node sql-exec.mjs --sql "<SQL 脚本>" [选项]
  node sql-exec.mjs --file <path.sql | entity-*.md> [选项]

选项（SQL 执行模式）：
  --sql <text>       内联完整 SQL，原样提交；调用方负责语句独立与回放完整性
  --file <path>      读 SQL 文件；.md 则抽取第一个 \`\`\`sql 代码块
  --type ddl|dml|probe  归档类型；复杂方言语句须显式声明，执行 SQL 不做语法校验
  --table-name <name>  DML 归档目标；动作模式可从 operations.tableRef.name 取得
  --init-data        种子数据申报（仅单语句 DML 生效；仅供漏报探测：申报种子但清单无此表 → claimMismatch 警告）
  --data-source-name <p>  目标数据源标识（归档分桶；mcp 模式作为 dbName 定位远端数据源）
  --module-id <id>        归档归属模块（工程方案 codeModules[].moduleId）：
                          命中 ⇒ 归档根 = <项目产物根>/<该模块 pathBase>/sql/<dataSourceName>；
                          工程方案有多个 codeModules 时**必传**（缺参/未命中 ⇒ exit 1，不执行不落盘，禁回落聚合根 backend/sql）。
                          同时用于 per-module（D13）粒度下按模块解析 dataSourceName（查 _meta/datasource-binding.json）；
                          per-module 粒度下两者都缺 ⇒ 拒绝回退契约默认条目。
                          与 --data-source-name **不互斥**：前者决定归档与服务归属，后者决定数据源。

增量 SQL 动作 / 执行回执 v3（可选；传了任一动作参数即进入动作模式，参数不全 ⇒ exit 1 不执行）：
  --operations <path>         operations.json（schemaVersion=3）；动作目标只从这里读，禁止按 actionId 反解表名
  --action-id <id>            原样复制 operations[].actionId（不重新生成）
  --iteration-id <id>         本轮迭代 id，必须与 operations.iterationId 一致
  --table-ref <json>          可选显式目标 {"sourceId","owner","kind":"table","name"}；
                              给出时必须与 operations[].tableRef 四字段逐字相等，否则 exit 1
  --receipt <path>            回执落盘路径（原子写 tmp+rename）；给了却写不出来 ⇒ exit 1
  --require-module-binding    强制同时给 --module-id 与 --data-source-name：
                              缺任一 ⇒ exit 1（不执行不落盘），禁回退聚合根/默认库（增量轮硬约束）

  --source-id / --object-id 已退役：传入即 exit 1（错误码 RETIRED_ACTION_IDENTITY），
  不静默忽略，也不按旧 id 猜表；请改用 --operations + --action-id。

  执行证据（plan 2026-11-08）：给了 --action-id 就机械派生
  <归档根>/sql/<dataSourceName>/_evidence/<sanitize(actionId)>/，每次执行都落
  statement.sql / request.json / response.json / outcome.json（不接受调用方指定路径）。
  outcome.status 只有 completed|skipped；一切非成功统一 skipped，不阻断 build。
  证据写盘失败不掩盖执行结果：stderr 警告 + outcome.evidenceWriteError。

  回执 schemaVersion=3：tableRef（sourceId+owner+kind+name）替代 sourceId/objectId；
  只有身份/binding/target/sqlDigest/执行结果（可选 postcheck）；不再接收
  --precheck/--postcheck/--expected-before/--expected-after/--*-digest 等旧结构状态参数，
  传入 ⇒ exit 1 并列出参数名（不做静默忽略）。
  执行状态（以数据库实际结果为准，传输成功/任务 ID 不等于成功）：
    completed     数据库明确成功
    failed        数据库明确失败
    unknown       已提交但最终结果未知（保留任务引用；不自动重发）
    not-executed  提交前失败（连接/参数/未提交）

归档根（plan 2026-10-24 §D6，先验后执行：任何 die 都在连接/执行/落盘之前）：
  归档根 = <项目产物根>/<codeModules[].pathBase>/sql/<dataSourceName>/，pathBase 相对项目产物根
  （如 backend/<service> 或 backend/<service>/<module>）。
  · 多模块工程（engineering-plan.json codeModules.length > 1）：必须带 --module-id <该表/DDL 所属模块>；
    缺参/未命中 → exit 1，不执行不落盘（禁止把多服务产物混在聚合根 backend/sql）。
  · 单模块工程 或 无工程方案（monolith/存量）→ 回落 <backendDir>/sql/<dataSourceName>/（旧布局逐字节兼容）。

执行与归档契约：
  一次调用原样提交一份 SQL，不按分号拆分或改写；数据库判断语法并返回实际执行结果。
  调用方负责语句自包含，不依赖跨调用的会话状态。非动作模式失败 exit 1；动作模式按回执记录并返回 skipped。

归档四分路由（类型由 --type 声明，DML 目标由 --table-name 或动作 tableRef 提供；简单旧调用可推断）：
  单语句 DDL → <backendDir>/sql/<dataSourceName>/scheme/
  单语句 DML 且表 ∈ <plans>/backend/_meta/seed-tables.json → .../seed/；∉ → biz/（不落盘）
  单语句探测语句（SELECT/SHOW/DESC/EXPLAIN 等）→ probe/（冒烟证据归档，带结果水印，不进重放）；
    无法推断的语句必须显式提供 --type，不把未知写操作冒充 probe
  单语句 DML 时清单缺失 → 拒绝执行（fail loud，exit 1）；清单由 build 波前置种子表识别任务产出，禁手改。
  多语句提交 → fail loud（拆分责任在提交方；框架侧 delta.sql 由生成脚本拆成序号文件逐个提交）。

选项（建库模式 --database）：
  --database                 切到建库模式：调 MCP ProAppDatabaseController.create 在沙箱内为应用建库
                              （不走 SQL 执行路径，不归档 .sql 文件）
  --app-id <str>             应用 ID（必填；沙箱 env APP_ID 注入，不再从 db-config 读取）
  --used-datasource-list <JSON array string>
                            已使用的数据源名列表，平台据此算下一个 seq 避开占用（缺省 []）

选项（登记 circlePort 模式 --update-circle-port）：
  --update-circle-port       切到登记模式：调 MCP InternalAppDatabaseProxyController.updateCirclePort
                              把 sbx-outbound 拿到的 loopbackPort 写入 dev 环境行（代理解析时用作本地端口），
                              不走 SQL 执行路径，不归档 .sql 文件
  --app-id <str>             应用 ID（必填；同 --database 模式）
  --data-source-name <str>   数据源名（必填；取 4b 上一步 app_database_create 返回的 result.dataSourceName）
  --circle-port <str>        沙箱回环端口（必填；取 sbx-outbound add stdout.loopbackPort 字符串化）

执行通道：mcp（MySQL 固定走远端 executeSqlDirect，本地直连通道已退役）；mcp 下 SQL_EXEC_MCP_ENDPOINT / SQL_EXEC_MCP_ENV 可覆盖
  注：--database / --update-circle-port 模式始终走 mcp 通道（建库 / 登记 circlePort 只能调远端 MCP server）。

退出码：
  - SQL 模式：数据库明确成功（completed）→ exit 0；失败/未知/未提交/多语句 → exit 1
    （failed / unknown / not-executed 均不通过；unknown 不自动重发）
  - 建库模式：建库失败/缺 appId → exit 1；建库成功 → exit 0
  - 登记 circlePort 模式：MCP 调用失败/缺参 → exit 1；成功 → exit 0

stdout 输出单行 JSON：
  - SQL 模式：{ ok, statements, status, file, msg?, claimMismatch?, receipt?, receiptFile?, receiptSkipped? }
  - 建库模式：{ ok, result? {dataSourceName,databaseName,databaseHost,databasePort,...}, error? }
  - 登记 circlePort 模式：{ ok, result?, error? }
`);
}

// ── 参数解析 ─────────────────────────────────────────────────────────────────
function parseArgs(argv) {
  const args = {
    sql: null,
    file: null,
    type: null,
    tableName: null,
    initData: false,
    dataSourceName: null,
    // D13：per-module 粒度下按模块解析 dataSourceName（binding envelope 的键）——
    // 与 --data-source-name 二选一；两者都给时以显式 --data-source-name 为准。
    moduleId: null,
    // 增量 SQL 动作回执 v3（objectId 退役）：目标只从 operations v3 读取。
    requireModuleBinding: false,
    operations: null,
    actionId: null,
    iterationId: null,
    tableRef: null,
    receipt: null,
    // 已退役的动作身份参数：解析期收集，统一报迁移错误（不静默忽略）。
    retiredActionFlags: [],
    // 旧版结构状态参数：解析期收集，统一报错拒绝（不静默忽略）。
    legacyActionFlags: [],
    // --database 模式（2026-08-XX）：建库模式，不走 SQL 执行路径
    database: false,
    appId: null,
    usedDatasourceList: null,
    // --update-circle-port 模式：登记 sbx-outbound 拿到的 loopbackPort 到 dev 环境行
    updateCirclePort: false,
    circlePort: null,
    // 代码根声明（D5）：显式根 / 活跃 spec 目录，供共享 resolveDeclaredBackendRoots 使用。
    backendRoots: [],
    activeSpecDir: null,
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    switch (a) {
      case '--sql': args.sql = argv[++i]; break;
      case '--file': args.file = argv[++i]; break;
      case '--type': args.type = argv[++i]; break;
      case '--table-name': args.tableName = argv[++i]; break;
      case '--init-data': args.initData = true; break; // 申报语义（见 header）：不参与路由/命名
      // --data-source-name 在 SQL 执行模式与 --update-circle-port 模式共用：
      // SQL 模式作为归档分桶 + mcp dbName 定位；update-circle-port 模式作 MCP 入参 dataSourceName
      case '--data-source-name': args.dataSourceName = argv[++i]; break;
      case '--module-id': args.moduleId = argv[++i]; break;
      case '--require-module-binding': args.requireModuleBinding = true; break;
      case '--operations': args.operations = argv[++i]; break;
      case '--action-id': args.actionId = argv[++i]; break;
      case '--iteration-id': args.iterationId = argv[++i]; break;
      case '--table-ref': args.tableRef = argv[++i]; break;
      // objectId 退役后的旧目标参数：收集后统一报迁移错误（不静默忽略、不猜表）。
      case '--source-id':
      case '--object-id': {
        args.retiredActionFlags.push(a);
        const next = argv[i + 1];
        if (next !== undefined && !String(next).startsWith('-')) i += 1;
        break;
      }
      // v2 已删除、v3 继续拒绝的结构状态参数：收集后统一拒绝（旧调用方必须显式升级）。
      case '--precheck':
      case '--postcheck':
      case '--expected-before':
      case '--expected-after':
      case '--precheck-status':
      case '--actual-digest':
      case '--postcheck-status':
      case '--postcheck-actual-digest':
      case '--postcheck-query-ref':
      case '--query-ref': {
        args.legacyActionFlags.push(a);
        const next = argv[i + 1];
        // 这些参数历史上都带值；只吞非 flag 值，避免把后续参数吃掉。
        if (next !== undefined && !String(next).startsWith('-')) i += 1;
        break;
      }
      case '--receipt': args.receipt = argv[++i]; break;
      case '--database': args.database = true; break;
      case '--app-id': args.appId = argv[++i]; break;
      case '--used-datasource-list': args.usedDatasourceList = argv[++i]; break;
      case '--update-circle-port': args.updateCirclePort = true; break;
      case '--circle-port': args.circlePort = argv[++i]; break;
      case '--backend-root': args.backendRoots.push(resolve(argv[++i])); break;
      case '--active-spec-dir': args.activeSpecDir = resolve(argv[++i]); break;
      case '--help': case '-h': printHelp(); process.exit(0); break;
      default: break; // 未知参数忽略
    }
  }
  if (args.legacyActionFlags.length > 0) {
    const flags = [...new Set(args.legacyActionFlags)];
    die(
      `执行回执已升级为 v3，不再接受结构状态类参数：${flags.join('、')}。` +
        '请移除这些参数后重跑（执行结果以数据库实际结果为准：completed/failed/unknown/not-executed）；' +
        'precheck/postcheck/expected-before-after 与结构摘要已从契约删除，旧结论不能作为成功依据。',
    );
  }
  return args;
}

// ── 读取 SQL 文本（内联 / 文件 / entity-*.md 抽取 ```sql 块）──────────────────
function readSql(args) {
  if (args.sql) return args.sql;
  if (!args.file) return null;
  const p = resolve(args.file);
  if (!existsSync(p)) die(`SQL 文件不存在：${args.file}`);
  const text = readFileSync(p, 'utf-8');
  if (/\.md$/i.test(p)) {
    const m = text.match(/```sql\s*\n([\s\S]*?)```/i);
    if (!m) die(`entity md 未找到 sql 代码块：${args.file}`);
    return m[1];
  }
  return text;
}

// ── 注释剥离（分类/识别专用：切分器把注释并进语句文本，直接正则会把带注释的 INSERT
// 误判成 ddl/probe——0904 事故归档里 4 条带注释 INSERT 全被标 type=ddl、table= 丢失）────────
function stripComments(sql) {
  let out = '';
  let i = 0;
  let inLine = false;
  let inBlock = false;
  let quote = null;
  while (i < sql.length) {
    const c = sql[i];
    const next = sql[i + 1];
    if (inLine) {
      if (c === '\n') { inLine = false; out += c; }
      i++;
      continue;
    }
    if (inBlock) {
      if (c === '*' && next === '/') { inBlock = false; i += 2; continue; }
      i++;
      continue;
    }
    if (quote) {
      out += c;
      if (c === '\\' && quote !== '`') { out += next || ''; i += 2; continue; }
      if (c === quote) quote = null;
      i++;
      continue;
    }
    if (c === '-' && next === '-') { inLine = true; i += 2; continue; }
    if (c === '#') { inLine = true; i++; continue; }
    if (c === '/' && next === '*') { inBlock = true; i += 2; continue; }
    if (c === "'" || c === '"' || c === '`') { quote = c; out += c; i++; continue; }
    out += c;
    i++;
  }
  return out;
}

// ── 类型 + 表名识别 ──────────────────────────────────────────────────────────
function stripIdent(name) {
  return String(name || '').replace(/^`/, '').replace(/`$/, '').replace(/[;,]/, '').trim();
}

function detectStatement(stmt) {
  const s = stmt.trim();
  let m;
  if ((m = s.match(/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([^\s(]+)/i))) {
    return { type: 'ddl', table: stripIdent(m[1]) };
  }
  if ((m = s.match(/^ALTER\s+TABLE\s+`?([^\s]+)/i))) return { type: 'ddl', table: stripIdent(m[1]) };
  if ((m = s.match(/^(?:DROP|TRUNCATE)\s+TABLE\s+`?([^\s]+)/i))) return { type: 'ddl', table: stripIdent(m[1]) };
  if ((m = s.match(/^CREATE\s+(?:UNIQUE\s+)?INDEX\s+`?[^\s]+`?\s+ON\s+`?([^\s(]+)/i))) {
    return { type: 'ddl', table: stripIdent(m[1]) };
  }
  if ((m = s.match(/^INSERT\s+INTO\s+`?([^\s(]+)/i))) return { type: 'dml', table: stripIdent(m[1]) };
  if ((m = s.match(/^REPLACE\s+INTO\s+`?([^\s(]+)/i))) return { type: 'dml', table: stripIdent(m[1]) };
  if ((m = s.match(/^UPDATE\s+(?:IGNORE\s+|LOW_PRIORITY\s+)?`?([^\s]+)/i))) return { type: 'dml', table: stripIdent(m[1]) };
  if ((m = s.match(/^DELETE\s+FROM\s+`?([^\s]+)/i))) return { type: 'dml', table: stripIdent(m[1]) };
  // 兜底：按首关键字粗判
  if (/^(CREATE|ALTER|DROP|TRUNCATE|RENAME)\b/i.test(s)) return { type: 'ddl', table: null };
  if (/^(INSERT|UPDATE|DELETE|REPLACE|MERGE)\b/i.test(s)) return { type: 'dml', table: null };
  if (/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN)\b/i.test(s)) return { type: 'probe', table: null };
  return { type: null, table: null };
}

// ── 执行证据目录名（actionId 只做安全字符替换，不参与语义）──────────────────────
function sanitizeActionIdForDir(actionId) {
  return String(actionId ?? '').replace(/[^A-Za-z0-9._-]/g, '_') || 'action';
}

// ── 时间戳 ───────────────────────────────────────────────────────────────────
function formatTimestamp(d) {
  const p = (n, w = 2) => String(n).padStart(w, '0');
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}${p(d.getMilliseconds(), 3)}`;
}

// ── 归档文件名（同秒/同名冲突：查磁盘追加序号，保证跨调用不覆盖、顺序存储）──────────
// 三分（scheme/seed/biz）体现在父目录而非文件名；-init 后缀随归档语义收口而废弃。
function makeArchiveName(archiveDir, ts, table, type) {
  const base = table || type || 'stmt';
  let name = `${ts}-${base}.sql`;
  let n = 2;
  while (existsSync(join(archiveDir, name))) {
    name = `${ts}-${base}-${n}.sql`;
    n++;
  }
  return name;
}

// ── 水印（标识 + 审计元信息，写入归档 .sql 头部，便于识别与回放溯源）────────────────
const SQL_EXEC_WATERMARK_TAG = '[sql-exec]';

function buildWatermark(ts, table, type, bucket, initData, statements, result) {
  const meta = [
    `auto-generated ${ts}`,
    table ? `table=${table}` : null,
    `type=${type}`,
    bucket ? `bucket=${bucket}` : null,
    Number.isFinite(statements) ? `statements=${statements}` : null,
    initData ? 'claimed-seed' : null,
    // probe 归档的执行结果（plan 2026-09-21 §B5 rev2：冒烟证据交叉核对面——文件在且执行过，
    // rows 为 SELECT 回显行数；mcp 通道无行数回显则只记 ok）。
    result ? `result=${result}` : null,
  ].filter(Boolean).join(' · ');
  return `-- ${SQL_EXEC_WATERMARK_TAG} ${meta}\n-- 由 sql-exec CLI 统一收口生成，请勿手改（审计/回放用途；probe 桶只作冒烟证据，不进发布重放）。\n`;
}

// ── seed 清单解析（DML 归档路由的权威数据源，plans/seed-inventory 阶段产）───────────
/** 向上探测 plans/backend/_meta/seed-tables.json（直接子目录 plans/，或 docs/<ts>/plans/，最新优先）。
 *  与 mysql-client.mjs findDbConfigJson 同语义但不依赖其内部；SEED_TABLES_MANIFEST 显式覆盖。最多 8 层。 */
function findSeedManifestPath(workdir) {
  if (process.env.SEED_TABLES_MANIFEST) return process.env.SEED_TABLES_MANIFEST;
  let dir = workdir;
  for (let i = 0; i < 8; i++) {
    const direct = resolve(dir, 'plans', 'backend', '_meta', 'seed-tables.json');
    if (existsSync(direct)) return direct;
    const docsDir = resolve(dir, 'docs');
    if (existsSync(docsDir)) {
      let names = [];
      try {
        names = readdirSync(docsDir);
      } catch {
        names = [];
      }
      for (const n of names.sort().reverse()) {
        const p = resolve(docsDir, n, 'plans', 'backend', '_meta', 'seed-tables.json');
        if (existsSync(p)) return p;
      }
    }
    const parent = resolve(dir, '..');
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

/** 载入 seed 清单 → { manifestPath, seedKeys:Set('ds\0table' + '*\0table' 通配键) }。文件不存在返回 null。
 *  表名/ds 一律小写折叠比对（清单侧 check-seed-tables 已保证表名字符合法+去重）。 */
function loadSeedManifest(workdir, dsName) {
  const manifestPath = findSeedManifestPath(workdir);
  if (!manifestPath || !existsSync(manifestPath)) return null;
  let doc;
  try {
    doc = JSON.parse(readFileSync(manifestPath, 'utf-8'));
  } catch (e) {
    die(`seed-tables.json 已存在但解析失败（${manifestPath}）：${e.message}。清单由 build 波前置种子表识别任务产出，禁止手改——如确为脏数据请重跑该任务（build 波 seed-tables stage）。`);
  }
  const seedKeys = new Set();
  for (const t of Array.isArray(doc.tables) ? doc.tables : []) {
    if (!t || typeof t.table !== 'string') continue;
    const tableK = t.table.toLowerCase();
    if (typeof t.dataSourceName === 'string' && t.dataSourceName.trim()) {
      seedKeys.add(`${t.dataSourceName.trim().toLowerCase()}\0${tableK}`);
    } else {
      seedKeys.add(`*\0${tableK}`);
    }
  }
  return { manifestPath, seedKeys, dsName: (dsName || '').toLowerCase() };
}

function isSeedTable(m, table) {
  if (!m || !table) return false;
  const k = table.toLowerCase();
  return m.seedKeys.has(`${m.dsName}\0${k}`) || m.seedKeys.has(`*\0${k}`);
}

// ── 归档根解析：按归属模块落盘（plan 2026-10-24 §D6）─────────────────────────────
// 真值 = 工程方案 codeModules[].pathBase（与部署侧 maven-build-unit.ts 同一基准：相对**项目产物根**，
// 形如 backend/<service> 或 backend/<service>/<module>）。0-1 后端根目录名不动，只是 SQL 从聚合根下沉。
//
// 三支机械判定（先验后执行：所有 die 都在连接/执行/落盘之前）：
//   ① 给了 --module-id：命中 codeModules → <projectRoot>/<pathBase>/sql/<ds>；未命中 ⇒ die（列可用 id）。
//   ② 工程方案可读且 codeModules.length > 1、未给 --module-id ⇒ die（禁回落 <backendDir>/sql 混装多服务产物）。
//   ③ 无工程方案（monolith/存量）或单模块 ⇒ <backendDir>/sql/<ds>（旧布局逐字节兼容）。
//
// 注：--module-id 与 --data-source-name 可并存——前者决定归档/服务归属，后者决定数据源，互不替代
// （D13 的 per-module 数据源解析仍由 resolveDesignTimeDatasource 单独负责）。
function normalizePathBase(pathBase) {
  return String(pathBase || '').replace(/\\/g, '/').replace(/^\.\//, '').replace(/\/+$/, '');
}

/**
 * 增量工程方案（外层 schemaVersion="2"、scenario="incremental"）的模块读面。
 *
 * v1 fresh-micro 读器只认 schemaVersion="1" ∧ scenario="fresh" ∧ form="micro"；
 * v2 增量方案带同一份 codeModules[].{moduleId,pathBase}，是 SQL 归档归属的等价真值。
 * 这里只在「归档归属」这一读面接受 v2 增量：
 *   · 返回 null = 不是 v2 增量方案（交给 fresh 读器的 invalid 理由；未知版本/形态仍 fail loud）；
 *   · state='invalid' = 是 v2 增量方案但 malformed（坏模块/重复 id/缺 pathBase 等），
 *     **不得**过滤成「若干可用模块」后继续；
 *   · state='present' = 契约完整的模块列表。
 * 版本是字符串 "2"（工程方案契约），与执行回执的数字 schemaVersion 2 无关。
 */
function readIncrementalPlanModules(planPath) {
  if (!planPath || !existsSync(planPath)) return null;
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(planPath, 'utf-8'));
  } catch {
    return null; // 坏 JSON 由 fresh 读器给统一 invalid 理由
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
  if (parsed.schemaVersion !== ENGINEERING_PLAN_V2_SCHEMA_VERSION || parsed.scenario !== 'incremental') return null;

  const invalid = (reason) => ({ state: 'invalid', planPath, reason, modules: [] });
  if (!Array.isArray(parsed.codeModules) || parsed.codeModules.length === 0) {
    return invalid(`增量工程方案 codeModules[] 缺失或为空：${planPath}`);
  }
  const modules = [];
  const seen = new Set();
  for (let index = 0; index < parsed.codeModules.length; index += 1) {
    const raw = parsed.codeModules[index];
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
      return invalid(`增量工程方案 codeModules[${index}] 不是对象：${planPath}`);
    }
    const moduleId = typeof raw.moduleId === 'string' ? raw.moduleId.trim() : '';
    if (!moduleId) {
      return invalid(`增量工程方案 codeModules[${index}] 缺 moduleId：${planPath}`);
    }
    if (seen.has(moduleId)) {
      return invalid(`增量工程方案 codeModules[] moduleId 重复：${moduleId}（${planPath}）`);
    }
    seen.add(moduleId);
    const pathBase = typeof raw.pathBase === 'string' ? raw.pathBase.trim() : '';
    if (!pathBase) {
      return invalid(`增量工程方案模块 "${moduleId}" 缺 pathBase（禁按模块名猜目录）：${planPath}`);
    }
    const normalized = normalizePathBase(pathBase);
    const segments = normalized.split('/').filter(Boolean);
    if (!normalized || normalized.startsWith('/') || segments.some((s) => s === '.' || s === '..')) {
      return invalid(
        `增量工程方案模块 "${moduleId}" 的 pathBase 非法：${JSON.stringify(raw.pathBase)}` +
          `——须是相对项目产物根的路径（如 backend/<service>[/<module>]），不含绝对路径前缀或 \`..\` 段（${planPath}）`,
      );
    }
    modules.push({ moduleId, pathBase });
  }
  return { state: 'present', planPath, modules };
}

/** 工程方案读面：legacy（无文件）不算错误；invalid（在场但自描述不符）必须 fail loud——
 *  否则「新格式不被旧读取器支持」会被伪装成「没有工程方案」而静默回落到聚合根。 */
function readEngineeringPlanModules(planBackendDir) {
  if (!planBackendDir) return { state: 'absent', planPath: null, modules: [] };
  const read = readFreshMicroEngineeringPlan(planBackendDir);
  if (read.kind === 'legacy') return { state: 'absent', planPath: read.planPath, modules: [] };
  if (read.kind === 'invalid') {
    const incremental = readIncrementalPlanModules(read.planPath);
    if (incremental?.state === 'invalid') {
      return { state: 'invalid', planPath: read.planPath, reason: incremental.reason, modules: [] };
    }
    if (incremental?.state === 'present') {
      return { state: 'present', planPath: read.planPath, modules: incremental.modules };
    }
    return { state: 'invalid', planPath: read.planPath, reason: read.reason, modules: [] };
  }
  const modules = (Array.isArray(read.plan.codeModules) ? read.plan.codeModules : [])
    .filter((m) => m && typeof m === 'object' && !Array.isArray(m))
    .map((m) => ({
      moduleId: typeof m.moduleId === 'string' ? m.moduleId.trim() : '',
      pathBase: typeof m.pathBase === 'string' ? m.pathBase.trim() : '',
    }))
    .filter((m) => m.moduleId);
  const duplicate = modules.find((m, index) => modules.findIndex((other) => other.moduleId === m.moduleId) !== index);
  if (duplicate) {
    return {
      state: 'invalid',
      planPath: read.planPath,
      reason: `工程方案 codeModules[] moduleId 重复：${duplicate.moduleId}（${read.planPath}）`,
      modules: [],
    };
  }
  return { state: 'present', planPath: read.planPath, modules };
}

/** `<projectRoot>/<pathBase>/sql/<ds>`。pathBase 首段须等于 backendDir 目录名，否则 die（写明期望与实际，不猜）。 */
function moduleArchiveDir(projectRoot, backendDir, module, dsName) {
  const normalized = normalizePathBase(module.pathBase);
  const segments = normalized.split('/').filter(Boolean);
  // pathBase 会被拼进写盘路径：绝对路径 / `..` 逃逸一律拒绝（工程方案缺口，不猜也不修）。
  if (!normalized || normalized.startsWith('/') || segments.some((s) => s === '.' || s === '..')) {
    die(
      `工程方案模块 "${module.moduleId}" 的 pathBase 非法：${JSON.stringify(module.pathBase)}——` +
        '须是相对项目产物根的路径（如 backend/<service>[/<module>]），不含绝对路径前缀或 `..` 段。',
    );
  }
  const backendRootName = basename(backendDir);
  if (segments[0] !== backendRootName) {
    die(
      `工程方案模块 "${module.moduleId}" 的 pathBase 首段与后端产物根目录名不一致：` +
        `期望 "${backendRootName}"（findBackendDir 定位到 ${backendDir}），实际 "${segments[0]}"（pathBase=${normalized}）。` +
        'pathBase 约定相对项目产物根且首段即后端根目录名；不按目录猜测归属，请修正工程方案或 --module-id。',
    );
  }
  return resolve(projectRoot ?? dirname(backendDir), ...segments, 'sql', dsName);
}

/**
 * 多代码根 → 单根消费者（归档门禁）用的根。
 *
 * 单根直接采用；多根时只认**声明里本身是其余所有根祖先**的聚合根（工程方案 aggregate /
 * parent-child 形态的根构建单元，如 `backend` 与 `backend/<svc>`）。无此类聚合根 = 无法唯一
 * 确定，返回 null 由调用方报候选，禁止取公共祖先/任选一根去猜。
 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/**
 * 代码根定位（D5）：声明/显式根优先，启发式 `findBackendDir` 仅兜底并打 warning。
 *
 * 为什么锚定项目产物根（plan 2026-10-24 §R5/D6 的漂移形态）：agent 常从服务目录
 * `<project>/backend/<svc>` 执行 sql-exec，此时按 cwd 解析会把**服务目录**当后端根、
 * `resolvePlanBackendDir(cwd)` 找不到工程方案 ⇒ 多模块归档门禁失效并静默落回 `<service>/sql`，
 * 归档位置又随 cwd 漂移。归档归属必须锚定项目产物根，而不是 cwd。
 */
function resolveArchiveBackendRoot(args, projectRoot, cwd, activeSpecDir) {
  const baseRoot = projectRoot ?? cwd;
  const declared = resolveDeclaredBackendRoots({
    activeSpecDir: args.activeSpecDir ?? activeSpecDir,
    rootDir: baseRoot,
    explicitRoots: args.backendRoots,
  });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[sql-exec] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[sql-exec] 代码根存在多个且无声明聚合根，无法唯一确定归档根：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root（聚合根），或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[sql-exec] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(baseRoot) ?? (baseRoot === cwd ? null : findBackendDir(cwd));
  if (legacy) {
    console.warn(`[sql-exec] 未找到代码根声明，回落启发式 findBackendDir：${legacy}（建议补齐代码根声明）`);
  }
  return legacy;
}

function resolveArchiveDir(backendDir, projectRoot, planBackendDir, moduleId, dsName) {
  const legacyDir = resolve(backendDir, 'sql', dsName);
  const plan = readEngineeringPlanModules(planBackendDir);
  if (plan.state === 'invalid') {
    die(
      `工程方案不可读，无法判定 SQL 归档归属：${plan.reason}（${plan.planPath}）。` +
        '禁止静默回落聚合根 backend/sql（治理责任面 = 工程方案生产任务）。',
    );
  }
  const wanted = typeof moduleId === 'string' && moduleId.trim() ? moduleId.trim() : '';
  if (wanted) {
    const hit = plan.modules.find((m) => m.moduleId === wanted);
    if (!hit) {
      const available = plan.modules.map((m) => m.moduleId);
      die(
        `--module-id "${wanted}" 不在工程方案 codeModules[]（${plan.planPath || '工程方案缺席'}）——` +
          `可用 moduleId：${available.length ? available.join('、') : '（无）'}。` +
          '模块 id 须逐字符照抄工程方案；无工程方案时不能凭 --module-id 指定归档目录。',
      );
    }
    if (!hit.pathBase) {
      die(
        `工程方案 codeModules[] 中模块 "${wanted}" 缺 pathBase，无法判定 SQL 归档目录（禁按模块名猜目录）：${plan.planPath}`,
      );
    }
    return moduleArchiveDir(projectRoot, backendDir, hit, dsName);
  }
  if (plan.modules.length > 1) {
    const available = plan.modules.map((m) => m.moduleId);
    die(
      `工程方案有 ${plan.modules.length} 个 codeModules（${available.join('、')}），未给 --module-id ⇒ 无法判定这条 SQL 的归档归属；` +
        '禁止回落到聚合根 <backendDir>/sql 把多服务产物混在一起（plan 2026-10-24 §D6）。' +
        `请补 --module-id <该表/DDL 所属模块>（可用：${available.join('、')}）。` +
        '--module-id 与 --data-source-name 可并存：前者决定归档与服务归属，后者决定数据源。',
    );
  }
  return legacyDir;
}

// ── 增量 SQL 动作回执 v3（plan-objectid-retirement §3.2/§5.3 / C04 SqlExecutionReceiptV3）──
// 契约单源：spec-server `config/shared/database/receipts.ts` + `validate.ts::validateSqlExecutionReceipt`。
// 这里只**产出**回执，不做裁决；状态必须来自数据库实际结果（传输成功/任务 id 不等于 SQL 成功）。
const RECEIPT_SCHEMA_VERSION = 3; // 数字版本，与工程方案的字符串版本 "1"/"2" 是不同契约
const OPERATIONS_SCHEMA_VERSION = 3;
const EXECUTION_STATUSES = ['completed', 'failed', 'unknown', 'not-executed'];

/** 与 C04 `computeSqlDigest` 同口径：对 SQL 文本 UTF-8 字节取 `sha256:<hex>`。 */
function sqlDigestOf(text) {
  return `sha256:${createHash('sha256').update(String(text ?? ''), 'utf8').digest('hex')}`;
}

/**
 * 严格校验 tableRef：精确 {sourceId, owner, kind, name}，kind 必须 table。
 * 不 trim、不转小写、不剥 schema 前缀；owner 无值必须显式 null。
 * 返回规范化四字段对象（原值逐字保留），非法时 die（错误码随 label 区分）。
 */
function normalizeTableRef(raw, label, code) {
  const fail = (reason) => die(`[${code}] ${label} ${reason}`);
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    fail('必须是 {sourceId, owner, kind, name} 对象');
  }
  const expectedKeys = ['kind', 'name', 'owner', 'sourceId'];
  const keys = Object.keys(raw).sort();
  if (keys.length !== expectedKeys.length || !keys.every((key, index) => key === expectedKeys[index])) {
    fail('必须精确为 {sourceId, owner, kind, name}（owner 无值写 null；不得携带 objectId 等旧字段）');
  }
  const nonBlank = (value) => typeof value === 'string' && value.trim().length > 0;
  if (!nonBlank(raw.sourceId)) fail('的 sourceId 必须是非空、非纯空白字符串');
  if (!(raw.owner === null || nonBlank(raw.owner))) fail('的 owner 必须是字符串或显式 null');
  if (raw.kind !== 'table') fail('的 kind 必须为 table（表级动作不引用 view/sequence/other）');
  if (!nonBlank(raw.name)) fail('的 name 必须是非空、非纯空白字符串');
  return { sourceId: raw.sourceId, owner: raw.owner, kind: 'table', name: raw.name };
}

/** 四字段逐字相等；不做任何归一化。 */
function sameTableRef(a, b) {
  return a.sourceId === b.sourceId && a.owner === b.owner && a.kind === b.kind && a.name === b.name;
}

/** 显式 --table-ref：JSON 解析 + 严格校验（错误码 TABLE_REF_INVALID）。 */
function parseExplicitTableRef(rawText) {
  let parsed;
  try {
    parsed = JSON.parse(rawText);
  } catch (e) {
    die(`[TABLE_REF_INVALID] --table-ref 必须是 JSON 对象：${e.message}`);
  }
  return normalizeTableRef(parsed, '--table-ref', 'TABLE_REF_INVALID');
}

/**
 * 读 operations v3 并按 actionId 唯一定位本条动作（先验后执行；失败即 exit 1）。
 *
 * 禁止按表名/序号猜动作：找不到即拒绝；同一 actionId 出现多次即拒绝（不任选其一）。
 * 返回 { tableRef, moduleId, inputRevision, operation }，供回执与证据共用同一目标。
 */
function loadOperationsAction(operationsPath, iterationId, actionId) {
  const fullPath = resolve(operationsPath);
  if (!existsSync(fullPath)) {
    die(`[OPERATIONS_NOT_FOUND] --operations 文件不存在：${operationsPath}（${fullPath}）`);
  }
  let raw;
  try {
    raw = JSON.parse(readFileSync(fullPath, 'utf-8'));
  } catch (e) {
    die(`[OPERATIONS_INVALID] --operations 不是合法 JSON：${operationsPath}：${e.message}`);
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    die(`[OPERATIONS_INVALID] --operations 必须是 JSON 对象：${operationsPath}`);
  }
  if (raw.schemaVersion === 2) {
    die(
      '[OPERATIONS_LEGACY_V2] operations.json 仍是 v2（sourceId+objectId 形态）。' +
        'objectId 已退役：先用集中迁移器升级到 schemaVersion=3（tableRef 形态）后重跑；' +
        'sql-exec 不就地兼容 v2，也不从 actionId 反解表名。',
    );
  }
  if (raw.schemaVersion !== OPERATIONS_SCHEMA_VERSION) {
    die(
      `[OPERATIONS_VERSION_UNSUPPORTED] operations schemaVersion 必须是 ${OPERATIONS_SCHEMA_VERSION}，` +
        `收到 ${JSON.stringify(raw.schemaVersion)}；不做降级/猜测。`,
    );
  }
  if (typeof raw.iterationId !== 'string' || raw.iterationId.trim() === '') {
    die('[OPERATIONS_INVALID] operations.iterationId 必须是非空字符串');
  }
  if (raw.iterationId !== iterationId) {
    die(
      `[OPERATIONS_ITERATION_MISMATCH] --iteration-id ${JSON.stringify(iterationId)} 与 ` +
        `operations.iterationId ${JSON.stringify(raw.iterationId)} 不一致；动作身份必须来自同一轮产物。`,
    );
  }
  if (!Array.isArray(raw.operations)) {
    die('[OPERATIONS_INVALID] operations.operations 必须是数组');
  }
  const matches = raw.operations.filter((operation) => operation && operation.actionId === actionId);
  if (matches.length === 0) {
    die(
      `[ACTION_NOT_FOUND] operations 中找不到 actionId ${JSON.stringify(actionId)}；` +
        '不得按表名/序号猜动作，也不得从 actionId 反解目标表。',
    );
  }
  if (matches.length > 1) {
    die(
      `[ACTION_AMBIGUOUS] operations 中 actionId ${JSON.stringify(actionId)} 出现 ${matches.length} 次；` +
        '动作身份必须唯一，修复输入后再执行。',
    );
  }
  const operation = matches[0];
  const tableRef = normalizeTableRef(
    operation.tableRef,
    `operations[actionId=${JSON.stringify(actionId)}].tableRef`,
    'OPERATION_TABLE_REF_INVALID',
  );
  if (operation.moduleId !== undefined && (typeof operation.moduleId !== 'string' || operation.moduleId.trim() === '')) {
    die('[OPERATIONS_INVALID] operation.moduleId 若存在必须是非空字符串');
  }
  if (raw.inputRevision !== undefined && (typeof raw.inputRevision !== 'string' || raw.inputRevision.trim() === '')) {
    die('[OPERATIONS_INVALID] operations.inputRevision 若存在必须是非空字符串');
  }
  return {
    path: fullPath,
    operation,
    tableRef,
    moduleId: operation.moduleId,
    inputRevision: raw.inputRevision,
  };
}

/**
 * 通道级失败是否发生在「提交 SQL 之前」。
 *
 * SSE 端点连不上 / DNS / 拒绝连接 / endpoint 配置缺失 ⇒ 还没有提交，记 not-executed；
 * 其余（POST 超时、等待响应超时、响应中途断连）可能已提交，保守记 unknown，禁止自动重发。
 */
function isPreSubmitChannelError(message) {
  return /端点连接超时|ECONNREFUSED|ENOTFOUND|EAI_AGAIN|EHOSTUNREACH|ENETUNREACH|getaddrinfo|endpoint 为空|ERR_INVALID_URL|Invalid URL/i
    .test(String(message ?? ''));
}

/** 传了任一动作参数即进入「动作模式」：此时必须参数齐全，否则拒绝执行（不产出无证据执行）。 */
function isActionMode(args) {
  return Boolean(
    args.actionId || args.iterationId || args.operations || args.tableRef || args.receipt,
  );
}

/**
 * 动作参数完整性检查（fail-loud，先于连接/执行/落盘）。
 *
 * 为什么缺参要拒绝执行而不是「省略回执继续跑」：增量验收的必验对象就是这些动作的**可核验证据**；
 * 身份缺失时跑出的结果无法与 operations[].actionId 对上，等于制造一次无证据执行。
 * v3 不再要求 sourceId/objectId，也不接受用它们替代 operations。返回 null 表示齐全。
 */
function actionArgProblem(args) {
  const missing = [];
  const required = [
    ['--operations', args.operations],
    ['--action-id', args.actionId],
    ['--iteration-id', args.iterationId],
  ];
  for (const [flag, value] of required) {
    if (!value || String(value).trim() === '') missing.push(flag);
  }
  if (missing.length > 0) {
    return `[MISSING_ACTION_IDENTITY] 缺少动作回执参数：${missing.join('、')}`;
  }
  if (args.receipt === '') return '[MISSING_ACTION_IDENTITY] --receipt 给了空路径';
  return null;
}

/**
 * 组装 C04 回执 v3（纯函数，不写盘）。
 *
 * 只保留身份/tableRef/binding/target/sqlDigest/实际执行结果；precheck/expected-before-after/
 * 结构摘要全部删除。`taskRef` 保留远端任务引用，供 unknown 场景人工查询原任务最终状态。
 * postcheck 缺席表示未做（不等于通过）；本 CLI 不做后置核验，因此不写该字段。
 *
 * @param {object} input
 * @param {object} input.args             CLI 参数
 * @param {object} input.ds               解析出的执行数据源（db/dataSourceName）
 * @param {object} input.action           已定位的 operations 动作（tableRef/moduleId/inputRevision）
 * @param {string} input.dbKey            归一后的方言键（normalizeDatabaseKey）
 * @param {'completed'|'failed'|'unknown'|'not-executed'} input.executionStatus
 * @param {'mcp'} input.channel
 * @param {string|null} input.attemptedAt 实际提交时间（not-executed 必须 null）
 * @param {'FINISHED'|'FAILED'|null} input.remoteStatus
 * @param {string|null} input.taskRef     远端任务 id（有则保留，不自动重发）
 * @param {string|null} input.errorText
 * @param {string[]} input.archiveRefs
 * @param {string} input.sqlText          本次提交的 SQL 原文（用于 sqlDigest）
 */
function buildActionReceipt(input) {
  const { args, ds, action } = input;
  if (!EXECUTION_STATUSES.includes(input.executionStatus)) {
    throw new Error(`回执 execution.status 非法：${input.executionStatus}`);
  }
  const dataSourceName =
    (args.dataSourceName && String(args.dataSourceName).trim()) ||
    (ds && ds.dataSourceName) ||
    '';
  const moduleId =
    (action && action.moduleId && String(action.moduleId).trim()) ||
    (args.moduleId && String(args.moduleId).trim()) ||
    '';
  return {
    schemaVersion: RECEIPT_SCHEMA_VERSION,
    actionId: args.actionId,
    iterationId: args.iterationId,
    ...(moduleId ? { moduleId } : {}),
    tableRef: { ...action.tableRef },
    binding: { dataSourceName, entryRef: `datasources.json#${dataSourceName}` },
    target: {
      dialect: String(input.dbKey || 'unknown').toLowerCase(),
      database: ds && ds.db ? ds.db : null,
      // 实际解析到的执行目标 owner 未做额外采集；不复用 tableRef.owner 冒充已解析结果。
      owner: null,
    },
    execution: {
      status: input.executionStatus,
      channel: input.channel,
      sqlDigest: sqlDigestOf(input.sqlText),
      attemptedAt: input.attemptedAt,
      remoteStatus: input.remoteStatus ?? null,
      ...(input.executionStatus === 'not-executed' ? {} : { taskRef: input.taskRef ?? null }),
      errorText: input.errorText ?? null,
      archiveRefs: [...input.archiveRefs],
    },
    ...(action && action.inputRevision ? { inputRevision: action.inputRevision } : {}),
  };
}

/** 原子写回执：先写 `<path>.tmp` 再 rename（半截文件不会被消费侧当成证据）。 */
function persistReceipt(receiptPath, receipt) {
  const target = resolve(receiptPath);
  mkdirSync(dirname(target), { recursive: true });
  const tmp = `${target}.tmp`;
  writeFileSync(tmp, `${JSON.stringify(receipt, null, 2)}\n`, 'utf-8');
  renameSync(tmp, target);
  return target;
}

/**
 * 把回执挂进 stdout 载荷并（可选）落盘。
 *
 * `dieOnWriteFailure`：成功路径下「要了回执却写不出来」必须红停——否则 B1 会拿到一次看似成功、
 * 实则没有证据的执行；失败路径已经是 exit 1，写不出来只记录 `receiptError`，不掩盖真实失败原因。
 */
function attachReceipt(payload, args, receipt, { dieOnWriteFailure }) {
  if (!receipt) {
    payload.receipt = null;
    payload.receiptFile = null;
    payload.receiptSkipped = '未提供动作身份参数（--operations/--action-id/--iteration-id），非增量动作调用，不生成执行回执';
    return payload;
  }
  payload.receipt = receipt;
  payload.receiptFile = null;
  if (!args.receipt) return payload;
  try {
    payload.receiptFile = persistReceipt(args.receipt, receipt);
  } catch (e) {
    if (dieOnWriteFailure) {
      die(
        `执行回执写盘失败（${args.receipt}）：${e.message}——数据库执行已发生但证据未持久化，不得当作通过。` +
          `恢复入口：先核对数据库实际结果，再手工补写回执到 ${resolve(args.receipt)}；` +
          '禁止直接重跑同一条 SQL（可能重复执行），除非已确认该动作未生效。',
      );
    }
    payload.receiptError = e.message;
    console.error(`[sql-exec] 执行回执写盘失败（不影响已发生的执行）：${e.message}`);
  }
  return payload;
}

// ── 主流程 ───────────────────────────────────────────────────────────────────

/**
 * 解析 --used-datasource-list 参数：JSON 字符串数组 → Array<string>；缺省 []。
 * 非 JSON / 非数组 → die。
 */
function parseUsedDatasourceList(raw) {
  if (!raw || raw.trim() === '') return [];
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    die(`--used-datasource-list 非 JSON 数组：${raw}`);
  }
  if (!Array.isArray(parsed)) die(`--used-datasource-list 不是数组：${raw}`);
  return parsed.map((x) => String(x));
}

/**
 * --database 模式：调 MCP ProAppDatabaseController.create 建库。
 *
 * 流程（实测 2026-08-XX 真实 appId "31650e02-..."）：
 *   - 入参 arg0 包裹：{ appId, usedDatasourceList }，**不传 env**（平台返 dev+online 两 env，
 *     wrapper 只取 envName==='dev' 给 initialize 用）
 *   - 响应 result 嵌套结构：{ appId, allocated, dataSourceName, datasources: [{envName, ...}×2] }
 *   - allocated:true=平台复用空闲库(未新建);false=本次新建（仅 stderr 日志，不透传）
 *   - usedDatasourceList 累积机制： []→返 defaultds0；[defaultds0]→返 defaultds1...
 *   - databasePort 平台返字符串，wrapper 转 Number
 *
 * stdout 单行 JSON：{ ok, result?, error? }（被 plugin create-app-database 包装回 agent）。
 */
async function createDatabaseMode(args) {
  if (!args.appId) {
    printHelp();
    die('缺少 --app-id 参数（建库模式必填）');
  }
  const usedDatasourceList = parseUsedDatasourceList(args.usedDatasourceList);
  try {
    const r = await callMcpTool(
      'ProAppDatabaseController.create',
      'arg0',                                  // 实测稳定的 wrapper key
      { appId: args.appId, usedDatasourceList },
    );
    if (!r.success) {
      throw new Error(
        `ProAppDatabaseController.create failed: code=${r.code ?? 'N/A'} msg=${r.msg || '(无 msg)'}`,
      );
    }
    if (!r.result) throw new Error('ProAppDatabaseController.create: structuredContent.result is null');
    if (!Array.isArray(r.result.datasources) || r.result.datasources.length === 0) {
      throw new Error('ProAppDatabaseController.create: result.datasources is empty');
    }
    const dev = r.result.datasources.find((ds) => ds.envName === 'dev') ?? r.result.datasources[0];
    const port = Number(dev.databasePort);
    if (!Number.isFinite(port)) {
      throw new Error(`ProAppDatabaseController.create: invalid databasePort "${dev.databasePort}"`);
    }
    console.error(
      `[sql-exec --database] ProAppDatabaseController.create: appId=${args.appId} ` +
      `usedDatasourceList=[${usedDatasourceList.join(',')}] ` +
      `→ dataSourceName=${r.result.dataSourceName} database=${dev.databaseName} ` +
      `allocated=${r.result.allocated} ${r.result.allocated ? '(reused 空闲库)' : '(newly created)'}`,
    );
    const result = {
      dataSourceName: r.result.dataSourceName || dev.dataSourceName,
      databaseName: dev.databaseName,
      databaseHost: dev.databaseHost,
      databasePort: port,
      databaseUsername: dev.databaseUsername,
      databasePassword: dev.databasePassword,
      databaseDriverType: dev.databaseDriverType,
      databaseSchemaName: dev.databaseSchemaName,
      databaseVersion: dev.databaseVersion,
      envName: dev.envName,
    };
    process.stdout.write(`${JSON.stringify({ ok: true, result })}\n`);
    process.exit(0);
  } catch (e) {
    process.stdout.write(`${JSON.stringify({ ok: false, error: e.message })}\n`);
    process.exit(1);
  }
}

/**
 * --update-circle-port 模式：调 MCP InternalAppDatabaseProxyController.updateCirclePort，
 * 把 sbx-outbound 拿到的 loopbackPort 作为 circlePort 写入应用-数据源关系表的 dev 环境行。
 *
 * 调用时机：agent 在 4b 多源路径上，先调 app_database_create 拿到 result.dataSourceName
 * 与 result.databaseHost/databasePort，再 Bash 调 \`sbx-outbound add -r <host>:<port>\`
 * 解析 stdout.loopbackPort，然后**必须**调一次本子命令登记 circlePort（否则代理解析时
 * 无法把 6003 上收到的 SQL 包转发到正确的 sandbox-loopback forwarder）。
 *
 * 入参 arg0 包裹：{ appId, dataSourceName, circlePort }，**circlePort 必须 string**
 * （MCP inputSchema 规定 'circlePort' 类型为 string）。
 *
 * stdout 单行 JSON：{ ok, result?, error? }（被 plugin update-app-database-circle-port 包装回 agent）。
 *
 * 审计落盘（2026-08-27 新增）：MCP 调用成功后，把 (appId, dataSourceName, circlePort, registeredAt)
 * upsert 到 \`${projectArtifactDir}/.initialize/circle-port-registry.json\`（path 由
 * process.env.APP_NAME + process.cwd() 派生：path.join(cwd, APP_NAME, '.initialize',
 * 'circle-port-registry.json')）。该文件供 spec-server \`resolveComponentEndpointsChecker\`
 * dim 10 校验每库 (appId,dataSourceName) 已登记且 circlePort === String(raw.databases[].port)，
 * 防 agent 漏调 updateCirclePort 让 4c SQL 包绕开真实 dev 库。
 * 审计写失败（APP_NAME 缺失 / 目录权限不足 / JSON 解析失败）→ stderr warn-and-continue，
 * 不影响 plugin 返回 ok:true（MCP 调用本身才真正成功；本地审计是 cheater 兜底点，不是主成功信号）。
 */
async function updateCirclePortMode(args) {
  if (!args.appId) {
    printHelp();
    die('缺少 --app-id 参数（登记 circlePort 模式必填）');
  }
  if (!args.dataSourceName) {
    printHelp();
    die('缺少 --data-source-name 参数（取 4b 上一步 app_database_create 返回的 result.dataSourceName）');
  }
  if (args.circlePort == null || String(args.circlePort).trim() === '') {
    printHelp();
    die('缺少 --circle-port 参数（取 sbx-outbound add stdout.loopbackPort 字符串化）');
  }
  const circlePort = String(args.circlePort).trim();
  try {
    const r = await callMcpTool(
      'InternalAppDatabaseProxyController.updateCirclePort',
      'arg0',                                  // MCP inputSchema required key
      { appId: args.appId, dataSourceName: args.dataSourceName, circlePort },
    );
    if (!r.success) {
      throw new Error(
        `InternalAppDatabaseProxyController.updateCirclePort failed: code=${r.code ?? 'N/A'} msg=${r.msg || '(无 msg)'}`,
      );
    }
    console.error(
      `[sql-exec --update-circle-port] InternalAppDatabaseProxyController.updateCirclePort: ` +
      `appId=${args.appId} dataSourceName=${args.dataSourceName} circlePort=${circlePort} → registered`,
    );
    // 本地审计 upsert（fail-open：写审计失败仅 warn，不影响 plugin ok:true）
    try {
      writeCirclePortAuditEntry(args.appId, args.dataSourceName, circlePort);
    } catch (auditErr) {
      console.error(
        `[sql-exec --update-circle-port] 审计文件写入失败（不影响 MCP 调用成功）：${auditErr.message}`,
      );
    }
    process.stdout.write(`${JSON.stringify({ ok: true, result: r.result ?? null })}\n`);
    process.exit(0);
  } catch (e) {
    process.stdout.write(`${JSON.stringify({ ok: false, error: e.message })}\n`);
    process.exit(1);
  }
}

/**
 * 看 cwd/{APP_NAME}/.initialize/ 目录下 circle-port-registry.json 的 (appId,dataSourceName)
 * 条目 upsert：已存在则更新 circlePort + registeredAt，不存在则追加。
 *
 * 失败默认（调用方 try/catch 兜底）：APP_NAME 缺失 → 抛 Error；目录创建/JSON 解析失败 → 抛 Error
 * 由调用方决定是否 fail-open（update-circle-port 模式下 fail-open，不阻断 MCP 的真实成功）
 */
function writeCirclePortAuditEntry(appId, dataSourceName, circlePort) {
  const appName = process.env.APP_NAME;
  if (!appName) {
    throw new Error('APP_NAME env 缺失，无法计算 circle-port-registry.json 路径');
  }
  const registryPath = join(process.cwd(), appName, '.initialize', 'circle-port-registry.json');
  let registry = { entries: [] };
  if (existsSync(registryPath)) {
    try {
      const existing = JSON.parse(readFileSync(registryPath, 'utf-8'));
      if (existing && Array.isArray(existing.entries)) {
        registry = existing;
      }
    } catch {
      // 损坏 JSON → 覆盖重建，不阻断流程
      registry = { entries: [] };
    }
  }
  const now = new Date().toISOString();
  const existingIdx = registry.entries.findIndex(
    (e) => e && e.appId === appId && e.dataSourceName === dataSourceName,
  );
  const entry = { appId, dataSourceName, circlePort: String(circlePort), registeredAt: now };
  if (existingIdx >= 0) {
    registry.entries[existingIdx] = entry;
  } else {
    registry.entries.push(entry);
  }
  mkdirSync(dirname(registryPath), { recursive: true });
  writeFileSync(registryPath, `${JSON.stringify(registry, null, 2)}\n`, 'utf-8');
}

async function run() {
  const args = parseArgs(process.argv.slice(2));

  // 1. --database 模式：建库路径，不走 SQL 执行
  if (args.database) {
    await createDatabaseMode(args);
    return;
  }

  // 2. --update-circle-port 模式：登记 circlePort，不走 SQL 执行
  if (args.updateCirclePort) {
    await updateCirclePortMode(args);
    return;
  }

  const sql = readSql(args);
  if (!sql || !sql.trim()) {
    printHelp();
    die('缺少 --sql 或 --file 参数');
  }
  if (args.type && !['ddl', 'dml', 'probe'].includes(args.type)) die(`--type 仅支持 ddl|dml|probe，实为「${args.type}」`);
  if (args.tableName !== null && !String(args.tableName).trim()) die('--table-name 必须为非空表名');

  // ── 增量动作前置校验（先验后执行：任何 die 都早于连接/执行/落盘）──────────────
  // ① --require-module-binding：模块绑定与数据源必须显式给出，**单模块工程也不回退聚合根/默认库**
  //    （增量轮的作用域是 action 级，不是工程级；回退会让证据落到错模块、错库）。
  if (args.requireModuleBinding) {
    const missing = [];
    if (!args.moduleId || String(args.moduleId).trim() === '') missing.push('--module-id');
    if (!args.dataSourceName || String(args.dataSourceName).trim() === '') missing.push('--data-source-name');
    if (missing.length > 0) {
      die(
        `--require-module-binding 要求显式绑定模块与数据源，缺 ${missing.join('、')}——` +
          '增量动作禁止回退聚合根 backend/sql 或默认库（否则证据归属不可核验）。' +
          '请补 --module-id <工程方案 codeModules[].moduleId> 与 --data-source-name <该模块绑定的数据源>。',
      );
    }
  }
  // ② 已退役的动作身份参数：确定性迁移错误，不静默忽略、不按旧 id 猜表。
  if (args.retiredActionFlags.length > 0) {
    const flags = [...new Set(args.retiredActionFlags)];
    die(
      `[RETIRED_ACTION_IDENTITY] ${flags.join('、')} 已退役（objectId 退役），不再作为动作目标来源。` +
        '动作目标只认 operations v3 的 tableRef：请改用 ' +
        '`--operations <operations.json> --action-id <id> --iteration-id <id>`；' +
        '确需手工指定目标时用 --table-ref \'{"sourceId":…,"owner":…,"kind":"table","name":…}\'，' +
        '且必须与 operations[].tableRef 逐字相等。旧参数不会被忽略，也不会被用来反解表名。',
    );
  }
  // ③ 动作模式：传了任一动作身份参数就必须齐全，否则拒绝执行（不制造无证据执行）。
  const actionMode = isActionMode(args);
  let actionContext = null;
  if (actionMode) {
    const problem = actionArgProblem(args);
    if (problem) {
      die(
        `${problem}——动作模式下身份参数不全不执行（缺身份的执行结果无法与 operations[].actionId 对上）。` +
          '请按 `--operations <operations.json> --action-id <id> --iteration-id <id>` 原样补齐后重跑；' +
          '禁止省略参数重试，也不得改用已退役的 --source-id/--object-id。',
      );
    }
    actionContext = loadOperationsAction(args.operations, args.iterationId, args.actionId);
    if (args.tableRef !== null && args.tableRef !== undefined) {
      const explicit = parseExplicitTableRef(args.tableRef);
      if (!sameTableRef(explicit, actionContext.tableRef)) {
        die(
          `[TABLE_REF_MISMATCH] --table-ref ${JSON.stringify(explicit)} 与 ` +
            `operations[actionId=${JSON.stringify(args.actionId)}].tableRef ` +
            `${JSON.stringify(actionContext.tableRef)} 不一致（四字段逐字比较，不做归一化）。` +
            '显式目标只能用于核对，不能覆盖 operations 的目标。',
        );
      }
    }
    if (
      actionContext.moduleId &&
      args.moduleId &&
      String(args.moduleId).trim() !== '' &&
      String(args.moduleId).trim() !== actionContext.moduleId
    ) {
      die(
        `[MODULE_ID_MISMATCH] --module-id ${JSON.stringify(String(args.moduleId).trim())} 与 ` +
          `operations[actionId=${JSON.stringify(args.actionId)}].moduleId ` +
          `${JSON.stringify(actionContext.moduleId)} 不一致；模块身份必须与 operations 同值。`,
      );
    }
  }

  // 执行通道：所有数据库类型统一走远端 MCP（本地直连通道已退役，不向调用方开放切换）。

  const cwd = process.cwd();
  // 项目产物根锚定（plan 2026-10-24 D6 收口）：先向上找含 docs/<ts>/plans/backend 的祖先，
  // 再从该根解析后端产物根与工程方案——否则 agent 从服务目录执行时门禁失效、归档位置随 cwd 漂移。
  const projectRoot = resolveProjectRoot(cwd);
  // 工程方案目录（最新 docs/<ts>/plans/backend）：D13 数据源判据、§D6 归档归属与代码根声明共用同一读面。
  const planBackendDir = projectRoot ? resolvePlanBackendDir(projectRoot) : resolvePlanBackendDir(cwd);
  // planBackendDir = <activeSpecDir>/plans/backend ⇒ activeSpecDir 需再上溯一层（plans 的父目录）。
  const activeSpecDir = args.activeSpecDir ?? (planBackendDir ? dirname(dirname(planBackendDir)) : undefined);
  const backendDir = resolveArchiveBackendRoot(args, projectRoot, cwd, activeSpecDir);

  // ── D13（plan 2026-10-17/phase2-micro §2.2 2d / §3 行 12）───────────────────────────────
  // per-module 粒度下**按模块显式解析** dataSourceName（显式 --data-source-name 或按 --module-id 查
  // binding envelope），**禁省略参数回退默认库**——已确认契约条目是唯一真值
  // （沙箱双数据源错库事故在案）。判据实现单源见 extract-code-schema.mjs。
  // shared / monolith / 老产物无粒度决策 ⇒ policy 放行，但 dataSourceName 仍须显式传入。
  const designTimePolicy = resolveDesignTimeDatasource({
    planBackendDir,
    dataSourceName: args.dataSourceName,
    moduleId: args.moduleId,
  });
  if (!designTimePolicy.ok) die(designTimePolicy.reason);

  // 数据源解析（plan 2026-11-04/retire-db-config-json-artifact §3）：坐标只认已确认契约条目
  // + APP_ID；dataSourceName 必须显式传入（designTimePolicy 已按 binding/参数解析），
  // 缺条目/缺字段由 resolver 以 error 返回，调用方红停——无 env / db-config / 默认库回退。
  // 须先于 archiveDir 解析：归档缺省路径按数据源分桶，依赖 ds.dataSourceName。
  const ds = resolveExecDatasource(backendDir || cwd, designTimePolicy.dataSourceName || undefined);
  if (ds.error) die(`数据源解析失败：${ds.error}`);

  // 归档根：按归属模块落盘（plan 2026-10-24 §D6，先验后执行——所有 die 均早于连接/执行/落盘）。
  // 有工程方案且多模块 ⇒ 必须 --module-id，归档根下沉到 <projectRoot>/<pathBase>/sql/<ds>；
  // 单模块 / 无工程方案（monolith/存量）⇒ 维持 <backendDir>/sql/<ds> 旧布局（逐字节兼容）。
  // 桶内仍四分 scheme|seed|biz|probe（scheme/seed 见 plan 2026-09-01、probe 见 plan 2026-09-03，下方路由）。
  const archiveDir = backendDir
    ? resolveArchiveDir(backendDir, projectRoot, planBackendDir, args.moduleId, ds.dataSourceName || ds.db)
    : null;
  if (!archiveDir) die('未定位后端目录（缺 pom.xml）');

  // 一次调用提交一份完整 SQL，程序体/字符串中的分号由数据库解释。
  // 调用方负责提供可独立执行与回放的单条语句；执行器不拆分或改写 SQL。
  const statements = [sql];
  const masked = sanitizeSql(sql);
  if (/\bDROP\s+(TABLE|DATABASE|SCHEMA)\b|\bTRUNCATE\s+TABLE\b/i.test(masked.text) || masked.executableComment) {
    die('含 DROP/TRUNCATE 破坏性操作或可执行注释，禁止执行');
  }

  // ── 回执通道身份（v3）：状态只由数据库实际结果决定，不再有 precheck 前置门 ────────────
  // 通道恒为 mcp（plan 2026-11-09 D1/D5：local 已退役，不存在按方言切换的通道）。
  const receiptDbKey = normalizeDatabaseKey(ds.databaseType);
  const receiptChannel = 'mcp';

  // ── 分类与路由（先验后执行：任何 die 都发生在执行之前）─────────────────────────────
  // 识别用剥注释后的语句文本（修 0904 发现的「注释带偏类型判定」：带 -- 注释的 INSERT 曾被判 ddl/probe）。
  let type;
  let table;
  let bucket;
  let claimMismatch = false;
  // 归档身份由调用方声明；旧调用仅对已识别的简单语句保留推断。
  // 无法识别时要求补元数据，不将未知写语句冒充 probe。
  {
    const detected = detectStatement(stripComments(sql));
    type = args.type || detected.type;
    if (!type) die('缺少归档类型：请传 --type ddl|dml|probe；SQL 语法由数据库判定');
    const actionTable = actionContext?.tableRef?.name;
    if (args.tableName && actionTable && args.tableName !== actionTable) {
      die('--table-name 与 operations.tableRef.name 不一致');
    }
    table = args.tableName || actionTable || detected.table;
    if (type === 'dml') {
      if (!table) die('DML 缺少归档目标：请传 --table-name <种子表清单中的表名> 或动作 tableRef');
      // 清单只在单语句 DML 时是硬依赖（建表可先于 seed-inventory 消费场景）。
      const seedManifest = loadSeedManifest(backendDir || cwd, ds.dataSourceName || ds.db);
      if (!seedManifest) {
        die(
          '缺少种子表清单，DML 无法归档路由。缺的文件：<plans 大纲目录>/backend/_meta/seed-tables.json（向上 8 层探测，含 docs/<ts>/plans/；' +
            '人工调试可用环境变量 SEED_TABLES_MANIFEST=<abs path> 显式指定）。' +
            '该清单由 build 波前置种子表识别任务（seed-tables stage，首个 DML 之前）唯一产出——正常流程该任务已先行；' +
            '出现本红=该任务被跳过/失败，回查该任务补产，禁止手工编写清单；' +
            '禁止手改既有清单、禁止为绕过本门把 DML 拆成 --type ddl。',
        );
      }
      bucket = isSeedTable(seedManifest, table) ? 'seed' : 'biz';
      // 漏报探测（单向、只报不拦）：申报种子但清单无此表 → claimMismatch，归档仍在 biz（清单权威）。
      claimMismatch = args.initData && bucket === 'biz';
    } else {
      bucket = type === 'probe' ? 'probe' : 'scheme';
    }
  }


  // ── 执行通道（单次调用，单条语句）─────────────────────────────────────────────
  // 任务超时（SQL_EXEC_TIMEOUT_MS 可覆盖，缺省 120s）。
  const timeoutMs = Number(process.env.SQL_EXEC_TIMEOUT_MS) || 120_000;
  // 执行通道恒为远端 mcp：所有数据库类型同一条派发路径，无方言路由、无 local 回退
  // （plan 2026-11-09 D1/D5）。
  // status = stdout 兼容状态；executionStatus = 回执 v3 状态；remoteStatus 只保留 FINISHED/FAILED。
  let status = null;
  let executionStatus = null;
  let remoteStatus = null;
  let taskRef = null;
  let failReason = null;
  // probe 归档的结果水印（SELECT 回显行数；mcp 通道无行数回显 → null 只记 ok）。
  let resultRows = null;
  // 执行尝试时间：回执 completed/failed/unknown 必填；not-executed 必须为 null。
  let executionAttemptedAt = null;
  let rawResponse = null;

  // ── 执行证据目录（plan 2026-11-08/b1-sql-action-non-blocking-evidence）──────────────
  // 机械派生，与 seed/bucket 同级，**不接受 agent 指定路径**：
  //   <归档根>/sql/<dataSourceName>/_evidence/<sanitize(actionId)>/
  // 每个动作一个目录：statement.sql + request.json + response.json + outcome.json。
  // 无 --action-id（手工调试）⇒ 不写证据、不报错。
  // 证据写失败只 stderr 警告 + outcome.evidenceWriteError，**绝不掩盖真实执行结果**。
  const evidenceDir = args.actionId
    ? join(archiveDir, '_evidence', sanitizeActionIdForDir(args.actionId))
    : null;
  const evidenceErrors = [];
  let evidenceBaseWritten = false;
  const writeEvidenceFile = (name, content) => {
    if (!evidenceDir) return;
    try {
      mkdirSync(evidenceDir, { recursive: true });
      writeFileSync(join(evidenceDir, name), content, 'utf-8');
    } catch (e) {
      evidenceErrors.push(`${name}: ${e.message}`);
      console.error(`[sql-exec] 执行证据写入失败（${name}，不影响真实执行结果）：${e.message}`);
    }
  };
  const writeEvidenceJson = (name, value) =>
    writeEvidenceFile(name, `${JSON.stringify(value, null, 2)}\n`);
  const evidenceRequestOf = () => ({
    // action / 参数：与执行通道实际入参同源（不写密码等凭据）。
    action: 'InternalWebSqlController.executeSqlDirect',
    arguments: {
      sql,
      dataSourceName: ds.dataSourceName ?? null,
      dbName: ds.db ?? null,
      appId: ds.appId ?? null,
      env: process.env.SQL_EXEC_MCP_ENV || 'dev',
    },
    dataSourceName: ds.dataSourceName || args.dataSourceName || null,
    moduleId: (actionContext && actionContext.moduleId) || args.moduleId || null,
    tableRef: actionContext ? { ...actionContext.tableRef } : null,
    operationsPath: actionContext ? actionContext.path : null,
    actionId: args.actionId || null,
    iterationId: args.iterationId || null,
    sqlPath: args.file ? resolve(args.file) : null,
    channel: receiptChannel,
  });
  const prepareEvidenceBase = () => {
    if (!evidenceDir || evidenceBaseWritten) return;
    evidenceBaseWritten = true;
    writeEvidenceFile('statement.sql', `${sql.trim()}\n`);
    writeEvidenceJson('request.json', evidenceRequestOf());
  };
  const finalizeEvidence = ({ evidenceStatus, response, errorCode, errorText, archivedSql }) => {
    if (!evidenceDir) return;
    prepareEvidenceBase();
    writeEvidenceJson('response.json', response ?? { error: errorText ?? null });
    writeEvidenceJson('outcome.json', {
      status: evidenceStatus,
      actionId: args.actionId || null,
      moduleId: (actionContext && actionContext.moduleId) || args.moduleId || null,
      tableRef: actionContext ? { ...actionContext.tableRef } : null,
      ...(errorCode ? { errorCode } : {}),
      ...(errorText ? { errorText } : {}),
      archivedSql: archivedSql ?? null,
      ...(evidenceErrors.length > 0 ? { evidenceWriteError: evidenceErrors.join('; ') } : {}),
    });
  };
  /**
   * 提交前失败（连接/通道/参数不可用）：动作模式留一份 `not-executed` 回执——未提交 ≠ 执行失败，
   * 也绝不能写成 completed；attemptedAt 为 null。非动作模式维持 die（旧行为）。
   */
  const finishNotExecuted = (message) => {
    if (!actionMode) die(message);
    executionStatus = 'not-executed';
    status = 'SKIPPED';
    failReason = message;
    finalizeEvidence({ evidenceStatus: 'skipped', response: rawResponse, errorText: message, archivedSql: null });
    const receipt = buildActionReceipt({
      args,
      ds,
      action: actionContext,
      dbKey: receiptDbKey,
      executionStatus,
      channel: receiptChannel,
      attemptedAt: null,
      remoteStatus: null,
      taskRef: null,
      errorText: message,
      archiveRefs: [],
      sqlText: sql,
    });
    const payload = {
      ok: true,
      statements: statements.length,
      status,
      skipped: true,
      executionStatus,
      file: null,
      msg: message,
      ...(evidenceDir ? { evidenceDir } : {}),
    };
    attachReceipt(payload, args, receipt, { dieOnWriteFailure: false });
    console.log(JSON.stringify(payload));
    console.error(`[sql-exec] 已归档跳过（not-executed，不阻断 build）：${message}`);
    process.exit(0);
  };
  // 远端 executeSqlDirect 单语句单任务执行（所有数据库类型唯一通道）。statementDTO 要求
  // dataSourceName + dbName 必填（来源：已确认契约条目 + APP_ID；缺任一远端报「缺少必要的参数」）。
  if (!ds.dataSourceName) finishNotExecuted('mcp 模式缺数据源标识（未显式传入契约条目 dataSourceName），无法定位远端库');
  if (!ds.db) finishNotExecuted('mcp 模式缺目标库名（契约条目缺连接目标库），无法定位远端库');
  if (!ds.appId) finishNotExecuted('mcp 模式缺 appId（沙箱 env 未注入 APP_ID），无法调远端 MCP');
  const mcpEndpoint = process.env.SQL_EXEC_MCP_ENDPOINT || null;
  const mcpEnv = process.env.SQL_EXEC_MCP_ENV || 'dev';
  console.error(`[sql-exec] mcp 执行：dataSource=${ds.dataSourceName} db=${ds.db} appId=${ds.appId} env=${mcpEnv}${mcpEndpoint ? ` endpoint=${mcpEndpoint}` : ''}，单条语句执行，归档根 ${archiveDir}（scheme|seed|probe 落盘归档，biz 只判定不落盘；mcp 无行数回显，probe 水印记 ok 不记 rows，timeout=${timeoutMs}ms）`);
  let r = null;
  executionAttemptedAt = new Date().toISOString();
  try {
    r = await executeSqlViaMcp({
      sql,
      dataSourceName: ds.dataSourceName,
      dbName: ds.db,
      appId: ds.appId,
      env: mcpEnv,
      timeoutMs,
      ...(mcpEndpoint ? { endpoint: mcpEndpoint } : {}),
    });
  } catch (e) {
    // 连接前失败（SSE 端点不可达/拒绝连接/配置缺失）⇒ not-executed；
    // 其余超时/断连可能已提交 ⇒ unknown，保留（可能的）任务引用，不自动重发。
    failReason = (e && (e.message || String(e))) || '';
    rawResponse = { error: failReason };
    if (isPreSubmitChannelError(failReason)) {
      finishNotExecuted(`MCP 通道连接失败（未提交 SQL）：${failReason}`);
    }
    status = 'UNKNOWN';
    executionStatus = 'unknown';
  }
  if (r !== null) {
    rawResponse = r;
    const task = r.result && typeof r.result === 'object' ? r.result : null;
    const taskStatus = task && typeof task.status === 'string' ? task.status : null;
    taskRef = task && typeof task.taskId === 'string' ? task.taskId : null;
    const taskError = task && typeof task.result === 'string' ? task.result : null;
    if (taskStatus === 'FINISHED') {
      // 只有数据库返回终态 FINISHED 才是 completed；传输成功/任务 id/exit 0 都不算。
      status = 'FINISHED';
      executionStatus = 'completed';
      remoteStatus = 'FINISHED';
    } else if (taskStatus === 'FAILED') {
      // 含重复键/已存在等数据库明确失败：幂等下沉到 SQL 层，工具层不掩码。
      status = 'FAILED';
      executionStatus = 'failed';
      remoteStatus = 'FAILED';
      failReason = taskError || r.msg || 'MCP 返回任务状态 FAILED';
    } else {
      status = 'UNKNOWN';
      executionStatus = 'unknown';
      failReason = `MCP 任务最终状态未知（status=${taskStatus ?? 'null'}）：传输/任务提交成功不等于 SQL 成功，需查询原任务后再判定`;
    }
  }

  /** 执行结束后的回执（非动作模式返回 null：旧调用不多出证据字段、不写文件）。 */
  const buildReceiptFor = (receiptStatus, archiveRefs) =>
    actionMode
      ? buildActionReceipt({
          args,
          ds,
          action: actionContext,
          dbKey: receiptDbKey,
          executionStatus: receiptStatus,
          channel: receiptChannel,
          attemptedAt: receiptStatus === 'not-executed' ? null : executionAttemptedAt,
          remoteStatus,
          taskRef,
          errorText: receiptStatus === 'completed' ? null : failReason,
          archiveRefs,
          sqlText: sql,
        })
      : null;

  if (executionStatus !== 'completed') {
    // 非动作模式（手工/调试，无 --action-id）：保留旧语义——失败即 exit 1，不写证据目录。
    if (!actionMode) {
      console.log(JSON.stringify({ ok: false, statements: statements.length, status, file: null, msg: failReason }));
      process.exit(1);
    }
    // 动作模式：一切非成功（数据库报错 / unknown / 未提交）统一归档跳过：不落 .sql 归档、不阻断 build。
    // 证据四件套必须先落盘；回执仍按数据库实际结果写 failed/unknown/not-executed（不伪造成功）。
    finalizeEvidence({ evidenceStatus: 'skipped', response: rawResponse, errorText: failReason, archivedSql: null });
    const payload = {
      ok: true,
      statements: statements.length,
      status: 'SKIPPED',
      skipped: true,
      executionStatus,
      file: null,
      msg: failReason,
      ...(evidenceDir ? { evidenceDir } : {}),
    };
    attachReceipt(payload, args, buildReceiptFor(executionStatus, []), { dieOnWriteFailure: false });
    console.log(JSON.stringify(payload));
    const label = executionStatus === 'unknown'
      ? '语句执行结果未知（已归档跳过，不自动重发；请查询原任务最终状态）'
      : executionStatus === 'not-executed'
        ? '语句未提交执行（已归档跳过）'
        : '语句执行失败（已归档跳过，不阻断 build）';
    console.error(`[sql-exec] ${label}：${failReason}`);
    process.exit(0);
  }

  if (claimMismatch) {
    console.error(`[sql-exec] ⚠ claimMismatch：--init-data 申报种子，但 "${table}" 不在 seed-tables.json 清单，已按清单判定 biz/（清单为唯一权威）。上报协调者转人审补登清单；build 期禁手改清单，也禁止去掉申报参数重试来"消音"。`);
  }

  // biz 只判定不落盘（2026-09-07 收口，probe 已解禁）：业务 DML 不进发布重放，留盘只会
  // 污染 scheme|seed 已执行清单的按目录核对。file=null 与失败/空脚本同形。
  if (bucket === 'biz') {
    finalizeEvidence({ evidenceStatus: 'completed', response: rawResponse, archivedSql: null });
    const payload = {
      ok: true,
      statements: statements.length,
      status,
      file: null,
      bucket,
      claimMismatch,

      ...(evidenceDir ? { evidenceDir } : {}),
    };
    attachReceipt(payload, args, buildReceiptFor('completed', []), { dieOnWriteFailure: true });
    console.log(JSON.stringify(payload));
    console.error(`[sql-exec] 已执行（单条语句），判定 biz/（不落盘：业务 DML 不进归档与重放）`);
    process.exit(0);
  }

  // ── 归档：执行原文一份落盘（watermark + 原文；scheme|seed=发布重放同构，probe=冒烟
  // 证据归档——plan 2026-09-21 §B5 rev2，段 AS 产物 evidence 交叉核对面，不进重放）────
  const bucketDir = join(archiveDir, bucket);
  mkdirSync(bucketDir, { recursive: true });
  // 文件名时间戳执行成功后现取（一调用一文件，同毫秒跨调用冲突由 makeArchiveName -2 序号兜底）。
  const ts = formatTimestamp(new Date());
  const name = makeArchiveName(bucketDir, ts, table, type);
  const filePath = join(bucketDir, name);
  try {
    const result = resultRows === null ? 'ok' : `ok rows=${resultRows}`;
    writeFileSync(
      filePath,
      `${buildWatermark(
        ts,
        table,
        type,
        bucket,
        args.initData,
        statements.length,
        bucket === 'probe' ? result : null,
      )}${sql.trim()}\n`,
      'utf-8',
    );
  } catch (e) {
    finalizeEvidence({ evidenceStatus: 'skipped', response: rawResponse, errorText: `写归档文件失败：${e.message}`, archivedSql: null });
    console.log(JSON.stringify({ ok: false, statements: statements.length, status, file: null, msg: `写归档文件失败：${e.message}` }));
    console.error(`[sql-exec] 归档写盘失败：${e.message}`);
    process.exit(1);
  }

  finalizeEvidence({ evidenceStatus: 'completed', response: rawResponse, archivedSql: filePath });
  const successPayload = {
    ok: true,
    statements: statements.length,
    status,
    file: filePath,
    claimMismatch,

    ...(evidenceDir ? { evidenceDir } : {}),
  };
  attachReceipt(successPayload, args, buildReceiptFor('completed', [filePath]), { dieOnWriteFailure: true });
  console.log(JSON.stringify(successPayload));
  console.error(`[sql-exec] 已执行（单条语句），归档 ${filePath}`);
  process.exit(0);
}

run();
