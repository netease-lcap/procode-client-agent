#!/usr/bin/env node
/**
 * 通用 schema 采集执行器（**不含任何方言 SQL**）。
 *
 * Plan: docs/hicode-spec/plan/2026-11-04/incremental-code-schema-and-build-codegen.md §5.3 / §5.8 / §9.1
 *
 * runner 只做四件事：建通道、执行 agent 提案的 SQL、收集 raw result、写 raw 产物。
 * SQL 由 Agent B 提供（见 `./plan-schema.json`）；MySQL 也没有 fast path——脚本不拼
 * `SHOW CREATE TABLE` / `information_schema` 之类的方言 SQL。
 *
 * ── 输入 ────────────────────────────────────────────────────────────────────
 * plan JSON（已由 `./plan-schema.mjs` 校验）：
 *
 *   {
 *     "dialect": "mysql",                         // 必填、非空；不做白名单
 *     "catalog": {                                // 可选：门 A 前的表清单 preflight
 *       "listTablesSql": "SELECT ... LIMIT {{limit}} OFFSET {{offset}}", // 使用 {{limit}}/{{offset}} 分页参数，或提供 countSql
 *       "fallbackSql": ["SELECT ..."],             //   可选
 *       "countSql": "SELECT COUNT(*) AS cnt ...",  //   可选：与分页行数对账
 *       "pageSize": 500                            //   可选：分页大小（默认 500）
 *     },
 *     "tables": [                                 // 可选：逐表采集
 *       {
 *         "table": "sys_user",
 *         "dataSourceName": "<已确认数据源名>",     //   单源和多源均必填
 *         "sql": "SHOW CREATE TABLE `sys_user`",   //   agent 提案的 SQL
 *         "fallbackSql": ["SELECT ..."],           //   主 SQL 失败/空结果后按序尝试
 *         "expectedShape": "ddl" | "columns"
 *       }
 *     ],
 *     "probe": {                                  // 可选：能力/版本探针（best-effort）
 *       "versionSql": "SELECT VERSION() AS version",
 *       "fallbackSql": ["SELECT ..."]
 *     }
 *   }
 *
 *   `tables: []` 非法；catalog-only plan 合法；两者可同时出现（catalog 先执行，复用同一会话）。
 *
 * ── 通道 ────────────────────────────────────────────────────────────────────
 *   mcp    ：`openMcpSession` + `executeSqlDirectOnSession`（platform MCP；所有数据库类型统一走此通道）
 *   local 通道已退役（plan 2026-11-09 D1/D5）：显式 `channel:"local"` 或 `options.local`
 *   ⇒ `SCHEMA_RUN_CHANNEL_INVALID`（"local 通道已退役，请经 MCP 重新采集"），不静默忽略。
 *
 * ── 只读边界 ────────────────────────────────────────────────────────────────
 *   · plan-schema 对 primary / fallback / probe / catalog / catalog.count 做语句级白名单；
 *   · runner 在**真正下发前**用同一实现二次校验（纵深防御），失败抛
 *     `SCHEMA_RUN_SQL_NOT_READONLY`，不静默跳过、不降级为 fallback；
 *   · MCP 无法设会话只读，只能依赖上述语句白名单 + 下发前二次校验（不得声称具备
 *     `BEGIN READ ONLY` 的同等服务端保护）。
 *
 * ── 目录分页 ────────────────────────────────────────────────────────────────
 *   · catalog 按 pageSize（catalog.pageSize / options.catalogPageSize，默认 500）循环
 *     填入 Agent 模板中的数值参数，直到某页返回行数 < pageSize；
 *   · 每页元数据记入 `pages[]`；`catalogPageCount` = 实际执行的页数；
 *   · 有 countSql 时对账：COUNT ≠ 分页行数 ⇒ SCHEMA_RUN_CATALOG_COUNT_MISMATCH；
 *   · 页间列不一致 / 跨页重复行 ⇒ SCHEMA_RUN_CATALOG_PAGE_INCONSISTENT；
 *   · `truncated` 仍然只表示**字节截断**，与分页完整性（catalogComplete）不混用。
 *
 * ── 批量纪律 ────────────────────────────────────────────────────────────────
 *   · 整轮只建**一条**会话（MCP 复用 SSE session）；
 *   · MCP 表级 SQL 有界并发（默认 4），结果按 plan 顺序 fan-in；
 *   · 大字段：默认单条 raw result ≤ 16MiB；超限时按 UTF-8 安全截断并标 `truncated:true`
 *     与 `truncatedFields[]`，绝不静默当成完整；
 *   · SQL 失败 / 空结果：尝试 fallbackSql；全部失败 = 该表失败；
 *   · 任一表失败 → **不写成功产物**（并移除本轮旧产物，避免 stale success），
 *     抛 `SchemaRunnerError`；CLI 输出结构化 `{ok:false,...}` 并 exit 1。
 *
 * ── 输出 ────────────────────────────────────────────────────────────────────
 * `<cwd>/plans/backend/_meta/table-structure.raw.json`（可用 outputPath 覆盖；唯一写者=runner）：
 *
 *   {
 *     schemaVersion: 1,
 *     kind: "table-structure.raw",
 *     generatedAt, dialect, channel,
 *     plan: { kind, path, sha256 },
 *     execution: { startedAt, finishedAt, durationMs, session:{opened,reused,queries},
 *                  concurrency, limits:{maxResultBytes}, truncated },
 *     tables: [{
 *       table, expectedShape, usedSql,
 *       attempts: [{sql, role:"primary"|"fallback", success, msg, durationMs, channelResult}],
 *       rawResult,            // 通道返回的实际 payload（可能被截断；见 truncated）
 *       rawRows,              // 机械抽取的行集（数组/对象；text 表不解析）
 *       rowCount, truncated, truncatedFields, originalBytes, returnedBytes,
 *       channelResult,        // MCP task 元数据
 *       executedAt, durationMs
 *     }]
 *   }
 *
 * catalog 模式另写 `<cwd>/plans/backend/_meta/db-table-list.json`（同目录；唯一写者=runner）：
 *
 *   { schemaVersion:1, kind:"db-table-list", generatedAt, dialect, channel,
 *     usedSql, usedSqlTemplate, count:{sql,expected,returned}|null,
 *     attempts, pages:[{offset,limit,rowCount,usedSql,truncated,...}],
 *     catalogPageCount, catalogComplete, catalogExpected, catalogReturned,
 *     rawResult, rawRows, rowCount, tableNames:[...], tableNameColumn,
 *     rawText,             // D6：通道返回的原文（文本表），截断到 8KB
 *     rawTextTruncated,    // rawText 是否被截断（不代表字节预算的 truncated）
 *     truncated, truncatedFields, execution:{...} }
 *
 * ── 通道返回格式适配（D6，方言无关）────────────────────────────────────────
 *   · MCP 等通道可能返回**文本表**（字符串），而不是结构化 rows；
 *   · catalog 路径在结构化为空时按已知形态解析：JSON 字符串 / pipe 表格 /
 *     TSV / 单列换行列表；逐表结构路径仍把文本原文留给 Agent B（rawRows=[]）；
 *   · 非空文本解析 0 行 ⇒ 抛 `SCHEMA_RUN_CATALOG_TEXT_UNPARSED`（内部可修复），
 *     禁止静默空集、禁止置 catalogComplete=true；
 *   · **通道行数上限截断**（沙箱实证 2026-11-04）：MCP 文本表单次最多 100 数据行，
 *     超出时末尾追 `... 共 N 行，已截断`。该标记不是数据行，且代表本页没收全；
 *     runner 据它把有效页大小降到通道实际返回行数继续分页（不回退给 agent），
 *     并在 `pages[].transportTruncated` / `catalogTransportTruncated` 留痕；
 *     截断且无数据行 ⇒ `SCHEMA_RUN_CATALOG_TRANSPORT_TRUNCATED`（内部可修）；
 *   · 原文经 `rawText` 落盘（截断保护），供 agent 诊断/修复格式；
 *   · 方言 SQL 仍由 agent 提案，runner 不新增任何方言 SQL。
 *
 * ── 模块接口 ────────────────────────────────────────────────────────────────
 *   runSchemaPlan(plan, options) -> Promise<{ok:true, outputPath, catalogOutputPath, document, catalogDocument}>
 *   runTablePlan(plan, options)  -> 同上（要求 plan.tables）
 *   runCatalogPlan(plan, options)-> 同上（要求 plan.catalog）
 *   extractRows(payload)         -> 行集抽取（导出供门 B / 单测复用）
 *   extractCatalogRows(payload)  -> catalog 专用：额外解析通道返回的文本表（D6，导出供单测复用）
 *   extractTableNames(rows)      -> { names, column }（导出供门 A / 单测复用）
 *   enforceByteBudget(value, n)  -> { value, truncated, truncatedFields, originalBytes, returnedBytes }
 *   inspectReadOnlySql(sql) / assertReadOnlyBeforeDispatch(sql) -> 只读门禁
 *   renderCatalogPage(sql, limit, offset) / extractCatalogCount(payload, rows)
 *   SchemaRunnerError / SCHEMA_RUNNER_VERSION / RAW_SCHEMA_VERSION / 默认路径常量
 *
 * options（均可选，除连接信息）：
 *   {
 *     channel: "mcp",              // 唯一合法值；显式 "local" 已退役 ⇒ SCHEMA_RUN_CHANNEL_INVALID
 *     cwd, outputPath, catalogOutputPath,
 *     mcp: { dataSourceName, dbName, appId, env, endpoint, timeoutMs },
 *     sourceName, // MCP 取 mcp.dataSourceName，显式传入时必须一致
 *     concurrency, maxResultBytes, write, planRef, now, catalogPageSize,
 *     dependencies: { openMcpSession, executeSqlDirectOnSession } // 单测注入
 *   }
 *
 * ── CLI ─────────────────────────────────────────────────────────────────────
 *   node runner.mjs --plan <path|-> [--channel mcp] [--cwd <dir>]
 *        [--out <path>] [--catalog-out <path>] [--concurrency N]
 *        [--max-result-bytes N] [--quiet]
 *     MCP:   --data-source-name <name> --db-name <db> [--app-id <id>]
 *            [--mcp-env dev] [--mcp-endpoint <url>] [--mcp-timeout-ms N]
 *   显式 --channel local ⇒ SCHEMA_RUN_CHANNEL_INVALID（local 已退役，请经 MCP 重新采集）。
 *   成功：stdout 一行 JSON `{ok:true,...}`，exit 0
 *   失败：stderr 结构化 JSON `{ok:false,code,message,details}`，exit 1
 */

import { createHash } from 'crypto';
import { mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'fs';
import { dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

import {
  executeSqlDirectOnSession,
  openMcpSession,
} from '../mcp-sql-client.mjs';
import { inspectReadOnlySql, PlanValidationError, validatePlan } from './plan-schema.mjs';

export const SCHEMA_RUNNER_VERSION = 1;
export const RAW_SCHEMA_VERSION = 1;
export const TABLE_RAW_REL = 'plans/backend/_meta/table-structure.raw.json';
export const TABLE_LIST_REL = 'plans/backend/_meta/db-table-list.json';
export const DEFAULT_MAX_RESULT_BYTES = 16 * 1024 * 1024;
export const DEFAULT_CONCURRENCY = 4;
export const DEFAULT_CATALOG_PAGE_SIZE = 500;
/** 分页保护：超过该页数视为分页失控（避免 0 行页/服务端不推进时死循环）。 */
export const MAX_CATALOG_PAGES = 10000;

export class SchemaRunnerError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'SchemaRunnerError';
    this.code = code;
    this.details = details;
  }

  toJSON() {
    return {
      ok: false,
      code: this.code,
      message: this.message,
      details: this.details,
    };
  }
}

export const SCHEMA_RUN_SQL_NOT_READONLY = 'SCHEMA_RUN_SQL_NOT_READONLY';
/** 非空文本表解析 0 行：内部可修复（agent 读 rawText 修复格式/重采），不得静默空集。 */
export const SCHEMA_RUN_CATALOG_TEXT_UNPARSED = 'SCHEMA_RUN_CATALOG_TEXT_UNPARSED';
/** 通道文本表截断且无数据行：无法续采（内部可修），不得冒充空库/完整目录。 */
export const SCHEMA_RUN_CATALOG_TRANSPORT_TRUNCATED = 'SCHEMA_RUN_CATALOG_TRANSPORT_TRUNCATED';
/** catalog 原文落盘上限（诊断/agent 输入；与字节预算的 truncated 无关）。 */
export const CATALOG_RAW_TEXT_MAX_BYTES = 8 * 1024;

/**
 * 下发前二次只读校验（纵深防御）。
 *
 * plan-schema 已在入口校验过一次；通道包装仍对**每一条**要真正下发的 SQL 复核
 * （primary / fallback / probe / catalog / catalog.count），失败抛结构化
 * `SCHEMA_RUN_SQL_NOT_READONLY`——不得静默跳过、不得降级为 fallback。
 *
 * @param {string} sql
 * @param {object} [details] 附加上下文（channel / role / table 等）
 * @returns {{readonly:true, keyword:string|null, reason:string}}
 * @throws {SchemaRunnerError}
 */
export function assertReadOnlyBeforeDispatch(sql, details = {}) {
  const verdict = inspectReadOnlySql(sql);
  if (verdict.readonly) return verdict;
  throw new SchemaRunnerError(
    SCHEMA_RUN_SQL_NOT_READONLY,
    `拒绝下发非只读 SQL：${verdict.reason}`,
    { ...details, sql, reason: verdict.reason, keyword: verdict.keyword },
  );
}

const DEFAULT_DEPENDENCIES = Object.freeze({
  openMcpSession,
  executeSqlDirectOnSession,
});

const isPlainObject = (value) =>
  value != null && typeof value === 'object' && !Array.isArray(value);

const bytesOfJson = (value) => {
  try {
    return Buffer.byteLength(JSON.stringify(value) ?? 'null', 'utf8');
  } catch {
    return Infinity;
  }
};

/** UTF-8 安全截断（不把多字节字符切成半个）。 */
export function truncateUtf8(text, maxBytes) {
  const source = String(text);
  if (maxBytes <= 0) return '';
  const buffer = Buffer.from(source, 'utf8');
  if (buffer.length <= maxBytes) return source;
  let end = maxBytes;
  while (end > 0 && (buffer[end] & 0xc0) === 0x80) end -= 1;
  return buffer.subarray(0, end).toString('utf8');
}

function cloneWithStringCap(value, capBytes, path, truncatedFields) {
  if (typeof value === 'string') {
    if (Buffer.byteLength(value, 'utf8') <= capBytes) return value;
    truncatedFields.push(path);
    return truncateUtf8(value, capBytes);
  }
  if (Array.isArray(value)) {
    return value.map((item, index) => cloneWithStringCap(item, capBytes, `${path}[${index}]`, truncatedFields));
  }
  if (isPlainObject(value)) {
    const out = {};
    for (const key of Object.keys(value)) {
      out[key] = cloneWithStringCap(value[key], capBytes, `${path}.${key}`, truncatedFields);
    }
    return out;
  }
  return value;
}

/**
 * 单条 raw result 的字节预算。
 *
 * 未超限：原样返回，`truncated:false`。
 * 超限：所有字符串字段按同一 UTF-8 字节上限截断（非字符串结构保留），
 *       并返回被截断字段路径；调用方必须把 `truncated` 写进产物。
 *
 * @param {unknown} value
 * @param {number} maxBytes 0/负数/null = 不限制
 */
export function enforceByteBudget(value, maxBytes) {
  const originalBytes = bytesOfJson(value);
  if (!maxBytes || maxBytes <= 0 || originalBytes <= maxBytes) {
    return { value, truncated: false, truncatedFields: [], originalBytes, returnedBytes: originalBytes };
  }

  const strings = [];
  const walk = (node, path) => {
    if (typeof node === 'string') {
      strings.push(Buffer.byteLength(node, 'utf8'));
      return;
    }
    if (Array.isArray(node)) {
      node.forEach((item, index) => walk(item, `${path}[${index}]`));
      return;
    }
    if (isPlainObject(node)) {
      for (const key of Object.keys(node)) walk(node[key], `${path}.${key}`);
    }
  };
  walk(value, '$');

  const stringBytes = strings.reduce((sum, size) => sum + size, 0);
  const overhead = Math.max(0, originalBytes - stringBytes);
  // 给 JSON 标点/转义留 64B 余量；字符串份额在全部字符串间均分。
  const budget = Math.max(0, maxBytes - overhead - 64);
  const capBytes = strings.length > 0 ? Math.floor(budget / strings.length) : 0;
  const truncatedFields = [];
  const truncatedValue = cloneWithStringCap(value, capBytes, '$', truncatedFields);
  const returnedBytes = bytesOfJson(truncatedValue);

  return {
    value: truncatedValue,
    truncated: truncatedFields.length > 0 || returnedBytes > maxBytes,
    truncatedFields,
    originalBytes,
    returnedBytes,
  };
}

/**
 * 从通道 payload 机械抽取行集（不做方言归一、不解析文本表）。
 * 文本表保持 rawResult 原文；rawRows 为空数组，由 Agent B 读取原文。
 */
export function extractRows(payload) {
  if (payload == null) return [];
  if (Array.isArray(payload)) return payload;
  if (typeof payload === 'string') return [];
  if (typeof payload === 'object') {
    for (const key of ['rows', 'data', 'records']) {
      if (Array.isArray(payload[key])) return payload[key];
    }
    if (Object.prototype.hasOwnProperty.call(payload, 'result')) {
      const nested = extractRows(payload.result);
      if (nested.length > 0) return nested;
    }
    return [payload];
  }
  return [{ value: payload }];
}

// ─── catalog 文本表解析（D6：通道返回格式适配，不涉及任何方言语义）────────────

/** 把文本表原文截断到安全长度，返回 rawText + 截断标记。 */
function catalogRawTextOf(payload, maxBytes = CATALOG_RAW_TEXT_MAX_BYTES) {
  if (typeof payload !== 'string') return null;
  const bytes = Buffer.byteLength(payload, 'utf8');
  return {
    rawText: bytes > maxBytes ? truncateUtf8(payload, maxBytes) : payload,
    truncated: bytes > maxBytes,
    bytes,
  };
}

/** 文本表行：统一换行、去掉首尾空白行（保留行内内容）。 */
function catalogTextLines(text) {
  return String(text).replace(/\r\n?/g, '\n').split('\n');
}

/** markdown/pipe 表格的分隔行（如 |---|---|），不是数据行。 */
function isTableSeparatorLine(line) {
  const trimmed = line.trim();
  return trimmed.includes('-') && /^[\s|:-]+$/.test(trimmed);
}

/** 去首尾 `|` 后按 `|` 切列。 */
function splitPipeLine(line) {
  let source = line.trim();
  if (source.startsWith('|')) source = source.slice(1);
  if (source.endsWith('|')) source = source.slice(0, -1);
  return source.split('|').map((cell) => cell.trim());
}

function rowFromCells(header, cells) {
  const row = {};
  header.forEach((name, index) => {
    const key = name || `column_${index + 1}`;
    row[key] = cells[index] === undefined ? '' : cells[index];
  });
  return row;
}

/**
 * MCP 文本表通道的行数上限截断标记（沙箱实证 2026-11-04）：
 *   `... 共 200 行，已截断`
 * 通道把单次文本表响应截断在 100 数据行，并在末尾追一行标记（N = SQL 自身的结果行数）。
 * 标记不是数据行，且出现即代表**这一页没收全**——必须据此降页大小续采，不得当完整页。
 */
const TRANSPORT_TRUNCATION_RE = /^\.{3}\s*共\s*(\d+)\s*行\s*[，,]?\s*已截断\s*$/;

/** 一行是否为通道截断标记；是则返回其声明的总行数，否则 null。 */
function transportTruncationRowsOf(line) {
  const match = TRANSPORT_TRUNCATION_RE.exec(String(line).trim());
  if (!match) return null;
  const declared = Number.parseInt(match[1], 10);
  return Number.isInteger(declared) && declared >= 0 ? declared : 0;
}

/**
 * 解析已知文本表形态（首行表头）：
 *   · pipe/`|` 表格（含 markdown 分隔行）；
 *   · TSV（`\t`）；
 *   · 单列换行列表（后续每个非空行一个值）。
 * 通道截断标记行被剔除，并单独回报（`transportTruncated` / `declaredRows`）。
 * 无法识别/无数据行时 rows=[]（由调用方 fail-loud）。
 *
 * @returns {{ rows: Array<object>, transportTruncated: boolean, declaredRows: number|null }}
 */
function parseCatalogTextTable(text) {
  const empty = { rows: [], transportTruncated: false, declaredRows: null };
  const lines = catalogTextLines(text);
  const headerIndex = lines.findIndex((line) => line.trim() !== '');
  if (headerIndex === -1) return empty;
  const headerLine = lines[headerIndex].trim();

  let declaredRows = null;
  const dataLines = [];
  for (const line of lines.slice(headerIndex + 1)) {
    if (line.trim() === '') continue;
    const declared = transportTruncationRowsOf(line);
    if (declared !== null) {
      if (declaredRows === null) declaredRows = declared;
      continue;
    }
    dataLines.push(line);
  }
  const transportTruncated = declaredRows !== null;

  if (headerLine.includes('|')) {
    const header = splitPipeLine(headerLine);
    const rows = [];
    for (const line of dataLines) {
      if (isTableSeparatorLine(line)) continue;
      rows.push(rowFromCells(header, splitPipeLine(line)));
    }
    return { rows, transportTruncated, declaredRows };
  }

  if (headerLine.includes('\t')) {
    const header = headerLine.split('\t').map((cell) => cell.trim());
    return {
      rows: dataLines.map((line) => rowFromCells(header, line.split('\t').map((cell) => cell.trim()))),
      transportTruncated,
      declaredRows,
    };
  }

  // 单列换行列表：首行即列名。
  return {
    rows: dataLines.map((line) => ({ [headerLine]: line.trim() })),
    transportTruncated,
    declaredRows,
  };
}

/** 只要行集（保留旧签名）。 */
function parseCatalogTextRows(text) {
  return parseCatalogTextTable(text).rows;
}

/** JSON 字符串：数组 / 含 rows|data|records 的对象 → 复用结构化分支；其余不算 JSON。 */
function parseCatalogJsonText(text) {
  const trimmed = text.trim();
  if (!trimmed.startsWith('[') && !trimmed.startsWith('{')) return null;
  let parsed;
  try {
    parsed = JSON.parse(trimmed);
  } catch {
    return null;
  }
  if (Array.isArray(parsed)) return extractRows(parsed);
  if (isPlainObject(parsed) && ['rows', 'data', 'records'].some((key) => Array.isArray(parsed[key]))) {
    return extractRows(parsed);
  }
  return null;
}

/**
 * catalog 页解析：文本表的行集 + 通道截断事实（D6 + 截断标记）。
 *
 * `transportTruncated=true` 表示**这一页没收全**（通道在 100 行处截断），
 * 调用方必须据此降页大小续采，不得当完整页/完整目录。
 *
 * @returns {{ rows: Array<object|string|number>, transportTruncated: boolean, declaredRows: number|null }}
 * @throws {SchemaRunnerError}
 */
export function extractCatalogPage(payload) {
  const plain = { rows: [], transportTruncated: false, declaredRows: null };
  if (payload == null) return { ...plain, rows: [] };
  if (typeof payload !== 'string') {
    return { ...plain, rows: extractRows(payload) };
  }

  const text = payload.trim();
  if (!text) return plain;

  const jsonRows = parseCatalogJsonText(payload);
  if (jsonRows !== null) return { ...plain, rows: jsonRows };

  const parsed = parseCatalogTextTable(payload);
  if (parsed.rows.length > 0) return parsed;
  // 已知表头 + 无数据行是明确的空行集；任意说明文本不作空库证据。
  const header = catalogTextLines(payload).find((line) => line.trim() !== '')?.trim() || '';
  if (/^\|?\s*table_?name\s*\|?$/i.test(header) && !parsed.transportTruncated) return parsed;
  // 只有截断标记、没有数据行：也是「这一页没收全」，交分页层处理。
  if (parsed.transportTruncated) return parsed;

  const raw = catalogRawTextOf(payload);
  const firstLine = catalogTextLines(payload).find((line) => line.trim() !== '') || '';
  throw new SchemaRunnerError(
    SCHEMA_RUN_CATALOG_TEXT_UNPARSED,
    `表清单返回非空文本，但无法解析出数据行（首行：${JSON.stringify(firstLine.trim())}）`,
    {
      reason: 'catalog-text-unparsed',
      // 内部可修复：agent 读 rawText 识别格式/修复 SQL 后重采，不进 external/blocked。
      failureClass: 'repairable',
      rawText: raw.rawText,
      rawTextTruncated: raw.truncated,
      rawTextBytes: raw.bytes,
      firstLine: firstLine.trim(),
    },
  );
}

/**
 * catalog 专用行集抽取（保留旧签名）：只要行集。
 *
 * @param {unknown} payload 通道原始 payload
 * @returns {Array<object|string|number>}
 * @throws {SchemaRunnerError}
 */
export function extractCatalogRows(payload) {
  return extractCatalogPage(payload).rows;
}


function isEmptyValue(value) {
  if (value == null) return true;
  if (typeof value === 'string') return value.trim() === '';
  if (Array.isArray(value)) return value.length === 0 || value.every(isEmptyValue);
  if (isPlainObject(value)) {
    const values = Object.values(value);
    return values.length === 0 || values.every(isEmptyValue);
  }
  return false;
}

/**
 * 表清单行集 → 表名（门 A 可直接复用）。
 * 优先 `table_name`，其次 table+name 组合，最后「每行恰好一个键」。
 * 无法机械确定列时返回 column:null + names:[]，由调用方 fail-loud。
 */
export function extractTableNames(rows) {
  if (!Array.isArray(rows) || rows.length === 0) return { names: [], column: null };

  if (rows.every((row) => typeof row === 'string' || typeof row === 'number')) {
    const names = [...new Set(rows.map((row) => String(row).trim()).filter(Boolean))].sort();
    return { names, column: null };
  }

  const objects = rows.filter(isPlainObject);
  if (objects.length !== rows.length) return { names: [], column: null };

  const columns = [...new Set(objects.flatMap((row) => Object.keys(row)))];
  const usable = (key) =>
    objects.every((row) => {
      if (!Object.prototype.hasOwnProperty.call(row, key)) return false;
      const value = row[key];
      return (typeof value === 'string' && value.trim() !== '') || typeof value === 'number';
    });

  const preferred = columns.filter((key) => /^table_?name$/i.test(key));
  const fallback = columns.filter((key) => /table/i.test(key) && /name/i.test(key));
  const single = columns.length === 1 ? columns : [];
  const column = [...preferred, ...fallback, ...single].find(usable) || null;
  if (!column) return { names: [], column: null };

  const names = [
    ...new Set(
      objects
        .map((row) => String(row[column]).trim())
        .filter((name) => name !== ''),
    ),
  ].sort();
  return { names, column };
}

function resolveChannel(options) {
  const explicit = options.channel;
  if (explicit !== undefined && explicit !== null && explicit !== '') {
    if (explicit !== 'mcp') {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_CHANNEL_INVALID',
        explicit === 'local'
          ? 'local 通道已退役，请经 MCP 重新采集'
          : `未知 channel "${explicit}"（只支持 mcp；local 通道已退役，请经 MCP 重新采集）`,
        { channel: explicit },
      );
    }
  }
  if (options.local !== undefined && options.local !== null) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_CHANNEL_INVALID',
      'local 通道已退役，请经 MCP 重新采集',
      { channel: 'local' },
    );
  }
  return 'mcp';
}

function resolveMcpOptions(options) {
  const mcp = options.mcp || {};
  const dataSourceName = mcp.dataSourceName;
  const dbName = mcp.dbName;
  const appId = mcp.appId ?? process.env.APP_ID;
  const env = mcp.env ?? process.env.SQL_EXEC_MCP_ENV ?? 'dev';
  const endpoint = mcp.endpoint ?? process.env.SQL_EXEC_MCP_ENDPOINT ?? undefined;
  const timeoutMs = Number(mcp.timeoutMs) > 0 ? Number(mcp.timeoutMs) : 30_000;
  if (!dataSourceName || !dbName || !appId) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_CONNECTION_INVALID',
      'MCP 通道缺连接参数（dataSourceName / dbName / appId；appId 可来自 APP_ID）',
      { hasDataSourceName: Boolean(dataSourceName), hasDbName: Boolean(dbName), hasAppId: Boolean(appId) },
    );
  }
  return { dataSourceName, dbName, appId, env, endpoint, timeoutMs };
}

function nowIso(clock) {
  return clock();
}

function channelMetaOfMpcResult(result) {
  const task = result && typeof result === 'object' && !Array.isArray(result) ? result : null;
  if (!task) return null;
  return {
    taskId: task.taskId ?? null,
    sql: task.sql ?? null,
    status: task.status ?? null,
    progress: task.progress ?? null,
  };
}

function mcpPayloadOf(result) {
  const task = result && typeof result === 'object' && !Array.isArray(result) ? result : null;
  if (task && Object.prototype.hasOwnProperty.call(task, 'result')) return task.result;
  return result;
}

/**
 * 唯一通道：MCP。所有数据库类型走同一条派发路径（local 通道已退役）。
 */
function buildChannelRunner(channel, options, deps) {
  const mcp = resolveMcpOptions(options);
  return {
    channel,
    async withSession(fn) {
      let session;
      try {
        session = await deps.openMcpSession({
          endpoint: mcp.endpoint,
          timeoutMs: mcp.timeoutMs,
          clientName: 'schema-runner',
        });
      } catch (error) {
        throw new SchemaRunnerError(
          'SCHEMA_RUN_SESSION_FAILED',
          `MCP 会话建立失败：${(error && error.message) || error}`,
          { channel, cause: (error && error.message) || String(error) },
        );
      }
      try {
        return await fn({
          query: async (sql) => {
            assertReadOnlyBeforeDispatch(sql, { channel });
            const started = Date.now();
            const result = await deps.executeSqlDirectOnSession(
              session,
              {
                sql,
                dataSourceName: mcp.dataSourceName,
                dbName: mcp.dbName,
                appId: mcp.appId,
                env: mcp.env,
              },
              mcp.timeoutMs,
            );
            const durationMs = Date.now() - started;
            if (!result.success) {
              const error = new SchemaRunnerError(
                'SCHEMA_RUN_SQL_FAILED',
                `SQL 执行失败：${result.msg || '未知错误'}`,
                { sql, channel, msg: result.msg || '' },
              );
              error.sqlFailure = true;
              throw error;
            }
            return {
              payload: mcpPayloadOf(result.result),
              channelResult: channelMetaOfMpcResult(result.result),
              durationMs,
            };
          },
          isBroken: () => session.isBroken?.() === true,
        });
      } finally {
        session.close?.();
      }
    },
  };
}

function emptyFailure(code, message, details) {
  return new SchemaRunnerError(code, message, details);
}

/**
 * 执行一条候选 SQL（primary/fallback），返回统一结果。
 * SQL 失败/空结果都是「该候选失败」，由调用方决定是否继续 fallback。
 *
 * `allowEmpty:true` 用于目录分页：空表库 / 精确整页后的尾页（0 行）是合法结果，
 * 不能被当成通道失败。
 */
async function executeCandidate({ sql, role, query, maxResultBytes, allowEmpty = false }) {
  const started = Date.now();
  try {
    const response = await query(sql);
    const durationMs = Date.now() - started;
    const payload = response.payload;
    if (isEmptyValue(payload)) {
      const explicitEmpty = Array.isArray(payload) && payload.length === 0 ||
        isPlainObject(payload) && ['rows', 'data', 'records'].some((key) => Array.isArray(payload[key]) && payload[key].length === 0);
      if (allowEmpty && explicitEmpty) {
        return {
          ok: true,
          attempt: {
            sql,
            role,
            success: true,
            msg: '',
            durationMs,
            channelResult: response.channelResult ?? null,
            truncated: false,
            truncatedFields: [],
          },
          payload: [],
          rows: [],
          truncated: false,
          truncatedFields: [],
          originalBytes: 0,
          returnedBytes: 0,
          channelResult: response.channelResult ?? null,
          durationMs,
        };
      }
      return {
        ok: false,
        attempt: {
          sql,
          role,
          success: false,
          msg: '结果缺失或无可用证据（不能作为零行结果）',
          durationMs,
          channelResult: response.channelResult ?? null,
        },
      };
    }
    const budget = enforceByteBudget(payload, maxResultBytes);
    return {
      ok: true,
      attempt: {
        sql,
        role,
        success: true,
        msg: '',
        durationMs,
        channelResult: response.channelResult ?? null,
        truncated: budget.truncated,
        truncatedFields: budget.truncatedFields,
      },
      payload: budget.value,
      rows: extractRows(budget.value),
      truncated: budget.truncated,
      truncatedFields: budget.truncatedFields,
      originalBytes: budget.originalBytes,
      returnedBytes: budget.returnedBytes,
      channelResult: response.channelResult ?? null,
      durationMs,
    };
  } catch (error) {
    // 只读门禁是硬失败：不得被当成普通 SQL 失败进入 fallback/表失败聚合。
    if (error && error.code === SCHEMA_RUN_SQL_NOT_READONLY) throw error;
    const durationMs = Date.now() - started;
    return {
      ok: false,
      sessionBroken: error && error.sqlFailure !== true ? false : undefined,
      attempt: {
        sql,
        role,
        success: false,
        msg: (error && error.message) || String(error),
        durationMs,
        channelResult: null,
        errorCode: (error && error.code) || null,
      },
      error,
    };
  }
}

async function executeTableEntry(entry, query, { maxResultBytes, isBroken }) {
  const candidates = [
    { sql: entry.sql, role: 'primary' },
    ...(entry.fallbackSql || []).map((sql) => ({ sql, role: 'fallback' })),
  ];
  const attempts = [];
  for (const candidate of candidates) {
    const result = await executeCandidate({ ...candidate, query, maxResultBytes });
    attempts.push(result.attempt);
    if (result.ok) {
      return {
        ok: true,
        entry: {
          table: entry.table,
          dataSourceName: entry.dataSourceName,
          expectedShape: entry.expectedShape,
          usedSql: candidate.sql,
          attempts,
          rawResult: result.payload,
          rawRows: result.rows,
          rowCount: Array.isArray(result.rows) ? result.rows.length : null,
          truncated: result.truncated,
          truncatedFields: result.truncatedFields,
          originalBytes: result.originalBytes,
          returnedBytes: result.returnedBytes,
          channelResult: result.channelResult,
          executedAt: null,
          durationMs: attempts.reduce((sum, attempt) => sum + (attempt.durationMs || 0), 0),
        },
      };
    }
    // 会话级断开：后续候选/表都不再尝试（避免把整批记成假失败）。
    if (typeof isBroken === 'function' && isBroken()) {
      return { ok: false, attempts, broken: true, lastError: result.error };
    }
    // 单条 SQL 业务失败可继续 fallback；网络/会话错误也继续由 isBroken 判定。
  }
  const lastAttempt = attempts[attempts.length - 1];
  return {
    ok: false,
    attempts,
    broken: false,
    failure: {
      table: entry.table,
      dataSourceName: entry.dataSourceName,
      expectedShape: entry.expectedShape,
      usedSql: lastAttempt ? lastAttempt.sql : null,
      attempts,
      lastError: lastAttempt
        ? { message: lastAttempt.msg, code: lastAttempt.errorCode ?? null }
        : { message: '无候选 SQL', code: null },
    },
  };
}

async function executeCandidates(candidates, query, { maxResultBytes, allowEmpty }) {
  const attempts = [];
  for (const candidate of candidates) {
    const result = await executeCandidate({ ...candidate, query, maxResultBytes });
    attempts.push(result.attempt);
    if (result.ok) return { ok: true, attempts, result };
    if (allowEmpty && result.attempt.msg === '空结果（不得作为证据）') {
      return {
        ok: true,
        attempts,
        result: {
          payload: [],
          rows: [],
          truncated: false,
          truncatedFields: [],
          originalBytes: 0,
          returnedBytes: 0,
          channelResult: result.attempt.channelResult,
          durationMs: result.attempt.durationMs,
        },
      };
    }
  }
  return { ok: false, attempts, lastAttempt: attempts[attempts.length - 1] };
}

function writeJsonAtomic(filePath, document) {
  mkdirSync(dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  writeFileSync(tempPath, `${JSON.stringify(document, null, 2)}\n`, 'utf-8');
  renameSync(tempPath, filePath);
}

function safeRemove(filePath) {
  try {
    rmSync(filePath, { force: true });
  } catch {
    /* 旧产物清理失败不遮住主错误 */
  }
}

/** 从探针结果机械取一个版本/能力值（不做方言解释）。 */
export function extractProbeValue(payload, rows = []) {
  if (typeof payload === 'string') {
    const text = payload.trim();
    if (!text) return '';
    // MCP 文本表 = 表头行 + 数据行（如 `version\n8.0.46`）：取值必须跳表头。
    const { rows: textRows } = parseCatalogTextTable(text);
    const firstRow = textRows[0];
    if (isPlainObject(firstRow)) {
      const values = Object.values(firstRow);
      if (values.length > 0) {
        const value = values[0];
        return value == null ? '' : String(value).trim();
      }
    }
    // 非表格形态（纯标量文本）才回落到首行。
    const line = text.split(/\r?\n/).map((item) => item.trim()).find(Boolean);
    return line || '';
  }
  const candidates = Array.isArray(rows) && rows.length > 0 ? rows : extractRows(payload);
  if (candidates.length === 0) return '';
  const first = candidates[0];
  if (typeof first === 'string' || typeof first === 'number') return String(first).trim();
  if (isPlainObject(first)) {
    const keys = Object.keys(first);
    const preferred =
      keys.find((key) => /^(version|server_?version|banner|value|result)$/i.test(key)) ||
      keys.find((key) => /version|banner/i.test(key)) ||
      (keys.length === 1 ? keys[0] : null);
    if (preferred) {
      const value = first[preferred];
      return value == null ? '' : String(value).trim();
    }
  }
  return '';
}

/**
 * 能力探针（best-effort）：执行 agent 提案的版本/能力 SQL，记录 raw。
 * 失败不抛出、不阻断采集；code-schema 的 completeness 会因缺 serverVersion 降级。
 */
async function runProbe({ plan, channelRunner, channelCtx, maxResultBytes, clock }) {
  const probe = plan.probe;
  const candidates = [
    { sql: probe.versionSql, role: 'primary' },
    ...(probe.fallbackSql || []).map((sql) => ({ sql, role: 'fallback' })),
  ];
  const startedAt = clock();
  const startedMs = Date.now();
  const outcome = await executeCandidates(candidates, channelCtx.query, {
    maxResultBytes,
    // 版本查询返回空 = 探针失败（不得当成功）。
    allowEmpty: false,
  });
  const finishedAt = clock();
  const durationMs = Date.now() - startedMs;

  if (!outcome.ok) {
    const last = outcome.lastAttempt || null;
    return {
      document: {
        ok: false,
        kind: 'probe',
        startedAt,
        finishedAt,
        durationMs,
        attempts: outcome.attempts,
        usedSql: last ? last.sql : null,
        rawResult: null,
        rawRows: [],
        value: '',
        truncated: false,
        error: last ? { message: last.msg, code: last.errorCode ?? null } : { message: '无候选 SQL', code: null },
      },
      queries: outcome.attempts.length,
    };
  }

  const result = outcome.result;
  const value = extractProbeValue(result.payload, result.rows);
  return {
    document: {
      ok: Boolean(value) && result.truncated !== true,
      kind: 'probe',
      startedAt,
      finishedAt,
      durationMs,
      attempts: outcome.attempts,
      usedSql: outcome.attempts[outcome.attempts.length - 1]?.sql ?? null,
      rawResult: result.payload,
      rawRows: result.rows,
      rowCount: Array.isArray(result.rows) ? result.rows.length : null,
      value,
      truncated: result.truncated,
      truncatedFields: result.truncatedFields,
      originalBytes: result.originalBytes,
      returnedBytes: result.returnedBytes,
      channelResult: result.channelResult,
      error: value ? null : { message: '探针结果无法机械取值', code: null },
    },
    queries: outcome.attempts.length,
  };
}

/** Agent 提供分页模板；这里只替换数值参数，不识别 SQL 方言或分页语法。 */
export function renderCatalogPage(sql, limit, offset) {
  const source = String(sql);
  const hasOffset = source.includes('{{offset}}');
  const hasSize = source.includes('{{limit}}') || source.includes('{{end}}');
  if (!hasOffset || !hasSize) return null;
  const values = { limit, offset, end: offset + limit };
  return source.replace(/\{\{(limit|offset|end)\}\}/g, (_, key) => String(values[key]));
}

/**
 * 从 COUNT 结果机械取总数（优先 cnt/count/total 列；单列/标量亦可）。
 * @returns {{ok:true, value:number} | {ok:false, reason:string}}
 */
export function extractCatalogCount(payload, rows = []) {
  let candidates;
  try {
    candidates = Array.isArray(rows) && rows.length > 0 ? rows
      : typeof payload === 'string'
        ? (/^\d+$/.test(payload.trim()) ? [payload.trim()] : extractCatalogPage(payload).rows)
        : extractRows(payload);
  } catch (error) {
    return { ok: false, reason: `COUNT 结果无法解析：${error.message}` };
  }
  if (!Array.isArray(candidates) || candidates.length === 0) {
    return { ok: false, reason: 'COUNT 查询返回空结果' };
  }
  const first = candidates[0];
  const asCount = (value) => {
    if (typeof value !== 'number' && (typeof value !== 'string' || !/^\d+$/.test(value.trim()))) return null;
    const n = Number(value);
    return Number.isSafeInteger(n) && n >= 0 ? { ok: true, value: n } : null;
  };
  if (typeof first === 'number' || typeof first === 'string') {
    return asCount(first) || { ok: false, reason: `COUNT 结果不是非负整数（${JSON.stringify(first)}）` };
  }
  if (isPlainObject(first)) {
    const keys = Object.keys(first);
    const key =
      keys.find((item) => /^(cnt|count|total|table_count|tablecount)$/i.test(item)) ||
      (keys.length === 1 ? keys[0] : null);
    if (key) {
      return asCount(first[key]) || { ok: false, reason: `COUNT 列 "${key}" 不是非负整数（${JSON.stringify(first[key])}）` };
    }
  }
  return { ok: false, reason: '无法从 COUNT 结果机械取值（需 cnt/count/total 列或单列标量）' };
}

/** 目录分页大小：options.catalogPageSize > options.pageSize > plan.catalog.pageSize > 500。 */
function resolveCatalogPageSize(plan, options) {
  const raw = options.catalogPageSize ?? options.pageSize ?? plan.catalog.pageSize;
  if (raw === undefined || raw === null) return DEFAULT_CATALOG_PAGE_SIZE;
  const size = Number(raw);
  if (!Number.isInteger(size) || size <= 0) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_CATALOG_PAGING_INVALID',
      `目录分页 pageSize 非法（${JSON.stringify(raw)}；须为正整数）`,
      { pageSize: raw },
    );
  }
  return size;
}

function catalogRowKey(row, column) {
  if (column && isPlainObject(row) && Object.prototype.hasOwnProperty.call(row, column)) {
    return `${column}=${String(row[column])}`;
  }
  if (row === undefined) return 'row=undefined';
  try {
    return `row=${JSON.stringify(row)}`;
  } catch {
    return `row=${String(row)}`;
  }
}

/**
 * 对单个候选 SQL 做完整分页。
 *
 * - 每页填入 Agent 模板的 limit/offset/end 数值，直到返回行数 < pageSize；
 * - 页间列不一致 / 出现重复行 ⇒ `SCHEMA_RUN_CATALOG_PAGE_INCONSISTENT`（不当作完整目录）；
 * - 任一分页 SQL 失败 ⇒ 返回 ok:false（由调用方决定是否换 fallback 候选）。
 */
async function paginateCatalogCandidate({ candidate, pageSize, query, maxResultBytes, channel }) {
  const pages = [];
  const rows = [];
  const attempts = [];
  const truncatedFields = [];
  const seen = new Set();
  let tableNameColumn = null;
  let truncated = false;
  let offset = 0;
  // 通道文本表有行数上限（沙箱实证：100 行 + `... 共 N 行，已截断` 标记）。
  // 首见截断即把有效页大小降到通道实际返回行数，继续分页——自闭环，不回退给 agent。
  let effectivePageSize = pageSize;
  let transportTruncated = false;
  // D6：文本表原文（截断到 8KB）供诊断/agent 修复；只累计前 8KB。
  let rawText = '';
  let rawTextTruncated = false;

  for (let pageIndex = 0; ; pageIndex += 1) {
    if (pageIndex >= MAX_CATALOG_PAGES) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_CATALOG_PAGING_INVALID',
        `目录分页超过 ${MAX_CATALOG_PAGES} 页，疑似分页未推进`,
        { channel, pageSize: effectivePageSize, offset, pageCount: pages.length },
      );
    }
    const rendered = renderCatalogPage(candidate.sql, effectivePageSize, offset);
    const pageSql = rendered ?? candidate.sql;
    const outcome = await executeCandidate({
      sql: pageSql,
      role: candidate.role,
      query,
      maxResultBytes,
      // 空表库 / 精确整页后的尾页（0 行）是合法分页结果。
      allowEmpty: true,
    });
    attempts.push(outcome.attempt);
    if (!outcome.ok) {
      return { ok: false, attempts, pages, rows, lastAttempt: outcome.attempt, offset };
    }

    // D6：MCP 等通道可能返回文本表（字符串）——仅 catalog 路径做格式适配；
    // 逐表结构路径的 rawRows 仍保持 []，原文留给 Agent B。
    let pageRows = outcome.rows;
    let pageTransportTruncated = false;
    let pageDeclaredRows = null;
    if (
      (!Array.isArray(pageRows) || pageRows.length === 0) &&
      typeof outcome.payload === 'string' &&
      outcome.payload.trim() !== ''
    ) {
      const parsedPage = extractCatalogPage(outcome.payload);
      pageRows = parsedPage.rows;
      pageTransportTruncated = parsedPage.transportTruncated === true;
      pageDeclaredRows = parsedPage.declaredRows ?? null;
    }
    const pageLimit = effectivePageSize;
    if (pageTransportTruncated) {
      // 通道截断但一行都没解析出来：无法续采，结构化可修失败（不冒充空库/完整目录）。
      if (pageRows.length === 0) {
        throw new SchemaRunnerError(
          'SCHEMA_RUN_CATALOG_TRANSPORT_TRUNCATED',
          `表清单第 ${pageIndex + 1} 页被通道截断且无数据行（声明共 ${String(pageDeclaredRows)} 行，offset=${offset}）`,
          {
            channel,
            pageSize: effectivePageSize,
            offset,
            declaredRows: pageDeclaredRows,
            failureClass: 'repairable',
          },
        );
      }
      transportTruncated = true;
    }
    const pageRawText = catalogRawTextOf(outcome.payload);
    if (pageRawText && !rawTextTruncated) {
      const remaining = CATALOG_RAW_TEXT_MAX_BYTES - Buffer.byteLength(rawText, 'utf8') - (rawText ? 1 : 0);
      if (remaining <= 0) {
        rawTextTruncated = true;
      } else {
        const piece = truncateUtf8(pageRawText.rawText, remaining);
        rawText = rawText ? `${rawText}\n${piece}` : piece;
        if (Buffer.byteLength(piece, 'utf8') < pageRawText.bytes) rawTextTruncated = true;
      }
    }

    const pageNames = extractTableNames(pageRows);
    if (pageIndex === 0) {
      tableNameColumn = pageNames.column;
    } else if (pageRows.length > 0 && pageNames.column !== tableNameColumn) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_CATALOG_PAGE_INCONSISTENT',
        `目录分页列不一致（第 ${pageIndex + 1} 页 tableNameColumn=${JSON.stringify(pageNames.column)}，首页 ${JSON.stringify(tableNameColumn)}）`,
        { channel, pageIndex, pageSize, offset },
      );
    }

    for (const row of pageRows) {
      const key = catalogRowKey(row, tableNameColumn);
      if (seen.has(key)) {
        throw new SchemaRunnerError(
          'SCHEMA_RUN_CATALOG_PAGE_INCONSISTENT',
          `目录分页出现跨页重复行（${key}），分页结果不稳定`,
          { channel, pageIndex, pageSize, offset, duplicate: key },
        );
      }
      seen.add(key);
    }

    rows.push(...pageRows);
    if (outcome.truncated) {
      truncated = true;
      truncatedFields.push(...outcome.truncatedFields.map((field) => `pages[${pageIndex}]${field}`));
    }
    pages.push({
      offset,
      limit: pageLimit,
      rowCount: pageRows.length,
      usedSql: pageSql,
      truncated: outcome.truncated,
      truncatedFields: outcome.truncatedFields,
      // 通道文本表行数上限导致的截断（与字节截断/分页完整性分开记录）。
      transportTruncated: pageTransportTruncated,
      ...(pageDeclaredRows === null ? {} : { declaredRows: pageDeclaredRows }),
      originalBytes: outcome.originalBytes,
      returnedBytes: outcome.returnedBytes,
      durationMs: outcome.durationMs,
      // D6：通道原文（文本表形态）截断到 8KB，供诊断/agent 修复；非文本通道为 null。
      rawText: pageRawText ? pageRawText.rawText : null,
      rawTextTruncated: pageRawText ? pageRawText.truncated : false,
    });

    if (rendered === null) {
      // 单次原样查询必须由 COUNT 证明完整；截断不能被 COUNT 偶然匹配掩盖。
      return { ok: true, attempts, pages, rows, tableNameColumn, truncated, truncatedFields,
        transportTruncated, effectivePageSize, rawText, rawTextTruncated, singleQuery: true };
    }

    if (pageTransportTruncated) {
      // 本页按 ORDER BY 顺序取到了通道能给的整段：把有效页大小降到实际行数继续下一个 offset。
      effectivePageSize = Math.max(1, Math.min(pageLimit, pageRows.length));
      offset += pageRows.length;
      continue;
    }

    if (pageRows.length < pageLimit) {
      return {
        ok: true,
        attempts,
        pages,
        rows,
        tableNameColumn,
        truncated,
        truncatedFields,
        transportTruncated,
        effectivePageSize,
        rawText,
        rawTextTruncated,
      };
    }
    offset += pageLimit;
  }
}

async function runCatalog({ plan, channelRunner, channelCtx, options, maxResultBytes, clock }) {
  const catalog = plan.catalog;
  const startedAt = clock();
  const startedMs = Date.now();
  const pageSize = resolveCatalogPageSize(plan, options);

  const rawCandidates = [
    { sql: catalog.listTablesSql, role: 'primary' },
    ...(catalog.fallbackSql || []).map((sql) => ({ sql, role: 'fallback' })),
  ];
  // 兼容不含模板的原样 SQL，但须提供 COUNT，避免把固定第一页当成完整目录。
  const candidates = rawCandidates;
  for (const candidate of candidates) {
    if (renderCatalogPage(candidate.sql, pageSize, 0) === null && !catalog.countSql) {
      throw new SchemaRunnerError('SCHEMA_RUN_CATALOG_COMPLETENESS_REQUIRED',
        '目录查询须提供 {{offset}} 和 {{limit}}（或 {{end}}）分页模板，或提供 countSql 对账；runner 不改写 SQL',
        { channel: channelRunner.channel, pageSize });
    }
  }

  let paged = null;
  let usedCandidate = null;
  let attempts = [];
  let lastFailure = null;
  for (const candidate of candidates) {
    const outcome = await paginateCatalogCandidate({
      candidate,
      pageSize,
      query: channelCtx.query,
      maxResultBytes,
      channel: channelRunner.channel,
    });
    attempts = attempts.concat(outcome.attempts);
    if (outcome.ok) {
      paged = outcome;
      usedCandidate = candidate;
      break;
    }
    lastFailure = outcome;
  }

  if (!paged) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_CATALOG_FAILED',
      `表清单 preflight 全部候选失败：${lastFailure?.lastAttempt?.msg || '未知错误'}`,
      {
        channel: channelRunner.channel,
        attempts,
        pageSize,
        failedAtOffset: lastFailure?.offset ?? null,
        outputPath: options.catalogOutputPath,
      },
    );
  }

  // COUNT 对账（可选）：分页行数与 COUNT 不一致 = 目录不完整，结构化红。
  let expected = null;
  let countAttempts = [];
  if (catalog.countSql) {
    const countOutcome = await executeCandidates(
      [{ sql: catalog.countSql, role: 'count' }],
      channelCtx.query,
      { maxResultBytes, allowEmpty: false },
    );
    countAttempts = countOutcome.attempts;
    if (!countOutcome.ok) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_CATALOG_COUNT_FAILED',
        `表清单 COUNT 对账查询失败：${countOutcome.lastAttempt?.msg || '未知错误'}`,
        { channel: channelRunner.channel, attempts: countOutcome.attempts },
      );
    }
    const parsed = extractCatalogCount(countOutcome.result.payload, countOutcome.result.rows);
    if (!parsed.ok) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_CATALOG_COUNT_INVALID',
        `无法从 COUNT 结果机械取值：${parsed.reason}`,
        { channel: channelRunner.channel, attempts: countOutcome.attempts },
      );
    }
    expected = parsed.value;
    if (expected !== paged.rows.length) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_CATALOG_COUNT_MISMATCH',
        `目录分页不完整：COUNT=${expected}，分页返回 ${paged.rows.length} 行`,
        {
          channel: channelRunner.channel,
          expected,
          returned: paged.rows.length,
          pageSize,
          pageCount: paged.pages.length,
        },
      );
    }
  }

  const rows = paged.rows;
  const { names, column } = extractTableNames(rows);
  if (rows.length > 0 && names.length === 0) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_CATALOG_UNPARSEABLE',
      '表清单结果非空，但无法机械确定表名列（需返回 table_name 或单列行集）',
      {
        channel: channelRunner.channel,
        rowCount: rows.length,
        sampleRow: rows[0],
        usedSql: usedCandidate ? usedCandidate.sql : null,
      },
    );
  }

  const finishedAt = clock();
  const lastPage = paged.pages[paged.pages.length - 1] || null;
  const countMatched = expected !== null && expected === rows.length;
  const reachedEnd = lastPage !== null && lastPage.transportTruncated !== true &&
    Number.isInteger(lastPage.limit) && lastPage.rowCount < lastPage.limit;
  const catalogComplete = !paged.truncated && (paged.singleQuery
    ? !paged.transportTruncated && countMatched
    : reachedEnd || countMatched);
  if (paged.singleQuery && !catalogComplete) {
    throw new SchemaRunnerError('SCHEMA_RUN_CATALOG_INCOMPLETE',
      '原样目录查询未取得完整结果，请由 Agent 提供分页模板后重采',
      { channel: channelRunner.channel, expected, returned: rows.length, truncated: paged.truncated, transportTruncated: paged.transportTruncated });
  }
  const allAttempts = [...attempts, ...countAttempts];

  return {
    document: {
      schemaVersion: RAW_SCHEMA_VERSION,
      kind: 'db-table-list',
      generatedAt: clock(),
      dataSourceName: options.sourceName ?? null,
      dialect: plan.dialect,
      channel: channelRunner.channel,
      usedSql: lastPage ? lastPage.usedSql : null,
      usedSqlTemplate: usedCandidate ? usedCandidate.sql : null,
      count: catalog.countSql
        ? { sql: catalog.countSql, expected, returned: rows.length }
        : null,
      attempts: allAttempts,
      pages: paged.pages,
      catalogPageCount: paged.pages.length,
      catalogComplete,
      // 通道文本表截断事实（true 时 catalogComplete 仍可为 true：已在更小页大小下续采完整）。
      catalogTransportTruncated: paged.transportTruncated === true,
      catalogEffectivePageSize: paged.effectivePageSize ?? pageSize,
      catalogExpected: expected,
      catalogReturned: rows.length,
      rawResult: rows,
      rawRows: rows,
      rowCount: rows.length,
      tableNames: names,
      tableNameColumn: column,
      // D6：通道原文（跨页拼接，最多 8KB）；非文本通道为 null。
      rawText: paged.rawText || null,
      rawTextTruncated: paged.rawTextTruncated === true,
      truncated: paged.truncated,
      truncatedFields: paged.truncatedFields,
      execution: {
        startedAt,
        finishedAt,
        durationMs: Date.now() - startedMs,
        session: { opened: 1, reused: true, queries: allAttempts.length },
        limits: { maxResultBytes, catalogPageSize: pageSize },
      },
    },
    tableNames: names,
    queries: allAttempts.length,
    truncated: paged.truncated,
  };
}

async function runTables({ plan, channelRunner, channelCtx, options, maxResultBytes, clock }) {
  const entries = plan.tables;
  const concurrency = Math.max(1, Math.floor(Number(options.concurrency) || DEFAULT_CONCURRENCY));
  const { query, isBroken } = channelCtx;
  {
    const startedAt = clock();
    const startedMs = Date.now();
    const results = new Array(entries.length);
    let nextIndex = 0;
    let broken = false;
    let brokenError = null;

    const worker = async () => {
      while (!broken) {
        const index = nextIndex++;
        if (index >= entries.length) return;
        let outcome;
        try {
          outcome = await executeTableEntry(entries[index], query, { maxResultBytes, isBroken });
        } catch (error) {
          if (error && error.code === SCHEMA_RUN_SQL_NOT_READONLY) throw error;
          outcome = {
            ok: false,
            broken: true,
            attempts: [],
            lastError: error,
            failure: {
              table: entries[index].table,
              expectedShape: entries[index].expectedShape,
              usedSql: null,
              attempts: [],
              lastError: { message: (error && error.message) || String(error), code: null },
            },
          };
        }
        if (outcome.broken) {
          broken = true;
          brokenError = outcome.lastError || null;
        }
        results[index] = outcome;
      }
    };

    await Promise.all(
      Array.from({ length: Math.min(concurrency, entries.length) }, () => worker()),
    );

    const finishedAt = clock();
    const durationMs = Date.now() - startedMs;
    const failures = results
      .map((result, index) =>
        result && !result.ok
          ? result.failure || {
              table: entries[index].table,
              expectedShape: entries[index].expectedShape,
              usedSql: null,
              attempts: result.attempts || [],
              lastError: { message: '未知失败', code: null },
            }
          : null,
      )
      .filter(Boolean);
    const tableDocuments = results
      .map((result, index) => {
        if (!result || !result.ok) return null;
        return {
          ...result.entry,
          executedAt: finishedAt,
        };
      })
      .filter(Boolean);
    const queries = results.reduce((sum, result) => {
      const attempts = result?.ok ? result.entry?.attempts : result?.attempts;
      return sum + (attempts?.length || 0);
    }, 0);

    if (broken || failures.length > 0) {
      const reason = broken
        ? `会话中断，采集中止：${(brokenError && brokenError.message) || '未知错误'}`
        : `有 ${failures.length} 张表采集失败`;
      throw new SchemaRunnerError('SCHEMA_RUN_TABLE_FAILED', reason, {
        channel: channelRunner.channel,
        failures,
        tablesRequested: entries.length,
        tablesSucceeded: tableDocuments.length,
        outputPath: options.outputPath,
      });
    }

    return {
      document: {
        schemaVersion: RAW_SCHEMA_VERSION,
        kind: 'table-structure.raw',
        generatedAt: clock(),
        dataSourceName: options.sourceName ?? null,
        dialect: plan.dialect,
        channel: channelRunner.channel,
        plan: {
          kind: plan.catalog ? 'tables+catalog' : 'tables',
          path: options.planRef?.path ?? null,
          sha256: options.planRef?.sha256 ?? null,
        },
        execution: {
          startedAt,
          finishedAt,
          durationMs,
          session: { opened: 1, reused: true, queries },
          concurrency,
          limits: { maxResultBytes },
          truncated: tableDocuments.some((table) => table.truncated),
        },
        tables: tableDocuments,
      },
      tableCount: tableDocuments.length,
      truncated: tableDocuments.some((table) => table.truncated),
      queries,
    };
  }
}

/**
 * 执行 plan。
 *
 * @param {object} plan 见文件头契约
 * @param {object} [options]
 * @returns {Promise<{ok:true, outputPath:string|null, catalogOutputPath:string|null,
 *   document:object|null, catalogDocument:object|null}>}
 * @throws {PlanValidationError|SchemaRunnerError}
 */
export async function runSchemaPlan(plan, options = {}) {
  const validated = validatePlan(plan);
  const normalizedPlan = validated.plan;
  const deps = { ...DEFAULT_DEPENDENCIES, ...(options.dependencies || {}) };
  const clock = typeof options.now === 'function' ? options.now : () => new Date().toISOString();
  const cwd = options.cwd ? resolve(options.cwd) : process.cwd();
  const write = options.write !== false;
  const outputPath = options.outputPath
    ? resolve(cwd, options.outputPath)
    : resolve(cwd, TABLE_RAW_REL);
  const catalogOutputPath = options.catalogOutputPath
    ? resolve(cwd, options.catalogOutputPath)
    : resolve(cwd, TABLE_LIST_REL);
  const maxResultBytes =
    options.maxResultBytes === undefined
      ? DEFAULT_MAX_RESULT_BYTES
      : Number(options.maxResultBytes) || 0;

  const channel = resolveChannel(options);
  const channelRunner = buildChannelRunner(channel, options, deps);

  // 一次 runner 只执行一个已解析连接，不能用连接身份覆盖 plan 中的错误归属。
  const connectionSource = options.mcp?.dataSourceName;
  const sourceName = typeof connectionSource === 'string' ? connectionSource.trim() : '';
  if (
    normalizedPlan.tables?.length && options.sourceName !== undefined &&
    (typeof options.sourceName !== 'string' || options.sourceName.trim() !== sourceName)
  ) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_DATASOURCE_MISMATCH',
      `sourceName=${JSON.stringify(options.sourceName)} 与执行连接数据源 ${JSON.stringify(sourceName)} 不一致`,
      { actual: options.sourceName, expected: sourceName || null },
    );
  }
  for (const [index, entry] of (normalizedPlan.tables || []).entries()) {
    if (!sourceName || entry.dataSourceName !== sourceName) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_DATASOURCE_MISMATCH',
        `tables[${index}].dataSourceName=${JSON.stringify(entry.dataSourceName)} 与执行连接数据源 ${JSON.stringify(sourceName)} 不一致；请核对已确认连接及逐表归属`,
        { index, table: entry.table, actual: entry.dataSourceName, expected: sourceName || null },
      );
    }
  }
  const executionOptions = { ...options, sourceName: sourceName || options.sourceName };

  // 先清旧产物：失败轮不得留下 stale success 被下游误读。
  if (write) {
    if (normalizedPlan.catalog) safeRemove(catalogOutputPath);
    if (normalizedPlan.tables) safeRemove(outputPath);
  }

  let catalogDocument = null;
  let catalogTableNames = null;
  let catalogQueries = 0;
  let catalogTruncated = false;
  let probeDocument = null;
  let probeQueries = 0;
  let document = null;

  try {
    // 整轮只建一条会话/连接：catalog preflight 与逐表采集复用同一通道。
    await channelRunner.withSession(async (channelCtx) => {
      if (normalizedPlan.probe) {
        const probeOutcome = await runProbe({
          plan: normalizedPlan,
          channelRunner,
          channelCtx,
          maxResultBytes,
          clock,
        });
        probeDocument = probeOutcome.document;
        probeQueries = probeOutcome.queries;
      }

      if (normalizedPlan.catalog) {
        const catalogOutcome = await runCatalog({
          plan: normalizedPlan,
          channelRunner,
          channelCtx,
          options: { ...executionOptions, catalogOutputPath },
          maxResultBytes,
          clock,
        });
        catalogDocument = catalogOutcome.document;
        catalogTableNames = catalogOutcome.tableNames;
        catalogQueries = catalogOutcome.queries;
        catalogTruncated = catalogOutcome.truncated;
      }

      if (normalizedPlan.tables) {
        const tablesOutcome = await runTables({
          plan: normalizedPlan,
          channelRunner,
          channelCtx,
          options: { ...executionOptions, outputPath },
          maxResultBytes,
          clock,
        });
        document = tablesOutcome.document;
      }
    });
  } catch (error) {
    if (error instanceof SchemaRunnerError) {
      error.details = {
        ...(error.details || {}),
        catalogTableNames,
        catalogQueries,
      };
    }
    throw error;
  }

  if (document && catalogDocument) {
    document.execution.session.queries += catalogQueries;
    document.execution.truncated = document.execution.truncated || catalogTruncated;
  }

  // 探针是附加证据，best-effort；失败不改变采集成功/失败语义。
  if (probeDocument) {
    const target = document || catalogDocument;
    if (target) {
      target.probe = probeDocument;
      if (target.execution?.session) {
        target.execution.session.queries = (target.execution.session.queries || 0) + probeQueries;
      }
      if (target.execution && probeDocument.truncated) target.execution.truncated = true;
    }
  }

  if (write) {
    try {
      if (catalogDocument) writeJsonAtomic(catalogOutputPath, catalogDocument);
      if (document) writeJsonAtomic(outputPath, document);
    } catch (error) {
      throw new SchemaRunnerError(
        'SCHEMA_RUN_WRITE_FAILED',
        `raw 产物写入失败：${(error && error.message) || error}`,
        { outputPath, catalogOutputPath, cause: (error && error.message) || String(error) },
      );
    }
  }

  return {
    ok: true,
    outputPath: document ? outputPath : null,
    catalogOutputPath: catalogDocument ? catalogOutputPath : null,
    document,
    catalogDocument,
    catalogTableNames,
    probe: probeDocument,
  };
}

/** 只允许逐表 plan（tables 必须存在且非空）。 */
export async function runTablePlan(plan, options = {}) {
  if (!isPlainObject(plan) || !Object.prototype.hasOwnProperty.call(plan, 'tables')) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_PLAN_KIND_MISMATCH',
      'runTablePlan 需要 plan.tables',
    );
  }
  return runSchemaPlan(plan, options);
}

/** 只允许 catalog plan（catalog 必须存在）。 */
export async function runCatalogPlan(plan, options = {}) {
  if (!isPlainObject(plan) || !Object.prototype.hasOwnProperty.call(plan, 'catalog')) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_PLAN_KIND_MISMATCH',
      'runCatalogPlan 需要 plan.catalog',
    );
  }
  if (Object.prototype.hasOwnProperty.call(plan, 'tables')) {
    throw new SchemaRunnerError(
      'SCHEMA_RUN_PLAN_KIND_MISMATCH',
      'runCatalogPlan 不接受 plan.tables（catalog-only）',
    );
  }
  return runSchemaPlan(plan, options);
}

// ─── CLI ────────────────────────────────────────────────────────────────────
function parseArgv(argv) {
  const args = {
    plan: null,
    channel: null,
    cwd: null,
    out: null,
    catalogOut: null,
    concurrency: null,
    maxResultBytes: null,
    catalogPageSize: null,
    quiet: false,
    help: false,
    validateOnly: false,
    mcp: {},
  };
  for (let i = 2; i < argv.length; i += 1) {
    const arg = argv[i];
    const next = () => argv[++i];
    if (arg === '--help' || arg === '-h') args.help = true;
    else if (arg === '--validate-only') args.validateOnly = true;
    else if (arg === '--plan') args.plan = next();
    else if (arg === '--channel') args.channel = next();
    else if (arg === '--cwd') args.cwd = next();
    else if (arg === '--out') args.out = next();
    else if (arg === '--catalog-out') args.catalogOut = next();
    else if (arg === '--concurrency') args.concurrency = Number(next());
    else if (arg === '--max-result-bytes') args.maxResultBytes = Number(next());
    else if (arg === '--catalog-page-size') args.catalogPageSize = Number(next());
    else if (arg === '--quiet') args.quiet = true;
    else if (arg === '--data-source-name') args.mcp.dataSourceName = next();
    else if (arg === '--source-name') args.sourceName = next();
    else if (arg === '--db-name') args.mcp.dbName = next();
    else if (arg === '--app-id') args.mcp.appId = next();
    else if (arg === '--mcp-env') args.mcp.env = next();
    else if (arg === '--mcp-endpoint') args.mcp.endpoint = next();
    else if (arg === '--mcp-timeout-ms') args.mcp.timeoutMs = Number(next());
    else throw new SchemaRunnerError('SCHEMA_RUN_USAGE', `未知参数：${arg}`);
  }
  return args;
}

function usage() {
  return [
    '用法: node runner.mjs --plan <path|-> [--validate-only] [--channel mcp] [--cwd <dir>]',
    '  [--out <path>] [--catalog-out <path>] [--concurrency N] [--max-result-bytes N]',
    '  [--catalog-page-size N] [--quiet]',
    '  [--source-name <dataSourceName>]  （须与 --data-source-name 一致）',
    '  MCP:   --data-source-name <name> --db-name <db> [--app-id <id>] [--mcp-env dev]',
    '         [--mcp-endpoint <url>] [--mcp-timeout-ms N]',
    '  显式 --channel local 返回 SCHEMA_RUN_CHANNEL_INVALID（local 已退役，请经 MCP 重新采集）。',
    '  plan 形状见 shared/schema/plan-schema.json；runner 不含任何方言 SQL。',
  ].join('\n');
}

function readPlan(arg) {
  if (arg === '-') {
    return { plan: JSON.parse(readFileSync(0, 'utf-8')), path: null };
  }
  const absolute = resolve(arg);
  const text = readFileSync(absolute, 'utf-8');
  return { plan: JSON.parse(text), path: absolute, text };
}

export async function main(argv = process.argv) {
  const args = parseArgv(argv);
  if (args.help) {
    process.stdout.write(`${usage()}\n`);
    return 0;
  }
  if (!args.plan) throw new SchemaRunnerError('SCHEMA_RUN_USAGE', '缺 --plan <path|->');

  const baseDir = args.cwd ? resolve(args.cwd) : process.cwd();
  const loaded = readPlan(args.plan);
  const planRef = loaded.path
    ? {
        path: loaded.path,
        sha256: createHash('sha256').update(loaded.text, 'utf8').digest('hex'),
      }
    : null;

  if (args.validateOnly) {
    const validated = validatePlan(loaded.plan);
    if (!args.quiet) {
      process.stdout.write(
        `${JSON.stringify({
          ok: true,
          kind: validated.kind,
          dialect: validated.plan.dialect,
          tables: validated.plan.tables ? validated.plan.tables.length : 0,
          hasCatalog: Boolean(validated.plan.catalog),
          hasProbe: Boolean(validated.plan.probe),
          planSha256: planRef ? planRef.sha256 : null,
        })}\n`,
      );
    }
    return 0;
  }

  const options = {
    channel: args.channel,
    cwd: baseDir,
    planRef,
    concurrency: args.concurrency ?? undefined,
    maxResultBytes: args.maxResultBytes ?? undefined,
    catalogPageSize: args.catalogPageSize ?? undefined,
    sourceName:
      typeof args.sourceName === 'string' && args.sourceName.trim()
        ? args.sourceName.trim()
        : args.mcp.dataSourceName || undefined,
  };
  if (args.out) options.outputPath = resolve(baseDir, args.out);
  if (args.catalogOut) options.catalogOutputPath = resolve(baseDir, args.catalogOut);
  options.mcp = args.mcp;

  const result = await runSchemaPlan(loaded.plan, options);
  if (!args.quiet) {
    process.stdout.write(
      `${JSON.stringify({
        ok: true,
        outputPath: result.outputPath,
        catalogOutputPath: result.catalogOutputPath,
        tables: result.document ? result.document.tables.length : 0,
        catalogTables: result.catalogTableNames ? result.catalogTableNames.length : 0,
        catalogPageCount: result.catalogDocument ? result.catalogDocument.catalogPageCount : 0,
        catalogComplete: result.catalogDocument ? result.catalogDocument.catalogComplete : null,
        probe: result.probe ? { ok: result.probe.ok === true, value: result.probe.value ?? '' } : null,
        truncated: result.document ? result.document.execution.truncated : false,
      })}\n`,
    );
  }
  return 0;
}

const isMainEntry =
  process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]);
if (isMainEntry) {
  main().then(
    (code) => {
      process.exit(code ?? 0);
    },
    (error) => {
      const payload =
        error && typeof error.toJSON === 'function'
          ? error.toJSON()
          : { ok: false, code: error?.code || 'SCHEMA_RUN_INTERNAL', message: error?.message || String(error) };
      process.stderr.write(`${JSON.stringify(payload, null, 2)}\n`);
      process.exit(1);
    },
  );
}
