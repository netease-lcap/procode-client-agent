#!/usr/bin/env node

/**
 * 1-1.1 增量设计 · 澄清基线定位脚本（纯 fs 定位，无库、无 LLM）
 *
 * 职责：保证增量协调者 ⓠ gate 读到的 `plans/backend/_meta/clarify-decisions.json`
 *   反映上一轮（1.0）澄清基线。
 *   - 主导路径（docs run 目录被复用，信号 ①）：active 目录已就地含 1.0 台账 → 恒 no-op。
 *   - 边界路径（docs run 目录 ≥2，active 是不含台账的新目录，信号 ②）：跨 docs run
 *     定位最近一个含台账的旧 run，拷入 active，避免协调者退化成「从零首次」丢 1.0 基线。
 *
 * 幂等：active 已有台账则不覆盖；找不到任何旧台账则标 no-prior-ledger（真·首次，不报错）。
 *
 * 用法：
 *   node seed-clarify-baseline.mjs [--cwd <dir>]
 *   输出：stdout 单行 JSON { ok, action, from? }
 *     action ∈ noop-active-present | seeded-from-prior-run | no-prior-ledger | no-active-dir
 */

import { existsSync, readdirSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { resolve, dirname } from 'path';
import { resolveProjectRoot } from './shared/backend-common.mjs';

function parseArgs(argv) {
  for (let i = 2; i < argv.length; i++) {
    if (argv[i] === '--cwd') process.chdir(argv[++i]);
  }
}

/** 当前工作根：PROJECT_CWD 优先，否则 process.cwd()（在 --cwd chdir 之后取，故实时读取）。 */
function currentCwd() {
  return process.env.PROJECT_CWD || process.cwd();
}

const LEDGER_REL = ['plans', 'backend', '_meta', 'clarify-decisions.json'];

/** 定位 docs 根：项目根走共享 resolveProjectRoot 上溯（唯一实现），docs 根按 <appName>/docs 优先回退 <root>/docs。 */
function findDocsRoot() {
  const projectRoot = resolveProjectRoot(currentCwd());
  if (!projectRoot) return null;
  const appName = process.env.APP_NAME || process.env.APP_ID || 'project';
  for (const candidate of [resolve(projectRoot, appName, 'docs'), resolve(projectRoot, 'docs')]) {
    if (existsSync(candidate)) return candidate;
  }
  return null;
}

/** 列 docs 下的 run 目录（忽略 . 前缀、须含 plans/backend），按名排序（时间戳名 = 时序）。 */
function listRunDirs(docsRoot) {
  try {
    return readdirSync(docsRoot)
      .filter((n) => !n.startsWith('.') && existsSync(resolve(docsRoot, n, 'plans', 'backend')))
      .sort();
  } catch {
    return [];
  }
}

function ledgerPathFor(docsRoot, run) {
  return resolve(docsRoot, run, ...LEDGER_REL);
}

function nonEmptyFile(p) {
  try {
    return existsSync(p) && Boolean(readFileSync(p, 'utf-8').trim());
  } catch {
    return false;
  }
}

function main() {
  parseArgs(process.argv);
  const docsRoot = findDocsRoot();
  if (!docsRoot) return { ok: true, action: 'no-active-dir' };

  const runs = listRunDirs(docsRoot);
  if (runs.length === 0) return { ok: true, action: 'no-active-dir' };

  const activeRun = runs[runs.length - 1];
  const activeLedger = ledgerPathFor(docsRoot, activeRun);

  // 主导路径：active 已就地含台账（run 目录被复用，1.0 台账原地留存）→ 不覆盖。
  if (nonEmptyFile(activeLedger)) return { ok: true, action: 'noop-active-present' };

  // 边界路径：跨 docs run 找最近一个含台账的旧 run（除 active 外，最新在前）。
  const priorRuns = runs.slice(0, -1).reverse();
  for (const run of priorRuns) {
    const priorLedger = ledgerPathFor(docsRoot, run);
    if (nonEmptyFile(priorLedger)) {
      mkdirSync(dirname(activeLedger), { recursive: true });
      writeFileSync(activeLedger, readFileSync(priorLedger, 'utf-8'), 'utf-8');
      return { ok: true, action: 'seeded-from-prior-run', from: run };
    }
  }

  // 无任何旧台账 → 真·首次，协调者据此走首次 RECLARIFY，不报错。
  return { ok: true, action: 'no-prior-ledger' };
}

try {
  const result = main();
  process.stdout.write(JSON.stringify(result) + '\n');
} catch (err) {
  process.stdout.write(JSON.stringify({ ok: false, action: 'error', error: String(err && err.message || err) }) + '\n');
}
