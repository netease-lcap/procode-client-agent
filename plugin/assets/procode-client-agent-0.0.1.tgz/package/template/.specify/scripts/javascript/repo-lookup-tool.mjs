/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/repo-lookup/cli.mts
import { realpathSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { createLogger } from "./shared/logger.mjs";

// src/utils/customWaveAgent/speckit/config/shared/repo-lookup/repo-lookup.ts
import fs from "node:fs";
import http from "node:http";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import tls from "node:tls";
var SUPPORTED_SOURCE_OPTIONS = ["auto", "nexus", "repo1", "gradle-plugins"];
var DEFAULT_TIMEOUT_MS = 15e3;
var REPO1_BASE_DEFAULT = "https://repo1.maven.org/maven2";
var GRADLE_PLUGINS_BASE_DEFAULT = "https://plugins.gradle.org/m2";
var REPO_LOOKUP_FILE_PREFIX = "repo-lookup-";
var RepoLookupError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RepoLookupError";
  }
};
var isCanonicalCoordinate = (raw) => typeof raw === "string" && /^[A-Za-z0-9._-]+:[A-Za-z0-9._-]+$/.test(raw);
var metadataUrlFor = (baseUrl, coordinate) => {
  const [group, artifact] = coordinate.split(":");
  return `${baseUrl.replace(/\/+$/, "")}/${group.replace(/\./g, "/")}/${artifact}/maven-metadata.xml`;
};
var sanitizeCoordinateForFilename = (coordinate) => coordinate.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
var repoLookupFileName = (coordinate) => `${REPO_LOOKUP_FILE_PREFIX}${sanitizeCoordinateForFilename(coordinate)}.json`;
var parseMavenSettingsMirrors = (xml) => {
  const mirrors = [];
  const blockRe = /<mirror\b([^>]*)>([\s\S]*?)<\/mirror>/g;
  const attr = (name, tag) => new RegExp(`${name}="([^"]*)"`).exec(tag)?.[1]?.trim();
  let block;
  while ((block = blockRe.exec(xml)) !== null) {
    const tag = block[1];
    const inner = block[2];
    const mirrorOf = /<mirrorOf>([\s\S]*?)<\/mirrorOf>/.exec(inner)?.[1]?.trim() ?? attr("mirrorOf", tag);
    const url = /<url>([\s\S]*?)<\/url>/.exec(inner)?.[1]?.trim() ?? attr("url", tag);
    if (mirrorOf !== void 0 && url !== void 0) {
      mirrors.push({ mirrorOf, url });
    }
  }
  return mirrors;
};
var discoverNexusBaseUrl = (xml) => {
  if (!xml) return null;
  const mirrors = parseMavenSettingsMirrors(xml);
  const exact = mirrors.find((m) => m.mirrorOf === "*");
  if (exact) return exact.url;
  const loose = mirrors.find((m) => m.mirrorOf.includes("*"));
  return loose ? loose.url : null;
};
var readSettingsXmlFile = () => {
  const custom = process.env.REPO_LOOKUP_SETTINGS_XML?.trim();
  const file = custom || path.join(os.homedir(), ".m2", "settings.xml");
  try {
    return fs.readFileSync(file, "utf-8");
  } catch {
    return null;
  }
};
var parseMavenMetadataXml = (xml) => {
  const tag = (name, scope) => {
    const m2 = new RegExp(`<${name}>([\\s\\S]*?)<\\/${name}>`).exec(scope);
    return m2 ? m2[1].trim() : null;
  };
  const versioning = /<versioning>([\s\S]*?)<\/versioning>/.exec(xml)?.[1] ?? null;
  const latest = versioning ? tag("latest", versioning) : null;
  const release = versioning ? tag("release", versioning) : null;
  const versionsBlock = versioning ? /<versions>([\s\S]*?)<\/versions>/.exec(versioning)?.[1] ?? "" : "";
  const versions = [];
  const versionRe = /<version>([\s\S]*?)<\/version>/g;
  let m;
  while ((m = versionRe.exec(versionsBlock)) !== null) {
    const v = m[1].trim();
    if (v) versions.push(v);
  }
  return { latest, release, versions };
};
function resolveTimeoutMs() {
  const raw = Number(process.env.REPO_LOOKUP_TIMEOUT_MS);
  return Number.isFinite(raw) && raw > 0 ? raw : DEFAULT_TIMEOUT_MS;
}
function resolveProxyFor(target) {
  const proxyEnv = target.protocol === "https:" ? process.env.HTTPS_PROXY || process.env.https_proxy : process.env.HTTP_PROXY || process.env.http_proxy;
  if (!proxyEnv) return null;
  const noProxy = process.env.NO_PROXY || process.env.no_proxy || "";
  const hit = noProxy.split(",").map((s) => s.trim()).filter(Boolean).some((pat) => {
    if (pat === "*") return true;
    return target.hostname === pat || target.hostname.endsWith(pat.startsWith(".") ? pat : "." + pat);
  });
  if (hit) return null;
  try {
    return new URL(proxyEnv);
  } catch {
    return null;
  }
}
var isLoopbackHost = (hostname) => hostname === "localhost" || hostname === "::1" || /^127\./.test(hostname);
function connectTunnel(proxy, target, deadline) {
  return new Promise((resolve, reject) => {
    const remaining = deadline - Date.now();
    if (remaining <= 0) {
      reject(new RepoLookupError(`\u4EE3\u7406 CONNECT \u8D85\u65F6\uFF08deadline \u5DF2\u8FC7\uFF09`));
      return;
    }
    const socket = net.connect({
      host: proxy.hostname,
      port: Number(proxy.port) || (proxy.protocol === "https:" ? 443 : 80)
    });
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new RepoLookupError(`\u4EE3\u7406 CONNECT \u8D85\u65F6 ${remaining}ms\uFF08${proxy.href} \u2192 ${target.hostname}:${target.port}\uFF09`));
    }, remaining);
    socket.once("error", (error) => {
      clearTimeout(timer);
      reject(new RepoLookupError(`\u4EE3\u7406\u8FDE\u63A5\u5931\u8D25\uFF08${proxy.href}\uFF09`, { cause: error }));
    });
    let header = "";
    const onData = (chunk) => {
      header += chunk.toString("latin1");
      if (!header.includes("\r\n\r\n")) return;
      socket.off("data", onData);
      clearTimeout(timer);
      const statusLine = header.split("\r\n")[0] ?? "";
      if (!/^HTTP\/1\.[01] 2\d\d/.test(statusLine)) {
        socket.destroy();
        reject(new RepoLookupError(`\u4EE3\u7406 CONNECT \u88AB\u62D2\uFF1A${statusLine}\uFF08${proxy.href}\uFF09`));
        return;
      }
      resolve(socket);
    };
    socket.on("data", onData);
    socket.write(`CONNECT ${target.hostname}:${target.port} HTTP/1.1\r
Host: ${target.hostname}:${target.port}\r
\r
`);
  });
}
function singleGet(url, deadline) {
  return new Promise((resolve, reject) => {
    const headers = {
      Accept: "application/xml, */*",
      "User-Agent": "speckit-repo-lookup/1",
      Host: url.host
    };
    const isHttps = url.protocol === "https:";
    const proxy = isLoopbackHost(url.hostname) ? null : resolveProxyFor(url);
    const collect = (clientReq) => {
      clientReq.on("timeout", () => {
        clientReq.destroy(new RepoLookupError(`\u8BF7\u6C42\u8D85\u65F6\uFF08${url.href}\uFF09`));
      });
      clientReq.on("error", (error) => {
        if (error instanceof RepoLookupError) {
          reject(error);
          return;
        }
        reject(new RepoLookupError(`\u7F51\u7EDC\u8C03\u7528\u5931\u8D25\uFF08${url.href}\uFF09`, { cause: error }));
      });
      clientReq.end();
    };
    const onResponse = (res) => {
      const chunks = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("error", (error) => {
        reject(new RepoLookupError(`\u54CD\u5E94\u4E2D\u65AD\uFF08${url.href}\uFF09`, { cause: error }));
      });
      res.on("end", () => {
        resolve({
          status: res.statusCode ?? 0,
          body: Buffer.concat(chunks).toString("utf-8"),
          location: res.headers.location ?? null
        });
      });
    };
    const remaining = Math.max(deadline - Date.now(), 1);
    if (!isHttps && !proxy) {
      collect(
        http.request(
          {
            method: "GET",
            hostname: url.hostname,
            port: url.port || 80,
            path: `${url.pathname}${url.search}`,
            headers,
            timeout: remaining
          },
          onResponse
        )
      );
      return;
    }
    if (!isHttps && proxy) {
      collect(
        http.request(
          {
            method: "GET",
            hostname: proxy.hostname,
            port: Number(proxy.port) || 80,
            path: url.href,
            headers,
            timeout: remaining
          },
          onResponse
        )
      );
      return;
    }
    void (async () => {
      try {
        let socket;
        if (proxy) {
          const tunneled = await connectTunnel(
            proxy,
            { hostname: url.hostname, port: Number(url.port) || 443 },
            deadline
          );
          socket = tls.connect({
            socket: tunneled,
            servername: url.hostname
          });
        } else {
          socket = tls.connect({
            host: url.hostname,
            port: Number(url.port) || 443,
            servername: url.hostname
          });
        }
        await new Promise((ready, fail2) => {
          const timer = setTimeout(() => {
            socket.destroy();
            fail2(new RepoLookupError(`TLS \u8FDE\u63A5\u8D85\u65F6\uFF08${url.href}\uFF09`));
          }, Math.max(deadline - Date.now(), 1));
          socket.once("secureConnect", () => {
            clearTimeout(timer);
            ready();
          });
          socket.once("error", (error) => {
            clearTimeout(timer);
            fail2(new RepoLookupError(`TLS \u8FDE\u63A5\u5931\u8D25\uFF08${url.href}\uFF09`, { cause: error }));
          });
        });
        collect(
          http.request(
            {
              method: "GET",
              path: `${url.pathname}${url.search}`,
              headers,
              timeout: Math.max(deadline - Date.now(), 1),
              createConnection: () => socket
            },
            onResponse
          )
        );
      } catch (error) {
        reject(error instanceof RepoLookupError ? error : new RepoLookupError(String(error)));
      }
    })();
  });
}
async function httpGetText(rawUrl, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let current = new URL(rawUrl);
  for (let hop = 0; hop <= 3; hop++) {
    const { status, body, location } = await singleGet(current, deadline);
    if (status >= 200 && status < 300) return body;
    const redirectable = status === 301 || status === 302 || status === 303 || status === 307 || status === 308;
    if (redirectable && location) {
      current = new URL(location, current);
      continue;
    }
    throw new RepoLookupError(`HTTP ${status}\uFF08${current.href}\uFF09`);
  }
  throw new RepoLookupError(`\u91CD\u5B9A\u5411\u6B21\u6570\u8D85\u9650\uFF08>3\uFF0C\u8D77\u70B9 ${rawUrl}\uFF09`);
}
function resolveSourceBase(source, readSettingsXml) {
  if (source === "nexus") {
    return discoverNexusBaseUrl(readSettingsXml());
  }
  if (source === "repo1") {
    return process.env.REPO_LOOKUP_REPO1_BASE?.trim() || REPO1_BASE_DEFAULT;
  }
  return process.env.REPO_LOOKUP_GRADLE_BASE?.trim() || GRADLE_PLUGINS_BASE_DEFAULT;
}
async function lookupVersions(coordinate, options = {}, deps = {}) {
  const fetchText = deps.fetchText ?? httpGetText;
  const readSettingsXml = deps.readSettingsXml ?? readSettingsXmlFile;
  const now = deps.now ?? (() => /* @__PURE__ */ new Date());
  const sourceList = options.source && options.source !== "auto" ? [options.source] : ["nexus", "repo1"];
  const timeoutMs = resolveTimeoutMs();
  const attempts = [];
  for (const source of sourceList) {
    const base = resolveSourceBase(source, readSettingsXml);
    if (!base) {
      attempts.push({
        source,
        url: "",
        error: "nexus \u51FA\u53E3\u672A\u53D1\u73B0\uFF08settings.xml \u65E0 mirrorOf \u542B * \u7684\u955C\u50CF\uFF0C\u4E14\u672C\u6E90\u65E0\u5176\u5B83\u51FA\u53E3\uFF09"
      });
      continue;
    }
    const url = metadataUrlFor(base, coordinate);
    try {
      const xml = await fetchText(url, timeoutMs);
      const parsed = parseMavenMetadataXml(xml);
      if (parsed.latest === null && parsed.release === null && parsed.versions.length === 0) {
        throw new RepoLookupError(`metadata \u4E0D\u53EF\u5224\uFF08\u7F3A versioning \u7ED3\u6784\u6216\u5168\u7A7A\uFF1A${url}\uFF09`);
      }
      return {
        ok: true,
        coordinate,
        source,
        url,
        fetchedAt: now().toISOString(),
        latest: parsed.latest,
        release: parsed.release,
        versions: parsed.versions
      };
    } catch (error) {
      attempts.push({
        source,
        url,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  return { ok: false, degraded: true, coordinate, attempts };
}
var resolveActivePlansMetaDir = (rootDir = process.env.PROJECT_CWD || process.cwd()) => {
  const appName = process.env.APP_NAME || process.env.APP_ID || "project";
  const entry = readSpecEntryPointer(rootDir);
  for (const candidate of [path.resolve(rootDir, appName, "docs"), path.resolve(rootDir, "docs")]) {
    let entries;
    try {
      entries = fs.readdirSync(candidate);
    } catch {
      continue;
    }
    const runs = entries.filter((name) => !name.startsWith(".")).filter((name) => {
      try {
        return fs.statSync(path.join(candidate, name)).isDirectory();
      } catch {
        return false;
      }
    }).filter((run) => fs.existsSync(path.join(candidate, run, "plans")));
    if (runs.length === 0) continue;
    if (entry) {
      const pointed = runs.find((run) => entry.endsWith(run));
      if (pointed) {
        return path.join(candidate, pointed, "plans", "_meta");
      }
    }
    const byMtime = [...runs].sort((a, b) => {
      const mtimeDiff = fs.statSync(path.join(candidate, b)).mtimeMs - fs.statSync(path.join(candidate, a)).mtimeMs;
      return mtimeDiff || a.localeCompare(b, "en");
    });
    return path.join(candidate, byMtime[0], "plans", "_meta");
  }
  return null;
};
var readSpecEntryPointer = (rootDir) => {
  try {
    const raw = fs.readFileSync(path.resolve(rootDir, "_spec.json"), "utf-8");
    const parsed = JSON.parse(raw);
    return typeof parsed?.entry === "string" ? parsed.entry : null;
  } catch {
    return null;
  }
};
var toPersistedDocument = (result) => "attempts" in result ? { verdict: "degraded", coordinate: result.coordinate, attempts: result.attempts } : {
  verdict: "pass",
  coordinate: result.coordinate,
  source: result.source,
  url: result.url,
  fetchedAt: result.fetchedAt,
  latest: result.latest,
  versions: result.versions
};
var persistRepoLookup = (metaDir, result) => {
  fs.mkdirSync(metaDir, { recursive: true });
  const file = path.join(metaDir, repoLookupFileName(result.coordinate));
  fs.writeFileSync(file, `${JSON.stringify(toPersistedDocument(result), null, 2)}
`, "utf-8");
  return file;
};

// src/utils/customWaveAgent/speckit/config/shared/repo-lookup/cli.mts
var log = createLogger("repo-lookup");
var EXIT = {
  OK: 0,
  FAILURE: 1,
  USAGE: 2
};
var SUBCOMMAND_SPECS = {
  "lookup-versions": {
    values: { "--coordinate": "coordinate", "--source": "source" },
    /** 必填取值 flag（`--source` 可选：缺省 `auto` = nexus → repo1 依序降级）。 */
    required: ["coordinate"],
    usage: "lookup-versions --coordinate <group:artifact> [--source auto|nexus|repo1|gradle-plugins]",
    // 源适配器范围（plan 2026-09-23/plans-free-mode-third-scenario-and-stack-agnostic-clarify
    // 条目 11 §3.2：工具注册描述同批同步）。本工具的**全部** `--source` 值（nexus / repo1 /
    // gradle-plugins）都是 Maven 格式仓库、输入都是 `<group:artifact>` Maven 坐标 ⇒ 它只服务
    // **Maven 家族坐标族**。自由模式（栈不受限）下，非 Maven 生态（npm / PyPI / Go module /
    // Cargo 等）**没有适配器** ⇒ 那些语言的版本域只能走外部知识或生态查询，**禁止**硬凑成
    // Maven 坐标形态来本工具冒查（会把非 Maven 版本域错落成 Maven 快照，污染 repoLookupRef
    // 冻结轨）。扩展位 = 在 SUPPORTED_SOURCE_OPTIONS + provider 层加适配器行（v5 D4 预留的
    // 「源适配器注册表」位），不是在描述里临时放宽语义——故此处只把范围写进 agent 可见的
    // summary，不新增 spec 键（`SUBCOMMAND_SPECS` 受 `SubcommandSpec` 类型约束，加键即 tsc 红）。
    summary: "\u6309 Maven \u5750\u6807\u67E5 registry \u7248\u672C\u57DF\uFF08**\u4EC5 Maven \u5BB6\u65CF\u5750\u6807\u65CF**\uFF1A\u5168\u90E8 --source \u503C\u5747\u4E3A Maven \u683C\u5F0F\u4ED3\u5E93\uFF0C\u975E Maven \u751F\u6001\u5982 npm/PyPI/Go module \u65E0\u9002\u914D\u5668\u3001\u7981\u5192\u67E5\uFF1Blatest/release/versions\uFF1B\u7ED3\u679C\u81EA\u52A8\u843D\u76D8 _meta\uFF0Cagent \u7981\u624B\u5199\uFF1B\u5168\u6E90\u4E0D\u53EF\u8FBE=\u964D\u7EA7\u7B54\u6848 exit 0\uFF09"
  }
};
function fail(code, message) {
  process.stderr.write(`${message}
`);
  log.error(message.split("\n")[0]);
  return code;
}
function usage(reason) {
  const lines = Object.keys(SUBCOMMAND_SPECS).map(
    (name) => `  ${SUBCOMMAND_SPECS[name].usage.padEnd(72)}${SUBCOMMAND_SPECS[name].summary}`
  );
  process.exit(
    fail(
      EXIT.USAGE,
      `\u53C2\u6570\u975E\u6CD5\uFF1A${reason}
\u7528\u6CD5\uFF1Arepo-lookup-tool <${Object.keys(SUBCOMMANDS).join("|")}> [flags]
${lines.join("\n")}`
    )
  );
}
function parseFlags(rest, subcommand) {
  const spec = SUBCOMMAND_SPECS[subcommand];
  const values = {};
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    let flag = arg;
    let inlineValue;
    const eq = arg.indexOf("=");
    if (arg.startsWith("--") && eq !== -1) {
      flag = arg.slice(0, eq);
      inlineValue = arg.slice(eq + 1);
    }
    const valueKey = Object.prototype.hasOwnProperty.call(spec.values, flag) ? spec.values[flag] : void 0;
    if (valueKey === void 0) {
      const allowed = Object.keys(spec.values);
      usage(`\u672A\u77E5\u6216\u8D8A\u6743 flag\uFF1A${arg}\uFF08${subcommand} \u7684\u5141\u8BB8\u96C6\uFF1A${allowed.join(" ") || "(\u65E0)"}\uFF09`);
    }
    if (inlineValue !== void 0) {
      values[valueKey] = inlineValue;
      continue;
    }
    if (i + 1 >= rest.length) usage(`flag \u7F3A\u503C\uFF1A${arg}`);
    values[valueKey] = rest[++i];
  }
  for (const key of spec.required) {
    if (values[key] === void 0) {
      const flag = Object.keys(spec.values).find((f) => spec.values[f] === key) ?? key;
      usage(`\u7F3A\u5C11\u5FC5\u586B flag\uFF1A${flag}\uFF08${subcommand} \u7684\u7528\u6CD5\uFF1A${spec.usage}\uFF09`);
    }
  }
  return values;
}
function emit(payload) {
  process.stdout.write(`${JSON.stringify(payload)}
`);
}
async function handlerLookupVersions(rest) {
  const flags = parseFlags(rest, "lookup-versions");
  if (!isCanonicalCoordinate(flags.coordinate)) {
    usage(`--coordinate \u5F62\u6001\u975E\u6CD5\uFF1A${flags.coordinate}\uFF08\u5E94\u4E3A group:artifact\uFF0C\u6BB5\u5185\u9650\u5B57\u6BCD/\u6570\u5B57/._-\uFF09`);
  }
  if (flags.source !== void 0 && !SUPPORTED_SOURCE_OPTIONS.includes(flags.source)) {
    usage(
      `--source \u503C\u975E\u6CD5\uFF1A${flags.source}\uFF08\u503C\u57DF\uFF1A${SUPPORTED_SOURCE_OPTIONS.join("|")}\uFF09`
    );
  }
  const result = await lookupVersions(flags.coordinate, {
    source: flags.source
  });
  try {
    const metaDir = resolveActivePlansMetaDir();
    if (metaDir) {
      const file = persistRepoLookup(metaDir, result);
      process.stderr.write(`[repo-lookup] \u67E5\u8BE2\u7559\u75D5\u5DF2\u843D\u76D8\uFF1A${file}
`);
    } else {
      process.stderr.write(
        "[repo-lookup] \u672A\u5B9A\u4F4D\u5230\u6D3B\u8DC3 spec \u7684 plans/_meta\uFF08\u65E0 docs \u6839\u6216\u65E0\u542B plans \u7684 run \u76EE\u5F55\uFF09\uFF0C\u8DF3\u8FC7\u843D\u76D8\n"
      );
    }
  } catch (error) {
    process.stderr.write(
      `[repo-lookup] \u843D\u76D8\u5931\u8D25\uFF08\u975E\u81F4\u547D\uFF09\uFF1A${error instanceof Error ? error.message : String(error)}
`
    );
  }
  emit(result);
  return EXIT.OK;
}
var SUBCOMMANDS = {
  "lookup-versions": handlerLookupVersions
};
async function main() {
  const startedAt = Date.now();
  const [sub, ...rest] = process.argv.slice(2);
  const handler = sub !== void 0 && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, sub) ? SUBCOMMANDS[sub] : void 0;
  if (handler === void 0) {
    usage(`\u672A\u77E5\u5B50\u547D\u4EE4\uFF1A${sub ?? "(\u65E0)"}\uFF08\u53EF\u7528\uFF1A${Object.keys(SUBCOMMANDS).join(" / ")}\uFF09`);
  }
  let code;
  try {
    code = await handler(rest);
  } catch (err) {
    process.exit(fail(EXIT.FAILURE, `repo-lookup-tool: ${errorMessage(err)}`));
  }
  if (code === EXIT.OK) {
    log.tool(sub, { exit: code, ms: Date.now() - startedAt });
  }
  process.exit(code);
}
function errorMessage(err) {
  return err instanceof Error ? err.message : String(err);
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  let real = null;
  try {
    real = pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    real = null;
  }
  return import.meta.url === plain || import.meta.url === real;
}
if (isInvokedAsEntry()) {
  void main();
}
export {
  SUBCOMMANDS
};
