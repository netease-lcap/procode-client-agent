import fs from 'fs';
import path from 'path';

import {
  parsedToRaw,
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  writeToFileSync,
  formatWritedFiles,
  parse,
  parseStemFromPath,
  parseMenusToTable,
  auto,
} from '../shared/index.mjs';

export const findTerms = (item) => item.endsWith('specs/terms.md');
export const findMenus = (item) => item.endsWith('specs/menus.md');
export const findContent = (item) => item.endsWith('pieces/content.md');
export const findPrecheck = (item) => item.endsWith('pieces/precheck.md');
export const findIgnoredSection = (item) => item.endsWith('pieces/ignored-section.md');
export const filterChecklistModules = (item) => item.includes('specs/checklist-');

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  const options = { rootDir };

  const termsBundle = findUnderSpecs(rootDir)(findTerms);
  const menusBundle = findUnderSpecs(rootDir)(findMenus);
  const precheckBundle = findUnderSpecs(rootDir)(findPrecheck);
  const ignoredSectionBundle = findUnderSpecs(rootDir)(findIgnoredSection);
  const checklistModuleBundles = filterUnderSpecs(rootDir)(filterChecklistModules);

  const parsedTerms = parse(options)(termsBundle?.absoluteFilePath) || [];
  const ignoredSectionSource = readFileSync(ignoredSectionBundle?.absoluteFilePath) || '';

  const checklistModuleCount = checklistModuleBundles.length;

  const failureMessage = '计算失败，请重新生成规范需求';

  if (!checklistModuleCount) {
    console.log(failureMessage);
    process.exit(1);
  }

  const number = 100;

  const parsedTermsSource = parsedTerms?.[0]?.children || parsedTerms;
  const businessTerms = parsedTermsSource?.[1]?.table || [];
  const permissionTerms = parsedTermsSource?.[0]?.table || [];
  const termsLength = businessTerms?.length + permissionTerms?.length;

  const businessContent = businessTerms
    .slice(0, 3)
    .map((item) => item[0])
    .join('、');

  const checklistModuleContent = checklistModuleBundles
    .slice(0, 3)
    .map((item) => parseStemFromPath(item.absoluteFilePath))
    .join('、');

  const hideIgnored = true || number === 100 || !ignoredSectionBundle?.quoteFilePath;
  const coverageContent = hideIgnored ? `**${number}%**` : `[**${number}%**](${ignoredSectionBundle?.quoteFilePath})`;

  const precheckMessage = (() => {
    const options = { rootDir };
    const parsed = parse(options)(precheckBundle.absoluteFilePath);
    const precheckCount = parsed?.[0]?.children?.length || 0;

    if (!precheckCount) {
      return;
    }

    return `4. **[需求歧义精准澄清](${precheckBundle.quoteFilePath})**：针对原始需求中【${precheckCount}】处模糊内容（范围界定、术语表述、目标预期等），定向问询用户确认，形成无歧义表述。`;
  })();

  const messages = [
    `完成原始需求文本的全面研读，输出规范化需求文档，覆盖原始需求文档中的 ${coverageContent} 的业务内容 ，总共输出【${checklistModuleCount}】个需求，具体如下：`,
    `1. **[标准化术语表梳理](${termsBundle.quoteFilePath})：** 结合需求分析理解，梳理${businessContent}等【${termsLength}】个核心业务与需求术语，明确定义、适用场景，形成术语表，支撑精准需求描述与技术实现。`,
    `2. **[基于用户故事拆解](${menusBundle.quoteFilePath})：** 完成${checklistModuleContent}等【${checklistModuleCount}】个业务模块需求拆分，明确各模块功能范围、逻辑规则、输入输出及交互边界，为分模块推进提供依据。`,
    precheckMessage,
    '下一步待办：',
    `请阅读[功能模块目录](${menusBundle.quoteFilePath})及各业务模块验收清单，进行逐一确认，如需调整，可在对话框中输入调整要求。全部确认无误后，可点击下一步 **[开始技术设计]**。`,
    '提示：这个过程可能费时，但是关乎到后续功能生成是否准确。',
  ];

  return messages.filter(Boolean).join('\n\n');
};

auto(import.meta)(toRaw);
export default toRaw;
