#!/usr/bin/env node

/**
 * 方言↔选型一致性门（plan 2026-09-21/pg-selection-fidelity-full-chain-repair §D3）
 *
 * 机械比对 canonical entity-*.md 的 DDL 方言签名 vs tech-stack.json database 选型。
 * 判据结构与参数分离（D7）：正负指纹单一真理源 = 同目录 shared/dialect-signatures.json，
 * 本脚本只做读取与比对，禁写字面方言事实。
 *
 * 判据矩阵（对齐 plan §D7「DDL 方言」行）：
 *   已知族（字典有行）——DDL 含本族负向指纹（如 postgresql 选型下的 AUTO_INCREMENT/ENGINE=）
 *     → 硬红（声明≠签名）；无指纹的朴素 DDL → 过（留痕 note，无方言信号可判）。
 *   归一命中但字典缺行（如 oracle）——放行留痕（2026-09-22 拍板，plan
 *     dialect-dictionary-miss-full-pass：判据只作用于字典有行的方言，缺行族
 *     不做任何比对，信任生成侧，终局实建+启动仲裁）。
 *   未知类型（归一 null，如 db2）——自洽判：多族指纹混杂 → 硬红；恰一族指纹 → 警告留痕
 *     过（兼容模式让步：DM MySQL 兼容模式合法用 AUTO_INCREMENT，硬红会误杀，实建仲裁）；
 *     无族指纹 → 过（留痕 note）。
 *   tech-stack database.type 缺席 —— 按存量 MySQL 形态比对 + note 留痕（对齐 B5 rev2 拍板：
 *     缺席不臆测新族；存量 round 无类型字段是旧 schema 正常态）。
 *
 * 用法：
 *   node check-dialect-consistency.mjs --entity-dir <backend entity 目录> --tech-stack <tech-stack.json>
 *
 * 契约 mimic check-backend-design.mjs：判定结果走 stdout JSON { ok, failures, warnings, notes }
 * （executor 吞 exit code，判定红必须是可解析 JSON）；仅用法错误/内部不变量破坏 throw
 * fail-loud（非零 exit → 上层 exec 拒绝 → checker 落红，双保险）。
 */

import { readFileSync, readdirSync, existsSync } from 'fs';
import { resolve, join } from 'path';
import { fileURLToPath } from 'url';

import { normalizeDatabaseKey, findDialectSignature, dialectSignatures } from './shared/dialect-signature.mjs';

// ── 参数解析（缺参=用法错误，throw fail-loud）────────────────────────────────
function parseArgs(argv) {
  const args = { entityDir: null, techStack: null, stack: 'java-spring' };
  for (let i = 2; i < argv.length; i++) {
    if (argv[i] === '--entity-dir') args.entityDir = argv[++i];
    else if (argv[i] === '--tech-stack') args.techStack = argv[++i];
    else if (argv[i] === '--stack') args.stack = argv[++i];
    else throw new Error(`[check-dialect-consistency] 未知参数: ${argv[i]}`);
  }
  if (!args.entityDir || !args.techStack) {
    throw new Error(
      '[check-dialect-consistency] 用法: node check-dialect-consistency.mjs --entity-dir <dir> --tech-stack <tech-stack.json>',
    );
  }
  return args;
}

// ── DDL 提取：单 entity 文件全部 sql 块拼接（增量 delta 形态同口径）──────────────
function extractEntityDdl(entityText) {
  const blocks = [...entityText.matchAll(/```sql\s*\n([\s\S]*?)```/g)].map((m) => m[1]);
  return blocks.join('\n');
}

// 大小写无关指纹包含判定
function ddlHas(ddl, fingerprint) {
  return ddl.toUpperCase().includes(fingerprint.toUpperCase());
}

// ── 判定主流程 ───────────────────────────────────────────────────────────────
function checkDialectConsistency({ entityDir, techStack, stack }) {
  const failures = [];
  const warnings = [];
  const notes = [];

  // tech-stack 读取：不可读/不可解析 → 判定红（证据不可解析禁 skip，verification-gate 铁律）
  let techRaw;
  try {
    const json = JSON.parse(readFileSync(techStack, 'utf-8'));
    techRaw = typeof json?.database?.type === 'string' ? json.database.type.trim() : '';
  } catch (e) {
    return {
      ok: false,
      failures: [`无法读取/解析 tech-stack.json: ${techStack}（${e.message}）——方言真值缺席，禁按默认形态判绿`],
      warnings,
      notes,
    };
  }

  // 方言真值归一：缺席=MySQL 存量形态留痕（不臆测新族）；非空但归一 null=未知类型降级路径
  let key = 'MySQL';
  if (!techRaw) {
    notes.push('tech-stack.json database.type 缺席：按存量 MySQL 形态比对（不臆测新族）');
  } else {
    key = normalizeDatabaseKey(techRaw);
  }

  // entity 目录缺席 → 判定红（门作用对象缺席不是 skip 理由——设计阶段该目录必在）
  if (!existsSync(entityDir)) {
    return {
      ok: false,
      failures: [`entity 目录不存在: ${entityDir}`],
      warnings,
      notes,
    };
  }

  const entityFiles = readdirSync(entityDir).filter((n) => /^entity-.*\.md$/.test(n)).sort();
  if (entityFiles.length === 0) {
    // 零实体合法性归 coverage 门裁决，本门无判据对象 → 过 + 留痕
    notes.push('entity 目录无 entity-*.md：方言门无判据对象（零实体合法性归覆盖门）');
    return { ok: true, failures, warnings, notes };
  }

  const row = key ? findDialectSignature(stack, key) : undefined;

  // ── 字典缺行族：放行留痕（2026-09-22 拍板，plan dialect-dictionary-miss-full-pass）──
  // 判据只作用于字典有行的方言；归一命中但缺行（如 oracle）不走任何方言比对，直接放行，
  // 误写由终局实建+启动仲裁兜底。留痕防静默（review-ledger「禁静默放行」）。
  if (key && !row) {
    notes.push(`字典缺行族（databaseType=${key}，原值「${techRaw}」）无方言判据：方言门比对跳过放行（2026-09-22 拍板），终局实建+启动仲裁`);
    return { ok: true, failures, warnings, notes };
  }

  const ddls = entityFiles.map((name) => ({
    name,
    ddl: extractEntityDdl(readFileSync(join(entityDir, name), 'utf-8')),
  }));

  // ── 未知类型（归一 null）：自洽判 + 已知族指纹警告留痕（兼容模式让步）────────
  if (!key) {
    const familiesHit = new Set();
    for (const sig of dialectSignatures) {
      if (sig.stack !== stack) continue;
      for (const { ddl } of ddls) {
        if (sig.ddlPositive.some((fp) => ddlHas(ddl, fp))) familiesHit.add(sig.db);
      }
    }
    if (familiesHit.size >= 2) {
      return {
        ok: false,
        failures: [
          `未知类型「${techRaw}」下 DDL 多方言混杂（同时含 ${[...familiesHit].join(' / ')} 族指纹）——自洽失败，须统一为选型方言形态`,
        ],
        warnings,
        notes,
      };
    }
    if (familiesHit.size === 1) {
      warnings.push(
        `未知类型「${techRaw}」下 DDL 呈 ${[...familiesHit][0]} 族方言形态——兼容模式让步，本门放过，终局由实建+启动仲裁`,
      );
    } else {
      notes.push(`未知类型「${techRaw}」且 DDL 无已知族指纹——无方言信号可判，本门放过`);
    }
    return { ok: true, failures, warnings, notes };
  }

  // ── 已知族主路径：DDL 含本族负向指纹 → 硬红（声明≠签名）────────────────────
  for (const { name, ddl } of ddls) {
    const negatives = row.ddlNegative.filter((fp) => ddlHas(ddl, fp));
    if (negatives.length > 0) {
      failures.push(
        `${name}: DDL 含 ${row.db} 选型下的异族方言指纹 ${negatives.map((n) => `「${n}」`).join('、')}——tech-stack database=${techRaw}，DDL 必须用 ${row.db} 方言形态（正向指纹：${row.ddlPositive.join(' / ')}；如 PG 选型禁 AUTO_INCREMENT/ENGINE=，改 GENERATED BY DEFAULT AS IDENTITY + COMMENT ON）`,
      );
    } else if (!row.ddlPositive.some((fp) => ddlHas(ddl, fp))) {
      notes.push(`${name}: DDL 无 ${row.db} 族正负指纹（朴素 DDL）——方言门无信号，过`);
    }
  }

  return { ok: failures.length === 0, failures, warnings, notes };
}

const _isMainEntry = process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]);
if (_isMainEntry) {
  const result = checkDialectConsistency(parseArgs(process.argv));
  console.log(JSON.stringify(result, null, 2));
}
