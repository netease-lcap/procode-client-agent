#!/usr/bin/env node

/**
 * 预创建实体包子目录 — 在 type-registry 生成后、段 A 实体并发生成前运行。
 *
 * 根因：段 A 多个域的 entity agent 几乎同一秒并发 write 各自 entity/Xxx.java 到同一个
 * 尚不存在的新建子目录（如 common/system/entity/），触发并发 mkdir 竞争，目录创建失败、
 * 文件全部未落盘（实测 task-260812：7 个 system 域 entity 文件全丢，B0 兜底重建）。
 *
 * 解法：编排层单线程预 mkdir -p 所有需要的包子目录（entity/dto/vo/repository/service），
 * agent write 时父目录已存在，纯写文件、永不触发 mkdir 竞争。
 *
 * 数据源：type-registry.json + 工程/实测约定 + 硬补 entity 子包。
 *   - type-registry.json 登记了 dto/vo/repository/service/controller 等子包的完整包路径
 *     （generate-type-registry.mjs 已为 entity/service/dto/vo/repository 加子包）。
 *   - 但 type-registry 只登记「存在的类对应的包」，若某域尚未生成任何文件则该域包路径
 *     不会出现在 registry 里。为兜底，额外从 entity-*.md 推导每个域的 modulePackage 并
 *     按契约 layerPackages 角色补分层子包（JPA=repository/MyBatis=mapper…）。
 *   - 根包 SOT：micro 工程方案（fresh/incremental）= 工程方案 `codeModules[].packageName` 公共前缀
 *     （方案 pathBase 是代码根基准）；其他场景 = skeleton-conventions.json 的 rootPackage。缺失 fail loud（exit 1），
 *     禁止本地 walk 包树/兜底假包名（0909 沙箱 ehs0908001 阶段三事故放大器根因，
 *     plan 2026-09-09/root-package-contract-consumers-stack-neutral-roles §3.2）。
 *   - micro 工程方案的域→模块归属读工程方案 + service-binding / entity-module-binding；
 *     **禁读 `skeleton-conventions.module.modules[].serviceName`**（实测产物没有该写者）。
 *
 * 只 mkdir，不写任何文件；幂等（目录已存在不报错）。
 * 详见 docs/hicode-spec/plan/2026-08-12/precreate-entity-package-dirs.md
 */

import { existsSync, readdirSync, readFileSync, mkdirSync } from 'fs';
import { resolve, dirname, sep } from 'path';
import {
  findBackendDir,
  findPlanBackendDir,
  loadSkeletonConventions,
  readMicroEngineeringPlan,
  freshMicroContextOfPlan,
  resolveDeclaredBackendRoots,
  resolveFreshMicroServiceModule,
  resolveFreshMicroEntityPlacement,
  resolveProjectRoot,
} from './shared/backend-common.mjs';

const cwd = process.cwd();

// ── 定位 plans 目录（共享 findPlanBackendDir）──────────────────────────────────────
function findMetaDir(planDir) {
  return planDir ? resolve(planDir, '_meta') : resolve(cwd, '_meta');
}

/** 单根直接采用；多根只认声明里本身是其余所有根祖先的聚合根，否则无法唯一确定（null）。 */
function declaredAggregateBackendRoot(roots) {
  if (roots.length === 0) return null;
  if (roots.length === 1) return roots[0];
  return roots.find((candidate) => roots.every((root) => root === candidate || root.startsWith(`${candidate}${sep}`))) ?? null;
}

/** 代码根定位（D5）：声明根优先；findBackendDir 仅兜底并打 warning；歧义不猜。 */
function resolveBackendRoot(activeSpecDir) {
  const baseRoot = resolveProjectRoot(cwd) ?? cwd;
  const declared = resolveDeclaredBackendRoots({ activeSpecDir, rootDir: baseRoot });
  if (declared.roots.length > 0) {
    if (declared.source === 'heuristic' || declared.ambiguous.length > 0) {
      const detail = declared.ambiguous.length > 0 ? `（未采用候选：${declared.ambiguous.join('、')}）` : '';
      console.warn(`[precreate-package-dirs] 代码根取自启发式/存在未采用候选：${declared.roots.join('、')}${detail}`);
    }
    const backendRoot = declaredAggregateBackendRoot(declared.roots);
    if (backendRoot) return backendRoot;
    console.error('[precreate-package-dirs] 代码根存在多个且无声明聚合根，无法唯一确定：');
    for (const candidate of declared.roots) console.error(`  - ${candidate}`);
    console.error('  - 请显式传 --backend-root，或在工程方案 buildUnits 中声明 aggregate/parent-child 根单元。');
    process.exit(1);
  }
  if (declared.ambiguous.length > 0) {
    console.error('[precreate-package-dirs] 代码根声明歧义，无法唯一确定：');
    for (const candidate of declared.ambiguous) console.error(`  - ${candidate}`);
    console.error('  - 请修正 engineering-plan.buildUnits[].rootDir / iteration-context / services 声明，或显式传 --backend-root。');
    process.exit(1);
  }
  const legacy = findBackendDir(cwd);
  if (legacy) console.warn(`[precreate-package-dirs] 未找到代码根声明，回落启发式 findBackendDir：${legacy}`);
  return legacy;
}

// ── 先判定 micro 工程方案（fresh=v1 / incremental=v2）：方案在场且自描述匹配时，代码根由方案 pathBase 决定，
//    不再假设单一后端根（plan 2026-10-20/fresh-micro-plan-complete-design-handoff §6.2 第 7 点）。
//    v2 增量方案没有 executionActions，本脚本只依赖 codeModules/runtime，不读该字段。
const planDir = findPlanBackendDir(cwd);
const planState = planDir ? readMicroEngineeringPlan(planDir) : { kind: 'legacy', planPath: '' };
if (planState.kind === 'invalid') {
  console.error(`[precreate-package-dirs] 工程方案不可用：${planState.reason}（${planState.planPath}）——fail loud，禁止回落旧 conventions/README 映射`);
  process.exit(1);
}
const microPlan = planState.kind === 'fresh-micro' || planState.kind === 'incremental-micro';

// micro 工程方案（fresh/incremental）的源码根由工程方案 pathBase/sourceDirs 决定，不需要单后端根；
// legacy 才用声明代码根。
const backendDir = microPlan ? null : resolveBackendRoot(planDir ? dirname(dirname(planDir)) : undefined);
if (!backendDir && !microPlan) {
  console.error('[precreate-package-dirs] 未找到后端工程目录，跳过（agent write 时会隐式 mkdir 回退）');
  process.exit(0); // 非硬依赖，不阻断 build
}
if (!planDir) {
  console.error('[precreate-package-dirs] 未找到 plans/backend 目录，跳过');
  process.exit(0);
}

const metaDir = findMetaDir(planDir);

// ── 读 domain.json → domain 列表 ──────────────────────────────────────────────────
const domainJsonPath = resolve(dirname(planDir), 'domain.json');
const domains = [];
if (existsSync(domainJsonPath)) {
  try {
    const raw = JSON.parse(readFileSync(domainJsonPath, 'utf-8'));
    for (const d of raw.domains || []) {
      domains.push({ id: d.id, nameZh: d.nameZh });
    }
  } catch (e) {
    console.error('[precreate-package-dirs] domain.json 解析失败:', e.message);
  }
}

// ── 读 README.md §3 取 domain → 模块目录映射（复用 generate-type-registry.mjs 逻辑）────
const readmePath = resolve(planDir, 'README.md');
const readmeContent = existsSync(readmePath) ? readFileSync(readmePath, 'utf-8') : '';

const domainModuleMap = new Map();
const tableRe = /\|\s*(.+?)\s*\|\s*(\w+)\s*\|\s*\w+\s*\|\s*(\w+)\s*\|/g;
let m;
while ((m = tableRe.exec(readmeContent)) !== null) {
  const domainId = m[2].trim();
  const moduleDir = m[3].trim();
  if (domainId && moduleDir && !domainModuleMap.has(domainId)) {
    domainModuleMap.set(domainId, moduleDir);
  }
}

// ── 根包名与分层约定（契约优先，plan 2026-09-09/root-package-contract-consumers-stack-neutral-roles §3.2）──
// SOT：micro 工程方案（fresh/incremental）= 工程方案 `codeModules[].packageName` 公共前缀；
// 其他场景 = skeleton-conventions.rootPackage。
// 旧实现本地 walk 包树，包树歧义时静默退化 rootPackage='com' 把域目录 mkdir 到错误层级
// （0909 沙箱 ehs0908001 阶段三事故放大器），且兜底 'com.company.app' 假包名继续跑——两者皆废。
// 缺契约 = 上游产物缺失（上游故障）→ fail loud。
const conventions = loadSkeletonConventions(planDir);
const rootPackage = conventions?.rootPackage || '';

// ── 多服务多模块：domain → modulePackage 机械映射（真值优先于 README 表推断）────────
// legacy 真值链：service-binding.json 的 domains[].serviceId → skeleton-conventions.module.modules[]
// 的 serviceName/modulePackage 后缀匹配。
// micro 工程方案（fresh/incremental）真值链：工程方案 codeModules[] + runtime[].serviceRef（显式服务绑定）→ 模块唯一匹配；
// **禁读 `module.modules[].serviceName`**——实测 conventions 没有该写者，按它匹配会静默丢域。
// 解析不到就**跳过该域并显式报缺口**（禁止用 domain id 兜底当包名——那会在根目录造出
// `com.company.<app>.identity/` 之类幻影包，误导后续 agent）。
const modulePackageByDomain = new Map();
let multiModuleSkeleton = false;
let freshCtx = null;
if (microPlan) {
  // 实测 conventions 是 build 实现后产物；本脚本在阶段三之前运行，缺席属于上游故障，不能跳过子包预建。
  if (!conventions.measuredPresent) {
    console.error('[precreate-package-dirs] micro 工程方案（fresh/incremental）实测 skeleton-conventions.json 缺失或不可解析（build 实现后采样产物）——fail loud');
    console.error(`  - planDir: ${planDir}`);
    console.error('  - 处置：先完成 micro 工程方案公共底座实现与实测 conventions 生成；本脚本不造伪实测产物');
    process.exit(1);
  }
  freshCtx = freshMicroContextOfPlan(planDir, planState);
  for (const entry of Array.isArray(freshCtx.serviceBinding?.domains) ? freshCtx.serviceBinding.domains : []) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
    const domainId = typeof entry.domain === 'string' ? entry.domain.trim() : '';
    if (!domainId) continue;
    const resolved = resolveFreshMicroServiceModule(freshCtx, entry.serviceId);
    if (resolved.kind === 'bound' && resolved.module.modulePackage) {
      modulePackageByDomain.set(domainId, resolved.module.modulePackage);
    }
  }
  // micro 工程方案（fresh/incremental）永不回落 domain 名作 moduleDir：单模块工程也会按方案 packageName 建包。
  multiModuleSkeleton = true;
  console.log(`[precreate-package-dirs] micro 工程方案（fresh/incremental）：代码根 ${freshCtx.codeRoot}，代码模块 ${freshCtx.modules.length} 个，域映射 ${modulePackageByDomain.size} 个（工程方案 + service-binding）`);
} else {
  const conventionsModules = Array.isArray(conventions?.module?.modules) ? conventions.module.modules : [];
  multiModuleSkeleton = conventionsModules.length > 1;
  try {
    const bindingPath = resolve(metaDir, 'service-binding.json');
    const bindingDoc = existsSync(bindingPath) ? JSON.parse(readFileSync(bindingPath, 'utf-8')) : null;
    const modules = conventionsModules;
    const suffixOf = (serviceId) => (serviceId.includes('-backend-')
      ? serviceId.replace(/^.*-backend-/, '')
      : serviceId.replace(/^[a-z0-9]+-/, ''));
    for (const entry of bindingDoc?.domains || []) {
      const domainId = typeof entry?.domain === 'string' ? entry.domain : '';
      const serviceId = typeof entry?.serviceId === 'string' ? entry.serviceId.trim() : '';
      if (!domainId || !serviceId) continue;
      const suffix = suffixOf(serviceId);
      const matched = modules.find((mod) =>
        (typeof mod?.serviceName === 'string' && mod.serviceName.replace(/^.*-backend-/, '') === suffix)
        || (typeof mod?.modulePackage === 'string' && mod.modulePackage.split('.').pop() === suffix)
        || mod?.moduleDir === suffix);
      if (typeof matched?.modulePackage === 'string' && matched.modulePackage.trim()) {
        modulePackageByDomain.set(domainId, matched.modulePackage.trim());
      }
    }
    if (modulePackageByDomain.size) {
      console.log(`[precreate-package-dirs] 多模块映射：${modulePackageByDomain.size} 个域 → modulePackage（skeleton-conventions）`);
    }
  } catch (e) {
    console.warn('[precreate-package-dirs] 多模块映射解析失败，回退 README 表:', e?.message ?? e);
  }
}
if (!rootPackage) {
  console.error(microPlan
    ? '[precreate-package-dirs] micro 工程方案（fresh/incremental）无法确定根包（fail loud，不兜底假包名）'
    : '[precreate-package-dirs] 无法确定根包：skeleton-conventions.json 缺失或无 rootPackage（fail loud，不兜底假包名）');
  console.error(`  - planDir: ${planDir}`);
  if (microPlan) {
    console.error(`  - 原因：${conventions.rootPackageReason || '工程方案 codeModules[].packageName 公共前缀不可判定'}`);
    console.error('  - 处置：工程方案生产任务补齐 packageName/Java 栈声明；本脚本禁止按目录名或 com.company 猜根包');
  } else {
    console.error('  - 处置：design 阶段须先产出 backend/_meta/skeleton-conventions.json（rootPackage 从骨架包树派生）；属上游产物缺失，非本脚本可修');
  }
  process.exit(1);
}

// 分层子包名照契约 layerPackages 角色（JPA=repository / MyBatis=mapper…，值由 design 期扫骨架得出，
// 消费方禁本地默认清单）。三种形态区别对待（plan 2026-09-09/root-package-contract-consumers-stack-neutral-roles §3.4）：
//   显式 absent:true = 骨架无分层子包 → 只建域根包，静默跳过（合法形态）；
//   缺 key（旧版 design 产物）  → 跳过但打响亮 warn（段 A 并发 mkdir 竞争防护降级，宜重跑 design 补齐）——
//                                design 期结构门（check-backend-design.mjs）已拦缺 key，此处是旧 run 兼容软门。
const layerPackagesRole = conventions.conventions.layerPackages;
let layerPackages;
if (!layerPackagesRole) {
  if (microPlan) {
    // micro 工程方案（fresh/incremental）的实测生产者按结构门写出全部 10 角色（缺角色须显式 absent）；缺 key = 实测产物损坏。
    // 静默跳子包预建会重开段 A 并发 mkdir 竞争防护的缺口，故 fail loud。
    console.error('[precreate-package-dirs] micro 工程方案（fresh/incremental）实测 conventions 缺 layerPackages 角色（非显式 absent）——fail loud');
    console.error('  - 处置：重跑 build 实测 conventions 生成（10 角色结构门）；本脚本不按栈惯例补默认分层清单');
    process.exit(1);
  }
  console.warn('[precreate-package-dirs] 契约缺 layerPackages 角色（非显式 absent，疑为旧版 design 产物）——跳过子包预建，段 A 并发 mkdir 竞争防护降级；建议重跑 design 产出 10 角色契约或手补该角色');
  layerPackages = null;
} else if (layerPackagesRole.absent === true) {
  layerPackages = null;
} else if (Array.isArray(layerPackagesRole.layers)) {
  layerPackages = layerPackagesRole.layers.filter((n) => typeof n === 'string' && n.trim()).map((n) => n.trim());
} else {
  if (microPlan) {
    console.error('[precreate-package-dirs] micro 工程方案（fresh/incremental）实测 conventions 的 layerPackages 非 absent 但缺 layers 非空 string[]——fail loud');
    process.exit(1);
  }
  console.warn('[precreate-package-dirs] layerPackages 非 absent 但缺 layers 非空 string[]（design 结构门应已拦；按缺角色处理）');
  layerPackages = null;
}

// 域→公共包映射照契约 commonPackageMapping 角色（如 home_auth→common.auth）；查无 → 通用 root.<moduleDir>。
// 缺 key（旧产物）≠ 显式 absent：absent 是"无公共包归并"的合法声明，回退通用路径无损失；
// 缺 key 留一行留痕（回退结果通常等价，不惊扰）；micro 工程方案（fresh/incremental）的缺 key 视为实测产物损坏（结构门应已拦）。
let commonPackageMapping = null;
if (!('commonPackageMapping' in conventions.conventions)) {
  if (microPlan) {
    console.error('[precreate-package-dirs] micro 工程方案（fresh/incremental）实测 conventions 缺 commonPackageMapping 角色（非显式 absent）——fail loud');
    process.exit(1);
  }
  console.warn('[precreate-package-dirs] 契约缺 commonPackageMapping 角色（非显式 absent，疑为旧版 design 产物）——按通用 root.<moduleDir> 回退');
} else {
  const commonMappingRole = conventions.conventions.commonPackageMapping;
  if (commonMappingRole && commonMappingRole.absent !== true && commonMappingRole.mapping && typeof commonMappingRole.mapping === 'object') {
    commonPackageMapping = commonMappingRole.mapping;
  } else if (!(commonMappingRole && commonMappingRole.absent === true)) {
    if (microPlan) {
      console.error('[precreate-package-dirs] micro 工程方案（fresh/incremental）实测 conventions 的 commonPackageMapping 非 absent 但缺 mapping object<string,string>——fail loud');
      process.exit(1);
    }
    console.warn('[precreate-package-dirs] commonPackageMapping 非 absent 但缺 mapping object<string,string>（design 结构门应已拦；按缺角色处理）');
  }
}

// ── 收集所有需要的包路径（去重）──────────────────────────────────────────────────
const packagePaths = new Set();

// 来源 1：type-registry.json 里所有出现过的包路径
const registryPath = resolve(metaDir, 'type-registry.json');
if (existsSync(registryPath)) {
  try {
    const registry = JSON.parse(readFileSync(registryPath, 'utf-8'));
    for (const className of Object.keys(registry)) {
      const fqn = registry[className];
      // fqn = com.company.<appName>.xxx.YyyClassName → 取去掉最后一段类名后的包路径
      const lastDot = fqn.lastIndexOf('.');
      if (lastDot > 0) {
        packagePaths.add(fqn.slice(0, lastDot));
      }
    }
  } catch (e) {
    console.error('[precreate-package-dirs] type-registry.json 解析失败，改用 entity-*.md 推导:', e.message);
  }
}

// 来源 2：从 entity-*.md 推导每个域的 modulePackage，按契约 layerPackages 硬补子包（兜底，确保 entity 子包必建）
const entityFiles = readdirSync(planDir).filter((n) => n.startsWith('entity-') && n.endsWith('.md'));

const skippedDomains = [];
// micro 工程方案（fresh/incremental）：包路径 → 所属代码模块（用于按模块 sourceDirs/testDirs 落盘，而不是单一后端根）。
const freshPackageTargets = new Map();
for (const ef of entityFiles) {
  const entityPath = resolve(planDir, ef);
  const content = readFileSync(entityPath, 'utf-8');
  const domainMatch = content.match(/^\s*>\s*业务领域[：:]\s*(\w+)/m);
  const domain = domainMatch ? domainMatch[1].trim() : 'common';

  let pkgBase;
  let targetModule = null;
  if (microPlan) {
    // micro 工程方案（fresh/incremental）：实体投影绑定优先，service-binding 次之；不可判即显式缺口，
    // 禁回落 README 表 / 旧 conventions modules / domain 名。
    const placement = resolveFreshMicroEntityPlacement(freshCtx, entityPath);
    if (placement.kind !== 'bound') {
      skippedDomains.push(`${domain}（${placement.reason}）`);
      continue;
    }
    targetModule = placement.module;
    if (!targetModule.modulePackage) {
      skippedDomains.push(`${domain}（模块 ${targetModule.moduleId} 未声明 packageName）`);
      continue;
    }
    const commonPkg = commonPackageMapping ? commonPackageMapping[domain] : null;
    pkgBase = commonPkg ? `${rootPackage}.${commonPkg}` : targetModule.modulePackage;
  } else {
    const mappedPackage = modulePackageByDomain.get(domain);
    const moduleDir = domainModuleMap.get(domain) || (multiModuleSkeleton ? undefined : domain);
    if (!mappedPackage && !moduleDir) {
      // 多模块骨架 + 无机械映射：不建目录（禁止用 domain id 当包名造幻影包）；
      // 单模块老工程：moduleDir 回退 domain（与历史行为一致，包就是 root.<domain>）
      skippedDomains.push(domain);
      continue;
    }
    // 域→公共包映射照契约 commonPackageMapping（换应用/换公共层包名不改代码）；查无 → 通用 root.<moduleDir>
    const commonPkg = commonPackageMapping ? commonPackageMapping[domain] : null;
    pkgBase = mappedPackage || (commonPkg ? `${rootPackage}.${commonPkg}` : `${rootPackage}.${moduleDir}`);
  }

  // 按契约 layerPackages 预建分层子包（角色 absent = 骨架无分层子包，只建域根包；禁本地默认清单）
  if (layerPackages) {
    for (const sub of layerPackages) {
      const subPkg = `${pkgBase}.${sub}`;
      packagePaths.add(subPkg);
      if (targetModule) freshPackageTargets.set(subPkg, targetModule);
    }
  }
  // 也补域根包本身（controller 等可能在根包下）
  packagePaths.add(pkgBase);
  if (targetModule) freshPackageTargets.set(pkgBase, targetModule);
}

if (skippedDomains.length) {
  const detail = microPlan
    ? `以下域/实体在工程方案 + 既有绑定中无唯一模块归属，已显式跳过预建（禁 domain/README 兜底）：${[...new Set(skippedDomains)].join('、')}`
    : `以下域无 modulePackage 机械映射，已跳过预建（禁 domain 名兜底）：${[...new Set(skippedDomains)].join('、')}`;
  console.warn(`[precreate-package-dirs] ${detail}`);
}

// ── mkdir -p 每个包路径对应的源码/测试目录 ──────────────────────────────────────────
function pkgToDir(pkg) {
  return pkg.replace(/\./g, '/');
}

let mainCreated = 0;
let testCreated = 0;
function ensureDir(abs) {
  if (existsSync(abs)) return false;
  mkdirSync(abs, { recursive: true });
  return true;
}

if (microPlan) {
  // 多构建单元/多代码模块：按工程方案 pathBase + sourceDirs/testDirs 逐模块解析代码根，
  // 不再假设 `backendDir/src/main/java` 是唯一源码根。
  const createForModule = (pkg, module) => {
    if (!pkg || pkg === rootPackage || !pkg.startsWith(rootPackage + '.')) return false;
    const rel = pkgToDir(pkg);
    if (module.sourceDirs.length === 0) {
      console.warn(`[precreate-package-dirs] 代码模块 ${module.moduleId} 未声明 sourceDirs，无法预建包 ${pkg}（工程方案缺口）`);
      return false;
    }
    let created = false;
    for (const dir of module.sourceDirs) {
      if (ensureDir(resolve(freshCtx.codeRoot, module.pathBase, dir, rel))) {
        mainCreated++;
        created = true;
      }
    }
    for (const dir of module.testDirs) {
      if (ensureDir(resolve(freshCtx.codeRoot, module.pathBase, dir, rel))) {
        testCreated++;
        created = true;
      }
    }
    return created;
  };
  const handled = new Set();
  for (const [pkg, module] of freshPackageTargets) {
    if (createForModule(pkg, module)) handled.add(pkg);
  }
  // type-registry 里可能还有未由 entity-*.md 覆盖的公共包；按模块 packageName 前缀定位归属。
  for (const pkg of packagePaths) {
    if (handled.has(pkg)) continue;
    if (!pkg || pkg === rootPackage || !pkg.startsWith(rootPackage + '.')) continue;
    const module = freshCtx.modules.find(
      (candidate) => candidate.modulePackage && (pkg === candidate.modulePackage || pkg.startsWith(`${candidate.modulePackage}.`)),
    );
    if (!module) {
      console.warn(`[precreate-package-dirs] 包 ${pkg} 不属于工程方案任何 codeModules[].packageName，已跳过（禁猜模块/单根兜底）`);
      continue;
    }
    createForModule(pkg, module);
  }
} else {
  const mainJavaBase = resolve(backendDir, 'src', 'main', 'java');
  const testJavaBase = resolve(backendDir, 'src', 'test', 'java');
  for (const pkg of packagePaths) {
    if (!pkg || pkg === rootPackage) continue; // 跳过空和纯根包（根包目录已存在）
    // 只处理属于 rootPackage 下的包（避免误建无关目录）
    if (!pkg.startsWith(rootPackage + '.')) continue;

    const rel = pkgToDir(pkg);
    if (ensureDir(resolve(mainJavaBase, rel))) mainCreated++;
    if (ensureDir(resolve(testJavaBase, rel))) testCreated++;
  }
}

console.log(`[precreate-package-dirs] 预创建包目录完成：${packagePaths.size} 个包路径，main 新建 ${mainCreated} 个目录，test 新建 ${testCreated} 个目录`);
if (microPlan) {
  console.log(`  - 代码根: ${freshCtx.codeRoot}（SOT=工程方案 pathBase 基准）`);
  console.log(`  - codeModules: ${freshCtx.modules.map((module) => `${module.moduleId}→${module.pathBase}`).join('、')}`);
  console.log(`  - rootPackage: ${rootPackage}（SOT=工程方案 codeModules[].packageName）`);
} else {
  console.log(`  - backendDir: ${backendDir}`);
  console.log(`  - rootPackage: ${rootPackage}（SOT=skeleton-conventions.json）`);
}
console.log(`  - layerPackages: ${layerPackages ? layerPackages.join('/') : 'absent（骨架无分层子包，跳过子包预建）'}`);
console.log(`  - commonPackageMapping: ${commonPackageMapping ? Object.keys(commonPackageMapping).join(',') : 'absent（走通用 root.<moduleDir>）'}`);
console.log(`  - entity-*.md 数: ${entityFiles.length}`);
