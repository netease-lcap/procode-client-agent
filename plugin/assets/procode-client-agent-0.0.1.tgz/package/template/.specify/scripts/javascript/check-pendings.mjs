import fs from 'fs';
import path from 'path';

import {
  PENDING,
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  findUnderSpecs,
  filterUnderSpecs,
  removeUnderSpecs,
  parse,
  writeToFileSync,
  formatWritedFiles,
  auto,
  writeToLog,
} from './shared/index.mjs';

export const filter = (item) => item.includes('specs/') || item.includes('plans/');

export const toRaw = (rootDir = '') => {
  rootDir = rootDir || process.cwd();

  writeToLog('check-pending', '检查开始');

  const bundles = filterUnderSpecs(rootDir)(filter);
  const matched = bundles
    .filter((item = {}) => {
      const { absoluteFilePath } = item;

      if (absoluteFilePath?.endsWith?.('.json')) {
        return;
      }

      if (absoluteFilePath?.includes?.('/plans/')) {
        return;
      }

      const content = readFileSync(absoluteFilePath) || '';
      const matched = content.includes(PENDING);

      if (!matched) {
        return;
      }

      return item;
    })
    .map((item = {}) => {
      const { absoluteFilePath } = item;

      const parsed = parse({ rootDir })(absoluteFilePath);
      const title = parsed?.[0]?.title;

      if (title === '关联主题') {
        return `- ${absoluteFilePath}`;
      }

      return `- [${title}](${absoluteFilePath})`;
    });

  writeToLog('check-pending', '检查结束');

  if (!matched.length) {
    return '所有文件均已修改验收';
  }

  const messages = [
    '未修改验收文件列表：',
    '',
    '<!-- **特别注意/关键规则**：你有充足的时间与资源，必须严格按照任务要求，对以下文件内容进行验收改正。禁止出于任何理由，导致没有严格遵守任务要求验收文件内容。 -->',
    '',
    ...matched,
  ];

  return messages.join('\n');
};

auto(import.meta)(toRaw);
export default toRaw;
