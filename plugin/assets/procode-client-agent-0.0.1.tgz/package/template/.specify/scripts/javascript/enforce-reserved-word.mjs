#!/usr/bin/env node

// enforce-reserved-word.mjs — 保留字表名机械改名（确定性，无语义判断）
//
// 用途：data-model 自检（check-backend-design.mjs）报出表名命中 SQL 保留字时，
// 生成 agent 调用本脚本完成文件改名 + DDL/字段表/跨域小节内表名标识符替换，
// 禁 agent 手动 `rm`/`git mv`/`mv`+`sed` 做改名——git 操作不在生成 agent 权限内
// （会触发 git 禁令连累整条命令），手动 sed/Edit 易 whitespace 漂移失败。
//
// 语义判断（新表名取什么，如 user→app_user 还是 sys_user）由 agent 按业务语境决定
// 并通过 argv 传入；本脚本只做机械替换：word-boundary 标识符替换不会误伤
// user_id/username/app_user 等含该子串的非表名标识符（_ 为 word 字符，\b 不在其间断）。
//
// 用法：node enforce-reserved-word.mjs <entity-文件绝对路径> <新表名>
//   例：node enforce-reserved-word.mjs .../plans/backend/entity-user.md app_user
// 输出：stdout JSON { ok, oldName, newName, newPath, replacements, referrers }
//   referrers = 同目录其他 entity-*.md 中以标识符形式引用旧表名的文件（只读扫描提示，
//   不自动改他文件——避免并发写冲突；agent 据此清单逐个修引用）。

import { readFileSync, writeFileSync, existsSync, unlinkSync, readdirSync } from 'fs';
import { resolve, dirname, basename, join } from 'path';

const [,, entityFile, newTableRaw] = process.argv;

if (!entityFile || !newTableRaw) {
  console.log(JSON.stringify({
    ok: false,
    failures: ['用法: node enforce-reserved-word.mjs <entity-文件绝对路径> <新表名>'],
  }));
  process.exit(0);
}

const newTable = String(newTableRaw).trim();

// 新表名合法性：snake_case，首字母小写字母/下划线，后续字母数字下划线，禁含连字符/空格
if (!/^[a-z][a-z0-9_]*$/.test(newTable)) {
  console.log(JSON.stringify({
    ok: false,
    failures: [`新表名「${newTable}」不合法：须 snake_case（小写字母开头，仅字母/数字/下划线，禁连字符/空格）`],
  }));
  process.exit(0);
}

if (!existsSync(entityFile)) {
  console.log(JSON.stringify({ ok: false, failures: [`文件不存在: ${entityFile}`] }));
  process.exit(0);
}

const absFile = resolve(entityFile);
const dir = dirname(absFile);
const oldBasename = basename(absFile); // 如 entity-user.md
const content = readFileSync(absFile, 'utf-8');

// 从 DDL 提取当前表名（CREATE TABLE [IF NOT EXISTS] [`]name[`]）
const tblM = content.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([a-zA-Z_][\w]*)`?/i);
if (!tblM) {
  console.log(JSON.stringify({
    ok: false,
    failures: ['未在 DDL 找到 CREATE TABLE 语句，无法确定当前表名——本脚本只改有 DDL 的 entity 文件'],
  }));
  process.exit(0);
}
const oldTable = tblM[1];

if (oldTable === newTable) {
  console.log(JSON.stringify({
    ok: false,
    failures: [`新表名与当前表名同为「${oldTable}」，无需改名`],
  }));
  process.exit(0);
}

// 目标文件名：entity-{old}.md → entity-{new}.md（entity 文件名 = DDL 表名约定）
const oldSlug = oldBasename.replace(/^entity-/, '').replace(/\.md$/, '');
const newBasename = `entity-${newTable}.md`;
const newPath = join(dir, newBasename);

if (existsSync(newPath)) {
  console.log(JSON.stringify({
    ok: false,
    failures: [`目标文件已存在: ${newPath}——疑似表名撞名，未改名；请确认新表名或先处理既有同名文件`],
  }));
  process.exit(0);
}

// word-boundary 标识符替换：\boldTable\b 不匹配 user_id/username/app_user 等子串
// （_ 为 word 字符，user 与 _user/username 之间无 \b 边界）
const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const identRe = new RegExp(`\\b${escapeRe(oldTable)}\\b`, 'g');
let replacements = 0;
const newContent = content.replace(identRe, (m) => { replacements++; return newTable; });

if (replacements === 0) {
  console.log(JSON.stringify({
    ok: false,
    failures: [`文件内容未找到表名标识符「${oldTable}」（word-boundary 未命中）——可能 DDL 表名与文件名 slug 不一致，请先核对`],
  }));
  process.exit(0);
}

// 写新文件 + 删旧文件
writeFileSync(newPath, newContent, 'utf-8');
unlinkSync(absFile);

// 只读扫描同目录其他 entity-*.md，列出以标识符形式引用旧表名的文件（提示 agent 修引用）
let referrers = [];
try {
  referrers = readdirSync(dir)
    .filter((n) => n.startsWith('entity-') && n.endsWith('.md') && n !== newBasename && n !== oldBasename)
    .map((n) => {
      const c = readFileSync(join(dir, n), 'utf-8');
      const hits = (c.match(identRe) || []).length;
      return hits > 0 ? { file: n, references: hits } : null;
    })
    .filter(Boolean);
} catch {
  // 扫描失败不影响改名结果
}

console.log(JSON.stringify({
  ok: true,
  oldName: oldTable,
  newName: newTable,
  oldSlug,
  newPath,
  replacements,
  referrers,
}, null, 2));
process.exit(0);
