/**
 * Agent B SQL plan 的机械校验（无第三方依赖）。
 *
 * 契约来源：
 *   - plan/2026-11-04/incremental-code-schema-and-build-codegen.md §5.3（table plan）
 *   - 同 plan §5.2.1（catalog preflight）
 *   - 同 plan §5.8（local mock 的四条 canonical SQL）
 *
 * 形状：
 *   { dialect, tables:[{ table, dataSourceName, sql, fallbackSql?, expectedShape }] } // 逐表 plan
 *   { dialect, catalog:{ listTablesSql, fallbackSql?, countSql?, pageSize? } } // 表清单 preflight
 *   两者可同时出现；`tables: []` 合法（零存量结构：目标库确认没有可采集的 code table）。
 *   空表计划是否可放行由上游 plan checker 按「该数据源 codeTables=[] 且 catalogComplete=true」判定。
 *
 * 校验口径：
 *   - dialect 非空（拒绝空白）；
 *   - tables 为数组（可为空）；table / sql / fallbackSql 条目均为非空字符串；
 *   - dataSourceName 必填：每条表记录显式声明已确认的数据源，单源与多源同一契约；
 *   - expectedShape ∈ { ddl, columns }；
 *   - 拒绝表条目/ catalog 条目的未知键（防 agent 幻觉字段），顶层额外元数据放行；
 *   - **语句级只读校验**：primary / fallback / probe.versionSql / catalog.listTablesSql /
 *     catalog.countSql 只允许 SELECT / SHOW / WITH...SELECT / EXPLAIN / DESCRIBE（允许前导
 *     空白与注释）；拒绝 DML/DDL/DCL、多语句、MySQL 可执行注释 `/*! ... *\/`、
 *     `SELECT ... INTO OUTFILE/DUMPFILE`、`SELECT ... FOR UPDATE/SHARE`；
 *   - 不做方言白名单，不内置任何方言 SQL。
 *
 * 导出：
 *   collectPlanIssues(plan)      → string[]（空数组=合法）
 *   validatePlan(plan)           → { kind, plan }，非法时抛 PlanValidationError
 *   inspectReadOnlySql(sql)      → { readonly, keyword, reason }（runner 下发前二次校验复用）
 *   LOCAL_MOCK_SQL               → §5.8 四条 canonical 模板（只读）
 *   renderLocalMockSql(name, p)  → 模板占位替换（缺参数/未知模板抛错）
 */

import { readFileSync } from 'fs';
import { sanitizeSql } from '../sql-text.mjs';

const SCHEMA_FILE = new URL('./plan-schema.json', import.meta.url);

/** 原样导出 JSON Schema，供文档 / 外部校验器使用。 */
export const PLAN_SCHEMA = JSON.parse(readFileSync(SCHEMA_FILE, 'utf-8'));

/** §5.8 四条 MySQL canonical 只读 SQL（本地 mock 场景必须选用）。 */
export const LOCAL_MOCK_SQL = Object.freeze({ ...PLAN_SCHEMA.localMockSql });

export const LOCAL_MOCK_SQL_NAMES = Object.freeze(Object.keys(LOCAL_MOCK_SQL));

export const PLAN_VALIDATION_CODE = 'SCHEMA_PLAN_INVALID';

const TABLE_KEYS = new Set(['table', 'dataSourceName', 'sql', 'fallbackSql', 'expectedShape']);
const CATALOG_KEYS = new Set(['listTablesSql', 'fallbackSql', 'countSql', 'pageSize']);
const PROBE_KEYS = new Set(['versionSql', 'fallbackSql']);
const EXPECTED_SHAPES = new Set(['ddl', 'columns']);

const isPlainObject = (value) =>
  value != null && typeof value === 'object' && !Array.isArray(value);

const isNonEmptyString = (value) => typeof value === 'string' && value.trim() !== '';

// ─── 只读 SQL 语句级校验 ─────────────────────────────────────────────────────
// 只做「语句类型」判定，不做方言解析：SELECT / SHOW / WITH...SELECT / EXPLAIN /
// DESCRIBE。注释与字符串先被屏蔽，避免把字面量里的分号/关键字当成语句结构。

const ALLOWED_READONLY_KEYWORDS = new Set(['SELECT', 'SHOW', 'WITH', 'EXPLAIN', 'DESCRIBE', 'DESC']);

/** 可作为「主语句」起点的关键字（含写语句，用于识别 WITH ... DELETE / EXPLAIN DELETE）。 */
const STATEMENT_KEYWORDS = new Set([
  'SELECT',
  'SHOW',
  'WITH',
  'EXPLAIN',
  'DESCRIBE',
  'DESC',
  'INSERT',
  'UPDATE',
  'DELETE',
  'MERGE',
  'REPLACE',
  'CREATE',
  'ALTER',
  'DROP',
  'TRUNCATE',
  'RENAME',
  'GRANT',
  'REVOKE',
  'CALL',
  'DO',
  'COPY',
  'LOCK',
  'UNLOCK',
  'SET',
  'USE',
  'LOAD',
  'HANDLER',
  'OPTIMIZE',
  'REPAIR',
  'FLUSH',
  'KILL',
  'PREPARE',
  'EXECUTE',
  'DEALLOCATE',
]);

const rejectReadonly = (reason, keyword = null) => ({ readonly: false, keyword, reason });
const acceptReadonly = (keyword) => ({ readonly: true, keyword, reason: '' });

/**
 * 把注释替换为空格、把字符串/引用标识符的内容屏蔽掉（保留引号边界）。
 * 返回 { text, executableComment }：`/*! ... *\/`（MySQL 会执行注释内容）单独标记。
 */
/** 从 fromIndex 起找第一个 depth=0 的语句关键字；返回 { word, index }。 */
function findMainStatementKeyword(code, fromIndex) {
  let depth = 0;
  let i = fromIndex;
  while (i < code.length) {
    const ch = code[i];
    if (ch === '(') {
      depth += 1;
      i += 1;
      continue;
    }
    if (ch === ')') {
      depth = Math.max(0, depth - 1);
      i += 1;
      continue;
    }
    if (depth === 0 && /[A-Za-z_]/.test(ch)) {
      let j = i + 1;
      while (j < code.length && /[A-Za-z0-9_$]/.test(code[j])) j += 1;
      const word = code.slice(i, j).toUpperCase();
      if (STATEMENT_KEYWORDS.has(word)) return { word, index: i };
      i = j;
      continue;
    }
    i += 1;
  }
  return { word: null, index: -1 };
}

function checkReadonlyStatement(code) {
  const match = /^([A-Za-z]+)/.exec(code);
  if (!match) return rejectReadonly('无法识别语句关键字（只允许只读 SQL）');
  const keyword = match[1].toUpperCase();
  if (!ALLOWED_READONLY_KEYWORDS.has(keyword)) {
    return rejectReadonly(`首语句不是只读语句（发现 "${keyword}"）`, keyword);
  }

  if (keyword === 'WITH') {
    const main = findMainStatementKeyword(code, match[0].length);
    if (!main.word) return rejectReadonly('WITH 语句缺少主语句', keyword);
    if (main.word === 'WITH') {
      return checkReadonlyStatement(code.slice(main.index));
    }
    if (main.word !== 'SELECT') {
      return rejectReadonly(`WITH 主语句必须是 SELECT（发现 "${main.word}"）`, keyword);
    }
    return acceptReadonly(keyword);
  }

  if (keyword === 'EXPLAIN') {
    const main = findMainStatementKeyword(code, match[0].length);
    // `EXPLAIN <table>`（等价 DESCRIBE）没有主语句关键字：只读。
    if (!main.word) return acceptReadonly(keyword);
    if (main.word === 'WITH' || main.word === 'EXPLAIN') {
      return checkReadonlyStatement(code.slice(main.index));
    }
    if (main.word !== 'SELECT') {
      return rejectReadonly(`EXPLAIN 的目标语句必须是只读 SELECT（发现 "${main.word}"）`, keyword);
    }
    return acceptReadonly(keyword);
  }

  return acceptReadonly(keyword);
}

/**
 * 语句级只读判定（primary/fallback/probe/catalog 共用；runner 下发前二次校验复用同一实现）。
 *
 * 允许：SELECT、SHOW、WITH ... SELECT、EXPLAIN [ANALYZE] SELECT、DESCRIBE/DESC；
 * 允许前导空白与注释。拒绝：其余全部语句、多语句（分号分隔）、MySQL 可执行注释、
 * `SELECT ... INTO OUTFILE/DUMPFILE`、`SELECT ... FOR UPDATE/SHARE`。
 *
 * @param {unknown} sql
 * @returns {{readonly:boolean, keyword:string|null, reason:string}}
 */
export function inspectReadOnlySql(sql) {
  if (typeof sql !== 'string' || sql.trim() === '') {
    return rejectReadonly('SQL 为空');
  }
  const { text, executableComment } = sanitizeSql(sql);
  if (executableComment) {
    return rejectReadonly('含 MySQL 可执行注释 /*! ... */（注释内容会被数据库执行）');
  }
  const trimmed = text.trim();
  if (trimmed === '') return rejectReadonly('SQL 只有注释');

  // 只允许一个尾分号；去掉尾分号后仍出现分号 = 多语句。
  const trailing = /;+\s*$/.exec(trimmed);
  if (trailing && trailing[0].length > 1) {
    return rejectReadonly('包含多语句（只有单个尾分号允许）');
  }
  const body = (trailing ? trimmed.slice(0, trimmed.length - trailing[0].length) : trimmed).trim();
  if (body.includes(';')) {
    return rejectReadonly('包含多语句（只允许单条只读语句）');
  }

  const verdict = checkReadonlyStatement(body);
  if (!verdict.readonly) return verdict;
  // CTE 内的写语句也会执行；SHOW CREATE 和 SELECT REPLACE(...) 仍是查询。
  if (/(?:^|[;(])\s*(?:INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE)\b/i.test(body)) {
    return rejectReadonly('只读采集不能包含写操作', verdict.keyword);
  }
  if (['WITH', 'SELECT'].includes(verdict.keyword) && /\bINTO\b/i.test(body)) {
    return rejectReadonly('SELECT INTO 不属于只读采集', verdict.keyword);
  }

  // 只读语句里的写文件 / 加锁变体同样拒绝。
  if (/\bINTO\s+(?:OUTFILE|DUMPFILE)\b/i.test(body)) {
    return rejectReadonly('SELECT ... INTO OUTFILE/DUMPFILE 会写文件', verdict.keyword);
  }
  if (/\bFOR\s+(?:NO\s+KEY\s+UPDATE|KEY\s+SHARE|UPDATE|SHARE)\b/i.test(body)) {
    return rejectReadonly('SELECT ... FOR UPDATE/SHARE 会加锁，不属于只读采集', verdict.keyword);
  }
  return verdict;
}

function validateReadOnlySql(sql, label, issues) {
  if (!isNonEmptyString(sql)) return;
  const verdict = inspectReadOnlySql(sql);
  if (!verdict.readonly) {
    issues.push(
      `${label} 不是只读 SQL：${verdict.reason}（只允许 SELECT / SHOW / WITH...SELECT / EXPLAIN / DESCRIBE）`,
    );
  }
}

/** 结构化校验错误：issues 全量保留，调用方不得只取第一条。 */
export class PlanValidationError extends Error {
  constructor(issues, message = 'SQL plan 形状非法') {
    super(message);
    this.name = 'PlanValidationError';
    this.code = PLAN_VALIDATION_CODE;
    this.issues = [...issues];
  }

  toJSON() {
    return {
      ok: false,
      code: this.code,
      message: this.message,
      issues: [...this.issues],
    };
  }
}

function validateFallback(entry, label, issues) {
  if (entry.fallbackSql === undefined) return;
  if (!Array.isArray(entry.fallbackSql)) {
    issues.push(`${label}.fallbackSql 必须是字符串数组`);
    return;
  }
  entry.fallbackSql.forEach((sql, index) => {
    if (!isNonEmptyString(sql)) {
      issues.push(`${label}.fallbackSql[${index}] 必须是非空字符串`);
      return;
    }
    validateReadOnlySql(sql, `${label}.fallbackSql[${index}]`, issues);
  });
}

function validateUnknownKeys(entry, allowed, label, issues) {
  for (const key of Object.keys(entry)) {
    if (!allowed.has(key)) issues.push(`${label} 含未知字段 "${key}"`);
  }
}

function validateTableEntry(entry, index, issues) {
  const label = `tables[${index}]`;
  if (!isPlainObject(entry)) {
    issues.push(`${label} 必须是对象`);
    return;
  }
  validateUnknownKeys(entry, TABLE_KEYS, label, issues);
  if (!isNonEmptyString(entry.table)) issues.push(`${label}.table 必须是非空字符串`);
  if (!isNonEmptyString(entry.dataSourceName)) {
    issues.push(`${label}.dataSourceName 必填且必须是非空字符串（表 ${JSON.stringify(entry.table)}；从已确认的数据源契约读取，单源也必须显式填写）`);
  }
  if (!isNonEmptyString(entry.sql)) {
    issues.push(`${label}.sql 必须是非空字符串`);
  } else {
    validateReadOnlySql(entry.sql, `${label}.sql`, issues);
  }
  if (entry.expectedShape === undefined) {
    issues.push(`${label}.expectedShape 必填（ddl | columns）`);
  } else if (!EXPECTED_SHAPES.has(entry.expectedShape)) {
    issues.push(`${label}.expectedShape 必须是 "ddl" 或 "columns"`);
  }
  validateFallback(entry, label, issues);
}

function validateCatalogEntry(catalog, issues) {
  const label = 'catalog';
  if (!isPlainObject(catalog)) {
    issues.push(`${label} 必须是对象`);
    return;
  }
  validateUnknownKeys(catalog, CATALOG_KEYS, label, issues);
  if (!isNonEmptyString(catalog.listTablesSql)) {
    issues.push(`${label}.listTablesSql 必须是非空字符串`);
  } else {
    validateReadOnlySql(catalog.listTablesSql, `${label}.listTablesSql`, issues);
  }
  if (catalog.countSql !== undefined) {
    if (!isNonEmptyString(catalog.countSql)) {
      issues.push(`${label}.countSql 必须是非空字符串`);
    } else {
      validateReadOnlySql(catalog.countSql, `${label}.countSql`, issues);
    }
  }
  if (catalog.pageSize !== undefined && (!Number.isInteger(catalog.pageSize) || catalog.pageSize <= 0)) {
    issues.push(`${label}.pageSize 必须是正整数`);
  }
  validateFallback(catalog, label, issues);
}

function validateProbeEntry(probe, issues) {
  const label = 'probe';
  if (!isPlainObject(probe)) {
    issues.push(`${label} 必须是对象`);
    return;
  }
  validateUnknownKeys(probe, PROBE_KEYS, label, issues);
  if (!isNonEmptyString(probe.versionSql)) {
    issues.push(`${label}.versionSql 必须是非空字符串`);
  } else {
    validateReadOnlySql(probe.versionSql, `${label}.versionSql`, issues);
  }
  validateFallback(probe, label, issues);
}

/** 收集全部形状问题（不抛错；测试/门禁可直接用）。 */
export function collectPlanIssues(plan) {
  const issues = [];
  if (!isPlainObject(plan)) {
    return ['plan 必须是对象'];
  }
  if (!isNonEmptyString(plan.dialect)) {
    issues.push('dialect 必须是非空字符串');
  }

  const hasTablesKey = Object.prototype.hasOwnProperty.call(plan, 'tables');
  const hasCatalogKey = Object.prototype.hasOwnProperty.call(plan, 'catalog');

  if (hasTablesKey) {
    if (!Array.isArray(plan.tables)) {
      issues.push('tables 必须是数组');
    } else {
      plan.tables.forEach((entry, index) => validateTableEntry(entry, index, issues));
    }
  }

  if (hasCatalogKey) validateCatalogEntry(plan.catalog, issues);

  const hasProbeKey = Object.prototype.hasOwnProperty.call(plan, 'probe');
  if (hasProbeKey) validateProbeEntry(plan.probe, issues);

  if (!hasTablesKey && !hasCatalogKey) {
    issues.push('plan 必须至少包含 tables 或 catalog 之一（probe 只是附加探针，不构成采集）');
  }
  return issues;
}

function normalizeFallback(fallbackSql) {
  if (!Array.isArray(fallbackSql)) return undefined;
  return fallbackSql.map((sql) => sql.trim());
}

function normalizeEntry(entry) {
  const normalized = {
    table: entry.table.trim(),
    dataSourceName: entry.dataSourceName.trim(),
    sql: entry.sql.trim(),
    expectedShape: entry.expectedShape,
  };
  const fallbackSql = normalizeFallback(entry.fallbackSql);
  if (fallbackSql !== undefined) normalized.fallbackSql = fallbackSql;
  return normalized;
}

function normalizeCatalog(catalog) {
  const normalized = { listTablesSql: catalog.listTablesSql.trim() };
  if (catalog.countSql !== undefined) normalized.countSql = catalog.countSql.trim();
  if (catalog.pageSize !== undefined) normalized.pageSize = catalog.pageSize;
  const fallbackSql = normalizeFallback(catalog.fallbackSql);
  if (fallbackSql !== undefined) normalized.fallbackSql = fallbackSql;
  return normalized;
}

function normalizeProbe(probe) {
  const normalized = { versionSql: probe.versionSql.trim() };
  const fallbackSql = normalizeFallback(probe.fallbackSql);
  if (fallbackSql !== undefined) normalized.fallbackSql = fallbackSql;
  return normalized;
}

/**
 * 校验并返回归一化 plan（trim dialect / 表名 / SQL 首尾空白；不改写 SQL 内部）。
 *
 * @returns {{kind:'tables'|'catalog'|'tables+catalog', plan:object}}
 * @throws {PlanValidationError}
 */
export function validatePlan(plan) {
  const issues = collectPlanIssues(plan);
  if (issues.length > 0) throw new PlanValidationError(issues);

  const hasTables = Object.prototype.hasOwnProperty.call(plan, 'tables');
  const hasCatalog = Object.prototype.hasOwnProperty.call(plan, 'catalog');
  const hasProbe = Object.prototype.hasOwnProperty.call(plan, 'probe');
  const normalized = { dialect: plan.dialect.trim() };
  if (hasCatalog) normalized.catalog = normalizeCatalog(plan.catalog);
  if (hasProbe) normalized.probe = normalizeProbe(plan.probe);
  if (hasTables) normalized.tables = plan.tables.map(normalizeEntry);

  const kind = hasTables && hasCatalog ? 'tables+catalog' : hasTables ? 'tables' : 'catalog';
  return { kind, plan: normalized };
}

/**
 * 渲染 §5.8 local mock canonical SQL。
 *
 * 占位符：{{database}} / {{limit}} / {{offset}} / {{tableIdentifier}}。
 * 调用方负责方言安全的字面量/标识符拼装；本函数只做字符串替换。
 *
 * @param {keyof typeof LOCAL_MOCK_SQL} name
 * @param {Record<string, string|number>} [params]
 * @returns {string}
 */
export function renderLocalMockSql(name, params = {}) {
  if (!Object.prototype.hasOwnProperty.call(LOCAL_MOCK_SQL, name)) {
    throw new PlanValidationError(
      [`未知 localMockSql 模板 "${name}"`],
      `未知 localMockSql 模板 "${name}"（可选：${LOCAL_MOCK_SQL_NAMES.join(', ')}）`,
    );
  }
  let rendered = LOCAL_MOCK_SQL[name];
  for (const [key, value] of Object.entries(params)) {
    rendered = rendered.split(`{{${key}}}`).join(String(value));
  }
  const missing = rendered.match(/\{\{[A-Za-z_][A-Za-z0-9_]*\}\}/g);
  if (missing) {
    throw new PlanValidationError(
      [`localMockSql "${name}" 缺参数：${missing.join(', ')}`],
      `localMockSql "${name}" 缺参数：${missing.join(', ')}`,
    );
  }
  return rendered;
}
