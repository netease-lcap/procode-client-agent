import fs from 'fs';
import path from 'path';

const filePath = process.argv[2];

if (!filePath) {
  process.exit(0);
}

const normalized = filePath.replace(/\\/g, '/');

if (!fs.existsSync(normalized)) {
  console.error(`文件不存在: ${normalized}`);
  process.exit(1);
}

const content = fs.readFileSync(normalized, 'utf8');

const extractPaths = (source) => {
  const paths = new Set();

  const linkReg = /^###\s+\[([^\]]+)\]\(([^)]+)\)/gm;
  let match;
  while ((match = linkReg.exec(source)) !== null) {
    const p = match[2].trim();
    if (p && !p.includes('[') && /\.(md|json|txt)$/i.test(p)) {
      paths.add(p);
    }
  }

  return Array.from(paths);
};

const paths = extractPaths(content);

if (!paths.length) {
  process.exit(0);
}

const rootDir = process.cwd();
const missing = [];

for (const p of paths) {
  const norm = p.replace(/\\/g, '/');

  if (fs.existsSync(norm)) continue;

  const resolved = path.resolve(rootDir, norm);
  if (fs.existsSync(resolved)) continue;

  missing.push(p);
}

if (missing.length === 0) {
  process.exit(0);
}

console.error('变更历史文件路径验证失败');
console.error('以下文件路径不存在：');
missing.forEach((p) => console.error(`  - ${p}`));
console.error('请修正变更历史中的文件路径。');
process.exit(1);
