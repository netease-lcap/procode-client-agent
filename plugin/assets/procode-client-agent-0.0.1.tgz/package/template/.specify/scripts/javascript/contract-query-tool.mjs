/* Generated from cli.mts — do not edit; rebuild: pnpm build */


// src/utils/customWaveAgent/speckit/config/shared/contract-query/cli.mts
import { realpathSync, statSync } from "node:fs";
import path2 from "node:path";
import { pathToFileURL } from "node:url";

// src/utils/customWaveAgent/speckit/config/shared/contract-query/core.ts
import fs from "node:fs";
import path from "node:path";
import { createHash } from "node:crypto";
var isIdentityOnlyObject = (object) => object.basis === "db-only" && object.diffable === false && Array.isArray(object.columns) && object.columns.length === 0;
var CONTRACT_QUERY_DEFAULT_MAX_BYTES = 8192;
var CONTRACT_QUERY_ALLOWED_ROOTS = ["plans", "specs"];
var MAX_FILE_BYTES = 64 * 1024 * 1024;
var SUMMARY_ARRAY_SAMPLE_LIMIT = 20;
var SCHEMA_DETAIL_SECTIONS = [
  "columns",
  "indexes",
  "constraints",
  "foreignKeys",
  "rawDdl",
  "comments",
  "tableOptions",
  "parseIssues"
];
var SCHEMA_OBJECT_KINDS = ["table", "view", "sequence", "other"];
var INVALID_LITERAL = Symbol("invalid-literal");
var fail = (reason, message) => ({
  ok: false,
  reason,
  message
});
var sha256Hex = (input) => createHash("sha256").update(input).digest("hex");
var toPosix = (value) => value.replace(/\\/g, "/");
var isPlainObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var contractNodeType = (value) => {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  const kind = typeof value;
  if (kind === "string" || kind === "number" || kind === "boolean") return kind;
  if (kind === "object") return "object";
  return "null";
};
var jsonByteLength = (value) => {
  const text = JSON.stringify(value);
  return Buffer.byteLength(text === void 0 ? "undefined" : text, "utf8");
};
var byteShare = (part, total) => Math.round(part / Math.max(total, 1) * 1e4) / 1e4;
var normalizeMaxBytes = (raw) => {
  const value = typeof raw === "number" ? raw : Number.NaN;
  return Number.isFinite(value) && value > 0 ? Math.floor(value) : CONTRACT_QUERY_DEFAULT_MAX_BYTES;
};
var normalizeNonNegative = (raw) => {
  const value = typeof raw === "number" ? raw : Number.NaN;
  return Number.isFinite(value) && value >= 0 ? Math.floor(value) : 0;
};
var escapePointerToken = (token) => token.replace(/~/g, "~0").replace(/\//g, "~1");
var unescapePointerToken = (token) => token.replace(/~1/g, "/").replace(/~0/g, "~");
var parseJsonPointer = (pointer) => {
  if (typeof pointer !== "string") return null;
  if (pointer === "") return [];
  if (!pointer.startsWith("/")) return null;
  const tokens = [];
  for (const raw of pointer.slice(1).split("/")) {
    if (/~(?![01])/.test(raw)) return null;
    tokens.push(unescapePointerToken(raw));
  }
  return tokens;
};
var formatJsonPointer = (tokens) => tokens.length === 0 ? "" : `/${tokens.map(escapePointerToken).join("/")}`;
var readPointer = (rootValue, tokens) => {
  let current = rootValue;
  for (const token of tokens) {
    if (Array.isArray(current)) {
      if (!/^(0|[1-9]\d*)$/.test(token)) return { found: false };
      const index = Number(token);
      if (index >= current.length) return { found: false };
      current = current[index];
      continue;
    }
    if (isPlainObject(current)) {
      if (!Object.prototype.hasOwnProperty.call(current, token)) return { found: false };
      current = current[token];
      continue;
    }
    return { found: false };
  }
  return { found: true, value: current };
};
var isContractFileFailure = (result) => result.ok === false;
var isInside = (rootAbs, targetAbs) => {
  const prefix = rootAbs.endsWith(path.sep) ? rootAbs : `${rootAbs}${path.sep}`;
  return targetAbs.startsWith(prefix);
};
var firstSegment = (relative) => relative.split(/[\\/]/).filter(Boolean)[0] ?? "";
var allowedRoot = (segment) => CONTRACT_QUERY_ALLOWED_ROOTS.includes(segment);
var resolveContractFile = (root, file) => {
  if (typeof file !== "string" || file.length === 0) {
    return { ok: false, reason: "path-not-allowed", message: "\u5951\u7EA6\u6587\u4EF6\u8DEF\u5F84\u4E0D\u80FD\u4E3A\u7A7A" };
  }
  if (file.includes("\0")) {
    return { ok: false, reason: "path-not-allowed", message: "\u5951\u7EA6\u6587\u4EF6\u8DEF\u5F84\u542B\u7A7A\u5B57\u8282" };
  }
  if (path.isAbsolute(file) || /^[A-Za-z]:[\\/]/.test(file) || file.startsWith("\\\\")) {
    return { ok: false, reason: "path-not-allowed", message: "\u62D2\u7EDD\u7EDD\u5BF9\u8DEF\u5F84\uFF1A\u53EA\u63A5\u53D7\u76F8\u5BF9\u5DE5\u4F5C\u533A\u6839\u7684 plans/ \u6216 specs/ \u8DEF\u5F84" };
  }
  const rootAbs = path.resolve(root);
  const targetAbs = path.resolve(rootAbs, file);
  if (!isInside(rootAbs, targetAbs)) {
    return { ok: false, reason: "path-not-allowed", message: "\u8DEF\u5F84\u8D8A\u51FA\u5DE5\u4F5C\u533A\u6839\uFF08\u4E0D\u5141\u8BB8 .. \u7A7F\u8D8A\uFF09" };
  }
  const relative = path.relative(rootAbs, targetAbs);
  if (!allowedRoot(firstSegment(relative))) {
    return {
      ok: false,
      reason: "path-not-allowed",
      message: `\u8DEF\u5F84\u4E0D\u5728\u767D\u540D\u5355\u5185\uFF1A\u53EA\u5141\u8BB8 ${CONTRACT_QUERY_ALLOWED_ROOTS.join("/ \u4E0E ")}/ \u5B50\u6811`
    };
  }
  let realRoot;
  try {
    realRoot = fs.realpathSync(rootAbs);
  } catch {
    return { ok: false, reason: "not-found", message: `\u5DE5\u4F5C\u533A\u6839\u4E0D\u5B58\u5728\u6216\u4E0D\u53EF\u8BFB\uFF1A${rootAbs}` };
  }
  let realTarget;
  try {
    realTarget = fs.realpathSync(targetAbs);
  } catch {
    return { ok: false, reason: "not-found", message: `\u5951\u7EA6\u6587\u4EF6\u4E0D\u5B58\u5728\uFF1A${toPosix(relative)}` };
  }
  if (!isInside(realRoot, realTarget)) {
    return { ok: false, reason: "path-not-allowed", message: "\u8DEF\u5F84\u7ECF\u7B26\u53F7\u94FE\u63A5\u9003\u9038\u51FA\u5DE5\u4F5C\u533A\u6839" };
  }
  const realRelative = path.relative(realRoot, realTarget);
  if (!allowedRoot(firstSegment(realRelative))) {
    return {
      ok: false,
      reason: "path-not-allowed",
      message: `\u8DEF\u5F84\u7ECF\u7B26\u53F7\u94FE\u63A5\u843D\u5230\u767D\u540D\u5355\u5916\uFF1A\u53EA\u5141\u8BB8 ${CONTRACT_QUERY_ALLOWED_ROOTS.join("/ \u4E0E ")}/ \u5B50\u6811`
    };
  }
  try {
    if (!fs.statSync(realTarget).isFile()) {
      return { ok: false, reason: "not-found", message: `\u4E0D\u662F\u666E\u901A\u6587\u4EF6\uFF1A${toPosix(relative)}` };
    }
  } catch {
    return { ok: false, reason: "not-found", message: `\u5951\u7EA6\u6587\u4EF6\u4E0D\u53EF\u8BFB\uFF1A${toPosix(relative)}` };
  }
  return { ok: true, absolutePath: targetAbs, realPath: realTarget, relativePath: toPosix(relative) };
};
var resolveContractSource = (source) => {
  if (!source || typeof source !== "object") {
    return { ok: false, reason: "invalid-request", message: "source \u5FC5\u987B\u662F { root, file } \u6216 { value }" };
  }
  if (typeof source.file === "string") {
    if (typeof source.root !== "string" || source.root.length === 0) {
      return { ok: false, reason: "invalid-request", message: "\u6587\u4EF6\u6570\u636E\u6E90\u5FC5\u987B\u540C\u65F6\u63D0\u4F9B root \u4E0E file" };
    }
    const checked = resolveContractFile(source.root, source.file);
    if (isContractFileFailure(checked)) {
      return { ok: false, reason: checked.reason, message: checked.message };
    }
    let buffer;
    try {
      buffer = fs.readFileSync(checked.realPath);
    } catch {
      return { ok: false, reason: "not-found", message: `\u5951\u7EA6\u6587\u4EF6\u4E0D\u53EF\u8BFB\uFF1A${checked.relativePath}` };
    }
    if (buffer.byteLength > MAX_FILE_BYTES) {
      return {
        ok: false,
        reason: "file-too-large",
        message: `\u5951\u7EA6\u6587\u4EF6\u8D85\u8FC7 ${MAX_FILE_BYTES} \u5B57\u8282\u4E0A\u9650\uFF0C\u62D2\u7EDD\u6574\u6587\u4EF6\u8F7D\u5165`
      };
    }
    let value;
    try {
      value = JSON.parse(buffer.toString("utf-8"));
    } catch {
      return { ok: false, reason: "invalid-json", message: `JSON \u89E3\u6790\u5931\u8D25\uFF1A${checked.relativePath}` };
    }
    return {
      ok: true,
      value,
      source: checked.relativePath,
      digest: `sha256:${sha256Hex(buffer)}`
    };
  }
  if (Object.prototype.hasOwnProperty.call(source, "value")) {
    const serialized = JSON.stringify(source.value);
    const name = typeof source.name === "string" && source.name.trim() ? source.name.trim() : "<memory>";
    return {
      ok: true,
      value: source.value,
      source: name,
      digest: `sha256:${sha256Hex(serialized === void 0 ? String(source.value) : serialized)}`
    };
  }
  return { ok: false, reason: "invalid-request", message: "source \u5FC5\u987B\u662F { root, file } \u6216 { value }" };
};
var FIELD_PATH_RE = /^[^\s()=!,'"]+(?:\.[^\s()=!,'"]+)*$/;
var parseFieldPath = (raw) => {
  const text = raw.trim();
  if (text.length === 0 || !FIELD_PATH_RE.test(text)) return null;
  const tokens = text.split(".");
  if (tokens.some((token) => token.length === 0)) return null;
  return tokens;
};
var unescapeLiteralText = (text) => {
  let out = "";
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (char !== "\\") {
      out += char;
      continue;
    }
    const next = text[index + 1];
    if (next === void 0) return INVALID_LITERAL;
    if (next === "\\" || next === "'" || next === '"') out += next;
    else if (next === "n") out += "\n";
    else if (next === "t") out += "	";
    else if (next === "r") out += "\r";
    else return INVALID_LITERAL;
    index += 1;
  }
  return out;
};
var parseLiteral = (raw) => {
  const text = raw.trim();
  if (text.length === 0) return INVALID_LITERAL;
  const quote = text[0];
  if (quote === "'" || quote === '"') {
    if (text.length < 2 || text[text.length - 1] !== quote) return INVALID_LITERAL;
    return unescapeLiteralText(text.slice(1, -1));
  }
  if (text === "true") return true;
  if (text === "false") return false;
  if (text === "null") return null;
  if (/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/.test(text)) return Number(text);
  return INVALID_LITERAL;
};
var splitTopLevelArgs = (inner) => {
  const parts = [];
  let current = "";
  let quote = null;
  for (let index = 0; index < inner.length; index += 1) {
    const char = inner[index];
    if (quote !== null) {
      current += char;
      if (char === "\\" && index + 1 < inner.length) {
        current += inner[index + 1];
        index += 1;
        continue;
      }
      if (char === quote) quote = null;
      continue;
    }
    if (char === "'" || char === '"') {
      quote = char;
      current += char;
      continue;
    }
    if (char === ",") {
      parts.push(current);
      current = "";
      continue;
    }
    current += char;
  }
  parts.push(current);
  return parts;
};
var splitComparison = (text) => {
  let quote = null;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quote !== null) {
      if (char === "\\") {
        index += 1;
        continue;
      }
      if (char === quote) quote = null;
      continue;
    }
    if (char === "'" || char === '"') {
      quote = char;
      continue;
    }
    if (char === "=" && text[index + 1] === "=") {
      return { left: text.slice(0, index), op: "==", right: text.slice(index + 2) };
    }
    if (char === "!" && text[index + 1] === "=") {
      return { left: text.slice(0, index), op: "!=", right: text.slice(index + 2) };
    }
    if (char === "=") return null;
  }
  return null;
};
var parseWherePredicate = (expr) => {
  if (typeof expr !== "string") return null;
  const text = expr.trim();
  if (text.length === 0) return null;
  const containsMatch = /^contains\s*\(([\s\S]*)\)$/.exec(text);
  if (containsMatch) {
    const parts = splitTopLevelArgs(containsMatch[1]);
    if (parts.length !== 2) return null;
    const field2 = parseFieldPath(parts[0]);
    if (field2 === null) return null;
    const literal2 = parseLiteral(parts[1]);
    if (literal2 === INVALID_LITERAL) return null;
    return { kind: "contains", field: field2, literal: literal2 };
  }
  const split = splitComparison(text);
  if (split === null) return null;
  const field = parseFieldPath(split.left);
  if (field === null) return null;
  const literal = parseLiteral(split.right);
  if (literal === INVALID_LITERAL) return null;
  return { kind: "compare", field, op: split.op, literal };
};
var readFieldPath = (item, tokens) => {
  let current = item;
  for (const token of tokens) {
    if (Array.isArray(current)) {
      if (!/^(0|[1-9]\d*)$/.test(token)) return { found: false };
      const index = Number(token);
      if (index >= current.length) return { found: false };
      current = current[index];
      continue;
    }
    if (isPlainObject(current)) {
      if (!Object.prototype.hasOwnProperty.call(current, token)) return { found: false };
      current = current[token];
      continue;
    }
    return { found: false };
  }
  return { found: true, value: current };
};
var literalEquals = (actual, literal) => {
  if (literal === null) return actual === null;
  if (typeof literal === "number") return typeof actual === "number" && actual === literal;
  if (typeof literal === "boolean") return actual === literal;
  return typeof actual === "string" && actual === literal;
};
var matchesPredicate = (item, predicate) => {
  const hit = readFieldPath(item, predicate.field);
  if (!hit.found) return false;
  const actual = hit.value;
  if (predicate.kind === "compare") {
    const equal = literalEquals(actual, predicate.literal);
    return predicate.op === "==" ? equal : !equal;
  }
  if (typeof actual === "string") return actual.includes(String(predicate.literal));
  if (Array.isArray(actual)) return actual.some((entry) => literalEquals(entry, predicate.literal));
  return false;
};
var clipTextByBytes = (text, maxBytes) => {
  if (Buffer.byteLength(text, "utf8") <= maxBytes) return text;
  let low = 0;
  let high = text.length;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (Buffer.byteLength(text.slice(0, mid), "utf8") <= maxBytes) low = mid;
    else high = mid - 1;
  }
  return text.slice(0, Math.max(low, 1));
};
var oversizedSummary = (value, maxBytes) => {
  const serialized = JSON.stringify(value);
  const text = serialized === void 0 ? String(value) : serialized;
  const bytes = Buffer.byteLength(text, "utf8");
  const previewBudget = Math.max(32, maxBytes - 160);
  const summary2 = {
    summary: true,
    type: contractNodeType(value),
    bytes,
    preview: clipTextByBytes(text, previewBudget)
  };
  if (Array.isArray(value)) summary2.length = value.length;
  else if (isPlainObject(value)) summary2.keys = Object.keys(value).length;
  else if (typeof value === "string") summary2.length = value.length;
  return summary2;
};
var clipArrayWindow = (items, start, limit, maxBytes) => {
  const total = items.length;
  const from = Math.min(Math.max(start, 0), total);
  if (from >= total) {
    return { value: [], total, returned: 0, truncated: false, startIndex: from };
  }
  const cap = Math.min(total, from + (Number.isFinite(limit) ? Math.max(limit, 0) : total));
  const picked = [];
  let used = 2;
  for (let index = from; index < cap; index += 1) {
    const item = items[index];
    const itemBytes = jsonByteLength(item);
    if (picked.length > 0 && used + itemBytes + 1 > maxBytes) break;
    if (picked.length === 0 && used + itemBytes > maxBytes) {
      const summary2 = oversizedSummary(item, maxBytes);
      picked.push(summary2);
      used += jsonByteLength(summary2);
      break;
    }
    picked.push(item);
    used += itemBytes + (picked.length > 1 ? 1 : 0);
  }
  const consumed = from + picked.length;
  const truncated = consumed < total;
  return {
    value: picked,
    total,
    returned: picked.length,
    truncated,
    nextOffset: truncated ? consumed : void 0,
    startIndex: from
  };
};
var clipStringWindow = (text, start, maxBytes) => {
  const total = text.length;
  const from = Math.min(Math.max(start, 0), total);
  const rest = text.slice(from);
  if (jsonByteLength(rest) <= maxBytes) {
    return { value: rest, total, returned: rest.length, truncated: false };
  }
  let low = 1;
  let high = rest.length;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (jsonByteLength(rest.slice(0, mid)) <= maxBytes) low = mid;
    else high = mid - 1;
  }
  const picked = rest.slice(0, Math.max(low, 1));
  const consumed = from + picked.length;
  const truncated = consumed < total;
  return {
    value: picked,
    total,
    returned: picked.length,
    truncated,
    nextOffset: truncated ? consumed : void 0
  };
};
var clipObjectWindow = (obj, start, maxBytes) => {
  const keys = Object.keys(obj);
  const total = keys.length;
  const from = Math.min(Math.max(start, 0), total);
  const picked = [];
  if (from >= total) {
    return { value: {}, total, returned: 0, truncated: false, startIndex: from, keys: [] };
  }
  let used = 2;
  for (let index = from; index < total; index += 1) {
    const key = keys[index];
    const raw = obj[key];
    let value = raw;
    let cost = jsonByteLength(key) + jsonByteLength(raw) + 2;
    if (picked.length > 0 && used + cost + 1 > maxBytes) break;
    if (picked.length === 0 && used + cost > maxBytes) {
      value = oversizedSummary(raw, maxBytes);
      cost = jsonByteLength(key) + jsonByteLength(value) + 2;
    }
    picked.push([key, value]);
    used += cost + (picked.length > 1 ? 1 : 0);
  }
  const consumed = from + picked.length;
  const truncated = consumed < total;
  return {
    value: Object.fromEntries(picked),
    total,
    returned: picked.length,
    truncated,
    nextOffset: truncated ? consumed : void 0,
    startIndex: from,
    keys: picked.map(([key]) => key)
  };
};
var clipAny = (value, options) => {
  const maxBytes = normalizeMaxBytes(options.maxBytes);
  const offset = normalizeNonNegative(options.offset);
  if (Array.isArray(value)) return clipArrayWindow(value, offset, Number.POSITIVE_INFINITY, maxBytes);
  if (typeof value === "string") return clipStringWindow(value, offset, maxBytes);
  if (isPlainObject(value)) return clipObjectWindow(value, offset, maxBytes);
  return { value, total: 1, returned: 1, truncated: false };
};
var summarizeEntry = (key, pointer, value, totalBytes) => {
  const bytes = jsonByteLength(value);
  const entry = {
    key,
    pointer,
    type: contractNodeType(value),
    bytes,
    byteShare: byteShare(bytes, totalBytes)
  };
  if (Array.isArray(value)) entry.length = value.length;
  else if (isPlainObject(value)) entry.keys = Object.keys(value).length;
  else if (typeof value === "string") entry.length = value.length;
  return entry;
};
var okResult = (resolved, pathText, clipped, pointers = []) => {
  const result = {
    ok: true,
    source: resolved.source,
    digest: resolved.digest,
    path: pathText,
    total: clipped.total,
    returned: clipped.returned,
    truncated: clipped.truncated
  };
  if (clipped.nextOffset !== void 0) result.nextOffset = clipped.nextOffset;
  result.value = clipped.value;
  if (pointers.length > 0) result.pointers = pointers;
  return result;
};
var arrayPointers = (pathText, startIndex, returned) => {
  const pointers = [];
  for (let index = 0; index < returned; index += 1) {
    pointers.push(`${pathText}/${escapePointerToken(String(startIndex + index))}`);
  }
  return pointers;
};
var clipPointers = (pathText, clipped) => {
  if (clipped.keys) {
    return clipped.keys.map((key) => `${pathText}/${escapePointerToken(key)}`);
  }
  if (clipped.startIndex !== void 0 && Array.isArray(clipped.value)) {
    return arrayPointers(pathText, clipped.startIndex, clipped.returned);
  }
  return [];
};
var runSummary = (resolved, options) => {
  const maxBytes = normalizeMaxBytes(options.maxBytes);
  const offset = normalizeNonNegative(options.offset);
  const root = resolved.value;
  const totalBytes = Math.max(jsonByteLength(root), 1);
  const entries = [];
  let total = 1;
  let from = 0;
  if (isPlainObject(root)) {
    const keys = Object.keys(root);
    total = keys.length;
    from = Math.min(offset, total);
    let used = 2;
    for (let index = from; index < total; index += 1) {
      const key = keys[index];
      const entry = summarizeEntry(key, `/${escapePointerToken(key)}`, root[key], totalBytes);
      const size = jsonByteLength(entry);
      if (entries.length > 0 && used + size + 1 > maxBytes) break;
      entries.push(entry);
      used += size + (entries.length > 1 ? 1 : 0);
    }
  } else if (Array.isArray(root)) {
    total = root.length;
    from = Math.min(offset, total);
    let used = 2;
    for (let index = from; index < total; index += 1) {
      if (entries.length >= SUMMARY_ARRAY_SAMPLE_LIMIT) break;
      const entry = summarizeEntry(String(index), `/${index}`, root[index], totalBytes);
      const size = jsonByteLength(entry);
      if (entries.length > 0 && used + size + 1 > maxBytes) break;
      entries.push(entry);
      used += size + (entries.length > 1 ? 1 : 0);
    }
  } else {
    entries.push(summarizeEntry("", "", root, totalBytes));
  }
  const returned = entries.length;
  const truncated = from + returned < total;
  const summaryValue = {
    type: contractNodeType(root),
    bytes: jsonByteLength(root),
    entries
  };
  if (isPlainObject(root)) summaryValue.keys = Object.keys(root).length;
  else if (Array.isArray(root) || typeof root === "string") summaryValue.length = root.length;
  const result = {
    ok: true,
    source: resolved.source,
    digest: resolved.digest,
    path: "",
    total,
    returned,
    truncated
  };
  if (truncated) result.nextOffset = from + returned;
  result.value = summaryValue;
  const pointers = entries.map((entry) => entry.pointer).filter((pointer) => pointer !== "");
  if (pointers.length > 0) result.pointers = pointers;
  return result;
};
var runGet = (resolved, pointer, options) => {
  const tokens = parseJsonPointer(pointer === void 0 ? "" : pointer);
  if (tokens === null) return fail("invalid-pointer", `JSON Pointer \u975E\u6CD5\uFF1A${String(pointer)}`);
  const hit = readPointer(resolved.value, tokens);
  const pathText = formatJsonPointer(tokens);
  if (!hit.found) return fail("pointer-not-found", `\u6307\u9488\u4E0D\u5B58\u5728\uFF1A${pathText || "/"}`);
  const clipped = clipAny(hit.value, options);
  return okResult(resolved, pathText, clipped, clipPointers(pathText, clipped));
};
var runSelect = (resolved, pointer, options) => {
  const tokens = parseJsonPointer(pointer === void 0 ? "" : pointer);
  if (tokens === null) return fail("invalid-pointer", `JSON Pointer \u975E\u6CD5\uFF1A${String(pointer)}`);
  const hit = readPointer(resolved.value, tokens);
  const pathText = formatJsonPointer(tokens);
  if (!hit.found) return fail("pointer-not-found", `\u6307\u9488\u4E0D\u5B58\u5728\uFF1A${pathText || "/"}`);
  if (!Array.isArray(hit.value)) return fail("not-an-array", `select \u53EA\u80FD\u4F5C\u7528\u4E8E\u6570\u7EC4\uFF1A${pathText || "/"}`);
  const maxBytes = normalizeMaxBytes(options.maxBytes);
  const offset = normalizeNonNegative(options.offset);
  const limit = options.limit === void 0 ? Number.POSITIVE_INFINITY : normalizeNonNegative(options.limit);
  const clipped = clipArrayWindow(hit.value, offset, limit, maxBytes);
  return okResult(
    resolved,
    pathText,
    clipped,
    arrayPointers(pathText, clipped.startIndex ?? offset, clipped.returned)
  );
};
var runWhere = (resolved, pointer, expr, options) => {
  const tokens = parseJsonPointer(pointer === void 0 ? "" : pointer);
  if (tokens === null) return fail("invalid-pointer", `JSON Pointer \u975E\u6CD5\uFF1A${String(pointer)}`);
  const hit = readPointer(resolved.value, tokens);
  const pathText = formatJsonPointer(tokens);
  if (!hit.found) return fail("pointer-not-found", `\u6307\u9488\u4E0D\u5B58\u5728\uFF1A${pathText || "/"}`);
  if (!Array.isArray(hit.value)) return fail("not-an-array", `where \u53EA\u80FD\u4F5C\u7528\u4E8E\u6570\u7EC4\uFF1A${pathText || "/"}`);
  const predicate = parseWherePredicate(expr);
  if (predicate === null) {
    return fail(
      "unsupported-predicate",
      "\u4E0D\u652F\u6301\u7684\u7B5B\u9009\u8868\u8FBE\u5F0F\uFF1A\u4EC5\u5141\u8BB8 field == value\u3001field != value\u3001contains(field, value)"
    );
  }
  const matches = [];
  hit.value.forEach((item, index) => {
    if (matchesPredicate(item, predicate)) matches.push({ index, value: item });
  });
  const maxBytes = normalizeMaxBytes(options.maxBytes);
  const offset = normalizeNonNegative(options.offset);
  const limit = options.limit === void 0 ? Number.POSITIVE_INFINITY : normalizeNonNegative(options.limit);
  const clipped = clipArrayWindow(
    matches.map((match) => match.value),
    offset,
    limit,
    maxBytes
  );
  const from = clipped.startIndex ?? Math.min(offset, matches.length);
  const pointers = [];
  for (let index = 0; index < clipped.returned; index += 1) {
    pointers.push(`${pathText}/${matches[from + index].index}`);
  }
  return okResult(resolved, pathText, clipped, pointers);
};
var runCount = (resolved, pointer, _options) => {
  const tokens = parseJsonPointer(pointer === void 0 ? "" : pointer);
  if (tokens === null) return fail("invalid-pointer", `JSON Pointer \u975E\u6CD5\uFF1A${String(pointer)}`);
  const hit = readPointer(resolved.value, tokens);
  const pathText = formatJsonPointer(tokens);
  if (!hit.found) return fail("pointer-not-found", `\u6307\u9488\u4E0D\u5B58\u5728\uFF1A${pathText || "/"}`);
  const target = hit.value;
  let countValue;
  if (Array.isArray(target)) countValue = target.length;
  else if (isPlainObject(target)) countValue = Object.keys(target).length;
  else if (typeof target === "string") countValue = target.length;
  else return fail("not-countable", `count \u53EA\u652F\u6301\u6570\u7EC4\u3001\u5BF9\u8C61\u4E0E\u5B57\u7B26\u4E32\uFF1A${pathText || "/"}`);
  return {
    ok: true,
    source: resolved.source,
    digest: resolved.digest,
    path: pathText,
    total: countValue,
    returned: 1,
    truncated: false,
    value: countValue
  };
};
var SCHEMA_OBJECT_KIND_SET = new Set(SCHEMA_OBJECT_KINDS);
var SCHEMA_DETAIL_SECTION_SET = new Set(SCHEMA_DETAIL_SECTIONS);
var STRUCTURE_SECTIONS = [
  "columns",
  "indexes",
  "constraints",
  "foreignKeys",
  "rawDdl"
];
var schemaFailure = (reason, message) => ({
  ok: false,
  reason,
  message
});
var isResolvedSourceFailure = (resolved) => resolved.ok === false;
var isDetailSectionsFailure = (result) => result.ok === false;
var normalizeSchemaLimit = (raw) => {
  if (raw === void 0) return { ok: true, value: Number.POSITIVE_INFINITY };
  const value = typeof raw === "number" ? raw : Number.NaN;
  if (!Number.isFinite(value) || value <= 0) return { ok: false };
  return { ok: true, value: Math.floor(value) };
};
var isNonBlankString = (value) => typeof value === "string" && value.trim().length > 0;
var asCodeSchema = (value) => {
  const invalid = (message) => ({
    ok: false,
    reason: "invalid-schema",
    message
  });
  if (!isPlainObject(value)) return invalid("code-schema \u5FC5\u987B\u662F\u5BF9\u8C61");
  const version = value.schemaVersion;
  if (version === void 0 || version === 1) {
    return invalid("code-schema \u662F\u5386\u53F2 v1\uFF08\u7F3A schemaVersion \u6216 schemaVersion:1\uFF09\uFF1A\u5FC5\u987B\u91CD\u65B0\u91C7\u96C6");
  }
  if (version === 2) {
    return invalid(
      "code-schema \u662F legacy-v2\uFF08objectId \u5F62\u6001\uFF09\uFF1A\u666E\u901A\u67E5\u8BE2\u4E0D\u5C31\u5730\u517C\u5BB9\uFF0C\u8BF7\u5148\u7ECF\u96C6\u4E2D\u8FC1\u79FB\u5668\u5347\u7EA7\u5230 v3 \u540E\u518D\u67E5\u8BE2"
    );
  }
  if (version !== 3) {
    return invalid(`\u672A\u77E5 code-schema \u7248\u672C\uFF1A${String(version)}\uFF1B\u5F53\u524D\u53EA\u63A5\u53D7 schemaVersion:3`);
  }
  if (Object.prototype.hasOwnProperty.call(value, "tables")) {
    return invalid("code-schema v3 \u4E0D\u5F97\u6DF7\u5165 v1 \u9876\u5C42 tables");
  }
  if (!Array.isArray(value.sources)) return invalid("code-schema v3 \u7F3A\u5C11 sources[] \u6570\u7EC4");
  const seenSources = /* @__PURE__ */ new Set();
  const seenRefs = /* @__PURE__ */ new Set();
  for (const source of value.sources) {
    if (!isPlainObject(source)) return invalid("sources[] \u5FC5\u987B\u662F\u5BF9\u8C61");
    if (!isNonBlankString(source.sourceId)) {
      return invalid("sources[].sourceId \u5FC5\u987B\u662F\u975E\u7A7A\u3001\u975E\u7EAF\u7A7A\u767D\u5B57\u7B26\u4E32");
    }
    if (seenSources.has(source.sourceId)) {
      return invalid(`sources[] \u51FA\u73B0\u91CD\u590D sourceId\uFF1A${source.sourceId}`);
    }
    seenSources.add(source.sourceId);
    if (typeof source.databaseType !== "string") return invalid("sources[].databaseType \u5FC5\u987B\u662F\u5B57\u7B26\u4E32");
    if (typeof source.dialect !== "string" || !["mysql", "oracle", "postgresql", "unknown"].includes(source.dialect)) {
      return invalid("sources[].dialect \u5FC5\u987B\u662F mysql/oracle/postgresql/unknown \u4E4B\u4E00");
    }
    if (source.channel !== "mcp") {
      return invalid('code-schema v3 \u7684 sources[].channel \u5FC5\u987B\u662F "mcp"\uFF1Blocal \u57FA\u7EBF\u5FC5\u987B\u5148\u91CD\u65B0\u91C7\u96C6');
    }
    if (!isPlainObject(source.completeness)) return invalid("sources[].completeness \u5FC5\u987B\u662F\u5BF9\u8C61");
    const completeness = source.completeness;
    if (completeness.status !== "complete" && completeness.status !== "partial" && completeness.status !== "failed") {
      return invalid("sources[].completeness.status \u5FC5\u987B\u662F complete/partial/failed");
    }
    if (!Array.isArray(completeness.missingPermissions) || !Array.isArray(completeness.evidenceRefs)) {
      return invalid("sources[].completeness \u7F3A\u5C11 missingPermissions/evidenceRefs \u6570\u7EC4");
    }
    if (typeof completeness.catalogReturned !== "number" || typeof completeness.objectsParsed !== "number") {
      return invalid("sources[].completeness \u7684 catalogReturned/objectsParsed \u5FC5\u987B\u662F\u6570\u5B57");
    }
    if (typeof completeness.truncated !== "boolean") {
      return invalid("sources[].completeness.truncated \u5FC5\u987B\u662F\u5E03\u5C14\u503C");
    }
    if (!Array.isArray(source.objects)) return invalid("sources[].objects \u5FC5\u987B\u662F\u6570\u7EC4");
    for (const object of source.objects) {
      if (!isPlainObject(object)) return invalid("sources[].objects[] \u5FC5\u987B\u662F\u5BF9\u8C61");
      if (Object.prototype.hasOwnProperty.call(object, "objectId")) {
        return invalid("code-schema v3 \u4E0D\u5F97\u643A\u5E26 objectId\uFF08\u534A\u8FC1\u79FB\u4EA7\u7269\uFF09\uFF1B\u8BF7\u5148\u5B8C\u6210\u8FC1\u79FB");
      }
      if (!isNonBlankString(object.name)) {
        return invalid("sources[].objects[].name \u5FC5\u987B\u662F\u975E\u7A7A\u3001\u975E\u7EAF\u7A7A\u767D\u5B57\u7B26\u4E32");
      }
      if (object.owner !== null && !isNonBlankString(object.owner)) {
        return invalid("sources[].objects[].owner \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6216\u663E\u5F0F null\uFF0C\u4E14\u4E0D\u5F97\u4E3A\u7A7A/\u7EAF\u7A7A\u767D");
      }
      if (!isPlainObject(object.quoted)) return invalid("sources[].objects[].quoted \u5FC5\u987B\u662F\u5BF9\u8C61");
      if (typeof object.quoted.name !== "boolean" || typeof object.quoted.owner !== "boolean") {
        return invalid("sources[].objects[].quoted.name/owner \u5FC5\u987B\u662F\u5E03\u5C14\u503C");
      }
      if (typeof object.kind !== "string" || !SCHEMA_OBJECT_KIND_SET.has(object.kind)) {
        return invalid("sources[].objects[].kind \u5FC5\u987B\u662F table/view/sequence/other \u4E4B\u4E00");
      }
      const refKey = JSON.stringify([source.sourceId, object.owner, object.kind, object.name]);
      if (seenRefs.has(refKey)) {
        return invalid(
          `\u540C\u4E00 source \u5185\u5BF9\u8C61\u5F15\u7528\u91CD\u590D\uFF08sourceId/owner/kind/name \u5B8C\u5168\u76F8\u540C\uFF09\uFF1A${source.sourceId} ${String(object.owner)}.${object.name}\uFF1B\u8BF7\u5148\u4FEE\u590D\u57FA\u7EBF\uFF0C\u4E0D\u5F97\u4EFB\u9009\u5176\u4E00`
        );
      }
      seenRefs.add(refKey);
      if (typeof object.rawDdl !== "string") return invalid("sources[].objects[].rawDdl \u5FC5\u987B\u662F\u5B57\u7B26\u4E32");
      if (!Array.isArray(object.columns)) return invalid("sources[].objects[].columns \u5FC5\u987B\u662F\u6570\u7EC4");
      for (const column of object.columns) {
        if (!isPlainObject(column) || typeof column.name !== "string" || typeof column.ddl !== "string") {
          return invalid("sources[].objects[].columns[] \u5FC5\u987B\u542B\u5B57\u7B26\u4E32 name/ddl");
        }
      }
      for (const key of ["indexes", "constraints", "foreignKeys", "parseIssues"]) {
        const entries = object[key];
        if (!Array.isArray(entries) || entries.some((entry) => typeof entry !== "string")) {
          return invalid(`sources[].objects[].${key} \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6570\u7EC4`);
        }
      }
      if (!isPlainObject(object.comments)) return invalid("sources[].objects[].comments \u5FC5\u987B\u662F\u5BF9\u8C61");
      const comments = object.comments;
      if (comments.table !== null && typeof comments.table !== "string") {
        return invalid("sources[].objects[].comments.table \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6216 null");
      }
      if (!isPlainObject(comments.columns)) return invalid("sources[].objects[].comments.columns \u5FC5\u987B\u662F\u5BF9\u8C61");
      if (Object.values(comments.columns).some((entry) => typeof entry !== "string")) {
        return invalid("sources[].objects[].comments.columns \u7684\u503C\u5FC5\u987B\u662F\u5B57\u7B26\u4E32");
      }
      if (object.tableOptions !== null && typeof object.tableOptions !== "string") {
        return invalid("sources[].objects[].tableOptions \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6216 null");
      }
      if (typeof object.diffable !== "boolean") return invalid("sources[].objects[].diffable \u5FC5\u987B\u662F\u5E03\u5C14\u503C");
      if (object.basis !== void 0 && object.basis !== "code" && object.basis !== "db-only" && object.basis !== "catalog") {
        return invalid("sources[].objects[].basis \u5FC5\u987B\u662F code/db-only/catalog \u4E4B\u4E00");
      }
    }
  }
  return { ok: true, schema: value };
};
var effectiveBasis = (object) => object.basis ?? "code";
var baselineCompleteOf = (object) => !isIdentityOnlyObject(object) && object.diffable !== false && Array.isArray(object.columns) && object.columns.length > 0;
var pageArrayVerbatim = (items, start, limit, maxBytes) => {
  const total = items.length;
  const from = Math.min(Math.max(start, 0), total);
  if (from >= total) return { value: [], total, returned: 0, truncated: false };
  const cap = Math.min(total, from + (Number.isFinite(limit) ? Math.max(Math.floor(limit), 0) : total));
  const picked = [];
  let used = 2;
  let overBudget = false;
  for (let index = from; index < cap; index += 1) {
    const item = items[index];
    const cost = jsonByteLength(item) + (picked.length > 0 ? 1 : 0);
    if (picked.length > 0 && used + cost > maxBytes) break;
    if (picked.length === 0 && used + cost > maxBytes) {
      picked.push(item);
      used += cost;
      overBudget = true;
      break;
    }
    picked.push(item);
    used += cost;
  }
  const consumed = from + picked.length;
  const truncated = consumed < total;
  const page = { value: picked, total, returned: picked.length, truncated };
  if (truncated) page.nextOffset = consumed;
  if (overBudget) page.overBudget = true;
  return page;
};
var pageStringVerbatim = (text, start, maxBytes) => {
  const total = text.length;
  const from = Math.min(Math.max(start, 0), total);
  const rest = text.slice(from);
  if (jsonByteLength(rest) <= maxBytes) {
    return { value: rest, total, returned: rest.length, truncated: false };
  }
  let low = 1;
  let high = rest.length;
  while (low < high) {
    const mid = Math.ceil((low + high) / 2);
    if (jsonByteLength(rest.slice(0, mid)) <= maxBytes) low = mid;
    else high = mid - 1;
  }
  const picked = rest.slice(0, Math.max(low, 1));
  const consumed = from + picked.length;
  const truncated = consumed < total;
  const page = {
    value: picked,
    total,
    returned: picked.length,
    truncated
  };
  if (truncated) page.nextOffset = consumed;
  if (jsonByteLength(picked) > maxBytes) page.overBudget = true;
  return page;
};
var pageCommentsVerbatim = (comments, start, limit, maxBytes) => {
  const table = comments.table ?? null;
  const columnEntries = Object.entries(comments.columns);
  const page = pageArrayVerbatim(columnEntries, start, limit, maxBytes);
  const value = {
    table,
    columns: Object.fromEntries(page.value),
    columnsTotal: page.total,
    columnsReturned: page.returned,
    columnsTruncated: page.truncated
  };
  if (page.nextOffset !== void 0) value.columnsNextOffset = page.nextOffset;
  const result = {
    value,
    total: page.total,
    returned: page.returned,
    truncated: page.truncated
  };
  if (page.nextOffset !== void 0) result.nextOffset = page.nextOffset;
  if (page.overBudget || table !== null && jsonByteLength(table) > maxBytes) result.overBudget = true;
  return result;
};
var buildSchemaSectionPage = (section, object, offset, limit, maxBytes) => {
  switch (section) {
    case "columns":
      return pageArrayVerbatim(object.columns, offset, limit, maxBytes);
    case "indexes":
      return pageArrayVerbatim(object.indexes, offset, limit, maxBytes);
    case "constraints":
      return pageArrayVerbatim(object.constraints, offset, limit, maxBytes);
    case "foreignKeys":
      return pageArrayVerbatim(object.foreignKeys, offset, limit, maxBytes);
    case "rawDdl":
      return pageStringVerbatim(object.rawDdl, offset, maxBytes);
    case "comments":
      return pageCommentsVerbatim(object.comments, offset, limit, maxBytes);
    case "tableOptions":
      if (object.tableOptions === null) {
        return { value: null, total: 0, returned: 0, truncated: false };
      }
      return pageStringVerbatim(object.tableOptions, offset, maxBytes);
    case "parseIssues":
      return pageArrayVerbatim(object.parseIssues, offset, limit, maxBytes);
    default:
      return { value: null, total: 0, returned: 0, truncated: false };
  }
};
var normalizeDetailSections = (raw) => {
  if (raw === void 0) return { ok: true, value: [] };
  if (!Array.isArray(raw)) return { ok: false, message: "sections \u5FC5\u987B\u662F\u6570\u7EC4" };
  const value = [];
  for (const item of raw) {
    if (typeof item !== "string" || !SCHEMA_DETAIL_SECTION_SET.has(item)) {
      return {
        ok: false,
        message: `\u672A\u77E5 section\uFF1A${String(item)}\uFF1B\u5141\u8BB8\uFF1A${SCHEMA_DETAIL_SECTIONS.join(", ")}`
      };
    }
    if (!value.includes(item)) value.push(item);
  }
  return { ok: true, value };
};
var summary = (source, options = {}) => {
  const resolved = resolveContractSource(source);
  if (!resolved.ok) return resolved;
  return runSummary(resolved, options);
};
var get = (source, pointer = "", options = {}) => {
  const resolved = resolveContractSource(source);
  if (!resolved.ok) return resolved;
  return runGet(resolved, pointer, options);
};
var select = (source, pointer = "", options = {}) => {
  const resolved = resolveContractSource(source);
  if (!resolved.ok) return resolved;
  return runSelect(resolved, pointer, options);
};
var where = (source, pointer = "", expr = "", options = {}) => {
  const resolved = resolveContractSource(source);
  if (!resolved.ok) return resolved;
  return runWhere(resolved, pointer, expr, options);
};
var count = (source, pointer = "", options = {}) => {
  const resolved = resolveContractSource(source);
  if (!resolved.ok) return resolved;
  return runCount(resolved, pointer, options);
};
var batch = (source, queries, options = {}) => {
  const resolved = resolveContractSource(source);
  if (!resolved.ok) return resolved;
  if (!Array.isArray(queries)) {
    return fail("invalid-request", "batch \u7684 queries \u5FC5\u987B\u662F\u6570\u7EC4");
  }
  const results = queries.map((query) => {
    try {
      if (!query || typeof query !== "object") {
        return fail("invalid-request", "\u67E5\u8BE2\u9879\u5FC5\u987B\u662F\u5BF9\u8C61");
      }
      const merged = {
        maxBytes: query.maxBytes ?? options.maxBytes,
        offset: query.offset ?? options.offset,
        limit: query.limit ?? options.limit
      };
      switch (query.op) {
        case "summary":
          return runSummary(resolved, merged);
        case "get":
          return runGet(resolved, query.path, merged);
        case "select":
          return runSelect(resolved, query.path, merged);
        case "where":
          return runWhere(resolved, query.path, query.expr, merged);
        case "count":
          return runCount(resolved, query.path, merged);
        default:
          return fail("unknown-op", `\u672A\u77E5\u67E5\u8BE2\u5B50\u547D\u4EE4\uFF1A${String(query.op)}`);
      }
    } catch (error) {
      return fail("invalid-request", `\u67E5\u8BE2\u6267\u884C\u5931\u8D25\uFF1A${error instanceof Error ? error.message : String(error)}`);
    }
  });
  return {
    ok: true,
    source: resolved.source,
    digest: resolved.digest,
    path: "",
    total: queries.length,
    returned: results.length,
    truncated: false,
    value: results
  };
};
var schemaList = (source, query = {}) => {
  const resolved = resolveContractSource(source);
  if (isResolvedSourceFailure(resolved)) {
    return schemaFailure(resolved.reason, resolved.message);
  }
  const resolution = asCodeSchema(resolved.value);
  if ("reason" in resolution) {
    return schemaFailure(resolution.reason, resolution.message);
  }
  const schema = resolution.schema;
  if (!query || typeof query !== "object") {
    return schemaFailure("invalid-request", "\u67E5\u8BE2\u53C2\u6570\u5FC5\u987B\u662F\u5BF9\u8C61");
  }
  if (query.sourceId !== void 0 && typeof query.sourceId !== "string") {
    return schemaFailure("invalid-request", "sourceId \u5FC5\u987B\u662F\u5B57\u7B26\u4E32");
  }
  if (query.kind !== void 0 && !SCHEMA_OBJECT_KIND_SET.has(query.kind)) {
    return schemaFailure(
      "invalid-request",
      `\u672A\u77E5 kind\uFF1A${String(query.kind)}\uFF1B\u5141\u8BB8\uFF1A${SCHEMA_OBJECT_KINDS.join(", ")}`
    );
  }
  if (query.name !== void 0 && typeof query.name !== "string") {
    return schemaFailure("invalid-request", "name \u5FC5\u987B\u662F\u5B57\u7B26\u4E32");
  }
  const limit = normalizeSchemaLimit(query.limit);
  if (!limit.ok) return schemaFailure("invalid-request", "limit \u5FC5\u987B\u662F\u6B63\u6574\u6570");
  const offset = normalizeNonNegative(query.offset);
  const maxBytes = normalizeMaxBytes(query.maxBytes);
  if (query.sourceId !== void 0 && !schema.sources.some((entry) => entry.sourceId === query.sourceId)) {
    return schemaFailure("source-not-found", `code-schema \u4E2D\u4E0D\u5B58\u5728 sourceId\uFF1A${query.sourceId}`);
  }
  const entries = [];
  for (const schemaSource of schema.sources) {
    if (query.sourceId !== void 0 && schemaSource.sourceId !== query.sourceId) continue;
    for (const object of schemaSource.objects) {
      if (query.kind !== void 0 && object.kind !== query.kind) continue;
      if (query.name !== void 0 && object.name !== query.name) continue;
      entries.push({
        sourceId: schemaSource.sourceId,
        owner: object.owner,
        kind: object.kind,
        name: object.name,
        tableComment: object.comments?.table ?? null,
        basis: effectiveBasis(object)
      });
    }
  }
  const page = pageArrayVerbatim(entries, offset, limit.value, maxBytes);
  const result = {
    ok: true,
    source: resolved.source,
    digest: resolved.digest,
    path: "",
    total: page.total,
    returned: page.returned,
    truncated: page.truncated,
    value: { entries: page.value },
    sources: schema.sources.map((entry) => ({
      sourceId: entry.sourceId,
      databaseType: entry.databaseType,
      dialect: entry.dialect,
      status: entry.completeness.status,
      objects: entry.objects.length
    }))
  };
  if (page.nextOffset !== void 0) result.nextOffset = page.nextOffset;
  if (page.overBudget) result.overBudget = true;
  return result;
};
var normalizeObjectRef = (raw) => {
  const failRef = (message) => ({
    ok: false,
    reason: "invalid-object-ref",
    message
  });
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) {
    return failRef(
      "objectRef \u5FC5\u987B\u662F {sourceId, owner, kind, name} \u7ED3\u6784\u5316\u5BF9\u8C61\uFF1Bowner \u65E0\u503C\u5FC5\u987B\u663E\u5F0F\u5199 null\u3002\u6062\u590D\uFF1A\u7531\u7A0B\u5E8F\u6309\u5DF2\u786E\u8BA4 source \u7EC4\u88C5\u5F15\u7528\uFF0C\u4E0D\u8981\u8BA9 agent \u624B\u586B\u8BA1\u7B97\u503C\u3002"
    );
  }
  const candidate = raw;
  if (!isNonBlankString(candidate.sourceId)) {
    return failRef("objectRef.sourceId \u5FC5\u987B\u662F\u975E\u7A7A\u3001\u975E\u7EAF\u7A7A\u767D\u5B57\u7B26\u4E32\uFF08\u539F\u6837\u53D6\u81EA schema-list \u76EE\u5F55\u884C\uFF09");
  }
  if (candidate.owner !== null && !isNonBlankString(candidate.owner)) {
    return failRef(
      "objectRef.owner \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6216\u663E\u5F0F null\uFF08\u65E0\u503C\u5199 null\uFF0C\u4E0D\u5F97\u7701\u7565\u3001\u7A7A\u4E32\u6216\u7EAF\u7A7A\u767D\uFF09"
    );
  }
  if (typeof candidate.kind !== "string" || !SCHEMA_OBJECT_KIND_SET.has(candidate.kind)) {
    return failRef(`objectRef.kind \u5FC5\u987B\u662F ${SCHEMA_OBJECT_KINDS.join("/")} \u4E4B\u4E00\uFF1A${String(candidate.kind)}`);
  }
  if (!isNonBlankString(candidate.name)) {
    return failRef(
      "objectRef.name \u5FC5\u987B\u662F\u975E\u7A7A\u3001\u975E\u7EAF\u7A7A\u767D\u5B57\u7B26\u4E32\uFF08\u6570\u636E\u5E93\u76EE\u5F55\u540D\uFF0C\u4E0D\u662F\u5E26\u5F15\u53F7\u7684 SQL \u6587\u672C\uFF09"
    );
  }
  return {
    ok: true,
    ref: {
      sourceId: candidate.sourceId,
      owner: candidate.owner,
      kind: candidate.kind,
      name: candidate.name
    }
  };
};
var schemaDetail = (source, query) => {
  const resolved = resolveContractSource(source);
  if (isResolvedSourceFailure(resolved)) {
    return schemaFailure(resolved.reason, resolved.message);
  }
  const resolution = asCodeSchema(resolved.value);
  if ("reason" in resolution) {
    return schemaFailure(resolution.reason, resolution.message);
  }
  const schema = resolution.schema;
  if (!query || typeof query !== "object") {
    return schemaFailure("invalid-request", "\u67E5\u8BE2\u53C2\u6570\u5FC5\u987B\u662F\u5BF9\u8C61");
  }
  const normalizedRef = normalizeObjectRef(query.objectRef);
  if ("reason" in normalizedRef) {
    return schemaFailure(normalizedRef.reason, normalizedRef.message);
  }
  const ref = normalizedRef.ref;
  const sections = normalizeDetailSections(query.sections);
  if (isDetailSectionsFailure(sections)) {
    return schemaFailure("invalid-request", sections.message);
  }
  const limit = normalizeSchemaLimit(query.limit);
  if (!limit.ok) return schemaFailure("invalid-request", "limit \u5FC5\u987B\u662F\u6B63\u6574\u6570");
  const offset = normalizeNonNegative(query.offset);
  const maxBytes = normalizeMaxBytes(query.maxBytes);
  const schemaSource = schema.sources.find((entry) => entry.sourceId === ref.sourceId);
  if (schemaSource === void 0) {
    return schemaFailure("source-not-found", `code-schema \u4E2D\u4E0D\u5B58\u5728 sourceId\uFF1A${ref.sourceId}`);
  }
  const matches = schemaSource.objects.filter(
    (entry) => entry.owner === ref.owner && entry.kind === ref.kind && entry.name === ref.name
  );
  if (matches.length === 0) {
    const ownerText = ref.owner === null ? "null" : ref.owner;
    return schemaFailure(
      "object-not-found",
      `source ${ref.sourceId} \u4E2D\u4E0D\u5B58\u5728 objectRef\uFF1Aowner=${ownerText}\u3001kind=${ref.kind}\u3001name=${ref.name}\uFF1B\u56DB\u5B57\u6BB5\u5FC5\u987B\u4E0E schema-list \u76EE\u5F55\u9010\u5B57\u4E00\u81F4\uFF08\u5927\u5C0F\u5199\u3001\u5F15\u53F7\u3001\u70B9\u53F7\u90FD\u5C5E\u4E8E\u540D\u5B57\u7684\u4E00\u90E8\u5206\uFF09\uFF0C\u4E0D\u5F97\u6309\u88F8\u8868\u540D\u6216\u6A21\u7CCA\u5339\u914D\u515C\u5E95`
    );
  }
  if (matches.length > 1) {
    return schemaFailure(
      "ambiguous-object-ref",
      `objectRef \u5728 source ${ref.sourceId} \u5185\u547D\u4E2D ${matches.length} \u4E2A\u5BF9\u8C61\uFF08owner=${ref.owner === null ? "null" : ref.owner}\u3001kind=${ref.kind}\u3001name=${ref.name}\uFF09\uFF1A\u5148\u4FEE\u590D\u57FA\u7EBF\u91CD\u590D\u5F15\u7528\uFF0C\u4E0D\u5F97\u4EFB\u9009\u5176\u4E00`
    );
  }
  const object = matches[0];
  const requested = sections.value;
  const detailSections = {};
  const pendingSections = [];
  let remaining = maxBytes;
  let overBudget = false;
  for (let index = 0; index < requested.length; index += 1) {
    const section = requested[index];
    const share = Math.max(1, Math.floor(remaining / (requested.length - index)));
    const page = buildSchemaSectionPage(section, object, offset, limit.value, share);
    detailSections[section] = page;
    remaining = Math.max(1, remaining - jsonByteLength(page.value));
    if (page.truncated) pendingSections.push(section);
    if (page.overBudget) overBudget = true;
  }
  const identityOnly = isIdentityOnlyObject(object);
  const baselineComplete = baselineCompleteOf(object);
  const complete = pendingSections.length === 0;
  const structureComplete = baselineComplete && STRUCTURE_SECTIONS.every((section) => {
    const page = detailSections[section];
    return requested.includes(section) && page !== void 0 && page.truncated === false;
  });
  const firstPending = pendingSections[0];
  const firstPendingPage = firstPending === void 0 ? void 0 : detailSections[firstPending];
  const result = {
    ok: true,
    source: resolved.source,
    digest: resolved.digest,
    path: "",
    total: requested.length,
    returned: requested.length - pendingSections.length,
    truncated: !complete,
    sourceId: schemaSource.sourceId,
    objectRef: ref,
    identity: {
      sourceId: schemaSource.sourceId,
      owner: object.owner,
      kind: object.kind,
      name: object.name,
      quoted: { name: object.quoted.name, owner: object.quoted.owner },
      basis: effectiveBasis(object),
      diffable: object.diffable !== false,
      identityOnly
    },
    tableComment: object.comments?.table ?? null,
    completeness: schemaSource.completeness,
    sourceComplete: schemaSource.completeness.status === "complete",
    baselineComplete,
    complete,
    structureComplete,
    identityOnly,
    counts: {
      columns: object.columns.length,
      indexes: object.indexes.length,
      constraints: object.constraints.length,
      foreignKeys: object.foreignKeys.length,
      parseIssues: object.parseIssues.length,
      commentColumns: Object.keys(object.comments?.columns ?? {}).length,
      rawDdlBytes: Buffer.byteLength(object.rawDdl, "utf8")
    },
    sections: detailSections,
    pendingSections
  };
  if (firstPending !== void 0 && firstPendingPage?.nextOffset !== void 0) {
    result.next = { section: firstPending, offset: firstPendingPage.nextOffset };
  }
  if (overBudget) result.overBudget = true;
  return result;
};

// src/utils/customWaveAgent/speckit/config/shared/contract-query/cli.mts
var EXIT = { OK: 0, FAILURE: 1, USAGE: 2 };
var COMMON = {
  "--root": "root",
  "--file": "file",
  "--max-bytes": "maxBytes"
};
var SUBCOMMAND_SPECS = {
  summary: {
    values: { ...COMMON, "--offset": "offset" },
    required: ["file"],
    usage: "summary [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> [--max-bytes N] [--offset N]"
  },
  get: {
    values: { ...COMMON, "--path": "path", "--offset": "offset" },
    required: ["file"],
    usage: "get [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> [--path /a/b] [--max-bytes N] [--offset N]"
  },
  select: {
    values: { ...COMMON, "--path": "path", "--offset": "offset", "--limit": "limit" },
    required: ["file"],
    usage: "select [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> --path /items [--offset N] [--limit N] [--max-bytes N]"
  },
  where: {
    values: {
      ...COMMON,
      "--path": "path",
      "--expr": "expr",
      "--offset": "offset",
      "--limit": "limit"
    },
    required: ["file", "expr"],
    usage: `where [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> --path /items --expr "kind == 'x'" [--limit N] [--max-bytes N]`
  },
  count: {
    values: { ...COMMON, "--path": "path" },
    required: ["file"],
    usage: "count [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> [--path /a/b] [--max-bytes N]"
  },
  batch: {
    values: { ...COMMON, "--queries": "queries", "--max-bytes": "maxBytes" },
    required: ["file", "queries"],
    usage: "batch [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> --queries '<JSON \u6570\u7EC4>' [--max-bytes N]"
  },
  "schema-list": {
    values: {
      ...COMMON,
      "--source-id": "sourceId",
      "--kind": "kind",
      "--name": "name",
      "--offset": "offset",
      "--limit": "limit"
    },
    required: ["file"],
    usage: "schema-list [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> [--source-id <id>] [--kind table|view|sequence|other] [--name <\u539F\u540D>] [--offset N] [--limit N] [--max-bytes N]"
  },
  "schema-detail": {
    values: {
      ...COMMON,
      "--ref": "objectRef",
      "--sections": "sections",
      "--offset": "offset",
      "--limit": "limit"
    },
    required: ["file", "objectRef"],
    usage: `schema-detail [--root <\u5DE5\u4F5C\u533A\u6839>] --file <\u8DEF\u5F84> --ref '<JSON: {"sourceId":"src-...","owner":null,"kind":"table","name":"users"}>' [--sections ${SCHEMA_DETAIL_SECTIONS.join(",")}] [--offset N] [--limit N] [--max-bytes N]`
  }
};
var usageResult = (reason, explicitRoot) => {
  const lines = Object.keys(SUBCOMMAND_SPECS).map(
    (name) => `  ${SUBCOMMAND_SPECS[name].usage}`
  );
  return {
    ok: false,
    reason: "usage",
    message: `\u53C2\u6570\u975E\u6CD5\uFF1A${reason}
\u7528\u6CD5\uFF1Acontract-query <${Object.keys(SUBCOMMAND_SPECS).join("|")}> [flags]
${lines.join("\n")}
${rootDiagnostic(explicitRoot)}`
  };
};
var usageOutcome = (reason, explicitRoot) => ({
  exitCode: EXIT.USAGE,
  result: usageResult(reason, explicitRoot)
});
var WORKSPACE_ROOT_MARKERS = [".specify", "plans"];
var EXAMPLE_FILE = "plans/backend/_meta/architecture.json";
var isDirectory = (candidate) => {
  try {
    return statSync(candidate).isDirectory();
  } catch {
    return false;
  }
};
var detectWorkspaceRoot = (start) => {
  const tried = [];
  let current = path2.resolve(start);
  for (; ; ) {
    tried.push(current);
    if (WORKSPACE_ROOT_MARKERS.some((marker) => isDirectory(path2.join(current, marker)))) {
      return { root: current, tried };
    }
    const parent = path2.dirname(current);
    if (parent === current) return { tried };
    current = parent;
  }
};
var rootDiagnostic = (explicitRoot) => {
  if (explicitRoot !== void 0) {
    const resolved = path2.resolve(explicitRoot);
    return `--root \u5DF2\u89E3\u6790\u5230\uFF1A${resolved}
\u53EF\u7528\u793A\u4F8B\uFF1Anode .specify/scripts/javascript/contract-query-tool.mjs summary --root ${resolved} --file ${EXAMPLE_FILE}`;
  }
  const cwd = path2.resolve(process.cwd());
  const probe = detectWorkspaceRoot(cwd);
  if (probe.root !== void 0) {
    return `--root \u672A\u663E\u5F0F\u7ED9\u51FA\uFF0C\u5DF2\u4ECE ${cwd} \u5411\u4E0A\u89E3\u6790\u5230\uFF1A${probe.root}
\u53EF\u7528\u793A\u4F8B\uFF1Anode .specify/scripts/javascript/contract-query-tool.mjs summary --root ${probe.root} --file ${EXAMPLE_FILE}`;
  }
  return `--root \u672A\u663E\u5F0F\u7ED9\u51FA\u4E14\u89E3\u6790\u5931\u8D25\uFF1A\u4ECE ${cwd} \u5411\u4E0A\u672A\u627E\u5230\u542B ${WORKSPACE_ROOT_MARKERS.map((marker) => `${marker}/`).join(" \u6216 ")} \u7684\u76EE\u5F55\uFF08\u5DF2\u5C1D\u8BD5\uFF1A${probe.tried.join(" \u2192 ")}\uFF09`;
};
var canonicalize = (targetAbs) => {
  let current = targetAbs;
  const suffix = [];
  for (; ; ) {
    try {
      const real = realpathSync(current);
      return suffix.length === 0 ? real : path2.join(real, ...suffix);
    } catch {
      const parent = path2.dirname(current);
      if (parent === current) return targetAbs;
      suffix.unshift(path2.basename(current));
      current = parent;
    }
  }
};
var normalizeFile = (rootAbs, rawFile, cwd) => {
  if (rawFile.length === 0) {
    return { ok: false, reason: "path-not-allowed", message: "\u5951\u7EA6\u6587\u4EF6\u8DEF\u5F84\u4E0D\u80FD\u4E3A\u7A7A" };
  }
  if (rawFile.includes("\0")) {
    return { ok: false, reason: "path-not-allowed", message: "\u5951\u7EA6\u6587\u4EF6\u8DEF\u5F84\u542B\u7A7A\u5B57\u8282" };
  }
  if (/^[A-Za-z]:[\\/]/.test(rawFile) || rawFile.startsWith("\\\\")) {
    return {
      ok: false,
      reason: "path-not-allowed",
      message: `\u62D2\u7EDD Windows \u9A71\u52A8\u5668/UNC \u8DEF\u5F84\uFF1A\u53EA\u63A5\u53D7\u5DE5\u4F5C\u533A\u6839\u5185 ${CONTRACT_QUERY_ALLOWED_ROOTS.join("/ \u4E0E ")}/ \u8DEF\u5F84`
    };
  }
  const allowedRoot2 = (segment) => CONTRACT_QUERY_ALLOWED_ROOTS.includes(segment);
  const firstSegment2 = (value) => value.split(/[\\/]/).filter(Boolean)[0] ?? "";
  if (!path2.isAbsolute(rawFile) && allowedRoot2(firstSegment2(rawFile))) {
    return { ok: true, file: rawFile };
  }
  const targetAbs = path2.isAbsolute(rawFile) ? path2.resolve(rawFile) : path2.resolve(cwd, rawFile);
  const rootCanon = canonicalize(rootAbs);
  const targetCanon = canonicalize(targetAbs);
  const prefix = rootCanon.endsWith(path2.sep) ? rootCanon : `${rootCanon}${path2.sep}`;
  if (!targetCanon.startsWith(prefix)) {
    return { ok: false, reason: "path-not-allowed", message: `\u8DEF\u5F84\u8D8A\u51FA\u5DE5\u4F5C\u533A\u6839\uFF08\u4E0D\u5141\u8BB8 .. \u7A7F\u8D8A\uFF09\uFF1A${rawFile}` };
  }
  const relative = path2.relative(rootCanon, targetCanon);
  if (!allowedRoot2(firstSegment2(relative))) {
    return {
      ok: false,
      reason: "path-not-allowed",
      message: `\u8DEF\u5F84\u4E0D\u5728\u767D\u540D\u5355\u5185\uFF1A\u53EA\u5141\u8BB8 ${CONTRACT_QUERY_ALLOWED_ROOTS.join("/ \u4E0E ")}/ \u5B50\u6811\uFF08\u89E3\u6790\u7ED3\u679C\uFF1A${relative.split(path2.sep).join("/")}\uFF09`
    };
  }
  return { ok: true, file: relative.split(path2.sep).join("/") };
};
var normalizeContractRequest = (rawRoot, rawFile, cwd) => {
  if (rawRoot === void 0) {
    const probe = detectWorkspaceRoot(cwd);
    if (probe.root === void 0) {
      return {
        ok: false,
        reason: "root-not-found",
        message: `\u672A\u627E\u5230\u5DE5\u4F5C\u533A\u6839\uFF1A\u4ECE ${path2.resolve(cwd)} \u5411\u4E0A\u9010\u7EA7\u67E5\u627E\u542B ${WORKSPACE_ROOT_MARKERS.map((marker) => `${marker}/`).join(" \u6216 ")} \u7684\u76EE\u5F55\u5747\u672A\u547D\u4E2D\u3002\u5DF2\u5C1D\u8BD5\uFF1A
${probe.tried.join("\n")}
\u53EF\u7528 --root \u663E\u5F0F\u6307\u5B9A\u5DE5\u4F5C\u533A\u6839\u3002`
      };
    }
    const file2 = normalizeFile(probe.root, rawFile, cwd);
    if (file2.ok === false) return file2;
    return { ok: true, root: probe.root, file: file2.file };
  }
  const rootAbs = path2.resolve(rawRoot);
  const file = normalizeFile(rootAbs, rawFile, cwd);
  if (file.ok === false) return file;
  return { ok: true, root: rawRoot, file: file.file };
};
var parseFlags = (rest, subcommand) => {
  const spec = SUBCOMMAND_SPECS[subcommand];
  const values = {};
  for (let index = 0; index < rest.length; index += 1) {
    const arg = rest[index];
    let flag = arg;
    let inlineValue;
    const eq = arg.indexOf("=");
    if (arg.startsWith("--") && eq !== -1) {
      flag = arg.slice(0, eq);
      inlineValue = arg.slice(eq + 1);
    }
    const valueKey = Object.prototype.hasOwnProperty.call(spec.values, flag) ? spec.values[flag] : void 0;
    if (valueKey === void 0) {
      return {
        ok: false,
        values,
        reason: `\u672A\u77E5\u6216\u8D8A\u6743 flag\uFF1A${arg}\uFF08${subcommand} \u7684\u5141\u8BB8\u96C6\uFF1A${Object.keys(spec.values).join(" ") || "(\u65E0)"}\uFF09`
      };
    }
    if (inlineValue !== void 0) {
      values[valueKey] = inlineValue;
      continue;
    }
    if (index + 1 >= rest.length) return { ok: false, values, reason: `flag \u7F3A\u503C\uFF1A${arg}` };
    values[valueKey] = rest[index += 1];
  }
  for (const key of spec.required) {
    if (values[key] === void 0) {
      const flag = Object.keys(spec.values).find((candidate) => spec.values[candidate] === key) ?? key;
      return {
        ok: false,
        values,
        reason: `\u7F3A\u5C11\u5FC5\u586B flag\uFF1A${flag}\uFF08${subcommand} \u7684\u7528\u6CD5\uFF1A${spec.usage}\uFF09`
      };
    }
  }
  return { ok: true, values };
};
var parseIntegerFlag = (raw, flag) => {
  if (raw === void 0) return { ok: true, value: void 0 };
  const text = String(raw).trim();
  if (!/^-?\d+$/.test(text)) {
    return { ok: false, reason: `${flag} \u5FC5\u987B\u662F\u6574\u6570\uFF1A${raw}` };
  }
  const value = Number(text);
  if (!Number.isSafeInteger(value) || value < 0) {
    return { ok: false, reason: `${flag} \u5FC5\u987B\u662F\u975E\u8D1F\u6574\u6570\uFF1A${raw}` };
  }
  return { ok: true, value };
};
var parseMaxBytes = (raw) => {
  if (raw === void 0) return { ok: true, value: void 0 };
  const text = String(raw).trim();
  if (!/^\d+$/.test(text)) return { ok: false, reason: `--max-bytes \u5FC5\u987B\u662F\u6B63\u6574\u6570\uFF1A${raw}` };
  const value = Number(text);
  if (!Number.isSafeInteger(value) || value <= 0) {
    return { ok: false, reason: `--max-bytes \u5FC5\u987B\u662F\u6B63\u6574\u6570\uFF1A${raw}` };
  }
  return { ok: true, value };
};
var runSubcommand = (subcommand, rest) => {
  const parsed = parseFlags(rest, subcommand);
  if (!parsed.ok) return usageOutcome(parsed.reason, parsed.values.root);
  const flags = parsed.values;
  const offset = parseIntegerFlag(flags.offset, "--offset");
  if (!offset.ok) return usageOutcome(offset.reason, flags.root);
  const limit = parseIntegerFlag(flags.limit, "--limit");
  if (!limit.ok) return usageOutcome(limit.reason, flags.root);
  const maxBytes = parseMaxBytes(flags.maxBytes);
  if (!maxBytes.ok) return usageOutcome(maxBytes.reason, flags.root);
  if ((subcommand === "schema-list" || subcommand === "schema-detail") && limit.value !== void 0 && limit.value < 1) {
    return usageOutcome("--limit \u5FC5\u987B\u4E3A\u6B63\u6574\u6570\uFF08schema-* \u5B50\u547D\u4EE4\u4E0D\u63A5\u53D7 0\uFF09", flags.root);
  }
  if (subcommand === "schema-list" && flags.kind !== void 0 && !SCHEMA_OBJECT_KINDS.includes(flags.kind)) {
    return usageOutcome(
      `--kind \u5FC5\u987B\u662F ${SCHEMA_OBJECT_KINDS.join("/")} \u4E4B\u4E00\uFF1A${flags.kind}`,
      flags.root
    );
  }
  let requestedSections;
  if (subcommand === "schema-detail" && flags.sections !== void 0) {
    const parts = flags.sections.split(",").map((part) => part.trim()).filter((part) => part.length > 0);
    if (parts.length === 0) return usageOutcome("--sections \u4E0D\u80FD\u4E3A\u7A7A", flags.root);
    const invalid = parts.find((part) => !SCHEMA_DETAIL_SECTIONS.includes(part));
    if (invalid !== void 0) {
      return usageOutcome(
        `--sections \u542B\u672A\u77E5 section\uFF1A${invalid}\uFF08\u5141\u8BB8\uFF1A${SCHEMA_DETAIL_SECTIONS.join(",")}\uFF09`,
        flags.root
      );
    }
    requestedSections = Array.from(new Set(parts));
  }
  let objectRef;
  if (subcommand === "schema-detail") {
    const raw = flags.objectRef;
    try {
      objectRef = JSON.parse(raw);
    } catch {
      return usageOutcome(
        `--ref \u5FC5\u987B\u662F\u5408\u6CD5 JSON \u5BF9\u8C61\uFF0C\u4F8B\u5982 --ref '{"sourceId":"src-...","owner":null,"kind":"table","name":"users"}'\uFF1A${raw}`,
        flags.root
      );
    }
    if (objectRef === null || typeof objectRef !== "object" || Array.isArray(objectRef)) {
      return usageOutcome(
        "--ref \u5FC5\u987B\u662F JSON \u5BF9\u8C61 {sourceId, owner, kind, name}\uFF08\u4E0D\u662F\u6570\u7EC4\u6216\u5B57\u9762\u91CF\uFF09\uFF1Bowner \u65E0\u503C\u5199 null",
        flags.root
      );
    }
  }
  const options = {
    offset: offset.value,
    limit: limit.value,
    maxBytes: maxBytes.value
  };
  const normalized = normalizeContractRequest(flags.root, flags.file, process.cwd());
  if (normalized.ok === false) {
    return {
      exitCode: EXIT.FAILURE,
      result: { ok: false, reason: normalized.reason, message: normalized.message }
    };
  }
  const source = { root: normalized.root, file: normalized.file };
  let result;
  switch (subcommand) {
    case "summary":
      result = summary(source, options);
      break;
    case "get":
      result = get(source, flags.path, options);
      break;
    case "select":
      result = select(source, flags.path, options);
      break;
    case "where":
      result = where(source, flags.path, flags.expr, options);
      break;
    case "count":
      result = count(source, flags.path, options);
      break;
    case "batch": {
      let queries;
      let queriesParsed = true;
      try {
        queries = JSON.parse(flags.queries);
      } catch {
        queriesParsed = false;
      }
      if (!queriesParsed) {
        const probe = batch(source, []);
        if (!probe.ok) return { exitCode: EXIT.FAILURE, result: probe };
        return usageOutcome("--queries \u5FC5\u987B\u662F\u5408\u6CD5 JSON \u6570\u7EC4");
      }
      result = batch(source, queries, options);
      break;
    }
    case "schema-list": {
      const query = {
        sourceId: flags.sourceId,
        kind: flags.kind,
        name: flags.name,
        offset: offset.value,
        limit: limit.value,
        maxBytes: maxBytes.value
      };
      result = schemaList(source, query);
      break;
    }
    case "schema-detail": {
      const query = {
        objectRef,
        sections: requestedSections,
        offset: offset.value,
        limit: limit.value,
        maxBytes: maxBytes.value
      };
      result = schemaDetail(source, query);
      break;
    }
  }
  return { exitCode: result.ok ? EXIT.OK : EXIT.FAILURE, result };
};
var emit = (payload) => {
  process.stdout.write(`${JSON.stringify(payload)}
`);
};
var SUBCOMMANDS = {
  summary: (rest) => runSubcommand("summary", rest),
  get: (rest) => runSubcommand("get", rest),
  select: (rest) => runSubcommand("select", rest),
  where: (rest) => runSubcommand("where", rest),
  count: (rest) => runSubcommand("count", rest),
  batch: (rest) => runSubcommand("batch", rest),
  "schema-list": (rest) => runSubcommand("schema-list", rest),
  "schema-detail": (rest) => runSubcommand("schema-detail", rest)
};
function main() {
  const [subcommand, ...rest] = process.argv.slice(2);
  const handler = subcommand !== void 0 && Object.prototype.hasOwnProperty.call(SUBCOMMANDS, subcommand) ? SUBCOMMANDS[subcommand] : void 0;
  if (handler === void 0) {
    const result = usageResult(subcommand === void 0 ? "\u7F3A\u5C11\u5B50\u547D\u4EE4" : `\u672A\u77E5\u5B50\u547D\u4EE4\uFF1A${subcommand}`);
    emit(result);
    process.exit(EXIT.USAGE);
  }
  let outcome;
  try {
    outcome = handler(rest);
  } catch (error) {
    outcome = {
      exitCode: EXIT.FAILURE,
      result: {
        ok: false,
        reason: "invalid-request",
        message: `contract-query \u6267\u884C\u5931\u8D25\uFF1A${error instanceof Error ? error.message : String(error)}`
      }
    };
  }
  emit(outcome.result);
  process.exit(outcome.exitCode);
}
function isInvokedAsEntry() {
  if (!process.argv[1]) return false;
  const plain = pathToFileURL(process.argv[1]).href;
  try {
    return import.meta.url === plain || import.meta.url === pathToFileURL(realpathSync(process.argv[1])).href;
  } catch {
    return import.meta.url === plain;
  }
}
if (isInvokedAsEntry()) {
  main();
}
export {
  SUBCOMMANDS
};
