// 职责：micro 归位 README 两张索引表（`## 模块清单` / `### 9.2 领域`）的**确定性渲染器**
// （plan 2026-10-24/stage5-repair-chain-convergence §2 D10 / §3.6 / §3.7；用户拍板 3D）。
//
// 为什么单列脚本：这两张表是**机器数据**，此前由归位 agent 手抄并反复自检（沙箱实测 230 次 bash /
// 117 处 failure 才收口）。机器数据禁经模型转录（知识节点 `machine-data-must-not-be-transcribed-by-model`）
// ⇒ 改为「TS 侧算 + 机器产物传 + 本脚本只格式化」。
//
// ⛔ **本脚本不判语言**：`modulePackage` 列的取值口径（Java ⇒ 字面包名；工程方案声明非 Java ⇒
//    canonical `moduleId`）由 TS 侧唯一谓词 `module-kind.ts#isJavaPackageJudged` 判定，波 5 派发计划步
//    把逐模块结果写进 `backend/_meta/module-index.json`。**禁**在本文件复制该谓词 / 语言归一
//    （集合差集双写必然分叉：`bff-node-module-must-not-carry-java-package-literal`）。
//    本脚本只做三件事：读产物 → 校验形状 → 格式化 Markdown。
//
// 唯一输入：`<spec>/plans/backend/_meta/module-index.json`（本脚本不读其它产物，也不读模块文档）。
// 输出形态：README 里的围栏块
//   <!-- AUTO:module-index:start -->
//   …两张表…
//   <!-- AUTO:module-index:end -->
//   · 围栏块在场 ⇒ **只替换块内内容**，块外正文逐字保留；
//   · 围栏块缺席 ⇒ 追加到 README 末尾（不触碰既有正文）；
//   · 同一输入两次运行输出逐字相同（无时间戳、无随机、行序 = 产物的 modules 数组序）。
//
// CLI（cwd = 工作区根）：
//   node .specify/scripts/javascript/render-module-index.mjs --workspace <本次 spec 目录>   # 就地写 README
//   node .specify/scripts/javascript/render-module-index.mjs --workspace <本次 spec 目录> --stdout  # 只打印围栏块
// 失败（输入缺席 / 形状违例 / 任一模块 `modulePackage` 不可用）⇒ stderr 说明 + exit 1（**不静默降级**）。

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

/** 机器产物落点（相对 `<spec>/plans/`；写者 = TS 侧波 5 派发计划步）。 */
export const MODULE_INDEX_REL = 'backend/_meta/module-index.json';
/** README 落点（相对 `<spec>/plans/`）。 */
export const MODULE_INDEX_README_REL = 'backend/README.md';

/** 围栏标记（逐字；checker 与本脚本共认这一对串）。 */
export const INDEX_BLOCK_START = '<!-- AUTO:module-index:start -->';
export const INDEX_BLOCK_END = '<!-- AUTO:module-index:end -->';

/** 两张表的表头（逐字）。`### 9.2 领域` 四列表头是下游 `parseDomainModuleMap` 的解析硬条件。 */
export const MODULE_TABLE_HEADER = '| 模块 id | role | 持久化与库绑定 | 文档链接 | 专家派发集 |';
export const DOMAIN_TABLE_HEADER = '| 领域标识 | 归并模块 | modulePackage | 目录 |';
/** `### 9.2 领域` 段头（逐字；编号是解析锚，禁改写）。 */
export const DOMAIN_TABLE_SECTION = '9.2 领域';

const MODULE_TABLE_DIVIDER = '| --- | --- | --- | --- | --- |';
const DOMAIN_TABLE_DIVIDER = '| --- | --- | --- | --- |';

/** 表格单元转义：值里的 `|` 不许打断列（当前产物不含，但格式化层不假设上游恒定）。 */
const cell = (value) => String(value ?? '').replace(/\|/g, '\\|').trim();

const isRecord = (value) => Boolean(value) && typeof value === 'object' && !Array.isArray(value);

/**
 * 读并校验机器产物（**形状违例 ⇒ failures，不猜**）。
 *
 * 校验面（每条都对应下游会静默出错的位置）：
 *   · `domainsResolved !== true` ⇒ `### 9.2 领域` 的「归并模块」列无真源（架构契约发布包不可读时，
 *     全表会被渲染成「无域」——那正是假绿）；
 *   · `gaps` 非空 / 任一模块 `modulePackage` 为空 ⇒ Java 判据面不可派生（波 2a 根包前缀缺席等）；
 *   · `modules` 为空 ⇒ 空表恒真式假绿（`shared-finder-form-coverage-is-a-separate-surface`）。
 */
export const validateModuleIndex = (raw) => {
  const failures = [];
  if (!isRecord(raw)) return { ok: false, artifact: null, failures: ['module-index.json 形状违例：顶层不是对象'] };
  if (raw.domainsResolved !== true) {
    failures.push(
      'module-index.json 的 `domainsResolved` 不是 true —— 架构契约发布包不可读 / 未投影，' +
        '`### 9.2 领域` 的「归并模块」列无真源（禁把它整表渲染成「无域」）。修复：重跑波 1 / 恢复发布包后重跑波 5 派发计划步。',
    );
  }
  for (const gap of Array.isArray(raw.gaps) ? raw.gaps : []) {
    failures.push(`module-index.json 记录了取数缺口：${String(gap)}`);
  }
  const modules = Array.isArray(raw.modules) ? raw.modules : [];
  if (modules.length === 0) {
    failures.push('module-index.json 的 `modules` 为空 —— 无行可渲染（空表恒真 = 盲区假绿），不写围栏块。');
  }
  modules.forEach((entry, index) => {
    if (!isRecord(entry)) {
      failures.push(`module-index.json modules[${index}] 形状违例：不是对象`);
      return;
    }
    for (const key of ['moduleId', 'roleAxis', 'docRel']) {
      if (typeof entry[key] !== 'string' || !entry[key].trim()) {
        failures.push(`module-index.json modules[${index}] 缺 \`${key}\`（空 / 非字符串）`);
      }
    }
    if (typeof entry.modulePackage !== 'string' || !entry.modulePackage.trim()) {
      failures.push(
        `模块 \`${String(entry.moduleId ?? `#${index}`)}\` 的 \`modulePackage\` 不可用（null / 空）——` +
          'Java 判据面不可派生（根包前缀决策缺席 / 非法）或产物被手改；禁在此处现造包名。',
      );
    }
    if (!Array.isArray(entry.ownedDomainIds)) {
      failures.push(`模块 \`${String(entry.moduleId ?? `#${index}`)}\` 的 \`ownedDomainIds\` 不是数组`);
    }
    if (!Array.isArray(entry.experts)) {
      failures.push(`模块 \`${String(entry.moduleId ?? `#${index}`)}\` 的 \`experts\` 不是数组`);
    }
  });
  return { ok: failures.length === 0, artifact: raw, failures };
};

/** 「持久化与库绑定」单元（真源 = `module-tech-facts.json` 的 `persistence`，经 TS 侧投影）。 */
const persistenceCell = (entry) => {
  if (entry.persistence !== true) return '不连库';
  const databaseType = typeof entry.databaseType === 'string' ? entry.databaseType.trim() : '';
  return databaseType ? `连库（${databaseType}）` : '连库';
};

/** 「专家派发集」单元：含被波 4 判 `full` 裁掉、直接继承的格（`（继承）` 后缀）。 */
const expertsCell = (entry) => {
  const experts = Array.isArray(entry.experts) ? entry.experts : [];
  const cells = experts
    .filter((expert) => isRecord(expert) && typeof expert.expertId === 'string' && expert.expertId)
    .map((expert) => (expert.dispatch === false ? `${expert.expertId}（继承）` : expert.expertId));
  return cells.length > 0 ? cells.join(' / ') : '—';
};

/** 「归并模块」单元：有效模块归属（`ownedDomainIds` 原样；view 归属不在投影里）；无 ⇒ 「无域」。 */
const domainsCell = (entry) => {
  const domains = (Array.isArray(entry.ownedDomainIds) ? entry.ownedDomainIds : []).filter(
    (domainId) => typeof domainId === 'string' && domainId.trim(),
  );
  return domains.length > 0 ? domains.join('、') : '无域';
};

/**
 * 渲染围栏块（纯函数；输入已校验）。行序 = `artifact.modules` 数组序（**不排序**：
 * 产物的序就是契约声明序，排序会让「两次运行逐字相同」这一断言失去意义）。
 */
export const renderModuleIndexBlock = (artifact) => {
  const lines = [
    INDEX_BLOCK_START,
    '## 模块清单',
    '',
    MODULE_TABLE_HEADER,
    MODULE_TABLE_DIVIDER,
    // 行首**不许**有空白：下游解析器按 `line.startsWith('|')` 认表行。
    ...artifact.modules.map(
      (entry) =>
        `| ${[
          cell(entry.moduleId),
          cell(entry.role || entry.roleAxis),
          cell(persistenceCell(entry)),
          cell(entry.docRel),
          cell(expertsCell(entry)),
        ].join(' | ')} |`,
    ),
    '',
    `### ${DOMAIN_TABLE_SECTION}`,
    '',
    DOMAIN_TABLE_HEADER,
    DOMAIN_TABLE_DIVIDER,
    ...artifact.modules.map(
      (entry) =>
        `| ${[
          cell(entry.moduleId),
          cell(domainsCell(entry)),
          cell(entry.modulePackage),
          cell(`modules/${entry.moduleId}`),
        ].join(' | ')} |`,
    ),
    INDEX_BLOCK_END,
  ];
  return lines.join('\n');
};

/** 从 README 正文里取围栏块（含两枚标记）；缺席 / 多义 ⇒ `{present:false}` / 抛错由调用方判。 */
export const extractIndexBlock = (readme) => {
  const text = String(readme ?? '');
  const starts = [];
  const ends = [];
  let cursor = 0;
  while (true) {
    const at = text.indexOf(INDEX_BLOCK_START, cursor);
    if (at < 0) break;
    starts.push(at);
    cursor = at + INDEX_BLOCK_START.length;
  }
  cursor = 0;
  while (true) {
    const at = text.indexOf(INDEX_BLOCK_END, cursor);
    if (at < 0) break;
    ends.push(at);
    cursor = at + INDEX_BLOCK_END.length;
  }
  if (starts.length === 0 && ends.length === 0) return { present: false, block: null, ambiguous: false };
  if (starts.length !== 1 || ends.length !== 1 || ends[0] < starts[0]) {
    return { present: false, block: null, ambiguous: true };
  }
  return {
    present: true,
    block: text.slice(starts[0], ends[0] + INDEX_BLOCK_END.length),
    ambiguous: false,
  };
};

/**
 * 把围栏块写回 README（纯函数）：块内内容替换 ⇒ **块外正文逐字保留**；
 * 块缺席 ⇒ 追加到末尾（与既有正文之间空一行）。
 */
export const applyModuleIndexBlock = (readme, block) => {
  const text = String(readme ?? '');
  const found = extractIndexBlock(text);
  if (found.ambiguous) {
    throw new Error(
      `README 的围栏标记不成对（${INDEX_BLOCK_START} / ${INDEX_BLOCK_END} 各须恰好一次、且 start 在前）——` +
        '禁猜用哪一段；请先人工消除重复标记再跑渲染器。',
    );
  }
  if (found.present) {
    const at = text.indexOf(found.block);
    return `${text.slice(0, at)}${block}${text.slice(at + found.block.length)}`;
  }
  const head = text.trimEnd();
  return head ? `${head}\n\n${block}\n` : `${block}\n`;
};

/** 读 `<spec>/plans` 下的 JSON（缺席 / 不可解析 ⇒ 可读失败原因）。 */
const readJsonInput = (specDir) => {
  const abs = path.join(specDir, 'plans', ...MODULE_INDEX_REL.split('/'));
  try {
    return { ok: true, value: JSON.parse(fs.readFileSync(abs, 'utf-8')) };
  } catch (error) {
    return {
      ok: false,
      reason:
        `模块索引机器产物不可读：${abs}（${error?.message ?? String(error)}）——` +
        '写者 = TS 侧波 5 派发计划步；修复：重跑波 5 第 1 步（禁手写本产物、禁在 README 里手抄两张表）。',
    };
  }
};

/**
 * 一次完整渲染：读产物 → 校验 → 渲染围栏块。失败 ⇒ `{ok:false, failures}`（调用方 exit 1）。
 * `--stdout` 与就地写盘共用本函数，保证两条路径的输出**逐字相同**。
 */
export const renderModuleIndexForWorkspace = (specDir) => {
  const resolved = path.resolve(String(specDir ?? '').trim());
  if (!resolved) return { ok: false, failures: ['缺少 --workspace（本次 spec 目录）'] };
  const plansBackendDir = path.join(resolved, 'plans', 'backend');
  if (!fs.existsSync(plansBackendDir)) {
    return {
      ok: false,
      failures: [
        `--workspace 不是有效的本次 spec 目录：${resolved}（缺 \`plans/backend\`）——` +
          '请传 TASK INPUT 里的大纲目录（含 plans/backend/README.md 的那一层）。',
      ],
    };
  }
  const input = readJsonInput(resolved);
  if (!input.ok) return { ok: false, failures: [input.reason] };
  const validated = validateModuleIndex(input.value);
  if (!validated.ok) return { ok: false, failures: validated.failures };
  return { ok: true, block: renderModuleIndexBlock(validated.artifact), specDir: resolved };
};

const parseArgs = (argv) => {
  const args = { workspace: '', stdout: false };
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === '--stdout') args.stdout = true;
    else if (token === '--workspace') {
      args.workspace = argv[index + 1] ?? '';
      index += 1;
    } else if (token.startsWith('--workspace=')) args.workspace = token.slice('--workspace='.length);
    else if (token === '--help' || token === '-h') args.help = true;
    else {
      args.error = `未知参数：${token}`;
      return args;
    }
  }
  return args;
};

const usage = [
  '用法：node .specify/scripts/javascript/render-module-index.mjs --workspace <本次 spec 目录> [--stdout]',
  '  --workspace <dir>  本次 spec 目录（含 plans/backend/README.md 与 plans/backend/_meta/module-index.json）',
  '  --stdout           只打印渲染出的围栏块（供归位 checker / 单测比对），不写盘',
].join('\n');

const main = (argv = process.argv.slice(2)) => {
  const args = parseArgs(argv);
  if (args.help) {
    process.stdout.write(`${usage}\n`);
    return 0;
  }
  if (args.error || !args.workspace) {
    process.stderr.write(`${args.error ? `${args.error}\n` : ''}${usage}\n`);
    return 1;
  }
  const rendered = renderModuleIndexForWorkspace(args.workspace);
  if (!rendered.ok) {
    process.stderr.write(`渲染模块索引失败：\n  - ${rendered.failures.join('\n  - ')}\n`);
    return 1;
  }
  if (args.stdout) {
    process.stdout.write(`${rendered.block}\n`);
    return 0;
  }
  const readmeAbs = path.join(rendered.specDir, 'plans', ...MODULE_INDEX_README_REL.split('/'));
  let readme = '';
  try {
    readme = fs.readFileSync(readmeAbs, 'utf-8');
  } catch {
    process.stderr.write(
      `渲染模块索引失败：\`${readmeAbs}\` 不可读 —— 归位 README 尚未落盘；` +
        '先由归位者写出 README（prose 章节），再跑渲染器刷新围栏块。\n',
    );
    return 1;
  }
  try {
    fs.writeFileSync(readmeAbs, applyModuleIndexBlock(readme, rendered.block));
  } catch (error) {
    process.stderr.write(`渲染模块索引失败：写 README 出错（${error?.message ?? String(error)}）\n`);
    return 1;
  }
  process.stdout.write(`模块索引围栏块已刷新：${readmeAbs}（块外正文未改动）\n`);
  return 0;
};

// 仅在**直接执行**时跑 CLI（被 import 时零副作用：checker / 单测按需调上面的纯函数）。
// 两侧都取 realpath：ESM 加载器会把软链解析成真实路径（macOS 上 `/tmp` → `/private/tmp`、
// `os.tmpdir()` 也是软链）——只比字符串会在「脚本被复制到临时工作区」时静默不执行（stdout 空、exit 0）。
const invokedDirectly = (() => {
  try {
    return (
      Boolean(process.argv[1]) &&
      fs.realpathSync(path.resolve(process.argv[1])) === fs.realpathSync(fileURLToPath(import.meta.url))
    );
  } catch {
    return false;
  }
})();

if (invokedDirectly) {
  process.exitCode = main();
}

export default renderModuleIndexForWorkspace;
