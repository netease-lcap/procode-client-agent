#!/usr/bin/env node
/**
 * check-initialize.mjs
 *
 * Sandbox-side checker for initialize workflow (existing project onboarding).
 * Zero external dependencies (only node built-ins). Fail fast on schema issues
 * and stack whitelist violations.
 *
 * Subcommands:
 *   stack       <manifest-path> <stack-path> <sourceKind>  (sourceKind = 'unified' | 'separated')
 *   components  <components-path>
 *   libs        <libs-required-path> <project-artifact-dir>
 *   metadata    <manifest-path>
 *   config-rewrite <project-artifact-dir>   (requires APP_NAME env)
 *   runtime-connectivity <project-artifact-dir>   (probes 127.0.0.1:6002/6003 via node:http;
 *                                                  ports overridable via env CHECK_INITIALIZE_FRONTEND_PORT /
 *                                                  CHECK_INITIALIZE_BACKEND_PORT, used by tests for dynamic ports;
 *                                                  probe timeout overridable via env
 *                                                  CHECK_INITIALIZE_PROBE_TIMEOUT_MS (ms, default 5000);
 *                                                  probe rotation interval overridable via env
 *                                                  CHECK_INITIALIZE_PROBE_INTERVAL_MS (ms, default 1000);
 *                                                  backend probes are path-discovering and rotate across the
 *                                                  5 retries: /api/health -> discovered parameterless @GetMapping
 *                                                  (prefixed by server.servlet.context-path) -> '/' fallback;
 *                                                  a probe passes when any HTTP response is received (2xx
 *                                                  short-circuits) — an app answering 4xx/5xx on the probed
 *                                                  paths is still a running service, only transport-level
 *                                                  errors on all 5 attempts count as unreachable;
 *                                                  when kind==='separated', also probes the external
 *                                                  ingress → frontend → proxy → backend API chain
 *                                                  end-to-end; the ingress URL is APP_FE_INGRESS_URL
 *                                                  when set, otherwise resolved from
 *                                                  .manifest/deploy.json public endpoints +
 *                                                  get-service-domains (preview-registration output);
 *                                                  public endpoints present but no usable entry →
 *                                                  ingress-url-missing blocks; the ingress HTTP client
 *                                                  is proxy-aware (honors
 *                                                  HTTP_PROXY/HTTPS_PROXY/NO_PROXY, required under
 *                                                  sandbox --unshare-net egress forwarding))
 *   lock-governance <package-lock.json-path>  (#289 §5.15 D：删旧私服 host 条目，B2)
 *
 * Exit codes:
 *   0  ok
 *   1  failure (stdout contains structured JSON report)
 *
 * L3 (unrecoverable, out-of-scope stack) is signaled by writing
 * `.initialize/unrecoverable-diagnosis.json` inside the project artifact dir
 * AND printing a `[UNRECOVERABLE]` prefix line to stdout.
 * 注意：`[UNRECOVERABLE]` 前缀目前仅是信息性标记 —— speckit 引擎没有消费它的短路逻辑；
 * 实际的 L3 终止依赖 runWithChecker 的「连续 3 轮归一化相同 → abort」（executor.ts 无效修复检测，
 * 约 3 轮 agent 重跑成本）。discovery agent 的 prompt 已明确要求：见到 [UNRECOVERABLE] 后
 * 保持 manifest 不变、立即结束，使 stale-abort 尽早触发（历史 backlog #58；引擎级真短路不在
 * initialize 范围内）。
 */

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import https from 'node:https';
import tls from 'node:tls';
import zlib from 'node:zlib';
import { execFile, execFileSync } from 'node:child_process';

const [, , subcommand, ...rest] = process.argv;

function readDeployManifestForChecker(projectArtifactDir) {
  const resourcesRoot = path.dirname(path.resolve(projectArtifactDir));
  const tool = path.join(resourcesRoot, '.specify', 'scripts', 'javascript', 'deploy-tool.mjs');
  let stdout;
  try {
    stdout = execFileSync(process.execPath, [tool, 'get'], {
      cwd: resourcesRoot,
      encoding: 'utf8',
      maxBuffer: 8 * 1024 * 1024,
    });
  } catch (error) {
    let reason = error?.message || String(error);
    try {
      const result = JSON.parse(error?.stdout?.toString() || '');
      if (typeof result?.error?.message === 'string') reason = result.error.message;
    } catch {}
    throw new Error(`deploy-tool get failed: ${reason}`);
  }
  let manifest;
  try {
    manifest = JSON.parse(stdout);
  } catch {
    throw new Error('deploy-tool get returned invalid JSON');
  }
  if (!manifest || typeof manifest !== 'object' || !Array.isArray(manifest.services)) {
    throw new Error('deploy-tool get returned an invalid Manifest');
  }
  return manifest;
}

const usage = () => {
  console.log(JSON.stringify({
    ok: false,
    errors: [`usage: check-initialize.mjs <stack|components|libs|metadata|config-rewrite|runtime-connectivity|lock-governance> ...`],
  }));
  process.exit(1);
};

if (!subcommand) usage();

const STACK_WHITELIST = {
  backend: {
    // 编译期回退（与 shared/constants.ts 同源；装机动态源优先读
    // `.initialize/jdk-versions.json`，见下方 readJdkMajorsSnapshot）。
    // A 全放行口径：5 / 6 / 7 / 8 / 9 / 17 / 21。
    jdkMajors: [5, 6, 7, 8, 9, 17, 21],
  },
};

/**
 * 读 JDK 版本快照（阶段二 `snapshotJdkVersions` 落盘的契约产物）。
 * 快照缺失/损坏/空 majors → null（调用方回退编译期常量，不误伤）。
 */
function readJdkMajorsSnapshot(projectArtifactDir) {
  try {
    const parsed = JSON.parse(
      fs.readFileSync(path.join(projectArtifactDir, '.initialize', 'jdk-versions.json'), 'utf-8'),
    );
    if (!Array.isArray(parsed.majors)) return null;
    const majors = parsed.majors.filter((m) => typeof m === 'number' && Number.isFinite(m));
    return majors.length > 0 ? majors : null;
  } catch {
    return null;
  }
}

/** Tomcat 容器编译期回退（与 shared/constants.ts 的 INITIALIZE_TOMCAT_CONTAINERS 同源）。 */
const TOMCAT_CONTAINERS = ['tomcat-7', 'tomcat-8.5', 'tomcat-9', 'tomcat-10', 'tomcat-10.1', 'tomcat-11'];

/**
 * 读 Tomcat 容器快照（阶段二 `snapshotTomcatVersions` 落盘）。
 * 快照缺失/损坏/空 containers → null（调用方回退编译期常量）。
 */
function readTomcatContainersSnapshot(projectArtifactDir) {
  try {
    const parsed = JSON.parse(
      fs.readFileSync(path.join(projectArtifactDir, '.initialize', 'tomcat-versions.json'), 'utf-8'),
    );
    if (!Array.isArray(parsed.containers)) return null;
    const containers = parsed.containers.filter((c) => typeof c === 'string' && c.trim());
    return containers.length > 0 ? containers : null;
  } catch {
    return null;
  }
}

function majorOf(v) {
  const m = /^(\d+)(?:\.(\d+))?/.exec(String(v ?? ''));
  if (!m) return null;
  const major = Number(m[1]);
  // legacy 1.x 口径：1.5→5 / 1.6→6 / 1.7→7 / 1.8→8
  return major === 1 && m[2] !== undefined ? Number(m[2]) : major;
}

function readJson(p, label) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf-8'));
  } catch (e) {
    throw new Error(`failed to read ${label} at ${p}: ${e.message}`);
  }
}

/**
 * war 形态检测（框架放开后唯一的打包形态门）。
 * 读后端根 pom.xml 的 <packaging>（相对 projectArtifactDir + rootDir 定位）；
 * packaging 缺失/不可读/不可解析 → { isWar: false }（不误伤，默认 jar 语义）。
 * 只认 `war` 字面值（大小写不敏感去空格），其它值一律非 war。
 */
function detectWarPackaging(projectArtifactDir, rootDir) {
  if (typeof rootDir !== 'string' || !rootDir) return { isWar: false, pomPath: '', pomText: '' };
  const pomPath = path.join(projectArtifactDir, rootDir, 'pom.xml');
  let text;
  try {
    text = fs.readFileSync(pomPath, 'utf-8');
  } catch {
    return { isWar: false, pomPath, pomText: '' };
  }
  const m = /<packaging>\s*([^<]+?)\s*<\/packaging>/.exec(text);
  if (!m) return { isWar: false, pomPath, pomText: text };
  return { isWar: m[1].trim().toLowerCase() === 'war', pomPath, pomText: text };
}

/**
 * war 容器声明归一（集中一处，与 TS resolveWarContainer 语义对齐）。
 * 三段式/短式统一归一到短式：9.x.x→tomcat-9、8.5.x→tomcat-8.5、7.0.x→tomcat-7、
 * 10.1.x→tomcat-10.1、10.0.x→tomcat-10、11.x→tomcat-11；无法识别原样返回（由矩阵校验拒绝）。
 */
function normalizeWarContainer(declared) {
  const v = String(declared ?? '').trim();
  if (!v) return '';
  const lower = v.toLowerCase();
  if (lower.startsWith('tomcat-')) {
    const ver = lower.slice('tomcat-'.length);
    const m = /^(\d+)(?:\.(\d+))?/.exec(ver);
    if (m) {
      const major = Number(m[1]);
      const minor = m[2] === undefined ? null : Number(m[2]);
      if (major === 7) return 'tomcat-7';
      if (major === 8) return 'tomcat-8.5';
      if (major === 9) return 'tomcat-9';
      if (major === 10) return minor === 1 ? 'tomcat-10.1' : 'tomcat-10';
      if (major === 11) return 'tomcat-11';
    }
    return lower;
  }
  const m = /^(\d+)(?:\.(\d+))?/.exec(v);
  if (m) {
    const major = Number(m[1]);
    const minor = m[2] === undefined ? null : Number(m[2]);
    if (major === 7) return 'tomcat-7';
    if (major === 8) return 'tomcat-8.5';
    if (major === 9) return 'tomcat-9';
    if (major === 10) return minor === 1 ? 'tomcat-10.1' : 'tomcat-10';
    if (major === 11) return 'tomcat-11';
  }
  return v;
}

/**
 * war 放行门（容器可用口径：只认 packaging=war + 容器在装机快照/内置清单内；容器可用性不与 JDK 档绑定——JDK 门在调用前对所有后端/一体应用统一执行）。
 * 容器解析：stack.container 先归一（短式/三段式统一），缺失默认 tomcat-9；
 * 可用清单 = `.initialize/tomcat-versions.json` 的 containers（缺失回退 TOMCAT_CONTAINERS）。
 * 明确拒绝：容器不在可用清单（含闭源商业容器/未安装版本）——reason 报可用容器清单；
 * pom 不可读时 fail-closed。多 war 由 manifest 层记 N 项，此处只判单应用形态。
 */
function checkWarGate(projectArtifactDir, rootDir, stack) {
  const verdict = detectWarPackaging(projectArtifactDir, rootDir);
  if (!verdict.pomText) {
    return { ok: false, reason: `war packaging detected but pom.xml unreadable (${verdict.pomPath}); please check pom or contact support` };
  }
  const declared = stack && typeof stack.container === 'string' ? stack.container : '';
  const container = normalizeWarContainer(declared) || 'tomcat-9';
  const available = readTomcatContainersSnapshot(projectArtifactDir) ?? TOMCAT_CONTAINERS;
  if (!available.includes(container)) {
    return { ok: false, reason: `war container '${container || '(unset)'}' is not supported by this sandbox (available: ${available.join(' / ')}) (${verdict.pomPath})` };
  }
  return { ok: true };
}

/**
 * 按 reason 组装用户行动文案（诊断文件 userActionRequired）。
 * 注意：旧实现固定写 JDK 文案，导致 OUT_OF_SCOPE_STACK（如 uni-app/HBuilderX 端）
 * 也提示「请上传 JDK」，误导用户换栈而非移除该端。
 * - OUT_OF_SCOPE_STACK：带 detail（含 outOfScopeReason），引导移除该端后重传 / 联系扩栈；
 * - OUT_OF_SCOPE_JDK_VERSION：JDK 快照清单文案（缺失回退 8 / 17 / 21）；
 * - OUT_OF_SCOPE_WAR_PACKAGING：报沙箱可用 Tomcat 容器清单；
 * - 其它（含 topology-mismatch）：保持原默认文案（服务层对 topology-mismatch 有覆写）。
 */
function buildUserActionRequired(projectArtifactDir, reason, detail) {
  if (reason === 'OUT_OF_SCOPE_STACK') {
    return `请移除该端（${detail}）后重新上传源码包，或联系平台申请扩栈支持`;
  }
  if (reason === 'OUT_OF_SCOPE_JDK_VERSION') {
    const majors = readJdkMajorsSnapshot(projectArtifactDir) ?? [8, 17, 21];
    return `请上传 JDK ${majors.join(' / ')} 的项目，或联系平台支持`;
  }
  if (reason === 'OUT_OF_SCOPE_WAR_PACKAGING') {
    const containers = readTomcatContainersSnapshot(projectArtifactDir) ?? TOMCAT_CONTAINERS;
    return `war 部署容器不在沙箱可用清单内，可用容器：${containers.join(' / ')}；请改用可用容器或改为 jar 部署后重新上传，或联系平台支持`;
  }
  return `请上传 JDK ${(readJdkMajorsSnapshot(projectArtifactDir) ?? [8, 17, 21]).join(' / ')} 的项目，或联系平台支持`;
}

function writeUnrecoverable(projectArtifactDir, reason, detail, phase) {
  try {
    const dir = path.join(projectArtifactDir, '.initialize');
    fs.mkdirSync(dir, { recursive: true });
    const diag = {
      reason,
      detail,
      phase,
      occurredAt: new Date().toISOString(),
      userActionRequired: buildUserActionRequired(projectArtifactDir, reason, detail),
    };
    fs.writeFileSync(
      path.join(dir, 'unrecoverable-diagnosis.json'),
      `${JSON.stringify(diag, null, 2)}\n`,
    );
  } catch (e) {
    // fall through: still print [UNRECOVERABLE] on stdout
  }
}

// ---------- #289 shared helpers (DESIGN §5.15，与 TS 侧 bundled-deps.ts 双实现同步) ----------

/**
 * 从 npm tarball（.tgz = gzip tar）中读 package/package.json 的 name/version。
 * 与 TS 侧 bundled-deps.ts readTgzPackageJson 保持同步（§6.5 双实现取舍同 metadata）：
 * zlib.gunzipSync + 最小 tar 头顺序扫描（不校验 checksum）；>100MB / 读取失败 / 无该条目 /
 * 字段缺失 → null。publish 记账键 = tgz 内容 name@version（与 TS publish 步骤同键）。
 */
function readTgzPackageJson(tgzPath) {
  try {
    if (fs.statSync(tgzPath).size > 100 * 1024 * 1024) return null;
    const data = zlib.gunzipSync(fs.readFileSync(tgzPath));
    let offset = 0;
    while (offset + 512 <= data.length) {
      const name = data.toString('utf-8', offset, offset + 100).replace(/\0[\s\S]*$/, '');
      if (name === '') break; // 全零块 = 归档结束
      const sizeField = data.toString('utf-8', offset + 124, offset + 136).replace(/\0[\s\S]*$/, '').trim();
      const size = parseInt(sizeField, 8);
      if (Number.isNaN(size) || size < 0) break;
      const payloadStart = offset + 512;
      if (name === 'package/package.json') {
        const json = JSON.parse(data.subarray(payloadStart, payloadStart + size).toString('utf-8'));
        if (json && typeof json.name === 'string' && typeof json.version === 'string') {
          return { name: json.name, version: json.version };
        }
        return null;
      }
      offset = payloadStart + Math.ceil(size / 512) * 512;
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * 读 publish 记账 {projectArtifactDir}/.initialize/published.json（与 TS readPublishedRecord
 * 语义一致）：ENOENT（常规，publish 尚未发生）→ 空集不 warn；损坏/读失败 → stderr warn 后
 * 空集（corrupt=true 标记——损坏时记账状态不可判定，publish 校验放行防误报，TS 侧会幂等
 * 重 publish 自愈）。只收 value===true 的键（与 TS 过滤一致）。
 */
function readPublishedRecord(projectArtifactDir) {
  try {
    const raw = JSON.parse(
      fs.readFileSync(path.join(projectArtifactDir, '.initialize', 'published.json'), 'utf-8'),
    );
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
      const out = {};
      for (const [key, value] of Object.entries(raw)) {
        if (value === true) out[key] = true;
      }
      return { record: out, corrupt: false };
    }
    return { record: {}, corrupt: true };
  } catch (e) {
    if (e && e.code === 'ENOENT') return { record: {}, corrupt: false };
    console.error(`[warning] 读 published 记账失败（按无记录处理）: ${e?.message || e}`);
    return { record: {}, corrupt: true };
  }
}

/**
 * npm 公共源 host 白名单（#289，DESIGN §5.15 D）——与 TS 侧 bundled-deps.ts
 * PUBLIC_NPM_REGISTRY_HOSTS 同步，修改必须双改。白名单 host 保留直拉；白名单外
 * （旧私服）的 lock .tgz 条目由 lock-governance 子命令删除。
 * 注意：白名单有意不含私服 nexus host——lock 治理语义
 * 是「一切非公共源条目都删、重走 nexus group resolve」，nexus 自身条目也不例外（阶段三
 * 若跑过 npm install，resolved 会指向 nexus group，全量删后重 resolve 幂等但多一轮网络；
 * 换取的是旧私服 host 无需枚举、统一归一，属有意设计，勿按遗漏补白名单）。
 */
const PUBLIC_REGISTRY_HOSTS = ['registry.npmjs.org', 'registry.npmmirror.com', 'registry.yarnpkg.com'];

// ---------- stack subcommand ----------

// 签名：stack <manifest-path> <stack-path> <sourceKind>
// sourceKind 来自 initializePayload.sourceKind（'unified' | 'separated'），做交叉校验
const SCHEMA_SUMMARY = '期望结构：顶层 {schemaVersion:1, kind:"unified|separated", apps:[{id, kind, rootDir, sourceDir, stack:{language, languageVersion, framework, frameworkVersion, buildTool, packageManager, entry}, outOfScope, outOfScopeReason}], components:null, runtimeConfigRef:null}';

function checkStack(manifestPath, stackJsonPath, expectedSourceKind) {
  const failures = [];
  const manifest = readJson(manifestPath, 'apps-manifest.json');
  const stackFile = readJson(stackJsonPath, 'stack.json');

  // stack.json 基本 schema 校验：必须是对象，至少有一个字段
  if (!stackFile || typeof stackFile !== 'object' || Array.isArray(stackFile)) {
    failures.push({ type: 'schema', field: 'stack.json', reason: 'stack.json must be a non-array object' });
  } else if (Object.keys(stackFile).length === 0) {
    failures.push({ type: 'schema', field: 'stack.json', reason: 'stack.json is empty; agent must record detection evidence' });
  }

  // kind 交叉校验已放宽（一体包内允许判 separated）：manifest.kind 与 sourceKind 不一致
  // 不再是失败项——仅记录提示（warn 级，不进 failures、不落盘诊断、不阻断）。
  // unified 包内允许判 separated（多前端记 N 项、应用数不限，见 §3.2/§3.5）；acquisition 不改写 sourceKind。
  if (expectedSourceKind && manifest.kind !== expectedSourceKind) {
    console.error(
      `[warning] apps-manifest.kind (${manifest.kind}) differs from initializePayload.sourceKind (${expectedSourceKind}); accepted (unified package may be identified as separated)`,
    );
  }

  if (manifest.schemaVersion !== 1) {
    failures.push({ type: 'schema', field: 'schemaVersion', reason: `expected 1, got ${manifest.schemaVersion}` });
  }
  if (manifest.kind !== 'unified' && manifest.kind !== 'separated') {
    failures.push({ type: 'schema', field: 'kind', reason: `expected unified|separated, got ${JSON.stringify(manifest.kind)}` });
  }

  const apps = Array.isArray(manifest.apps) ? manifest.apps : [];
  // 保持原样：应用数量按扫描结果记 N 项（kind 集合覆盖实际形态即可，不再限 unified=1 / separated=2）；
  // rootDir 为实际相对路径（允许嵌套，禁 .. 与绝对路径）。其余校验收紧为格式校验。
  if (apps.length === 0) {
    failures.push({ type: 'schema', field: 'apps.length', reason: 'apps must be a non-empty array' });
  }
  if (manifest.kind === 'unified' && apps.length !== 1) {
    failures.push({ type: 'schema', field: 'apps.length', reason: `unified requires 1 app, got ${apps.length}` });
  }

  const projectArtifactDir = path.dirname(path.dirname(path.resolve(manifestPath)));
  // manifestPath = <projectArtifactDir>/.initialize/apps-manifest.json → .. → .initialize → .. → projectArtifactDir

  // 文件缺失由部署契约归一化为空服务；已存在但损坏时必须显式失败。
  try {
    readDeployManifestForChecker(projectArtifactDir);
  } catch (error) {
    failures.push({ type: 'deploy-manifest-read', reason: error.message });
  }

  let unrecoverable = false;
  let unrecoverableReason = '';
  let unrecoverableDetail = '';

  for (const [idx, app] of apps.entries()) {
    if (!app || typeof app !== 'object') continue;
    // 保持原样：rootDir 为实际相对路径（允许嵌套，禁 ..、绝对路径与空字节）；其余为格式校验。
    if (typeof app.rootDir !== 'string' || !app.rootDir) {
      failures.push({ type: 'schema', field: `apps[${idx}].rootDir`, reason: 'required' });
    } else if (app.rootDir.includes('..') || app.rootDir.startsWith('/') || app.rootDir.includes('\\') || app.rootDir.includes('\0')) {
      failures.push({ type: 'schema', field: `apps[${idx}].rootDir`, reason: `must be a relative path without '..': ${app.rootDir}` });
    }
    const stack = app.stack;
    if (!stack || typeof stack !== 'object') {
      failures.push({ type: 'schema', field: `apps[${idx}].stack`, reason: 'missing' });
      continue;
    }
    if (app.outOfScope === true) {
      unrecoverable = true;
      unrecoverableReason = 'OUT_OF_SCOPE_STACK';
      unrecoverableDetail = `apps[${idx}] (${app.kind}) marked outOfScope: ${app.outOfScopeReason ?? 'no reason'}`;
      break;
    }
    // 框架类型已放开：后端只判 JDK 档（装机动态源优先，快照缺失回退编译期常量），
    // 前端框架不限，不再拦截。JDK 门对 jar / war 一视同仁（先过 JDK 门）；
    // war 再判 packaging=war + 容器在装机快照/内置清单内（不做 JDK×容器兼容校验）；
    // 闭源商业容器/未安装版本明确拒绝。
    if (app.kind === 'backend' || app.kind === 'unified') {
      const allowedMajors = readJdkMajorsSnapshot(projectArtifactDir) ?? STACK_WHITELIST.backend.jdkMajors;
      const langMajor = majorOf(stack.languageVersion);
      if (langMajor === null || !allowedMajors.includes(langMajor)) {
        unrecoverable = true;
        unrecoverableReason = 'OUT_OF_SCOPE_JDK_VERSION';
        unrecoverableDetail = `JDK major version must be one of ${allowedMajors.join(' / ')}, got ${stack.languageVersion}`;
      } else {
        // war 形态检测：读后端根 pom.xml 的 packaging（缺文件/不可解析时跳过，不误伤）。
        const warVerdict = detectWarPackaging(projectArtifactDir, app.rootDir);
        if (warVerdict.isWar) {
          const warGate = checkWarGate(projectArtifactDir, app.rootDir, stack);
          if (!warGate.ok) {
            unrecoverable = true;
            unrecoverableReason = 'OUT_OF_SCOPE_WAR_PACKAGING';
            unrecoverableDetail = warGate.reason;
          }
        }
      }
    }
    // 前端框架已放开：不拦截（保留 app.kind === 'frontend' 分支位，零判定）。
    if (unrecoverable) break;
  }

  if (unrecoverable) {
    writeUnrecoverable(projectArtifactDir, unrecoverableReason, unrecoverableDetail, 'discovery');
    console.log('[UNRECOVERABLE]');
    console.log(JSON.stringify({
      ok: false,
      unrecoverable: true,
      reason: unrecoverableReason,
      detail: unrecoverableDetail,
    }));
    process.exit(1);
  }

  // M17：其余 topology-mismatch（如还有）也落盘诊断文件（与 UNRECOVERABLE 同契约），
  // 供服务层 classifySourceRejection 识别为「源码被拒」触发重传；stdout 仍走 failures 分支不变。
  // kind 交叉不一致已放宽为 warn，不再产生 topology-mismatch、不落盘、不阻断。
  const topologyMismatch = failures.find((f) => f.type === 'topology-mismatch');
  if (topologyMismatch) {
    writeUnrecoverable(projectArtifactDir, 'topology-mismatch', topologyMismatch.reason, 'discovery');
  }

  if (failures.length > 0) {
    console.log(JSON.stringify({ ok: false, failures, schemaSummary: SCHEMA_SUMMARY }));
    process.exit(1);
  }
  // 成功轮清旧诊断：失败轮落盘的 unrecoverable-diagnosis.json 在后续成功轮必须清除，
  // 否则残留诊断误导排障（best-effort，删失败不阻断成功语义）。
  try {
    fs.rmSync(path.join(projectArtifactDir, '.initialize', 'unrecoverable-diagnosis.json'), { force: true });
  } catch {}
  console.log(JSON.stringify({ ok: true }));
  process.exit(0);
}

// ---------- components subcommand (M2 Task 5, M6 多库化) ----------
function checkComponents(componentsPath) {
  const failures = [];
  const cfg = readJson(componentsPath, 'components.json');
  if (cfg.schemaVersion !== 1) {
    failures.push({ type: 'schema', field: 'schemaVersion', reason: `expected 1, got ${cfg.schemaVersion}` });
  }

  // databases：开放式清单（每项 name + engine；engine 取平台字面值口径，不枚举类型；
  // 仅关系型——非关系型（mongodb / elasticsearch / clickhouse / doris / starrocks / etcd / zookeeper 等）
  // 走 middlewares + FOUR_M 中间件流程）
  // 与 TS 侧 `isRelationalEngine`（shared/datasource-contract.ts）同集合（零依赖镜像，改一处须同步另一处）。
  const NON_RELATIONAL_ENGINES = new Set([
    // 文档
    'mongodb', 'mongo', 'couchdb', 'couchbase',
    // 搜索
    'elasticsearch', 'es',
    // 列族 / 列式 OLAP
    'cassandra', 'hbase', 'clickhouse', 'ck', 'doris', 'starrocks', 'sr',
    // 图
    'neo4j',
    // 时序
    'influxdb',
    // 键值 / 协调
    'redis', 'memcached', 'etcd', 'zookeeper',
  ]);
  if (!Array.isArray(cfg.databases)) {
    failures.push({ type: 'schema', field: 'databases', reason: 'must be an array (open-ended database list)' });
  } else {
    for (const [idx, db] of cfg.databases.entries()) {
      if (!db || typeof db !== 'object') {
        failures.push({ type: 'schema', field: `databases[${idx}]`, reason: 'not an object' });
        continue;
      }
      if (!db.name) {
        failures.push({ type: 'schema', field: `databases[${idx}].name`, reason: 'required (original db name)' });
        continue;
      }
      if (typeof db.engine !== 'string' || db.engine === '') {
        failures.push({ type: 'schema', field: `databases[${idx}].engine`, reason: 'required (platform engine literal, e.g. mysql/oracle/db2/dameng)' });
      } else if (NON_RELATIONAL_ENGINES.has(String(db.engine).trim().toLowerCase())) {
        failures.push({
          type: 'database-non-relational',
          field: `databases[${idx}].engine`,
          reason: `non-relational engine ${JSON.stringify(db.engine)} must go to middlewares + FOUR_M middleware flow, not databases[] (datasource flow is relational-only)`,
        });
      }
      if (db.source !== 'platform-builtin') {
        failures.push({
          type: 'database-source',
          field: `databases[${idx}].source`,
          reason: `database source must be 'platform-builtin', got ${JSON.stringify(db.source)}`,
        });
      }
    }
    const seenNames = new Set();
    for (const [idx, db] of cfg.databases.entries()) {
      if (db && typeof db === 'object' && typeof db.name === 'string') {
        if (seenNames.has(db.name)) {
          failures.push({
            type: 'database-duplicate-name',
            field: `databases[${idx}].name`,
            reason: `duplicate database name ${JSON.stringify(db.name)}; names must be unique`,
          });
        }
        seenNames.add(db.name);
      }
    }
  }

  // redis / s3 段已下线——中间件统一经中间件契约层（middlewares.json + middlewares-tool.mjs）
  // 配置，components.json 只保留「中间件类型清单」一栏（见下方 middlewares）。

  // middlewares：开放式类型清单（数组、每项非空字符串、去重；关系型数据库引擎不入列，
  // 非关系型数据库按中间件入列）
  if (!Array.isArray(cfg.middlewares)) {
    failures.push({ type: 'schema', field: 'middlewares', reason: 'must be an array (open-ended middleware type list; empty array ok)' });
  } else {
    const seenMw = new Set();
    for (const [idx, mw] of cfg.middlewares.entries()) {
      if (typeof mw !== 'string' || mw.length === 0) {
        failures.push({ type: 'schema', field: `middlewares[${idx}]`, reason: 'must be a non-empty string (middleware type name)' });
        continue;
      }
      // 关系型数据库引擎在 databases[] 承载；middlewares 只列非数据库中间件 + 非关系型数据库
      // ——不再按 'mysql' 特判（引擎集合动态，代码不枚举类型）。
      if (seenMw.has(mw)) {
        failures.push({
          type: 'middleware-duplicate',
          field: `middlewares[${idx}]`,
          reason: `duplicate middleware type ${JSON.stringify(mw)}`,
        });
      } else {
        seenMw.add(mw);
      }
    }
  }

  if (failures.length > 0) {
    console.log(JSON.stringify({ ok: false, failures }));
    process.exit(1);
  }
  console.log(JSON.stringify({ ok: true }));
  process.exit(0);
}

// ---------- libs subcommand (M2 Task 5, M7 闭环规则, M13 bundled-tarball 存在性, M14 unreadable) ----------
// M7 形态：status/resolveStrategy 枚举 + bundled-zip 闭环（zipContent 回填）+ missing 闭环（resolved）。
// bundled-zip 的安装动作由 workflow 侧 checker（bundled-deps.ts installBundled）保证，本脚本只验证回填物。
// M13：bundled local-tarball（相对路径 tarball 就位）仅校验 expectedPath 文件存在即通过——
// 不要求 resolved、不做 package/package.json 内容比对（lcap 平台 tgz 内部布局未知）。
// M14（D5 实施落地）：bundled-zip 项 zipContent.unreadable === true → 显式失败
// bundled-zip-unreadable（不再按「zipContent 非空即通过」放过）——路径不可达=可修复错误，
// 修复通道是 agent 按新基准（相对 projectArtifactDir）重写 bundledPath，不询问、不进 checklist。
function checkLibs(libsRequiredPath, projectArtifactDir) {
  const failures = [];
  const cfg = readJson(libsRequiredPath, 'libs-required.json');
  if (cfg.schemaVersion !== 1) {
    failures.push({ type: 'schema', field: 'schemaVersion', reason: `expected 1, got ${cfg.schemaVersion}` });
  }
  const STATUSES = ['bundled', 'missing'];
  const STRATEGIES = ['local-jar', 'local-tarball', 'bundled-zip'];
  const requirements = Array.isArray(cfg.requirements) ? cfg.requirements : [];
  for (const [idx, req] of requirements.entries()) {
    if (!req || typeof req !== 'object') {
      failures.push({ type: 'schema', field: `requirements[${idx}]`, reason: 'not an object' });
      continue;
    }
    const f = (name) => `requirements[${idx}].${name}`;
    if (!STATUSES.includes(req.status)) {
      failures.push({ type: 'schema', field: f('status'), reason: `expected bundled|missing, got ${JSON.stringify(req.status)}` });
    }
    if (!STRATEGIES.includes(req.resolveStrategy)) {
      failures.push({ type: 'schema', field: f('resolveStrategy'), reason: `expected local-jar|local-tarball|bundled-zip, got ${JSON.stringify(req.resolveStrategy)}` });
    }
    if (req.resolveStrategy === 'local-tarball' && req.status === 'bundled') {
      // M13：bundled 相对路径 tarball 就位即闭合 —— 仅存在性校验（不要求 resolved、不校验内容）。
      if (!req.expectedPath) {
        failures.push({ type: 'schema', field: f('expectedPath'), reason: 'required' });
      } else {
        const absPath = path.join(projectArtifactDir, req.expectedPath);
        if (!fs.existsSync(absPath)) {
          failures.push({
            type: 'bundled-tarball-missing',
            field: f('expectedPath'),
            reason: `bundled local-tarball file not found at ${absPath}`,
          });
        }
      }
      continue;
    }
    if (req.resolveStrategy === 'bundled-zip') {
      // bundled-zip 闭环：bundledPath 指向 zip 即视为已安装（workflow inspect 回填 zipContent）。
      // zipContent 是可选回填物（叶子 checker 先于 wrapper 回填运行），不作为失败条件。
      // M14（D5 实施落地）：zipContent.unreadable === true → 显式失败
      // { type:'bundled-zip-unreadable', field: bundledPath, reason: unreadableReason }。
      // unreadable 时四布尔可全 false，不因全 false 拦截（拦截点就是 unreadable 本身）。
      if (!req.bundledPath) {
        failures.push({ type: 'schema', field: f('bundledPath'), reason: 'required for bundled-zip' });
      } else if (
        req.zipContent && typeof req.zipContent === 'object'
        && req.zipContent.unreadable === true
      ) {
        failures.push({
          type: 'bundled-zip-unreadable',
          field: f('bundledPath'),
          reason: typeof req.zipContent.unreadableReason === 'string'
            ? req.zipContent.unreadableReason
            : `bundledPath ${JSON.stringify(req.bundledPath)} marked unreadable without reason`,
        });
      }
    } else {
      if (!req.expectedPath) {
        failures.push({ type: 'schema', field: f('expectedPath'), reason: 'required' });
        continue;
      }
      const absPath = path.join(projectArtifactDir, req.expectedPath);
      const exists = fs.existsSync(absPath);
      if (req.resolved === true && !exists) {
        failures.push({
          type: 'resolved-but-missing',
          field: f('expectedPath'),
          reason: `resolved=true but file not found at ${absPath}`,
        });
      }
    }
    if (req.status === 'missing' && req.resolved !== true) {
      failures.push({
        type: 'unresolved',
        field: `requirements[${idx}]`,
        reason: `libs unresolved: ${req.coordinate} (upload to ${req.expectedPath})`,
      });
    }
  }

  // #289 publish 状态校验（DESIGN §5.15 F 三真源之三）：已闭合（文件就位）的前端
  // local-tarball 项应已在 .initialize/published.json 记账（键 = tgz 内容 name@version，
  // 与 TS publish 步骤同键——bundled 项的清单 coordinate 是路径推导值、可能与 tgz 内部
  // name@version 不同，join 必须以内容坐标为准）。
  // 硬拦截范围刻意收窄为 bundled 项 + file-refs.json 快照存在（快照存在 = 闭环 checker 已
  // 完成过完整 publish+改写轮——publish 诊断非空时改写不执行，见 bundled-closure.tasks.ts
  // 3b-pre/3b 顺序）；bundled 项集合自首轮稳定，快照存在后未记账只可能是记账/清单被改写。
  // missing 补齐项与首轮 bundled 项不硬拦（引擎时序：leaf libs checker 先于 wrapper 闭环
  // checker 运行——wrapper 的 publish 发生在 leaf 通过之后，硬拦 = agent 无法自修复的
  // 10 轮重试死锁），只 stderr warn 提示时序性滞后；published.json 损坏同样放行（TS 侧
  // 幂等重 publish 自愈）。诊断文案对齐 §5.15 F 错误分类语义。
  const { record: publishedRecord, corrupt: publishedCorrupt } = readPublishedRecord(projectArtifactDir);
  const fileRefsSnapshotExists = fs.existsSync(
    path.join(projectArtifactDir, '.initialize', 'file-refs.json'),
  );
  // publish 缺账硬拦谓词（M-4 抽取）：硬拦范围刻意收窄为「bundled 项 + 快照存在 + 记账未损坏」
  // ——三条件语义见上方块注释；抽命名谓词让收窄意图自解释（勿内联回循环）。
  const shouldHardBlockPublishMissing = (req) =>
    req.status === 'bundled' && fileRefsSnapshotExists && !publishedCorrupt;
  for (const [idx, req] of requirements.entries()) {
    if (!req || typeof req !== 'object') continue;
    if (req.kind !== 'frontend' || req.resolveStrategy !== 'local-tarball') continue;
    if (typeof req.expectedPath !== 'string' || !req.expectedPath) continue;
    const absPath = path.join(projectArtifactDir, req.expectedPath);
    const closed = fs.existsSync(absPath) && (req.status === 'bundled' || req.resolved === true);
    if (!closed) continue;
    const pkg = readTgzPackageJson(absPath);
    if (!pkg) continue; // tgz 不可解析 → TS publish 步骤产出自有诊断，mjs 不重复判
    const key = `${pkg.name}@${pkg.version}`;
    if (publishedRecord[key]) continue;
    if (shouldHardBlockPublishMissing(req)) {
      failures.push({
        type: 'publish-record-missing',
        field: `requirements[${idx}].coordinate`,
        reason: `已就位的前端二方包未在 .initialize/published.json 记账（tgz 内容坐标 ${key}，清单坐标 ${req.coordinate ?? '无'}）：publish 记账与 libs-required.json 不一致（阶段三 publish 结果丢失或 .initialize 记账被改写）。请勿手动编辑 .initialize/published.json；可重跑阶段三恢复（leaf 侧 abort 后 wrapper 的 publish 步骤不运行，重跑阶段三让依赖闭环 checker 的 publish 步骤幂等补记账——published/冲突均记账，§5.15 F）`,
      });
    } else {
      // warning-only：missing 补齐项当轮滞后（leaf 先于 wrapper publish）/ 首轮时序 / 记账损坏
      console.error(`[warning] 前端二方包 ${key}（${req.expectedPath}）尚未在 published.json 记账——leaf checker 先于依赖闭环 checker 的 publish 步骤运行，属正常时序，等待下轮复验`);
    }
  }
  if (failures.length > 0) {
    console.log(JSON.stringify({ ok: false, failures }));
    process.exit(1);
  }
  console.log(JSON.stringify({ ok: true }));
  process.exit(0);
}

// ---------- metadata subcommand (M3c) ----------
/**
 * 与 shared/metadata.ts 逻辑保持同步 —— 修改本函数时必须对齐 shared/metadata.ts 的 validateBackendReadme / validateFrontendReadme。
 * 双份实现的取舍见设计文档 §6.5（本 mjs 脚本保持零外部依赖，无法 import metadata.ts）。
 */
function checkMetadata(manifestPath) {
  const failures = [];
  const manifest = readJson(manifestPath, 'apps-manifest.json');
  const projectArtifactDir = path.dirname(path.dirname(path.resolve(manifestPath)));

  const backendApp = (manifest.apps || []).find((a) =>
    a && (a.kind === 'backend' || a.kind === 'unified'),
  );
  const frontendApp = manifest.kind === 'separated'
    ? (manifest.apps || []).find((a) => a && a.kind === 'frontend')
    : null;

  const backendRequired = ['技术栈', '架构', '业务模块', '接口契约', '集成', '命名'];
  const frontendRequired = ['技术栈', '目录结构', '路径 alias', '应用入口', '路由', '状态管理', '接口管理', '命名规范'];
  const prohibitedRe = /<!PENDING>|\[\*\*\*\]|\bTBD\b/;

  // 与 shared/metadata.ts 的 normalizeKeyword 保持同步（§6.5 双实现）
  const normalizeKeyword = (s) => String(s).replace(/\s+/g, '').toLowerCase();

  function validateReadme(mdPath, required, label) {
    if (!fs.existsSync(mdPath)) {
      failures.push({ type: 'metadata-readme-missing', file: mdPath, reason: `${label} README not found` });
      return;
    }
    const md = fs.readFileSync(mdPath, 'utf-8');
    if (prohibitedRe.test(md)) {
      failures.push({ type: 'metadata-readme-placeholder', file: mdPath, reason: `${label} README contains prohibited placeholders` });
    }
    const lines = md.split('\n');
    const sections = [];
    for (const line of lines) {
      const m = /^##\s+\d+\.\s+(.+?)\s*$/.exec(line);
      if (m) sections.push(m[1]);
    }
    const joined = normalizeKeyword(sections.join('|'));
    for (const keyword of required) {
      if (!joined.includes(normalizeKeyword(keyword))) {
        failures.push({
          type: 'metadata-readme-missing-chapter',
          file: mdPath,
          reason: `${label} README missing chapter containing "${keyword}"`,
        });
      }
    }
  }

  if (backendApp) {
    validateReadme(
      path.join(projectArtifactDir, backendApp.rootDir, 'README.md'),
      backendRequired,
      'backend',
    );
    // database.sql 按库抽检（M6 多库化）
    const databasesUsed = (() => {
      try {
        const componentsPath = path.join(projectArtifactDir, '.initialize', 'components.json');
        const c = JSON.parse(fs.readFileSync(componentsPath, 'utf-8'));
        return c && Array.isArray(c.databases) && c.databases.length > 0;
      } catch { return false; }
    })();
    if (databasesUsed) {
      const mappingPath = path.join(projectArtifactDir, '.initialize', 'db-name-mapping.json');
      let mappings = [];
      try {
        mappings = JSON.parse(fs.readFileSync(mappingPath, 'utf-8')).mappings || [];
      } catch {
        failures.push({ type: 'metadata-mapping-missing', file: mappingPath, reason: 'db-name-mapping.json required when mysql.used=true' });
      }
      for (const m of mappings) {
        const sqlPath = path.join(projectArtifactDir, backendApp.rootDir, 'sql', m.original, 'database.sql');
        if (!fs.existsSync(sqlPath)) {
          failures.push({ type: 'metadata-sql-missing', file: sqlPath, reason: `sql/${m.original}/database.sql required for mapped database` });
        } else {
          const sql = fs.readFileSync(sqlPath, 'utf-8');
          if (!/CREATE\s+TABLE/i.test(sql)) {
            failures.push({ type: 'metadata-sql-content', file: sqlPath, reason: `sql/${m.original}/database.sql must contain at least one CREATE TABLE statement` });
          }
        }
      }
    }
  }

  if (frontendApp) {
    validateReadme(
      path.join(projectArtifactDir, frontendApp.rootDir, 'README.md'),
      frontendRequired,
      'frontend',
    );
  }

  if (failures.length > 0) {
    console.log(JSON.stringify({ ok: false, failures }));
    process.exit(1);
  }
  console.log(JSON.stringify({ ok: true }));
  process.exit(0);
}

// ---------- config-rewrite subcommand ----------

/**
 * npm userconfig 路径解析（与 TS 侧 bundled-deps.ts 的 resolveNpmUserconfigPath 同序，修改必须双改）：
 *   1. `process.env.NPM_CONFIG_USERCONFIG`（显式指定，最优先）
 *   2. `/root/.npmrc`（沙箱平台预置约定位置；fs.existsSync 存在才选——沙箱 HOME 可能 ≠ /root）
 *   3. `path.join(os.homedir(), '.npmrc')`（本地/通用兜底）
 */
function resolveNpmUserconfigPath() {
  const explicit = process.env.NPM_CONFIG_USERCONFIG;
  if (explicit) return explicit;
  const sandboxNpmrc = '/root/.npmrc';
  if (fs.existsSync(sandboxNpmrc)) return sandboxNpmrc;
  return path.join(os.homedir(), '.npmrc');
}

/**
 * 宽松读 user 级 .npmrc 的 registry= 行（缺失/读失败 → null，不校验 nexus 特征）。
 * 路径经 resolveNpmUserconfigPath()（与 TS 侧同源解析）。
 * 有意 keep-loose（fail-open）：本函数仅做候选 registry 的尽力发现（probe 走
 * NPM_CONFIG_REGISTRY 优先），缺失时 layer-2 整体放行（warn），不硬失败。
 */
function readNpmrcRegistryLoose() {
  try {
    const text = fs.readFileSync(resolveNpmUserconfigPath(), 'utf-8');
    const m = /^registry\s*=\s*(.+)$/m.exec(text);
    return m?.[1]?.trim() || null;
  } catch {
    return null;
  }
}

/**
 * npm view <name>@<version> --registry=<registry> 可解析性判定（#289，DESIGN §5.15 layer-2）。
 * 返回 'ok'（exit 0）/ 'missing'（404 / notarget / E404 / 'is not in this registry' 等注册表
 * 缺值形态——确定的不可解析；本 mjs 的 missing 正则为 TS 侧 isNpmNotExistsOutput 的**有意超集**
 * （多 `Not [Ff]ound` / 裸 `notarget` 形态，fail-open 方向安全——多认缺失走 publish 重发、少漏判），
 * TS isNpmNotExistsOutput 为子集；修改必须双改（新增形态先在 TS 侧收敛，再评估是否补入 mjs 超集））/
 * 'unknown'（超时（killed/SIGTERM）、网络错误、npm 不可达、其他意外形态——不判定，放行，
 * 阶段六 npm install 兜底，不因网络抖动误报 broken）。
 * 单次超时可经 INITIALIZE_NPM_VIEW_TIMEOUT_MS 覆盖，默认 30s——注意外层 wrapper checker
 * （createInitializeScriptChecker，script-checker.ts）对整个脚本有 120s 硬超时，单次超时 +
 * 多候选整体预算（见 checkConfigRewrite layer-2）都必须在该硬超时内收口，否则外层先杀进程、
 * 产出无诊断的 killed 死锁。npm 标准环境变量 NPM_CONFIG_REGISTRY 优先于 .npmrc，
 * 与 npm 子进程自身行为一致；`--userconfig=<resolveNpmUserconfigPath()>` 与 TS 侧
 * npmDryRunProbe/npmView/publish 同源（bundled-deps.ts 的 resolveNpmUserconfigPath，修改必须双改）。
 */
const execFileAsync = (file, args, options) => new Promise((resolve) => {
  execFile(file, args, options, (error, stdout, stderr) => {
    resolve({ error, stdout: String(stdout ?? ''), stderr: String(stderr ?? '') });
  });
});

async function npmViewResolvable(name, version, registry) {
  const configuredTimeoutMs = Number(process.env.INITIALIZE_NPM_VIEW_TIMEOUT_MS);
  const timeoutMs = configuredTimeoutMs > 0 ? configuredTimeoutMs : 30000;
  const { error, stdout, stderr } = await execFileAsync(
    'npm',
    ['view', `${name}@${version}`, '--registry', registry, `--userconfig=${resolveNpmUserconfigPath()}`],
    { timeout: timeoutMs },
  );
  if (!error) return 'ok';
  if (error.killed || error.signal === 'SIGTERM') return 'unknown'; // 超时
  const output = `${stdout}\n${stderr}\n${error.message ?? ''}`;
  if (/\bE404\b|404 Not Found|Not [Ff]ound|notarget|No matching version found|\bETARGET\b|is not in this registry/.test(output)) {
    return 'missing';
  }
  // 网络错误 / spawn ENOENT（npm 不在 PATH）/ 其他意外形态 → 不判定（放行）
  return 'unknown';
}

/**
 * 多端前端布局（M10）：读 {projectArtifactDir}/.initialize/stack.json 的
 * frontendEnds / frontendMainEnd。返回 { ends, main }；frontendEnds 缺失/为空或
 * 文件读取失败 → null（视为常规单端，走现状逻辑）。
 * 主端确定规则：frontendMainEnd（合法且在清单内）→ 否则清单内的 'pc' → 否则清单第一个。
 */
function readMultiEndLayout(projectArtifactDir) {
  try {
    const stackPath = path.join(projectArtifactDir, '.initialize', 'stack.json');
    const stack = JSON.parse(fs.readFileSync(stackPath, 'utf-8'));
    const ends = Array.isArray(stack && stack.frontendEnds)
      ? stack.frontendEnds.filter((e) => typeof e === 'string' && e.length > 0)
      : [];
    if (ends.length === 0) return null;
    let main = typeof stack.frontendMainEnd === 'string' && stack.frontendMainEnd
      ? stack.frontendMainEnd
      : null;
    if (!ends.includes(main)) main = ends.includes('pc') ? 'pc' : ends[0];
    return { ends, main };
  } catch {
    return null;
  }
}

function grepFilesRecursive(root, extensions, onFile) {
  const stack = [root];
  while (stack.length) {
    const cur = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(cur, { withFileTypes: true });
    } catch { continue; }
    for (const entry of entries) {
      const full = path.join(cur, entry.name);
      if (entry.isDirectory()) {
        // 跳过 node_modules / dist / build / .git
        if (['node_modules', 'dist', 'build', '.git', '.next', '.output', '.turbo'].includes(entry.name)) continue;
        stack.push(full);
      } else if (entry.isFile()) {
        const ext = path.extname(entry.name);
        if (extensions.includes(ext) || extensions.includes(entry.name)) {
          try {
            onFile(full, fs.readFileSync(full, 'utf-8'));
          } catch { /* skip */ }
        }
      }
    }
  }
}

function extractObjectBlock(text, key) {
  const re = new RegExp(`(^|[^\\w.])${key}\\s*:\\s*\\{`);
  const m = re.exec(text);
  if (!m) return null;
  // 定位到开 `{` 的字符位置
  let i = m.index + m[0].length - 1;
  let depth = 0;
  const start = i + 1;
  for (; i < text.length; i++) {
    const ch = text[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return text.slice(start, i);
    }
  }
  return null; // 括号不闭合
}

// ---------- runtime-connectivity: ingress 端到端探测（2026-09-04） ----------
//
// 背景：localhost 探活（6002/6003）证明不了「外部入口 → 前端 → 代理 → 后端」链路
// （gaoma 线上实测：全部 checker 绿，外部浏览器 Network Error）。本组函数经
// APP_FE_INGRESS_URL（沙箱注入的外部前端入口）实测该链路。
//
// HTTP 客户端必须代理感知：沙箱 bwrap --unshare-net 下访问外部域名要走
// HTTP_PROXY（127.0.0.1:7000 转发代理）；node:http 默认不认 env 代理，直连会假红。

function pickProxyFor(protocol) {
  const isHttps = protocol === 'https:';
  const primary = isHttps
    ? (process.env.HTTPS_PROXY || process.env.https_proxy)
    : (process.env.HTTP_PROXY || process.env.http_proxy);
  const secondary = isHttps
    ? (process.env.HTTP_PROXY || process.env.http_proxy)
    : (process.env.HTTPS_PROXY || process.env.https_proxy);
  const raw = String(primary || secondary || '').trim();
  if (!raw) return null;
  try {
    const u = new URL(raw);
    if (!/^https?:$/.test(u.protocol)) return null;
    return u;
  } catch {
    return null;
  }
}

function shouldBypassProxy(hostname) {
  const list = String(process.env.NO_PROXY || process.env.no_proxy || '')
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (list.includes('*')) return true;
  const host = String(hostname || '').toLowerCase();
  return list.some((entry) => host === entry || host.endsWith(`.${entry}`));
}

function settleHttpResponse(res) {
  return {
    status: res.statusCode ?? null,
    contentType: String(res.headers['content-type'] || '').split(';')[0].trim().toLowerCase(),
  };
}

const PROBE_ACCEPT_HEADER = { Accept: 'application/json, text/plain, */*' };

/** 直连 GET（不经代理；后端 127.0.0.1:6003 探测用）。失败/超时返回 null。 */
function httpGetDirect(urlStr, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    try {
      const u = new URL(urlStr);
      const mod = u.protocol === 'https:' ? https : http;
      const req = mod.get(urlStr, { timeout: timeoutMs, headers: PROBE_ACCEPT_HEADER }, (res) => {
        done(settleHttpResponse(res));
        res.resume();
      });
      req.on('error', () => done(null));
      req.on('timeout', () => { req.destroy(); done(null); });
    } catch {
      done(null);
    }
  });
}

/** 代理感知 GET（ingress 探测用）。http 目标走绝对 URI 请求；https 目标走 CONNECT + TLS。失败返回 null。 */
function httpGetViaProxy(urlStr, timeoutMs = 8000) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (v) => { if (!settled) { settled = true; resolve(v); } };
    let target;
    try {
      target = new URL(urlStr);
    } catch {
      done(null);
      return;
    }
    const send = (mod, options) => {
      try {
        const req = mod.request(options, (res) => {
          done(settleHttpResponse(res));
          res.resume();
        });
        req.on('error', () => done(null));
        req.on('timeout', () => { req.destroy(); done(null); });
        req.end();
      } catch {
        done(null);
      }
    };
    const proxy = shouldBypassProxy(target.hostname) ? null : pickProxyFor(target.protocol);
    if (!proxy) {
      const mod = target.protocol === 'https:' ? https : http;
      send(mod, {
        hostname: target.hostname,
        port: target.port || (target.protocol === 'https:' ? 443 : 80),
        method: 'GET',
        path: `${target.pathname}${target.search}`,
        headers: { ...PROBE_ACCEPT_HEADER, Host: target.host },
        timeout: timeoutMs,
      });
      return;
    }
    if (target.protocol === 'http:') {
      // http 目标：向代理发绝对 URI 请求
      send(http, {
        host: proxy.hostname,
        port: Number(proxy.port) || 80,
        method: 'GET',
        path: target.href,
        headers: { ...PROBE_ACCEPT_HEADER, Host: target.host },
        timeout: timeoutMs,
      });
      return;
    }
    // https 目标：CONNECT 隧道 + TLS
    try {
      const req = http.request({
        host: proxy.hostname,
        port: Number(proxy.port) || 80,
        method: 'CONNECT',
        path: `${target.hostname}:${target.port || 443}`,
        timeout: timeoutMs,
      });
      req.on('connect', (res, socket) => {
        if (res.statusCode !== 200) {
          socket.destroy();
          done(null);
          return;
        }
        const tlsSocket = tls.connect({ socket, servername: target.hostname }, () => {
          send(http, {
            createConnection: () => tlsSocket,
            method: 'GET',
            path: `${target.pathname}${target.search}`,
            headers: { ...PROBE_ACCEPT_HEADER, Host: target.host },
            timeout: timeoutMs,
          });
        });
        tlsSocket.on('error', () => done(null));
      });
      req.on('error', () => done(null));
      req.on('timeout', () => { req.destroy(); done(null); });
      req.end();
    } catch {
      done(null);
    }
  });
}

function joinUrlPath(a, b) {
  const left = String(a || '').replace(/\/+$/, '');
  const right = String(b || '').replace(/^\/+/, '');
  if (!left) return right ? `/${right}` : '/';
  if (!right) return left;
  return `${left}/${right}`;
}

/**
 * 发现浏览器实际使用的后端 API 前缀（可能多个，如 /api、/a、/graphql）：
 * 构建配置的 proxy key（vite server.proxy / vue devServer.proxy / next rewrites source）
 * + .env 相对 API base 值 + src 中 baseURL 相对值。发现不了返回空数组（调用方 skip + warn）。
 */
function discoverBrowserApiPrefixes(frontendDir) {
  const found = new Set();
  const add = (raw) => {
    let p = String(raw || '').trim();
    if (p.startsWith('^')) p = p.slice(1);
    if (!p.startsWith('/') || p === '/') return;
    found.add(p);
  };
  if (!fs.existsSync(frontendDir)) return [];
  grepFilesRecursive(
    frontendDir,
    ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.vue', '.env', '.env.development', '.env.local'],
    (file, text) => {
      const base = path.basename(file);
      if (/^(vite|vue|next|webpack|rspack)\.config\./.test(base)) {
        const proxyBlock = extractObjectBlock(text, 'proxy');
        if (proxyBlock) {
          const keyRe = /["']([^"']+)["']\s*:/g;
          let m;
          while ((m = keyRe.exec(proxyBlock)) !== null) add(m[1]);
        }
        const srcRe = /source\s*:\s*["']([^"']+)["']/g;
        let s;
        while ((s = srcRe.exec(text)) !== null) add(s[1]);
        return;
      }
      if (base.startsWith('.env')) {
        const envRe = /^[A-Z0-9_]*API[A-Z0-9_]*(?:BASE[A-Z0-9_]*)?URL\s*=\s*["']?(\/[^\s"']*)/gm;
        let m;
        while ((m = envRe.exec(text)) !== null) add(m[1]);
        return;
      }
      const baseRe = /base_?url\s*[:=]\s*["'](\/[^"']*)["']/gi;
      let m;
      while ((m = baseRe.exec(text)) !== null) add(m[1]);
    },
  );
  return [...found];
}

/**
 * 发现后端无路径参数的 GET 端点（探测用真实接口，避免合成路径的 404 语义歧义）：
 * 扫 *Controller.java 的 @GetMapping；类级 @RequestMapping 作前缀（首个出现，启发式）。
 * 含 `{` 路径变量的跳过。找不到返回空数组（调用方退化为探测前缀本身）。
 */
function discoverBackendGetEndpoints(backendDir) {
  const found = new Set();
  if (!fs.existsSync(backendDir)) return [];
  grepFilesRecursive(backendDir, ['.java'], (file, text) => {
    if (!/Controller\.java$/.test(path.basename(file))) return;
    const cm = /@RequestMapping\s*\(\s*(?:value\s*=\s*)?["']([^"']*)["']/.exec(text);
    const classPrefix = cm ? cm[1] : '';
    const re = /@GetMapping\s*\(\s*(?:value\s*=\s*)?["']([^"']*)["']/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      const p = m[1];
      if (!p.startsWith('/') || p.includes('{')) continue;
      found.add(joinUrlPath(classPrefix, p));
    }
  });
  return [...found].sort((a, b) => a.length - b.length);
}

/** 读 server.servlet.context-path（yml / properties）；默认 ''。 */
function readServerContextPath(backendDir) {
  const resDir = path.join(backendDir, 'src', 'main', 'resources');
  if (!fs.existsSync(resDir)) return '';
  for (const f of ['application.yml', 'application.yaml', 'application.properties']) {
    const p = path.join(resDir, f);
    if (!fs.existsSync(p)) continue;
    try {
      const text = fs.readFileSync(p, 'utf-8');
      if (f.endsWith('.properties')) {
        const m = /^server\.servlet\.context-path\s*=\s*(\S+)/m.exec(text);
        if (m) return m[1];
      } else {
        const m = /context-path:\s*(\S+)/.exec(text);
        if (m) return m[1].replace(/^["']|["']$/g, '');
      }
    } catch { /* skip */ }
  }
  return '';
}

const isHtmlContentType = (ct) => ct === 'text/html' || ct.endsWith('+html') || ct === 'application/xhtml+xml';

/**
 * 发现浏览器 baseURL 的相对前缀值（2026-09-05 双前缀根因修复配套）：
 * 来源 = .env* 的 API base 变量值（**含空串**——空也是合法发现值，代表「path 自带前缀」形态）
 * + src 中 baseURL 赋值行上的相对字面量（含 `|| '/api'` 兜底形态）。
 * 返回 { found, values }：found=false 表示完全无线索（调用方回退多形态探测）；
 * values 为去重前缀集合（可含 ''）。
 */
function discoverBrowserBasePrefixes(frontendDir) {
  const values = new Set();
  let found = false;
  if (!fs.existsSync(frontendDir)) return { found, values: [] };
  grepFilesRecursive(
    frontendDir,
    ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.vue', '.env', '.env.development', '.env.local', '.env.example'],
    (file, text) => {
      const base = path.basename(file);
      if (base.startsWith('.env')) {
        const envRe = /^[A-Z0-9_]*API[A-Z0-9_]*(?:BASE[A-Z0-9_]*)?URL\s*=\s*(.*)$/gm;
        let m;
        while ((m = envRe.exec(text)) !== null) {
          const v = m[1].trim().replace(/^["']|["']$/g, '').split(/\s+#/)[0].trim();
          // 空串 = path 自带前缀形态（合法发现）；绝对地址不属于「前缀」（另有断言拦截）；相对前缀收集
          if (v === '') { values.add(''); found = true; }
          else if (v.startsWith('/') && v !== '/') { values.add(v); found = true; }
        }
        return;
      }
      if (/\.(ts|tsx|js|jsx|mjs|cjs|vue)$/.test(base)) {
        // baseURL 赋值行上的相对字面量（含兜底 `|| '/api'` / `?? '/api'`）；同一行可能既有 env 引用又有兜底字面量
        const lineRe = /base_?url\s*[:=][^\n]*/gi;
        let lm;
        while ((lm = lineRe.exec(text)) !== null) {
          const line = lm[0];
          if (/https?:\/\//i.test(line)) continue; // 绝对地址行由 frontend-browser-api-base 断言管
          const litRe = /["'](\/[^"'?\s]*)["']/g;
          let cm;
          while ((cm = litRe.exec(line)) !== null) {
            if (cm[1] !== '/') { values.add(cm[1]); found = true; }
          }
          if (/["']\s*\|\|\s*["']\s*["']|["']{2}/.test(line)) { values.add(''); found = true; }
        }
      }
    },
  );
  return { found, values: [...values] };
}

/**
 * 读 `.manifest/deploy.json` 的 public 入口服务（endpoints[].exposure === 'public'）。
 * 返回 [{ serviceName, basePaths: string[] }]；文件缺失/损坏/无 public 入口 → []。
 * 用途：判断「本次部署是否期望产出外部入口」——有 public 入口却拿不到任何可用域名
 * 即预览注册未产出外部入口，必须阻断（ingress-url-missing），不再只看 env。
 */
function readPublicDeployServices(projectArtifactDir) {
  try {
    const raw = JSON.parse(fs.readFileSync(path.join(projectArtifactDir, '.manifest', 'deploy.json'), 'utf-8'));
    const services = Array.isArray(raw && raw.services) ? raw.services : [];
    const out = [];
    for (const s of services) {
      if (!s || typeof s.serviceName !== 'string') continue;
      const endpoints = Array.isArray(s.endpoints) ? s.endpoints : [];
      const basePaths = endpoints
        .filter((e) => e && e.exposure === 'public')
        .map((e) => (typeof e.basePath === 'string' && e.basePath ? e.basePath : '/'));
      if (basePaths.length > 0) out.push({ serviceName: s.serviceName, basePaths });
    }
    return out;
  } catch {
    return [];
  }
}

/**
 * 经 sibling platform-tool `get-service-domains` 查实际可达域名（与 deploy 侧同一子进程
 * 边界；身份取 APP_ID/PRD_ID/CURRENT_BRANCH，平台实现不内联进 checker）。脚本缺失、
 * 身份缺失、退出非 0、结构非法 → []（调用方按「无可用域名」处理并给出恢复指引）。
 */
async function readIngressDomains(projectArtifactDir) {
  const script = path.join(projectArtifactDir, '.specify', 'scripts', 'javascript', 'platform-tool.mjs');
  if (!fs.existsSync(script)) return [];
  const { error, stdout } = await execFileAsync(
    process.execPath,
    [script, 'get-service-domains'],
    { cwd: projectArtifactDir, env: process.env, timeout: 30_000, maxBuffer: 1024 * 1024, windowsHide: true },
  );
  if (error) return [];
  try {
    const payload = JSON.parse(stdout);
    if (!payload || !Array.isArray(payload.domains)) return [];
    return payload.domains.flatMap((service) => {
      if (!service || typeof service.serviceName !== 'string' || !Array.isArray(service.endpoints)) return [];
      return service.endpoints
        .filter((endpoint) => endpoint && typeof endpoint.url === 'string' && endpoint.url.trim())
        .map((endpoint) => ({ serviceName: service.serviceName, url: endpoint.url }));
    });
  } catch {
    return [];
  }
}

/**
 * ingress 端到端探测主体：
 * 0) 解析外部入口 URL（2026-10-18 新口径：不再以 env 为唯一来源）：
 *    - APP_FE_INGRESS_URL 合法 → 直接用（存量/本地测试路径，最高优先级）
 *    - env 缺失/非法 → 读 `.manifest/deploy.json` 的 public 入口服务，经
 *      `get-service-domains` 取实际可达域名（预览注册产物），匹配 public 服务名，
 *      取其 endpoints[].url 作为入口
 *    - 有 public 入口却两路都拿不到可用入口 → ingress-url-missing 阻断（预览注册
 *      未产出外部入口；回环探活覆盖不到该故障类）
 *    - 无 public 入口（无外部入口期望）→ warn 跳过
 * 1) 发现浏览器 baseURL 前缀（discoverBrowserBasePrefixes：env 值 + src baseURL 字面量，
 *    含空串）；完全无线索 → 回退「直通 + 剥 proxy 前缀」双形态保守探测
 * 2) 发现真实 GET 端点（@GetMapping）；无端点 → 退化为探测前缀本身
 * 3) 逐候选对探测：browserPath 经 ingress（代理感知） vs backendPath 直连 127.0.0.1:6003；
 *    status + content-type 一致 → 链路证明通过；ingress HTML 且直连非 HTML → SPA fallback；
 *    全部不一致 → mismatch（browserPath 前缀叠在 endpoint 同前缀上时给 double-prefix 提示）；
 *    网络不可达 → unreachable。
 * browserPath 优先取「baseURL 前缀 + endpoint」确定形态（真实浏览器请求 path = baseURL + 请求 path，
 * 2026-09-05 双前缀根因：baseURL='/api' + path='/api/x' → /api/api/x → 后端 No static resource 500；
 * 确定形态不与直通形态混探，双前缀才能被 mismatch 抓住）。
 */
async function probeIngressApiChain({ projectArtifactDir, manifest, backendPort, failures }) {
  const publicServices = readPublicDeployServices(projectArtifactDir);
  const rawIngress = String(process.env.APP_FE_INGRESS_URL || '').trim();
  let ingress = null;
  let ingressSource = 'APP_FE_INGRESS_URL';
  if (rawIngress) {
    try {
      const candidate = new URL(rawIngress);
      if (!['http:', 'https:'].includes(candidate.protocol)) throw new Error('protocol must be http/https');
      if (candidate.username || candidate.password) throw new Error('credentials not allowed');
      ingress = candidate;
    } catch (e) {
      console.error(`[warning] APP_FE_INGRESS_URL invalid (${rawIngress}: ${e?.message || e}); falling back to manifest public endpoints + service domains`);
    }
  }
  if (!ingress) {
    if (publicServices.length === 0) {
      console.error('[warning] no public endpoints in .manifest/deploy.json and no usable APP_FE_INGRESS_URL; skip ingress api-chain probe');
      return;
    }
    const domains = await readIngressDomains(projectArtifactDir);
    const publicNames = new Set(publicServices.map((s) => s.serviceName));
    const matched = domains.find((d) => publicNames.has(d.serviceName));
    if (matched) {
      try {
        ingress = new URL(matched.url);
        ingressSource = `service-domains (${matched.serviceName})`;
      } catch {}
    }
    if (!ingress) {
      failures.push({
        type: 'ingress-url-missing',
        reason: `public 入口服务 [${[...publicNames].join(', ')}] 未解析到任何可用外部入口 — APP_FE_INGRESS_URL 未注入/非法，且 get-service-domains 未返回匹配域名，说明预览注册未产出可用外部入口（注册失败即无 domains）。请重新触发预览注册，待外部入口可用后再跑阶段校验；回环探活覆盖不到该故障类，故直接阻断。`,
      });
      return;
    }
  }
  const apps = manifest && Array.isArray(manifest.apps) ? manifest.apps : [];
  const feApp = apps.find((a) => a && a.kind === 'frontend' && typeof a.rootDir === 'string' && a.rootDir);
  const beApp = apps.find((a) => a && a.kind === 'backend' && typeof a.rootDir === 'string' && a.rootDir);
  const frontendDir = feApp
    ? path.join(projectArtifactDir, feApp.rootDir)
    : process.env.APP_NAME ? path.join(projectArtifactDir, `${process.env.APP_NAME}-frontend`) : null;
  const backendDir = beApp
    ? path.join(projectArtifactDir, beApp.rootDir)
    : process.env.APP_NAME ? path.join(projectArtifactDir, `${process.env.APP_NAME}-backend`) : null;
  if (!frontendDir || !backendDir) {
    console.error('[warning] cannot locate frontend/backend dirs (manifest unreadable and APP_NAME unset); skip ingress api-chain probe');
    return;
  }

  const prefixes = discoverBrowserApiPrefixes(frontendDir);
  if (prefixes.length === 0) {
    console.error(`[warning] no browser api prefixes discovered under ${frontendDir}; skip ingress api-chain probe`);
    return;
  }
  const ctxPath = readServerContextPath(backendDir);
  const endpoints = discoverBackendGetEndpoints(backendDir).map((e) => joinUrlPath(ctxPath, e));

  // 候选探测组（2026-09-05 双前缀根因修复重设计）：
  // - baseURL 前缀发现成功（discoverBrowserBasePrefixes found）→ 每个前缀值一组「prefix + endpoint」
  //   确定形态（真实浏览器请求 path = baseURL + 请求 path）；**全部组通过才放行**——半修复形态
  //   （env 置空但代码兜底仍是 '/api'）运行时 base 取兜底值，若任一成功即放行会被 env 空值的
  //   '' 形态掩盖；不与直通形态混探，双前缀才能被 mismatch 抓住（gaoma 实测 /api/api/x 500
  //   时直通 /api/x 却 200）
  // - 完全无线索 → 回退「直通 + 剥 proxy 前缀」双形态保守探测（猜测形态，任一成功即过）
  const basePrefixInfo = discoverBrowserBasePrefixes(frontendDir);
  const groups = [];
  const seenPair = new Set();
  const pushPair = (arr, browserPath, backendPath) => {
    const key = `${browserPath}=>${backendPath}`;
    if (seenPair.has(key)) return;
    seenPair.add(key);
    arr.push({ browserPath, backendPath });
  };
  if (endpoints.length > 0) {
    if (basePrefixInfo.found) {
      for (const bp of basePrefixInfo.values.slice(0, 3)) {
        const pairs = [];
        for (const e of endpoints.slice(0, 3)) pushPair(pairs, joinUrlPath(bp, e), e);
        if (pairs.length > 0) groups.push({ prefix: bp, pairs, allGroupsMustPass: true });
      }
    } else {
      const pairs = [];
      for (const e of endpoints.slice(0, 3)) {
        pushPair(pairs, e, e);
        for (const p of prefixes.slice(0, 3)) pushPair(pairs, joinUrlPath(p, e), e);
      }
      if (pairs.length > 0) groups.push({ prefix: null, pairs, allGroupsMustPass: false });
    }
  } else {
    console.error('[warning] no parameterless @GetMapping endpoints discovered; probing bare prefixes');
    const pairs = [];
    for (const p of prefixes.slice(0, 3)) pushPair(pairs, p, p);
    if (pairs.length > 0) groups.push({ prefix: null, pairs, allGroupsMustPass: false });
  }
  if (groups.length === 0) return;

  let sawHtmlFallback = false;
  let sawIngressUnreachable = false;
  let ingressResponded = 0;
  let sawDoublePrefix = false;
  const details = [];
  let fallbackGroupPassed = false;
  const failedGroups = [];
  for (const group of groups) {
    let groupPassed = false;
    for (const pair of group.pairs) {
      const ingressUrl = new URL(pair.browserPath, ingress).href;
      const directUrl = `http://127.0.0.1:${backendPort}${pair.backendPath}`;
      const [viaIngress, direct] = await Promise.all([
        httpGetViaProxy(ingressUrl, 8000),
        httpGetDirect(directUrl, 8000),
      ]);
      if (!viaIngress) sawIngressUnreachable = true;
      if (viaIngress) ingressResponded++;
      if (viaIngress && direct) {
        if (viaIngress.status === direct.status && viaIngress.contentType === direct.contentType) {
          groupPassed = true; // 该组链路证明通过（status + content-type 与直连一致）
          break;
        }
        if (isHtmlContentType(viaIngress.contentType) && !isHtmlContentType(direct.contentType)) {
          sawHtmlFallback = true;
        }
      }
      // 双前缀特征：browserPath = P + backendPath 且 backendPath 本身以 P 开头
      const seg = pair.browserPath.split('/').filter(Boolean);
      const backSeg = pair.backendPath.split('/').filter(Boolean);
      if (seg.length === backSeg.length + 1 && backSeg.length > 0
        && seg[0] === backSeg[0] && `/${backSeg.join('/')}` === pair.backendPath) {
        sawDoublePrefix = true;
      }
      details.push(
        `${pair.browserPath}: ingress ${viaIngress ? `${viaIngress.status}/${viaIngress.contentType || '?'}` : 'unreachable'}`
        + ` vs direct ${direct ? `${direct.status}/${direct.contentType || '?'}` : 'unreachable'}`,
      );
    }
    group.passed = groupPassed;
    if (groupPassed && !group.allGroupsMustPass) fallbackGroupPassed = true;
    if (!groupPassed && group.allGroupsMustPass) {
      failedGroups.push(String(group.prefix === '' ? "(empty)" : group.prefix));
    }
  }
  // 回退形态（无线索）：任一组成功即整体通过；确定形态：全部组通过才整体通过
  if (groups.every((g) => g.passed) || fallbackGroupPassed) return;

  const summary = details.join('; ');
  const doublePrefixHint = sawDoublePrefix
    ? ' Detected a doubled path prefix (browserPath = prefix + backendPath where backendPath already starts with the same prefix): the browser baseURL relative prefix must be flattened to empty — request paths already carry the prefix (path equivalence).'
    : '';
  const groupHint = failedGroups.length > 0
    ? ` The browser baseURL prefix value(s) [${failedGroups.join(', ')}] did not reach the backend consistently.`
    : '';
  if (sawHtmlFallback) {
    failures.push({
      type: 'ingress-api-spa-fallback',
      reason: `API request through the external ingress ${ingressSource} (${ingress.href}) hit the SPA fallback (HTML from frontend) instead of the backend — the browser api prefix is not proxied. Ensure every discovered prefix (${prefixes.join(', ')}) is proxied by the frontend dev/preview server to http://127.0.0.1:${backendPort}.${groupHint}${doublePrefixHint} detail: ${summary}`,
    });
  } else if (sawIngressUnreachable && ingressResponded === 0) {
    failures.push({
      type: 'ingress-api-unreachable',
      reason: `cannot reach the backend API through the external ingress ${ingressSource} (${ingress.href}) — the external entry or the frontend proxy chain is broken (probed prefixes: ${prefixes.join(', ')}).${groupHint} detail: ${summary}`,
    });
  } else {
    failures.push({
      type: 'ingress-api-mismatch',
      reason: `API response through the external ingress ${ingressSource} (${ingress.href}) differs from the direct backend response (status/content-type) — the external chain is broken or serving wrong content (probed prefixes: ${prefixes.join(', ')}).${groupHint}${doublePrefixHint} detail: ${summary}`,
    });
  }
}

async function checkConfigRewrite(projectArtifactDir) {
  const failures = [];

  // 保持原样：前后端目录读清单实际值（manifest 优先 + 固定名兜底，老数据可用）。
  const manifestDirs = readManifestAppDirs(projectArtifactDir);
  const backendDir = manifestDirs.backend
    ?? (process.env.APP_NAME ? path.join(projectArtifactDir, `${process.env.APP_NAME}-backend`) : null);
  const frontendDir = manifestDirs.frontend
    ?? (process.env.APP_NAME ? path.join(projectArtifactDir, `${process.env.APP_NAME}-frontend`) : null);

  // 两路皆不可定位 → 硬失败（不要静默通过）
  if (!backendDir && !frontendDir) {
    console.log(JSON.stringify({
      ok: false,
      failures: [{
        type: 'env-missing',
        reason: 'cannot locate backend/frontend dirs (apps-manifest.json unreadable and APP_NAME unset)',
      }],
    }));
    process.exit(1);
  }

  let deployPorts;
  try {
    deployPorts = readDeployServicePorts(readDeployManifestForChecker(projectArtifactDir));
  } catch (error) {
    console.log(JSON.stringify({ ok: false, failures: [{ type: 'deploy-manifest-read', reason: error.message }] }));
    process.exit(1);
  }

  // 1. 后端 application.yml server.port 必须 = 对应服务 deploy.json 监听值。
  //    多后端：deploy.json 含 backend 服务监听值时逐服务验（服务目录 = apps-manifest 同名
  //    rootDir 或 sourceDir 归属，定位不到则跳过该服务）；无 deploy.json 端口时回退单后端
  //    6003（单服务存量语义不变）。
  function checkBackendPortInDir(dir, expectedPort, label) {
    const resDir = path.join(dir, 'src', 'main', 'resources');
    if (!fs.existsSync(resDir)) return;
    const mainYmls = fs.readdirSync(resDir).filter((f) =>
      f === 'application.yml' || f === 'application.yaml' || f === 'application.properties',
    );
    for (const f of mainYmls) {
      const full = path.join(resDir, f);
      const text = fs.readFileSync(full, 'utf-8');
      if (f.endsWith('.properties')) {
        const m = /^server\.port\s*=\s*(\d+)/m.exec(text);
        if (!m || Number(m[1]) !== expectedPort) {
          failures.push({
            type: 'backend-port',
            file: full,
            reason: `${label} server.port must be ${expectedPort}, got ${m ? m[1] : 'unset'}`,
          });
        }
      } else {
        // yml
        const lines = text.split('\n');
        let inServer = false;
        let found = null;
        for (const line of lines) {
          if (/^server:\s*$/.test(line)) { inServer = true; continue; }
          if (inServer) {
            const indent = line.search(/\S/);
            if (indent === -1) continue;
            if (indent === 0) { inServer = false; continue; }
            const m = /^\s+port:\s*(\d+)/.exec(line);
            if (m) { found = Number(m[1]); break; }
          }
        }
        if (found !== expectedPort) {
          failures.push({
            type: 'backend-port',
            file: full,
            reason: `${label} server.port must be ${expectedPort}, got ${found ?? 'unset'}`,
          });
        }
      }
    }
  }
  if (backendDir && fs.existsSync(backendDir)) {
    const deployBackends = deployPorts.filter((s) => s.serviceType === 'backend');
    if (deployBackends.length > 1) {
      // 多后端：按 apps-manifest rootDir 定位各服务目录（sourceDir 归属优先、rootDir 名含服务名兜底）
      let manifestApps = [];
      try {
        const m = JSON.parse(fs.readFileSync(path.join(projectArtifactDir, '.initialize', 'apps-manifest.json'), 'utf-8'));
        if (Array.isArray(m.apps)) manifestApps = m.apps;
      } catch {}
      for (const s of deployBackends) {
        const hit = manifestApps.find((a) => a && (a.kind === 'backend' || a.kind === 'unified')
          && typeof a.rootDir === 'string'
          && (a.rootDir === s.serviceName || a.rootDir.endsWith(`/${s.serviceName}`) || s.serviceName.endsWith(a.rootDir)));
        const dir = hit ? path.join(projectArtifactDir, hit.rootDir) : null;
        if (dir && fs.existsSync(dir)) {
          checkBackendPortInDir(dir, s.port, `backend ${s.serviceName}`);
        } else {
          console.error(`[warning] backend service ${s.serviceName} dir not located; skip server.port check`);
        }
      }
    } else if (deployBackends.length === 1) {
      checkBackendPortInDir(backendDir, deployBackends[0].port, 'backend');
    } else {
      // 无 deploy.json 后端端口 → 硬失败（不再回退 6003）
      failures.push({
        type: 'backend-port',
        source: 'deploy-json',
        reason: 'deploy.json has no backend service http port; cannot determine server.port target (no fallback)',
      });
    }
  }

  // 2. 前端 dev server 端口 = 6002
  //    - Vite: vite.config.{ts,js,mjs} 里 server.port
  //    - CRA: package.json 里 "scripts": "PORT=6002 react-scripts start" 或 .env 里 PORT=6002
  //    - Vue CLI: vue.config.js 里 devServer.port
  //    - Rspack: rspack.config.{js,ts,mjs} 里 devServer.port
  //    - Next.js: package.json scripts 里 next dev -p 6002
  //    M10 多端形态：dev port 检测仅主端目录（stack.json frontendMainEnd，默认 pc，
  //    无 pc 取第一个端目录）；其他端端口不动、不检测；主端无配置不强制。
  //    常规单端（frontendEnds 为空或 stack.json 读取失败）：检测前端根，现状不变。
  if (frontendDir && fs.existsSync(frontendDir)) {
    const multiEnd = readMultiEndLayout(projectArtifactDir);
    const devPortRoot = multiEnd ? path.join(frontendDir, multiEnd.main) : frontendDir;

    const pkgPath = path.join(devPortRoot, 'package.json');
    let pkg = null;
    try { pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8')); } catch {}

    let devPortDetected = null;
    let devPortSource = null;

    // Vite
    for (const cfg of ['vite.config.ts', 'vite.config.js', 'vite.config.mjs']) {
      const p = path.join(devPortRoot, cfg);
      if (!fs.existsSync(p)) continue;
      const text = fs.readFileSync(p, 'utf-8');
      const m = /server\s*:\s*\{[^}]*port\s*:\s*(\d+)/.exec(text);
      if (m) { devPortDetected = Number(m[1]); devPortSource = cfg; }

      // Host 放行断言（仅主端，DESIGN §3.7 "监听地址与 Host 放行约束"，2026-08-27 根因修复）：
      // 沙箱以 `vite preview` 承载生产预览（读 `preview.*`，与 `server.*` 不互相兜底）；
      // 只配 server.allowedHosts 会在生产预览被 Host 白名单拦截报 `Blocked request`。
      const serverBlock = extractObjectBlock(text, 'server');
      const previewBlock = extractObjectBlock(text, 'preview');

      // server.host 必须监听全网卡：写死裸字面量 '0.0.0.0'（或 true / '::'）。
      // **不接受 env 门控形态**（如 `process.env.HOST || '0.0.0.0'`）——存量出现时要求 4a 改写为裸字面量。
      // 裸字面量才能保证沙箱内 dev/生产预览恒定监听全网卡，不依赖环境变量是否注入。
      const hostRe = /host\s*:\s*(true|'0\.0\.0\.0'|"0\.0\.0\.0"|0\.0\.0\.0|'::'|"::")/m;
      if (serverBlock !== null) {
        if (!hostRe.test(serverBlock)) {
          const gotM = /host\s*:\s*([^\n,}]+)/m.exec(serverBlock);
          failures.push({
            type: 'frontend-listen-host',
            file: p,
            reason: `vite server.host must be the bare literal '0.0.0.0' (listen on all interfaces; dev + production preview; env-gated forms like \`ENV || '0.0.0.0'\` are not accepted — flatten to the literal), got ${gotM ? gotM[1].trim() : 'unset'}`,
          });
        }
      }

      // allowedHosts 断言：server 与 preview 均必须为裸字面量 `true`（放行全部合法 Host）；
      // 不得为固定域名数组/具体域名字符串，也不接受 env 门控形态。
      const assertAllowedHosts = (block, blockName) => {
        if (block === null) {
          failures.push({
            type: `frontend-${blockName}-host-allow`,
            file: p,
            reason: `vite ${blockName}.allowedHosts missing — must be the bare literal \`true\` (allow all legit hosts); sandbox runs \`vite preview\` reading \`preview.*\`, server/preview do not fall back (Blocked request root cause)`,
          });
          return;
        }
        const ahM = /allowedHosts\s*:\s*(true|'[^']*'|"[^"]*"|\[[\s\S]*?\])/m.exec(block);
        if (!ahM) {
          failures.push({
            type: `frontend-${blockName}-host-allow`,
            file: p,
            reason: `vite ${blockName}.allowedHosts must be the bare literal \`true\` (allow all legit hosts); env-gated forms like \`ENV || true\` are not accepted — flatten to the literal`,
          });
        } else if (ahM[1] !== 'true') {
          const kind = ahM[1].startsWith('[') ? 'domain array' : 'domain string';
          failures.push({
            type: `frontend-${blockName}-host-allow`,
            file: p,
            reason: `vite ${blockName}.allowedHosts must be the bare literal \`true\` (allow all legit hosts), got fixed ${kind} (${ahM[1]}) — fixed domain arrays/strings are forbidden (sandbox proxy domain varies by tenant/env)`,
          });
        }
      };
      assertAllowedHosts(serverBlock, 'server');
      assertAllowedHosts(previewBlock, 'preview');
      break; // 第一个存在的 vite.config.* 即主端配置，不再继续探测其它扩展名
    }

    // Vue CLI
    if (devPortDetected == null) {
      for (const cfg of ['vue.config.js', 'vue.config.ts']) {
        const p = path.join(devPortRoot, cfg);
        if (fs.existsSync(p)) {
          const text = fs.readFileSync(p, 'utf-8');
          const m = /devServer\s*:\s*\{[^}]*port\s*:\s*(\d+)/.exec(text);
          if (m) { devPortDetected = Number(m[1]); devPortSource = cfg; break; }
        }
      }
    }

    // Rspack（rspack.config.{js,ts,mjs}）
    // Host 放行断言（仅主端，DESIGN §3.7）：rspack 无独立 preview 配置块，dev 直读 devServer；
    // 生产预览命令重建 devServer 丢弃 allowedHosts（阶段六 start.sh 幂等补丁透传承载）——配置层
    // 保证 devServer.allowedHosts 存在且裸 'all'：缺失/域名数组/env 门控形态 → 失败。
    // 构建栈互斥（防其他构建栈误报）：主端存在 vite.config.* / vue.config.* 时本项目以
    // Vite / Vue CLI 为权威构建栈，rspack.config.* 视为迁移残留——跳过 rspack 断言与
    // devPort 检测（与 4a prompt 的构建工具判定顺序对齐：Vite/Vue CLI 优先于 Rspack）。
    {
      let rspackConfigPath = null;
      for (const cfg of ['rspack.config.js', 'rspack.config.ts', 'rspack.config.mjs']) {
        const p = path.join(devPortRoot, cfg);
        if (fs.existsSync(p)) { rspackConfigPath = p; break; }
      }
      const hasOtherBuilderConfig = [
        'vite.config.ts', 'vite.config.js', 'vite.config.mjs',
        'vue.config.js', 'vue.config.ts',
      ].some((cfg) => fs.existsSync(path.join(devPortRoot, cfg)));
      if (rspackConfigPath !== null && !hasOtherBuilderConfig) {
        const text = fs.readFileSync(rspackConfigPath, 'utf-8');
        if (devPortDetected == null) {
          const m = /devServer\s*:\s*\{[^}]*port\s*:\s*(\d+)/.exec(text);
          if (m) { devPortDetected = Number(m[1]); devPortSource = path.basename(rspackConfigPath); }
        }

        const devServerBlock = extractObjectBlock(text, 'devServer');
        if (devServerBlock !== null) {
          // devServer.host 必须监听全网卡：裸字面量 '0.0.0.0'（或 true / '::'）；env 门控形态不接受。
          const hostRe = /host\s*:\s*(true|'0\.0\.0\.0'|"0\.0\.0\.0"|0\.0\.0\.0|'::'|"::")/m;
          if (!hostRe.test(devServerBlock)) {
            const gotM = /host\s*:\s*([^\n,}]+)/m.exec(devServerBlock);
            failures.push({
              type: 'frontend-listen-host',
              file: rspackConfigPath,
              reason: `rspack devServer.host must be the bare literal '0.0.0.0' (listen on all interfaces; dev + production preview; env-gated forms like \`ENV || '0.0.0.0'\` are not accepted — flatten to the literal), got ${gotM ? gotM[1].trim() : 'unset'}`,
            });
          }

          // devServer.allowedHosts 必须为裸字面量 'all'（放行全部合法 Host）；
          // 固定域名数组/具体域名字符串/env 门控形态均不接受。
          const ahM = /allowedHosts\s*:\s*('all'|"all"|'[^']*'|"[^"]*"|\[[\s\S]*?\])/m.exec(devServerBlock);
          if (!ahM) {
            failures.push({
              type: 'frontend-rspack-host-allow',
              file: rspackConfigPath,
              reason: `rspack devServer.allowedHosts missing — must be the bare literal 'all' (allow all legit hosts); the sandbox reverse proxy preserves the original external Host header, missing allow-all rejects external access with 403 Invalid Host header`,
            });
          } else if (ahM[1] !== "'all'" && ahM[1] !== '"all"') {
            const kind = ahM[1].startsWith('[') ? 'domain array' : 'domain string';
            failures.push({
              type: 'frontend-rspack-host-allow',
              file: rspackConfigPath,
              reason: `rspack devServer.allowedHosts must be the bare literal 'all' (allow all legit hosts), got fixed ${kind} (${ahM[1]}) — fixed domain arrays/strings are forbidden (sandbox proxy domain varies by tenant/env)`,
            });
          }
        }
      }
    }

    // package.json scripts (CRA / Next.js)
    if (devPortDetected == null && pkg && pkg.scripts) {
      for (const [name, script] of Object.entries(pkg.scripts)) {
        if (typeof script !== 'string') continue;
        // PORT=6002 或 -p 6002
        const m = /(?:PORT\s*=\s*|-p\s+|--port\s+|--port=)(\d+)/.exec(script);
        if (m) { devPortDetected = Number(m[1]); devPortSource = `package.json scripts.${name}`; break; }
      }
    }

    // .env / .env.development
    if (devPortDetected == null) {
      for (const env of ['.env', '.env.development', '.env.local']) {
        const p = path.join(devPortRoot, env);
        if (fs.existsSync(p)) {
          const text = fs.readFileSync(p, 'utf-8');
          const m = /^PORT\s*=\s*(\d+)/m.exec(text);
          if (m) { devPortDetected = Number(m[1]); devPortSource = env; break; }
        }
      }
    }

    // 多端形态：主端无配置不强制（不报 frontend-dev-port）；常规单端：未检出仍报（现状）。
    // 期望值只认 deploy.json 前端监听值（无端口 → 硬失败，不回退 6002）。
    const frontendPorts = deployPorts.filter((s) => s.serviceType === 'frontend');
    const expectedFrontendPort = frontendPorts.length > 0 ? frontendPorts[0].port : null;
    if (frontendPorts.length === 0) {
      failures.push({
        type: 'frontend-dev-port',
        source: 'deploy-json',
        reason: 'deploy.json has no frontend service http port; cannot determine dev server port target (no fallback)',
      });
    } else {
      if (devPortDetected !== expectedFrontendPort && !(multiEnd && devPortDetected == null)) {
        failures.push({
          type: 'frontend-dev-port',
          source: devPortSource ?? 'not-detected',
          reason: `frontend dev server port must be ${expectedFrontendPort}, got ${devPortDetected ?? 'unset'}`,
        });
      }
    }

    // 3. 前端源码里 localhost:PORT 端口非 6003 视为违规
    //    扫描始终覆盖整个 frontendDir（M10 多端形态下各端源码/配置都查，不限于主端）
    //    2026-09-05 修复体验加固：failure 带 file:line + offending line（此前只有裸 port，
    //    agent 收到报错后反复 grep 定位、多轮重新论证例外条款——实测 23 blocks 里 17 个
    //    是排障浪费；与 frontend-browser-api-base 的报错格式对齐）
    const nonMatchingPorts = [];
    // 合法端口集合：只认 deploy.json 各服务监听值（无回退常量）。
    const legalPorts = new Set(deployPorts.map((s) => s.port));
    grepFilesRecursive(frontendDir, ['.ts', '.tsx', '.js', '.jsx', '.vue', '.env', '.env.development'], (file, text) => {
      // 简单跳过 lockfile / dist
      if (file.endsWith('.min.js')) return;
      const re = /https?:\/\/(localhost|127\.0\.0\.1)(?::(\d+))?/g;
      let m;
      while ((m = re.exec(text)) !== null) {
        if (!m[2]) continue;
        const port = Number(m[2]);
        if (!legalPorts.has(port)) {
          // 定位行号与整行内容（供 agent 直接跳改，免去重复 grep 定位）
          const upto = text.slice(0, m.index);
          const lineNo = upto.split('\n').length;
          const lineText = (text.split('\n')[lineNo - 1] || '').trim();
          nonMatchingPorts.push({ file, port, raw: m[0], line: lineNo, lineText });
        }
      }
    });
    const appName = path.basename(path.resolve(projectArtifactDir));
    const registryPorts = readServiceRegistryPorts(projectArtifactDir);
    const formalPortHint = registryPorts.length > 0
      ? `${appName}-services.json (current value: ${registryPorts.join('/')})`
      : `${appName}-services.json (unavailable; manifest frontend port fallback: ${expectedFrontendPort ?? 'none'})`;
    for (const item of nonMatchingPorts.slice(0, 20)) {
      failures.push({
        type: 'frontend-hardcoded-port',
        file: item.file,
        reason: `frontend contains hardcoded localhost:${item.port} — the formal port must come from ${formalPortHint}, not be baked into source; connectPort is a dynamic runtime value and the formal port is injected via the PORT env at runtime, so neither may be hardcoded into vite.config.js or other source. offending line (${item.file}:${item.line}): ${item.lineText}`,
      });
    }
    if (nonMatchingPorts.length > 20) {
      failures.push({
        type: 'frontend-hardcoded-port-truncated',
        reason: `${nonMatchingPorts.length - 20} more occurrences omitted`,
      });
    }

    // 3b. 浏览器消费面 API base 静态断言（2026-09-04 根因修复）：
    //     .env* 的浏览器注入 API base 变量与 src 中 API client（baseURL / fetch / axios）
    //     禁止出现 localhost/127.0.0.1 绝对后端地址——这些值构建期烤进浏览器产物，
    //     localhost 只在沙箱内有效，外部浏览器解析到访问者本机 → ERR_NETWORK
    //     （gaoma 线上实测：全部 checker 绿但外部访问 Network Error）。
    //     服务端代理目标（vite/vue/next/webpack config 里的 proxy target，指向 deploy.json
    //     后端监听值）是合法落点，不在此断言范围；test/e2e/scripts 目录与 .min.js 不扫；
    //     URL 仅作为参数传给后端服务端转发的行（无 baseURL/fetch/axios token）不误伤
    //     （与 build 阶段 dist 扫描口径一致）。
    const browserApiBaseViolations = [];
    const BROWSER_SCAN_SKIP_SEGMENTS = new Set([
      'test', 'tests', '__tests__', 'e2e', 'cypress', 'mock', 'mocks', 'scripts', '.specify',
    ]);
    const isBrowserApiScanTarget = (file) => {
      const base = path.basename(file);
      if (/^(vite|vue|next|webpack|rspack|turbo|metro|babel|jest|vitest|tailwind|postcss)\.config\./.test(base)) return false;
      if (/\.(test|spec)\.[cm]?[jt]sx?$/.test(base)) return false;
      if (base.endsWith('.min.js')) return false;
      return !file.split(path.sep).some((seg) => BROWSER_SCAN_SKIP_SEGMENTS.has(seg));
    };
    const ABS_LOCAL_URL_RE = /https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?/i;
    // 外部入口域名（APP_FE_INGRESS_URL 的 host，2026-09-05 补）：浏览器消费面 API base
    // 同样禁止——与 localhost:6003 对偶的镜像错误（agent「正确地」把入口域名写进 baseURL）；
    // 域随租户/环境可变，构建期烤死换域必复发。env 未注入时跳过该维度（本地跑测试等场景）。
    const ingressHost = (() => {
      const raw = String(process.env.APP_FE_INGRESS_URL || '').trim();
      if (!raw) return null;
      try {
        const u = new URL(raw);
        return u.host ? u.host.toLowerCase() : null;
      } catch { return null; }
    })();
    const bannedBaseKind = (text) => {
      if (ABS_LOCAL_URL_RE.test(text)) return 'absolute-local';
      if (ingressHost && String(text).toLowerCase().includes(ingressHost)) return 'ingress-host';
      return null;
    };
    const ENV_API_BASE_LINE_RE = /^(?:VITE|REACT_APP|VUE_APP|NEXT_PUBLIC)_[A-Z0-9_]*API[A-Z0-9_]*(?:BASE[A-Z0-9_]*)?URL\s*=\s*(.*)$/;
    const SRC_API_TOKEN_RE = /baseURL|baseUrl|base_url|BASE_URL|fetch\s*\(|axios/;
    grepFilesRecursive(
      frontendDir,
      ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.vue', '.env', '.env.development', '.env.local', '.env.example'],
      (file, text) => {
        if (!isBrowserApiScanTarget(file)) return;
        const isEnvFile = path.basename(file).startsWith('.env');
        const lines = text.split('\n');
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          if (!bannedBaseKind(line)) continue;
          if (isEnvFile) {
            const m = ENV_API_BASE_LINE_RE.exec(line.trim());
            if (m && bannedBaseKind(m[1])) {
              browserApiBaseViolations.push({ file, line: i + 1, raw: line.trim(), kind: bannedBaseKind(m[1]) });
            }
          } else if (SRC_API_TOKEN_RE.test(line)) {
            browserApiBaseViolations.push({ file, line: i + 1, raw: line.trim(), kind: bannedBaseKind(line) });
          }
        }
      },
    );
    for (const v of browserApiBaseViolations.slice(0, 20)) {
      const why = v.kind === 'ingress-host'
        ? `the external ingress host (${ingressHost}, from APP_FE_INGRESS_URL) must never be baked into browser-consumed API base config — it varies by tenant/environment and the page origin already IS the ingress; use same-origin relative paths`
        : `an absolute backend address gets baked into browser artifacts at build time and breaks external access (ERR_NETWORK)`;
      // 代理目标按服务列监听值（读 deploy.json 后端监听值；无则不写具体值，只给方向）。
      const backendPorts = deployPorts.filter((s) => s.serviceType === 'backend');
      const proxyHint = backendPorts.length > 0
        ? ` (targets http://127.0.0.1:${backendPorts.map((s) => s.port).join(' / http://127.0.0.1:')})`
        : '';
      failures.push({
        type: 'frontend-browser-api-base',
        file: v.file,
        reason: `browser-consumed API base must be same-origin relative (empty or a relative prefix like '/api'); ${why}. Route it through the frontend dev/preview server proxy${proxyHint}. offending line (${v.file}:${v.line}): ${v.raw}`,
      });
    }
    if (browserApiBaseViolations.length > 20) {
      failures.push({
        type: 'frontend-browser-api-base-truncated',
        reason: `${browserApiBaseViolations.length - 20} more occurrences omitted`,
      });
    }

    // 3c. 双前缀静态断言（2026-09-05 根因修复）：
    //     浏览器 baseURL 相对前缀 P + 业务请求 path 字面量以 P 开头 → 浏览器最终请求
    //     /P/P/... → 后端 No static resource 500（gaoma 线上实测：baseURL='/api' +
    //     path='/api/db/mysql/list' → /api/api/db/mysql/list）。
    //     P 来源：.env* API base 变量相对前缀值 + src baseURL 赋值行相对字面量（含 `|| '/api'` 兜底）；
    //     请求 path 扫描范围收窄：行含请求 token（path:/url:/fetch(/axios/.get(/.post( 等）且
    //     字符串字面量以 P/ 开头；router/routes 目录跳过（SPA 路由 path 不过 baseURL 拼接）；
    //     P 为空串不参与（无前缀可叠）。
    const basePrefixInfo = discoverBrowserBasePrefixes(frontendDir);
    const doublePrefixCandidates = basePrefixInfo.values.filter((v) => v !== '');
    const doublePrefixViolations = [];
    if (doublePrefixCandidates.length > 0) {
      const REQ_PATH_TOKEN_RE = /(?:path|url)\s*:\s*|fetch\s*\(|axios|\.(?:get|post|put|patch|delete)\s*\(|request\s*\(/i;
      const skipSegments = new Set([...BROWSER_SCAN_SKIP_SEGMENTS, 'router', 'routes']);
      const isReqPathScanTarget = (file) => {
        const base = path.basename(file);
        if (/\.(test|spec)\.[cm]?[jt]sx?$/.test(base)) return false;
        if (base.endsWith('.min.js')) return false;
        return !file.split(path.sep).some((seg) => skipSegments.has(seg));
      };
      for (const P of doublePrefixCandidates) {
        const pathLitRe = new RegExp(`["']${P.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}/[^"']+["']`);
        grepFilesRecursive(
          frontendDir,
          ['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs', '.vue'],
          (file, text) => {
            if (doublePrefixViolations.some((v) => v.file === file && v.prefix === P)) return;
            if (!isReqPathScanTarget(file)) return;
            const lines = text.split('\n');
            for (let i = 0; i < lines.length; i++) {
              if (!REQ_PATH_TOKEN_RE.test(lines[i])) continue;
              if (pathLitRe.test(lines[i])) {
                doublePrefixViolations.push({ file, line: i + 1, prefix: P, raw: lines[i].trim() });
                break; // 每文件每前缀只记一条（修复指引一致：baseURL 回退空串）
              }
            }
          },
        );
      }
    }
    for (const v of doublePrefixViolations.slice(0, 20)) {
      failures.push({
        type: 'frontend-api-base-double-prefix',
        file: v.file,
        reason: `browser API base prefix '${v.prefix}' is doubled onto request paths that already start with it (browser final path ${v.prefix}${v.prefix}/... -> backend No static resource 500). The project's request paths already carry the prefix, so the baseURL relative prefix must be flattened to empty (path equivalence). offending line (${v.file}:${v.line}): ${v.raw}`,
      });
    }

    // 4. package.json 依赖改写条目两层断言（#289，DESIGN §5.15 B + §5.2 G3 断言改造）：
    //    layer-1（file-refs.json 快照，快照值 = 阶段三闭环改写的 name@version）：
    //    改写键存在 + 值恒等（键缺失或值变化 → file-reference-changed；4a 不得 clobber
    //    闭环 checker 写入的 name@version / npm:name@version 声明）。快照不存在 → 跳过
    //    （无 bundled 改写场景）。原 H3 硬断言（源码 file: 键值不变 + 本地目标存在性）
    //    随 #289 bundled 改写语义移除——由 layer-1 快照恒等 + layer-2 resolve 承担。
    //    layer-2：非 file: 的裸版本号 / npm:name@version 别名值须可从 registry resolve
    //    （npm view 404 → registry-unresolvable；网络错误/超时 → 放行，阶段六兜底）；
    //    区间（^x.y.z）/ 星号 / git / workspace 值不校验（公共依赖由 nexus group 代理直拉）。
    //    硬拦范围收窄（#289 Task3 review I-1）：registry-unresolvable 硬失败仅限
    //    ① file-refs.json 快照键、② libs-required.json publish 集坐标（= #289 改写的
    //    name@version，必须可从 nexus resolve，agent 唯一修复通道是重跑闭环 publish）；
    //    其余精确版本依赖（源码自带公共依赖）404 → stderr warn 放行（阶段六兜底）——
    //    nexus group 未代理某公共包是平台侧配置问题，agent 不可修复，硬拦 = 10 轮
    //    无效重试死锁。
    //    整体预算（I-3）：npm view 逐个累加耗时，超预算（默认 90s，可经
    //    INITIALIZE_NPM_VIEW_BUDGET_MS 覆盖）后剩余候选转 warn 放行——外层 wrapper
    //    checker（script-checker.ts）对整个脚本有 120s 硬超时，不收口会被外层先杀
    //    进程、产出无诊断的 killed 死锁；预算内硬拦候选优先消费（排序前置）。
    const fileRefsPath = path.join(projectArtifactDir, '.initialize', 'file-refs.json');
    let fileRefsSnapshot = null;
    try {
      fileRefsSnapshot = JSON.parse(fs.readFileSync(fileRefsPath, 'utf-8'));
    } catch { /* 无快照 → 跳过快照比对 */ }
    if (
      fileRefsSnapshot && typeof fileRefsSnapshot === 'object'
      && Array.isArray(fileRefsSnapshot.refs)
    ) {
      const snapPkgPath = typeof fileRefsSnapshot.frontendPackageJson === 'string'
        ? path.resolve(projectArtifactDir, fileRefsSnapshot.frontendPackageJson)
        : pkgPath;
      let snapPkg = null;
      try {
        snapPkg = JSON.parse(fs.readFileSync(snapPkgPath, 'utf-8'));
      } catch { /* package.json 缺失/不可解析 → 全部视为键缺失 */ }
      const snapDeps = snapPkg && snapPkg.dependencies
        && typeof snapPkg.dependencies === 'object' && !Array.isArray(snapPkg.dependencies)
        ? snapPkg.dependencies
        : {};
      for (const ref of fileRefsSnapshot.refs) {
        if (!ref || typeof ref !== 'object' || typeof ref.key !== 'string') continue;
        const current = snapDeps[ref.key];
        if (current !== ref.value) {
          failures.push({
            type: 'file-reference-changed',
            field: `dependencies.${ref.key}`,
            reason: `name@version 依赖被修改（原值 ${ref.value}，当前 ${current === undefined ? '键已删除' : current}）——4a 不得 clobber 阶段三依赖闭环 checker 写入的 name@version 声明`,
          });
        }
      }
    }
    if (pkg && pkg.dependencies && typeof pkg.dependencies === 'object' && !Array.isArray(pkg.dependencies)) {
      // layer-2：name@version 依赖可从 registry resolve（精确版本值与 npm: 别名值）。
      // 硬拦范围（I-1 收窄）：file-refs.json 快照键 + libs-required.json publish 集坐标。
      const registry = process.env.NPM_CONFIG_REGISTRY || readNpmrcRegistryLoose();
      const EXACT_VERSION_RE = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;
      const hardBlockDepKeys = new Set();
      if (
        fileRefsSnapshot && typeof fileRefsSnapshot === 'object'
        && Array.isArray(fileRefsSnapshot.refs)
      ) {
        for (const ref of fileRefsSnapshot.refs) {
          if (ref && typeof ref === 'object' && typeof ref.key === 'string') {
            hardBlockDepKeys.add(ref.key);
          }
        }
      }
      // publish 集坐标（与 TS collectPublishableTgzPaths 同语义：bundled 项 + resolved
      // missing 项、文件就位、以 tgz 内容 name@version 为准——清单 coordinate 是路径推导值
      // 不可靠）。libs-required.json 缺失/损坏 → 空集（仅快照键硬拦），不 fail。
      const publishSetCoords = new Set();
      try {
        const libsRequired = JSON.parse(
          fs.readFileSync(path.join(projectArtifactDir, '.initialize', 'libs-required.json'), 'utf-8'),
        );
        const libReqs = Array.isArray(libsRequired && libsRequired.requirements)
          ? libsRequired.requirements
          : [];
        for (const libReq of libReqs) {
          if (!libReq || typeof libReq !== 'object') continue;
          if (libReq.kind !== 'frontend' || libReq.resolveStrategy !== 'local-tarball') continue;
          if (typeof libReq.expectedPath !== 'string' || !libReq.expectedPath) continue;
          const tgzAbs = path.join(projectArtifactDir, libReq.expectedPath);
          const closed = fs.existsSync(tgzAbs)
            && (libReq.status === 'bundled' || libReq.resolved === true);
          if (!closed) continue;
          const tgzPkg = readTgzPackageJson(tgzAbs);
          if (tgzPkg) publishSetCoords.add(`${tgzPkg.name}@${tgzPkg.version}`);
        }
      } catch { /* 无 libs-required.json / 不可解析 → 无 publish 集坐标 */ }
      const isHardBlockCandidate = (c) =>
        hardBlockDepKeys.has(c.depKey) || publishSetCoords.has(`${c.name}@${c.version}`);
      const candidates = [];
      for (const [key, value] of Object.entries(pkg.dependencies)) {
        if (typeof value !== 'string' || value.startsWith('file:')) continue;
        if (value.startsWith('npm:')) {
          const inner = value.slice('npm:'.length);
          const at = inner.lastIndexOf('@');
          if (at > 0 && EXACT_VERSION_RE.test(inner.slice(at + 1))) {
            candidates.push({ depKey: key, name: inner.slice(0, at), version: inner.slice(at + 1) });
          }
        } else if (EXACT_VERSION_RE.test(value)) {
          candidates.push({ depKey: key, name: key, version: value });
        }
      }
      if (candidates.length > 0 && registry) {
        // 整体预算（I-3）：硬拦候选排序前置优先消费预算；超预算的剩余候选 warn 放行。
        const configuredBudgetMs = Number(process.env.INITIALIZE_NPM_VIEW_BUDGET_MS);
        const budgetMs = configuredBudgetMs > 0 ? configuredBudgetMs : 90000;
        let spentMs = 0;
        candidates.sort((a, b) => Number(isHardBlockCandidate(b)) - Number(isHardBlockCandidate(a)));
        const seen = new Set();
        for (const { depKey, name, version } of candidates) {
          const coord = `${name}@${version}`;
          if (seen.has(coord)) continue;
          seen.add(coord);
          if (spentMs >= budgetMs) {
            console.error(`[warning] npm view 整体预算（${budgetMs}ms）已耗尽——${coord} 跳过 resolve 校验（放行），阶段六 npm install 兜底`);
            continue;
          }
          const startedAt = Date.now();
          const verdict = await npmViewResolvable(name, version, registry);
          spentMs += Date.now() - startedAt;
          if (verdict === 'missing') {
            if (isHardBlockCandidate({ depKey, name, version })) {
              failures.push({
                type: 'registry-unresolvable',
                field: `dependencies.${depKey}`,
                reason: `name@version 依赖 registry 无法解析（${coord}，registry=${registry}，npm view 404）：阶段三 publish 未完成或 registry 未同源（§5.15 E/F）；不得改回 file:/区间值`,
              });
            } else {
              // 非改写项（源码自带公共依赖）不硬拦：nexus group 未代理该公共包属平台侧
              // 配置问题，agent 不可修复——warn 放行，阶段六 npm install 兜底。
              console.error(`[warning] 源码自带公共依赖 ${coord} registry 无法解析（npm view 404）——非 #289 改写项不硬拦（放行），阶段六 npm install 兜底`);
            }
          } else if (verdict === 'unknown') {
            console.error(`[warning] npm view ${coord} 超时/网络错误——layer-2 不判定（放行），阶段六 npm install 兜底`);
          }
        }
      } else if (candidates.length > 0) {
        console.error('[warning] npm registry 未配置（NPM_CONFIG_REGISTRY / ~/.npmrc）——name@version 依赖 resolve 校验跳过（放行），阶段六兜底');
      }
    }
  }

  if (failures.length > 0) {
    console.log(JSON.stringify({ ok: false, failures }));
    process.exit(1);
  }
  console.log(JSON.stringify({ ok: true }));
  process.exit(0);
}

// ---------- runtime-connectivity subcommand ----------

/**
 * 用 Node http.get 探测端口（避免依赖沙箱镜像内 curl）。
 * 接收 probePath，返回 { status, errorCode }（曾收到响应则 status 非 null）。
 * 超时归一为 'TIMEOUT'：destroy() 之后 'error' 事件以 ECONNRESET（socket hang up）
 * 触发——原样透出会把「服务仍在启动中」误读成「服务已退出/端口被抢占」（正是本
 * 修复要消除的盲修诱因），故以 timedOut 标记保证超时语义不被 error 分支抢答；
 * 'timeout' 分支只置标记 + destroy，不 resolve（首个 resolve 胜出即错）。
 */
function httpProbe(host, port, probePath, timeoutMs = 5000) {
  return new Promise((resolve) => {
    let timedOut = false;
    const req = http.get({ host, port, path: probePath, timeout: timeoutMs }, (res) => {
      resolve({ status: res.statusCode ?? null, errorCode: null });
      res.resume();  // 丢弃响应体
    });
    req.on('error', (e) => resolve({ status: null, errorCode: timedOut ? 'TIMEOUT' : (e?.code || 'UNKNOWN') }));
    req.on('timeout', () => { timedOut = true; req.destroy(); });
  });
}

/**
 * 解析后端目录（三段式，与 probeIngressApiChain 同形）：
 * manifest.apps[] 中 kind==='backend' 的 rootDir → 否则 `${APP_NAME}-backend` → 否则 null。
 * 每段都先做非空校验（path.join(null, ...) 会抛 ERR_INVALID_ARG_TYPE）。
 */
function resolveBackendDir(projectArtifactDir, manifest) {
  const apps = manifest && Array.isArray(manifest.apps) ? manifest.apps : [];
  const beApp = apps.find((a) => a && (a.kind === 'backend' || a.kind === 'unified') && typeof a.rootDir === 'string' && a.rootDir);
  if (beApp) return path.join(projectArtifactDir, beApp.rootDir);
  if (process.env.APP_NAME) return path.join(projectArtifactDir, `${process.env.APP_NAME}-backend`);
  return null;
}

/**
 * 解析前后端目录（一对，与 resolveBackendDir 同源）：
 * manifest.apps[] 中 kind==='backend'/'unified' 与 kind==='frontend' 的 rootDir。
 * 保持原样：rootDir 为实际相对路径（允许嵌套）；读不到返回 null 字段（调用方兜底固定名）。
 */
function readManifestAppDirs(projectArtifactDir) {
  let manifest = null;
  try {
    manifest = readJson(path.join(projectArtifactDir, '.initialize', 'apps-manifest.json'), 'apps-manifest.json');
  } catch {
    return { backend: null, frontend: null };
  }
  const apps = manifest && Array.isArray(manifest.apps) ? manifest.apps : [];
  const beApp = apps.find((a) => a && (a.kind === 'backend' || a.kind === 'unified') && typeof a.rootDir === 'string' && a.rootDir);
  const feApp = apps.find((a) => a && a.kind === 'frontend' && typeof a.rootDir === 'string' && a.rootDir);
  return {
    backend: beApp ? path.join(projectArtifactDir, beApp.rootDir) : null,
    frontend: feApp ? path.join(projectArtifactDir, feApp.rootDir) : null,
  };
}

/**
 * 构造后端探测候选路径（按优先级）：/api/health → 发现的无参 @GetMapping（最短一条，
 * 叠 server.servlet.context-path）→ '/' 兜底。旧实现硬编码 '/'，根路径未映射的应用
 * （No static resource . → 异常处理器兜 500）会被误判 unreachable（2026-09-21 C1 根因）。
 */
function buildBackendProbePaths(projectArtifactDir, manifest) {
  const paths = ['/api/health'];
  const backendDir = resolveBackendDir(projectArtifactDir, manifest);
  if (backendDir) {
    const ctxPath = readServerContextPath(backendDir);
    const endpoints = discoverBackendGetEndpoints(backendDir);  // 已按长度升序
    if (endpoints.length > 0) paths.push(joinUrlPath(ctxPath, endpoints[0]));
  }
  paths.push('/');  // 兜底
  return [...new Set(paths)];
}

/**
 * 从部署契约返回的完整 Manifest 投影已登记的 HTTP 监听端口。
 * 无服务/无已登记端口时返回空数组，由调用方兼容旧应用默认端口。
 */
function readDeployServicePorts(manifest) {
  const out = [];
  for (const service of manifest.services) {
    const httpPort = service.runtime?.ports?.find((port) => port.protocol === 'http' && Number.isInteger(port.port));
    if (httpPort) {
      out.push({ serviceName: service.serviceName, serviceType: service.serviceType, port: httpPort.port });
    }
  }
  return out;
}

/**
 * 读应用目录 `<appName>-services.json`（服务清单；service-manager / test-helper 的「正式端口」
 * 权威源）中的端口集合，供 frontend-hardcoded-port 回灌文案引用当前值。
 * appName 取 `projectArtifactDir` 的 basename（与 `project.ts` 落点 `${appName}-services.json` 同源）。
 * 文件缺失/损坏/条目无有效 port → []（调用方回退 deploy.json 前端监听值，存量不误伤）。
 */
function readServiceRegistryPorts(projectArtifactDir) {
  const appName = path.basename(path.resolve(projectArtifactDir));
  try {
    const raw = JSON.parse(fs.readFileSync(path.join(projectArtifactDir, `${appName}-services.json`), 'utf-8'));
    const list = Array.isArray(raw) ? raw : (Array.isArray(raw && raw.services) ? raw.services : []);
    return list
      .map((s) => Number(s && s.port))
      .filter((n) => Number.isInteger(n) && n > 0);
  } catch {
    return [];
  }
}

async function checkRuntimeConnectivity(projectArtifactDir) {
  const failures = [];
  let deployPorts;
  try {
    deployPorts = readDeployServicePorts(readDeployManifestForChecker(projectArtifactDir));
  } catch (error) {
    console.log(JSON.stringify({ ok: false, failures: [{ type: 'deploy-manifest-read', reason: error.message }] }));
    process.exit(1);
  }
  // 测试 env 覆盖缝（动态空闲端口注入，避免宿主机端口占用导致测试假红，#305）；
  // 生产不设，端口只认 deploy.json（无端口 → 硬失败，不回退 6002/6003）。
  const ENV_FRONTEND_PORT = Number.parseInt(process.env.CHECK_INITIALIZE_FRONTEND_PORT ?? '', 10);
  const ENV_BACKEND_PORT = Number.parseInt(process.env.CHECK_INITIALIZE_BACKEND_PORT ?? '', 10);
  // 单次探测超时（ms）；env 缝供测试注入短超时，避免 5s × 5 轮拖慢用例
  const PROBE_TIMEOUT_MS = Number.parseInt(process.env.CHECK_INITIALIZE_PROBE_TIMEOUT_MS ?? '', 10) || 5000;
  // 轮转间隔（ms）；env 缝供测试注入短间隔，避免 1s × 4 次 sleep 拖慢用例
  const PROBE_INTERVAL_MS = Number.parseInt(process.env.CHECK_INITIALIZE_PROBE_INTERVAL_MS ?? '', 10) || 1000;

  // 0b. 构建产物新鲜度（2026-10-21 根因修复）：旧 dist/jar 会让「服务能起 + health 200」
  //     掩盖本轮 build.sh 失败（hycloud12b 现场：dist 是上一轮带入的旧产物，两次
  //     vue-cli-service build 全挂仍判 done）。验收任务在 build.sh 执行前记录 startedAt
  //     并落 build-freshness.json；此处按 mtime 复核，产物早于本轮构建开始即失败。
  //     文件缺失 → 跳过（兼容无该产物的历史轮次；缺失本身由验收 prompt 硬性要求补写）。
  const freshnessFile = path.join(projectArtifactDir, '.initialize', 'build-freshness.json');
  if (fs.existsSync(freshnessFile)) {
    try {
      const stamp = JSON.parse(fs.readFileSync(freshnessFile, 'utf-8'));
      const entries = Array.isArray(stamp && stamp.services) ? stamp.services : [];
      for (const entry of entries) {
        if (!entry || typeof entry !== 'object') continue;
        const startedAtMs = Date.parse(entry.startedAt);
        if (!Number.isFinite(startedAtMs) || typeof entry.artifact !== 'string' || !entry.artifact) continue;
        const artifactPath = path.resolve(projectArtifactDir, entry.artifact);
        let artifactMtimeMs;
        try {
          artifactMtimeMs = fs.statSync(artifactPath).mtimeMs;
        } catch {
          failures.push({
            type: 'build-artifact-missing',
            service: entry.serviceName,
            reason: `artifact ${entry.artifact} recorded in build-freshness.json does not exist`,
          });
          continue;
        }
        if (artifactMtimeMs < startedAtMs) {
          failures.push({
            type: 'build-artifact-stale',
            service: entry.serviceName,
            reason: `artifact ${entry.artifact} mtime (${new Date(artifactMtimeMs).toISOString()}) is older than this round's build start (${entry.startedAt}); build.sh did not refresh it — stale dist/jar must not pass acceptance`,
          });
        }
      }
    } catch (error) {
      failures.push({ type: 'build-freshness-read', reason: `build-freshness.json 不可读：${error.message}` });
    }
  }

  // 部署 acceptance 完成到 service 稳定可能有几秒延迟；这里做 5 次探测（间隔 PROBE_INTERVAL_MS）。
  // 判据（2026-09-21 C1 根因修复）：2xx 立即成功短路；5 轮走完后若曾收到过任何 HTTP
  // 响应（端口有进程在答，哪怕 4xx/5xx）仍判通过——被探路径不映射 ≠ 服务不可用
  // （根路径未映射的应用会被异常处理器兜成 500，正是旧判据 [200,500) 误杀的形态）；
  // 仅 5 轮全是传输层错误（无任何应答）才判失败。路径按序轮转：attempt i 探
  // paths[(i-1) % paths.length]，让每个候选路径都有机会被探到。
  // 无返回值：本函数只负责推进探测，失败经 `failures` 闭包沉淀（调用点均为 await 后丢弃）。
  async function probeWithRetry(port, label, probePaths) {
    const paths = (probePaths && probePaths.length) ? probePaths : ['/'];
    const seen = [];
    let sawHttpResponse = false;
    let lastError = null;
    for (let attempt = 1; attempt <= 5; attempt++) {
      const p = paths[(attempt - 1) % paths.length];
      seen.push(p);
      const { status, errorCode } = await httpProbe('127.0.0.1', port, p, PROBE_TIMEOUT_MS);
      if (status !== null) {
        // 收到应答即达标，非 2xx 也无需记账：下方 `sawHttpResponse` 短路保证失败分支
        // 只可能由传输层错误到达，`lastError` 必须保持传输层语义（勿在此回填 HTTP 码）
        sawHttpResponse = true;
        if (status >= 200 && status < 300) return;  // 2xx 立即短路
      } else {
        lastError = { errorCode, path: p };
      }
      if (attempt < 5) await new Promise((r) => setTimeout(r, PROBE_INTERVAL_MS));
    }
    if (sawHttpResponse) return;
    // 失败 reason 分级：传输层错误码 → 诊断提示（agent 据此分流「等待启动」vs
    // 「服务未启动」vs「中途退出」，不再盲修）
    const hint = {
      TIMEOUT: '连接/响应超时——服务未响应，可能仍在启动中',
      ECONNREFUSED: '端口无进程监听——服务未启动或已退出',
      ECONNRESET: '连接被重置——服务中途退出或端口被抢占',
    }[lastError ? lastError.errorCode : ''];
    failures.push({
      type: `${label}-unreachable`,
      reason: `http://127.0.0.1:${port} not reachable after 5 attempts (probed: ${[...new Set(seen)].join(', ')}; last error: ${lastError ? lastError.errorCode : 'unknown'}${hint ? ' — ' + hint : ''})`,
    });
  }

  // manifest 先行读取（后端探测的候选路径发现与 separated 判定都依赖它；
  // 缺失/损坏 → 保持默认，不抛）
  const manifestPath = path.join(projectArtifactDir, '.initialize', 'apps-manifest.json');
  let separated = false;
  let manifest = null;
  try {
    manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    separated = manifest.kind === 'separated';
  } catch {}

  // 1. 后端必须可达（一体、分离都探测）；候选路径 = /api/health → 发现的
  //    无参 @GetMapping（叠 context-path）→ '/' 兜底，5 轮按序轮转。
  //    多后端：deploy.json 含 backend 服务监听值时逐服务探测；无 deploy.json 端口时
  //    回退 6003 单端口（单服务存量语义不变）。
  let primaryBackendPort = null;
  {
    const backends = ENV_BACKEND_PORT > 0
      ? [{ serviceName: null, port: ENV_BACKEND_PORT }]
      : deployPorts.filter((s) => s.serviceType === 'backend');
    if (backends.length > 0) {
      primaryBackendPort = backends[0].port;
      for (const s of backends) {
        await probeWithRetry(
          s.port,
          s.serviceName ? `backend-${s.serviceName}` : 'backend',
          buildBackendProbePaths(projectArtifactDir, manifest),
        );
      }
    } else {
      failures.push({
        type: 'backend-port-missing',
        reason: 'deploy.json has no backend service http port and CHECK_INITIALIZE_BACKEND_PORT unset (no 6003 fallback)',
      });
    }
  }

  // 2. 前端仅分离项目探测；多前端对称：deploy.json 含 frontend 服务监听值时逐服务探测，
  //    无则回退 6002 单端口。
  if (separated) {
    const frontends = ENV_FRONTEND_PORT > 0
      ? [{ serviceName: null, port: ENV_FRONTEND_PORT }]
      : deployPorts.filter((s) => s.serviceType === 'frontend');
    if (frontends.length > 0) {
      for (const s of frontends) {
        await probeWithRetry(s.port, s.serviceName ? `frontend-${s.serviceName}` : 'frontend');
      }
    } else {
      failures.push({
        type: 'frontend-port-missing',
        reason: 'deploy.json has no frontend service http port and CHECK_INITIALIZE_FRONTEND_PORT unset (no 6002 fallback)',
      });
    }
  }

  // 2b. ingress 端到端探测（2026-09-04，仅 separated + APP_FE_INGRESS_URL 已注入）：
  //     localhost 探活证明不了「外部入口 → 前端 → 代理 → 后端」链路（gaoma 实测全绿但
  //     外部浏览器 Network Error）；经外部入口实测真实 API 链路。HTTP 客户端代理感知
  //     （沙箱 --unshare-net 下出站走 HTTP_PROXY，node:http 默认不认 env 代理）。
  if (separated && primaryBackendPort !== null) {
    await probeIngressApiChain({ projectArtifactDir, manifest, backendPort: primaryBackendPort, failures });
  }

  // 3. 前端构建产物 grep（warning-only：找不到只 log 不进 failures）
  //    原因：/api / 6003 都可能被 minifier / 环境变量间接引用规避；假阳性代价高
  if (separated) {
    const frontendApp = manifest && (manifest.apps || []).find((a) => a && a.kind === 'frontend');
    if (frontendApp) {
      const distDir = path.join(projectArtifactDir, frontendApp.rootDir, 'dist');
      const nextDir = path.join(projectArtifactDir, frontendApp.rootDir, '.next');
      const buildDir = path.join(projectArtifactDir, frontendApp.rootDir, 'build');
      const artifactDir = fs.existsSync(distDir) ? distDir : fs.existsSync(nextDir) ? nextDir : fs.existsSync(buildDir) ? buildDir : null;
      if (artifactDir) {
        let found = false;
        try {
          const stack = [artifactDir];
          while (stack.length && !found) {
            const cur = stack.pop();
            for (const entry of fs.readdirSync(cur, { withFileTypes: true })) {
              const full = path.join(cur, entry.name);
              if (entry.isDirectory()) {
                stack.push(full);
              } else if (/\.(js|html|json)$/.test(entry.name)) {
                const text = fs.readFileSync(full, 'utf-8');
                if (text.includes('6003') || text.includes('/api')) {
                  found = true;
                  break;
                }
              }
            }
          }
        } catch {}
        if (!found) {
          // warning-only：console.error 提示但不推 failures
          console.error(`[warning] frontend artifact at ${artifactDir} does not contain literal "6003" or "/api"; ` +
                        `this may be normal (env vars / minifier) but worth verifying M3b rewrite took effect.`);
        }
      }
    }
  }

  // 2c. war 实例探活（war 部署维度）：manifest apps[] 中 stack.packaging==='war'
  // 且 stack.container 有值的项，逐实例探其分配端口（stack.warPort，无则 warn 跳过不误伤）。
  // 探活语义与 probeWithRetry 一致（任一 HTTP 应答即过）；失败进 failures 阻断。
  if (manifest && Array.isArray(manifest.apps)) {
    for (const app of manifest.apps) {
      const st = app && app.stack;
      if (!st || st.packaging !== 'war' || typeof st.container !== 'string' || !st.container) continue;
      const warPort = Number(st.warPort);
      if (!Number.isFinite(warPort) || warPort <= 0) {
        console.error(`[warning] war app ${app.rootDir || app.id} missing warPort; skip war instance probe`);
        continue;
      }
      await probeWithRetry(warPort, `war-${app.rootDir || app.id}`, ['/']);
    }
  }

  if (failures.length > 0) {
    console.log(JSON.stringify({ ok: false, failures }));
    process.exit(1);
  }
  console.log(JSON.stringify({ ok: true }));
  process.exit(0);
}

// ---------- lock-governance subcommand (#289，DESIGN §5.15 D B2) ----------

/**
 * package-lock.json 源治理（阶段六 build.sh 前置调用，npm install 重 resolve 供消费）：
 * 扫描 `packages` 字段各条目的 `resolved`——仅处理 http(s) 且以 .tgz 结尾的 registry tarball
 * URL（git/workspace/本地路径条目保留，不可从 nexus 重 resolve）：host 在白名单
 * （PUBLIC_REGISTRY_HOSTS，与 TS 侧同步）→ 保留直拉；非白名单（旧私服，如 nexus 以外的
 * 历史 registry host）→ 从 lock 删除（B2），供后续 `npm install --replace-registry-host=never`
 * 从 nexus group 重 resolve 补条目。`resolved` 缺失 / URL 不可解析的条目保留。
 * lockfileVersion 2 的顶层 `dependencies` 镜像按同键（去 node_modules/ 前缀）同步删；
 * 无 `packages` 字段（lock v1）→ 零动作（v1 治理为 MVP 声明边界）。
 * 签名：lock-governance <package-lock.json-path>
 * 输出：{ok:true, removedCount, removed:[{key,resolved}], lockMissing?}（有删除才重写文件，
 * 2 空格缩进 + 尾换行，与 npm 落盘格式一致）；lock 损坏 → {ok:false, lock-parse-error}
 * 且文件不动。
 */
function lockGovernance(lockPath) {
  if (!fs.existsSync(lockPath)) {
    console.log(JSON.stringify({ ok: true, removedCount: 0, removed: [], lockMissing: true }));
    process.exit(0);
  }
  let lock;
  try {
    lock = JSON.parse(fs.readFileSync(lockPath, 'utf-8'));
  } catch (e) {
    console.log(JSON.stringify({
      ok: false,
      failures: [{ type: 'lock-parse-error', file: lockPath, reason: `package-lock.json 不可解析: ${e?.message || e}` }],
    }));
    process.exit(1);
  }
  const packages = lock && typeof lock === 'object' && lock.packages
    && typeof lock.packages === 'object' && !Array.isArray(lock.packages)
    ? lock.packages
    : null;
  if (!packages) {
    // 无 packages 字段（lock v1 / 空 lock）→ 零动作零重写
    console.log(JSON.stringify({ ok: true, removedCount: 0, removed: [] }));
    process.exit(0);
  }
  const removed = [];
  for (const [key, entry] of Object.entries(packages)) {
    const resolved = entry && typeof entry === 'object' ? entry.resolved : null;
    if (typeof resolved !== 'string' || !/^https?:\/\//.test(resolved)) continue;
    let url;
    try {
      url = new URL(resolved);
    } catch {
      continue; // 非 URL 形态保留
    }
    if (!url.pathname.endsWith('.tgz')) continue; // 仅 registry tarball 条目（git 等保留）
    if (PUBLIC_REGISTRY_HOSTS.includes(url.hostname)) continue; // 白名单直拉保留
    delete packages[key];
    removed.push({ key, resolved });
    // lockfileVersion 2 顶层 dependencies 镜像同删（仅顶层 node_modules/<name> 形态；
    // 嵌套镜像由 npm install 重 resolve 自愈，v3 无该字段天然跳过）
    if (lock.dependencies && typeof lock.dependencies === 'object' && !Array.isArray(lock.dependencies)) {
      const mirrorKey = key.replace(/^node_modules\//, '');
      if (mirrorKey !== key) delete lock.dependencies[mirrorKey];
    }
  }
  if (removed.length > 0) {
    fs.writeFileSync(lockPath, `${JSON.stringify(lock, null, 2)}\n`, 'utf-8');
  }
  console.log(JSON.stringify({ ok: true, removedCount: removed.length, removed }));
  process.exit(0);
}

// ---------- dispatch ----------
switch (subcommand) {
  case 'stack':
    // 需要 3 个参数：manifest-path / stack-path / sourceKind（unified | separated）
    if (rest.length < 3) usage();
    checkStack(rest[0], rest[1], rest[2]);
    break;
  case 'components':
    if (rest.length < 1) usage();
    checkComponents(rest[0]);
    break;
  case 'libs':
    if (rest.length < 2) usage();
    checkLibs(rest[0], rest[1]);
    break;
  case 'config-rewrite':
    if (rest.length < 1) usage();
    // config-rewrite 含 layer-2 npm view（async）；立即 invoke 并允许自然 exit
    checkConfigRewrite(rest[0]).catch((e) => {
      console.log(JSON.stringify({ ok: false, failures: [{ type: 'internal', reason: e?.message || String(e) }] }));
      process.exit(1);
    });
    break;
  case 'metadata':
    if (rest.length < 1) usage();
    checkMetadata(rest[0]);
    break;
  case 'lock-governance':
    if (rest.length < 1) usage();
    lockGovernance(rest[0]);
    break;
  case 'runtime-connectivity':
    if (rest.length < 1) usage();
    // runtime-connectivity 是 async；这里立即 invoke 并允许自然 exit
    checkRuntimeConnectivity(rest[0]).catch((e) => {
      console.log(JSON.stringify({ ok: false, failures: [{ type: 'internal', reason: e?.message || String(e) }] }));
      process.exit(1);
    });
    break;
  default:
    usage();
}
