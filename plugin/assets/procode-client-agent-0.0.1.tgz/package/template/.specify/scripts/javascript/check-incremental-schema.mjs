#!/usr/bin/env node

/**
 * 1-1.1 增量设计 · 产物 checker（code-schema **v3 only**，对象身份 = 四字段引用）
 *
 * 根（F3 §1.1/§1.2/§1.4、change-scope §10.4、slice-1 §2 T3）：
 *   校验 code-schema.json（v3）/ delta-schema.json / 迁移 SQL（单语句文件）/ 存量表收口，
 *   stdout JSON { ok, failures[] }，契约 mimic check-backend-design.mjs。
 *
 * 身份（v3）：对象一律以 `{sourceId, owner, kind, name}` 四字段逐字相等定位；`objectId` 已退役。
 *   **禁全小写、禁去 schema 前缀、禁 `split('.')` 猜分段、禁跨源按裸表名合并。** 引用索引键
 *   `refKeyOf` 只在进程内使用，不落盘。
 *
 * mode：
 *   code-schema <path>  — v3 基准校验：版本、completeness、sourceId 可重算、引用唯一、无全局 tables
 *   delta       <path>  — 差集产物校验（legacy 形态保留不变）
 *   migration   <path>  — 增量 SQL 校验：<path> 可为单个 .sql（老形态）或迁移目录（v1 operations 分源目录）
 *   retained    <code-schema.json> --entity-dir <dir> --retained <retained-tables.json>
 *                         — 存量表收口校验（按四字段引用作用域，禁跨源按裸表名合并）
 *
 * 版本纪律：只认 schemaVersion 3。v1/v2 产物一律显式红，并给出**可执行的迁移恢复入口**；
 *   未知/更高版本同样显式红，不降级、不猜测。
 *
 * 用法：
 *   node check-incremental-schema.mjs <mode> <abs-path> [--entity-dir <dir> --retained <path>]
 */

import { readFileSync, existsSync, readdirSync, statSync } from 'fs';
import { join, resolve, relative, sep } from 'path';
import { fileURLToPath } from 'url';
import {
  SOURCE_ID_RE,
  deriveSourceId,
  splitSqlStatements,
  normalizeDialect,
} from './extract-code-schema.mjs';
import { isSchemaObjectRef, refKeyOf, formatRef } from './lib/entity-pk-resolver.mjs';
import { extractCreateTableSegments, parseTableRefsMetadata } from './shared/cross-domain-decl.mjs';

/** v3 契约版本（本批本地钉死；共享常量由版本翻转批次统一切换，避免读到中间态）。 */
const CODE_SCHEMA_VERSION_V3 = 3;

/** 旧产物迁移恢复入口（错误必须带可执行恢复动作）。 */
export const CODE_SCHEMA_MIGRATION_RECOVERY =
  '恢复入口：① 用 extract-code-schema.mjs 重新采集 v3（产出 sources[].objects[]，对象只带 ' +
  '{owner,kind,name}，不再写 objectId）；② 若必须保留历史库快照，先跑集中迁移边界 ' +
  '`node scripts/migrate-code-schema-v2-to-v3.mjs --check`（不存在则按 plan 2026-11-09 的 ' +
  '迁移边界批次补建，禁止手工改版本号冒充 v3）；③ 采集/迁移后重跑本 checker。';

const allowedModes = ['code-schema', 'delta', 'migration', 'retained', 'classification'];
const OPERATION_KINDS = new Set([
  'add-column',
  'add-index',
  'add-unique',
  'create-table',
  'create-index',
  'add-comment',
]);

// ─── 版本守卫 ────────────────────────────────────────────────────────────────
/** v3 守卫：非 3 一律显式红；v1/v2 附集中迁移恢复入口，不静默兼容。 */
export function assertCodeSchemaVersion(parsed) {
  const failures = [];
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { ok: false, version: null, failures: ['code-schema.json 顶层不是对象'] };
  }
  const version = parsed.schemaVersion;
  if (version !== CODE_SCHEMA_VERSION_V3) {
    const isLegacy = version === 1 || version === 2 || (version === undefined && parsed.tables);
    const label = version === undefined ? '（缺 schemaVersion）' : JSON.stringify(version);
    failures.push(
      isLegacy
        ? `code-schema ${label} 是旧产物，已退役：v3 只按 sources[] 分组，对象身份改为 ` +
            `{sourceId, owner, kind, name} 四字段引用，objectId 已删除。${CODE_SCHEMA_MIGRATION_RECOVERY}`
        : `未知 code-schema 版本：${label}；本 checker 只接受 schemaVersion ${CODE_SCHEMA_VERSION_V3}，` +
            `拒绝降级/猜测。${CODE_SCHEMA_MIGRATION_RECOVERY}`,
    );
    return { ok: false, version: version === undefined ? null : version, failures };
  }
  if (Object.prototype.hasOwnProperty.call(parsed, 'tables')) {
    failures.push('v3 禁止全局 tables 段：sourceId 是唯一分组键，对象只能挂在 sources[].objects[] 下');
  }
  if (Object.prototype.hasOwnProperty.call(parsed, 'objectId')) {
    failures.push('v3 顶层不得出现 objectId（对象身份已改为四字段引用）');
  }
  return { ok: failures.length === 0, version, failures };
}

// ─── v3 引用索引（模块内单源；禁调用方各写一套裸名匹配）────────────────────────
/** 建 `refKey → {ref,sourceId,basis}` 与 `sourceId+精确名 → ref[]` 双索引。 */
function buildV3ObjectIndex(codeSchema, failures = []) {
  const refsByKey = new Map();
  const refsBySourceName = new Map();
  for (const src of (codeSchema && codeSchema.sources) || []) {
    if (!src || typeof src.sourceId !== 'string' || !Array.isArray(src.objects)) continue;
    for (const obj of src.objects) {
      if (!obj || typeof obj.name !== 'string' || !obj.name) continue;
      const ref = {
        sourceId: src.sourceId,
        owner: obj.owner === undefined ? null : obj.owner,
        kind: obj.kind === undefined ? 'table' : obj.kind,
        name: obj.name,
      };
      if (!isSchemaObjectRef(ref)) {
        failures.push(`${src.sourceId} 的对象 ${JSON.stringify(obj.name)} 不是合法 v3 引用（owner 必须显式 null/字符串）`);
        continue;
      }
      const key = refKeyOf(ref);
      if (refsByKey.has(key)) {
        failures.push(`基线引用重复：${formatRef(ref)}（同一引用出现多次）`);
        continue;
      }
      refsByKey.set(key, { ref, sourceId: src.sourceId, basis: obj.basis === 'db-only' ? 'db-only' : 'catalog' });
      const nameKey = `${src.sourceId}\u0000${obj.name}`;
      if (!refsBySourceName.has(nameKey)) refsBySourceName.set(nameKey, []);
      refsBySourceName.get(nameKey).push(ref);
    }
  }
  return { refsByKey, refsBySourceName };
}

/** 指定 source 作用域内按「精确表名 + 可选 owner」唯一解析；0 → missing，>1 → failure。 */
function resolveUniqueRefV3(index, sourceId, owner, name, context) {
  const candidates = (index.refsBySourceName.get(`${sourceId}\u0000${name}`) || []).filter(
    (ref) => owner == null || ref.owner === owner,
  );
  if (candidates.length === 1) return { ref: candidates[0] };
  if (candidates.length === 0) return { missing: true };
  return {
    failure:
      `${context}：${sourceId}/${owner == null ? '<null>' : owner}.${name} 在基线中命中 ${candidates.length} 个引用` +
      `（${candidates.map(formatRef).join(' / ')}）：请用 v3 tableRef 显式消歧，禁按裸表名合并`,
  };
}

// ─── code-schema v3 校验 ─────────────────────────────────────────────────────
/**
 * @param {string} text
 * @param {{expectBinding?: {dataSourceName?:string, entryRef?:string}}} [opts]
 */
export function checkCodeSchema(text, opts = {}) {
  const failures = [];
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, failures: ['code-schema.json 不是合法 JSON'] };
  }
  const guard = assertCodeSchemaVersion(parsed);
  if (!guard.ok) return { ok: false, failures: guard.failures };

  if (!Array.isArray(parsed.sources)) {
    return { ok: false, failures: ['缺少 sources 数组（v2 唯一分组键）'] };
  }
  if (parsed.sources.length === 0) {
    failures.push('sources 为空（未采集到任何已确认绑定，检查绑定 envelope 与库连接）');
    return { ok: false, failures };
  }

  const seenSources = new Set();
  const seenRefs = new Map(); // refKey → `${sourceId}/${name}`
  for (let si = 0; si < parsed.sources.length; si++) {
    const src = parsed.sources[si];
    const tag = `sources[${si}]`;
    if (!src || typeof src !== 'object') {
      failures.push(`${tag} 非对象`);
      continue;
    }
    // ── 身份：sourceId 可重算 ──
    if (typeof src.sourceId !== 'string' || !SOURCE_ID_RE.test(src.sourceId)) {
      failures.push(`${tag}.sourceId 非法（应为 src1.<32 位 base64url>，得 ${JSON.stringify(src.sourceId)}）`);
    } else if (seenSources.has(src.sourceId)) {
      failures.push(`${tag}.sourceId 重复：${src.sourceId}（同一 source 只能采一次）`);
    } else {
      seenSources.add(src.sourceId);
    }
    const binding = src.binding;
    if (!binding || typeof binding !== 'object') {
      failures.push(`${tag}.binding 缺失（必须记录 dataSourceName + entryRef）`);
    } else {
      if (!binding.dataSourceName || typeof binding.dataSourceName !== 'string') {
        failures.push(`${tag}.binding.dataSourceName 缺失（绑定身份不得缺省/不得用默认实例）`);
      }
      const expectedEntryRef = binding.dataSourceName ? `datasources.json#${binding.dataSourceName}` : null;
      if (!binding.entryRef) {
        failures.push(`${tag}.binding.entryRef 缺失（应为 datasources.json#<dataSourceName>）`);
      } else if (expectedEntryRef && binding.entryRef !== expectedEntryRef) {
        failures.push(`${tag}.binding.entryRef 与 dataSourceName 不一致：${binding.entryRef} ≠ ${expectedEntryRef}`);
      }
      if (opts.expectBinding) {
        if (opts.expectBinding.dataSourceName && binding.dataSourceName !== opts.expectBinding.dataSourceName) {
          failures.push(`${tag}.binding.dataSourceName=${binding.dataSourceName} 与已确认绑定 ${opts.expectBinding.dataSourceName} 不一致`);
        }
      }
    }

    // ── 方言/通道（方言允许集开放：接受声明的 canonical 方言 + evidence，不设白名单）──
    const declaredDialect = typeof src.dialect === 'string' ? src.dialect.trim() : '';
    const normalizedDeclared = normalizeDialect(declaredDialect);
    if (!declaredDialect || normalizedDeclared === 'unknown' || normalizedDeclared !== declaredDialect) {
      failures.push(
        `${tag}.dialect 非法/未归一：${JSON.stringify(src.dialect)}` +
          '（未知方言必须用 trim + 原字面值，不得写 unknown/别名；无方言不得写成功壳）',
      );
    } else if (src.databaseType && normalizeDialect(src.databaseType) !== declaredDialect) {
      failures.push(
        `${tag}.dialect=${declaredDialect} 与 databaseType=${JSON.stringify(src.databaseType)} 归一族不一致（不得假设方言）`,
      );
    }
    // Wave 1 起采集通道 MCP-only：local 通道产物不得再进入基线。
    if (src.channel !== 'mcp') {
      failures.push(
        `${tag}.channel=${JSON.stringify(src.channel)}：v3 基线只接受 channel:'mcp'（Wave 1 MCP-only）。` +
          '恢复：改用 MCP 通道重新采集，不得手改 channel 字段冒充。',
      );
    }
    if (!src.scope || typeof src.scope !== 'object') {
      failures.push(`${tag}.scope 缺失（database/owners/objectFilter 是 sourceId 派生输入的一部分）`);
    } else {
      if (!Array.isArray(src.scope.owners)) failures.push(`${tag}.scope.owners 非数组`);
      if (src.scope.database != null && typeof src.scope.database !== 'string') {
        failures.push(`${tag}.scope.database 非字符串/空`);
      }
      if (
        src.scope.basis !== undefined &&
        src.scope.basis !== 'code' &&
        src.scope.basis !== 'catalog'
      ) {
        failures.push(`${tag}.scope.basis 非法：${JSON.stringify(src.scope.basis)}（只允许 code|catalog）`);
      }
      if (src.dialect === 'mysql' && !String(src.scope.database || '').trim()) {
        failures.push(`${tag}.scope.database 缺失：MySQL 采集必须有已确认库名（无库名不能证明表全集）`);
      }
    }
    const basis = src.scope && src.scope.basis === 'code' ? 'code' : 'catalog';
    // sourceId 重算（输入齐全且合法时才比；缺字段已单独红）
    if (
      src.dialect &&
      src.binding &&
      src.binding.dataSourceName &&
      src.scope &&
      Array.isArray(src.scope.owners) &&
      SOURCE_ID_RE.test(String(src.sourceId || ''))
    ) {
      const recomputed = deriveSourceId({
        dataSourceName: src.binding.dataSourceName,
        dialect: src.dialect,
        scope: src.scope,
      });
      if (recomputed !== src.sourceId) {
        failures.push(
          `${tag}.sourceId 不可重算：声明 ${src.sourceId}，按 (dataSourceName, dialect, database, owners, objectFilter) 重算得 ${recomputed}` +
            '——身份被手改或 scope 与派生输入漂移。',
        );
      }
    }

    // ── completeness：不得把不完整/截断当完成 ──
    const objects = Array.isArray(src.objects) ? src.objects : [];
    const c = src.completeness;
    if (!c || typeof c !== 'object') {
      failures.push(`${tag}.completeness 缺失（catalogExpected/Returned/objectsParsed/truncated/missingPermissions 必须落盘）`);
    } else {
      if (c.status !== 'complete') {
        failures.push(
          `${tag}.completeness.status=${JSON.stringify(c.status)}：采集不完整/被降级；基线必须 complete，partial/failed 不得进入 code-schema.json`,
        );
      }
      if (c.dynamicPatterns !== undefined && !Array.isArray(c.dynamicPatterns)) {
        failures.push(`${tag}.completeness.dynamicPatterns 非数组（inventory v2 dynamicPatterns 必须落盘为数组）`);
      }
      if (!Number.isInteger(c.catalogExpected) || c.catalogExpected < 0) {
        failures.push(`${tag}.completeness.catalogExpected 非非负整数（无目录 COUNT 证据不能证明表全集）`);
      }
      if (!Number.isInteger(c.catalogReturned) || c.catalogReturned < 0) {
        failures.push(`${tag}.completeness.catalogReturned 非非负整数`);
      }
      if (!Number.isInteger(c.objectsParsed) || c.objectsParsed < 0) {
        failures.push(`${tag}.completeness.objectsParsed 非非负整数`);
      }
      if (Array.isArray(c.missingPermissions) && c.missingPermissions.length > 0) {
        failures.push(`${tag}.completeness.missingPermissions 非空：${c.missingPermissions.join(', ')}`);
      }
      if (c.truncated !== false) {
        failures.push(`${tag}.completeness.truncated 必须为 false（截断基线禁止当完成）`);
      }
      if (Number.isInteger(c.objectsParsed) && c.objectsParsed !== objects.length) {
        failures.push(`${tag}：objectsParsed=${c.objectsParsed} 与 objects.length=${objects.length} 不一致（有对象解析失败）`);
      }
      if (Number.isInteger(c.catalogExpected) && Number.isInteger(c.catalogReturned)) {
        if (c.catalogExpected < c.catalogReturned) {
          failures.push(`${tag}：catalogExpected(${c.catalogExpected}) < catalogReturned(${c.catalogReturned})，目录证据自相矛盾`);
        } else if (c.catalogExpected !== c.catalogReturned) {
          failures.push(
            `${tag}：catalogExpected(${c.catalogExpected}) ≠ catalogReturned(${c.catalogReturned})——表全集缺项/截断，` +
              '不得把不完整基线标 complete',
          );
        }
      }
      if (!Array.isArray(c.evidenceRefs) || c.evidenceRefs.length === 0) {
        failures.push(`${tag}.completeness.evidenceRefs 为空（无取证引用）`);
      }
      // 与 basis 无关：旧 unresolved 非空不得静默 complete。
      // dynamicPatterns 是已声明边界：门 A 已保证只放行 dml 上下文，消费侧不重复解析（entailment），不参与判红。
      if (Array.isArray(c.unresolved) && c.unresolved.length > 0) {
        failures.push(
          `${tag}.completeness.unresolved 非空（${c.unresolved.length} 项）：这是旧产物兼容字段，inventory v2 禁止 unresolved。` +
            '请回 Agent A 迁移后重跑：具体表 → tables[] scope:"external"（附 SQL 独立库证据），' +
            '动态表名 → dynamicPatterns[]；否则禁止 complete。',
        );
      }

      if (basis === 'catalog') {
        if (Number.isInteger(c.catalogReturned) && c.catalogReturned !== objects.length) {
          failures.push(`${tag}：catalogReturned=${c.catalogReturned} 与 objects.length=${objects.length} 不一致（表全集被裁剪？）`);
        }
      } else {
        // basis='code'：complete 语义 = code table 全覆盖且 unresolved 为空（§5.6）。
        const codeFields = ['codeExpected', 'codeCollected', 'dbOnly', 'dbOnlyCollected', 'codeOnly'];
        const codeInts = {};
        for (const field of codeFields) {
          if (!Number.isInteger(c[field]) || c[field] < 0) {
            failures.push(`${tag}.completeness.${field} 非非负整数（basis=code 必须落盘分类完整性）`);
          } else {
            codeInts[field] = c[field];
          }
        }
        if (!Array.isArray(c.unresolved)) {
          failures.push(`${tag}.completeness.unresolved 缺失/非数组（basis=code 必须落盘 unresolved 清账）`);
        }
        if (codeInts.codeExpected !== undefined && codeInts.codeCollected !== undefined) {
          if (codeInts.codeCollected !== codeInts.codeExpected) {
            failures.push(
              `${tag}：codeCollected=${codeInts.codeCollected} ≠ codeExpected=${codeInts.codeExpected}——code table 未全覆盖，` +
                '不得把不完整基线标 complete',
            );
          }
        }
        if (codeInts.dbOnly !== undefined && codeInts.dbOnlyCollected !== undefined) {
          if (codeInts.dbOnlyCollected !== codeInts.dbOnly) {
            failures.push(
              `${tag}：dbOnlyCollected=${codeInts.dbOnlyCollected} ≠ dbOnly=${codeInts.dbOnly}——identity-only db-only 对象未全覆盖，` +
                'retained/gaps 铁律会漏掉库表',
            );
          }
        }
        if (
          codeInts.codeCollected !== undefined &&
          codeInts.dbOnlyCollected !== undefined &&
          c.objectsParsed === objects.length &&
          objects.length !== codeInts.codeCollected + codeInts.dbOnlyCollected
        ) {
          failures.push(
            `${tag}：objects.length=${objects.length} ≠ codeCollected(${codeInts.codeCollected}) + dbOnlyCollected(${codeInts.dbOnlyCollected})` +
              '——code-only 不得写入 objects[]',
          );
        }
        if (
          Number.isInteger(c.catalogReturned) &&
          codeInts.codeExpected !== undefined &&
          codeInts.dbOnly !== undefined &&
          c.catalogReturned !== codeInts.codeExpected + codeInts.dbOnly
        ) {
          failures.push(
            `${tag}：catalogReturned=${c.catalogReturned} ≠ codeExpected(${codeInts.codeExpected}) + dbOnly(${codeInts.dbOnly})` +
              '——分类与库目录不一致',
          );
        }
      }
    }

    // ── objects：身份 + 原文 + 可 diff ──
    if (!Array.isArray(src.objects)) {
      failures.push(`${tag}.objects 非数组`);
      continue;
    }
    if (src.objects.length === 0) {
      // 零存量结构：该源 codeExpected=0 且 dbOnly=0、目录完整对账时，空对象集是合法基线。
      const zeroStockComplete =
        basis === 'code' &&
        c.status === 'complete' &&
        c.codeExpected === 0 &&
        c.dbOnly === 0 &&
        Number.isInteger(c.catalogExpected) &&
        c.catalogExpected === c.catalogReturned;
      if (!zeroStockComplete) {
        failures.push(`${tag}.objects 为空（该 source 未采到任何对象，check 库连接/权限/过滤）`);
      }
    }
    for (let oi = 0; oi < src.objects.length; oi++) {
      const obj = src.objects[oi];
      const otag = `${tag}.objects[${oi}]`;
      if (!obj || typeof obj !== 'object') {
        failures.push(`${otag} 非对象`);
        continue;
      }
      if (!obj.name || typeof obj.name !== 'string') failures.push(`${otag}.name 缺失`);
      if (!obj.quoted || typeof obj.quoted !== 'object') {
        failures.push(`${otag}.quoted 缺失（原文引号语义是身份/DDL 保真的一部分）`);
      }
      const objectBasis =
        obj.basis === undefined ? (basis === 'code' ? 'code' : 'catalog') : obj.basis;
      if (objectBasis !== 'code' && objectBasis !== 'db-only' && objectBasis !== 'catalog') {
        failures.push(`${otag}.basis 非法：${JSON.stringify(obj.basis)}（只允许 code|db-only|catalog）`);
      }
      const isDbOnly = objectBasis === 'db-only';
      if (isDbOnly && basis !== 'code') {
        failures.push(`${otag} 是 identity-only db-only，但 source.scope.basis≠code（旧 catalog 产物不得含 db-only 对象）`);
      }
      if (isDbOnly) {
        if (obj.kind !== undefined && obj.kind !== 'table') {
          failures.push(`${otag}.kind=${JSON.stringify(obj.kind)}：db-only identity-only 只能是 table`);
        }
        if (typeof obj.rawDdl !== 'string' || obj.rawDdl.trim()) {
          failures.push(`${otag}.rawDdl 必须为空字符串（db-only 是 identity-only，不得伪造库原文）`);
        }
        if (!Array.isArray(obj.columns) || obj.columns.length !== 0) {
          failures.push(`${otag}.columns 必须为空数组（db-only 不采集列结构）`);
        }
        if (obj.diffable !== false) {
          failures.push(`${otag}.diffable 必须为 false（db-only identity-only 不得参与 diff/unchanged）`);
        }
        if (Array.isArray(obj.parseIssues) && obj.parseIssues.length > 0) {
          failures.push(`${otag}.parseIssues 必须为空（db-only 不做解析）`);
        }
      } else {
        if (typeof obj.rawDdl !== 'string' || !obj.rawDdl.trim()) {
          failures.push(`${otag}.rawDdl 为空（库原文搬运失败，v2 禁空壳对象）`);
        }
        if (!Array.isArray(obj.columns) || obj.columns.length === 0) {
          failures.push(`${otag}.columns 为空（表对象至少应有列定义）`);
        } else {
          const ordinals = new Set();
          for (const col of obj.columns) {
            if (!col || !col.name) {
              failures.push(`${otag}：存在无 name 的列`);
              continue;
            }
            if (!col.ddl || !String(col.ddl).trim()) {
              failures.push(`${otag}.${col.name}：ddl 为空（库原文搬运失败，v2 不允许空 ddl）`);
            }
            if (col.source !== 'db') {
              failures.push(`${otag}.${col.name}：source=${JSON.stringify(col.source)}（纯库 shape 必须为 'db'）`);
            }
            if (!Number.isInteger(col.ordinal) || col.ordinal < 1) {
              failures.push(`${otag}.${col.name}：ordinal 非正整数`);
            } else if (ordinals.has(col.ordinal)) {
              failures.push(`${otag}.${col.name}：ordinal ${col.ordinal} 重复`);
            } else {
              ordinals.add(col.ordinal);
            }
          }
        }
      }
      // ── 身份：四字段引用（去 objectId）──
      if (Object.prototype.hasOwnProperty.call(obj, 'objectId')) {
        failures.push(
          `${otag}.objectId=${JSON.stringify(obj.objectId)}：objectId 已退役，v3 对象只允许 ` +
            '{sourceId(由所属 source 提供), owner, kind, name}。' +
            CODE_SCHEMA_MIGRATION_RECOVERY,
        );
      }
      const objectRef = {
        sourceId: src.sourceId,
        owner: obj.owner === undefined ? undefined : obj.owner,
        kind: obj.kind === undefined ? undefined : obj.kind,
        name: obj.name,
      };
      if (!isSchemaObjectRef(objectRef)) {
        failures.push(
          `${otag} 不是合法 v3 引用：需 {sourceId, owner, kind, name}；` +
            'owner 无值必须显式 null（不得省略），kind ∈ table|view|sequence|other，name 非空。' +
            '禁止按裸表名/全小写/去 schema 前缀猜身份。',
        );
      } else {
        const key = refKeyOf(objectRef);
        if (seenRefs.has(key)) {
          failures.push(
            `${otag} 引用重复：${formatRef(objectRef)}（已出现在 ${seenRefs.get(key)}）——` +
              '同一 source 内四字段引用必须唯一，禁跨 owner/source 合并同名对象',
          );
        } else {
          seenRefs.set(key, `${src.sourceId}/${obj.name}`);
        }
      }
      if (typeof obj.diffable !== 'boolean') failures.push(`${otag}.diffable 非布尔`);
      if (Array.isArray(obj.parseIssues) && obj.parseIssues.length > 0 && obj.diffable !== false) {
        failures.push(`${otag} 有 parseIssues 却标 diffable=true（不可 diff 对象不得参与派生）`);
      }
      for (const key of ['indexes', 'constraints', 'foreignKeys']) {
        if (!Array.isArray(obj[key])) failures.push(`${otag}.${key} 非数组`);
        else if (isDbOnly && obj[key].length > 0) {
          failures.push(`${otag}.${key} 必须为空数组（db-only 不采集结构）`);
        }
      }
      if (!obj.comments || typeof obj.comments !== 'object') failures.push(`${otag}.comments 缺失（{table, columns}）`);
    }
  }

  return { ok: failures.length === 0, failures };
}

// ─── retained 收口校验：按 sourceId 作用域，禁跨源裸表名合并 ──────────────────
/**
 * 存量表全集 − canonical entity 表 − retained 表 = 空集，但**每一侧都按 sourceId 作用域**：
 *   - retained 项必须带 sourceId（且该 source 存在于 code-schema），可选 objectId；
 *   - 不把不同 source 的同名表当成一张表。
 */
export function checkRetained(codeSchemaText, { entityDir, retainedPath } = {}) {
  const failures = [];
  let codeSchema;
  try {
    codeSchema = JSON.parse(codeSchemaText);
  } catch {
    return { ok: false, failures: ['code-schema.json 不是合法 JSON'] };
  }
  const guard = assertCodeSchemaVersion(codeSchema);
  if (!guard.ok) return { ok: false, failures: guard.failures };
  if (!Array.isArray(codeSchema.sources) || codeSchema.sources.length === 0) {
    return { ok: false, failures: ['code-schema.sources 为空'] };
  }

  const index = buildV3ObjectIndex(codeSchema, failures);
  const { refsByKey } = index;
  const resolveUniqueRef = (sourceId, owner, name, context) =>
    resolveUniqueRefV3(index, sourceId, owner, name, context);

  // canonical entity 声明的引用：优先 `## tableRefs` 元数据（权威），否则按 source 作用域唯一解析。
  const entityRefs = new Map(); // refKey → {ref, file}
  let files = [];
  try {
    files = readdirSync(entityDir).filter((f) => /^entity-.*\.md$/.test(f));
  } catch {
    failures.push(`无法读取 entity 目录：${entityDir}（canonical entity-*.md 应在此目录）`);
  }

  const headIdentityHints = (text) => {
    const head = text.slice(0, 4000);
    const read = (patterns) => {
      for (const pattern of patterns) {
        const m = head.match(pattern);
        if (m) return m[1].trim();
      }
      return undefined;
    };
    return {
      sourceId: read([/(?:^|\n)\s*sourceId\s*[：:]\s*`?([^\s`"']+)/i]),
      objectId: read([/(?:^|\n)\s*objectId\s*[：:]\s*`?([^\s`"']+)/i]),
      dataSourceName: read([
        /(?:^|\n)\s*dataSourceName\s*[：:]\s*`?([^\s`"']+)/i,
        /(?:^|\n)\s*数据源\s*[：:]\s*`?([^\s`"']+)/i,
      ]),
    };
  };

  const sourceIds = [...new Set(codeSchema.sources.map((src) => src && src.sourceId).filter(Boolean))];
  const ALTER_TABLE_RE = new RegExp(
    `ALTER\\s+TABLE\\s+(?:ONLY\\s+)?((?:\`(?:[^\`]|\`\`)[^\`]*\`|"[^"]+"|\\[[^\\]]+\\]|[A-Za-z0-9_$#]+)(?:\\s*\\.\\s*(?:\`(?:[^\`]|\`\`)[^\`]*\`|"[^"]+"|\\[[^\\]]+\\]|[A-Za-z0-9_$#]+))?)`,
    'gi',
  );

  for (const f of files) {
    const md = readFileSync(join(entityDir, f), 'utf-8');
    const metadata = parseTableRefsMetadata(md);
    const hints = headIdentityHints(md);
    if (hints.objectId) {
      failures.push(
        `${f} 头部仍声明 objectId=${hints.objectId}：objectId 已退役。恢复：改写为 v3 引用 ` +
          '（头部 sourceId + 段级 tableRef，或 `## tableRefs` 元数据）。',
      );
    }
    if (metadata.present && metadata.error) failures.push(`${f}：${metadata.error}`);

    const declaredRefs = [];
    if (metadata.present && !metadata.error) {
      for (const binding of metadata.bindings) declaredRefs.push(binding.tableRef);
    }

    // 无元数据时：用 sourceId / 数据源 把作用域收敛到单个 source，再按精确名唯一解析。
    let scopedSourceId = hints.sourceId || null;
    if (scopedSourceId && !sourceIds.includes(scopedSourceId)) {
      failures.push(`${f}：实体头部 sourceId=${scopedSourceId} 不在 code-schema v3 sources 中`);
      scopedSourceId = null;
    }
    if (!scopedSourceId && hints.dataSourceName) {
      const matched = codeSchema.sources.filter(
        (src) => src && src.binding && src.binding.dataSourceName === hints.dataSourceName,
      );
      if (matched.length === 1) scopedSourceId = matched[0].sourceId;
      else if (matched.length > 1) {
        failures.push(`${f}：数据源 ${hints.dataSourceName} 对应多份基线，无法唯一作用域（请写 sourceId 或 tableRefs）`);
      }
    }

    const ddlNames = [];
    for (const segment of extractCreateTableSegments(md)) {
      ddlNames.push({ owner: segment.owner, name: segment.tableName });
    }
    ALTER_TABLE_RE.lastIndex = 0;
    for (const m of md.matchAll(ALTER_TABLE_RE)) {
      const parts = String(m[1])
        .split(/\s*\.\s*/)
        .filter(Boolean)
        .map((token) => String(token).replace(/^[`"\[]|[`"\]]$/g, ''));
      if (parts.length === 0) continue;
      ddlNames.push({ owner: parts.length > 1 ? parts[parts.length - 2] : null, name: parts[parts.length - 1] });
    }

    for (const { owner, name } of ddlNames) {
      if (!name) continue;
      // 元数据已给出该文档的权威引用集：DDL 段只做绑定完整性提示，不再按裸名猜。
      if (declaredRefs.length > 0) continue;
      if (!scopedSourceId) {
        if (sourceIds.length === 1) scopedSourceId = sourceIds[0];
        else {
          failures.push(
            `${f}：表 ${owner == null ? name : `${owner}.${name}`} 无法确定所属 source（基线有 ${sourceIds.length} 份）。` +
              '恢复：在实体头部写 `sourceId：<src1.…>`/`数据源：<ds>`，或用 `## tableRefs` 元数据显式绑定 v3 引用。',
          );
          continue;
        }
      }
      const resolved = resolveUniqueRef(scopedSourceId, owner, name, `${f} 的 DDL`);
      if (resolved.ref) entityRefs.set(refKeyOf(resolved.ref), { ref: resolved.ref, file: f });
      else if (resolved.failure) failures.push(resolved.failure);
      // missing → 新表（不在基线）：不参与存量收口
    }

    for (const ref of declaredRefs) {
      if (!refsByKey.has(refKeyOf(ref))) {
        failures.push(`${f}：tableRef ${formatRef(ref)} 不在 code-schema v3 基线中（身份不存在，拒绝按同名猜）`);
        continue;
      }
      entityRefs.set(refKeyOf(ref), { ref, file: f });
    }
  }

  // retained 项：v3 用 tableRef（四字段精确命中）；legacy `sourceId + 精确表名` 仅在唯一命中时收编。
  let retained;
  try {
    retained = JSON.parse(readFileSync(retainedPath, 'utf-8'));
  } catch {
    const leftover = [];
    for (const [key, entry] of refsByKey) {
      if (!entityRefs.has(key)) leftover.push(formatRef(entry.ref));
    }
    if (leftover.length > 0) {
      failures.push(
        `retained-tables.json 不可读且以下存量表既未重设计（无 canonical entity）也未登记保留：${leftover.join(', ')}`,
      );
    }
    return { ok: failures.length === 0, failures };
  }
  if (!Array.isArray(retained.retained)) {
    failures.push('retained-tables.json 缺少 retained 数组');
    return { ok: false, failures };
  }

  const retainedRefs = new Map();
  for (const item of retained.retained) {
    if (!item || typeof item !== 'object') {
      failures.push('retained-tables.json：存在非对象项');
      continue;
    }
    if (Object.prototype.hasOwnProperty.call(item, 'objectId')) {
      failures.push(
        `retained-tables.json 项 ${JSON.stringify(item.objectId)} 仍用 objectId：已退役。` +
          '恢复：改写为 `tableRef:{sourceId,owner,kind:"table",name}`（四字段逐字）。',
      );
      continue;
    }
    if (item.tableRef !== undefined) {
      if (!isSchemaObjectRef(item.tableRef) || item.tableRef.kind !== 'table') {
        failures.push(`retained-tables.json 项 tableRef 非法：${JSON.stringify(item.tableRef)}`);
        continue;
      }
      const key = refKeyOf(item.tableRef);
      if (!refsByKey.has(key)) {
        failures.push(`retained-tables.json：tableRef ${formatRef(item.tableRef)} 不在 code-schema 基线中（禁跨源/跨 owner 登记）`);
        continue;
      }
      if (!item.reason) failures.push(`retained-tables.json.${item.tableRef.name}：缺 reason`);
      retainedRefs.set(key, { ref: item.tableRef });
      continue;
    }
    // legacy 形态：sourceId + 精确表名（不再接受全小写/去前缀）
    if (!item.sourceId) {
      failures.push(
        `retained-tables.json 项 ${JSON.stringify(item.table || '?')} 缺 sourceId/tableRef：` +
          'retained 必须落在具体 source 引用作用域内，禁按裸表名跨源合并',
      );
      continue;
    }
    if (!SOURCE_ID_RE.test(item.sourceId)) {
      failures.push(`retained-tables.json.${item.table || '?'}：sourceId 非法 ${JSON.stringify(item.sourceId)}`);
      continue;
    }
    if (!item.table) {
      failures.push(`retained-tables.json：sourceId=${item.sourceId} 的项缺 table/tableRef`);
      continue;
    }
    const resolved = resolveUniqueRef(item.sourceId, null, item.table, 'retained-tables.json');
    if (resolved.failure || resolved.missing) {
      failures.push(
        resolved.failure ||
          `retained-tables.json.${item.table}：该表不在 sourceId=${item.sourceId} 的基线对象内（禁跨源登记）`,
      );
      continue;
    }
    if (!item.reason) failures.push(`retained-tables.json.${item.table}：缺 reason`);
    retainedRefs.set(refKeyOf(resolved.ref), { ref: resolved.ref });
  }

  // 铁律：每个基线的 全集 − entity − retained（refKey 逐字匹配） = 空
  for (const [key, entry] of refsByKey) {
    if (entityRefs.has(key) || retainedRefs.has(key)) continue;
    const label = entry.basis === 'db-only' ? 'db-only identity-only 表' : '存量表';
    failures.push(
      `${label} ${formatRef(entry.ref)} 既未重设计（无 canonical entity）也未登记保留（不在 retained-tables.json）` +
        '——违反"存量表全集（含 identity-only db-only） = 重设计表 + 保留表 + orphan"铁律',
    );
  }

  return { ok: failures.length === 0, failures };
}

// ─── micro 最小分类校验：每张 identity-only db-only 必须有 retained/gaps 落点 ──────────
/**
 * §4.4：micro 增量没有设计 coverage 链时，agent 读 identity-only db-only 表 → 输出
 * `retained-tables.json` / `coverage-gaps.json` 决策；本 checker 只验分类完整性
 * （每张 db-only 必须有且仅需一个落点），不判业务语义。
 *
 * 落点判据：
 *   - retained[] 项：必须带 sourceId（禁跨源裸表名合并），按 table 或 objectId 命中；
 *   - gaps[] 项：按 `table` / `missingObject` / `expectedCarrier` 里的表名命中；带 sourceId 时
 *     必须与对象 source 一致（旧 coverage-gaps 无 sourceId，按裸表名唯一命中兼容）。
 */
export function checkClassification(codeSchemaText, { retainedPath, gapsPath } = {}) {
  const failures = [];
  let codeSchema;
  try {
    codeSchema = JSON.parse(codeSchemaText);
  } catch {
    return { ok: false, failures: ['code-schema.json 不是合法 JSON'] };
  }
  const guard = assertCodeSchemaVersion(codeSchema);
  if (!guard.ok) return { ok: false, failures: guard.failures };
  if (!Array.isArray(codeSchema.sources) || codeSchema.sources.length === 0) {
    return { ok: false, failures: ['code-schema.sources 为空'] };
  }

  const index = buildV3ObjectIndex(codeSchema, failures);
  const identityOnly = [];
  for (const src of codeSchema.sources) {
    if (!src || typeof src.sourceId !== 'string' || !Array.isArray(src.objects)) continue;
    for (const obj of src.objects) {
      if (!obj || typeof obj.name !== 'string' || !obj.name) continue;
      if (obj.basis !== 'db-only') continue;
      const ref = {
        sourceId: src.sourceId,
        owner: obj.owner === undefined ? null : obj.owner,
        kind: obj.kind === undefined ? 'table' : obj.kind,
        name: obj.name,
      };
      if (!isSchemaObjectRef(ref)) {
        failures.push(`db-only 对象 ${src.sourceId}/${obj.name} 不是合法 v3 引用（owner 必须显式 null/字符串）`);
        continue;
      }
      identityOnly.push({ ref });
    }
  }
  if (identityOnly.length === 0) {
    return { ok: true, failures, checked: 0 };
  }

  const readJson = (filePath, label) => {
    if (!filePath) {
      failures.push(`缺 ${label} 路径：无法校验 db-only 分类完整性`);
      return null;
    }
    try {
      return JSON.parse(readFileSync(filePath, 'utf-8'));
    } catch {
      failures.push(`${label} 不可读/非 JSON：${filePath}`);
      return null;
    }
  };

  const retainedDoc = readJson(retainedPath, 'retained-tables.json');
  const gapsDoc = readJson(gapsPath, 'coverage-gaps.json');
  if (!retainedDoc || !gapsDoc) return { ok: false, failures };

  const retained = Array.isArray(retainedDoc.retained) ? retainedDoc.retained : null;
  if (!retained) {
    failures.push('retained-tables.json 缺少 retained 数组');
    return { ok: false, failures };
  }
  const gaps = Array.isArray(gapsDoc.gaps) ? gapsDoc.gaps : null;
  if (!gaps) {
    failures.push('coverage-gaps.json 缺少 gaps 数组');
    return { ok: false, failures };
  }

  const retainedRefs = new Set();
  for (const item of retained) {
    if (!item || typeof item !== 'object') continue;
    if (Object.prototype.hasOwnProperty.call(item, 'objectId')) {
      failures.push(
        `retained-tables.json 项 ${JSON.stringify(item.objectId)} 仍用 objectId：已退役。` +
          '恢复：改写为 `tableRef:{sourceId,owner,kind:"table",name}`（四字段逐字）。',
      );
      continue;
    }
    if (item.tableRef !== undefined) {
      if (!isSchemaObjectRef(item.tableRef) || item.tableRef.kind !== 'table') {
        failures.push(`retained-tables.json 项 tableRef 非法：${JSON.stringify(item.tableRef)}`);
        continue;
      }
      retainedRefs.add(refKeyOf(item.tableRef));
      continue;
    }
    if (!item.sourceId) {
      failures.push(
        `retained-tables.json 项 ${JSON.stringify(item.table || '?')} 缺 sourceId/tableRef：` +
          'retained 必须落在具体 source 引用作用域内，禁按裸表名跨源合并',
      );
      continue;
    }
    if (!SOURCE_ID_RE.test(item.sourceId)) {
      failures.push(`retained-tables.json.${item.table || '?'}：sourceId 非法 ${JSON.stringify(item.sourceId)}`);
      continue;
    }
    if (!item.table) continue;
    const resolved = resolveUniqueRefV3(index, item.sourceId, null, item.table, 'retained-tables.json');
    if (resolved.ref) retainedRefs.add(refKeyOf(resolved.ref));
    else if (resolved.failure) failures.push(resolved.failure);
  }

  const gapRefs = new Set();
  for (const gap of gaps) {
    if (!gap || typeof gap !== 'object') continue;
    if (gap.tableRef !== undefined) {
      if (!isSchemaObjectRef(gap.tableRef) || gap.tableRef.kind !== 'table') {
        failures.push(`coverage-gaps.json 项 tableRef 非法：${JSON.stringify(gap.tableRef)}`);
        continue;
      }
      gapRefs.add(refKeyOf(gap.tableRef));
      continue;
    }
    const names = [gap.table, gap.missingObject, gap.expectedCarrier].filter(
      (value) => typeof value === 'string' && value.trim(),
    );
    for (const name of names) {
      if (gap.sourceId) {
        const resolved = resolveUniqueRefV3(index, gap.sourceId, null, name, 'coverage-gaps.json');
        if (resolved.ref) gapRefs.add(refKeyOf(resolved.ref));
        else if (resolved.failure) failures.push(resolved.failure);
        continue;
      }
      // 无 sourceId：只接受全基线唯一精确名命中；同名跨源必须显式 sourceId/tableRef（禁合并）。
      const hits = [...index.refsByKey.values()].filter((entry) => entry.ref.name === name).map((entry) => entry.ref);
      if (hits.length === 1) gapRefs.add(refKeyOf(hits[0]));
      else if (hits.length > 1) {
        failures.push(
          `coverage-gaps.json 项「${name}」缺 sourceId/tableRef，而在基线中命中 ${hits.length} 个同名引用` +
            `（${hits.map(formatRef).join(' / ')}）：禁按裸表名跨源合并，请显式给出引用。`,
        );
      }
    }
  }

  const unmatched = [];
  for (const item of identityOnly) {
    const key = refKeyOf(item.ref);
    if (!retainedRefs.has(key) && !gapRefs.has(key)) unmatched.push(formatRef(item.ref));
  }
  for (const entry of unmatched) {
    failures.push(
      `db-only identity-only 表 ${entry} 未分类：必须登记到 retained-tables.json（tableRef）或 coverage-gaps.json，` +
        '否则 §4.4 retained/gaps 铁律会漏掉库表',
    );
  }

  return { ok: failures.length === 0, failures, checked: identityOnly.length };
}


export function checkDelta(text) {
  const failures = [];
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return { ok: false, failures: ['delta-schema.json 不是合法 JSON'] };
  }
  if (!parsed.tables || typeof parsed.tables !== 'object') {
    return { ok: false, failures: ['缺少 tables 对象'] };
  }

  for (const [tbl, t] of Object.entries(parsed.tables)) {
    for (const col of t.addCol || []) {
      if (!col.name) failures.push(`表 ${tbl}.addCol：存在无 name 的项`);
      if (!col.ddl || !col.ddl.trim()) failures.push(`表 ${tbl}.addCol.${col.name || '?'}：缺 ddl（新列定义原文）`);
    }
    for (const m of t.modifyCol || []) {
      if (!m.name) failures.push(`表 ${tbl}.modifyCol：存在无 name 的项`);
      if (!m.fromDdl) failures.push(`表 ${tbl}.modifyCol.${m.name || '?'}：缺 fromDdl（库基准原文）`);
      if (!m.toDdl) failures.push(`表 ${tbl}.modifyCol.${m.name || '?'}：缺 toDdl（新设计原文）`);
      if (!t.needsHumanReview) {
        failures.push(`表 ${tbl}：存在 modifyCol（${m.name}）但未标 needsHumanReview（已有列属性变需人工裁决）`);
      }
    }
    for (const c of t.dropCol || []) {
      if (!c.name) failures.push(`表 ${tbl}.dropCol：存在无 name 的项`);
      if (!t.needsHumanReview) failures.push(`表 ${tbl}：存在 dropCol（${c.name}）但未标 needsHumanReview（禁 DROP 需人工裁决）`);
    }
    for (const idx of t.addIndex || []) {
      if (!idx.ddl || !idx.ddl.trim()) failures.push(`表 ${tbl}.addIndex：存在无 ddl 的项`);
    }
    if (t.newTable !== undefined && typeof t.newTable !== 'boolean') {
      failures.push(`表 ${tbl}：newTable 非布尔`);
    }
  }

  if (parsed.droppedTables) {
    if (!Array.isArray(parsed.droppedTables)) {
      failures.push('droppedTables 非数组');
    } else {
      for (const dt of parsed.droppedTables) {
        if (!dt.table) failures.push('droppedTables：存在无 table 的项');
        if (!dt.needsHumanReview) failures.push(`droppedTables.${dt.table || '?'}：未标 needsHumanReview（禁 DROP TABLE 需人工裁决）`);
      }
    }
  }

  return { ok: failures.length === 0, failures };
}

// ─── migration：单语句 .sql 文件校验（可分源目录批量）─────────────────────────
const FORBIDDEN_STMT_RE = /\b(drop\s+table|drop\s+database|drop\s+column|drop\s+index|truncate|rename\s+table|alter\s+table\s+\S+\s+modify|change\s+column)\b/i;

/** 单条执行的 DDL 前缀（含 COMMENT ON，供 add-comment 类操作）。 */
const ALLOWED_STMT_RE = /^(CREATE\s+TABLE|ALTER\s+TABLE|CREATE\s+(UNIQUE\s+)?INDEX|COMMENT\s+ON)\b/i;

export function checkMigrationStatement(statement, label = 'statement') {
  const failures = [];
  const stmt = String(statement || '').trim();
  if (!stmt) return { ok: false, failures: [`${label}：语句为空`] };
  if (FORBIDDEN_STMT_RE.test(stmt)) {
    failures.push(`${label}：检测到禁用语句（DROP/TRUNCATE/RENAME/MODIFY）——${stmt.slice(0, 100)}`);
  }
  if (!ALLOWED_STMT_RE.test(stmt)) {
    failures.push(`${label}：非合法 DDL（应 CREATE TABLE/ALTER TABLE/CREATE INDEX/COMMENT ON）——${stmt.slice(0, 100)}`);
  }
  if (/^ALTER\s+TABLE/i.test(stmt)) {
    failures.push(...checkAddColumnNotNull(stmt).map((f) => `${label}：${f}`));
  }
  return { ok: failures.length === 0, failures };
}

/** 单个 .sql 文件：恰好一条语句 + 合法 DDL；不要求头部说明注释（分源单语句文件形态）。 */
export function checkMigrationFile(text, label = 'sql') {
  const failures = [];
  if (!String(text || '').trim()) return { ok: false, failures: [`${label}：文件为空`] };
  const stmts = splitSqlStatements(text);
  if (stmts.length === 0) return { ok: false, failures: [`${label}：无可执行语句`] };
  if (stmts.length > 1) {
    failures.push(`${label}：含 ${stmts.length} 条语句（单语句文件约定：一个操作一个文件，禁多语句批）`);
  }
  for (let i = 0; i < stmts.length; i++) {
    failures.push(...checkMigrationStatement(stmts[i], `${label}#${i + 1}`).failures);
  }
  return { ok: failures.length === 0, failures };
}

/** ALTER ADD COLUMN 可空 backstop：存量表扩展列不得 NOT NULL 无 DEFAULT。 */
function checkAddColumnNotNull(alterStmt) {
  const failures = [];
  const addColRe = /\bADD\s+COLUMN\s+/gi;
  let m;
  while ((m = addColRe.exec(alterStmt)) !== null) {
    const rest = alterStmt.slice(m.index + m[0].length);
    let end = rest.length;
    const commaIdx = rest.indexOf(',');
    const nextAdd = rest.search(/\bADD\s+COLUMN\s+/i);
    if (commaIdx >= 0) end = Math.min(end, commaIdx);
    if (nextAdd >= 0) end = Math.min(end, nextAdd);
    const colDef = rest.slice(0, end).trim();
    const nameM = colDef.match(/^`?([a-z_][\w]*)`?/i);
    const colName = nameM ? nameM[1] : '?';
    if (/\bNOT\s+NULL\b/i.test(colDef) && !/\bDEFAULT\b/i.test(colDef)) {
      failures.push(`ALTER ADD COLUMN ${colName} 含 NOT NULL 无 DEFAULT，存量历史行会违约，须允许为空`);
    }
  }
  return failures;
}

/** 迁移目录：只扫 `<sourceId>/*.sql`；operation 声明（若有 operations.json）可选校验。 */
export function checkMigrationDir(dir) {
  const failures = [];
  const root = resolve(dir);
  if (!existsSync(root) || !statSync(root).isDirectory()) {
    return { ok: false, failures: [`迁移目录不存在：${dir}`] };
  }
  const sourceDirs = readdirSync(root, { withFileTypes: true }).filter((d) => d.isDirectory());
  if (sourceDirs.length === 0) {
    return { ok: false, failures: [`迁移目录下无分源子目录（应 <sourceId>/<kind>-<name>-<ordinal>.sql）：${dir}`] };
  }
  let count = 0;
  for (const d of sourceDirs) {
    if (!SOURCE_ID_RE.test(d.name)) {
      failures.push(`迁移目录含非 sourceId 子目录：${d.name}（分源目录名必须为 src1.<32 位 base64url>）`);
      continue;
    }
    const files = readdirSync(join(root, d.name)).filter((f) => f.endsWith('.sql'));
    if (files.length === 0) failures.push(`source 目录 ${d.name} 下无 .sql 文件`);
    for (const f of files) {
      count++;
      const label = `${d.name}/${f}`;
      const rel = relative(root, join(root, d.name, f));
      if (rel.split(sep).includes('..')) {
        failures.push(`${label}：路径越界`);
        continue;
      }
      const text = readFileSync(join(root, d.name, f), 'utf-8');
      failures.push(...checkMigrationFile(text, label).failures);
    }
  }
  if (count === 0) failures.push('未找到任何迁移 SQL 文件');
  return { ok: failures.length === 0, failures };
}

// ─── 分派 ────────────────────────────────────────────────────────────────────
function runCli(argv) {
  const [,, mode, filePath] = argv;
  const flagArgs = argv.slice(3);
  const getFlag = (name) => {
    const i = flagArgs.indexOf(name);
    return i >= 0 ? flagArgs[i + 1] : null;
  };
  const entityDir = getFlag('--entity-dir');
  const retainedPath = getFlag('--retained');
  const gapsPath = getFlag('--gaps');

  if (!allowedModes.includes(mode) || !filePath) {
    console.error(`Usage: node check-incremental-schema.mjs <${allowedModes.join('|')}> <abs-path> [--entity-dir <dir> --retained <path> --gaps <path>]`);
    process.exit(1);
  }
  if (mode === 'retained' && (!entityDir || !retainedPath)) {
    console.error('retained 模式需 --entity-dir <dir> --retained <retained-tables.json>');
    process.exit(1);
  }
  if (mode === 'classification' && (!retainedPath || !gapsPath)) {
    console.error('classification 模式需 --retained <retained-tables.json> --gaps <coverage-gaps.json>');
    process.exit(1);
  }

  // migration 目录模式不预读文件
  if (mode === 'migration' && existsSync(filePath) && statSync(filePath).isDirectory()) {
    console.log(JSON.stringify(checkMigrationDir(filePath)));
    return;
  }

  let content;
  try {
    content = readFileSync(filePath, 'utf-8');
  } catch {
    console.log(JSON.stringify({ ok: false, failures: [`无法读取文件: ${filePath}`] }));
    return;
  }

  const r =
    mode === 'code-schema'
      ? checkCodeSchema(content)
      : mode === 'delta'
        ? checkDelta(content)
        : mode === 'migration'
          ? checkMigrationFile(content, filePath.split(sep).pop() || 'sql')
          : mode === 'classification'
            ? checkClassification(content, { retainedPath, gapsPath })
            : checkRetained(content, { entityDir, retainedPath });
  // 单行 JSON：与 check-code-table-inventory / check-table-structure-evidence 同族输出契约，
  // 编排侧按「整段 JSON」解析（多行 pretty 只取末行会得到 `}`）。
  console.log(JSON.stringify(r));
}

const _isMainEntry = process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]);
if (_isMainEntry) {
  runCli(process.argv);
}

export { OPERATION_KINDS };
