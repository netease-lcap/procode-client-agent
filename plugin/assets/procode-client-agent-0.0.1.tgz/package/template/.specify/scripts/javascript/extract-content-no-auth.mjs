import fs from 'fs';
import path from 'path';

import {
  toNumber,
  getTextInRange,
  getTextInBetween,
  getActiveSpecDir,
  readFile,
  readdirSync,
  readFileSync,
  readRawSpecContentSync,
  findUnderSpecs,
  removeUnderSpecs,
  filterUnderSpecs,
  writeToFileSync,
  writeQuoteToContent,
  formatWritedFiles,
  parse,
  parseToList,
  parsedToRaw,
  parseStemFromPath,
  getMenuCombinedName,
  auto,
} from './shared/index.mjs';

export const findQuotes = (item) => Boolean(item) && typeof item === 'string' && item.endsWith('pieces/quotes.md');
export const filterPoint = (item) => Boolean(item) && typeof item === 'string' && item.includes('pieces/point-');
export const filterDesign = (item) => Boolean(item) && typeof item === 'string' && item.includes('pieces/design-');
export const filterContent = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/content-');
export const filterDataModel = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/data-model-');
export const filterPointeDesign = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/point-design-');
export const filterContentDesign = (item) =>
  Boolean(item) && typeof item === 'string' && item.includes('pieces/content-design.md');

export const getCount =
  (source = '') =>
  (keyword = '') => {
    if (!keyword) {
      return 0;
    }

    const replaced = source.replace(keyword, '');

    if (replaced.length === source.length) {
      return 0;
    }

    return 1 + getCount(replaced)(keyword);
  };

export const getImageSegments = (rootDir = '') => {
  const specContent = readRawSpecContentSync(rootDir) || '';

  return getImageSegmentsFromSource(specContent);
};

export const getImageUrls = (source = '') => {
  const urls = [];
  const imageReg = /!\[[^\]]*\]\(([^)]+)\)/g;
  let matched;

  while ((matched = imageReg.exec(source))) {
    const [, url = ''] = matched;
    const normalized = url.trim();

    if (normalized && !urls.includes(normalized)) {
      urls.push(normalized);
    }
  }

  return urls;
};

export const getImageSegmentsFromSource = (source = '') => {
  const startKeyword = '<图片内容|start>';
  const endKeyword = '<图片内容|end>';

  const splitted = source
    .split('\n')
    .filter((item) => item?.trim?.());

  const lines = splitted.map((item = '', index) => {
    const isStart = item.includes(startKeyword);
    const isEnd = item.includes(endKeyword);

    return {
      index,
      item,
      isStart,
      isEnd,
    };
  });

  const startLines = lines.filter((item) => item.isStart);
  const endLines = lines.filter((item) => item.isEnd);

  return startLines.map((a, index) => {
    const { index: startIndex = 0 } = startLines[index] || {};
    const { index: endIndex = -1 } = endLines[index] || {};

    const keyword = splitted[startIndex + 1];

    const content = splitted.slice(startIndex, endIndex + 1).join('\n');

    const suffix = splitted.slice(startIndex + 1, endIndex + 1).join('\n');

    return { keyword, content, suffix, urls: getImageUrls(content) };
  });
};

export const fulfillImageSegmentsFromContent =
  (content = '') =>
  (source = '') => {
    const segments = getImageSegmentsFromSource(content);

    if (!source || !segments.length) {
      return source;
    }

    return segments.reduce((result = '', segment = {}) => {
      const { content = '', urls = [] } = segment;

      const some = (url = '') => result.includes(url);
      const included = urls.some(some);

      if (!content || included) {
        return result;
      }

      return `${result.replace(/\s*$/, '')}\n\n${content}`;
    }, source);
  };

export const fulfillDesignImageSegmentsFromContent = (
  designAbsoluteFilePath = ''
) => (content = '') => {
  const source = readFileSync(designAbsoluteFilePath) || '';
  const corrected = fulfillImageSegmentsFromContent(content)(source);

  if (corrected === source) {
    return;
  }

  writeToFileSync('design', designAbsoluteFilePath)(corrected);
};

export const correctImage = (rootDir = '') => {
  const segments = getImageSegments(rootDir);

  const reduce = (result = '', segment = {}) => {
    const { suffix = '', keyword = '', content = '' } = segment;

    const splitted = result.split('\n');

    const count = getCount(result)(content);
    const keywordIndexes = splitted.reduce((result = [], item = '', index) => {
      const included = item.includes(keyword);

      included && result.push(index);
      return result;
    }, []);

    if (count === keywordIndexes.length) {
      return result;
    }

    return keywordIndexes.reduce((current = '', keywordIndex) => {
      let prev = keyword;
      let next = keyword;
      let index = keywordIndex;

      while (suffix.includes(next)) {
        prev = next;

        index += 1;
        next = `${next}\n${splitted[index]}`;
      }

      return current.replace(prev, suffix);
    }, result);
  };

  return (source = '') => segments.reduce(reduce, source);
};

export const fixPoint = (absoluteFilePath = '') => {
  const source = readFileSync(absoluteFilePath) || '';

  if (!source) {
    return;
  }


  const useless = ['design', '整体需求'];
  const string = parseStemFromPath(absoluteFilePath);
  const reg = new RegExp(`\\n-[^\\n]+`);

  if (useless.includes(string)) {
    return;
  }

  const correct = reg.test(source);

  if (correct) {
    return;
  }

  const designable = absoluteFilePath.includes('design');
  const suffix = designable ? '-视觉规范页面组件' : '';
  const got = `- **${string}${suffix}**：`;

  const replace = (current) => `${current}\n\n${got}`;
  const replaced = source.replace(/^[\s\n]*#[^\n]+/g, replace);

  writeToFileSync(string, absoluteFilePath)(replaced);
};

export const mergePointSubsets = (absoluteFilePath = '') => {
  const source = readFileSync(absoluteFilePath) || '';
  const list = parseToList()(source);

  if (list.length < 2) {
    return;
  }

  const first = list[0];
  const content = parsedToRaw({
    ...first,
    children: list.flatMap((item) => item.children || []),
  }, '\n');
  const prefix = source.split('\n').slice(0, first.start - 1).join('\n');
  const merged = `${prefix}\n${content}\n`;

  if (merged !== source) {
    writeToFileSync(parseStemFromPath(absoluteFilePath), absoluteFilePath, '\n')(merged);
  }
};

export const toRaw = (rootDir) => {
  rootDir = rootDir || process.cwd();

  removeUnderSpecs(rootDir)(filterDesign);
  removeUnderSpecs(rootDir)(filterContent);
  removeUnderSpecs(rootDir)(filterDataModel);

  const options = { rootDir };

  const {
    absoluteDir,
    relativeFilePath: quotesFilePath,
    absoluteFilePath: quotesAbsoluteFilePath,
  } = findUnderSpecs(rootDir)(findQuotes) || {};

  const pointBundles = filterUnderSpecs(rootDir)(filterPoint);

  if (!absoluteDir || !quotesAbsoluteFilePath) {
    const activeSpecDir = getActiveSpecDir(rootDir);
    throw new Error(`缺少原始引用文档：${activeSpecDir}/pieces/quotes.md`);
  }

  const mainAbsoluteFilePath = path.resolve(absoluteDir, 'content.md');
  const mainFile = writeQuoteToContent(rootDir, '关键内容')(quotesAbsoluteFilePath, mainAbsoluteFilePath);

  const files = pointBundles.map((bundle = {}) => {
    const { relativeFilePath, absoluteFilePath, absoluteDir: bundleAbsoluteDir } = bundle;

    const name = parseStemFromPath(relativeFilePath);
    const designable = filterPointeDesign(relativeFilePath);

    const fileName = designable ? `design-${name}.md` : `content-${name}.md`;
    const displayName = designable ? `设计内容-${name}` : `关键内容-${name}`;

    const contentAbsoluteFilePath = path.resolve(bundleAbsoluteDir, fileName);

    fixPoint(absoluteFilePath);
    mergePointSubsets(absoluteFilePath);
    return writeQuoteToContent(rootDir, displayName)(absoluteFilePath, contentAbsoluteFilePath);
  });

  const designBundles = filterUnderSpecs(rootDir)(filterDesign);
  const contentBundles = filterUnderSpecs(rootDir)(filterContent);

  designBundles.forEach((bundle = {}) => {
    const { absoluteDir, relativeFilePath, absoluteFilePath } = bundle;

    const parsed = parse(options)(absoluteFilePath) || [];

    parsed.map((item = {}) => {
      const { title = '' } = item;

      const parts = title.split('-');
      const label = getMenuCombinedName(parts.slice(0, -1));

      if (!label) {
        return;
      }

      const content = parsedToRaw(item);
      const fileName = `design-${label}.md`;
      const absoluteFilePath = path.resolve(absoluteDir, fileName);

      const corrected = correctImage(rootDir)(content);

      writeToFileSync(fileName, absoluteFilePath)(corrected);
    });
  });

  contentBundles.forEach((bundle = {}) => {
    const { absoluteDir, relativeFilePath, absoluteFilePath } = bundle;

    const parsed = parse(options)(absoluteFilePath) || [];

    parsed.map((item = {}) => {
      const { title = '' } = item;

      const source = title.replace('【标题】', '');
      const parts = source.split('-');
      const label = getMenuCombinedName(parts);

      if (!label) {
        return;
      }

      const content = parsedToRaw(item);

      const contentAbsoluteFilePath = path.resolve(absoluteDir, `content-${label}.md`);
      const dataModelAbsoluteFilePath = path.resolve(absoluteDir, `data-model-${label}.md`);
      const designAbsoluteFilePath = path.resolve(absoluteDir, `design-${label}.md`);

      // 保留实际引用内容，不把需求分析来源推断为权限默认补全。
      const finalContent = content;

      writeToFileSync(label, contentAbsoluteFilePath)(finalContent);
      label !== '视觉规范页面组件' && writeToFileSync(label, dataModelAbsoluteFilePath)(finalContent);

      fulfillDesignImageSegmentsFromContent(designAbsoluteFilePath)(content);
    });
  });

  return formatWritedFiles('关键内容文档列表')([mainFile, ...files]);
};

auto(import.meta)(toRaw);

export default toRaw;
