export const handle = async (callback) => {
  const filePath = process.argv.filter(Boolean).find((item) => item?.endsWith?.('.md'));

  const rootDir = process.cwd();
  const result = await callback(rootDir, filePath);
  const lines = result.split('\n').filter(Boolean);

  if (lines.length <= 1) {
    return;
  }

  throw new Error(result);
};
