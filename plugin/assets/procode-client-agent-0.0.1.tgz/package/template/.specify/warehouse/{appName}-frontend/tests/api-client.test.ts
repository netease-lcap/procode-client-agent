import { AxiosError, AxiosHeaders, type AxiosAdapter, type AxiosResponse } from 'axios';
import { afterEach, describe, expect, it, vi } from 'vitest';

import { ApiClient } from '../src/api/client';

const createAdapter = (handler: (config: Parameters<AxiosAdapter>[0]) => AxiosResponse): AxiosAdapter =>
  async (config) => handler(config);

afterEach(() => {
  vi.restoreAllMocks();
});

describe('ApiClient axios foundation', () => {
  it('keeps requests on /api and delegates JSON plus auth handling to axios', async () => {
    const adapter = vi.fn(
      createAdapter((config) => ({
        data: { url: `${config.baseURL}${config.url}`, body: config.data },
        status: 200,
        statusText: 'OK',
        headers: new AxiosHeaders({ 'content-type': 'application/json' }),
        config,
      })),
    );
    const client = new ApiClient({ adapter, getAuthToken: () => 'test-token' });

    await expect(client.request('/records', { method: 'POST', data: { name: 'record' } })).resolves.toEqual({
      url: '/api/records',
      body: '{"name":"record"}',
    });
    const config = adapter.mock.calls[0][0];
    expect(config.headers.get('Authorization')).toBe('Bearer test-token');
  });

  it('exposes the axios instance for standard interceptors and response modes', async () => {
    const adapter = createAdapter((config) => ({
      data: new Blob(['download']),
      status: 200,
      statusText: 'OK',
      headers: new AxiosHeaders(),
      config,
    }));
    const client = new ApiClient({ adapter });
    client.http.interceptors.request.use((config) => {
      config.headers.set('x-project-context', 'enabled');
      return config;
    });

    const response = await client.requestResponse<Blob>('/download', { responseType: 'blob' });
    expect(response.data).toBeInstanceOf(Blob);
    expect(response.config.headers.get('x-project-context')).toBe('enabled');
  });

  it('rejects absolute backend addresses before the adapter runs', async () => {
    const adapter = vi.fn(createAdapter(() => {
      throw new Error('adapter must not run');
    }));
    const client = new ApiClient({ adapter });

    await expect(client.request('http://127.0.0.1:6003/private')).rejects.toThrow(
      '浏览器 API 请求禁止使用绝对后端地址',
    );
    expect(adapter).not.toHaveBeenCalled();
  });

  it('uses axios error handling and reports failures through the common event hook', async () => {
    const onError = vi.fn();
    const adapter: AxiosAdapter = async (config) => {
      throw new AxiosError('timeout', AxiosError.ETIMEDOUT, config);
    };
    const client = new ApiClient({ adapter, onError });

    await expect(client.request('/slow')).rejects.toMatchObject({ code: AxiosError.ETIMEDOUT });
    expect(onError).toHaveBeenCalledWith(expect.objectContaining({ code: AxiosError.ETIMEDOUT }));
  });
});
