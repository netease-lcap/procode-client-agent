import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const distRoot = path.join(projectRoot, 'dist');
const indexPath = path.join(distRoot, 'index.html');

const fail = (message) => {
  throw new Error(`[verify-dist] ${message}`);
};

const listFiles = (directory) =>
  fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const absolutePath = path.join(directory, entry.name);
    return entry.isDirectory() ? listFiles(absolutePath) : [absolutePath];
  });

const resolveDistResource = (relativePath, owner = indexPath) => {
  const cleanPath = relativePath.split(/[?#]/, 1)[0];
  const absolutePath = path.resolve(path.dirname(owner), cleanPath);
  if (absolutePath !== distRoot && !absolutePath.startsWith(`${distRoot}${path.sep}`)) {
    fail(`资源引用越出 dist: ${relativePath}`);
  }
  return absolutePath;
};

const isExternalResource = (value) => /^(?:[a-z][a-z\d+.-]*:|\/\/|#)/i.test(value);

if (!fs.existsSync(indexPath)) fail('dist/index.html 不存在');
const html = fs.readFileSync(indexPath, 'utf8');
if (!html.trim()) fail('dist/index.html 为空');
if (!html.includes('data-ui-base-path-bootstrap')) fail('缺少 __UI_BASE_PATH__ 资源启动层');
if (html.includes('window.UIBasePath')) fail('仍存在旧变量 window.UIBasePath');
if (/<script\b[^>]*type=["']module["'][^>]*src=/i.test(html)) fail('入口 module script 未交由启动层管理');
if (/<link\b[^>]*rel=["'](?:stylesheet|modulepreload|manifest|icon)["']/i.test(html)) {
  fail('构建资源 link 未交由启动层管理');
}

const bootstrapIndex = html.indexOf('data-ui-base-path-bootstrap');
const headEndIndex = html.indexOf('</head>');
const htmlEndIndex = html.indexOf('</html>');
if (bootstrapIndex < 0 || headEndIndex < 0 || bootstrapIndex > headEndIndex) {
  fail('资源启动层不在合法 head 内');
}
if (htmlEndIndex >= 0 && bootstrapIndex > htmlEndIndex) fail('资源启动层错误地位于 </html> 之后');

const resourceListMatch = html.match(/const resources = (\[[^;]*\]);/);
if (!resourceListMatch) fail('资源启动层缺少可验证的入口资源清单');
const entryResources = JSON.parse(resourceListMatch[1]);
if (!Array.isArray(entryResources) || !entryResources.some((resource) => resource.kind === 'script')) {
  fail('入口资源清单缺少应用脚本');
}
for (const resource of entryResources) {
  if (typeof resource?.url !== 'string' || isExternalResource(resource.url)) continue;
  const resourcePath = resolveDistResource(resource.url);
  if (!fs.existsSync(resourcePath) || !fs.statSync(resourcePath).isFile()) {
    fail(`入口资源不存在: ${resource.url}`);
  }
}

const files = listFiles(distRoot);
const textAssets = files.filter((file) => /\.(?:css|js|html)$/i.test(file));
for (const file of textAssets) {
  const content = fs.readFileSync(file, 'utf8');
  if (/(?:["'(])\/assets\//.test(content)) {
    fail(`${path.relative(distRoot, file)} 中仍存在绕过前缀的 /assets/ 引用`);
  }
  if (path.extname(file).toLowerCase() !== '.css') continue;
  for (const match of content.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/gi)) {
    const resourceUrl = match[1];
    if (isExternalResource(resourceUrl) || resourceUrl.startsWith('data:')) continue;
    const resourcePath = resolveDistResource(resourceUrl, file);
    if (!fs.existsSync(resourcePath) || !fs.statSync(resourcePath).isFile()) {
      fail(`${path.relative(distRoot, file)} 引用的 CSS 资源不存在: ${resourceUrl}`);
    }
  }
}

process.stdout.write(`[verify-dist] verified ${files.length} production files\n`);
