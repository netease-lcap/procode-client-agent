import { describe, expect, it } from 'vitest';

import {
  collectHtmlResources,
  createSourceContentTracker,
  findUnmanagedHtmlResources,
  normalizeBuildAssetPath,
  normalizePreviewBasePath,
  resolveDevelopmentWebSocketRequest,
  resolvePreviewResourceAlias,
} from '../vite.config';

describe('UI base path build contract', () => {
  it('normalizes root and relative build asset paths', () => {
    expect(normalizeBuildAssetPath('/assets/main.js')).toBe('assets/main.js');
    expect(normalizeBuildAssetPath('./assets/main.css')).toBe('assets/main.css');
  });

  it('keeps resource kinds separate so CSS is never emitted as modulepreload', () => {
    const resources = collectHtmlResources(`
      <link rel="modulepreload" href="./assets/vendor.js">
      <link rel="stylesheet" href="./assets/main.css">
      <link rel="icon" href="/favicon.svg">
      <link rel="manifest" href="/manifest.webmanifest">
      <script type="module" src="./assets/main.js"></script>
    `);

    expect(resources).toEqual([
      { kind: 'modulepreload', url: 'assets/vendor.js' },
      { kind: 'stylesheet', url: 'assets/main.css' },
      { kind: 'icon', url: 'favicon.svg' },
      { kind: 'manifest', url: 'manifest.webmanifest' },
      { kind: 'script', url: 'assets/main.js' },
    ]);
  });

  it('rejects local HTML resources that would bypass the runtime prefix', () => {
    expect(
      findUnmanagedHtmlResources(`
        <img src="./assets/hero.png" srcset="./assets/hero.png 1x, ./assets/hero@2x.png 2x">
        <video poster="/assets/poster.webp"></video>
        <object data="./assets/document.pdf"></object>
        <svg><image href="./assets/sprite.svg"></image></svg>
        <link rel="preload" as="font" href="./assets/font.woff2">
        <script src="./legacy.js"></script>
      `),
    ).toEqual([
      'src=./assets/hero.png',
      'srcset=./assets/hero.png',
      'srcset=./assets/hero@2x.png',
      'poster=/assets/poster.webp',
      'data=./assets/document.pdf',
      'link=./assets/font.woff2',
      'script=./legacy.js',
      'href=./assets/sprite.svg',
    ]);
  });

  it('allows external, data and fragment references outside the managed build graph', () => {
    expect(
      findUnmanagedHtmlResources(`
        <img src="https://cdn.example.com/independent.png">
        <img src="data:image/svg+xml,example">
        <img data-src="./assets/lazy-runtime-image.png">
        <link rel="canonical" href="/current-page">
        <svg><use href="#symbol"></use></svg>
      `),
    ).toEqual([]);
  });
});

describe('development HMR continuity', () => {
  it('distinguishes a real source change from repeated identical writes', () => {
    const tracker = createSourceContentTracker();
    const file = new URL('../src/runtime/probe.ts', import.meta.url).pathname;

    tracker.remember(file, 'export const value = 1;\n');
    expect(tracker.hasChanged(file, 'export const value = 1;\n')).toBe(false);
    expect(tracker.hasChanged(file, 'export const value = 2;\n')).toBe(true);
    expect(tracker.hasChanged(file, 'export const value = 2;\n')).toBe(false);
  });

  it('normalizes the fixed Vite preview base before the server starts', () => {
    expect(normalizePreviewBasePath(undefined)).toBe('/');
    expect(normalizePreviewBasePath('__prototype__')).toBe('/__prototype__/');
    expect(normalizePreviewBasePath('/__prototype__/')).toBe('/__prototype__/');
    expect(normalizePreviewBasePath('https://assets.example.com/prototype')).toBe(
      'https://assets.example.com/prototype/',
    );
    expect(() => normalizePreviewBasePath('/__prototype__/?tenant=1')).toThrow(
      'VITE_PREVIEW_BASE_PATH 不能包含查询参数或哈希',
    );
  });

  it('serves development resources with or without the fixed preview base', () => {
    expect(resolvePreviewResourceAlias('/', '/__prototype__/')).toBe('/__prototype__/');
    expect(resolvePreviewResourceAlias('/?source=direct', '/__prototype__/')).toBe(
      '/__prototype__/?source=direct',
    );
    expect(resolvePreviewResourceAlias('/@vite/client', '/__prototype__/')).toBe(
      '/__prototype__/@vite/client',
    );
    expect(resolvePreviewResourceAlias('/@react-refresh', '/__prototype__/')).toBe(
      '/__prototype__/@react-refresh',
    );
    expect(resolvePreviewResourceAlias('/src/main.ts?import', '/__prototype__/')).toBe(
      '/__prototype__/src/main.ts?import',
    );
    expect(resolvePreviewResourceAlias('/assets/logo.svg', '/__prototype__/')).toBe(
      '/__prototype__/assets/logo.svg',
    );
    expect(resolvePreviewResourceAlias('/__prototype__/src/main.ts', '/__prototype__/')).toBeNull();
    expect(resolvePreviewResourceAlias('/api/customers.json', '/__prototype__/')).toBeNull();
    expect(resolvePreviewResourceAlias('/dashboard', '/__prototype__/')).toBeNull();
  });

  it('accepts Vite HMR websocket requests with or without the fixed preview base', () => {
    expect(resolveDevelopmentWebSocketRequest('/?token=hmr-token', '/__prototype__/')).toBe(
      '/__prototype__/?token=hmr-token',
    );
    expect(resolveDevelopmentWebSocketRequest('/__prototype__/?token=hmr-token', '/__prototype__/')).toBeNull();
    expect(resolveDevelopmentWebSocketRequest('/api/socket?token=api-token', '/__prototype__/')).toBeNull();
    expect(resolveDevelopmentWebSocketRequest('/?token=hmr-token', '/')).toBeNull();
  });
});
