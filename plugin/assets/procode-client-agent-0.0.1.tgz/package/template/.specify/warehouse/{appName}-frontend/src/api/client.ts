import axios, {
  AxiosError,
  type AxiosAdapter,
  type AxiosInstance,
  type AxiosRequestConfig,
  type AxiosResponse,
  type InternalAxiosRequestConfig,
} from 'axios';

const DEFAULT_API_BASE_URL = '/api';
const DEFAULT_TIMEOUT_MS = 30_000;

export interface ApiRequestConfig<Data = unknown> extends AxiosRequestConfig<Data> {
  skipAuth?: boolean;
}

export interface ApiClientOptions {
  baseURL?: string;
  timeoutMs?: number;
  adapter?: AxiosAdapter;
  getAuthToken?: () => string | null | undefined | Promise<string | null | undefined>;
  onError?: (error: AxiosError) => void;
}

const normalizeBaseURL = (baseURL: string): string => {
  const normalized = `/${baseURL}`.replace(/\/+/g, '/').replace(/\/$/, '');
  if (normalized !== DEFAULT_API_BASE_URL && !normalized.startsWith(`${DEFAULT_API_BASE_URL}/`)) {
    throw new Error('API baseURL 必须使用同源 /api 路径');
  }
  return normalized;
};

const normalizeRequestPath = (baseURL: string, requestPath = ''): string => {
  if (/^[a-z][a-z\d+.-]*:/i.test(requestPath) || requestPath.startsWith('//')) {
    throw new Error('浏览器 API 请求禁止使用绝对后端地址');
  }
  if (requestPath === baseURL) return '';
  if (requestPath.startsWith(`${baseURL}/`)) return requestPath.slice(baseURL.length);
  return requestPath.startsWith('/') ? requestPath : `/${requestPath}`;
};

const emitApiError = (error: AxiosError): void => {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('app:api-error', { detail: error }));
  }
};

export class ApiClient {
  readonly http: AxiosInstance;

  constructor(private readonly options: ApiClientOptions = {}) {
    const baseURL = normalizeBaseURL(options.baseURL || DEFAULT_API_BASE_URL);
    this.http = axios.create({
      baseURL,
      timeout: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
      withCredentials: true,
      adapter: options.adapter,
    });

    this.http.interceptors.request.use(async (config) => {
      const requestConfig = config as InternalAxiosRequestConfig & ApiRequestConfig;
      requestConfig.url = normalizeRequestPath(baseURL, requestConfig.url);
      if (!requestConfig.skipAuth && !requestConfig.headers.has('Authorization') && options.getAuthToken) {
        const token = await options.getAuthToken();
        if (token) requestConfig.headers.set('Authorization', `Bearer ${token}`);
      }
      delete requestConfig.skipAuth;
      return requestConfig;
    });

    this.http.interceptors.response.use(undefined, (reason: unknown) => {
      const error = axios.isAxiosError(reason)
        ? reason
        : AxiosError.from(reason, AxiosError.ERR_NETWORK);
      this.options.onError?.(error);
      emitApiError(error);
      return Promise.reject(error);
    });
  }

  async request<ResponseData = unknown, RequestData = unknown>(
    path: string,
    config: ApiRequestConfig<RequestData> = {},
  ): Promise<ResponseData> {
    const response = await this.requestResponse<ResponseData, RequestData>(path, config);
    return response.data;
  }

  requestResponse<ResponseData = unknown, RequestData = unknown>(
    path: string,
    config: ApiRequestConfig<RequestData> = {},
  ): Promise<AxiosResponse<ResponseData, RequestData>> {
    return this.http.request<ResponseData, AxiosResponse<ResponseData, RequestData>, RequestData>({
      ...config,
      url: path,
    });
  }
}

export const apiClient = new ApiClient();
export const apiRequest = <ResponseData = unknown, RequestData = unknown>(
  path: string,
  config?: ApiRequestConfig<RequestData>,
): Promise<ResponseData> => apiClient.request<ResponseData, RequestData>(path, config);
