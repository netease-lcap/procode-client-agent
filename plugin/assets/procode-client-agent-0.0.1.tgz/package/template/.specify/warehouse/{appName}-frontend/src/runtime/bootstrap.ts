interface MountOptions {
  importedResourceUrl: string;
}

const reportRuntimeError = (reason: unknown): void => {
  console.error('[frontend-runtime]', reason);
  window.dispatchEvent(new CustomEvent('app:runtime-error', { detail: reason }));
};

export const mountApplication = (root: HTMLElement, options: MountOptions): void => {
  window.addEventListener('error', (event) => reportRuntimeError(event.error || event.message));
  window.addEventListener('unhandledrejection', (event) => reportRuntimeError(event.reason));

  const heading = document.createElement('h1');
  heading.id = 'app-ready-title';
  heading.textContent = 'Frontend Application';

  const status = document.createElement('p');
  status.id = 'app-ready-status';
  status.dataset.debugId = 'app-ready-status';
  status.textContent = 'Frontend application is ready.';

  const importedResource = document.createElement('img');
  importedResource.src = options.importedResourceUrl;
  importedResource.alt = '';
  importedResource.setAttribute('aria-hidden', 'true');
  importedResource.dataset.debugId = 'js-imported-resource-probe';
  importedResource.className = 'engineering-resource-probe';

  const cssResource = document.createElement('span');
  cssResource.setAttribute('aria-hidden', 'true');
  cssResource.dataset.debugId = 'css-url-resource-probe';
  cssResource.className = 'engineering-css-resource-probe';

  root.replaceChildren(heading, status, importedResource, cssResource);
  root.dataset.appReady = 'true';
  window.dispatchEvent(new CustomEvent('app:ready'));
};
