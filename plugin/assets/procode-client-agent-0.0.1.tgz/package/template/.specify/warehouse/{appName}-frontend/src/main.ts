import importedResourceUrl from '@/assets/imported-resource.svg';
import { mountApplication } from '@/runtime/bootstrap';
import '@/styles/global.css';

const root = document.querySelector<HTMLElement>('#app');

if (!root) {
  throw new Error('应用启动入口 #app 不存在');
}

mountApplication(root, { importedResourceUrl });

void import('@/runtime/lazy-probe').then(({ mountLazyProbe }) => {
  mountLazyProbe(root);
});
