import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { afterEach, beforeEach, expect, it } from 'vitest';
import { build, createServer } from 'vite';
import { createFrontendDomainsPlugin, createUiBasePathHtmlPlugin, readFrontendDomains, resolveServiceRegistryFile } from '../vite.config';

let root: string;
let file: string;
const entry = (serviceName: string, businessType = 'application', url = `https://${serviceName}.example/`) => ({
  serviceName, serviceType: 'frontend', businessType,
  domain: { serviceName, portName: null, domain: `${serviceName}.example`, basePath: '/', url },
});
beforeEach(() => {
  root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'frontend-domains-')));
  file = path.join(root, 'app-services.json');
});
afterEach(() => fs.rmSync(root, { recursive: true, force: true }));

it('resolves the registry by project location, not cwd or service name', () => {
  expect(resolveServiceRegistryFile('/workspace/my-app/custom-frontend')).toBe('/workspace/my-app/my-app-services.json');
});

it('exposes both frontend kinds but no backend or service metadata', () => {
  fs.writeFileSync(file, JSON.stringify([
    entry('web'), entry('prototype', 'prototype'),
    { ...entry('backend'), serviceType: 'backend' },
    { serviceName: 'pending', serviceType: 'frontend', domain: null }, null,
  ]));
  expect(readFrontendDomains(file)).toEqual({ web: 'https://web.example/', prototype: 'https://prototype.example/' });
});

it('tolerates missing, unreadable and invalid data without blocking valid records', () => {
  expect(readFrontendDomains(file)).toEqual({});
  expect(readFrontendDomains(root)).toEqual({});
  fs.writeFileSync(file, '[]');
  expect(readFrontendDomains(file)).toEqual({});
  for (const data of ['broken', '{}', 'null', '[null,{},42]', JSON.stringify([entry('web', 'application', 'javascript:alert(1)')])]) {
    fs.writeFileSync(file, data);
    expect(readFrontendDomains(file)).toEqual({});
  }
  fs.writeFileSync(file, JSON.stringify([entry('bad', 'application', 'invalid url'), entry('web'), entry('web', 'application', 'https://other.example'), entry('mobile')]));
  expect(readFrontendDomains(file)).toEqual({ web: 'https://web.example/', mobile: 'https://mobile.example/' });
});

it('injects before application scripts in dev and safely coexists with the production resource bootstrap', async () => {
  const url = 'https://web.example/path?q=</script><script>bad()</script>';
  fs.writeFileSync(file, JSON.stringify([entry('web', 'application', url)]));
  fs.writeFileSync(path.join(root, 'index.html'), '<html><head><script type="module" src="/main.js"></script></head><body></body></html>');
  fs.writeFileSync(path.join(root, 'main.js'), 'console.log(window.domains);');
  const config = { root, configFile: false as const, logLevel: 'silent' as const, plugins: [createFrontendDomainsPlugin(file), createUiBasePathHtmlPlugin()] };
  const server = await createServer({ ...config, plugins: [createFrontendDomainsPlugin(file)], server: { middlewareMode: true } });
  const verify = (html: string) => {
    const script = html.match(/<script[^>]*data-service-domains[^>]*>([\s\S]*?)<\/script>/);
    expect(script).not.toBeNull();
    expect(script![1]).not.toContain('</script>');
    const context = { window: {} as { domains?: Record<string, string> } };
    vm.runInNewContext(script![1], context);
    expect(context.window.domains?.web).toBe(url);
    expect(html).not.toContain('"businessType"');
  };
  try {
    const html = await server.transformIndexHtml('/', fs.readFileSync(path.join(root, 'index.html'), 'utf8'));
    verify(html);
    expect(html.indexOf('data-service-domains')).toBeLessThan(html.indexOf('src="/main.js"'));
    fs.writeFileSync(file, JSON.stringify([entry('updated')]));
    expect(await server.transformIndexHtml('/', '<html><head></head></html>')).toContain('https://updated.example/');
    fs.writeFileSync(file, 'broken');
    expect(await server.transformIndexHtml('/', '<html><head></head></html>')).toContain('window.domains = {};');
    fs.writeFileSync(file, JSON.stringify([entry('web', 'application', url)]));
  } finally {
    await server.close();
  }
  await build({ ...config, base: './' });
  const html = fs.readFileSync(path.join(root, 'dist/index.html'), 'utf8');
  verify(html);
  expect(html.indexOf('data-service-domains')).toBeLessThan(html.indexOf('data-ui-base-path-bootstrap'));
});
