import './lazy-probe.css';

export const mountLazyProbe = (root: HTMLElement): void => {
  const marker = document.createElement('span');
  marker.setAttribute('aria-hidden', 'true');
  marker.dataset.debugId = 'lazy-chunk-resource-probe';
  marker.className = 'engineering-lazy-resource-probe';
  root.appendChild(marker);
};
