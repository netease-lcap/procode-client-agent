import { createHash } from 'node:crypto';
import fs from 'node:fs';
import type { IncomingMessage } from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { defineConfig, type Plugin, type ProxyOptions, type ViteDevServer } from 'vite';

const projectRoot = path.dirname(fileURLToPath(import.meta.url));
const host = process.env.HOST || '0.0.0.0';
const sourceRoot = path.join(projectRoot, 'src');
const developmentResourceRoots = ['@vite', '@id', '@fs', '@react-refresh', 'src', 'node_modules'] as const;
const developmentPublicResources = ['favicon.svg', 'manifest.webmanifest'] as const;

const sourceDigest = (content: string): string => createHash('sha256').update(content).digest('hex');

/** 工程位于 <appName>/<serviceName>，只消费项目清单，不查询或注册服务。 */
export const resolveServiceRegistryFile = (frontendRoot = projectRoot): string => {
  const appRoot = path.dirname(frontendRoot);
  return path.join(appRoot, `${path.basename(appRoot)}-services.json`);
};

export const readFrontendDomains = (file = resolveServiceRegistryFile()): Record<string, string> => {
  let content: string;
  try {
    content = fs.readFileSync(file, 'utf8');
  } catch {
    return {};
  }
  try {
    const services: unknown = JSON.parse(content);
    if (!Array.isArray(services)) return {};
    const domains: Record<string, string> = Object.create(null);
    for (const service of services) {
      if (!service || service.serviceType !== 'frontend' || service.domain == null) continue;
      const { serviceName, domain } = service;
      if (typeof serviceName !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(serviceName)
        || Array.isArray(domain) || domain.serviceName !== serviceName || typeof domain.url !== 'string') {
        continue;
      }
      try {
        const url = new URL(domain.url);
        if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) continue;
      } catch {
        continue;
      }
      // 重复名称保留第一条有效记录，不因坏数据阻断其他服务或构建。
      if (Object.hasOwn(domains, serviceName)) continue;
      domains[serviceName] = domain.url;
    }
    return domains;
  } catch {
    return {};
  }
};

/** 同时用于 dev 与 build；在应用入口与发布资源启动脚本之前注入安全 JSON。 */
export const createFrontendDomainsPlugin = (file = resolveServiceRegistryFile()): Plugin => ({
  name: 'warehouse-frontend-domains',
  transformIndexHtml: {
    order: 'post',
    handler() {
      let json = '{}';
      try {
        json = JSON.stringify(readFrontendDomains(file))
          .replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
      } catch {
        // 域名是辅助导航数据，任何异常均降级为空映射，不阻断页面生成。
      }
      return [{ tag: 'script', attrs: { 'data-service-domains': true }, children: `window.domains = ${json};`, injectTo: 'head-prepend' }];
    },
  },
});

export const normalizePreviewBasePath = (value: string | undefined): string => {
  const normalized = value?.trim();
  if (!normalized) return '/';
  if (/[?#]/.test(normalized)) {
    throw new Error(`VITE_PREVIEW_BASE_PATH 不能包含查询参数或哈希：${normalized}`);
  }
  if (/^[a-z][a-z\d+.-]*:\/\//i.test(normalized)) {
    return normalized.endsWith('/') ? normalized : `${normalized}/`;
  }
  return `/${normalized.replace(/^\/+|\/+$/g, '')}/`;
};

const previewInternalResourceRoots = ['/@vite/', '/@id/', '/@fs/', '/@react-refresh', '/src/', '/node_modules/'];

export const resolvePreviewResourceAlias = (url: string, base: string): string | null => {
  const basePath = new URL(base, 'http://preview.local').pathname;
  if (basePath === '/') return null;

  const requestUrl = new URL(url, 'http://preview.local');
  if (requestUrl.pathname === basePath.slice(0, -1) || requestUrl.pathname.startsWith(basePath)) return null;
  if (requestUrl.pathname === '/api' || requestUrl.pathname.startsWith('/api/')) return null;
  if (requestUrl.pathname === '/') return `${basePath}${requestUrl.search}`;

  const isInternalResource = previewInternalResourceRoots.some(
    (root) => requestUrl.pathname === root.replace(/\/$/, '') || requestUrl.pathname.startsWith(root),
  );
  const lastSegment = requestUrl.pathname.slice(requestUrl.pathname.lastIndexOf('/') + 1);
  const isFileResource = lastSegment.includes('.') && lastSegment !== '.' && lastSegment !== '..';
  if (!isInternalResource && !isFileResource) return null;

  return `${basePath.slice(0, -1)}${requestUrl.pathname}${requestUrl.search}`;
};

export const createPreviewBaseAliasPlugin = (base: string): Plugin => ({
  name: 'warehouse-preview-base-alias',
  apply: 'serve',
  enforce: 'pre',
  configurePreviewServer(server) {
    // 在 Vite 的 baseMiddleware 前内部映射，避免根路径被 302 重定向。
    // 使用最终配置，兼容 vite preview --base 对模板 base 的覆盖。
    server.middlewares.use((request, _response, next) => {
      if (request.url) request.url = resolvePreviewResourceAlias(request.url, server.config.base) || request.url;
      next();
    });
  },
  configureServer(server) {
    const handleUpgrade = (request: IncomingMessage) => {
      if (!request.url) return;
      const protocols = String(request.headers['sec-websocket-protocol'] || '')
        .split(',')
        .map((protocol) => protocol.trim());
      if (!protocols.includes('vite-hmr')) return;
      request.url = resolveDevelopmentWebSocketRequest(request.url, base) || request.url;
    };
    server.httpServer?.prependListener('upgrade', handleUpgrade);
    server.httpServer?.once('close', () => server.httpServer?.removeListener('upgrade', handleUpgrade));

    server.middlewares.use((request, _response, next) => {
      if (request.url) request.url = resolvePreviewResourceAlias(request.url, base) || request.url;
      next();
    });
  },
});

export const createSourceContentTracker = () => {
  const digests = new Map<string, string>();

  return {
    remember(file: string, content: string) {
      digests.set(path.resolve(file), sourceDigest(content));
    },
    hasChanged(file: string, content: string): boolean {
      const normalizedFile = path.resolve(file);
      const nextDigest = sourceDigest(content);
      const previousDigest = digests.get(normalizedFile);
      digests.set(normalizedFile, nextDigest);
      return previousDigest !== nextDigest;
    },
  };
};

export interface DevelopmentResourceRequest {
  prefix: string;
  url: string;
}

export const resolveDevelopmentResourceRequest = (url: string): DevelopmentResourceRequest | null => {
  const [pathname] = url.split('?', 1);
  const candidates = [
    ...developmentResourceRoots.map((root) => {
      const marker = `/${root}`;
      const index = pathname.indexOf(marker);
      if (index <= 0) return -1;
      const nextCharacter = pathname[index + marker.length];
      return nextCharacter === '/' || (root === '@react-refresh' && nextCharacter === undefined) ? index : -1;
    }),
    ...developmentPublicResources.map((resource) =>
      pathname.endsWith(`/${resource}`) ? pathname.length - resource.length - 1 : -1,
    ),
  ].filter((index) => index > 0);
  if (candidates.length === 0) return null;

  const resourceIndex = Math.min(...candidates);
  return {
    prefix: `${pathname.slice(0, resourceIndex).replace(/\/+$/, '')}/`,
    url: url.slice(resourceIndex),
  };
};

export const resolveDevelopmentWebSocketRequest = (url: string, base: string): string | null => {
  const basePath = new URL(base, 'http://preview.local').pathname;
  if (basePath === '/') return null;

  const requestUrl = new URL(url, 'http://preview.local');
  if (requestUrl.pathname !== '/') return null;
  return `${basePath}${requestUrl.search}`;
};

export const rewriteDevelopmentResourceUrls = (source: string, prefix: string): string => {
  const normalizedPrefix = `/${prefix.replace(/^\/+|\/+$/g, '')}/`;
  const resourceRoot = developmentResourceRoots.map((value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const quotedResource = new RegExp(`(["'\\\`])\\/(${resourceRoot})(?=[\\/?#"'\\\`])`, 'g');
  const cssResource = new RegExp(`(url\\(\\s*)\\/(${resourceRoot})(?=[\\/?#)])`, 'g');
  let rewritten = source
    .replace(quotedResource, `$1${normalizedPrefix}$2`)
    .replace(cssResource, `$1${normalizedPrefix}$2`);

  rewritten = rewritten.replace(
    new RegExp(`(__vite__createHotContext\\(["'])${normalizedPrefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`, 'g'),
    '$1/',
  );

  const importMetaDeclaration = 'const importMetaUrl = new URL(import.meta.url);';
  const socketHostDeclaration =
    'const socketHost = `${null || importMetaUrl.hostname}:${hmrPort || importMetaUrl.port}${"/"}`;';
  if (rewritten.includes(importMetaDeclaration) && rewritten.includes(socketHostDeclaration)) {
    rewritten = rewritten
      .replace(
        importMetaDeclaration,
        `${importMetaDeclaration}\nconst uiBasePath = importMetaUrl.pathname.replace(/@vite\\/client$/, "");`,
      )
      .replace(
        socketHostDeclaration,
        'const socketHost = `${null || importMetaUrl.hostname}:${hmrPort || importMetaUrl.port}${uiBasePath}`;',
      )
      .replace('const base = "/" || "/";', 'const base = uiBasePath || "/";');
  }

  return rewritten;
};

export const rewriteDevelopmentRuntimeAssetUrls = (source: string, requestUrl: string): string => {
  const url = new URL(requestUrl, 'http://development.local');
  const pathname = url.pathname.toLowerCase();
  let rewritten = source;

  if (
    url.searchParams.has('import') &&
    !/\.(?:[cm]?[jt]sx?|css|html?|json)$/.test(pathname)
  ) {
    rewritten = rewritten.replace(
      /(^|\n)(export default )("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')(?=;?\s*(?:\n|$))/,
      (statement, lineStart: string, declaration: string, literal: string) => {
        const value = literal.slice(1, -1);
        if (!value.startsWith('/') || value.startsWith('//')) return statement;
        return `${lineStart}${declaration}new URL(${literal}, import.meta.url).href`;
      },
    );
  }

  if (pathname.endsWith('.css') && rewritten.includes('const __vite__css = ')) {
    const cssResolver =
      'const __vite__resolveCssResourceUrls = (css) => css.replace(/url\\(\\s*(["\']?)(\\/(?!\\/)[^"\')]+)\\1\\s*\\)/g, (_match, quote, url) => `url(${quote}${new URL(url, import.meta.url).href}${quote})`);';
    rewritten = rewritten.replace(
      /(const __vite__css = )("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/,
      (_statement, declaration: string, literal: string) =>
        `${cssResolver}\n${declaration}__vite__resolveCssResourceUrls(${literal})`,
    );
  }

  return rewritten;
};

/**
 * Vite watches filesystem writes, not semantic source changes. Concurrent generators and
 * editor-style atomic saves can therefore emit HMR updates even when the loaded source bytes
 * are unchanged. Keep real HMR intact while dropping only proven no-op writes for modules that
 * have already participated in the active module graph.
 */
export const createNoopHmrGuardPlugin = (): Plugin => {
  const tracker = createSourceContentTracker();
  const normalizeModuleFile = (id: string) => path.resolve(id.split('?', 1)[0]);
  const isApplicationSource = (file: string) => file === sourceRoot || file.startsWith(`${sourceRoot}${path.sep}`);

  return {
    name: 'warehouse-noop-hmr-guard',
    apply: 'serve',
    enforce: 'pre',
    transform(code, id) {
      if (id.startsWith('\0')) return null;
      const file = normalizeModuleFile(id);
      if (isApplicationSource(file)) tracker.remember(file, code);
      return null;
    },
    async handleHotUpdate(context) {
      const file = path.resolve(context.file);
      if (!isApplicationSource(file)) return;

      // Read failures and genuine changes must stay on Vite's normal recovery path. Never hide
      // a required refresh or serve stale modules merely to make an update look seamless.
      let content: string;
      try {
        content = await context.read();
      } catch {
        return;
      }
      if (!tracker.hasChanged(file, content)) return [];
    },
  };
};

type HtmlResourceKind = 'modulepreload' | 'stylesheet' | 'script' | 'icon' | 'manifest';

export interface HtmlResource {
  kind: HtmlResourceKind;
  url: string;
}

const readAttribute = (tag: string, attribute: string): string | null => {
  const match = tag.match(new RegExp(`(?:^|\\s)${attribute}\\s*=\\s*["']([^"']+)["']`, 'i'));
  return match?.[1] || null;
};

export const normalizeBuildAssetPath = (value: string): string =>
  value.replace(/^\.\//, '').replace(/^\//, '');

export const collectHtmlResources = (html: string): HtmlResource[] => {
  const resources: HtmlResource[] = [];

  for (const match of html.matchAll(/<link\b[^>]*>/gi)) {
    const tag = match[0];
    const href = readAttribute(tag, 'href');
    const rel = readAttribute(tag, 'rel')?.toLowerCase();
    if (!href || !rel || /^(?:data:|#)/i.test(href)) continue;

    if (rel === 'modulepreload' || rel === 'stylesheet' || rel === 'manifest') {
      resources.push({ kind: rel, url: normalizeBuildAssetPath(href) });
    } else if (rel.includes('icon')) {
      resources.push({ kind: 'icon', url: normalizeBuildAssetPath(href) });
    }
  }

  for (const match of html.matchAll(/<script\b[^>]*>\s*<\/script>/gi)) {
    const tag = match[0];
    const src = readAttribute(tag, 'src');
    const type = readAttribute(tag, 'type')?.toLowerCase();
    if (src && type === 'module' && !/^(?:data:|#)/i.test(src)) {
      resources.push({ kind: 'script', url: normalizeBuildAssetPath(src) });
    }
  }

  return resources.filter(
    (resource, index, all) =>
      all.findIndex((candidate) => candidate.kind === resource.kind && candidate.url === resource.url) === index,
  );
};

const isLocalResourceReference = (value: string): boolean =>
  !/^(?:[a-z][a-z\d+.-]*:|\/\/|#)/i.test(value.trim());

export const findUnmanagedHtmlResources = (html: string): string[] => {
  const unmanaged: string[] = [];
  const resourceAttributes = ['src', 'poster', 'data'] as const;

  for (const match of html.matchAll(/<(?:img|source|audio|video|track|input|embed|object)\b[^>]*>/gi)) {
    const tag = match[0];
    for (const attribute of resourceAttributes) {
      const value = readAttribute(tag, attribute);
      if (value && isLocalResourceReference(value)) unmanaged.push(`${attribute}=${value}`);
    }
    const srcset = readAttribute(tag, 'srcset');
    if (srcset) {
      for (const candidate of srcset.split(',')) {
        const value = candidate.trim().split(/\s+/)[0];
        if (value && isLocalResourceReference(value)) unmanaged.push(`srcset=${value}`);
      }
    }
  }

  for (const match of html.matchAll(/<link\b[^>]*>/gi)) {
    const tag = match[0];
    const href = readAttribute(tag, 'href');
    const rel = readAttribute(tag, 'rel')?.toLowerCase().split(/\s+/) || [];
    if (href && rel.some((value) => ['preload', 'prefetch'].includes(value)) && isLocalResourceReference(href)) {
      unmanaged.push(`link=${href}`);
    }
  }
  for (const match of html.matchAll(/<script\b[^>]*>/gi)) {
    const src = readAttribute(match[0], 'src');
    if (src && isLocalResourceReference(src)) unmanaged.push(`script=${src}`);
  }
  for (const match of html.matchAll(/<(?:image|use)\b[^>]*>/gi)) {
    const href = readAttribute(match[0], 'href');
    if (href && isLocalResourceReference(href)) unmanaged.push(`href=${href}`);
  }
  for (const match of html.matchAll(/\bstyle\s*=\s*["'][^"']*url\(\s*["']?([^"')]+)["']?\s*\)[^"']*["']/gi)) {
    const value = match[1];
    if (value && isLocalResourceReference(value)) unmanaged.push(`style-url=${value}`);
  }
  return [...new Set(unmanaged)];
};

const createBootstrapSource = (resources: HtmlResource[]): string => `(() => {
  const injected = window.__UI_BASE_PATH__;
  const fallback = new URL('./', window.location.href).origin;
  const rawBase = typeof injected === 'string' && injected.trim() !== '' ? injected.trim() : fallback;
  const base = new URL(rawBase.endsWith('/') ? rawBase : rawBase + '/', document.baseURI).href;
  const resources = ${JSON.stringify(resources)};
  const toUrl = (value) => new URL(String(value).replace(/^\\.\\//, '').replace(/^\\//, ''), base).href;
  const applyCors = (element, url) => {
    if (new URL(url).origin !== window.location.origin) element.crossOrigin = 'anonymous';
  };
  const appendLink = (rel, href) => {
    const element = document.createElement('link');
    element.rel = rel;
    element.href = href;
    applyCors(element, href);
    document.head.appendChild(element);
  };

  for (const resource of resources) {
    const url = toUrl(resource.url);
    if (resource.kind === 'script') continue;
    appendLink(resource.kind === 'icon' ? 'icon' : resource.kind, url);
  }
  for (const resource of resources) {
    if (resource.kind !== 'script') continue;
    const element = document.createElement('script');
    element.type = 'module';
    element.src = toUrl(resource.url);
    element.async = false;
    applyCors(element, element.src);
    document.head.appendChild(element);
  }
})();`;

export const createUiBasePathHtmlPlugin = (): Plugin => ({
  name: 'warehouse-ui-base-path-html',
  enforce: 'post',
  configureServer(server) {
    const activePrefixes = new Set<string>();
    server.middlewares.use((request, response, next) => {
      if (!request.url) return next();
      const matchedPrefix = [...activePrefixes]
        .sort((left, right) => right.length - left.length)
        .find((prefix) => request.url?.startsWith(prefix));
      const resource = matchedPrefix
        ? { prefix: matchedPrefix, url: `/${request.url.slice(matchedPrefix.length)}` }
        : resolveDevelopmentResourceRequest(request.url);

      if (resource) {
        activePrefixes.add(resource.prefix);
        request.url = resource.url;
      }
      const servedUrl = request.url;
      response.setHeader('Access-Control-Allow-Origin', '*');
      const end = response.end.bind(response);
      response.end = ((chunk?: Parameters<typeof response.end>[0], ...args: unknown[]) => {
        const contentType = String(response.getHeader('Content-Type') || '');
        if (chunk && /(?:javascript|typescript|text\/css)/i.test(contentType)) {
          const encoding = typeof args[0] === 'string' ? (args[0] as BufferEncoding) : undefined;
          const source = Buffer.isBuffer(chunk) ? chunk.toString(encoding) : String(chunk);
          const prefixed = resource ? rewriteDevelopmentResourceUrls(source, resource.prefix) : source;
          const rewritten = rewriteDevelopmentRuntimeAssetUrls(prefixed, servedUrl);
          response.setHeader('Content-Length', Buffer.byteLength(rewritten));
          return end(rewritten, ...(args as []));
        }
        return end(chunk, ...(args as []));
      }) as typeof response.end;
      next();
    });
  },
  transformIndexHtml: {
    order: 'post',
    handler(html) {
      const resources = collectHtmlResources(html);
      if (!resources.some((resource) => resource.kind === 'script')) {
        throw new Error('HTML 未找到 Vite module 入口，无法建立 __UI_BASE_PATH__ 启动链路');
      }

      const withoutManagedLinks = html.replace(/<link\b[^>]*>/gi, (tag) => {
        const href = readAttribute(tag, 'href');
        const rel = readAttribute(tag, 'rel')?.toLowerCase();
        if (!href || !rel) return tag;
        return rel === 'modulepreload' || rel === 'stylesheet' || rel === 'manifest' || rel.includes('icon')
          ? ''
          : tag;
      });
      const withoutManagedScripts = withoutManagedLinks.replace(
        /<script\b[^>]*>\s*<\/script>/gi,
        (tag) =>
          readAttribute(tag, 'src') && readAttribute(tag, 'type')?.toLowerCase() === 'module' ? '' : tag,
      );
      const unmanagedResources = findUnmanagedHtmlResources(withoutManagedScripts);
      if (unmanagedResources.length > 0) {
        throw new Error(
          `HTML 存在未纳入 __UI_BASE_PATH__ 的本地资源：${unmanagedResources.join(', ')}。` +
            '请改为从模块或 CSS 导入，或按项目真实启动模型扩展唯一资源启动层。',
        );
      }
      const bootstrap = `<script data-ui-base-path-bootstrap>\n${createBootstrapSource(resources)}\n</script>`;

      if (!withoutManagedScripts.includes('</head>')) {
        throw new Error('生产 HTML 缺少 </head>，无法在合法位置写入资源启动层');
      }
      return withoutManagedScripts.replace('</head>', `  ${bootstrap}\n  </head>`);
    },
  },
});

/** 服务端专用映射，不导入客户端；相对配置文件定位，不依赖启动 cwd。 */
export const readServiceProxy = (file = path.join(projectRoot, 'services.json')): Record<string, ProxyOptions> => {
  let content: string;
  try {
    content = fs.readFileSync(file, 'utf8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return {};
    throw new Error(`读取代理配置失败：${path.resolve(file)}`, { cause: error });
  }
  try {
    const targets = JSON.parse(content);
    if (!targets || typeof targets !== 'object' || Array.isArray(targets)) throw new Error('必须是路径前缀到地址的对象');
    const proxy: Record<string, ProxyOptions> = {};
    for (const [prefix, target] of Object.entries(targets).sort(([a], [b]) => b.length - a.length)) {
      if (!/^\/api(?:\/[A-Za-z0-9_-]+)*\/?$/.test(prefix)) throw new Error(`无效 API 前缀：${prefix}`);
      if (typeof target !== 'string') throw new Error(`无效目标：${prefix}`);
      const url = new URL(target);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) {
        throw new Error(`目标必须是 HTTP(S) origin：${prefix}`);
      }
      const key = `^${prefix.replace(/\/$/, '')}(?:/|\\?|$)`;
      if (proxy[key]) throw new Error(`重复 API 前缀：${prefix}`);
      proxy[key] = { target: url.origin, changeOrigin: true, ws: true };
    }
    return proxy;
  } catch (error) {
    throw new Error(`代理配置无效：${path.resolve(file)}：${String(error)}`, { cause: error });
  }
};

/** 未声明的 API 不进入 SPA fallback，也不猜测默认后端。 */
export const createApiRouteGuard = (proxy: Record<string, ProxyOptions>): Plugin => {
  const routes = Object.keys(proxy).map((key) => new RegExp(key));
  const install = (server: Pick<ViteDevServer, 'middlewares'>) => {
    server.middlewares.use((req, res, next) => {
      const url = req.url || '/';
      if (/^\/api(?:\/|\?|$)/.test(url) && !routes.some((route) => route.test(url))) {
        res.statusCode = 404;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ error: 'API service route is not configured' }));
        return;
      }
      next();
    });
  };
  return { name: 'warehouse-api-route-guard', configureServer: install, configurePreviewServer: install };
};

export default defineConfig(({ command, isPreview }) => {
  const port = process.env.PORT ? Number(process.env.PORT) : undefined;
  if (command === 'serve' && (!Number.isInteger(port) || !port || port < 1 || port > 65535)) {
    throw new Error('PORT 必须由服务清单对应的运行配置注入，不提供默认端口');
  }
  const proxy = readServiceProxy();
  const isDevelopmentPreview = command === 'serve' && !isPreview;
  const base = command === 'serve' ? normalizePreviewBasePath(process.env.VITE_PREVIEW_BASE_PATH) : './';

  return {
    base,
    plugins: [
      createFrontendDomainsPlugin(),
      createApiRouteGuard(proxy),
      createNoopHmrGuardPlugin(),
      ...(isDevelopmentPreview || (isPreview && process.env.VITE_PREVIEW_BASE_PATH?.trim())
        ? [createPreviewBaseAliasPlugin(base)]
        : []),
      ...(command === 'build' ? [createUiBasePathHtmlPlugin()] : []),
    ],
    resolve: {
      alias: {
        '@': path.resolve(projectRoot, 'src'),
      },
    },
    server: {
      host,
      port,
      strictPort: true,
      allowedHosts: true,
      hmr: { overlay: false },
      watch: {
        // Wait for one source write to become stable before transforming it. This coalesces
        // chunked/atomic saves without turning HMR into a fixed-delay polling workflow.
        awaitWriteFinish: {
          stabilityThreshold: 150,
          pollInterval: 25,
        },
      },
      proxy,
    },
    preview: {
      host,
      port,
      strictPort: true,
      allowedHosts: true,
      proxy,
    },
    build: {
      outDir: 'dist',
      emptyOutDir: true,
      sourcemap: false,
      assetsInlineLimit: 0,
    },
  };
});
