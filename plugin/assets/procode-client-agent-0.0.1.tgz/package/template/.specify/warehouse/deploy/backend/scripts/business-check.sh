#!/usr/bin/env bash
set -euo pipefail

# Replace with one bounded, read-only smoke check of this service's real capabilities.
# BUSINESS_CHECK_URL is the candidate URL, not the formal service registry URL.
echo '业务可用性冒烟检查失败：后端 business-check.sh 尚未根据真实项目生成' >&2
exit 1
