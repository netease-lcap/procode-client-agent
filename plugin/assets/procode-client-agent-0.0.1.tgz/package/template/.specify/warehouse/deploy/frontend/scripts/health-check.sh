#!/usr/bin/env bash
set -euo pipefail

echo '前端部署 health-check.sh 尚未根据真实项目生成' >&2
exit 1
