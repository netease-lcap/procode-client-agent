#!/usr/bin/env bash
set -euo pipefail

echo '后端部署 start.sh 尚未根据真实项目生成' >&2
exit 1
