#!/usr/bin/env bash
set -euo pipefail

# Replace with one bounded smoke check of the actual page and essential data/resources.
# Reuse test-helper.mjs for browser checks; explicitly use BUSINESS_CHECK_URL as baseUrl.
echo '业务可用性冒烟检查失败：前端 business-check.sh 尚未根据真实项目生成' >&2
exit 1
